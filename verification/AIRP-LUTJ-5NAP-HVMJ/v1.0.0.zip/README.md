# Verification materials

Sharp Counts and Small Integer Witnesses for Tight Cone Rules
Version 1.0.0

Python 3, standard library only. Run the .py files from this folder without -O. The checks supplement the proofs in the manuscript.

Included files:
- lp_exact.py
