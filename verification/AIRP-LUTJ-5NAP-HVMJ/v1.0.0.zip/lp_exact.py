from fractions import Fraction as F
from itertools import combinations,permutations
import random,json
from math import gcd,lcm

def nullspace(A):
    A=[[F(v) for v in r] for r in A];m=len(A);n=len(A[0]);piv=[];i=0
    for j in range(n):
        k=next((k for k in range(i,m) if A[k][j]),None)
        if k is None:continue
        A[i],A[k]=A[k],A[i];d=A[i][j];A[i]=[v/d for v in A[i]]
        for k in range(m):
            if k!=i:
                d=A[k][j];A[k]=[a-d*b for a,b in zip(A[k],A[i])]
        piv.append(j);i+=1
        if i==m:break
    out=[]
    for j in range(n):
        if j in piv:continue
        v=[F(0)]*n;v[j]=1
        for i,k in enumerate(piv):v[k]=-A[i][j]
        out.append(v)
    return out

def normalize(v):
    if not any(v):return None
    if all(x<=0 for x in v):v=[-x for x in v]
    if not all(x>=0 for x in v):return None
    d=next(x for x in v if x);return tuple(F(x)/d for x in v)

def columns(H):return list(zip(*H))
def structure(H):
    cols=columns(H);pure=[i for i,c in enumerate(cols) if sum(x!=0 for x in c)==1]
    C={next(j for j,x in enumerate(cols[i]) if x) for i in pure}
    return [i for i in range(len(H)) if i not in pure],[j for j in range(len(H)) if j not in C]

def covers(H,y):
    hits=set()
    for h in columns(H):
        pos=[-y[k]/h[k] for k in range(len(y)) if h[k]>0]
        neg=[-y[k]/h[k] for k in range(len(y)) if h[k]<0]
        vs=[]
        vs.append([y[k]+max(pos)*h[k] for k in range(len(y))] if pos else [-v for v in h])
        vs.append([y[k]+min(neg)*h[k] for k in range(len(y))] if neg else list(h))
        for v in vs:
            assert all(x>=0 for x in v)
            nz=[i for i,x in enumerate(v) if x]
            if len(nz)==1:hits.add(nz[0])
    return len(hits)==len(y)

def all_tight(H):
    n=len(H);I,R=structure(H);assert len(I)==len(R)>=3
    H=[[F(v) for v in row] for row in H];cols=columns(H);cand=set()
    for a in range(n):cand.add(tuple(F(i==a) for i in range(n)))
    # Every two-support witness needs an outside missing ray, fixing its ratio.
    for a,b in combinations(range(n),2):
        for h in cols:
            if h[a]*h[b]>0:
                v=[F(0)]*n;v[a]=abs(h[a]);v[b]=abs(h[b]);cand.add(normalize(v))
    # Every large-support witness belongs to two distinct missing-ray planes.
    j,k=R[:2]
    for i,l in permutations(I,2):
        A=[[cols[i][a],F(a==j),-cols[l][a],-F(a==k)] for a in range(n)]
        basis=nullspace(A)
        if len(basis)!=1:continue
        v=basis[0];y=normalize([v[0]*cols[i][a]+v[1]*(a==j) for a in range(n)])
        if y is not None:cand.add(y)
    return sorted(y for y in cand if covers(H,y))

def triangle(H):
    I,R=structure(H)
    if len(I)!=3:return False
    seen=set()
    for i in I:
        h=columns(H)[i];S=tuple(j for j,v in enumerate(h) if v)
        if len(S)!=2 or not set(S)<=set(R) or h[S[0]]*h[S[1]]>=0:return False
        seen.add(S)
    return len(seen)==3

def audit(H):
    if nullspace(H):return None
    I,R=structure(H)
    if len(I)<3:return None
    ys=all_tight(H);q=len(I)
    assert len(ys)<=(3 if q==3 else 1),(H,ys)
    assert (len(ys)==3)==triangle(H),(H,ys)
    assert sum(sum(v>0 for v in y)>=3 for y in ys)<=1
    if any(sum(v>0 for v in y)>=3 for y in ys):assert len(ys)==1
    return {'m':len(H),'q':q,'count':len(ys),'witnesses':[[str(v) for v in y] for y in ys]}

def primitive(y):
    den=lcm(*(F(v).denominator for v in y));v=[int(F(a)*den) for a in y]
    g=gcd(*v);return [a//g for a in v]

out={'scope':'exact complete candidate enumeration for each tested rational H with q>=3; finite testing is not the universal proof','cases':[]}
def keep(name,H):
    r=audit(H)
    if r is not None:out['cases'].append({'name':name,'H':H,**r})

for m in range(3,9):
    H=[[(m+1 if i==j else 0)-1 for j in range(m)] for i in range(m)]
    keep('dense_sharp',H);assert out['cases'][-1]['count']==1
for alpha,beta,gamma in [(1,1,2),(2,3,5),(1,2,1)]:
    T=[[1,0,-gamma],[-alpha,1,0],[0,-beta,1]]
    for extra in range(4):
        n=3+extra;H=[[T[i][j] if i<3 and j<3 else int(i==j) for j in range(n)] for i in range(n)]
        keep('triangle_with_pure_padding',H);assert out['cases'][-1]['count']==3

# Exact nonzero structural perturbations must not silently inherit the zero pattern.
for eps in [-2,-1,0,1,2]:
    keep('structural_zero_test',[[1,eps,-2],[-1,1,0],[0,-1,1]])

rng=random.Random(20261018)
for m in [3,4,5]:
    for k in range(50):
        H=[[rng.choice([-2,-1,0,0,1,2]) for j in range(m)] for i in range(m)]
        keep('fixed_seed_rational',H)

height_examples=[]
for M in [3,5,7,11,31,101]:
    a,b,c=M,M-1,M-2
    H=[[1,-a,-b],[-a,1,-c],[-b,-c,1]]
    keep('quadratic_height_sharp_exponent',H)
    ys=all_tight(H);assert len(ys)==1
    v=primitive(ys[0]);assert v==[a*b,a*c,b*c] and max(v)==M*(M-1)
    height_examples.append({'M':M,'primitive':v,'height':max(v)})
height_count=0
for case in out['cases']:
    M=max(abs(v) for row in case['H'] for v in row)
    for y in case['witnesses']:
        v=primitive(y);assert max(v)<=M*M
        if sum(a>0 for a in v)==2:assert max(v)<=M
        height_count+=1

# Sharp q=3 and q>=4 bounds fail if deliberately changed to 2 and 0.
assert any(c['count']==3 for c in out['cases'])
assert any(c['q']>=4 and c['count']==1 for c in out['cases'])
out['negative_controls']={'false_q3_bound_2_rejected':True,'false_q4_bound_0_rejected':True,'singular_triangle_excluded':bool(nullspace([[1,0,-1],[-1,1,0],[0,-1,1]]))}
out['height_lemma']={'checked_witnesses':height_count,'sharp_exponent_families':height_examples,'false_linear_M_bound_rejected':all(v['height']>v['M'] for v in height_examples)}
out['summary']={'matrices':len(out['cases']),'nonempty':sum(c['count']>0 for c in out['cases']),'counts':{str(k):sum(c['count']==k for c in out['cases']) for k in range(4)}}
with open(__file__.replace('.py','.json'),'w') as f:json.dump(out,f,indent=2)
print('PASS',out['summary'],out['negative_controls'])
