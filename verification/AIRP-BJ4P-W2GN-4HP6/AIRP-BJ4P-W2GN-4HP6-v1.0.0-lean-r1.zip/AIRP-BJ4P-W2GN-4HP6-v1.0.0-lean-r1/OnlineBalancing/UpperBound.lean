import OnlineBalancing.TwoStreamCore
import Mathlib.Data.Fin.Tuple.Sort
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace OnlineBalancing
open Finset

/-- Pairwise form of the maximum-minus-minimum bound. -/
def RangeBound {n : ℕ} (x : Fin n → ℝ) (R : ℝ) : Prop :=
  ∀ i j, x i - x j ≤ R

noncomputable def mean {n : ℕ} (x : Fin n → ℝ) : ℝ :=
  (∑ i, x i) / n

theorem range_opposite {n : ℕ} (x y : Fin n → ℝ) (R : ℝ)
    (hx : Monotone x) (hy : Antitone y)
    (hxr : RangeBound x R) (hyr : RangeBound y R) :
    RangeBound (fun i => x i + y i) R := by
  intro i j
  rcases le_total i j with h | h
  · have := hx h
    have := hyr i j
    linarith
  · have := hy h
    have := hxr i j
    linarith

noncomputable def oppositePerm {n : ℕ} (x y : Fin n → ℝ) : Equiv.Perm (Fin n) :=
  (Tuple.sort x).symm.trans (Tuple.sort (fun i => -y i))

theorem oppositePerm_range {n : ℕ} (x y : Fin n → ℝ) (R : ℝ)
    (hx : RangeBound x R) (hy : RangeBound y R) :
    RangeBound (fun i => x i + y (oppositePerm x y i)) R := by
  let p := Tuple.sort x
  let q := Tuple.sort (fun i => -y i)
  have hxs : Monotone (fun i => x (p i)) := Tuple.monotone_sort x
  have hys : Antitone (fun i => y (q i)) := by
    intro i j h
    have hh := Tuple.monotone_sort (fun i => -y i) h
    change -y (q i) ≤ -y (q j) at hh
    linarith
  have h := range_opposite (fun i => x (p i)) (fun i => y (q i)) R hxs hys
    (fun i j => hx (p i) (p j)) (fun i j => hy (q i) (q j))
  intro i j
  simpa [oppositePerm, p, q] using h (p.symm i) (p.symm j)

theorem mean_add {n : ℕ} (x y : Fin n → ℝ) :
    mean (fun i => x i + y i) = mean x + mean y := by
  simp [mean, Finset.sum_add_distrib, add_div]

theorem mean_smul_perm {n : ℕ} (x : Fin n → ℝ) (e : ℝ)
    (p : Equiv.Perm (Fin n)) :
    mean (fun i => e * x (p i)) = e * mean x := by
  rw [mean, ← Finset.mul_sum, Equiv.sum_comp p]
  simp [mean, mul_div_assoc]

theorem cube_range {n : ℕ} (v : Fin n → ℝ) (hv : InCube v) : RangeBound v 2 := by
  intro i j
  have hi := (abs_le.mp (hv i)).2
  have hj := (abs_le.mp (hv j)).1
  linarith

theorem cube_mean {n : ℕ} (hn : 0 < n) (v : Fin n → ℝ) (hv : InCube v) :
    |mean v| ≤ 1 := by
  have hn' : (0 : ℝ) < n := Nat.cast_pos.mpr hn
  apply abs_le.mpr
  constructor
  · apply (le_div_iff₀ hn').mpr
    have h := Finset.sum_le_sum (s := Finset.univ) (fun i _ => (abs_le.mp (hv i)).1)
    simpa using h
  · apply (div_le_iff₀ hn').mpr
    have h := Finset.sum_le_sum (s := Finset.univ) (fun i _ => (abs_le.mp (hv i)).2)
    simpa using h

noncomputable def chosenSign (a b : ℝ) : ℝ := if a * b ≤ 0 then 1 else -1

theorem chosenSign_mem (a b : ℝ) : chosenSign a b = 1 ∨ chosenSign a b = -1 := by
  unfold chosenSign
  split_ifs <;> simp

theorem chosenSign_mean (a b : ℝ) (ha : |a| ≤ 1) (hb : |b| ≤ 1) :
    |a + chosenSign a b * b| ≤ 1 := by
  obtain ⟨ha₁, ha₂⟩ := abs_le.mp ha
  obtain ⟨hb₁, hb₂⟩ := abs_le.mp hb
  unfold chosenSign
  split_ifs with h
  · simp only [one_mul]
    rcases le_total a 0 with hA | hA <;> rcases le_total b 0 with hB | hB <;>
      apply abs_le.mpr <;> constructor <;> nlinarith
  · simp only [neg_mul, one_mul]
    rcases le_total a 0 with hA | hA <;> rcases le_total b 0 with hB | hB <;>
      apply abs_le.mpr <;> constructor <;> nlinarith

noncomputable def upperMove {n : ℕ} (s v : Fin n → ℝ) : LegalMove (Fin n) where
  sign := chosenSign (mean s) (mean v)
  sign_mem := chosenSign_mem _ _
  perm := oppositePerm s (fun i => chosenSign (mean s) (mean v) * v i)

theorem sign_cube {n : ℕ} (v : Fin n → ℝ) (hv : InCube v)
    (e : ℝ) (he : e = 1 ∨ e = -1) : InCube (fun i => e * v i) := by
  rcases he with rfl | rfl <;> simpa [InCube] using hv

def UpperInvariant {n : ℕ} (s : Fin n → ℝ) : Prop :=
  |mean s| ≤ 1 ∧ RangeBound s 2

theorem upperMove_invariant {n : ℕ} (hn : 0 < n) (s v : Fin n → ℝ)
    (hs : UpperInvariant s) (hv : InCube v) :
    UpperInvariant (fun i => s i + move (upperMove s v) v i) := by
  constructor
  · rw [show (fun i => s i + move (upperMove s v) v i) =
        (fun i => s i + (upperMove s v).sign * v ((upperMove s v).perm i)) from rfl,
      mean_add, mean_smul_perm]
    exact chosenSign_mean _ _ hs.1 (cube_mean hn v hv)
  · exact oppositePerm_range s _ 2 hs.2
      (cube_range _ (sign_cube v hv _ (chosenSign_mem _ _)))

/-- A single coordinate's deviation is bounded by all other coordinate differences. -/
theorem coordinate_mean_upper {n : ℕ} (hn : 0 < n) (x : Fin n → ℝ) (R : ℝ)
    (hx : RangeBound x R) (i : Fin n) :
    x i - mean x ≤ ((n : ℝ) - 1) * R / n := by
  have hn' : (0 : ℝ) < n := Nat.cast_pos.mpr hn
  have hsum := Finset.sum_le_sum (s := Finset.univ.erase i)
    (fun j _ => hx i j)
  have hcard : (Finset.univ.erase i).card = n - 1 := by simp
  have hzero := Finset.sum_erase_add (Finset.univ (α := Fin n))
    (fun j => x i - x j) (Finset.mem_univ i)
  simp only [sub_self, add_zero] at hzero
  rw [Finset.sum_const, hcard, nsmul_eq_mul, Nat.cast_sub (by omega : 1 ≤ n),
    Nat.cast_one, hzero, Finset.sum_sub_distrib] at hsum
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at hsum
  have hm : mean x * n = ∑ j, x j := by
    exact div_mul_cancel₀ _ (ne_of_gt hn')
  apply (le_div_iff₀ hn').mpr
  nlinarith

theorem mean_neg {n : ℕ} (x : Fin n → ℝ) : mean (fun i => -x i) = -mean x := by
  simp [mean, Finset.sum_neg_distrib, neg_div]

theorem coordinate_deviation {n : ℕ} (hn : 0 < n) (x : Fin n → ℝ) (R : ℝ)
    (hx : RangeBound x R) (i : Fin n) :
    |x i - mean x| ≤ ((n : ℝ) - 1) * R / n := by
  have hi := coordinate_mean_upper hn x R hx i
  have hj := coordinate_mean_upper hn (fun j => -x j) R (by
    intro a b
    have := hx b a
    linarith) i
  rw [mean_neg] at hj
  exact abs_le.mpr ⟨by linarith, hi⟩

theorem invariant_coordinate_bound {n : ℕ} (hn : 0 < n) (x : Fin n → ℝ)
    (hx : UpperInvariant x) (i : Fin n) :
    |x i| ≤ 3 - 2 / n := by
  have hn' : (0 : ℝ) < n := Nat.cast_pos.mpr hn
  have h := coordinate_deviation hn x 2 hx.2 i
  have ht : |x i| ≤ |x i - mean x| + |mean x| := by
    simpa using abs_add_le (x i - mean x) (mean x)
  have heq : ((n : ℝ) - 1) * 2 / n + 1 = 3 - 2 / n := by
    field_simp
    ring
  linarith [hx.1]

noncomputable def upperStep {n : ℕ} (s v : Fin n → ℝ) : Fin n → ℝ :=
  fun i => s i + move (upperMove s v) v i

noncomputable def upperState {n : ℕ} (inputs : List (Fin n → ℝ)) : Fin n → ℝ :=
  inputs.foldl upperStep (fun _ => 0)

noncomputable def upperPolicy {n : ℕ} : Policy (Fin n) := fun inputs =>
  match inputs.reverse with
  | [] => upperMove (fun _ => 0) (fun _ => 0)
  | v :: history => upperMove (upperState history.reverse) v

theorem upperPolicy_append {n : ℕ} (history : List (Fin n → ℝ)) (v : Fin n → ℝ) :
    upperPolicy (history ++ [v]) = upperMove (upperState history) v := by
  simp [upperPolicy]

theorem upperState_append {n : ℕ} (history : List (Fin n → ℝ)) (v : Fin n → ℝ) :
    upperState (history ++ [v]) = upperStep (upperState history) v := by
  simp [upperState, List.foldl_append]

theorem upper_playFrom {n : ℕ} (inputs history : List (Fin n → ℝ)) :
    playFrom upperPolicy history (upperState history) inputs = upperState (history ++ inputs) := by
  induction inputs generalizing history with
  | nil => simp [playFrom]
  | cons v vs ih =>
    rw [playFrom, upperPolicy_append]
    change playFrom upperPolicy (history ++ [v]) (upperStep (upperState history) v) vs = _
    rw [← upperState_append, ih]
    simp [List.append_assoc]

theorem upper_play {n : ℕ} (inputs : List (Fin n → ℝ)) :
    play upperPolicy inputs = upperState inputs := by
  simpa [play, upperState] using upper_playFrom inputs []

theorem upperState_invariant {n : ℕ} (hn : 0 < n) (inputs : List (Fin n → ℝ))
    (hi : ∀ v ∈ inputs, InCube v) : UpperInvariant (upperState inputs) := by
  have hfold : ∀ (xs : List (Fin n → ℝ)) (s : Fin n → ℝ),
      (∀ v ∈ xs, InCube v) → UpperInvariant s → UpperInvariant (xs.foldl upperStep s) := by
    intro xs
    induction xs with
    | nil => intro s _ hs; exact hs
    | cons v vs ih =>
      intro s hx hs
      apply ih (upperStep s v)
      · intro w hw; exact hx w (List.mem_cons_of_mem v hw)
      · exact upperMove_invariant hn s v hs (hx v (List.mem_cons_self))
  apply hfold inputs (fun _ => 0) hi
  constructor
  · simp [mean]
  · intro i j; norm_num

theorem upper_all_prefixes {n : ℕ} (hn : 0 < n) (inputs : List (Fin n → ℝ))
    (hi : ∀ v ∈ inputs, InCube v) (k : ℕ) (i : Fin n) :
    |play upperPolicy (inputs.take k) i| ≤ 3 - 2 / n := by
  rw [upper_play]
  apply invariant_coordinate_bound hn _
  apply upperState_invariant hn
  intro v hv
  exact hi v (List.mem_of_mem_take hv)

theorem upper_bound_nonnegative {n : ℕ} (hn : 0 < n) : (0 : ℝ) ≤ 3 - 2 / n := by
  have hn' : (1 : ℝ) ≤ n := by exact_mod_cast hn
  have hd : (2 : ℝ) / n ≤ 2 := (div_le_iff₀ (by linarith)).mpr (by linarith)
  linarith

/-- The known general upper bound, via the actual deterministic causal sorting policy.
    The manuscript credits Niles-Weed, Sadovsky and Shkrob, Theorem 9. -/
theorem onlineValue_upper_bound {n : ℕ} (hn : 0 < n) :
    onlineValue n ≤ ENNReal.ofReal (3 - 2 / (n : ℝ)) := by
  unfold onlineValue
  apply iInf_le_of_le (upperPolicy : Policy (Fin n))
  apply iSup_le
  intro inputs
  apply iSup_le
  intro k
  apply ENNReal.ofReal_le_ofReal
  apply (pi_norm_le_iff_of_nonneg (upper_bound_nonnegative hn)).mpr
  intro i
  simpa [Real.norm_eq_abs] using upper_all_prefixes hn inputs.val inputs.property k.val i

theorem onlineValue_four : onlineValue 4 = ENNReal.ofReal (5 / 2 : ℝ) := by
  apply le_antisymm
  · convert onlineValue_upper_bound (n := 4) (by norm_num) using 1 <;> norm_num
  · exact onlineValue_lower_bound 4 (by norm_num)

/-- Finiteness of the extended minimax value; this justifies its real representative. -/
theorem onlineValue_ne_top {n : ℕ} (hn : 0 < n) : onlineValue n ≠ ⊤ := by
  exact ne_top_of_le_ne_top ENNReal.ofReal_ne_top (onlineValue_upper_bound hn)

noncomputable def finiteOnlineValue (n : ℕ) : ℝ := (onlineValue n).toReal

theorem finiteOnlineValue_nonnegative (n : ℕ) : 0 ≤ finiteOnlineValue n :=
  ENNReal.toReal_nonneg

theorem finiteOnlineValue_exact {n : ℕ} (hn : 0 < n) :
    ENNReal.ofReal (finiteOnlineValue n) = onlineValue n :=
  ENNReal.ofReal_toReal (onlineValue_ne_top hn)

theorem finiteOnlineValue_upper {n : ℕ} (hn : 0 < n) :
    finiteOnlineValue n ≤ 3 - 2 / (n : ℝ) := by
  have h := ENNReal.toReal_mono ENNReal.ofReal_ne_top (onlineValue_upper_bound hn)
  simpa [finiteOnlineValue, ENNReal.toReal_ofReal (upper_bound_nonnegative hn)] using h

theorem finiteOnlineValue_four : finiteOnlineValue 4 = (5 / 2 : ℝ) := by
  norm_num [finiteOnlineValue, onlineValue_four]

theorem finiteOnlineValue_lower {n : ℕ} (hn : 4 ≤ n) :
    (5 / 2 : ℝ) ≤ finiteOnlineValue n := by
  have h := ENNReal.toReal_mono (onlineValue_ne_top (by omega : 0 < n))
    (onlineValue_lower_bound n hn)
  norm_num [finiteOnlineValue] at h ⊢
  exact h

theorem high_dimensional_main {n : ℕ} (hn : 4 ≤ n) :
    (5 / 2 : ℝ) ≤ finiteOnlineValue n ∧ finiteOnlineValue n ≤ 3 - 2 / (n : ℝ) :=
  ⟨finiteOnlineValue_lower hn, finiteOnlineValue_upper (by omega)⟩

end OnlineBalancing
