import Mathlib.Basic.Real.Basic
import Mathlib.Tactic.NormNum
import Mathlib.Analysis.Normed.Group.Constructions
import Mathlib.Analysis.Normed.Group.Real
import Mathlib.Basic.ENNReal.Real

namespace OnlineBalancing

/-- The normalized B state in the four-round obstruction, over real coordinates. -/
noncomputable def stateB {ι : Type*} [DecidableEq ι] (special i : ι) : ℝ :=
  if i = special then (1 / 2 : ℝ) else (-3 / 2 : ℝ)

/-- Two distinct negative unit entries cannot both land at the exceptional coordinate. -/
theorem stateB_escape_of_two_negatives {ι : Type*} [DecidableEq ι]
    (special : ι) (v : ι → ℝ) (j k : ι)
    (hjk : j ≠ k) (hj : v j = -1) (hk : v k = -1) :
    ∃ i, stateB special i + v i = (-5 / 2 : ℝ) := by
  by_cases hjs : j = special
  · have hks : k ≠ special := by
      intro h
      exact hjk (hjs.trans h.symm)
    exact ⟨k, by simp [stateB, hks, hk]; norm_num⟩
  · exact ⟨j, by simp [stateB, hjs, hj]; norm_num⟩

/-- Every permutation and either global sign of a vector with two positive and
    two negative unit entries forces the B-state escape. No coordinatewise signs. -/
theorem stateB_escape_signed_permutation {ι : Type*} [DecidableEq ι]
    (special : ι) (w : ι → ℝ) (p : Equiv.Perm ι) (ε : ℝ)
    (hε : ε = 1 ∨ ε = -1)
    (neg₁ neg₂ pos₁ pos₂ : ι)
    (hn : neg₁ ≠ neg₂) (hp : pos₁ ≠ pos₂)
    (hn₁ : w neg₁ = -1) (hn₂ : w neg₂ = -1)
    (hp₁ : w pos₁ = 1) (hp₂ : w pos₂ = 1) :
    ∃ i, stateB special i + ε * w (p i) = (-5 / 2 : ℝ) := by
  rcases hε with h | h
  · apply stateB_escape_of_two_negatives special (fun i => ε * w (p i))
      (p.symm neg₁) (p.symm neg₂)
    · exact fun e => hn (p.symm.injective e)
    · simp [h, hn₁]
    · simp [h, hn₂]
  · apply stateB_escape_of_two_negatives special (fun i => ε * w (p i))
      (p.symm pos₁) (p.symm pos₂)
    · exact fun e => hp (p.symm.injective e)
    · simp [h, hp₁]
    · simp [h, hp₂]

/-- The paper's four-coordinate obstruction, padded by zero in higher dimensions. -/
def fourRoundInput (n : ℕ) (i : Fin n) : ℝ :=
  if i.val < 2 then 1 else if i.val < 4 then -1 else 0

/-- The B branch of the paper's obstruction, for its exact w and all n ≥ 4. -/
theorem paper_B_branch (n : ℕ) (hn : 4 ≤ n) (special : Fin n)
    (p : Equiv.Perm (Fin n)) (ε : ℝ) (hε : ε = 1 ∨ ε = -1) :
    ∃ i, stateB special i + ε * fourRoundInput n (p i) = (-5 / 2 : ℝ) := by
  apply stateB_escape_signed_permutation special (fourRoundInput n) p ε hε
    ⟨2, by omega⟩ ⟨3, by omega⟩ ⟨0, by omega⟩ ⟨1, by omega⟩
  · intro h
    have := congrArg Fin.val h
    simp at this
  · intro h
    have := congrArg Fin.val h
    simp at this
  · norm_num [fourRoundInput]
  · norm_num [fourRoundInput]
  · norm_num [fourRoundInput]
  · norm_num [fourRoundInput]


/-- A legal move uses one global sign and one coordinate permutation. -/
structure LegalMove (ι : Type*) where
  sign : ℝ
  sign_mem : sign = 1 ∨ sign = -1
  perm : Equiv.Perm ι

def move {ι : Type*} (g : LegalMove ι) (v : ι → ℝ) (i : ι) : ℝ :=
  g.sign * v (g.perm i)

noncomputable def stateA {ι : Type*} [DecidableEq ι] (special i : ι) : ℝ :=
  if i = special then (3 / 2 : ℝ) else (-1 / 2 : ℝ)

def firstInput {ι : Type*} [DecidableEq ι] (special i : ι) : ℝ :=
  if i = special then 1 else -1

def normalize {ι : Type*} (g : LegalMove ι) (v : ι → ℝ) (i : ι) : ℝ :=
  g.sign * v (g.perm.symm i)

noncomputable def normalizedMove {ι : Type*} (g h : LegalMove ι) : LegalMove ι where
  sign := g.sign * h.sign
  sign_mem := by
    rcases g.sign_mem with hg | hg <;> rcases h.sign_mem with hh | hh <;>
      simp [hg, hh]
  perm := g.perm.symm.trans h.perm

theorem normalize_step {ι : Type*} (g h : LegalMove ι) (s v : ι → ℝ) :
    normalize g (fun i => s i + move h v i) =
      fun i => normalize g s i + move (normalizedMove g h) v i := by
  funext i
  simp only [normalize, move, normalizedMove, Equiv.trans_apply]
  simp only [mul_add, mul_assoc]

theorem normalize_first {ι : Type*} (g : LegalMove ι) (v : ι → ℝ) :
    normalize g (move g v) = v := by
  funext i
  rcases g.sign_mem with h | h <;> simp [normalize, move, h]

theorem abs_normalize {ι : Type*} (g : LegalMove ι) (v : ι → ℝ) (i : ι) :
    |normalize g v i| = |v (g.perm.symm i)| := by
  rcases g.sign_mem with h | h <;> simp [normalize, h]

theorem prefix_normalizes_to_A_or_B {ι : Type*} [DecidableEq ι]
    (special : ι) (g h : LegalMove ι) :
    normalize g (fun i => move g (firstInput special) i +
      move h (fun _ => (1 / 2 : ℝ)) i) = stateA special ∨
    normalize g (fun i => move g (firstInput special) i +
      move h (fun _ => (1 / 2 : ℝ)) i) = stateB special := by
  rw [normalize_step, normalize_first]
  rcases (normalizedMove g h).sign_mem with hp | hm
  · left; funext i; by_cases hi : i = special <;>
      simp [firstInput, stateA, move, hp, hi] <;> norm_num
  · right; funext i; by_cases hi : i = special <;>
      simp [firstInput, stateB, move, hm, hi] <;> norm_num

theorem stateA_minus_one {ι : Type*} [DecidableEq ι] (special : ι) :
    (fun i => stateA special i - 1) = stateB special := by
  funext i; by_cases hi : i = special <;> simp [stateA, stateB, hi] <;> norm_num

/-- The A branch either escapes immediately or reaches exactly B before w. -/
theorem paper_A_branch (n : ℕ) (hn : 4 ≤ n) (special : Fin n)
    (g h : LegalMove (Fin n)) :
    (∃ i, stateA special i + move g (fun _ => 1) i = (5 / 2 : ℝ)) ∨
    (∃ i, stateA special i + move g (fun _ => 1) i +
      move h (fourRoundInput n) i = (-5 / 2 : ℝ)) := by
  rcases g.sign_mem with hg | hg
  · left; exact ⟨special, by norm_num [stateA, move, hg]⟩
  · right
    obtain ⟨i, hi⟩ := paper_B_branch n hn special h.perm h.sign h.sign_mem
    refine ⟨i, ?_⟩
    have hs := congrFun (stateA_minus_one special) i
    simpa only [move, hg, mul_one, ← sub_eq_add_neg, hs] using hi

/-- Escape is preserved by undoing a legal global reflection and relabeling. -/
theorem escape_of_normalized {ι : Type*} (g : LegalMove ι) (s : ι → ℝ)
    (h : ∃ i, normalize g s i = (5 / 2 : ℝ) ∨
      normalize g s i = (-5 / 2 : ℝ)) : ∃ i, |s i| = (5 / 2 : ℝ) := by
  obtain ⟨i, hi⟩ := h
  refine ⟨g.perm.symm i, ?_⟩
  rw [← abs_normalize g s i]
  rcases hi with hi | hi <;> rw [hi] <;> norm_num

/-- Quantifies over all legal actions in both continuations, with shared first two moves. -/
theorem four_round_legal_obstruction (n : ℕ) (hn : 4 ≤ n) (special : Fin n)
    (g₁ g₂ g₃₀ g₃₁ g₄₁ : LegalMove (Fin n)) :
    let s₂ := fun i => move g₁ (firstInput special) i +
      move g₂ (fun _ => (1 / 2 : ℝ)) i
    (∃ i, |s₂ i + move g₃₀ (fourRoundInput n) i| = (5 / 2 : ℝ)) ∨
    (∃ i, |s₂ i + move g₃₁ (fun _ => 1) i| = (5 / 2 : ℝ)) ∨
    (∃ i, |s₂ i + move g₃₁ (fun _ => 1) i +
      move g₄₁ (fourRoundInput n) i| = (5 / 2 : ℝ)) := by
  dsimp only
  let s₂ := fun i => move g₁ (firstInput special) i +
    move g₂ (fun _ => (1 / 2 : ℝ)) i
  rcases prefix_normalizes_to_A_or_B special g₁ g₂ with hA | hB
  · change normalize g₁ s₂ = stateA special at hA
    obtain h | h := paper_A_branch n hn special (normalizedMove g₁ g₃₁)
      (normalizedMove g₁ g₄₁)
    · right; left
      apply escape_of_normalized g₁
      obtain ⟨i, hi⟩ := h
      refine ⟨i, Or.inl ?_⟩
      change normalize g₁ (fun j => s₂ j + move g₃₁ (fun _ => 1) j) i = _
      simpa only [normalize_step, hA] using hi
    · right; right
      apply escape_of_normalized g₁
      obtain ⟨i, hi⟩ := h
      refine ⟨i, Or.inr ?_⟩
      change normalize g₁ (fun j => s₂ j + move g₃₁ (fun _ => 1) j +
        move g₄₁ (fourRoundInput n) j) i = _
      simpa only [normalize_step, hA] using hi
  · change normalize g₁ s₂ = stateB special at hB
    left
    apply escape_of_normalized g₁
    obtain ⟨i, hi⟩ := paper_B_branch n hn special (normalizedMove g₁ g₃₀).perm
      (normalizedMove g₁ g₃₀).sign (normalizedMove g₁ g₃₀).sign_mem
    refine ⟨i, Or.inr ?_⟩
    change normalize g₁ (fun j => s₂ j + move g₃₀ (fourRoundInput n) j) i = _
    have hi' : stateB special i + move (normalizedMove g₁ g₃₀) (fourRoundInput n) i = (-5 / 2 : ℝ) := hi
    simpa only [normalize_step, hB] using hi'


/-- Deterministic causal controller: the action may use the entire revealed input prefix. -/
abbrev Policy (ι : Type*) := List (ι → ℝ) → LegalMove ι

def playFrom {ι : Type*} (P : Policy ι) (history : List (ι → ℝ))
    (state : ι → ℝ) : List (ι → ℝ) → (ι → ℝ)
  | [] => state
  | v :: vs => playFrom P (history ++ [v])
      (fun i => state i + move (P (history ++ [v])) v i) vs

def play {ι : Type*} (P : Policy ι) (inputs : List (ι → ℝ)) : ι → ℝ :=
  playFrom P [] (fun _ => 0) inputs

/-- The two fixed streams share their actual policy actions on the common prefix.
    The last zero in S0 is immaterial because its escape occurs at prefix length 3. -/
theorem deterministic_two_stream_obstruction (n : ℕ) (hn : 4 ≤ n)
    (special : Fin n) (P : Policy (Fin n)) :
    (∃ i, |play P [firstInput special, (fun _ => (1 / 2 : ℝ)), fourRoundInput n] i|
      = (5 / 2 : ℝ)) ∨
    (∃ i, |play P [firstInput special, (fun _ => (1 / 2 : ℝ)), (fun _ => 1)] i|
      = (5 / 2 : ℝ)) ∨
    (∃ i, |play P [firstInput special, (fun _ => (1 / 2 : ℝ)), (fun _ => 1),
      fourRoundInput n] i| = (5 / 2 : ℝ)) := by
  simpa [play, playFrom] using four_round_legal_obstruction n hn special
    (P [firstInput special]) (P [firstInput special, (fun _ => (1 / 2 : ℝ))])
    (P [firstInput special, (fun _ => (1 / 2 : ℝ)), fourRoundInput n])
    (P [firstInput special, (fun _ => (1 / 2 : ℝ)), (fun _ => 1)])
    (P [firstInput special, (fun _ => (1 / 2 : ℝ)), (fun _ => 1), fourRoundInput n])

/-- All coordinates lie in the manuscript input cube. -/
def InCube {ι : Type*} (v : ι → ℝ) : Prop := ∀ i, |v i| ≤ 1

theorem firstInput_inCube {ι : Type*} [DecidableEq ι] (special : ι) :
    InCube (firstInput special) := by
  intro i; by_cases hi : i = special <;> simp [firstInput, hi]

theorem fourRoundInput_inCube (n : ℕ) : InCube (fourRoundInput n) := by
  intro i; unfold fourRoundInput; split_ifs <;> norm_num

/-- A bound for every cube-input stream must be at least 5/2. The controller is
    quantified before the adverse fixed stream; no offline choices are permitted. -/
theorem every_uniform_bound_ge_five_halves (n : ℕ) (hn : 4 ≤ n)
    (P : Policy (Fin n)) (C : ℝ)
    (hC : ∀ inputs : List (Fin n → ℝ), (∀ v ∈ inputs, InCube v) →
      ∀ i, |play P inputs i| ≤ C) : (5 / 2 : ℝ) ≤ C := by
  let special : Fin n := ⟨0, by omega⟩
  have ha := firstInput_inCube special
  have hb : InCube (fun _ : Fin n => (1 / 2 : ℝ)) := by intro i; norm_num
  have hu : InCube (fun _ : Fin n => (1 : ℝ)) := by intro i; norm_num
  have hw := fourRoundInput_inCube n
  rcases deterministic_two_stream_obstruction n hn special P with ⟨i, hi⟩ | ⟨i, hi⟩ | ⟨i, hi⟩
  · have h := hC [firstInput special, (fun _ => (1 / 2 : ℝ)), fourRoundInput n]
      (by simpa using
        And.intro ha (And.intro hb hw)) i
    simpa only [hi] using h
  · have h := hC [firstInput special, (fun _ => (1 / 2 : ℝ)), (fun _ => 1)]
      (by simpa using
        And.intro ha (And.intro hb hu)) i
    simpa only [hi] using h
  · have h := hC [firstInput special, (fun _ => (1 / 2 : ℝ)), (fun _ => 1), fourRoundInput n]
      (by simpa using
        And.intro ha (And.intro hb (And.intro hu hw))) i
    simpa only [hi] using h


abbrev AdmissibleInputs (n : ℕ) :=
  {inputs : List (Fin n → ℝ) // ∀ v ∈ inputs, InCube v}

/-- Every deterministic controller has a cube-input stream of exactly four rounds
    and a prefix attaining norm at least 5/2. The witness in the proof is S0 or S1. -/
theorem deterministic_four_round_peak (n : ℕ) (hn : 4 ≤ n)
    (P : Policy (Fin n)) :
    ∃ inputs : AdmissibleInputs n, inputs.val.length = 4 ∧
      ∃ k : Fin (inputs.val.length + 1),
        ENNReal.ofReal (5 / 2 : ℝ) ≤ ENNReal.ofReal ‖play P (inputs.val.take k.val)‖ := by
  let special : Fin n := ⟨0, by omega⟩
  have ha := firstInput_inCube special
  have hb : InCube (fun _ : Fin n => (1 / 2 : ℝ)) := by intro i; norm_num
  have hu : InCube (fun _ : Fin n => (1 : ℝ)) := by intro i; norm_num
  have hz : InCube (fun _ : Fin n => (0 : ℝ)) := by intro i; norm_num
  have hw := fourRoundInput_inCube n
  rcases deterministic_two_stream_obstruction n hn special P with ⟨i, hi⟩ | ⟨i, hi⟩ | ⟨i, hi⟩
  · refine ⟨⟨[firstInput special, (fun _ => (1 / 2 : ℝ)), fourRoundInput n, (fun _ => 0)],
      by simpa using And.intro ha (And.intro hb (And.intro hw hz))⟩, rfl, ⟨3, by change 3 < 5; decide⟩, ?_⟩
    apply ENNReal.ofReal_le_ofReal
    change (5 / 2 : ℝ) ≤ ‖play P [firstInput special, (fun _ => (1 / 2 : ℝ)), fourRoundInput n]‖
    have h := norm_le_pi_norm (play P [firstInput special, (fun _ => (1 / 2 : ℝ)), fourRoundInput n]) i
    simpa only [Real.norm_eq_abs, hi] using h
  · refine ⟨⟨[firstInput special, (fun _ => (1 / 2 : ℝ)), (fun _ => 1), fourRoundInput n],
      by simpa using And.intro ha (And.intro hb (And.intro hu hw))⟩, rfl, ⟨3, by change 3 < 5; decide⟩, ?_⟩
    apply ENNReal.ofReal_le_ofReal
    change (5 / 2 : ℝ) ≤ ‖play P [firstInput special, (fun _ => (1 / 2 : ℝ)), (fun _ => 1)]‖
    have h := norm_le_pi_norm (play P [firstInput special, (fun _ => (1 / 2 : ℝ)), (fun _ => 1)]) i
    simpa only [Real.norm_eq_abs, hi] using h
  · refine ⟨⟨[firstInput special, (fun _ => (1 / 2 : ℝ)), (fun _ => 1), fourRoundInput n],
      by simpa using And.intro ha (And.intro hb (And.intro hu hw))⟩, rfl, ⟨4, by change 4 < 5; decide⟩, ?_⟩
    apply ENNReal.ofReal_le_ofReal
    change (5 / 2 : ℝ) ≤ ‖play P [firstInput special, (fun _ => (1 / 2 : ℝ)), (fun _ => 1), fourRoundInput n]‖
    have h := norm_le_pi_norm (play P [firstInput special, (fun _ => (1 / 2 : ℝ)), (fun _ => 1), fourRoundInput n]) i
    simpa only [Real.norm_eq_abs, hi] using h

/-- Extended nonnegative minimax value. Infinity is retained for unbounded controllers.
    The finite list sup includes every horizon and every prefix, starting from zero. -/
noncomputable def onlineValue (n : ℕ) : ENNReal :=
  ⨅ P : Policy (Fin n), ⨆ inputs : AdmissibleInputs n,
    ⨆ k : Fin (inputs.val.length + 1),
      ENNReal.ofReal ‖play P (inputs.val.take k.val)‖

theorem onlineValue_lower_bound (n : ℕ) (hn : 4 ≤ n) :
    ENNReal.ofReal (5 / 2 : ℝ) ≤ onlineValue n := by
  apply le_iInf
  intro P
  obtain ⟨inputs, _, k, hk⟩ := deterministic_four_round_peak n hn P
  exact le_iSup_of_le inputs (le_iSup_of_le k hk)


end OnlineBalancing
