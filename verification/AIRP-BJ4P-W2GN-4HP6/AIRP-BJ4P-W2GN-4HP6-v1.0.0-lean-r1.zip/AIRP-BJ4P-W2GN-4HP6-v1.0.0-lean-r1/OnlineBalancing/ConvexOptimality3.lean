import OnlineBalancing.Invariant3
import Mathlib.Analysis.Convex.Basic
import Mathlib.Topology.Order.Compact
import Mathlib.Topology.MetricSpace.ProperSpace
import Mathlib.Topology.Instances.Real.Lemmas

namespace OnlineBalancing.ConvexOptimality3
open Invariant3

/-- Precisely the compact convex, global-sign/permutation symmetric certificate class. -/
structure Certificate (C : ℝ) (K : Set (Fin 3 → ℝ)) : Prop where
  compact : IsCompact K
  convex : Convex ℝ K
  zero_mem : (fun _ => 0) ∈ K
  symmetry : ∀ (g : LegalMove (Fin 3)) (s : Fin 3 → ℝ), s ∈ K → move g s ∈ K
  bounded : ∀ s ∈ K, ∀ i, |s i| ≤ C
  controlled : ∀ s ∈ K, ∀ v, InCube v → ∃ g : LegalMove (Fin 3),
    (fun i => s i + move g v i) ∈ K

variable {C : ℝ} {K : Set (Fin 3 → ℝ)}

theorem cube_subset (h : Certificate C K) (v : Fin 3 → ℝ) (hv : InCube v) : v ∈ K := by
  obtain ⟨g, hg⟩ := h.controlled _ h.zero_mem v hv
  have hg' : move g v ∈ K := by simpa using hg
  let gi : LegalMove (Fin 3) := ⟨g.sign, g.sign_mem, g.perm.symm⟩
  have hh := h.symmetry gi _ hg'
  change normalize g (move g v) ∈ K at hh
  simpa only [normalize_first] using hh

theorem constant_mean (m : ℝ) : mean (fun _ : Fin 3 => m) = m := by
  simp [mean]

theorem mean_continuous : Continuous (mean : (Fin 3 → ℝ) → ℝ) := by
  unfold mean
  fun_prop

/-- Three cyclic permutations suffice for the exact convex average. -/
theorem diagonal_mem (h : Certificate C K) (s : Fin 3 → ℝ) (hs : s ∈ K) :
    (fun _ => mean s) ∈ K := by
  let u := move (Certificate3.action true 3) s
  let v := move (Certificate3.action true 4) s
  have hu : u ∈ K := h.symmetry _ _ hs
  have hv : v ∈ K := h.symmetry _ _ hs
  have hm := h.convex hs hu (a := (1/2 : ℝ)) (b := (1/2 : ℝ))
    (by norm_num) (by norm_num) (by norm_num)
  have ht := h.convex hm hv (a := (2/3 : ℝ)) (b := (1/3 : ℝ))
    (by norm_num) (by norm_num) (by norm_num)
  convert ht using 1
  funext i
  fin_cases i <;> simp [u, v, move, Certificate3.action, Certificate3.perm,
    Certificate3.permFn, mean, Fin.sum_univ_three] <;> ring

/-- Compactness supplies an actual mean maximizer, not an extra assumption. -/
theorem maximal_mean (h : Certificate C K) :
    ∃ M : ℝ, 1 ≤ M ∧ M ≤ C-1 ∧ (fun _ => M) ∈ K ∧ ∀ s ∈ K, mean s ≤ M := by
  obtain ⟨s, hs, hmax⟩ := h.compact.exists_isMaxOn ⟨_,h.zero_mem⟩ mean_continuous.continuousOn
  let M := mean s
  have hdiag : (fun _ => M) ∈ K := diagonal_mem h s hs
  have hone : (fun _ : Fin 3 => (1 : ℝ)) ∈ K := cube_subset h _ (by intro i; norm_num)
  have hM : 1 ≤ M := by simpa [constant_mean, M] using hmax hone
  have hv : InCube (![1,0,-1] : Fin 3 → ℝ) := by intro i; fin_cases i <;> norm_num
  obtain ⟨g, hg⟩ := h.controlled _ hdiag _ hv
  have hbound : M+1 ≤ C := by
    rcases g.sign_mem with he | he
    · have hh := (abs_le.mp (h.bounded _ hg (g.perm.symm 0))).2
      simpa [move, he] using hh
    · have hh := (abs_le.mp (h.bounded _ hg (g.perm.symm 2))).2
      simpa [move, he] using hh
  exact ⟨M,hM,by linarith,hdiag,fun t ht => hmax ht⟩

noncomputable def fibre (l : ℝ) : Fin 3 → ℝ := ![1+l,-1+l,-1+l]

theorem fibre_continuous : Continuous fibre := by
  apply continuous_pi
  intro i
  fin_cases i <;> simp [fibre] <;> fun_prop

theorem fibre_mid (l u : ℝ) :
    fibre ((l+u)/2) = (1/2 : ℝ) • fibre l + (1/2 : ℝ) • fibre u := by
  funext i
  fin_cases i <;> simp [fibre] <;> ring

theorem fibre_shift (l : ℝ) (g : LegalMove (Fin 3)) :
    (fun i => fibre l i + move g (fun _ => 1) i) = fibre (l+g.sign) := by
  funext i
  fin_cases i <;> simp [fibre, move] <;> ring

/-- The compact fibre has genuine attained endpoints; invariance forces width at least two. -/
theorem fibre_endpoints (h : Certificate C K) :
    ∃ L U : ℝ, fibre L ∈ K ∧ fibre U ∈ K ∧ 2 ≤ U-L ∧ U ≤ C-1 ∧ L ≤ C-3 := by
  let I : Set ℝ := {l | fibre l ∈ K}
  have hclosed : IsClosed I := h.compact.isClosed.preimage fibre_continuous
  have hsub : I ⊆ Set.Icc (-C-1) (C-1) := by
    intro l hl
    have hh := abs_le.mp (h.bounded _ hl 0)
    simp [fibre] at hh
    constructor <;> linarith
  have hcompact : IsCompact I := isCompact_Icc.of_isClosed_subset hclosed hsub
  have hzero : (0 : ℝ) ∈ I := by
    apply cube_subset h
    intro i
    fin_cases i <;> norm_num [fibre]
  obtain ⟨L,hL,hmin⟩ := hcompact.exists_isMinOn ⟨0,hzero⟩ continuous_id.continuousOn
  obtain ⟨U,hU,hmax⟩ := hcompact.exists_isMaxOn ⟨0,hzero⟩ continuous_id.continuousOn
  have hmid : fibre ((L+U)/2) ∈ K := by
    rw [fibre_mid]
    exact h.convex hL hU (by norm_num) (by norm_num) (by norm_num)
  obtain ⟨g,hg⟩ := h.controlled _ hmid (fun _ => 1) (by intro i; norm_num)
  rw [fibre_shift] at hg
  have hlo : L ≤ (L+U)/2+g.sign := hmin hg
  have hhi : (L+U)/2+g.sign ≤ U := hmax hg
  have hwidth : 2 ≤ U-L := by
    rcases g.sign_mem with he | he <;> rw [he] at hlo hhi <;> linarith
  have hupper : U ≤ C-1 := (hsub hU).2
  exact ⟨L,U,hL,hU,hwidth,hupper,by linarith⟩

theorem reflected_fibre (h : Certificate C K) (L : ℝ) (hL : fibre L ∈ K) :
    (![-1-L,1-L,1-L] : Fin 3 → ℝ) ∈ K := by
  have hh := h.symmetry (Certificate3.action false 0) _ hL
  convert hh using 1
  funext i
  fin_cases i <;> simp [move, Certificate3.action, Certificate3.perm, Certificate3.permFn, fibre] <;> ring

/-- A negative response necessarily adds r to one of the repeated high coordinates. -/
theorem negative_response (A B r : ℝ) (g : LegalMove (Fin 3)) (he : g.sign = -1) :
    ∃ i : Fin 3, (![A,B,B] i + move g ![1,-r,-r] i) = B+r := by
  have hev : ∀ j : Fin 3, j ≠ 0 → (![1,-r,-r] : Fin 3 → ℝ) j = -r := by
    intro j hj
    fin_cases j <;> simp_all
  by_cases h1 : g.perm 1 = 0
  · have h2 : g.perm 2 ≠ 0 := by
      intro hh
      have bad := g.perm.injective (hh.trans h1.symm)
      norm_num at bad
    refine ⟨2, ?_⟩
    simp [move, he, hev _ h2]
  · refine ⟨1, ?_⟩
    simp [move, he, hev _ h1]

/-- Manuscript Theorem convex: no member of the full stated certificate class beats 11/5. -/
theorem lower_bound (h : Certificate C K) : 11/5 ≤ C := by
  obtain ⟨M,hM,hMC,hdiag,hmax⟩ := maximal_mean h
  obtain ⟨L,U,hL,hU,hwidth,hUC,hLC⟩ := fibre_endpoints h
  have hs := reflected_fibre h L hL
  have hmean : mean (![-1-L,1-L,1-L] : Fin 3 → ℝ) = 1/3-L := by
    simp [mean, Fin.sum_univ_three]; ring
  have hmeanM : 1/3-L ≤ M := by simpa only [hmean] using hmax _ hs
  have hBC : 1-L ≤ C := by
    have hh := (abs_le.mp (h.bounded _ hs 1)).2
    simpa using hh
  by_contra hn
  have hC : C < 11/5 := lt_of_not_ge hn
  let lo := C-(1-L)
  let hi := 1/2-(3/2)*(M-(1/3-L))
  have hlo : 0 ≤ lo := by dsimp [lo]; linarith
  have hhi : hi ≤ 1/2 := by dsimp [hi]; linarith
  have hgap : lo < hi := by dsimp [lo,hi]; linarith
  obtain ⟨r,hrlo,hrhi⟩ := exists_between hgap
  have hr0 : 0 < r := lt_of_le_of_lt hlo hrlo
  have hrhalf : r < 1/2 := lt_of_lt_of_le hrhi hhi
  have hv : InCube (![1,-r,-r] : Fin 3 → ℝ) := by
    intro i
    fin_cases i <;> norm_num
    all_goals rw [abs_of_pos hr0]; linarith
  obtain ⟨g,hg⟩ := h.controlled _ hs _ hv
  rcases g.sign_mem with he | he
  · have hh := hmax _ hg
    rw [mean_add] at hh
    have hmove : mean (move g (![1,-r,-r] : Fin 3 → ℝ)) = g.sign * mean (![1,-r,-r] : Fin 3 → ℝ) :=
      mean_smul_perm _ _ _
    rw [hmove, he, one_mul, hmean] at hh
    norm_num [mean, Fin.sum_univ_three] at hh
    dsimp [hi] at hrhi
    linarith
  · obtain ⟨i,hi⟩ := negative_response (-1-L) (1-L) r g he
    have hh := (abs_le.mp (h.bounded _ hg i)).2
    rw [hi] at hh
    dsimp [lo] at hrlo
    linarith


/-- A closed universally indexed family is closed in the state space. -/
theorem closed_forall {ι : Type*} (P : ι → (Fin 3 → ℝ) → Prop)
    (h : ∀ i, IsClosed {s | P i s}) : IsClosed {s | ∀ i, P i s} := by
  have heq : {s | ∀ i, P i s} = ⋂ i, {s | P i s} := by ext s; simp
  rw [heq]
  exact isClosed_iInter h

theorem total_continuous : Continuous (total : (Fin 3 → ℝ) → ℝ) := by
  unfold total
  fun_prop

theorem KStar_closed : IsClosed {s : Fin 3 → ℝ | KStar s} := by
  change IsClosed ({s | ∀ i, |s i| ≤ 11/5} ∩
    ({s | |total s| ≤ 18/5} ∩ ({s | ∀ i j, s i-s j ≤ 2} ∩
      {s | ∀ i, |2*total s-s i| ≤ 7})))
  refine (closed_forall _ (fun i => isClosed_le (by fun_prop) continuous_const)).inter ?_
  refine (isClosed_le total_continuous.abs continuous_const).inter ?_
  refine (closed_forall _ (fun i => closed_forall _ (fun j =>
    isClosed_le (by fun_prop) continuous_const))).inter ?_
  exact closed_forall _ (fun i => isClosed_le
    (((continuous_const.mul total_continuous).sub (continuous_apply i)).abs) continuous_const)

theorem KStar_compact : IsCompact {s : Fin 3 → ℝ | KStar s} := by
  have hb : IsCompact {s : Fin 3 → ℝ | ∀ i, s i ∈ Set.Icc (-11/5 : ℝ) (11/5)} :=
    isCompact_pi_infinite (fun _ => isCompact_Icc)
  apply hb.of_isClosed_subset KStar_closed
  intro s hs i
  simpa [Set.mem_Icc, neg_div] using abs_le.mp (hs.1 i)

theorem abs_combination (x y B a b : ℝ) (hx : |x| ≤ B) (hy : |y| ≤ B)
    (ha : 0 ≤ a) (hb : 0 ≤ b) (hab : a+b=1) : |a*x+b*y| ≤ B := by
  calc
    |a*x+b*y| ≤ |a*x|+|b*y| := abs_add_le _ _
    _ = a*|x|+b*|y| := by rw [abs_mul, abs_mul, abs_of_nonneg ha, abs_of_nonneg hb]
    _ ≤ a*B+b*B := add_le_add (mul_le_mul_of_nonneg_left hx ha) (mul_le_mul_of_nonneg_left hy hb)
    _ = B := by rw [← add_mul, hab, one_mul]

theorem total_combination (s t : Fin 3 → ℝ) (a b : ℝ) :
    total (a • s+b • t) = a*total s+b*total t := by
  simp [total, Pi.smul_apply, Pi.add_apply, smul_eq_mul, Finset.sum_add_distrib, ← Finset.mul_sum]

theorem KStar_convex : Convex ℝ {s : Fin 3 → ℝ | KStar s} := by
  intro s hs t ht a b ha hb hab
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro i
    exact abs_combination (s i) (t i) _ a b (hs.1 i) (ht.1 i) ha hb hab
  · rw [total_combination]
    exact abs_combination _ _ _ a b hs.2.1 ht.2.1 ha hb hab
  · intro i j
    change a*s i+b*t i-(a*s j+b*t j) ≤ 2
    have h1 := mul_le_mul_of_nonneg_left (hs.2.2.1 i j) ha
    have h2 := mul_le_mul_of_nonneg_left (ht.2.2.1 i j) hb
    nlinarith
  · intro i
    have hh := abs_combination _ _ _ a b (hs.2.2.2 i) (ht.2.2.2 i) ha hb hab
    convert hh using 1
    rw [total_combination]
    change |2*(a*total s+b*total t)-(a*s i+b*t i)| = _
    congr 1
    ring

/-- The manuscript's explicit polytope attains the optimal certificate bound. -/
theorem KStar_certificate : Certificate (11/5) {s | KStar s} where
  compact := KStar_compact
  convex := KStar_convex
  zero_mem := Invariant3.zero_mem
  symmetry := KStar_move
  bounded := fun _ hs => hs.1
  controlled := fun s hs v hv => Invariant3.controlled s v hs hv

theorem KStar_contains_cube (v : Fin 3 → ℝ) (hv : InCube v) : KStar v :=
  cube_subset KStar_certificate v hv

/-- Exact optimum of the certificate class; this is not an equality for the unrestricted game. -/
theorem exact_optimum :
    (∃ K : Set (Fin 3 → ℝ), Certificate (11/5) K) ∧
    (∀ (C : ℝ) (K : Set (Fin 3 → ℝ)), Certificate C K → 11/5 ≤ C) :=
  ⟨⟨_,KStar_certificate⟩,fun _ _ h => lower_bound h⟩


/-- Joint LegalMove symmetry is equivalent to the two symmetries stated in the paper. -/
theorem symmetry_iff (K : Set (Fin 3 → ℝ)) :
    (∀ (g : LegalMove (Fin 3)) (s : Fin 3 → ℝ), s ∈ K → move g s ∈ K) ↔
    (∀ (p : Equiv.Perm (Fin 3)) (s : Fin 3 → ℝ), s ∈ K → (fun i => s (p i)) ∈ K) ∧
    (∀ (s : Fin 3 → ℝ), s ∈ K → (fun i => -s i) ∈ K) := by
  constructor
  · intro h
    constructor
    · intro p s hs
      convert h ⟨1, Or.inl rfl, p⟩ s hs using 1
      funext i
      simp [move]
    · intro s hs
      convert h ⟨-1, Or.inr rfl, Equiv.refl _⟩ s hs using 1
      funext i
      simp [move]
  · rintro ⟨hp,hn⟩ g s hs
    rcases g.sign_mem with he | he
    · convert hp g.perm s hs using 1
      funext i
      simp [move, he]
    · convert hn _ (hp g.perm s hs) using 1
      funext i
      simp [move, he]

/-- The lower bound with the manuscript's compactness, convexity and separate symmetries. -/
theorem source_convex_lower_bound (C : ℝ) (K : Set (Fin 3 → ℝ))
    (hc : IsCompact K) (hv : Convex ℝ K) (h0 : (fun _ => 0) ∈ K)
    (hp : ∀ (p : Equiv.Perm (Fin 3)) (s : Fin 3 → ℝ), s ∈ K → (fun i => s (p i)) ∈ K)
    (hn : ∀ (s : Fin 3 → ℝ), s ∈ K → (fun i => -s i) ∈ K)
    (hb : ∀ s ∈ K, ∀ i, |s i| ≤ C)
    (hi : ∀ s ∈ K, ∀ v, InCube v → ∃ g : LegalMove (Fin 3),
      (fun i => s i + move g v i) ∈ K) : 11/5 ≤ C :=
  lower_bound ⟨hc,hv,h0,(symmetry_iff K).mpr ⟨hp,hn⟩,hb,hi⟩

end OnlineBalancing.ConvexOptimality3
