import OnlineBalancing.ConvexOptimality3

namespace OnlineBalancing

/-- The complete deterministic main theorem of the frozen v1.0.0 manuscript.
The last conjunct is exact optimality of the specified certificate class only. -/
theorem paper_main :
    (∀ n : ℕ, 4 ≤ n → (5/2 : ℝ) ≤ finiteOnlineValue n ∧
      finiteOnlineValue n ≤ 3-2/(n : ℝ)) ∧
    finiteOnlineValue 4 = (5/2 : ℝ) ∧
    ((2197/1004 : ℝ) ≤ finiteOnlineValue 3 ∧ finiteOnlineValue 3 ≤ 11/5) ∧
    ((∃ K : Set (Fin 3 → ℝ), ConvexOptimality3.Certificate (11/5) K) ∧
      ∀ (C : ℝ) (K : Set (Fin 3 → ℝ)), ConvexOptimality3.Certificate C K → 11/5 ≤ C) :=
  ⟨fun _ hn => high_dimensional_main hn, finiteOnlineValue_four,
    Invariant3.three_dimensional_bounds, ConvexOptimality3.exact_optimum⟩

end OnlineBalancing
