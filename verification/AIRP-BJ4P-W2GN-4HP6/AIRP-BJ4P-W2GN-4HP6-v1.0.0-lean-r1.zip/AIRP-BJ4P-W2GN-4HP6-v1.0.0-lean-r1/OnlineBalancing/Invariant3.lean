import OnlineBalancing.Certificate3
import Mathlib.Tactic.Push
import Mathlib.Tactic.Tauto
import Mathlib.Algebra.BigOperators.Fin

namespace OnlineBalancing.Invariant3
open Finset

noncomputable def total (s : Fin 3 → ℝ) : ℝ := ∑ i, s i

def KStar (s : Fin 3 → ℝ) : Prop :=
  (∀ i, |s i| ≤ 11/5) ∧ |total s| ≤ 18/5 ∧ RangeBound s 2 ∧
  ∀ i, |2 * total s - s i| ≤ 7

theorem total_triple (x y z : ℝ) : total ![x,y,z] = x+y+z := by
  simp [total, Fin.sum_univ_succ]
  ring

/-- Exact three-coordinate scalar form of the manuscript's polytope. -/
theorem KStar_triple (x y z : ℝ) : KStar ![x,y,z] ↔
    (-11/5 ≤ x ∧ x ≤ 11/5) ∧ (-11/5 ≤ y ∧ y ≤ 11/5) ∧
    (-11/5 ≤ z ∧ z ≤ 11/5) ∧
    (-18/5 ≤ x+y+z ∧ x+y+z ≤ 18/5) ∧
    (x-y ≤ 2 ∧ x-z ≤ 2 ∧ y-x ≤ 2 ∧ y-z ≤ 2 ∧ z-x ≤ 2 ∧ z-y ≤ 2) ∧
    (-7 ≤ x+2*y+2*z ∧ x+2*y+2*z ≤ 7) ∧
    (-7 ≤ 2*x+y+2*z ∧ 2*x+y+2*z ≤ 7) ∧
    (-7 ≤ 2*x+2*y+z ∧ 2*x+2*y+z ≤ 7) := by
  simp [KStar, RangeBound, total_triple, Fin.forall_fin_succ, abs_le]
  simp only [and_assoc]
  constructor <;> rintro ⟨h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12,h13,h14,h15,h16,h17,h18,h19,h20⟩ <;> (repeat' constructor) <;> linarith

/-- All-real normalized branch arithmetic, including ties and boundary equalities. -/
theorem normalized_step (x y z a b c : ℝ)
    (hs : KStar ![x,y,z]) (hxy : x ≤ y) (hyz : y ≤ z) (hS : 0 ≤ x+y+z)
    (hv : InCube ![a,b,c]) (hab : a ≤ b) (hbc : b ≤ c) (hT : 0 ≤ a+b+c) :
    KStar (if x-a < -11/5 ∨ 11/5 < y-b then ![x+c,y+b,z+a]
      else ![x-a,y-b,z-c]) := by
  rw [KStar_triple] at hs
  rcases hs with ⟨⟨hxL,hxU⟩,⟨hyL,hyU⟩,⟨hzL,hzU⟩,⟨hSL,hSU⟩,
    ⟨hxyR,hxzR,hyxR,hyzR,hzxR,hzyR⟩,⟨hwxL,hwxU⟩,⟨hwyL,hwyU⟩,⟨hwzL,hwzU⟩⟩
  have ha := abs_le.mp (hv 0)
  have hb := abs_le.mp (hv 1)
  have hc := abs_le.mp (hv 2)
  norm_num at ha hb hc
  obtain ⟨haL,haU⟩ := ha
  obtain ⟨hbL,hbU⟩ := hb
  obtain ⟨hcL,hcU⟩ := hc
  split_ifs with he
  · rcases he with he | he <;> rw [KStar_triple] <;> (repeat' constructor) <;> linarith
  · push Not at he
    obtain ⟨heL,heU⟩ := he
    rw [KStar_triple]
    (repeat' constructor) <;> linarith


theorem total_move (g : LegalMove (Fin 3)) (s : Fin 3 → ℝ) :
    total (move g s) = g.sign * total s := by
  unfold total move
  rw [← Finset.mul_sum, Equiv.sum_comp g.perm]

theorem move_cube (g : LegalMove (Fin 3)) (v : Fin 3 → ℝ) (hv : InCube v) :
    InCube (move g v) := by
  intro i
  rcases g.sign_mem with he | he <;> simpa [move, he] using hv (g.perm i)

theorem KStar_move (g : LegalMove (Fin 3)) (s : Fin 3 → ℝ) (hs : KStar s) :
    KStar (move g s) := by
  rcases hs with ⟨hc, ht, hr, hw⟩
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro i
    rcases g.sign_mem with he | he <;> simpa [move, he] using hc (g.perm i)
  · rw [total_move]
    rcases g.sign_mem with he | he <;> simpa [he] using ht
  · intro i j
    rcases g.sign_mem with he | he
    · simpa [move, he] using hr (g.perm i) (g.perm j)
    · have h := hr (g.perm j) (g.perm i)
      simp only [move, he, neg_one_mul]
      linarith
  · intro i
    rw [total_move]
    have hh := hw (g.perm i)
    rcases g.sign_mem with he | he
    · simpa [move, he] using hh
    · have heq : 2 * (g.sign * total s) - move g s i =
          -(2 * total s - s (g.perm i)) := by simp [move, he]; ring
      rw [heq, abs_neg]
      exact hh

/-- Sorting uses a permutation and one global sign only. -/
theorem normalized_exists (s : Fin 3 → ℝ) :
    ∃ g : LegalMove (Fin 3), Monotone (move g s) ∧ 0 ≤ total (move g s) := by
  let e : ℝ := if 0 ≤ total s then 1 else -1
  have he : e = 1 ∨ e = -1 := by unfold e; split_ifs <;> simp
  let g : LegalMove (Fin 3) := ⟨e, he, Tuple.sort (fun i => e * s i)⟩
  refine ⟨g, Tuple.monotone_sort (fun i => e * s i), ?_⟩
  rw [total_move]
  change 0 ≤ e * total s
  unfold e
  split_ifs with h
  · simpa using h
  · simp only [neg_one_mul]
    linarith

theorem triple_eta (s : Fin 3 → ℝ) : ![s 0,s 1,s 2] = s := by
  funext i
  fin_cases i <;> simp

/-- The two normalized candidates are legal global-sign/permutation responses. -/
theorem normalized_controlled (s v : Fin 3 → ℝ) (hs : KStar s) (hv : InCube v)
    (hsort : Monotone s) (vsort : Monotone v)
    (hS : 0 ≤ total s) (hT : 0 ≤ total v) :
    ∃ g : LegalMove (Fin 3), KStar (fun i => s i + move g v i) := by
  have h := normalized_step (s 0) (s 1) (s 2) (v 0) (v 1) (v 2)
    (by simpa only [triple_eta] using hs) (hsort (by decide : (0 : Fin 3) ≤ 1))
    (hsort (by decide : (1 : Fin 3) ≤ 2))
    (by simpa [total, Fin.sum_univ_three] using hS)
    (by simpa only [triple_eta] using hv) (vsort (by decide : (0 : Fin 3) ≤ 1))
    (vsort (by decide : (1 : Fin 3) ≤ 2))
    (by simpa [total, Fin.sum_univ_three] using hT)
  by_cases he : s 0-v 0 < -11/5 ∨ 11/5 < s 1-v 1
  · rw [ite_eq_left he] at h
    refine ⟨Certificate3.action true 5, ?_⟩
    convert h using 1
    funext i
    fin_cases i <;> simp [move, Certificate3.action, Certificate3.perm, Certificate3.permFn]
  · rw [ite_eq_right he] at h
    refine ⟨Certificate3.action false 0, ?_⟩
    convert h using 1
    funext i
    fin_cases i <;> simp [move, Certificate3.action, Certificate3.perm, Certificate3.permFn, sub_eq_add_neg]

/-- The exact all-real-input controlled-invariance statement, without a graph assumption. -/
theorem controlled (s v : Fin 3 → ℝ) (hs : KStar s) (hv : InCube v) :
    ∃ g : LegalMove (Fin 3), KStar (fun i => s i + move g v i) := by
  obtain ⟨a, ha, hA⟩ := normalized_exists s
  obtain ⟨b, hb, hB⟩ := normalized_exists v
  obtain ⟨g, hg⟩ := normalized_controlled (move a s) (move b v)
    (KStar_move a s hs) (move_cube b v hv) ha hb hA hB
  let c := Certificate3.compose g b
  have hc : KStar (fun i => move a s i + move c v i) := by
    simpa only [c, Certificate3.move_compose] using hg
  let ai : LegalMove (Fin 3) := ⟨a.sign, a.sign_mem, a.perm.symm⟩
  refine ⟨normalizedMove a c, ?_⟩
  have hh := KStar_move ai _ hc
  change KStar (normalize a (fun i => move a s i + move c v i)) at hh
  simpa only [normalize_step, normalize_first] using hh


/-- A legal response selected solely from the current state and current input. -/
noncomputable def chosenMove (s v : Fin 3 → ℝ) : LegalMove (Fin 3) := by
  classical
  exact if h : KStar s ∧ InCube v then Classical.choose (controlled s v h.1 h.2)
    else Certificate3.action true 0

theorem chosenMove_invariant (s v : Fin 3 → ℝ) (hs : KStar s) (hv : InCube v) :
    KStar (fun i => s i + move (chosenMove s v) v i) := by
  classical
  simp only [chosenMove, dite_eq_left (show KStar s ∧ InCube v from ⟨hs,hv⟩)]
  exact Classical.choose_spec (controlled s v hs hv)

noncomputable def step (s v : Fin 3 → ℝ) : Fin 3 → ℝ :=
  fun i => s i + move (chosenMove s v) v i
noncomputable def state (inputs : List (Fin 3 → ℝ)) : Fin 3 → ℝ :=
  inputs.foldl step (fun _ => 0)
noncomputable def policy : Policy (Fin 3) := fun inputs =>
  match inputs.reverse with
  | [] => chosenMove (fun _ => 0) (fun _ => 0)
  | v :: history => chosenMove (state history.reverse) v

theorem policy_append (history : List (Fin 3 → ℝ)) (v : Fin 3 → ℝ) :
    policy (history ++ [v]) = chosenMove (state history) v := by simp [policy]
theorem state_append (history : List (Fin 3 → ℝ)) (v : Fin 3 → ℝ) :
    state (history ++ [v]) = step (state history) v := by simp [state, List.foldl_append]

theorem policy_playFrom (inputs history : List (Fin 3 → ℝ)) :
    playFrom policy history (state history) inputs = state (history ++ inputs) := by
  induction inputs generalizing history with
  | nil => simp [playFrom]
  | cons v vs ih =>
    rw [playFrom, policy_append]
    change playFrom policy (history ++ [v]) (step (state history) v) vs = _
    rw [← state_append, ih]
    simp [List.append_assoc]

theorem policy_play (inputs : List (Fin 3 → ℝ)) : play policy inputs = state inputs := by
  simpa [play, state] using policy_playFrom inputs []

theorem zero_mem : KStar (fun _ => 0) := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro i; norm_num
  · norm_num [total]
  · intro i j; norm_num
  · intro i; norm_num [total]

theorem state_invariant (inputs : List (Fin 3 → ℝ))
    (hi : ∀ v ∈ inputs, InCube v) : KStar (state inputs) := by
  have hfold : ∀ (xs : List (Fin 3 → ℝ)) (s : Fin 3 → ℝ),
      (∀ v ∈ xs, InCube v) → KStar s → KStar (xs.foldl step s) := by
    intro xs
    induction xs with
    | nil => intro s _ hs; exact hs
    | cons v vs ih =>
      intro s hx hs
      apply ih (step s v)
      · intro w hw; exact hx w (List.mem_cons_of_mem v hw)
      · exact chosenMove_invariant s v hs (hx v List.mem_cons_self)
  exact hfold inputs (fun _ => 0) hi zero_mem

/-- One deterministic causal policy bounds every prefix for every real cube-input list. -/
theorem all_prefixes (inputs : List (Fin 3 → ℝ))
    (hi : ∀ v ∈ inputs, InCube v) (k : ℕ) (i : Fin 3) :
    |play policy (inputs.take k) i| ≤ 11/5 := by
  rw [policy_play]
  exact (state_invariant (inputs.take k) (fun v hv => hi v (List.mem_of_mem_take hv))).1 i

theorem onlineValue_upper3 : onlineValue 3 ≤ ENNReal.ofReal (11/5 : ℝ) := by
  unfold onlineValue
  apply iInf_le_of_le policy
  apply iSup_le
  intro inputs
  apply iSup_le
  intro k
  apply ENNReal.ofReal_le_ofReal
  apply (pi_norm_le_iff_of_nonneg (by norm_num : (0 : ℝ) ≤ 11/5)).mpr
  intro i
  simpa [Real.norm_eq_abs] using all_prefixes inputs.val inputs.property k.val i

theorem finiteOnlineValue_upper3 : finiteOnlineValue 3 ≤ 11/5 := by
  have h := ENNReal.toReal_mono ENNReal.ofReal_ne_top onlineValue_upper3
  norm_num [finiteOnlineValue] at h ⊢
  exact h

theorem three_dimensional_bounds :
    2197/1004 ≤ finiteOnlineValue 3 ∧ finiteOnlineValue 3 ≤ 11/5 :=
  ⟨Certificate3.finiteOnlineValue_lower3, finiteOnlineValue_upper3⟩


end OnlineBalancing.Invariant3
