import OnlineBalancing.UpperBound
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Fintype.Perm
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace OnlineBalancing.Certificate3
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

def permFn : Fin 6 → Fin 3 → Fin 3 :=
  ![![0, 1, 2], ![0, 2, 1], ![1, 0, 2], ![1, 2, 0], ![2, 0, 1], ![2, 1, 0]]

def perm (p : Fin 6) : Equiv.Perm (Fin 3) where
  toFun := permFn p
  invFun := permFn (![0, 1, 2, 4, 3, 5] p)
  left_inv := by fin_cases p <;> decide
  right_inv := by fin_cases p <;> decide

theorem perms_complete : ∀ p : Equiv.Perm (Fin 3), ∃ k : Fin 6, p = perm k := by decide

def signZ (b : Bool) : ℤ := if b then 1 else -1

def actZ (b : Bool) (p : Fin 6) (v : Fin 3 → ℤ) : Fin 3 → ℤ :=
  fun i => signZ b * v (perm p i)

def states : Fin 32 → Fin 3 → ℤ :=
  ![![0, 0, 0], ![-11304, -11304, -11304], ![-23352, 744, 744], ![-14316, 9780, 9780], ![-21828, -21828, 2268], ![-17292, -17292, -9780], ![-21828, -17292, -5244], ![-16521, -16521, -11985], ![-22860, -18324, -5292], ![-17340, -17340, -12804], ![-24876, -24876, -756], ![-20340, -20340, -8292], ![-14316, -14316, -14316], ![-24852, -9804, -9804], ![-20340, -20340, -5292], ![-24876, -20340, -5292], ![-18852, -17340, -14316], ![-23844, -10812, -10812], ![-20340, -20340, -7308], ![-23214, -10182, -10182], ![-19080, -19080, -6048], ![-23844, -23844, 2220], ![-22860, -22860, -756], ![-18836, -18836, -12804], ![-23356, -23356, -5276], ![-23356, -17324, -11308], ![-20332, -14316, -14316], ![-20348, -20348, -14316], ![-22599, -10551, -10551], ![-18834, -18834, -6786], ![-23352, -23352, 744], ![-23352, -11304, -11304]]

def inputs : Fin 32 → Fin 3 → ℤ :=
  ![![-11304, -11304, -11304], ![-12048, -12048, 12048], ![-9036, -9036, -9036], ![-12048, -12048, -12048], ![-12048, 4536, 4536], ![-12048, 0, 12048], ![-11277, 5307, 5307], ![-11229, 6339, 6339], ![-12048, 5520, 5520], ![-12048, 7536, 7536], ![-7536, 4536, 4536], ![-6024, 6024, 6024], ![-12048, -12048, 12048], ![-10536, 4512, 4512], ![-9024, 6024, 6024], ![-12048, 6024, 6024], ![-9024, -9024, 12048], ![-9528, 3504, 3504], ![-7008, 6024, 6024], ![-8898, 4134, 4134], ![-8268, 4764, 4764], ![-10512, 3504, 3504], ![-12048, 4024, 4024], ![-7528, 4520, 4520], ![-9040, 9040, 9040], ![-9040, 3008, 3008], ![-12048, -12048, 12048], ![-6016, -6016, 12048], ![-8283, 3765, 3765], ![-7530, 4518, 4518], ![-9036, 3012, 3012], ![-9036, 3012, 3012]]

def ranks : Fin 32 → ℕ :=
  ![13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 3, 2, 2, 1, 3, 2, 5, 4, 3, 4, 3, 2, 2, 1, 1, 5, 4, 3, 3]

def nextData : Fin 32 → Fin 12 → Fin 32 × Bool × Fin 6 :=
  ![![(1, false, 0), (1, false, 0), (1, false, 0), (1, false, 0), (1, false, 0), (1, false, 0), (1, true, 0), (1, true, 0), (1, true, 0), (1, true, 0), (1, true, 0), (1, true, 0)], ![(2, true, 4), (2, true, 2), (2, true, 4), (2, true, 2), (2, true, 0), (2, true, 0), (30, true, 0), (30, true, 1), (30, true, 0), (30, true, 1), (30, true, 3), (30, true, 3)], ![(3, true, 0), (3, true, 0), (3, true, 0), (3, true, 0), (3, true, 0), (3, true, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0)], ![(4, false, 3), (4, false, 3), (4, false, 3), (4, false, 3), (4, false, 3), (4, false, 3), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0)], ![(0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (5, true, 0), (0, false, 0), (5, true, 0)], ![(6, true, 5), (0, false, 0), (6, true, 4), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (6, true, 4), (0, false, 0), (6, true, 5)], ![(28, true, 2), (28, true, 2), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (7, true, 1), (0, false, 0), (7, true, 1)], ![(8, true, 3), (8, true, 3), (8, true, 1), (22, true, 0), (8, true, 1), (22, true, 0), (0, false, 0), (0, false, 0), (0, false, 0), (19, true, 4), (0, false, 0), (19, true, 4)], ![(17, true, 2), (17, true, 2), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (9, true, 1), (0, false, 0), (9, true, 1)], ![(15, true, 3), (15, true, 3), (15, true, 1), (10, true, 0), (15, true, 1), (10, true, 0), (0, false, 0), (0, false, 0), (0, false, 0), (13, true, 4), (0, false, 0), (13, true, 4)], ![(0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (11, true, 0), (0, false, 0), (11, true, 0)], ![(0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (12, true, 0), (0, false, 0), (12, true, 0)], ![(0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0)], ![(12, true, 0), (12, true, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (14, true, 0), (14, true, 1), (14, true, 0), (14, true, 1)], ![(0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (12, true, 0), (0, false, 0), (12, true, 0)], ![(0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (16, true, 1), (0, false, 0), (16, true, 1)], ![(0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0)], ![(12, true, 0), (12, true, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (18, true, 0), (18, true, 1), (18, true, 0), (18, true, 1)], ![(0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (12, true, 0), (0, false, 0), (12, true, 0)], ![(12, true, 0), (12, true, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (20, true, 0), (20, true, 1), (20, true, 0), (20, true, 1)], ![(17, true, 2), (17, true, 2), (17, true, 0), (21, true, 0), (17, true, 0), (21, true, 0), (0, false, 0), (0, false, 0), (0, false, 0), (12, true, 0), (0, false, 0), (12, true, 0)], ![(0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (11, true, 0), (0, false, 0), (11, true, 0)], ![(0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (23, true, 0), (0, false, 0), (23, true, 0)], ![(25, true, 3), (25, true, 3), (25, true, 1), (24, true, 0), (25, true, 1), (24, true, 0), (0, false, 0), (0, false, 0), (0, false, 0), (26, true, 4), (0, false, 0), (26, true, 4)], ![(0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (12, true, 0), (0, false, 0), (12, true, 0)], ![(26, true, 2), (26, true, 2), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (27, true, 1), (0, false, 0), (27, true, 1)], ![(0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0)], ![(0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0)], ![(12, true, 0), (12, true, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (29, true, 0), (29, true, 1), (29, true, 0), (29, true, 1)], ![(31, true, 2), (31, true, 2), (31, true, 0), (30, true, 0), (31, true, 0), (30, true, 0), (0, false, 0), (0, false, 0), (0, false, 0), (12, true, 0), (0, false, 0), (12, true, 0)], ![(0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (11, true, 0), (0, false, 0), (11, true, 0)], ![(12, true, 0), (12, true, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (0, false, 0), (11, true, 0), (11, true, 1), (11, true, 0), (11, true, 1)]]

def response (j : Fin 32) (b : Bool) (p : Fin 6) : Fin 3 → ℤ :=
  fun i => states j i + actZ b p (inputs j) i

def responseIndex (b : Bool) (p : Fin 6) : Fin 12 :=
  ⟨(if b then 6 else 0) + p.val, by cases b <;> simp <;> omega⟩

/-- Exactly the supplied 32 rows and all twelve labelled legal responses. -/
theorem checked_table (j : Fin 32) :
    (0 < ranks j) ∧ (∀ i, |inputs j i| ≤ 12048) ∧
    (∀ i, |states j i| < 26364) ∧
    (∀ b p, (∃ i, 26364 ≤ |response j b p i|) ∨
      (ranks (nextData j (responseIndex b p)).1 < ranks j ∧
       actZ (nextData j (responseIndex b p)).2.1
         (nextData j (responseIndex b p)).2.2 (response j b p) =
         states (nextData j (responseIndex b p)).1)) := by
  fin_cases j <;> decide

noncomputable def scale (z : Fin 3 → ℤ) : Fin 3 → ℝ := fun i => (z i : ℝ) / 12048
noncomputable def action (b : Bool) (p : Fin 6) : LegalMove (Fin 3) where
  sign := if b then 1 else -1
  sign_mem := by cases b <;> simp
  perm := perm p

theorem actions_complete (g : LegalMove (Fin 3)) : ∃ b p, g = action b p := by
  obtain ⟨p, hp⟩ := perms_complete g.perm
  rcases g.sign_mem with h | h
  · refine ⟨true, p, ?_⟩
    cases g
    simp_all [action]
  · refine ⟨false, p, ?_⟩
    cases g
    simp_all [action]

theorem scale_act (b : Bool) (p : Fin 6) (z : Fin 3 → ℤ) :
    scale (actZ b p z) = move (action b p) (scale z) := by
  funext i
  cases b <;> simp [scale, actZ, signZ, move, action, neg_div]

theorem scale_response (j : Fin 32) (b : Bool) (p : Fin 6) :
    scale (response j b p) = fun i => scale (states j) i + move (action b p) (scale (inputs j)) i := by
  rw [show response j b p = fun i => states j i + actZ b p (inputs j) i from rfl]
  funext i
  simp only [scale, Int.cast_add, add_div]
  have h := congrFun (scale_act b p (inputs j)) i
  exact congrArg (fun x => (states j i : ℝ) / 12048 + x) h

theorem scaled_input_legal (j : Fin 32) : InCube (scale (inputs j)) := by
  intro i
  have h := (checked_table j).2.1 i
  have hh : |(inputs j i : ℝ)| ≤ 12048 := by exact_mod_cast h
  change |(inputs j i : ℝ) / 12048| ≤ 1
  rw [abs_div]
  norm_num
  linarith

theorem scaled_escape (z : Fin 3 → ℤ) (h : ∃ i, 26364 ≤ |z i|) :
    ∃ i, (2197 / 1004 : ℝ) ≤ |scale z i| := by
  obtain ⟨i,hi⟩ := h
  refine ⟨i, ?_⟩
  have hh : (26364 : ℝ) ≤ |(z i : ℝ)| := by exact_mod_cast hi
  change (2197 / 1004 : ℝ) ≤ |(z i : ℝ) / 12048|
  rw [abs_div]
  norm_num
  linarith

/-- Each arbitrary real legal move escapes or is genuinely conjugate to a lower-rank row. -/
theorem real_transition (j : Fin 32) (g : LegalMove (Fin 3)) :
    (∃ i, (2197 / 1004 : ℝ) ≤ |scale (states j) i + move g (scale (inputs j)) i|) ∨
    (∃ k : Fin 32, ranks k < ranks j ∧ ∃ h : LegalMove (Fin 3),
      move h (fun i => scale (states j) i + move g (scale (inputs j)) i) = scale (states k)) := by
  obtain ⟨b,p,rfl⟩ := actions_complete g
  rcases (checked_table j).2.2.2 b p with he | hs
  · left
    simpa only [scale_response] using scaled_escape (response j b p) he
  · right
    refine ⟨(nextData j (responseIndex b p)).1, hs.1,
      action (nextData j (responseIndex b p)).2.1 (nextData j (responseIndex b p)).2.2, ?_⟩
    rw [← scale_response, ← scale_act, hs.2]

noncomputable def compose (a b : LegalMove (Fin 3)) : LegalMove (Fin 3) where
  sign := a.sign * b.sign
  sign_mem := by rcases a.sign_mem with ha | ha <;> rcases b.sign_mem with hb | hb <;> simp [ha, hb]
  perm := a.perm.trans b.perm

theorem move_compose (a b : LegalMove (Fin 3)) (v : Fin 3 → ℝ) :
    move (compose a b) v = move a (move b v) := by
  funext i
  simp [move, compose, mul_assoc]

noncomputable def conjugate (h g : LegalMove (Fin 3)) : LegalMove (Fin 3) where
  sign := g.sign
  sign_mem := g.sign_mem
  perm := h.perm.trans (g.perm.trans h.perm.symm)

/-- Transform the new state while leaving all previous choices intact. -/
theorem conjugate_step (h g : LegalMove (Fin 3)) (s v : Fin 3 → ℝ) :
    move h (fun i => s i + move g (normalize h v) i) =
      fun i => move h s i + move (conjugate h g) v i := by
  funext i
  rcases h.sign_mem with hh | hh <;>
    simp [move, normalize, conjugate, hh] <;> ring

theorem normalize_cube (h : LegalMove (Fin 3)) (v : Fin 3 → ℝ) (hv : InCube v) :
    InCube (normalize h v) := by
  intro i
  rcases h.sign_mem with hh | hh <;> simpa [normalize, hh] using hv (h.perm.symm i)

theorem escape_of_move (h : LegalMove (Fin 3)) (s : Fin 3 → ℝ) (C : ℝ)
    (hs : ∃ i, C ≤ |move h s i|) : ∃ i, C ≤ |s i| := by
  obtain ⟨i,hi⟩ := hs
  refine ⟨h.perm i, ?_⟩
  rcases h.sign_mem with hh | hh <;> simpa [move, hh] using hi

/-- Rank induction produces an actual finite legal input list against every causal policy. -/
theorem rank_forces (j : Fin 32) (P : Policy (Fin 3))
    (history : List (Fin 3 → ℝ)) (s : Fin 3 → ℝ)
    (h : LegalMove (Fin 3)) (hs : move h s = scale (states j)) :
    ∃ xs : List (Fin 3 → ℝ), xs.length ≤ ranks j ∧
      (∀ v ∈ xs, InCube v) ∧
      ∃ i, (2197 / 1004 : ℝ) ≤ |playFrom P history s xs i| := by
  have go : ∀ r : ℕ, ∀ j : Fin 32, ranks j = r →
      ∀ (history : List (Fin 3 → ℝ)) (s : Fin 3 → ℝ) (h : LegalMove (Fin 3)),
      move h s = scale (states j) →
      ∃ xs : List (Fin 3 → ℝ), xs.length ≤ ranks j ∧
        (∀ v ∈ xs, InCube v) ∧
        ∃ i, (2197 / 1004 : ℝ) ≤ |playFrom P history s xs i| := by
    intro r
    induction r using Nat.strong_induction_on with
    | h r ih =>
      intro j hj history s h hs
      let v := normalize h (scale (inputs j))
      let g := P (history ++ [v])
      let t := fun i => s i + move g v i
      have hv : InCube v := normalize_cube h _ (scaled_input_legal j)
      have ht : move h t = fun i => scale (states j) i +
          move (conjugate h g) (scale (inputs j)) i := by
        dsimp [t, v]
        rw [conjugate_step, hs]
      rcases real_transition j (conjugate h g) with he | he
      · have htE : ∃ i, (2197 / 1004 : ℝ) ≤ |t i| :=
          escape_of_move h t _ (by simpa only [ht] using he)
        refine ⟨[v], ?_, ?_, ?_⟩
        · have := (checked_table j).1
          simp only [List.length_singleton]
          omega
        · intro w hw
          simpa using (List.mem_singleton.mp hw ▸ hv)
        · simpa only [playFrom, List.nil_append] using htE
      · obtain ⟨k,hk,a,ha⟩ := he
        have hnext : move (compose a h) t = scale (states k) := by
          rw [move_compose, ht]
          exact ha
        obtain ⟨xs,hxs,hlegal,hescape⟩ := ih (ranks k) (by omega) k rfl
          (history ++ [v]) t (compose a h) hnext
        refine ⟨v :: xs, ?_, ?_, ?_⟩
        · simp only [List.length_cons]
          omega
        · intro w hw
          rcases List.mem_cons.mp hw with rfl | hw
          · exact hv
          · exact hlegal w hw
        · exact hescape
  exact go (ranks j) j rfl history s h hs

/-- The source thirteen-move deterministic online lower theorem. -/
theorem lower3_thirteen (P : Policy (Fin 3)) :
    ∃ xs : List (Fin 3 → ℝ), xs.length ≤ 13 ∧
      (∀ v ∈ xs, InCube v) ∧ ∃ i, (2197 / 1004 : ℝ) ≤ |play P xs i| := by
  have hroot : move (action true 0) (fun _ => 0) = scale (states 0) := by
    funext i
    fin_cases i <;> norm_num [move, action, scale, states]
  simpa only [ranks, Matrix.cons_val_zero, play] using
    rank_forces 0 P [] (fun _ => 0) (action true 0) hroot

theorem onlineValue_lower3 : ENNReal.ofReal (2197 / 1004 : ℝ) ≤ onlineValue 3 := by
  apply le_iInf
  intro P
  obtain ⟨xs,hlen,hlegal,i,hi⟩ := lower3_thirteen P
  let inputs : AdmissibleInputs 3 := ⟨xs, hlegal⟩
  let k : Fin (inputs.val.length + 1) := ⟨xs.length, by simp [inputs]⟩
  have hn : (2197 / 1004 : ℝ) ≤ ‖play P xs‖ := by
    exact hi.trans (by simpa [Real.norm_eq_abs] using norm_le_pi_norm (play P xs) i)
  have he := ENNReal.ofReal_le_ofReal hn
  have hsup : ENNReal.ofReal ‖play P xs‖ ≤
      ⨆ inputs : AdmissibleInputs 3, ⨆ k : Fin (inputs.val.length + 1),
        ENNReal.ofReal ‖play P (inputs.val.take k.val)‖ := by
    apply le_iSup_of_le inputs
    apply le_iSup_of_le k
    simp [inputs, k]
  exact he.trans hsup

/-- Exact labelled-response count, independently checked by Lean reduction. -/
theorem escape_response_count :
    (Finset.univ.filter (fun a : Fin 32 × Bool × Fin 6 =>
      ∃ i, 26364 ≤ |response a.1 a.2.1 a.2.2 i|)).card = 242 := by decide

/-- Every listed representative is sorted and lexicographically no larger than
    its sorted global negation; this is exactly the source canonical convention. -/
theorem canonical_states (j : Fin 32) :
    states j 0 ≤ states j 1 ∧ states j 1 ≤ states j 2 ∧
    (states j 0 < -states j 2 ∨
      (states j 0 = -states j 2 ∧
        (states j 1 < -states j 1 ∨
          (states j 1 = -states j 1 ∧ states j 2 ≤ -states j 0)))) := by
  fin_cases j <;> decide

theorem ranks_at_most_thirteen (j : Fin 32) : ranks j ≤ 13 := by fin_cases j <;> decide

theorem move_preserves_norm (g : LegalMove (Fin 3)) (s : Fin 3 → ℝ) :
    ‖move g s‖ = ‖s‖ := by
  have habs : ∀ i, |move g s i| = |s (g.perm i)| := by
    intro i
    rcases g.sign_mem with h | h <;> simp [move, h]
  apply le_antisymm
  · apply (pi_norm_le_iff_of_nonneg (norm_nonneg _)).mpr
    intro i
    rw [Real.norm_eq_abs, habs]
    simpa [Real.norm_eq_abs] using norm_le_pi_norm s (g.perm i)
  · apply (pi_norm_le_iff_of_nonneg (norm_nonneg _)).mpr
    intro i
    have hi := norm_le_pi_norm (move g s) (g.perm.symm i)
    simpa only [Real.norm_eq_abs, habs, Equiv.apply_symm_apply] using hi

theorem finiteOnlineValue_lower3 : (2197 / 1004 : ℝ) ≤ finiteOnlineValue 3 := by
  have h := ENNReal.toReal_mono (onlineValue_ne_top (by norm_num : 0 < 3)) onlineValue_lower3
  norm_num [finiteOnlineValue] at h ⊢
  exact h

end OnlineBalancing.Certificate3
