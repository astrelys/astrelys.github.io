#!/usr/bin/env python3
"""Rebuild and audit the complete proof, with evidence in a new external directory.
Dependency installation is separate. No package content is uploaded.
"""
from pathlib import Path, PurePosixPath
import argparse, datetime, hashlib, json, os, re, shutil, subprocess, time
ROOT = Path(__file__).resolve().parents[1]
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def inventory():
    expected = read(ROOT/'hashes.json'); actual = set()
    for name, value in expected.items():
        parts = PurePosixPath(name)
        if parts.is_absolute() or any(x in ('', '.', '..') for x in name.split('/')) or '\\' in name:
            raise ValueError('unsafe inventory name')
        p = ROOT/name
        if p.is_symlink() or not p.is_file() or digest(p) != value: raise ValueError('member mismatch: '+name)
    for p in ROOT.rglob('*'):
        name = p.relative_to(ROOT).as_posix()
        if name == '.lake' or name.startswith('.lake/'): continue
        if p.is_symlink(): raise ValueError('unexpected symlink')
        if p.is_file(): actual.add(name)
    if actual != set(expected)|{'hashes.json'}: raise ValueError('inventory is not closed')
    return {n:digest(ROOT/n) for n in sorted(actual)}
def declarations():
    rows=[]
    for module in read(ROOT/'dependency-lock.json')['module_order']:
        if '.' not in module: continue
        name=module.replace('.','/')+'.lean';s=(ROOT/name).read_text();ns=re.search(r'^namespace (\S+)',s,re.M).group(1)
        for m in re.finditer(r'^(?:noncomputable )?(theorem|def|abbrev|structure) (\w+)',s,re.M):
            tail=s[m.start():];cut=tail.find(' where') if m.group(1)=='structure' else tail.find(':=')
            rows.append({'name':ns+'.'+m.group(2),'kind':m.group(1),'source':name,
                         'line':s[:m.start()].count('\n')+1,'statement_source':tail[:cut].strip()})
    return rows

def main():
    if not __debug__: raise SystemExit('Run Python without optimization flags.')
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',type=Path,required=True,help='new output directory outside the package')
    ap.add_argument('--mathlib',type=Path,help='optional existing pinned mathlib checkout with its dependency caches')
    ap.add_argument('--timeout',type=int,default=1800,help='per-command timeout in seconds')
    args=ap.parse_args();out=args.output.resolve()
    if out==ROOT or ROOT in out.parents or args.timeout<=0: raise SystemExit('Choose an external output directory and positive timeout.')
    before=inventory();out.mkdir(parents=True,exist_ok=False);build=out/'build';build.mkdir()
    report={'result':'in-progress','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'payload_sha256':before,'commands':[],'fresh':'not-run','checker_boundary':'Same Lean kernel implementation, separate fresh replay'}
    env=dict(os.environ);start=time.monotonic()
    def save(): (out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
    def run(label,argv,cwd):
        began=time.monotonic()
        with (out/(label+'.log')).open('w') as log:
            p=subprocess.Popen(argv,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
            (out/(label+'-worker.json')).write_text(json.dumps({'pid':p.pid})+'\n')
            try: code=p.wait(timeout=args.timeout)
            except subprocess.TimeoutExpired: p.kill();p.wait();code=124
        report['commands'].append({'label':label,'exit_code':code,'elapsed_seconds':round(time.monotonic()-began,3),'log_sha256':digest(out/(label+'.log'))});save()
        if code: raise RuntimeError('command failed: '+label)
        return (out/(label+'.log')).read_text()
    try:
        lock=read(ROOT/'dependency-lock.json');assert (ROOT/'lean-toolchain').read_text().strip()==lock['lean_toolchain']
        version=run('lean-version',['lean','--version'],ROOT);assert lock['lean_version'] in version and lock['lean_commit'][:7] in version
        manifest=read(ROOT/'lake-manifest.json');assert all(p['type']=='git'for p in manifest['packages'])
        assert {(p['name'],p['url'],p['rev'])for p in manifest['packages']}=={(p['name'],p['url'],p['rev'])for p in lock['packages']}
        mathlib=(args.mathlib or ROOT/'.lake/packages/mathlib').resolve()
        depbase=mathlib/'.lake/packages' if args.mathlib else ROOT/'.lake/packages'
        for dep in lock['packages']:
            path=mathlib if dep['name']=='mathlib' else depbase/dep['name']
            head=run('revision-'+dep['name'],['git','rev-parse','HEAD'],path).strip();assert head==dep['rev']
            status=run('clean-'+dep['name'],['git','status','--porcelain','--untracked-files=no'],path).strip();assert not status
        lakecwd=mathlib if args.mathlib else ROOT
        lp=run('dependency-path',['lake','env','printenv','LEAN_PATH'],lakecwd).strip()
        env['LEAN_PATH']=str(build)+os.pathsep+os.pathsep.join(str((lakecwd/p).resolve()) if not Path(p).is_absolute() else p for p in lp.split(os.pathsep))
        rows=declarations();assert rows==read(ROOT/'targets.json');names=read(ROOT/'audit-targets.json')
        assert len(names)==len(set(names)) and {r['name']for r in rows}<=set(names)
        assert (ROOT/'Audit.lean').read_text()=='import OnlineBalancing\n\n'+''.join('#print axioms '+n+'\n#check @'+n+'\n'for n in names)
        for claim in read(ROOT/'claims.json')['claims']:
            row=next(r for r in rows if r['name']==claim['declaration']);assert row['statement_source']==claim['statement_source']
        for module in lock['module_order']:
            rel=Path(module.replace('.','/')+'.lean');dest=build/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/rel,dest)
            run('compile-'+module,['lean','-o',str(rel.with_suffix('.olean')),str(rel)],build)
        audit=(out/'compile-Audit.log').read_text();actual={}
        for n,ax in re.findall(r"^'([^\n]+)' depends on axioms: \[([^]]*)\]",audit,re.M):actual[n]=[a.strip()for a in ax.split(',')if a.strip()]
        for n in re.findall(r"^'([^\n]+)' does not depend on any axioms",audit,re.M):actual[n]=[]
        (out/'axioms.json').write_text(json.dumps(actual,indent=2)+'\n')
        assert set(actual)==set(names) and all(set(x)<=ALLOWED for x in actual.values())
        assert actual==read(ROOT/'axioms.json')
        run('fresh-kernel-replay',['leanchecker','--fresh','--verbose','OnlineBalancing'],build);report['fresh']='passed'
        assert inventory()==before
        report.update(result='full-recheck-passed',named_declarations=len(rows),audited_declarations=len(names),
                      theorem_count=sum(r['kind']=='theorem'for r in rows),primary_targets_verified=1,
                      scope_complete=True,whole_paper_verified=False,source_unchanged=True,
                      elapsed_seconds=round(time.monotonic()-start,3),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    except Exception as exc: report.update(result='failed',error=str(exc));raise
    finally: save()
    print('VERIFIED: full-recheck-passed; 113 theorems; 170 audited declarations; fresh kernel replay passed')
if __name__=='__main__':main()
