# Licensing and attribution

The paper and its verification companion are attributed to Astrée Iriart. No additional open-source or redistribution license for these original files is granted by this package.

Lean and the pinned public dependencies retain their respective licenses. Their sources and compiled artifacts are not included here; fetch them from the repositories recorded in [dependency-lock.json](../dependency-lock.json), and consult their license files.

The general upper-bound argument follows the prior result credited in the paper to Niles-Weed, Sadovsky and Shkrob, Theorem 9. This companion does not present that bound as a new result.
