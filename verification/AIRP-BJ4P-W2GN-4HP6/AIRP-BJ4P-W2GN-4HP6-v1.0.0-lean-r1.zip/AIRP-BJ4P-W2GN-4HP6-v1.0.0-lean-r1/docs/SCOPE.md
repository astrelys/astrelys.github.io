# Scope and interpretation

[Overview](../README.md) · [Verification guide](VERIFY.md)

## Mathematical coverage

The entry point is `OnlineBalancing.paper_main`. It proves the complete deterministic
main theorem of the exact reference manuscript:

- For every integer n >= 4, 5/2 <= O_n <= 3 - 2/n, with O_4 = 5/2.
- In dimension three, 2197/1004 <= O_3 <= 11/5.
- The radius 11/5 is attained and is minimal among compact convex controlled
  invariants containing zero and invariant under coordinate permutations and
  one global negation.

The last conclusion does **not** assert O_3 = 11/5 for unrestricted strategies.

## Model and proof correspondence

An action consists of one global sign and one coordinate permutation. A deterministic
policy sees the revealed input prefix, never future inputs. Inputs range over all
real vectors in the cube. The minimax value uses every finite input sequence and
every prefix; the harmless empty list adds only the already included initial payoff
zero. Finiteness is proved before passing from the extended nonnegative value to its
exact real representative.

The three-dimensional lower proof checks the exact 32-state certificate with all
384 labelled responses, scale 12048, threshold 26364 and initial rank 13. Canonical
state witnesses, action conjugation, norm preservation and strict rank decrease
produce an actual legal finite input sequence against every deterministic policy.
It is not merely an executable Boolean check or an assumed graph property.

The upper proof covers arbitrary real states and inputs, including ties and boundaries.
Sorting and global signs are transported back to legal actions. Induction connects
the invariant to every prefix of an actual causal policy. Classical choice defines a
mathematical deterministic policy; no extracted-program performance claim is made.

For the convex-class obstruction, compactness supplies attained mean and fibre extrema.
Convexity supplies the averaged diagonal and fibre midpoint. The final real input defeats
all legal actions if the bound is less than 11/5. Compactness, convexity and controlled
invariance of the explicit attaining polytope are also proved. Reachability of every
point in that polytope is not assumed or required.

The known general upper bound retains the paper's attribution to Niles-Weed, Sadovsky
and Shkrob, Theorem 9. [claims.json](../claims.json) records the public manuscript labels.

## Trust and review

The whitelist is `propext`, `Classical.choice` and `Quot.sound`. There are no admitted
proofs, added axioms or native-trust arithmetic shortcuts. Finite certificate arithmetic
is checked through Lean's kernel. The 170 audit entries cover 159 named source
declarations, including 113 theorems, plus 11 generated structure constructors/fields.
The complete imported proof is also replayed with `leanchecker --fresh`.

This replay uses the same Lean kernel implementation in a separate process; it is not
an independently implemented checker. Source correspondence was reviewed with AI
assistance, not by an independent human reviewer. Hashes establish integrity, not
mathematical meaning, author identity or publisher authentication.

## Exclusions

The randomized expected-peak two-stream subgame and unrelated applications are outside
this formalization. It does not settle the unrestricted three-dimensional value,
sharp higher-dimensional constants, general randomized game, or offline problem.
Whole-paper verification remains false. Mechanical checking does not establish
originality, priority, authorship or peer review.
