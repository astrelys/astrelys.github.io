# Verification guide

[Overview](../README.md) · [Scope](SCOPE.md)

## 1. Check the download

From the directory containing the ZIP and its sidecar:

```sh
sha256sum -c AIRP-BJ4P-W2GN-4HP6-v1.0.0-lean-r1.zip.sha256
# macOS:
shasum -a 256 -c AIRP-BJ4P-W2GN-4HP6-v1.0.0-lean-r1.zip.sha256
```

Checksums detect changed bytes; they do not authenticate a publisher.
`hashes.json` covers every payload file except itself. Compare the reference
paper's SHA-256 with [paper.json](../paper.json).

## 2. Prepare the environment

Use Python 3.10 or later, Git, and elan. The exact toolchain is Lean 4.34.0,
commit `293d5d0c0c3f3dded4688b3ccd6a33939ac5102b`. The mathlib commit is
`5ed2965256430c3649e86755f9576b54eca72435`; all transitive repositories and commits
are fixed by [dependency-lock.json](../dependency-lock.json) and the Lake manifest.

From the extracted package root:

```sh
elan toolchain install leanprover/lean4:v4.34.0
lake exe cache get
```

This setup may fetch the toolchain, public Git repositories and compiled dependency
caches. Do not run `lake update` to advance revisions. The verifier rejects different
commits or modified tracked dependency files. The tested dependency cache occupied
about 7.3 GiB, excluding the Lean toolchain and verification output; allow additional
space. New-machine installation and a fresh dependency download were not tested.

## 3. Run the complete check

```sh
python3 scripts/verify.py --output ../verification-output
```

An existing pinned mathlib checkout, including its `.lake/packages` dependencies
and compiled caches, may instead be supplied explicitly:

```sh
python3 scripts/verify.py --mathlib /path/to/mathlib4 --output ../verification-output
```

Use the pinned Lean toolchain on `PATH`. The script validates the closed inventory,
versions, dependency revisions, declaration list and statement mapping. It copies
only proof sources to a new output build directory, recompiles the complete import
root and audit, compares all 170 transitive axiom entries, then runs
`leanchecker --fresh --verbose OnlineBalancing`. It checks the payload again afterward.
It contains no upload or telemetry operation; this is not a system-wide network sandbox.

The success line is:

```text
VERIFIED: full-recheck-passed; 113 theorems; 170 audited declarations; fresh kernel replay passed
```

## 4. Results and recovery

Evidence is written outside the package: `result.json`, command logs, `axioms.json`
and a separate `build/` directory. Every command must exit zero; `result.json` must
report `full-recheck-passed` and `fresh: passed`. An unfinished result, a failed
command, a mismatched hash, or a partial log is not acceptance.

The default timeout is 1800 seconds per command; `--timeout` changes it. Replay
usually takes minutes and depends on hardware. On failure, keep the output for
inspection, fix the reported environment or integrity problem, and retry with a
new output directory. Do not edit the checksum inventory to hide a mismatch.

The recorded local test used a new proof build directory and existing pinned
public dependency caches. No precompiled companion proof was reused. See the
[verification summary](../verification-summary.json) for the observed result.
