# Sharp Low-Dimensional Bounds for Online Vector Balancing with Permutations

### Lean verification companion

**Author · Astrée Iriart**

**AIRP-BJ4P-W2GN-4HP6 · Manuscript v1.0.0 · Package r1**

A formal proof of the paper's complete deterministic main theorem, including the
three-dimensional bound and the exact optimum of its convex invariant class.

| Coverage | Proof environment | Reproduction |
| :--- | :--- | :--- |
| Complete main theorem; 113 theorems | Lean 4.34.0 | Build, axiom audit, fresh replay |
| 159 named source declarations | Pinned mathlib and dependencies | 170 audit entries |

## Verify

With Python 3.10+, Git and [elan](https://github.com/leanprover/elan) installed,
run from the extracted package directory:

```sh
elan toolchain install leanprover/lean4:v4.34.0
lake exe cache get
python3 scripts/verify.py --output ../verification-output
```

Success ends with `VERIFIED: full-recheck-passed` and reports 113 theorems,
170 audited declarations, and a passed fresh kernel replay. The output directory
must not already exist. Dependency setup downloads public software; the verifier
runs against the installed environment. See the [verification guide](docs/VERIFY.md).

## Read the evidence

| File | Purpose |
| :--- | :--- |
| [Paper identity](paper.json) | Exact manuscript identifier and reference PDF hash |
| [Scope](docs/SCOPE.md) | Mathematical conclusions, assumptions and exclusions |
| [Claims](claims.json) | Manuscript labels mapped to formal statements |
| [Targets](targets.json) | Named declarations, statements and source locations |
| [Verification summary](verification-summary.json) | Recorded checks and their limits |
| [Proofs](OnlineBalancing/) | Six mathematical source modules |
| [Licensing notes](LICENSES/README.md) | Attribution and actual license status |

## Attribution

Astrée Iriart. *Sharp Low-Dimensional Bounds for Online Vector Balancing with
Permutations*. AIRP-BJ4P-W2GN-4HP6, manuscript v1.0.0. Lean verification companion, r1.

Formalization and source-to-statement review were AI-assisted. Fresh kernel replay
is not independent human peer review. A reference PDF is identified by its hash;
this package does not include the manuscript or claim a public paper URL.
