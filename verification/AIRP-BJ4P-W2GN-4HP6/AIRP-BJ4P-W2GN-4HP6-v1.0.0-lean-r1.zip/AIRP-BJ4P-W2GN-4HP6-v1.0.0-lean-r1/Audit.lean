import OnlineBalancing

#print axioms OnlineBalancing.stateB
#check @OnlineBalancing.stateB
#print axioms OnlineBalancing.stateB_escape_of_two_negatives
#check @OnlineBalancing.stateB_escape_of_two_negatives
#print axioms OnlineBalancing.stateB_escape_signed_permutation
#check @OnlineBalancing.stateB_escape_signed_permutation
#print axioms OnlineBalancing.fourRoundInput
#check @OnlineBalancing.fourRoundInput
#print axioms OnlineBalancing.paper_B_branch
#check @OnlineBalancing.paper_B_branch
#print axioms OnlineBalancing.LegalMove
#check @OnlineBalancing.LegalMove
#print axioms OnlineBalancing.move
#check @OnlineBalancing.move
#print axioms OnlineBalancing.stateA
#check @OnlineBalancing.stateA
#print axioms OnlineBalancing.firstInput
#check @OnlineBalancing.firstInput
#print axioms OnlineBalancing.normalize
#check @OnlineBalancing.normalize
#print axioms OnlineBalancing.normalizedMove
#check @OnlineBalancing.normalizedMove
#print axioms OnlineBalancing.normalize_step
#check @OnlineBalancing.normalize_step
#print axioms OnlineBalancing.normalize_first
#check @OnlineBalancing.normalize_first
#print axioms OnlineBalancing.abs_normalize
#check @OnlineBalancing.abs_normalize
#print axioms OnlineBalancing.prefix_normalizes_to_A_or_B
#check @OnlineBalancing.prefix_normalizes_to_A_or_B
#print axioms OnlineBalancing.stateA_minus_one
#check @OnlineBalancing.stateA_minus_one
#print axioms OnlineBalancing.paper_A_branch
#check @OnlineBalancing.paper_A_branch
#print axioms OnlineBalancing.escape_of_normalized
#check @OnlineBalancing.escape_of_normalized
#print axioms OnlineBalancing.four_round_legal_obstruction
#check @OnlineBalancing.four_round_legal_obstruction
#print axioms OnlineBalancing.Policy
#check @OnlineBalancing.Policy
#print axioms OnlineBalancing.playFrom
#check @OnlineBalancing.playFrom
#print axioms OnlineBalancing.play
#check @OnlineBalancing.play
#print axioms OnlineBalancing.deterministic_two_stream_obstruction
#check @OnlineBalancing.deterministic_two_stream_obstruction
#print axioms OnlineBalancing.InCube
#check @OnlineBalancing.InCube
#print axioms OnlineBalancing.firstInput_inCube
#check @OnlineBalancing.firstInput_inCube
#print axioms OnlineBalancing.fourRoundInput_inCube
#check @OnlineBalancing.fourRoundInput_inCube
#print axioms OnlineBalancing.every_uniform_bound_ge_five_halves
#check @OnlineBalancing.every_uniform_bound_ge_five_halves
#print axioms OnlineBalancing.AdmissibleInputs
#check @OnlineBalancing.AdmissibleInputs
#print axioms OnlineBalancing.deterministic_four_round_peak
#check @OnlineBalancing.deterministic_four_round_peak
#print axioms OnlineBalancing.onlineValue
#check @OnlineBalancing.onlineValue
#print axioms OnlineBalancing.onlineValue_lower_bound
#check @OnlineBalancing.onlineValue_lower_bound
#print axioms OnlineBalancing.RangeBound
#check @OnlineBalancing.RangeBound
#print axioms OnlineBalancing.mean
#check @OnlineBalancing.mean
#print axioms OnlineBalancing.range_opposite
#check @OnlineBalancing.range_opposite
#print axioms OnlineBalancing.oppositePerm
#check @OnlineBalancing.oppositePerm
#print axioms OnlineBalancing.oppositePerm_range
#check @OnlineBalancing.oppositePerm_range
#print axioms OnlineBalancing.mean_add
#check @OnlineBalancing.mean_add
#print axioms OnlineBalancing.mean_smul_perm
#check @OnlineBalancing.mean_smul_perm
#print axioms OnlineBalancing.cube_range
#check @OnlineBalancing.cube_range
#print axioms OnlineBalancing.cube_mean
#check @OnlineBalancing.cube_mean
#print axioms OnlineBalancing.chosenSign
#check @OnlineBalancing.chosenSign
#print axioms OnlineBalancing.chosenSign_mem
#check @OnlineBalancing.chosenSign_mem
#print axioms OnlineBalancing.chosenSign_mean
#check @OnlineBalancing.chosenSign_mean
#print axioms OnlineBalancing.upperMove
#check @OnlineBalancing.upperMove
#print axioms OnlineBalancing.sign_cube
#check @OnlineBalancing.sign_cube
#print axioms OnlineBalancing.UpperInvariant
#check @OnlineBalancing.UpperInvariant
#print axioms OnlineBalancing.upperMove_invariant
#check @OnlineBalancing.upperMove_invariant
#print axioms OnlineBalancing.coordinate_mean_upper
#check @OnlineBalancing.coordinate_mean_upper
#print axioms OnlineBalancing.mean_neg
#check @OnlineBalancing.mean_neg
#print axioms OnlineBalancing.coordinate_deviation
#check @OnlineBalancing.coordinate_deviation
#print axioms OnlineBalancing.invariant_coordinate_bound
#check @OnlineBalancing.invariant_coordinate_bound
#print axioms OnlineBalancing.upperStep
#check @OnlineBalancing.upperStep
#print axioms OnlineBalancing.upperState
#check @OnlineBalancing.upperState
#print axioms OnlineBalancing.upperPolicy
#check @OnlineBalancing.upperPolicy
#print axioms OnlineBalancing.upperPolicy_append
#check @OnlineBalancing.upperPolicy_append
#print axioms OnlineBalancing.upperState_append
#check @OnlineBalancing.upperState_append
#print axioms OnlineBalancing.upper_playFrom
#check @OnlineBalancing.upper_playFrom
#print axioms OnlineBalancing.upper_play
#check @OnlineBalancing.upper_play
#print axioms OnlineBalancing.upperState_invariant
#check @OnlineBalancing.upperState_invariant
#print axioms OnlineBalancing.upper_all_prefixes
#check @OnlineBalancing.upper_all_prefixes
#print axioms OnlineBalancing.upper_bound_nonnegative
#check @OnlineBalancing.upper_bound_nonnegative
#print axioms OnlineBalancing.onlineValue_upper_bound
#check @OnlineBalancing.onlineValue_upper_bound
#print axioms OnlineBalancing.onlineValue_four
#check @OnlineBalancing.onlineValue_four
#print axioms OnlineBalancing.onlineValue_ne_top
#check @OnlineBalancing.onlineValue_ne_top
#print axioms OnlineBalancing.finiteOnlineValue
#check @OnlineBalancing.finiteOnlineValue
#print axioms OnlineBalancing.finiteOnlineValue_nonnegative
#check @OnlineBalancing.finiteOnlineValue_nonnegative
#print axioms OnlineBalancing.finiteOnlineValue_exact
#check @OnlineBalancing.finiteOnlineValue_exact
#print axioms OnlineBalancing.finiteOnlineValue_upper
#check @OnlineBalancing.finiteOnlineValue_upper
#print axioms OnlineBalancing.finiteOnlineValue_four
#check @OnlineBalancing.finiteOnlineValue_four
#print axioms OnlineBalancing.finiteOnlineValue_lower
#check @OnlineBalancing.finiteOnlineValue_lower
#print axioms OnlineBalancing.high_dimensional_main
#check @OnlineBalancing.high_dimensional_main
#print axioms OnlineBalancing.Certificate3.permFn
#check @OnlineBalancing.Certificate3.permFn
#print axioms OnlineBalancing.Certificate3.perm
#check @OnlineBalancing.Certificate3.perm
#print axioms OnlineBalancing.Certificate3.perms_complete
#check @OnlineBalancing.Certificate3.perms_complete
#print axioms OnlineBalancing.Certificate3.signZ
#check @OnlineBalancing.Certificate3.signZ
#print axioms OnlineBalancing.Certificate3.actZ
#check @OnlineBalancing.Certificate3.actZ
#print axioms OnlineBalancing.Certificate3.states
#check @OnlineBalancing.Certificate3.states
#print axioms OnlineBalancing.Certificate3.inputs
#check @OnlineBalancing.Certificate3.inputs
#print axioms OnlineBalancing.Certificate3.ranks
#check @OnlineBalancing.Certificate3.ranks
#print axioms OnlineBalancing.Certificate3.nextData
#check @OnlineBalancing.Certificate3.nextData
#print axioms OnlineBalancing.Certificate3.response
#check @OnlineBalancing.Certificate3.response
#print axioms OnlineBalancing.Certificate3.responseIndex
#check @OnlineBalancing.Certificate3.responseIndex
#print axioms OnlineBalancing.Certificate3.checked_table
#check @OnlineBalancing.Certificate3.checked_table
#print axioms OnlineBalancing.Certificate3.scale
#check @OnlineBalancing.Certificate3.scale
#print axioms OnlineBalancing.Certificate3.action
#check @OnlineBalancing.Certificate3.action
#print axioms OnlineBalancing.Certificate3.actions_complete
#check @OnlineBalancing.Certificate3.actions_complete
#print axioms OnlineBalancing.Certificate3.scale_act
#check @OnlineBalancing.Certificate3.scale_act
#print axioms OnlineBalancing.Certificate3.scale_response
#check @OnlineBalancing.Certificate3.scale_response
#print axioms OnlineBalancing.Certificate3.scaled_input_legal
#check @OnlineBalancing.Certificate3.scaled_input_legal
#print axioms OnlineBalancing.Certificate3.scaled_escape
#check @OnlineBalancing.Certificate3.scaled_escape
#print axioms OnlineBalancing.Certificate3.real_transition
#check @OnlineBalancing.Certificate3.real_transition
#print axioms OnlineBalancing.Certificate3.compose
#check @OnlineBalancing.Certificate3.compose
#print axioms OnlineBalancing.Certificate3.move_compose
#check @OnlineBalancing.Certificate3.move_compose
#print axioms OnlineBalancing.Certificate3.conjugate
#check @OnlineBalancing.Certificate3.conjugate
#print axioms OnlineBalancing.Certificate3.conjugate_step
#check @OnlineBalancing.Certificate3.conjugate_step
#print axioms OnlineBalancing.Certificate3.normalize_cube
#check @OnlineBalancing.Certificate3.normalize_cube
#print axioms OnlineBalancing.Certificate3.escape_of_move
#check @OnlineBalancing.Certificate3.escape_of_move
#print axioms OnlineBalancing.Certificate3.rank_forces
#check @OnlineBalancing.Certificate3.rank_forces
#print axioms OnlineBalancing.Certificate3.lower3_thirteen
#check @OnlineBalancing.Certificate3.lower3_thirteen
#print axioms OnlineBalancing.Certificate3.onlineValue_lower3
#check @OnlineBalancing.Certificate3.onlineValue_lower3
#print axioms OnlineBalancing.Certificate3.escape_response_count
#check @OnlineBalancing.Certificate3.escape_response_count
#print axioms OnlineBalancing.Certificate3.canonical_states
#check @OnlineBalancing.Certificate3.canonical_states
#print axioms OnlineBalancing.Certificate3.ranks_at_most_thirteen
#check @OnlineBalancing.Certificate3.ranks_at_most_thirteen
#print axioms OnlineBalancing.Certificate3.move_preserves_norm
#check @OnlineBalancing.Certificate3.move_preserves_norm
#print axioms OnlineBalancing.Certificate3.finiteOnlineValue_lower3
#check @OnlineBalancing.Certificate3.finiteOnlineValue_lower3
#print axioms OnlineBalancing.Invariant3.total
#check @OnlineBalancing.Invariant3.total
#print axioms OnlineBalancing.Invariant3.KStar
#check @OnlineBalancing.Invariant3.KStar
#print axioms OnlineBalancing.Invariant3.total_triple
#check @OnlineBalancing.Invariant3.total_triple
#print axioms OnlineBalancing.Invariant3.KStar_triple
#check @OnlineBalancing.Invariant3.KStar_triple
#print axioms OnlineBalancing.Invariant3.normalized_step
#check @OnlineBalancing.Invariant3.normalized_step
#print axioms OnlineBalancing.Invariant3.total_move
#check @OnlineBalancing.Invariant3.total_move
#print axioms OnlineBalancing.Invariant3.move_cube
#check @OnlineBalancing.Invariant3.move_cube
#print axioms OnlineBalancing.Invariant3.KStar_move
#check @OnlineBalancing.Invariant3.KStar_move
#print axioms OnlineBalancing.Invariant3.normalized_exists
#check @OnlineBalancing.Invariant3.normalized_exists
#print axioms OnlineBalancing.Invariant3.triple_eta
#check @OnlineBalancing.Invariant3.triple_eta
#print axioms OnlineBalancing.Invariant3.normalized_controlled
#check @OnlineBalancing.Invariant3.normalized_controlled
#print axioms OnlineBalancing.Invariant3.controlled
#check @OnlineBalancing.Invariant3.controlled
#print axioms OnlineBalancing.Invariant3.chosenMove
#check @OnlineBalancing.Invariant3.chosenMove
#print axioms OnlineBalancing.Invariant3.chosenMove_invariant
#check @OnlineBalancing.Invariant3.chosenMove_invariant
#print axioms OnlineBalancing.Invariant3.step
#check @OnlineBalancing.Invariant3.step
#print axioms OnlineBalancing.Invariant3.state
#check @OnlineBalancing.Invariant3.state
#print axioms OnlineBalancing.Invariant3.policy
#check @OnlineBalancing.Invariant3.policy
#print axioms OnlineBalancing.Invariant3.policy_append
#check @OnlineBalancing.Invariant3.policy_append
#print axioms OnlineBalancing.Invariant3.state_append
#check @OnlineBalancing.Invariant3.state_append
#print axioms OnlineBalancing.Invariant3.policy_playFrom
#check @OnlineBalancing.Invariant3.policy_playFrom
#print axioms OnlineBalancing.Invariant3.policy_play
#check @OnlineBalancing.Invariant3.policy_play
#print axioms OnlineBalancing.Invariant3.zero_mem
#check @OnlineBalancing.Invariant3.zero_mem
#print axioms OnlineBalancing.Invariant3.state_invariant
#check @OnlineBalancing.Invariant3.state_invariant
#print axioms OnlineBalancing.Invariant3.all_prefixes
#check @OnlineBalancing.Invariant3.all_prefixes
#print axioms OnlineBalancing.Invariant3.onlineValue_upper3
#check @OnlineBalancing.Invariant3.onlineValue_upper3
#print axioms OnlineBalancing.Invariant3.finiteOnlineValue_upper3
#check @OnlineBalancing.Invariant3.finiteOnlineValue_upper3
#print axioms OnlineBalancing.Invariant3.three_dimensional_bounds
#check @OnlineBalancing.Invariant3.three_dimensional_bounds
#print axioms OnlineBalancing.ConvexOptimality3.Certificate
#check @OnlineBalancing.ConvexOptimality3.Certificate
#print axioms OnlineBalancing.ConvexOptimality3.cube_subset
#check @OnlineBalancing.ConvexOptimality3.cube_subset
#print axioms OnlineBalancing.ConvexOptimality3.constant_mean
#check @OnlineBalancing.ConvexOptimality3.constant_mean
#print axioms OnlineBalancing.ConvexOptimality3.mean_continuous
#check @OnlineBalancing.ConvexOptimality3.mean_continuous
#print axioms OnlineBalancing.ConvexOptimality3.diagonal_mem
#check @OnlineBalancing.ConvexOptimality3.diagonal_mem
#print axioms OnlineBalancing.ConvexOptimality3.maximal_mean
#check @OnlineBalancing.ConvexOptimality3.maximal_mean
#print axioms OnlineBalancing.ConvexOptimality3.fibre
#check @OnlineBalancing.ConvexOptimality3.fibre
#print axioms OnlineBalancing.ConvexOptimality3.fibre_continuous
#check @OnlineBalancing.ConvexOptimality3.fibre_continuous
#print axioms OnlineBalancing.ConvexOptimality3.fibre_mid
#check @OnlineBalancing.ConvexOptimality3.fibre_mid
#print axioms OnlineBalancing.ConvexOptimality3.fibre_shift
#check @OnlineBalancing.ConvexOptimality3.fibre_shift
#print axioms OnlineBalancing.ConvexOptimality3.fibre_endpoints
#check @OnlineBalancing.ConvexOptimality3.fibre_endpoints
#print axioms OnlineBalancing.ConvexOptimality3.reflected_fibre
#check @OnlineBalancing.ConvexOptimality3.reflected_fibre
#print axioms OnlineBalancing.ConvexOptimality3.negative_response
#check @OnlineBalancing.ConvexOptimality3.negative_response
#print axioms OnlineBalancing.ConvexOptimality3.lower_bound
#check @OnlineBalancing.ConvexOptimality3.lower_bound
#print axioms OnlineBalancing.ConvexOptimality3.closed_forall
#check @OnlineBalancing.ConvexOptimality3.closed_forall
#print axioms OnlineBalancing.ConvexOptimality3.total_continuous
#check @OnlineBalancing.ConvexOptimality3.total_continuous
#print axioms OnlineBalancing.ConvexOptimality3.KStar_closed
#check @OnlineBalancing.ConvexOptimality3.KStar_closed
#print axioms OnlineBalancing.ConvexOptimality3.KStar_compact
#check @OnlineBalancing.ConvexOptimality3.KStar_compact
#print axioms OnlineBalancing.ConvexOptimality3.abs_combination
#check @OnlineBalancing.ConvexOptimality3.abs_combination
#print axioms OnlineBalancing.ConvexOptimality3.total_combination
#check @OnlineBalancing.ConvexOptimality3.total_combination
#print axioms OnlineBalancing.ConvexOptimality3.KStar_convex
#check @OnlineBalancing.ConvexOptimality3.KStar_convex
#print axioms OnlineBalancing.ConvexOptimality3.KStar_certificate
#check @OnlineBalancing.ConvexOptimality3.KStar_certificate
#print axioms OnlineBalancing.ConvexOptimality3.KStar_contains_cube
#check @OnlineBalancing.ConvexOptimality3.KStar_contains_cube
#print axioms OnlineBalancing.ConvexOptimality3.exact_optimum
#check @OnlineBalancing.ConvexOptimality3.exact_optimum
#print axioms OnlineBalancing.ConvexOptimality3.symmetry_iff
#check @OnlineBalancing.ConvexOptimality3.symmetry_iff
#print axioms OnlineBalancing.ConvexOptimality3.source_convex_lower_bound
#check @OnlineBalancing.ConvexOptimality3.source_convex_lower_bound
#print axioms OnlineBalancing.paper_main
#check @OnlineBalancing.paper_main
#print axioms OnlineBalancing.LegalMove.mk
#check @OnlineBalancing.LegalMove.mk
#print axioms OnlineBalancing.LegalMove.sign
#check @OnlineBalancing.LegalMove.sign
#print axioms OnlineBalancing.LegalMove.sign_mem
#check @OnlineBalancing.LegalMove.sign_mem
#print axioms OnlineBalancing.LegalMove.perm
#check @OnlineBalancing.LegalMove.perm
#print axioms OnlineBalancing.ConvexOptimality3.Certificate.mk
#check @OnlineBalancing.ConvexOptimality3.Certificate.mk
#print axioms OnlineBalancing.ConvexOptimality3.Certificate.compact
#check @OnlineBalancing.ConvexOptimality3.Certificate.compact
#print axioms OnlineBalancing.ConvexOptimality3.Certificate.convex
#check @OnlineBalancing.ConvexOptimality3.Certificate.convex
#print axioms OnlineBalancing.ConvexOptimality3.Certificate.zero_mem
#check @OnlineBalancing.ConvexOptimality3.Certificate.zero_mem
#print axioms OnlineBalancing.ConvexOptimality3.Certificate.symmetry
#check @OnlineBalancing.ConvexOptimality3.Certificate.symmetry
#print axioms OnlineBalancing.ConvexOptimality3.Certificate.bounded
#check @OnlineBalancing.ConvexOptimality3.Certificate.bounded
#print axioms OnlineBalancing.ConvexOptimality3.Certificate.controlled
#check @OnlineBalancing.ConvexOptimality3.Certificate.controlled
