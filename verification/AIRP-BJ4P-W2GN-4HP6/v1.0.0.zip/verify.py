"""Portable exact verifier. Run: python3 verify.py. Standard library only."""
import json
from pathlib import Path
from itertools import permutations
from fractions import Fraction as F
from functools import lru_cache

if not __debug__:
    raise SystemExit('Run without -O: this verifier requires assertions.')

def orbit(x):
    return [tuple(e*x[j] for j in p) for e in (-1,1) for p in permutations(range(len(x)))]

def verify(data):
    q,H=data['scale'],data['threshold']; rows=data['rows']
    by={tuple(s):(rank,tuple(v),i) for i,(s,rank,v) in enumerate(rows)}
    assert len(by)==len(rows) and (0,0,0) in by
    transitions=[]; graph={s:set() for s in by}; escapes=0
    for s,(rank,v,i) in by.items():
        assert tuple(s)==min(orbit(s)) and max(map(abs,s))<H
        assert max(map(abs,v))<=q and 1<=rank<=13
        escaped=0; succ=set()
        for a in orbit(v):
            t=tuple(x+y for x,y in zip(s,a))
            if max(map(abs,t))>=H:
                escaped+=1
            else:
                z=min(orbit(t))
                assert z in by and by[z][0]<rank,(i,t,z)
                graph[s].add(z); succ.add(by[z][2])
        escapes+=escaped
        transitions.append({'id':i,'escaping_labeled_actions':escaped,'successors':sorted(succ)})
    reachable={(0,0,0)}; todo=list(reachable)
    while todo:
        for z in graph[todo.pop()]-reachable:
            reachable.add(z); todo.append(z)
    assert len(reachable)==len(rows)
    return {'states':len(rows),'labeled_responses':12*len(rows),'escapes':escapes,'root_rank':by[(0,0,0)][0],'value':str(F(H,q)),'transitions':transitions}

data=json.loads(Path(__file__).with_name('certificate.json').read_text())
answer=verify(data)
assert (answer['states'],answer['labeled_responses'],answer['escapes'])==(32,384,242)
assert F(data['threshold'],data['scale'])==F(2197,1004)
neg=[]
for label,change in [('threshold-plus-one',lambda d:d.update(threshold=d['threshold']+1)),('missing-terminal',lambda d:d['rows'].pop(12)),('root-rank-one',lambda d:d['rows'][0].__setitem__(1,1))]:
    corrupt=json.loads(json.dumps(data)); change(corrupt)
    try: verify(corrupt)
    except AssertionError: neg.append(label)
    else: raise AssertionError('corruption passed: '+label)

@lru_cache(None)
def peak(s,stream,sofar):
    if not stream:return sofar
    return min(peak(t,stream[1:],max(sofar,max(map(abs,t)))) for a in set(orbit(stream[0])) for t in [tuple(x+y for x,y in zip(s,a))])
# Integer scale two, n=4. No source enumeration result is imported.
A=(3,-1,-1,-1); B=(1,-3,-3,-3); w=(2,2,-2,-2); u=(2,2,2,2); z=(0,0,0,0)
matrix=[[peak(s,seq,3) for seq in ((w,z),(u,w))] for s in (A,B)]
assert matrix==[[3,5],[5,3]]
p=F(1,2)
assert all(sum(p*matrix[i][j]/2 for i in range(2))==2 for j in range(2))
assert all(sum(p*matrix[i][j]/2 for j in range(2))==2 for i in range(2))

def in_K(s):
    S=sum(s)
    return max(map(abs,s))<=F(11,5) and abs(S)<=F(18,5) and max(s)-min(s)<=2 and all(abs(2*S-x)<=7 for x in s)

def next_state(s,v):
    """The proved three-dimensional policy, with symmetry undone."""
    e=1 if sum(s)>=0 else -1
    order=sorted(range(3),key=lambda i:e*s[i])
    x=[e*s[i] for i in order]
    f=1 if sum(v)>=0 else -1
    a=sorted(f*y for y in v)
    t=[x[i]-a[i] for i in range(3)]
    branch='minus'
    if t[0]<-F(11,5) or t[1]>F(11,5):
        t=[x[i]+a[2-i] for i in range(3)]; branch='plus'
    out=[None]*3
    for i,j in enumerate(order):out[j]=e*t[i]
    out=tuple(out)
    assert tuple(out[i]-s[i] for i in range(3)) in orbit(v)
    return out,branch

fixtures=[
    ((F(-4,3),F(2,3),F(2,3)),(F(1),)*3,'plus'),
    ((F(-1,5),F(9,5),F(9,5)),(F(-9,20),F(-9,20),F(1)),'plus'),
    ((F(-1,5),F(9,5),F(9,5)),(F(-2,5),F(-2,5),F(1)),'minus'),
    ((F(0),)*3,(F(-1),F(0),F(1)),'minus'),
]
for s,v,expected in fixtures:
    assert in_K(s) and max(map(abs,v))<=1
    out,branch=next_state(s,v)
    assert in_K(out) and branch==expected
    for transformed_s in set(orbit(s)):
        for transformed_v in set(orbit(v)):
            assert in_K(next_state(transformed_s,transformed_v)[0])
answer.update(status='ALL_PORTABLE_CERTIFICATES_PASS',negative_controls=neg,two_stream_scaled_matrix=matrix,continuous_policy_fixtures=len(fixtures),policy_fixture_scope='strict low/high fallback, equality uses minus, zero sum; all symmetry transforms; not a proof of continuous invariance')
Path(__file__).with_name('verification.json').write_text(json.dumps(answer,indent=2)+'\n')
print(answer['status'],answer['states'],answer['labeled_responses'],answer['escapes'],len(neg))
