# Verification materials

Sharp Low-Dimensional Bounds for Online Vector Balancing with Permutations
Version 1.0.0

Python 3, standard library only. Run the .py files from this folder without -O. The checks supplement the proofs in the manuscript.

Included files:
- certificate.json
- verify.py
