#!/usr/bin/env python3
"""Build, audit and replay the proof package. Does not upload package content."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess,time,datetime
ROOT=Path(__file__).resolve().parents[1]
ALLOWED={'propext','Classical.choice','Quot.sound'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 if not __debug__:raise SystemExit("Run Python without -O: verification checks must remain enabled")
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--output',type=Path,required=True,help='new directory outside the package')
 ap.add_argument('--audit-only',action='store_true',help='relocation/import audit only; never a full fresh verdict')
 a=ap.parse_args();out=a.output.resolve()
 if out==ROOT or ROOT in out.parents:raise SystemExit('output must be outside the immutable package')
 hashes=json.loads((ROOT/'hashes.json').read_text())
 for rel,digest in hashes.items():
  f=ROOT/rel
  if not f.is_file() or sha(f)!=digest:raise SystemExit('package hash mismatch: '+rel)
 out.mkdir(parents=True,exist_ok=False);started=time.monotonic()
 result={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mode':'audit-only' if a.audit_only else 'full','commands':[],'result':'in-progress'}
 def save(): (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 def run(label,args):
  with (out/(label+'.log')).open('w') as f:p=subprocess.run(args,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
  txt=(out/(label+'.log')).read_text();result['commands'].append({'label':label,'argv':args,'exit_code':p.returncode,'log_sha256':sha(out/(label+'.log'))});save()
  if p.returncode or re.search(r'(^|\n).*\berror(?:\([^\n]*\))?:',txt):raise RuntimeError('failed: '+label)
  return txt
 try:
  lock=json.loads((ROOT/'dependency-lock.json').read_text())
  assert (ROOT/'lean-toolchain').read_text().strip()==lock['lean_toolchain']
  version=run('lean-version',['lake','env','lean','--version']);assert lock['lean_version'] in version and lock['lean_commit'][:7] in version
  for dep in lock['packages']:
   d=ROOT/'.lake/packages'/dep['name'];got=subprocess.check_output(['git','-C',str(d),'rev-parse','HEAD'],text=True).strip()
   assert got==dep['rev'],'dependency commit mismatch: '+dep['name']
   assert not subprocess.check_output(['git','-C',str(d),'status','--porcelain','--untracked-files=no'],text=True).strip(),'modified dependency: '+dep['name']
  if not a.audit_only:run('build',['lake','build','SpectralComparison.All'])
  txt=run('axioms-and-statements',['lake','env','lean','Audit.lean']);ax={}
  for name,deps in re.findall(r"^'([^\n]+)' depends on axioms: \[(.*?)\]",txt,re.S|re.M):
   deps=re.sub(r'\.\{[^}]*\}','',deps);ax[name]=[x.strip() for x in deps.split(',') if x.strip()]
  for name in re.findall(r"^'([^\n]+)' does not depend on any axioms",txt,re.M):ax[name]=[]
  targets=json.loads((ROOT/'targets.json').read_text());assert set(ax)=={x['name'] for x in targets}
  assert all(set(v)<=ALLOWED for v in ax.values())
  (out/'axioms.json').write_text(json.dumps(ax,indent=2)+'\n')
  if not a.audit_only:run('fresh-recheck',['lake','env','leanchecker','--fresh','--verbose','SpectralComparison.All'])
  for rel,digest in hashes.items():assert sha(ROOT/rel)==digest,'file changed: '+rel
  result.update(result='audit-only-passed' if a.audit_only else 'full-recheck-passed',declaration_count=len(ax),elapsed_seconds=round(time.monotonic()-started,3))
 except Exception as e:result.update(result='failed',error=str(e));raise
 finally:save()
if __name__=='__main__':main()
