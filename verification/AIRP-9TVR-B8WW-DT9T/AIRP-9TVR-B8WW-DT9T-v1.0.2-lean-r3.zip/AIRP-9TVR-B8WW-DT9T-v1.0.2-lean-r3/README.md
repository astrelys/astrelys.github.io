# A spectral comparison for worst-orientation Nyström approximation

### Lean verification companion

**Author · Astrée Iriart**

**AIRP-9TVR-B8WW-DT9T · Manuscript v1.0.2 · Package r3**

Reproducible formal proofs for the declared mathematical results of the paper.
The package includes source, exact dependencies, a claim-to-proof map and a
single verification command.

| Coverage | Proof environment | Verification |
| :--- | :--- | :--- |
| 37 assertion records | Lean 4.34.0 | Build, axiom audit and fresh replay |
| 20 numbered entries; 17 supplemental | Pinned public dependencies | 739 declarations across 194 modules |

## Verify

With Python 3, Git and [elan](https://github.com/leanprover/elan) installed,
open a terminal in the extracted package directory:

```sh
elan toolchain install leanprover/lean4:v4.34.0
lake exe cache get
python3 scripts/verify.py --output ../verification-output
```

Success means `full-recheck-passed` and `declaration_count: 739` in
`../verification-output/result.json`. The output directory must be new and
outside this package. Setup downloads public dependencies and may require
several GB of storage. See [Verification guide](docs/VERIFY.md) for prerequisites,
integrity checks and failure diagnosis.

## Read the evidence

| File | Purpose |
| :--- | :--- |
| [paper.json](paper.json) | Paper identity, version and reference PDF checksum |
| [Scope and interpretation](docs/SCOPE.md) | Covered results, exclusions and review limits |
| [claims.json](claims.json) | Manuscript statements mapped to Lean declarations |
| [targets.json](targets.json) | Audited declarations and their source statements |
| [verification-summary.json](verification-summary.json) | Recorded mechanical verification result |
| [SpectralComparison/](SpectralComparison/) | Formal definitions and proofs |
| [Licensing notes](LICENSES/README.md) | Source status and dependency notices |

The reference PDF is identified by SHA-256 in `paper.json`; the PDF itself is
not bundled. Reproduction needs only this archive and the pinned public tools
and dependencies. Mathematical scope is explicit: mechanical checking does
not establish novelty, peer review or the correctness of every prose sentence.

## Attribution

Astrée Iriart. *A spectral comparison for worst-orientation Nyström approximation*.
AIRP-9TVR-B8WW-DT9T, manuscript v1.0.2. Lean verification companion, r3.

The authorship and review disclosures are stated in [Scope and interpretation](docs/SCOPE.md).
