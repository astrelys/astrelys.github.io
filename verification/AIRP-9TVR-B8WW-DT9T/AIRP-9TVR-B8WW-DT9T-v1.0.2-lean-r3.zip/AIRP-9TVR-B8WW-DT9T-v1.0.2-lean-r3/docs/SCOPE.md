# Scope and interpretation

[Overview](../README.md) · [Verification guide](VERIFY.md)

## Mathematical coverage

The package covers **37 assertion records** from manuscript v1.0.2:
20 numbered entries (19 distinct results and one introduction restatement)
and 17 supplemental assertions, together with their required dependencies.
There are 695 theorems and 44 definitions in 194 modules. `Audit.lean` is the
separate audit entry point.

`claims.json` gives the manuscript location, original statement, assumptions,
conclusion and exact Lean declarations for each record. `targets.json` records
all audited declarations. Locations refer to the public manuscript or the
included Lean sources. They do not require any separate source archive.

For the principal comparison, start with `paper_main_theorem` and
`paper_equation_9_1`. Intermediate reduction lemmas take explicit construction
hypotheses; the final theorems discharge those hypotheses using the proved
constructions. Conditional intermediate lemmas are not substitutes for the
final statements.

## Trust and review

Only `propext`, `Classical.choice` and `Quot.sound` are allowed as transitive
axioms. No `sorryAx`, custom unproved axiom or native-evaluation trust axiom
is accepted. Fresh replay uses the same Lean kernel in a new environment;
it is not a separate checker implementation.

The correspondence between the manuscript and formal statements was reviewed
by the generating agent, not by an independent human reviewer. Some proof
routes differ while preserving the declared assumptions, quantifiers,
constants and conclusions. The coverage count measures the declared assertion
inventory, not every sentence in the paper.

## Exclusions

`exclusions.json` is the machine-readable inventory. It excludes literary and
bibliographic claims; originality, significance and priority; explicitly open
questions; efficiency and optimality claims that the paper does not make;
publication metadata; and literal certification of every natural-language
proof sentence. Mechanical success is not peer review or a novelty certificate.
