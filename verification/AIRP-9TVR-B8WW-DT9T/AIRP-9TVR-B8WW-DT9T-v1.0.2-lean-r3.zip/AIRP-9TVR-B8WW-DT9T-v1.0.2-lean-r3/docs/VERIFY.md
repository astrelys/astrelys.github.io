# Verification guide

[Overview](../README.md) · [Scope](SCOPE.md)

## 1. Check the download

Compare the ZIP with the `.zip.sha256` file supplied alongside it, before
extracting. In the directory containing both files, use one of:

```sh
sha256sum -c AIRP-9TVR-B8WW-DT9T-v1.0.2-lean-r3.zip.sha256
# macOS:
shasum -a 256 -c AIRP-9TVR-B8WW-DT9T-v1.0.2-lean-r3.zip.sha256
```

The checksum detects changed bytes; it does not authenticate the publisher.
`hashes.json` covers every package file except itself. The reference paper can
be checked separately with `sha256sum paper.pdf` or `shasum -a 256 paper.pdf`,
using the PDF checksum in `paper.json`.

## 2. Prepare the environment

Install Python 3, Git and [elan](https://github.com/leanprover/elan).
From the extracted package directory:

```sh
elan toolchain install leanprover/lean4:v4.34.0
lean --version
lake exe cache get
```

Use Lean 4.34.0 and the exact revisions in `dependency-lock.json` and
`lake-manifest.json`. Setup may download public sources and compiled dependency
caches; several GB of free space may be needed. No credentials or original
author workspace are required. Skip installation when that exact toolchain
is already available. Do not run `lake update` or edit the lock files.

## 3. Run the complete check

```sh
python3 scripts/verify.py --output ../verification-output
```

Do not use Python's `-O` option. Choose a new output directory outside the
package. The verifier checks file hashes, the toolchain and dependency commits;
builds every proof module; audits all 739 declarations against the axiom
whitelist; runs a fresh kernel replay; and checks the file hashes again.
Each phase has a 30-minute timeout.

The core Lean commands are:

```sh
lake build SpectralComparison.All
lake env lean Audit.lean
lake env leanchecker --fresh --verbose SpectralComparison.All
```

Use the Python entry point for the additional integrity, dependency, target-set
and axiom checks. Only `result: full-recheck-passed` with
`declaration_count: 739` in `result.json` represents full mechanical success.

## 4. Interpret failures and outputs

| Observation | Meaning / action |
| :--- | :--- |
| Hash or dependency mismatch | Use a fresh, checksum-verified extraction and the pinned revisions. |
| Output directory already exists | Choose a new directory; retain earlier diagnostics. |
| Missing tool or dependency | Complete the environment setup, then rerun. |
| Nonzero exit, timeout, missing or unfinished result | Verification has not succeeded. Inspect the phase log. |
| `audit-only-passed` | Import/axiom audit only; no complete build and fresh replay verdict. |

Logs and `axioms.json` are written to the chosen output directory. They describe
your run and are not part of the distributed package. A local reproduction
from an empty proof build directory passed during preparation; public dependency
caches were reused. A new-machine network installation was not tested.
