import SpectralComparison.TwoLevelWater

noncomputable section
open Filter Topology
namespace SpectralComparison

theorem harmonicEnvelope_two_level_div_tendsto {k m : ℕ} (hk : 1 ≤ k) (hm : 1 ≤ m) :
    Tendsto (fun ε : ℝ => harmonicEnvelope (twoLevelSpectrum k m ε) k (by omega)/ε)
      (𝓝[>] 0) (𝓝 ((k+m:ℕ):ℝ)) := by
  have hm0 : (0:ℝ) < m := by exact_mod_cast (show 0 < m by omega)
  have ht : Tendsto (fun ε : ℝ => ((k+m:ℕ):ℝ)*(m:ℝ)/((m:ℝ)+(k:ℝ)*ε)) (𝓝[>] 0)
      (𝓝 (((k+m:ℕ):ℝ)*(m:ℝ)/((m:ℝ)+(k:ℝ)*0))) :=
    tendsto_const_nhds.div (tendsto_const_nhds.add (tendsto_nhdsWithin_of_tendsto_nhds tendsto_id |>.const_mul (k:ℝ))) (by simpa using hm0.ne')
  simp only [mul_zero,add_zero,mul_div_cancel_right₀ _ hm0.ne'] at ht
  apply ht.congr'
  filter_upwards [self_mem_nhdsWithin,eventually_le_nhds (show (0:ℝ) < 1 by norm_num) |>.filter_mono nhdsWithin_le_nhds] with ε he he1
  have he0 : 0 < ε := he
  rw [harmonicEnvelope_two_level hk hm he0 he1]
  field_simp

/-- The unnumbered sharpness claim preceding D.2 concerns the auxiliary harmonic lower bound B. -/
theorem paper_harmonic_auxiliary_sharpness {k m : ℕ} (hk : 1 ≤ k) (hm : 1 ≤ m) :
    Tendsto (fun ε : ℝ => harmonicEnvelope (twoLevelSpectrum k m ε) k (by omega)/ε)
      (𝓝[>] 0) (𝓝 ((k+m:ℕ):ℝ)) ∧
    Tendsto (fun ε : ℝ => spectralMean (twoLevelSpectrum k m ε) k/ε)
      (𝓝[>] 0) (𝓝 (((k:ℝ)+1)*(m:ℝ))) ∧
    Tendsto (fun ε : ℝ => spectralMean (twoLevelSpectrum k m ε) k/
      harmonicEnvelope (twoLevelSpectrum k m ε) k (by omega))
      (𝓝[>] 0) (𝓝 ((((k:ℝ)+1)*(m:ℝ))/((k+m:ℕ):ℝ))) := by
  have hb := harmonicEnvelope_two_level_div_tendsto hk hm
  have hy := two_level_spectralMean_div_tendsto k m
  refine ⟨hb,hy,?_⟩
  have hn : ((k+m:ℕ):ℝ) ≠ 0 := by positivity
  have ht := hy.div hb hn
  apply ht.congr'
  filter_upwards [self_mem_nhdsWithin] with ε he
  have he0 : ε ≠ 0 := (show 0 < ε from he).ne'
  exact div_div_div_cancel_right₀ he0 _ _

end SpectralComparison
