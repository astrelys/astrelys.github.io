import SpectralComparison.LightNoise

/-! Two-sided signal compression and one-sided noise compression in equation (7.11). -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Orthonormal compression on the output cannot increase squared Frobenius norm. -/
theorem frobenius_left_compression {n m r : Type*} [Fintype n] [Fintype m] [Fintype r]
    [DecidableEq n] [DecidableEq r] (X : Matrix n m ℝ) (U : Matrix n r ℝ) (hU : Uᴴ*U=1) :
    ((Uᴴ*X)*(Uᴴ*X)ᴴ).trace≤(X*Xᴴ).trace := by
  have hh := trace_orthonormal_compression_le (Matrix.posSemidef_self_mul_conjTranspose X) U hU
  simpa only [Matrix.conjTranspose_mul,Matrix.conjTranspose_conjTranspose,Matrix.mul_assoc] using hh

/-- Orthonormal compression on the input cannot increase squared Frobenius norm. -/
theorem frobenius_right_compression {n m r : Type*} [Fintype n] [Fintype m] [Fintype r]
    [DecidableEq m] [DecidableEq r] (X : Matrix n m ℝ) (U : Matrix m r ℝ) (hU : Uᴴ*U=1) :
    ((X*U)*(X*U)ᴴ).trace≤(X*Xᴴ).trace := by
  have hh := trace_orthonormal_compression_le (Matrix.posSemidef_conjTranspose_mul_self X) U hU
  calc
    ((X*U)*(X*U)ᴴ).trace = (Uᴴ*(Xᴴ*X)*U).trace := by
      rw [Matrix.trace_mul_comm,Matrix.conjTranspose_mul]
      simp only [Matrix.mul_assoc]
    _ ≤ (Xᴴ*X).trace := hh
    _ = _ := Matrix.trace_mul_comm _ _

/-- Double orthonormal compression cannot increase squared Frobenius norm. -/
theorem frobenius_two_sided_compression {n r : Type*} [Fintype n] [Fintype r]
    [DecidableEq n] [DecidableEq r] (X : Matrix n n ℝ) (U : Matrix n r ℝ) (hU : Uᴴ*U=1) :
    ((Uᴴ*X*U)*(Uᴴ*X*U)ᴴ).trace≤(X*Xᴴ).trace := by
  exact (frobenius_right_compression (Uᴴ*X) U hU).trans (frobenius_left_compression X U hU)

/-- The exact algebraic compression step (7.11), from the signal factorization and PSD noise floor.
E carries the light-coordinate amplitudes. These geometric hypotheses must still be supplied by the construction. -/
theorem signal_noise_ridge_compression {n r l d : Type*}
    [Fintype n] [Fintype r] [Fintype l] [Fintype d]
    [DecidableEq n] [DecidableEq r] [DecidableEq l] [DecidableEq d]
    (Q : Matrix n r ℝ) (U : Matrix r d ℝ) (hU : Uᴴ*U=1)
    (E : Matrix n l ℝ) (G : Matrix l d ℝ) (hQ : Q*U=E*G)
    {C : Matrix n n ℝ} {a v : ℝ} (ha : 0≤a) (hv : 0≤v)
    (hnoise : (C-v • (E*Eᴴ)).PosSemidef) (M : Matrix r n ℝ) :
    let T := Uᴴ*M*E
    a*(((1 : Matrix d d ℝ)-T*G)*((1 : Matrix d d ℝ)-T*G)ᴴ).trace+v*(T*Tᴴ).trace ≤
      a*(((1 : Matrix r r ℝ)-M*Q)*((1 : Matrix r r ℝ)-M*Q)ᴴ).trace+(M*C*Mᴴ).trace := by
  let T := Uᴴ*M*E
  have hid : Uᴴ*((1 : Matrix r r ℝ)-M*Q)*U=1-T*G := by
    rw [Matrix.mul_sub,Matrix.sub_mul,Matrix.mul_one,hU]
    congr 1
    calc
      Uᴴ*(M*Q)*U=Uᴴ*M*(Q*U) := by simp only [Matrix.mul_assoc]
      _ = _ := by rw [hQ]; simp only [T,Matrix.mul_assoc]
  have hsignal := frobenius_two_sided_compression ((1 : Matrix r r ℝ)-M*Q) U hU
  rw [hid] at hsignal
  have hnoise' : v*((M*E)*(M*E)ᴴ).trace≤(M*C*Mᴴ).trace := by
    have hh := (hnoise.mul_mul_conjTranspose_same M).trace_nonneg
    rw [Matrix.mul_sub,Matrix.sub_mul,Matrix.mul_smul,Matrix.smul_mul,Matrix.trace_sub,Matrix.trace_smul,smul_eq_mul] at hh
    have he : M*(E*Eᴴ)*Mᴴ=(M*E)*(M*E)ᴴ := by simp only [Matrix.conjTranspose_mul,Matrix.mul_assoc]
    rw [he] at hh
    linarith
  have hnoise'' : v*(T*Tᴴ).trace≤(M*C*Mᴴ).trace := by
    have hh := frobenius_left_compression (M*E) U hU
    change ((Uᴴ*(M*E))*(Uᴴ*(M*E))ᴴ).trace≤_ at hh
    have he : Uᴴ*(M*E)=T := by simp only [T,Matrix.mul_assoc]
    rw [he] at hh
    exact (mul_le_mul_of_nonneg_left hh hv).trans hnoise'
  exact add_le_add (mul_le_mul_of_nonneg_left hsignal ha) hnoise''

end SpectralComparison
