import SpectralComparison.RobustLargeFrame

/-! Small dimensions and all-dimensional assembly of the robust kernel frame. -/
noncomputable section
open Matrix MeasureTheory ProbabilityTheory
namespace SpectralComparison

/-- Row selection is exactly a diagonal indicator compression. -/
theorem row_selection_gram_eq {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq n] (Q : Matrix n p ℝ) (J : Finset n) :
    (Q.submatrix (fun i : J => (i:n)) id)ᴴ*Q.submatrix (fun i : J => (i:n)) id =
      Qᴴ*Matrix.diagonal (fun i => if i∈J then (1:ℝ) else 0)*Q := by
  ext a b
  simp [Matrix.mul_apply,Matrix.diagonal_apply]
  exact Finset.sum_attach J (fun i => Q i a * Q i b)

/-- Selecting rows of a Parseval frame gives a column Gram bounded above by the identity. -/
theorem parseval_row_gram_upper {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p] (Q : Matrix n p ℝ) (hQ : Qᴴ*Q=1) (J : Finset n) :
    (1-(Q.submatrix (fun i : J => (i:n)) id)ᴴ*Q.submatrix (fun i : J => (i:n)) id).PosSemidef := by
  have hm : (Matrix.diagonal (fun i : n => if i∈J then (0:ℝ) else 1)).PosSemidef :=
    Matrix.PosSemidef.diagonal (fun i => by split_ifs <;> norm_num)
  have he : Matrix.diagonal (fun i : n => if i∈J then (0:ℝ) else 1)=
      1-Matrix.diagonal (fun i : n => if i∈J then (1:ℝ) else 0) := by
    ext i j
    by_cases hij : i=j
    · subst j; simp; split_ifs <;> norm_num
    · simp [hij]
  have hh := hm.conjTranspose_mul_mul_same Q
  rw [he,Matrix.mul_sub,Matrix.sub_mul,Matrix.mul_one,hQ,← row_selection_gram_eq] at hh
  exact hh

/-- Any permitted dimensions admit a Parseval frame whose small row sets are independent. -/
theorem exists_fullspark_parseval {N p : ℕ} (hpN : p≤N) :
    ∃ Q : Matrix (Fin N) (Fin p) ℝ, Qᴴ*Q=1 ∧
      ∀ J : Finset (Fin N), J.card≤p →
        (Q.submatrix (fun i : J => (i:Fin N)) id * (Q.submatrix (fun i : J => (i:Fin N)) id)ᴴ).PosDef := by
  let μ : Measure (Fin N × Fin p → ℝ) := Measure.pi (fun _ => gaussianReal 0 1)
  let X := fun (ω : Fin N × Fin p → ℝ) => Matrix.of (fun i j => ω (i,j))
  have hid : HasLaw id μ μ := HasLaw.id
  have hx := gaussian_product_entry_hasLaw id hid
  have hi := gaussian_product_independent id hid
  have hr := gaussian_all_row_grams_posDef_ae X hx hi
  have hxt (a : Fin p × Fin N) : HasLaw (fun ω => (X ω)ᴴ a.1 a.2) (gaussianReal 0 1) μ := by
    simpa only [Matrix.conjTranspose_apply,star_trivial,X,Matrix.of_apply,id_eq] using hx (a.2,a.1)
  have hit : iIndepFun (fun a : Fin p × Fin N => fun ω => (X ω)ᴴ a.1 a.2) μ := by
    simpa [Matrix.conjTranspose_apply,X,Prod.swap] using hi.precomp (Equiv.prodComm (Fin p) (Fin N)).injective
  have hc := gaussian_gram_posDef_ae (Fin.castLEEmb hpN) (fun ω => (X ω)ᴴ) hxt hit
  obtain ⟨ω,hcol,hrows⟩ := (hc.and hr).exists
  simp only [Matrix.conjTranspose_conjTranspose] at hcol
  obtain ⟨W,hW,hWSW,hWW⟩ := exists_inverse_sqrt hcol
  refine ⟨X ω*W,?_,?_⟩
  · simpa only [Matrix.conjTranspose_mul,hW.isHermitian.eq,Matrix.mul_assoc] using hWSW
  · intro J hJ
    have he : (X ω*W).submatrix (fun i : J => (i:Fin N)) id=
        (X ω).submatrix (fun i : J => (i:Fin N)) id * W := by ext a b; simp [Matrix.mul_apply]
    rw [he]
    exact row_gram_posDef_mul_isUnit _ (hrows J hJ) W hW.isUnit

/-- The target constant in the small-dimensional range is below one. -/
theorem robust_small_constant {k q : ℕ} (hk : 1≤k) (hks : k<16) :
    (k:ℝ)^2/(4000000000000000000000000000*((q:ℝ)+Real.sqrt k))≤1 := by
  have hk1 : (1:ℝ)≤k := by exact_mod_cast hk
  have hk15 : (k:ℝ)≤15 := by exact_mod_cast (show k≤15 by omega)
  have hs : (1:ℝ)≤Real.sqrt k := by simpa using Real.sqrt_le_sqrt hk1
  have hp : 0<4000000000000000000000000000*((q:ℝ)+Real.sqrt k) := by positivity
  apply (div_le_one hp).mpr
  nlinarith [Nat.cast_nonneg (α := ℝ) q, Nat.cast_nonneg (α := ℝ) k]

/-- The full equation (5.1) frame for every k>=1, including arbitrary orthonormal kernel bases.
The integer-repetition assertion (5.2) is a separate deterministic reduction. -/
theorem exists_robust_parseval_kernel {k q : ℕ} (hk : 1≤k) (hq : 2*q≤k) :
    ∃ Q : Matrix (Fin (2*k)) (Fin (k-q)) ℝ, Qᴴ*Q=1 ∧
      (∀ J : Finset (Fin (2*k)), J.card≤k-q →
        (Q.submatrix (fun i : J => (i:Fin (2*k))) id *
          (Q.submatrix (fun i : J => (i:Fin (2*k))) id)ᴴ).PosDef) ∧
      ∀ H L : Finset (Fin (2*k)), Disjoint H L → 4*H.card≤k → H.card+L.card≤k →
        ∀ U : Matrix (Fin (k-q)) (Fin (k-q-H.card)) ℝ, Uᴴ*U=1 →
          (Q.submatrix (fun i : H => (i:Fin (2*k))) id)*U=0 →
          (((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U)ᴴ*
            ((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U)).PosDef →
          (k:ℝ)^2/(4000000000000000000000000000*((q:ℝ)+Real.sqrt k))≤
            (((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U)ᴴ*
              ((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U))⁻¹.trace := by
  by_cases hkl : 16≤k
  · exact exists_robust_parseval_large hkl hq
  obtain ⟨Q,hQ,hrows⟩ := exists_fullspark_parseval (N := 2*k) (p := k-q) (by omega)
  refine ⟨Q,hQ,hrows,?_⟩
  intro H L _hdis hh _hl U hU _hHU hG
  have hgap := (parseval_row_gram_upper Q hQ L).conjTranspose_mul_mul_same U
  have he : Uᴴ*(1-(Q.submatrix (fun i : L => (i:Fin (2*k))) id)ᴴ*
      Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U =
      1-((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U)ᴴ*
        ((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U) := by
    simp only [Matrix.mul_sub,Matrix.sub_mul,Matrix.mul_one,hU,Matrix.conjTranspose_mul,Matrix.mul_assoc]
  rw [he] at hgap
  have ht := inverse_trace_order hG Matrix.PosDef.one hgap
  simp only [inv_one,Matrix.trace_one,Fintype.card_fin] at ht
  have hd : 1≤k-q-H.card := by omega
  have hdr : (1:ℝ)≤(k-q-H.card:ℕ) := by exact_mod_cast hd
  exact (robust_small_constant hk (by omega)).trans (hdr.trans ht)

end SpectralComparison
