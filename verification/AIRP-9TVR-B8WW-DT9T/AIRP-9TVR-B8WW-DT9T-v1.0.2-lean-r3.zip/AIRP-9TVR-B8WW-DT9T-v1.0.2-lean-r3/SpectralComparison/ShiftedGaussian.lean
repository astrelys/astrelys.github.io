import SpectralComparison.FiniteLevelReduction

noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

theorem shifted_gaussian_trace_tail {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {t q : ℕ} (ht : 4 ≤ t)
    (G : Ω → Matrix (Fin t) (Fin (t+q)) ℝ)
    (hG : ∀ a : Fin t × Fin (t+q), HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin t × Fin (t+q) => fun ω => G ω a.1 a.2) μ)
    (hmeas : ∀ a : Fin t × Fin (t+q), Measurable (fun ω => G ω a.1 a.2)) :
    μ.real {ω | (G ω*(G ω)ᴴ)⁻¹.trace ≤ (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t:ℕ)))} ≤
      2*Real.exp (-31*(t:ℕ)) := by
  let j := min t ⌊Real.sqrt (t:ℕ)⌋₊
  obtain ⟨hj, hjsqrt, hdim⟩ := gaussian_tail_dimension (q := 0) (by omega : 1 ≤ t) (by simpa using ht)
  simp only [Nat.add_zero, Nat.cast_zero, zero_add] at hj hjsqrt hdim
  have hjt : j ≤ t := min_le_left _ _
  have hjpos : (0:ℝ) < j := by exact_mod_cast (show 0 < j by omega)
  have hsub : t+q-(t-j) = q+j := by omega
  have h := gaussian_inverse_trace_chosen_rows G hG hind hmeas hj hjt (Nat.le_add_right t q)
  rw [hsub] at h
  have hden : (0:ℝ) < 1000*((q:ℝ)+j) := by positivity
  have hthresh : (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t:ℕ))) ≤
      (t:ℝ)/(1000*(q+j:ℕ)) := by
    simp only [Nat.cast_add]
    apply div_le_div_of_nonneg_left (by positivity) hden
    have hh : (j:ℝ) ≤ Real.sqrt (t:ℕ) := hjsqrt
    nlinarith
  have hmono : μ.real {ω | (G ω*(G ω)ᴴ)⁻¹.trace ≤ (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t:ℕ)))} ≤
      μ.real {ω | (G ω*(G ω)ᴴ)⁻¹.trace ≤ (t:ℝ)/(1000*(q+j:ℕ))} :=
    measureReal_mono (fun ω hω => hω.trans hthresh)
  apply (hmono.trans h).trans
  apply mul_le_mul_of_nonneg_left _ (by norm_num)
  apply Real.exp_le_exp.mpr
  have hd : (t:ℝ)/4 ≤ (j:ℝ)*((q:ℝ)+j) := by
    have hq : (0:ℝ) ≤ q := by positivity
    nlinarith [mul_nonneg (le_of_lt hjpos) hq]
  change -124*((j:ℝ)*(q+j:ℕ)) ≤ -31*(t:ℕ)
  simp only [Nat.cast_add] at hd ⊢
  nlinarith

theorem shifted_row_subset_tail {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {N t q : ℕ} (ht : 4 ≤ t)
    (G : Ω → Matrix (Fin N) (Fin (t+q)) ℝ)
    (hG : ∀ a : Fin N × Fin (t+q), HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin N × Fin (t+q) => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : Fin N × Fin (t+q), Measurable (fun ω => G ω a.1 a.2))
    (J : Finset (Fin N)) (hJ : J.card=t) :
    μ.real {ω | ((G ω).submatrix (fun i : J => (i : Fin N)) id *
      ((G ω).submatrix (fun i : J => (i : Fin N)) id)ᴴ)⁻¹.trace ≤
      (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t:ℕ)))} ≤ 2*Real.exp (-31*(t:ℕ)) := by
  let e : Fin t ≃ J := (finCongr (by simpa using hJ.symm)).trans (Fintype.equivFin J).symm
  let f : Fin t → Fin N := fun i => (e i : Fin N)
  have hf : Function.Injective f := Subtype.val_injective.comp e.injective
  let W := fun ω => (G ω).submatrix f id
  have hw (a : Fin t × Fin (t+q)) : HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ := hG (f a.1,a.2)
  have hmap : Function.Injective (fun a : Fin t × Fin (t+q) => (f a.1,a.2)) := by
    intro a b hab
    have h1 : f a.1 = f b.1 := congrArg (fun z : Fin N × Fin (t+q) => z.1) hab
    have h2 : a.2 = b.2 := congrArg (fun z : Fin N × Fin (t+q) => z.2) hab
    exact Prod.ext (hf h1) h2
  have hi : iIndepFun (fun a : Fin t × Fin (t+q) => fun ω => W ω a.1 a.2) μ :=
    hind.precomp hmap
  have h := shifted_gaussian_trace_tail ht W hw hi (fun a => hm (f a.1,a.2))
  have he (ω : Ω) : (W ω*(W ω)ᴴ)⁻¹.trace =
      ((G ω).submatrix (fun i : J => (i : Fin N)) id *
      ((G ω).submatrix (fun i : J => (i : Fin N)) id)ᴴ)⁻¹.trace :=
    inverse_gram_trace_reindex ((G ω).submatrix (fun i : J => (i : Fin N)) id) e
  simpa only [he] using h

theorem shifted_all_row_subsets_tail {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {N t q : ℕ} (ht : 4 ≤ t)
    (hN : N ≤ 2*t) (G : Ω → Matrix (Fin N) (Fin (t+q)) ℝ)
    (hG : ∀ a : Fin N × Fin (t+q), HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin N × Fin (t+q) => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : Fin N × Fin (t+q), Measurable (fun ω => G ω a.1 a.2)) :
    μ.real {ω | ∃ J : Finset (Fin N), J.card=t ∧
      ((G ω).submatrix (fun i : J => (i : Fin N)) id *
      ((G ω).submatrix (fun i : J => (i : Fin N)) id)ᴴ)⁻¹.trace ≤
      (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t:ℕ)))} ≤ 2*Real.exp (-29*(t:ℕ)) := by
  classical
  let s := (Finset.univ : Finset (Fin N)).powersetCard t
  have h := finite_union_probability_bound (μ := μ) s
    (fun J => {ω | ((G ω).submatrix (fun i : J => (i : Fin N)) id *
      ((G ω).submatrix (fun i : J => (i : Fin N)) id)ᴴ)⁻¹.trace ≤
      (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t:ℕ)))})
    (fun J hJ => shifted_row_subset_tail ht G hG hind hm J (Finset.mem_powersetCard.mp hJ).2)
  have hev : {ω | ∃ J ∈ s, ((G ω).submatrix (fun i : J => (i : Fin N)) id *
      ((G ω).submatrix (fun i : J => (i : Fin N)) id)ᴴ)⁻¹.trace ≤
      (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t:ℕ)))} =
      {ω | ∃ J : Finset (Fin N), J.card=t ∧ ((G ω).submatrix (fun i : J => (i : Fin N)) id *
      ((G ω).submatrix (fun i : J => (i : Fin N)) id)ᴴ)⁻¹.trace ≤
      (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t:ℕ)))} := by
    ext ω
    simp [s]
  simp only [Set.mem_ofPred_eq] at h
  rw [hev] at h
  have hc : (s.card:ℝ) ≤ (4:ℝ)^t := by
    have hn : s.card ≤ 2^N := by
      calc
        s.card ≤ (Finset.univ : Finset (Fin N)).powerset.card :=
          Finset.card_le_card (fun _ h => Finset.mem_powerset.mpr (Finset.mem_powersetCard.mp h).1)
        _ = 2^N := by simp
    have hpow : (2:ℝ)^N ≤ 2^(2*t) := pow_le_pow_right₀ (by norm_num) hN
    calc
      _ ≤ (2:ℝ)^N := by exact_mod_cast hn
      _ ≤ _ := hpow
      _ = (4:ℝ)^t := by rw [pow_mul]; norm_num
  have hfour : (4:ℝ)^t ≤ Real.exp (2*(t:ℕ)) := by
    have h4 : (4:ℝ) ≤ Real.exp 2 := by
      have h2 := Real.exp_one_gt_two.le
      calc
        (4:ℝ) = 2*2 := by norm_num
        _ ≤ Real.exp 1 * Real.exp 1 := mul_le_mul h2 h2 (by norm_num) (by positivity)
        _ = Real.exp 2 := by rw [← Real.exp_add]; norm_num
    calc
      _ ≤ (Real.exp 2)^t := pow_le_pow_left₀ (by norm_num) h4 _
      _ = Real.exp (2*(t:ℕ)) := by rw [← Real.exp_nat_mul]; congr 1; ring
  apply h.trans
  calc
    _ ≤ (4:ℝ)^t*(2*Real.exp (-31*(t:ℕ))) := by gcongr
    _ ≤ Real.exp (2*(t:ℕ))*(2*Real.exp (-31*(t:ℕ))) := by gcongr
    _ = 2*Real.exp (-29*(t:ℕ)) := by
      rw [show Real.exp (2*(t:ℕ))*(2*Real.exp (-31*(t:ℕ))) =
        2*(Real.exp (2*(t:ℕ))*Real.exp (-31*(t:ℕ))) by ring, ← Real.exp_add]
      congr 2
      ring


end SpectralComparison
