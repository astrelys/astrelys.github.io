import SpectralComparison.WeightedReindex

noncomputable section
open Matrix
namespace SpectralComparison

/-- A prefix frame plus singleton columns gives the exact weighted threshold construction. -/
theorem exists_weighted_prefix_frame {k m t : ℕ} (hk : 1≤k) (ht : 1≤t) (htm : t≤m)
    (b : Fin m → ℝ) (hb : ∀ i,0<b i) {z : ℝ} (hz : 0≤z)
    (hhead : ∀ i : Fin t,z≤b (i.castLE htm)) :
    ∃ R : Matrix (Fin (k+m)) (Fin m) ℝ,Rᴴ*R=1 ∧
      ∀ J : Finset (Fin (k+m)),J.card=m →
        IsUnit ((R.submatrix (fun i : J => (i:Fin (k+m))) id)ᴴ*R.submatrix (fun i : J => (i:Fin (k+m))) id) →
        z*((k:ℝ)+t)*Real.sqrt (min k t:ℕ)/16000000000≤
          (Matrix.diagonal b*((R.submatrix (fun i : J => (i:Fin (k+m))) id)ᴴ*
            R.submatrix (fun i : J => (i:Fin (k+m))) id)⁻¹).trace := by
  let ec : Fin m ≃ Fin t ⊕ Fin (m-t) := (finSumFinEquiv.trans (finCongr (Nat.add_sub_of_le htm))).symm
  let bs := Sum.elim (fun i : Fin t => b (ec.symm (Sum.inl i))) (fun i : Fin (m-t) => b (ec.symm (Sum.inr i)))
  obtain ⟨Q,hQ,hcost⟩ := exists_weighted_prefix_base hk ht
  have hcost' : ∀ I : Finset (Fin (k+t)),I.card=Fintype.card (Fin t) →
      IsUnit ((Q.submatrix (fun i : I => (i:Fin (k+t))) id)ᴴ*Q.submatrix (fun i : I => (i:Fin (k+t))) id) →
      z*((k:ℝ)+t)*Real.sqrt (min k t:ℕ)/16000000000≤
        (Matrix.diagonal (fun i : Fin t => b (ec.symm (Sum.inl i)))*
          ((Q.submatrix (fun i : I => (i:Fin (k+t))) id)ᴴ*Q.submatrix (fun i : I => (i:Fin (k+t))) id)⁻¹).trace := by
    intro I hI hu
    have hG := (posSemidef_conjTranspose_mul_self (Q.submatrix (fun i : I => (i:Fin (k+t))) id)).posDef_iff_isUnit.mpr hu
    have hbasis := hcost I (by simpa using hI) hu
    have hbase : ((k:ℝ)+t)*Real.sqrt (min k t:ℕ)/16000000000≤
        ((Q.submatrix (fun i : I => (i:Fin (k+t))) id)ᴴ*Q.submatrix (fun i : I => (i:Fin (k+t))) id)⁻¹.trace := by
      linarith [le_max_right ((t:ℝ)-k) 0]
    have hmin : ∀ i : Fin t,z≤b (ec.symm (Sum.inl i)) := by
      intro i
      convert hhead i using 1
      congr 1
    have h := weighted_basis_min_lower _ hmin hG hbase hz
    convert h using 1 <;> ring
  obtain ⟨hR,hbound⟩ := weighted_singleton_extension Q hQ
    (fun i : Fin t => b (ec.symm (Sum.inl i))) (fun i : Fin (m-t) => b (ec.symm (Sum.inr i)))
    (fun i => (hb _).le) hcost'
  let er : Fin (k+m) ≃ Fin (k+t) ⊕ Fin (m-t) := Fintype.equivOfCardEq (by simp; omega)
  obtain ⟨hR',hbound'⟩ := weighted_frame_reindex (Matrix.fromBlocks Q 0 0 1) hR bs hbound er ec
  have he : bs ∘ ec=b := by
    funext i
    have hh : bs (ec i)=b (ec.symm (ec i)) := by cases ec i <;> rfl
    simpa using hh
  rw [he] at hbound'
  refine ⟨(Matrix.fromBlocks Q 0 0 1).submatrix er ec,hR',?_⟩
  intro J hJ hu
  exact hbound' J (by simpa using hJ) hu

end SpectralComparison
