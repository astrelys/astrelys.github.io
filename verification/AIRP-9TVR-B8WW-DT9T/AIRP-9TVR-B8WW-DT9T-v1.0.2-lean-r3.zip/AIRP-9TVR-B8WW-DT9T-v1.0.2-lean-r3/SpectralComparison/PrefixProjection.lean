import SpectralComparison.PrefixSmall
import SpectralComparison.PrefixComplement

/-! Complete paper Lemma 6.1, including regularization of singular auxiliary blocks. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- The exact prefix projection exists for every permitted k,q,t. -/
theorem exists_prefix_projection {k q t : ℕ} (hk : 1≤k) (hq : 2*q≤k) (ht : 1≤t) :
    ∃ P : Matrix (Fin (k+t)) (Fin (k+t)) ℝ, P.PosSemidef ∧ P*P=P ∧ P.rank=t+q ∧
      ∀ J : Finset (Fin (k+t)), J.card=t →
        IsUnit (P.submatrix (fun i : J => (i:Fin (k+t))) (fun i : J => (i:Fin (k+t)))) →
        (k:ℝ)*t/(32000000000000000000000000000*((q:ℝ)+Real.sqrt k)) ≤
        (P.submatrix (fun i : J => (i:Fin (k+t))) (fun i : J => (i:Fin (k+t))))⁻¹.trace := by
  rcases le_total t k with htk | hkt
  · exact prefix_projection_short hk hq ht htk
  · exact prefix_projection_large hk hq hkt

/-- Paper Lemma 6.1 / equation (6.1), with the exact C1=32*10^27.
The same projection controls every nonsingular t-block; its regularized conclusion
holds for all t-blocks, including singular auxiliary projection blocks. -/
theorem paper_lemma_6_1 {k q t : ℕ} (hk : 1≤k) (hq : 2*q≤k) (ht : 1≤t) :
    ∃ P : Matrix (Fin (k+t)) (Fin (k+t)) ℝ, P.IsHermitian ∧ P*P=P ∧ P.rank=t+q ∧
      (∀ J : Finset (Fin (k+t)), J.card=t →
        IsUnit (P.submatrix (fun i : J => (i:Fin (k+t))) (fun i : J => (i:Fin (k+t)))) →
        (k:ℝ)*t/(32000000000000000000000000000*((q:ℝ)+Real.sqrt k)) ≤
        (P.submatrix (fun i : J => (i:Fin (k+t))) (fun i : J => (i:Fin (k+t))))⁻¹.trace) ∧
      (∀ (T : Matrix (Fin (k+t)) (Fin (k+t)) ℝ) (α β : ℝ), T.PosDef → 0<α → 0<β →
        (α • 1 + β • P - T).PosSemidef →
        ∀ J : Finset (Fin (k+t)), J.card=t →
        let L := (k:ℝ)*t/(32000000000000000000000000000*((q:ℝ)+Real.sqrt k))
        L/(β+α*L) ≤ (T.submatrix (fun i : J => (i:Fin (k+t))) (fun i : J => (i:Fin (k+t))))⁻¹.trace) := by
  obtain ⟨P,hP,hi,hr,hb⟩ := exists_prefix_projection hk hq ht
  refine ⟨P,hP.isHermitian,hi,hr,hb,?_⟩
  intro T α β hT hα hβ hgap J hJ
  let e : J → Fin (k+t) := fun i => i
  have hI : (1 : Matrix (Fin (k+t)) (Fin (k+t)) ℝ).submatrix e e=1 :=
    Matrix.submatrix_one e Subtype.val_injective
  have he : (α • 1 + β • P - T).submatrix e e = α • 1 + β • P.submatrix e e - T.submatrix e e := by
    ext a b
    have hh := congrFun (congrFun hI a) b
    simp only [Matrix.submatrix_apply] at hh
    simp only [Matrix.submatrix_apply,Matrix.sub_apply,Matrix.add_apply,Matrix.smul_apply,hh]
  have hlocal := hgap.submatrix e
  rw [he] at hlocal
  apply matrix_regularization (hP.submatrix e) (hT.submatrix Subtype.val_injective) hα hβ
  · apply div_pos
    · exact mul_pos (by exact_mod_cast (show 0<k by omega)) (by exact_mod_cast (show 0<t by omega))
    · apply mul_pos (by norm_num)
      exact add_pos_of_nonneg_of_pos (Nat.cast_nonneg q)
        (Real.sqrt_pos.mpr (by exact_mod_cast (show 0<k by omega)))
  · exact hb J hJ
  · exact hlocal

end SpectralComparison
