import SpectralComparison.EmbeddedPrecision

/-! Extending a prefix orientation with singleton covariance blocks preserves the exact spectrum. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- A block diagonal orthogonal matrix is orthogonal. -/
theorem block_orthogonal_extension {m n : Type*} [Fintype m] [Fintype n]
    [DecidableEq m] [DecidableEq n] (V : Matrix m m ℝ) (hV : V.transpose*V=1) :
    (Matrix.fromBlocks V 0 0 (1 : Matrix n n ℝ)).transpose *
      Matrix.fromBlocks V 0 0 (1 : Matrix n n ℝ)=1 := by
  simp only [Matrix.fromBlocks_transpose,Matrix.transpose_zero,Matrix.transpose_one,
    Matrix.fromBlocks_multiply,Matrix.mul_zero,Matrix.zero_mul,Matrix.mul_one,
    add_zero,zero_add,hV]
  exact Matrix.fromBlocks_one

/-- Block diagonal inversion separates the actual nonsingular prefix and singleton blocks. -/
theorem block_diagonal_inverse {m n : Type*} [Fintype m] [Fintype n]
    [DecidableEq m] [DecidableEq n] {A : Matrix m m ℝ} {D : Matrix n n ℝ}
    (hA : IsUnit A) (hD : IsUnit D) :
    (Matrix.fromBlocks A 0 0 D)⁻¹=Matrix.fromBlocks A⁻¹ 0 0 D⁻¹ := by
  apply Matrix.inv_eq_left_inv
  simp only [Matrix.fromBlocks_multiply,Matrix.mul_zero,Matrix.zero_mul,add_zero,zero_add,
    Matrix.nonsing_inv_mul A ((Matrix.isUnit_iff_isUnit_det _).mp hA),
    Matrix.nonsing_inv_mul D ((Matrix.isUnit_iff_isUnit_det _).mp hD)]
  exact Matrix.fromBlocks_one

/-- Extend one prefix orientation to a full prescribed spectrum, with exact prefix precision block. -/
theorem extend_prefix_orientation {m n l : Type*} [Fintype m] [Fintype n] [Fintype l]
    [DecidableEq m] [DecidableEq n] [DecidableEq l]
    (e : (m ⊕ n) ≃ l) (eig : l → ℝ) (heig : ∀ i,0<eig i)
    (V : Matrix m m ℝ) (hV : V.transpose*V=1) :
    ∃ W : Matrix l l ℝ, W.transpose*W=1 ∧
      ((W.transpose*Matrix.diagonal eig*W)⁻¹).submatrix (fun i => e (Sum.inl i)) (fun i => e (Sum.inl i)) =
        (V.transpose*Matrix.diagonal (fun i => eig (e (Sum.inl i)))*V)⁻¹ := by
  let B := Matrix.fromBlocks V 0 0 (1 : Matrix n n ℝ)
  have hB : B.transpose*B=1 := block_orthogonal_extension V hV
  let W := B.submatrix e.symm e.symm
  have hW : W.transpose*W=1 := by
    change (B.submatrix e.symm e.symm).transpose*B.submatrix e.symm e.symm=1
    rw [Matrix.transpose_submatrix,Matrix.submatrix_mul_equiv,hB]
    exact Matrix.submatrix_one e.symm e.symm.injective
  let A := V.transpose*Matrix.diagonal (fun i => eig (e (Sum.inl i)))*V
  let D : Matrix n n ℝ := Matrix.diagonal (fun i => eig (e (Sum.inr i)))
  have hA : A.PosDef := orbit_posDef _ (fun i => heig _) V hV
  have hD : D.PosDef := Matrix.PosDef.diagonal (fun i => heig _)
  have he : (W.transpose*Matrix.diagonal eig*W).submatrix e e=Matrix.fromBlocks A 0 0 D := by
    have hw : W.submatrix e e=B := by ext a b; simp [W]
    have hd : (Matrix.diagonal eig).submatrix e e =
        Matrix.fromBlocks (Matrix.diagonal (fun i => eig (e (Sum.inl i)))) 0 0 D := by
      rw [Matrix.submatrix_diagonal_equiv]
      ext a b
      cases a <;> cases b <;> simp [D,Matrix.diagonal_apply]
    rw [← Matrix.submatrix_mul_equiv _ _ e e e,← Matrix.submatrix_mul_equiv _ _ e e e,
      ← Matrix.transpose_submatrix,hw,hd]
    simp only [B,Matrix.fromBlocks_transpose,Matrix.transpose_zero,Matrix.transpose_one,
      Matrix.fromBlocks_multiply,Matrix.mul_zero,Matrix.zero_mul,Matrix.mul_one,Matrix.one_mul,
      add_zero,zero_add,A]
  refine ⟨W,hW,?_⟩
  have hh := congrArg (fun M : Matrix (m ⊕ n) (m ⊕ n) ℝ => M⁻¹.submatrix Sum.inl Sum.inl) he
  rw [Matrix.inv_submatrix_equiv,block_diagonal_inverse hA.isUnit hD.isUnit] at hh
  exact hh

end SpectralComparison
