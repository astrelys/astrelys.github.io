import SpectralComparison.FrameComplement

/-! Both realized lower bounds of the replication and complementary-rank proposition. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- A frame realizing the shifted bound in every nontrivial complementary dimension. -/
theorem exists_frame_complementary_rank_bound {n k : ℕ} (hk : 1≤k) (hkn : k<n) :
    ∃ Q : Matrix (Fin n) (Fin k) ℝ, Qᴴ*Q=1 ∧
      max (((n-k:ℕ):ℝ)-(k:ℝ)) 0+(n:ℝ)*Real.sqrt (min k (n-k):ℕ)/16000000000 ≤
      ((n-k:ℕ):ℝ)-(k:ℝ)+frameBasisMinimum Q := by
  by_cases hsmall : k≤n-k
  · obtain ⟨Q,hQ,hb⟩ := exists_replicated_balanced_frame hk (by omega : 2*k≤n)
    have hmin := le_frameBasisMinimum Q hQ hb
    have hs : (k:ℝ)≤(n-k:ℕ) := by exact_mod_cast hsmall
    refine ⟨Q,hQ,?_⟩
    rw [min_eq_left hsmall,max_eq_left (by linarith)]
    linarith
  · have hm : 1≤n-k := by omega
    obtain ⟨R,hR,hb⟩ := exists_replicated_balanced_frame hm (by omega : 2*(n-k)≤n)
    obtain ⟨Q,hQ,hQb⟩ := exists_complementary_frame_control (k:=k) (by omega : k+(n-k)=n) R hR hb
    have hmin := le_frameBasisMinimum Q hQ hQb
    have hs : ((n-k:ℕ):ℝ)≤k := by exact_mod_cast (by omega : n-k≤k)
    refine ⟨Q,hQ,?_⟩
    rw [min_eq_right (by omega),max_eq_right (by linarith)]
    linarith

/-- The second half of the replication proposition, with an actual frame and supremum consequence. -/
theorem paper_replication_complementary {n k : ℕ} (hk : 1≤k) (hkn : k<n) :
    (∃ Q : Matrix (Fin n) (Fin k) ℝ, Qᴴ*Q=1 ∧
      max (((n-k:ℕ):ℝ)-(k:ℝ)) 0+(n:ℝ)*Real.sqrt (min k (n-k):ℕ)/16000000000 ≤
      ((n-k:ℕ):ℝ)-(k:ℝ)+frameBasisMinimum Q) ∧
    ((max (((n-k:ℕ):ℝ)-(k:ℝ)) 0+(n:ℝ)*Real.sqrt (min k (n-k):ℕ)/16000000000:ℝ):EReal) ≤
      ((((n-k:ℕ):ℝ)-(k:ℝ):ℝ):EReal)+frameBasisSupremum n k := by
  obtain ⟨Q,hQ,hb⟩ := exists_frame_complementary_rank_bound hk hkn
  refine ⟨⟨Q,hQ,hb⟩,?_⟩
  have hc := EReal.coe_le_coe_iff.mpr hb
  simp only [EReal.coe_add] at hc
  exact hc.trans (add_le_add (le_refl _) (frameBasisMinimum_le_supremum Q hQ))

end SpectralComparison
