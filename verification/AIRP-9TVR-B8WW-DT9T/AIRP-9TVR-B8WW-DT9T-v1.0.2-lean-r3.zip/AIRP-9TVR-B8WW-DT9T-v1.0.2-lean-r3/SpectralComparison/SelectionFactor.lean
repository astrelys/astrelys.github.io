import SpectralComparison.SelectionNoise

/-! Actual selected signal rows factor through the light amplitudes after heavy-kernel compression. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- The factorization used in (7.11) holds for the selected rows themselves. -/
theorem actual_selection_signal_factor {n g r d : Type*}
    [Fintype n] [Fintype g] [Fintype r] [Fintype d]
    [DecidableEq n] [DecidableEq g]
    (f : n → Option g) (u : n → ℝ) (Q0 : Matrix g r ℝ) (Q : Matrix n r ℝ)
    (hrow : ∀ i j,Q i j=match f i with | none => 0 | some a => u i*Q0 a j)
    (U : Matrix r d ℝ)
    (hheavy : ∀ a,2≤(Finset.univ.filter (fun i => f i=some a)).card → ∀ j,(Q0*U) a j=0) :
    let L := Finset.univ.filter (fun a => (Finset.univ.filter (fun i => f i=some a)).card=1)
    let E : Matrix n L ℝ := Matrix.of (fun i j => if f i=some j.val then u i else 0)
    let G := Q0.submatrix Subtype.val id*U
    Q*U=E*G := by
  classical
  dsimp only
  let L := Finset.univ.filter (fun a => (Finset.univ.filter (fun i => f i=some a)).card=1)
  change Q*U=(Matrix.of (fun i (j : L) => if f i=some j.val then u i else 0))*_
  ext i j
  rw [Matrix.mul_apply,Matrix.mul_apply]
  simp only [hrow,Matrix.of_apply]
  cases hf : f i with
  | none => simp
  | some a =>
    have hpos : 0<(Finset.univ.filter (fun i => f i=some a)).card :=
      Finset.card_pos.mpr ⟨i,by simp [hf]⟩
    have hleft : (∑ x : r,u i*Q0 a x*U x j)=u i*(Q0*U) a j := by
      simp only [Matrix.mul_apply,Finset.mul_sum,mul_assoc]
    rw [hleft]
    by_cases ha : (Finset.univ.filter (fun i => f i=some a)).card=1
    · have haL : a∈L := by simp [L,ha]
      rw [Finset.sum_eq_single (⟨a,haL⟩ : L)]
      · change u i*(Q0*U) a j=(if some a=some a then u i else 0)*(Q0*U) a j
        rw [ite_eq_left rfl]
      · intro b _ hb
        have hab : a≠b.val := by intro hh; apply hb; exact Subtype.ext hh.symm
        simp [hab]
      · simp
    · rw [hheavy a (by omega),mul_zero]
      symm
      apply Finset.sum_eq_zero
      intro b _
      have hab : a≠b.val := by
        intro hh
        have hb := (Finset.mem_filter.mp b.property).2
        exact ha (hh ▸ hb)
      simp [hab]

end SpectralComparison
