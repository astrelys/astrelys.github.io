import SpectralComparison.Ridge

/-! Signal/noise compression for arbitrary predictors (paper equation 7.8). -/
noncomputable section
namespace SpectralComparison
open Matrix Finset
variable {ι κ ρ : Type*} [Fintype ι] [DecidableEq ι]
  [Fintype κ] [DecidableEq κ] [Fintype ρ] [DecidableEq ρ]

omit [DecidableEq ι] [DecidableEq κ] [Fintype ρ] [DecidableEq ρ] in
/-- A noise covariance supported orthogonally to Q has only the predicted-noise term
in the compressed error. No entries of a PSD matrix are discarded. -/
theorem orthogonal_noise_identity {C : Matrix ι ι ℝ} (hC : C.IsHermitian)
    (Q : Matrix ι ρ ℝ) (hQC : Q.conjTranspose*C = 0)
    (M : Matrix ρ κ ℝ) (E : Matrix κ ι ℝ) :
    (Q.conjTranspose-M*E)*C*(Q.conjTranspose-M*E).conjTranspose =
      M*(E*C*E.conjTranspose)*M.conjTranspose := by
  have hCQ : C*Q = 0 := by
    have h := congrArg Matrix.conjTranspose hQC
    simpa only [Matrix.conjTranspose_mul, Matrix.conjTranspose_conjTranspose,
      Matrix.conjTranspose_zero, hC.eq] using h
  simp only [Matrix.conjTranspose_sub, Matrix.conjTranspose_mul,
    Matrix.conjTranspose_conjTranspose, Matrix.sub_mul, Matrix.mul_sub, hQC,
    zero_sub, Matrix.neg_mul]
  simp only [Matrix.mul_assoc, hCQ, Matrix.mul_zero, neg_zero, zero_sub, neg_neg]

omit [DecidableEq κ] in
/-- Exact signal and noise covariance after compression to the signal coordinates. -/
theorem signal_noise_compressed_identity {C : Matrix ι ι ℝ} (hC : C.IsHermitian)
    (Q : Matrix ι ρ ℝ) (hQ : Q.conjTranspose*Q = 1) (hQC : Q.conjTranspose*C = 0)
    (A : Matrix ρ ρ ℝ) (E : Matrix κ ι ℝ) (L : Matrix ι κ ℝ) :
    let M := Q.conjTranspose*L
    let X := (1 : Matrix ρ ρ ℝ)-M*(E*Q)
    Q.conjTranspose*(((1 : Matrix ι ι ℝ)-L*E)*(Q*A*Q.conjTranspose+C)*
      ((1 : Matrix ι ι ℝ)-L*E).conjTranspose)*Q =
      X*A*X.conjTranspose+M*(E*C*E.conjTranspose)*M.conjTranspose := by
  let D := (1 : Matrix ι ι ℝ)-L*E
  let M := Q.conjTranspose*L
  let X := (1 : Matrix ρ ρ ℝ)-M*(E*Q)
  have hDQ : Q.conjTranspose*D*Q = X := by
    simp only [D, X, M, Matrix.mul_sub, Matrix.sub_mul, Matrix.mul_one, hQ, Matrix.mul_assoc]
  have hQD : Q.conjTranspose*D = Q.conjTranspose-M*E := by
    simp only [D, M, Matrix.mul_sub, Matrix.mul_one, Matrix.mul_assoc]
  have hsignal : Q.conjTranspose*(D*(Q*A*Q.conjTranspose)*D.conjTranspose)*Q =
      X*A*X.conjTranspose := by
    rw [← hDQ]
    simp only [Matrix.conjTranspose_mul, Matrix.conjTranspose_conjTranspose, Matrix.mul_assoc]
  have hnoise : Q.conjTranspose*(D*C*D.conjTranspose)*Q =
      M*(E*C*E.conjTranspose)*M.conjTranspose := by
    calc
      _ = (Q.conjTranspose*D)*C*(Q.conjTranspose*D).conjTranspose := by
        simp only [Matrix.conjTranspose_mul, Matrix.conjTranspose_conjTranspose, Matrix.mul_assoc]
      _ = _ := by rw [hQD]; exact orthogonal_noise_identity hC Q hQC M E
  change Q.conjTranspose*(D*(Q*A*Q.conjTranspose+C)*D.conjTranspose)*Q = _
  rw [Matrix.mul_add, Matrix.add_mul, Matrix.mul_add, Matrix.add_mul, hsignal, hnoise]

omit [DecidableEq κ] in
/-- Equation (7.8) for every predictor and every observation matrix.
The scalar Frobenius-square term is represented exactly by trace(X X^T). -/
theorem paper_equation_7_8 {C : Matrix ι ι ℝ} (hC : C.PosSemidef)
    (Q : Matrix ι ρ ℝ) (hQ : Q.conjTranspose*Q = 1) (hQC : Q.conjTranspose*C = 0)
    {A : Matrix ρ ρ ℝ} (hA : A.PosDef) {a : ℝ} (_ha : 0 < a)
    (hAa : (A-a • (1 : Matrix ρ ρ ℝ)).PosSemidef)
    (E : Matrix κ ι ℝ) (L : Matrix ι κ ℝ) :
    let M := Q.conjTranspose*L
    let X := (1 : Matrix ρ ρ ℝ)-M*(E*Q)
    a*(X*X.conjTranspose).trace+(M*(E*C*E.conjTranspose)*M.conjTranspose).trace ≤
      (((1 : Matrix ι ι ℝ)-L*E)*(Q*A*Q.conjTranspose+C)*
        ((1 : Matrix ι ι ℝ)-L*E).conjTranspose).trace := by
  let M := Q.conjTranspose*L
  let X := (1 : Matrix ρ ρ ℝ)-M*(E*Q)
  have hsignal : a*(X*X.conjTranspose).trace ≤ (X*A*X.conjTranspose).trace := by
    have h := (hAa.mul_mul_conjTranspose_same X).trace_nonneg
    simp only [Matrix.mul_sub, Matrix.sub_mul, Matrix.mul_smul, Matrix.smul_mul,
      Matrix.mul_one, Matrix.trace_sub, Matrix.trace_smul, smul_eq_mul] at h
    linarith
  have hK : (Q*A*Q.conjTranspose+C).PosSemidef :=
    (hA.posSemidef.mul_mul_conjTranspose_same Q).add hC
  have h := trace_orthonormal_compression_le
    (hK.mul_mul_conjTranspose_same ((1 : Matrix ι ι ℝ)-L*E)) Q hQ
  rw [signal_noise_compressed_identity hC.isHermitian Q hQ hQC A E L, Matrix.trace_add] at h
  dsimp only
  change (X*A*X.conjTranspose).trace + (M*(E*C*E.conjTranspose)*M.conjTranspose).trace ≤ _ at h
  exact (add_le_add hsignal (le_refl ((M*(E*C*E.conjTranspose)*M.conjTranspose).trace))).trans h

end SpectralComparison
