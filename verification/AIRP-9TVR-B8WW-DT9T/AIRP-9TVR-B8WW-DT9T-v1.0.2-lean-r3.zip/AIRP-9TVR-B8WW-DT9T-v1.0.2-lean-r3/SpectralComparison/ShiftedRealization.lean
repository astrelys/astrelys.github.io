import SpectralComparison.ShiftedSmallBall

noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

theorem shifted_exists_good_realization {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {t q : ℕ} (ht : 4 ≤ t) (hq : 2*q ≤ t)
    (G : Ω → Matrix (Fin (2*t)) (Fin (t+q)) ℝ)
    (hG : ∀ a : Fin (2*t) × Fin (t+q), HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin (2*t) × Fin (t+q) => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : Fin (2*t) × Fin (t+q), Measurable (fun ω => G ω a.1 a.2)) :
    ∃ ω, ‖(G ω).toEuclideanLin.toContinuousLinearMap‖ ≤ 10*Real.sqrt (t+q:ℕ) ∧
      (∀ x : EuclideanSpace ℝ (Fin (t+q)), ‖x‖=1 →
        Real.sqrt (t+q:ℕ)/10000000000 ≤ ‖(G ω).toEuclideanLin x‖) ∧
      ∀ J : Finset (Fin (2*t)), J.card=t →
        (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t:ℕ))) <
        ((G ω).submatrix (fun i : J => (i : Fin (2*t))) id *
        ((G ω).submatrix (fun i : J => (i : Fin (2*t))) id)ᴴ)⁻¹.trace := by
  obtain ⟨s,hs,hcard,hnet,hsmall⟩ := exists_shifted_small_ball_net (by omega : 2*(t+q) ≤ 3*t) G hG hind hm
  let A := {ω | 10*Real.sqrt (t+q:ℕ) < ‖(G ω).toEuclideanLin.toContinuousLinearMap‖}
  let B := {ω | ∃ v ∈ s, ‖(G ω).toEuclideanLin v‖^2 ≤ 4*(t+q:ℕ)/(10000000000:ℝ)^2}
  let C := {ω | ∃ J : Finset (Fin (2*t)), J.card=t ∧
        ((G ω).submatrix (fun i : J => (i : Fin (2*t))) id *
        ((G ω).submatrix (fun i : J => (i : Fin (2*t))) id)ᴴ)⁻¹.trace ≤
        (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t:ℕ)))}
  have hA : μ.real A ≤ Real.exp (-3*(t:ℝ)) :=
    (gaussian_opNorm_tail (by omega : 2*t ≤ 2*(t+q)) G hG hind hm).trans (Real.exp_le_exp.mpr (by simp only [Nat.cast_add]; linarith [Nat.cast_nonneg (α := ℝ) q]))
  have hB : μ.real B ≤ (1/16:ℝ)^t := hsmall
  have hC : μ.real C ≤ 2*Real.exp (-29*(t:ℕ)) := shifted_all_row_subsets_tail ht (by omega : 2*t ≤ 2*t) G hG hind hm
  have hbad : μ.real ((A ∪ B) ∪ C) < 1 := by
    calc
      _ ≤ μ.real (A ∪ B) + μ.real C := measureReal_union_le _ _
      _ ≤ μ.real A + μ.real B + μ.real C := by gcongr; exact measureReal_union_le _ _
      _ ≤ Real.exp (-3*(t:ℕ))+(1/16:ℝ)^t+2*Real.exp (-29*(t:ℕ)) := by linarith
      _ < 1 := gaussian_good_event_budget ht
  have hex : ∃ ω, ω ∉ (A ∪ B) ∪ C := by
    by_contra! h
    have he : (A ∪ B) ∪ C = Set.univ := Set.eq_univ_of_forall h
    simp [he] at hbad
  obtain ⟨ω,hω⟩ := hex
  have hupper : ‖(G ω).toEuclideanLin.toContinuousLinearMap‖ ≤ 10*Real.sqrt (t+q:ℕ) := by
    have : ω ∉ A := fun h => hω (Or.inl (Or.inl h))
    exact le_of_not_gt this
  have hlower : ∀ v ∈ s, 4*(t+q:ℕ)/(10000000000:ℝ)^2 < ‖(G ω).toEuclideanLin v‖^2 := by
    intro v hv
    exact lt_of_not_ge (fun h => hω (Or.inl (Or.inr ⟨v,hv,h⟩)))
  refine ⟨ω,hupper,shifted_net_lower_singular (G ω) s hnet hupper hlower,?_⟩
  intro J hJ
  exact lt_of_not_ge (fun h => hω (Or.inr ⟨J,hJ,h⟩))

/-- A deterministic matrix exists with the joint estimates; no random matrix or
probability-law assumption remains in this conclusion. -/
theorem exists_shifted_good_matrix {t q : ℕ} (ht : 4 ≤ t) (hq : 2*q ≤ t) :
    ∃ G : Matrix (Fin (2*t)) (Fin (t+q)) ℝ,
      ‖G.toEuclideanLin.toContinuousLinearMap‖ ≤ 10*Real.sqrt (t+q:ℕ) ∧
      (∀ x : EuclideanSpace ℝ (Fin (t+q)), ‖x‖=1 →
        Real.sqrt (t+q:ℕ)/10000000000 ≤ ‖G.toEuclideanLin x‖) ∧
      ∀ J : Finset (Fin (2*t)), J.card=t →
        (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t:ℕ))) <
        (G.submatrix (fun i : J => (i : Fin (2*t))) id *
        (G.submatrix (fun i : J => (i : Fin (2*t))) id)ᴴ)⁻¹.trace := by
  let μ : Measure (Fin (2*t) × Fin (t+q) → ℝ) := Measure.pi (fun _ => gaussianReal 0 1)
  let G := fun (ω : Fin (2*t) × Fin (t+q) → ℝ) => Matrix.of (fun i j => ω (i,j))
  have hX : HasLaw id μ μ := HasLaw.id
  have hG := gaussian_product_entry_hasLaw id hX
  have hi := gaussian_product_independent id hX
  have hm (a : Fin (2*t) × Fin (t+q)) : Measurable (fun ω => G ω a.1 a.2) := measurable_pi_apply a
  obtain ⟨ω,hω⟩ := shifted_exists_good_realization (μ := μ) ht hq G hG hi hm
  exact ⟨G ω,hω⟩

end SpectralComparison
