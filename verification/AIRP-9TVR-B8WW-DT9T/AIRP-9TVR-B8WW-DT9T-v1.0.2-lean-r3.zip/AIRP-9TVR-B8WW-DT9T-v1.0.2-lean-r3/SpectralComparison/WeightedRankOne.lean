import SpectralComparison.StrictConstants

noncomputable section
open Matrix Finset
namespace SpectralComparison
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Exact inverse of a rank-one perturbation, proved by multiplication. -/
theorem rank_one_resolvent (u : ι → ℝ) (h : 1-(∑ i,u i^2)≠0) :
    (1-Matrix.vecMulVec u u)⁻¹=
      1+(1-(∑ i,u i^2))⁻¹ • Matrix.vecMulVec u u := by
  let M := Matrix.vecMulVec u u
  let s := ∑ i,u i^2
  have hMM : M*M=s • M := by
    ext i j
    simp only [M,Matrix.mul_apply,Matrix.vecMulVec_apply,Matrix.smul_apply,smul_eq_mul]
    change (∑ l,u i*u l*(u l*u j))=(∑ l,u l^2)*(u i*u j)
    rw [Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro l _
    ring
  apply Matrix.inv_eq_left_inv
  change (1+(1-s)⁻¹ • M)*(1-M)=1
  simp only [Matrix.add_mul,Matrix.mul_sub,Matrix.one_mul,Matrix.mul_one,Matrix.smul_mul,hMM,smul_smul]
  have he : -1+(1-s)⁻¹-(1-s)⁻¹*s=0 := by dsimp [s]; field_simp; ring
  calc
    _ = 1+(-1+(1-s)⁻¹-(1-s)⁻¹*s) • M := by module
    _ = 1 := by rw [he,zero_smul,add_zero]

/-- Exact inverse trace after arbitrary diagonal row scaling. -/
theorem diagonal_rank_one_inverse_trace (u w : ι → ℝ) (hw : ∀ i,w i≠0) (h : 1-(∑ i,u i^2)≠0) :
    (Matrix.diagonal w*(1-Matrix.vecMulVec u u)*Matrix.diagonal w)⁻¹.trace=
      (∑ i,(w i)⁻¹^2)+(∑ i,(w i)⁻¹^2*u i^2)/(1-(∑ i,u i^2)) := by
  have hdiag : (Matrix.diagonal w)⁻¹=Matrix.diagonal (fun i => (w i)⁻¹) := by
    apply Matrix.inv_eq_left_inv
    rw [Matrix.diagonal_mul_diagonal]
    simp only [inv_mul_cancel₀ (hw _)]
    exact Matrix.diagonal_one
  rw [Matrix.mul_inv_rev,Matrix.mul_inv_rev,hdiag,rank_one_resolvent u h]
  simp only [Matrix.trace,Matrix.diag,Matrix.diagonal_mul,Matrix.mul_diagonal,
    Matrix.add_apply,Matrix.one_apply_eq,Matrix.smul_apply,Matrix.vecMulVec_apply,smul_eq_mul]
  rw [Finset.sum_div,← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  ring

/-- When the selected groups omit one group, the inverse cost has the manuscript's exact form. -/
theorem omitted_group_inverse_trace {g : Type*} [Fintype g] [DecidableEq g]
    (u r : g → ℝ) (hu : (∑ i,u i^2)=1) (hr : ∀ i,0<r i)
    (f : ι → g) (hf : Function.Injective f) (j : g)
    (himage : Finset.univ.image f=Finset.univ.erase j) (huj : u j≠0) :
    (Matrix.diagonal (fun i => (Real.sqrt (r (f i)))⁻¹)*
      (1-Matrix.vecMulVec (u ∘ f) (u ∘ f))*
        Matrix.diagonal (fun i => (Real.sqrt (r (f i)))⁻¹))⁻¹.trace=
      (∑ l,r l)-2*r j+(∑ l,r l*u l^2)/(u j^2) := by
  have hsum (v : g → ℝ) : (∑ i,v (f i))=(∑ l,v l)-v j := by
    rw [← Finset.sum_image hf.injOn,himage]
    exact eq_sub_of_add_eq (Finset.sum_erase_add (Finset.univ : Finset g) v (Finset.mem_univ j))
  have hs : (∑ i,(u ∘ f) i^2)=1-u j^2 := by
    change (∑ i,u (f i)^2)=1-u j^2
    rw [hsum (fun l => u l^2),hu]
  have hden : 1-(∑ i,(u ∘ f) i^2)=u j^2 := by rw [hs]; ring
  have hj : u j^2≠0 := pow_ne_zero _ huj
  rw [diagonal_rank_one_inverse_trace _ _ (fun i => inv_ne_zero (Real.sqrt_pos.mpr (hr (f i))).ne') (by rw [hden]; exact hj),hden]
  simp only [inv_inv,Real.sq_sqrt (hr _).le,Function.comp_def]
  rw [hsum r,hsum (fun l => r l*u l^2)]
  field_simp
  ring

end SpectralComparison
