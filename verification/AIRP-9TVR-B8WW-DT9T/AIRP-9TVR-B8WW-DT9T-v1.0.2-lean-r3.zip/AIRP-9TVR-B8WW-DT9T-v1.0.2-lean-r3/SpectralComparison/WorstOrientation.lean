import SpectralComparison.Nystrom

/-! Finite selection minima and the worst-orientation supremum.
Attainment of the outer supremum is proved in SpectralComparison.Attainment. -/
noncomputable section
namespace SpectralComparison
open Matrix Finset
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The finite set of literal residual trace values at cardinality k. -/
def selectionErrors (K : Matrix ι ι ℝ) (k : ℕ) : Set ℝ :=
  residualTrace K '' (↑((Finset.univ : Finset ι).powersetCard k) : Set (Finset ι))

/-- Optimal coordinate selection error; its infimum is attained when k ≤ n. -/
def bestError (K : Matrix ι ι ℝ) (k : ℕ) : ℝ := sInf (selectionErrors K k)

/-- All optimal errors obtained by varying the real orthogonal orientation. -/
def orbitErrors (eig : ι → ℝ) (k : ℕ) : Set ℝ :=
  (fun V : Matrix ι ι ℝ => bestError (V.transpose * Matrix.diagonal eig * V) k) ''
    {V | V.transpose * V = 1}

/-- Worst-orientation supremum, with the inner minimum proved attained below. -/
def worstError (eig : ι → ℝ) (k : ℕ) : ℝ := sSup (orbitErrors eig k)

/-- The paper's determinant-weighted spectral mean y_k. -/
def spectralMean (eig : ι → ℝ) (k : ℕ) : ℝ :=
  ((k : ℝ)+1) * (Finset.univ.val.map eig).esymm (k+1) / (Finset.univ.val.map eig).esymm k

theorem selectionErrors_finite (K : Matrix ι ι ℝ) (k : ℕ) : (selectionErrors K k).Finite := by
  exact ((Finset.univ : Finset ι).powersetCard k).finite_toSet.image _

theorem selectionErrors_nonempty (K : Matrix ι ι ℝ) {k : ℕ} (hk : k ≤ Fintype.card ι) :
    (selectionErrors K k).Nonempty := by
  exact (Finset.powersetCard_nonempty.mpr (by simpa using hk)).to_set.image _

theorem bestError_le (K : Matrix ι ι ℝ) {k : ℕ} {I : Finset ι} (hI : I.card = k) :
    bestError K k ≤ residualTrace K I := by
  exact csInf_le (selectionErrors_finite K k).bddBelow
    ⟨I, Finset.mem_powersetCard.mpr ⟨Finset.subset_univ _, hI⟩, rfl⟩

theorem le_bestError (K : Matrix ι ι ℝ) {k : ℕ} (hk : k ≤ Fintype.card ι) {a : ℝ}
    (ha : ∀ I : Finset ι, I.card = k → a ≤ residualTrace K I) : a ≤ bestError K k := by
  apply le_csInf (selectionErrors_nonempty K hk)
  rintro b ⟨I, hI, rfl⟩
  exact ha I (Finset.mem_powersetCard.mp hI).2

theorem bestError_attained (K : Matrix ι ι ℝ) {k : ℕ} (hk : k ≤ Fintype.card ι) :
    ∃ I : Finset ι, I.card = k ∧ bestError K k = residualTrace K I := by
  obtain ⟨I, hI, hmin⟩ := ((Finset.univ : Finset ι).powersetCard k).exists_min_image
    (residualTrace K) (Finset.powersetCard_nonempty.mpr (by simpa using hk))
  refine ⟨I, (Finset.mem_powersetCard.mp hI).2, le_antisymm (bestError_le K (Finset.mem_powersetCard.mp hI).2) ?_⟩
  exact le_bestError K hk (fun J hJ => hmin J (Finset.mem_powersetCard.mpr ⟨Finset.subset_univ _, hJ⟩))

theorem orbit_bestError_le_spectralMean (eig : ι → ℝ) (heig : ∀ i, 0 < eig i)
    (V : Matrix ι ι ℝ) (hV : V.transpose * V = 1) {k : ℕ} (hk : k < Fintype.card ι) :
    bestError (V.transpose * Matrix.diagonal eig * V) k ≤ spectralMean eig k := by
  obtain ⟨I, hI, hle⟩ := orbit_exists_residualTrace_le_spectral_ratio eig heig V hV hk
  exact (bestError_le _ (Finset.mem_powersetCard.mp hI).2).trans hle

theorem orbitErrors_nonempty (eig : ι → ℝ) (k : ℕ) : (orbitErrors eig k).Nonempty := by
  refine ⟨bestError (Matrix.diagonal eig) k, 1, ?_, ?_⟩ <;> simp

theorem orbitErrors_bddAbove (eig : ι → ℝ) (heig : ∀ i, 0 < eig i)
    {k : ℕ} (hk : k < Fintype.card ι) : BddAbove (orbitErrors eig k) := by
  refine ⟨spectralMean eig k, ?_⟩
  rintro b ⟨V, hV, rfl⟩
  exact orbit_bestError_le_spectralMean eig heig V hV hk

/-- Unconditional x_k ≤ y_k for the supremum formulation of the actual matrix objective. -/
theorem worstError_le_spectralMean (eig : ι → ℝ) (heig : ∀ i, 0 < eig i)
    {k : ℕ} (hk : k < Fintype.card ι) : worstError eig k ≤ spectralMean eig k := by
  apply csSup_le (orbitErrors_nonempty eig k)
  rintro b ⟨V, hV, rfl⟩
  exact orbit_bestError_le_spectralMean eig heig V hV hk

theorem orbit_bestError_le_worstError (eig : ι → ℝ) (heig : ∀ i, 0 < eig i)
    (V : Matrix ι ι ℝ) (hV : V.transpose * V = 1) {k : ℕ} (hk : k < Fintype.card ι) :
    bestError (V.transpose * Matrix.diagonal eig * V) k ≤ worstError eig k := by
  exact le_csSup (orbitErrors_bddAbove eig heig hk) ⟨V, hV, rfl⟩

end SpectralComparison
