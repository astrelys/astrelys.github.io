import SpectralComparison.DimensionRestriction

/-! Deleting small capped entries: exact retained cardinality, quotient mass and matrix objective. -/
noncomputable section
open Finset
namespace SpectralComparison

theorem esymm_tail_bound_of_card_le (head tail : Multiset ℝ)
    (hh : ∀ z∈head,0≤z) (ht : ∀ z∈tail,0≤z) {k : ℕ} (hk : head.card≤k) :
    (head+tail).esymm (k+1)≤tail.sum*(head+tail).esymm k := by
  induction tail using Multiset.induction_on with
  | empty => simp only [Multiset.add_zero,Multiset.sum_zero,zero_mul]; rw [Multiset.esymm_of_card_lt (by omega)]
  | @cons z tail ih =>
    have hz : 0≤z := ht z (by simp)
    have htt : ∀ w∈tail,0≤w := fun w hw => ht w (by simp [hw])
    have hall : ∀ w∈head+tail,0≤w := by intro w hw; rcases Multiset.mem_add.mp hw with hw|hw; exact hh w hw; exact htt w hw
    have hs : 0≤tail.sum := Multiset.sum_nonneg htt
    have hprev := ih htt
    have hmono := esymm_le_cons (head+tail) hall hz k
    rw [Multiset.add_cons,esymm_cons,Multiset.sum_cons]
    calc
      _ ≤ (z+tail.sum)*(head+tail).esymm k := by nlinarith
      _ ≤ (z+tail.sum)*(z ::ₘ (head+tail)).esymm k := mul_le_mul_of_nonneg_left hmono (add_nonneg hz hs)

theorem symmetricQuotient_add_loss (head tail : Multiset ℝ)
    (hh : ∀ z∈head,0<z) (ht : ∀ z∈tail,0<z) {k : ℕ} (hk : k≤head.card) :
    symmetricQuotient (head+tail) k≤symmetricQuotient head k+tail.sum := by
  induction tail using Multiset.induction_on with
  | empty => simp
  | @cons z tail ih =>
    have hz : 0<z := ht z (by simp)
    have htt : ∀ w∈tail,0<w := fun w hw => ht w (by simp [hw])
    have hall : ∀ w∈head+tail,0<w := by intro w hw; rcases Multiset.mem_add.mp hw with hw|hw; exact hh w hw; exact htt w hw
    rw [Multiset.add_cons,Multiset.sum_cons]
    have hstep := quotient_delete_loss (head+tail) hall (by simp only [Multiset.card_add]; omega : k≤(head+tail).card) hz
    have hi := ih htt
    linarith

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

theorem spectrum_partition_multiset (a : ι → ℝ) (S : Finset ι) :
    S.val.map a+(Finset.univ \ S).val.map a=Finset.univ.val.map a := by
  rw [← Multiset.map_add,Finset.sdiff_val,add_tsub_cancel_of_le (Finset.val_le_iff.mpr (Finset.subset_univ S))]

theorem restricted_spectrum_multiset (a : ι → ℝ) (S : Finset ι) :
    (Finset.univ : Finset S).val.map (fun i : S => a i)=S.val.map a := by
  simpa using Finset.univ_val_map_subtype_restrict a (fun i => i∈S)

/-- The scalar deletion assertion, applicable to the actual capped spectrum. -/
theorem retained_quotient_bound (a : ι → ℝ) (ha : ∀ i,0<a i) {k : ℕ}
    (hkn : k<Fintype.card ι) {F δ : ℝ} (hF : 0<F) (hδ : 0<δ)
    (hsmall : (Fintype.card ι:ℝ)*δ≤F/4)
    (hcap : F/2≤symmetricQuotient (Finset.univ.val.map a) k) :
    let S := Finset.univ.filter (fun i => δ≤a i)
    k<S.card ∧ F/4≤symmetricQuotient (S.val.map a) k := by
  let S := Finset.univ.filter (fun i => δ≤a i)
  let O := Finset.univ \ S
  have hh : ∀ z∈S.val.map a,0<z := by intro z hz; obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz; exact ha i
  have ht : ∀ z∈O.val.map a,0<z := by intro z hz; obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz; exact ha i
  have hall : ∀ z∈Finset.univ.val.map a,0<z := by intro z hz; obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz; exact ha i
  have he : S.val.map a+O.val.map a=Finset.univ.val.map a := spectrum_partition_multiset a S
  have hout : (O.val.map a).sum≤F/4 := by
    have hs : (∑ i∈O,a i)≤∑ _i∈O,δ := by
      apply Finset.sum_le_sum
      intro i hi
      have hn : ¬δ≤a i := by simpa only [S,Finset.mem_filter,Finset.mem_univ,true_and] using (Finset.mem_sdiff.mp hi).2
      exact (lt_of_not_ge hn).le
    have hc : (O.card:ℝ)≤Fintype.card ι := by exact_mod_cast O.card_le_univ
    calc
      (O.val.map a).sum=∑ i∈O,a i := rfl
      _ ≤ (O.card:ℝ)*δ := by simpa only [Finset.sum_const,nsmul_eq_mul] using hs
      _ ≤ (Fintype.card ι:ℝ)*δ := mul_le_mul_of_nonneg_right hc hδ.le
      _ ≤ F/4 := hsmall
  have hcard : k<S.card := by
    by_contra hn
    have hs := esymm_tail_bound_of_card_le (S.val.map a) (O.val.map a)
      (fun z hz => (hh z hz).le) (fun z hz => (ht z hz).le) (by simpa using le_of_not_gt hn)
    rw [he] at hs
    have hd := esymm_pos (Finset.univ.val.map a) hall k (by simpa using hkn.le)
    have hq : symmetricQuotient (Finset.univ.val.map a) k≤(O.val.map a).sum := (div_le_iff₀ hd).mpr hs
    linarith
  refine ⟨hcard,?_⟩
  have hl := symmetricQuotient_add_loss (S.val.map a) (O.val.map a) hh ht (by simpa using hcard.le)
  rw [he] at hl
  linarith

/-- All of (C.2): the actual retained sublist, original threshold and both objective bounds. -/
theorem paper_deletion {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i) (hk : 1≤k) (hkn : k<n) :
    let F := symmetricQuotient (Finset.univ.val.map a) k
    let T := spectralMean a k
    let δ := F/(4*n)
    let c := fun i => min (a i) T
    let S := Finset.univ.filter (fun i => δ≤c i)
    k<S.card ∧ S.card≤n ∧ (∀ i : S,δ≤c i ∧ c i≤T) ∧
      spectralMean a k/4≤spectralMean (fun i : S => c i) k ∧
      worstError (fun i : S => c i) k≤worstError a k := by
  let F := symmetricQuotient (Finset.univ.val.map a) k
  let T := spectralMean a k
  let δ := F/(4*n)
  let c := fun i => min (a i) T
  let S := Finset.univ.filter (fun i => δ≤c i)
  have hF : 0<F := symmetricQuotient_pos _ (by intro z hz; obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz; exact ha i) (by simpa using hkn)
  have hn : (0:ℝ)<n := by exact_mod_cast (by omega : 0<n)
  have hT : 0<T := by dsimp [T]; rw [spectralMean_eq_quotient]; exact mul_pos (by positivity) hF
  have hc : ∀ i,0<c i := fun i => lt_min (ha i) hT
  have hd : 0<δ := by dsimp [δ]; positivity
  have hsmall : (n:ℝ)*δ≤F/4 := by dsimp [δ]; apply le_of_eq; field_simp
  have hcap := spectralQuotient_capped_half a ha hk (by simpa using hkn)
  have hb := retained_quotient_bound c hc (by simpa using hkn) hF hd (by simpa using hsmall) hcap
  change k<S.card ∧ S.card≤n ∧ (∀ i : S,δ≤c i ∧ c i≤T) ∧
    spectralMean a k/4≤spectralMean (fun i : S => c i) k ∧ worstError (fun i : S => c i) k≤worstError a k
  refine ⟨hb.1,by simpa only [Fintype.card_fin] using S.card_le_univ,?_,?_,?_⟩
  · intro i; exact ⟨(Finset.mem_filter.mp i.property).2,min_le_right _ _⟩
  · rw [spectralMean_eq_quotient,spectralMean_eq_quotient,restricted_spectrum_multiset]
    have h := mul_le_mul_of_nonneg_left hb.2 (by positivity : 0≤(k:ℝ)+1)
    simpa only [mul_div_assoc] using h
  · exact (worstError_restrict c hc S hb.1).trans (worstError_mono c a hc ha (fun _ => min_le_left _ _) (by simpa using hkn))

end SpectralComparison
