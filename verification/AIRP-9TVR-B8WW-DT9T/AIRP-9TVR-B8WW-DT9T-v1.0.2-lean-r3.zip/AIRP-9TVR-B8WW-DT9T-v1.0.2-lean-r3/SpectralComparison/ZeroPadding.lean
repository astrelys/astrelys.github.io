import SpectralComparison.Replication

/-! Zero padding preserves every nonsingular principal-block guarantee. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Appending zero rows preserves orthonormal columns. -/
theorem zero_padded_frame_orthonormal {n r p : Type*} [Fintype n] [Fintype r]
    [Fintype p] [DecidableEq p] (V : Matrix n p ℝ) (hV : Vᴴ*V=1) :
    (Matrix.fromRows V (0 : Matrix r p ℝ))ᴴ * Matrix.fromRows V (0 : Matrix r p ℝ)=1 := by
  simpa only [Matrix.conjTranspose_fromRows_eq_fromCols_conjTranspose,
    Matrix.conjTranspose_zero,Matrix.fromCols_mul_fromRows,Matrix.zero_mul,add_zero] using hV

/-- A nonsingular principal block of a zero-padded Gram uses only original rows. -/
theorem zero_padded_block_indices {n r p : Type*} [Fintype p] [DecidableEq n] [DecidableEq r]
    (V : Matrix n p ℝ) (J : Finset (n ⊕ r))
    (hu : IsUnit (((Matrix.fromRows V (0 : Matrix r p ℝ))*(Matrix.fromRows V (0 : Matrix r p ℝ))ᴴ).submatrix
      (fun i : J => (i : n ⊕ r)) (fun i : J => (i : n ⊕ r)))) :
    ∀ i : J, ∃ k : n, (i : n ⊕ r)=Sum.inl k := by
  classical
  have hi := Matrix.linearIndependent_rows_of_isUnit hu
  intro i
  cases he : (i : n ⊕ r) with
  | inl k => exact ⟨k,rfl⟩
  | inr k =>
    exfalso
    apply hi.ne_zero i
    ext j
    simp [Matrix.row,he]

/-- Principal inverse-trace bounds survive arbitrary zero-row padding. -/
theorem zero_padded_principal_inverse_trace {n r p : Type*} [Fintype n] [DecidableEq n] [DecidableEq r]
    [Fintype p] (V : Matrix n p ℝ) {t : ℕ} {L : ℝ}
    (hblocks : ∀ I : Finset n, I.card=t → IsUnit ((V*Vᴴ).submatrix (fun i : I => (i:n)) (fun i : I => (i:n))) →
      L ≤ ((V*Vᴴ).submatrix (fun i : I => (i:n)) (fun i : I => (i:n)))⁻¹.trace)
    (J : Finset (n ⊕ r)) (hJ : J.card=t)
    (hu : IsUnit (((Matrix.fromRows V (0 : Matrix r p ℝ))*(Matrix.fromRows V (0 : Matrix r p ℝ))ᴴ).submatrix
      (fun i : J => (i : n ⊕ r)) (fun i : J => (i : n ⊕ r)))) :
    L ≤ (((Matrix.fromRows V (0 : Matrix r p ℝ))*(Matrix.fromRows V (0 : Matrix r p ℝ))ᴴ).submatrix
      (fun i : J => (i : n ⊕ r)) (fun i : J => (i : n ⊕ r)))⁻¹.trace := by
  classical
  have hex := zero_padded_block_indices V J hu
  let f : J → n := fun i => Classical.choose (hex i)
  have hfval (i : J) : (i : n ⊕ r)=Sum.inl (f i) := Classical.choose_spec (hex i)
  have hf : Function.Injective f := by
    intro a b hab
    apply Subtype.ext
    rw [hfval a,hfval b,hab]
  have he : (((Matrix.fromRows V (0 : Matrix r p ℝ))*(Matrix.fromRows V (0 : Matrix r p ℝ))ᴴ).submatrix
      (fun i : J => (i : n ⊕ r)) (fun i : J => (i : n ⊕ r))) = (V*Vᴴ).submatrix f f := by
    ext a b
    simp [Matrix.mul_apply,hfval]
  rw [he] at hu ⊢
  exact principal_inverse_trace_embedding (V*Vᴴ) hblocks f hf (by simpa using hJ) hu

end SpectralComparison
