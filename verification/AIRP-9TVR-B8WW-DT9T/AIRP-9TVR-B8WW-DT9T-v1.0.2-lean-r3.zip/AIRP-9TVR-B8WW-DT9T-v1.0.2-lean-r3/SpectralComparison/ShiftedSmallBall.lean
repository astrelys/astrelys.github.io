import SpectralComparison.ShiftedGaussian

noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

theorem shifted_small_ball_numeric {k p : ℕ} (hp : 2*p ≤ 3*k) :
    ((41:ℝ)*10000000000)^p * Real.exp (p:ℝ) * (2/10000000000:ℝ)^(2*k) ≤ (1/16:ℝ)^k := by
  have he : Real.exp (p:ℝ) ≤ (3:ℝ)^p := by
    rw [show (p:ℝ) = (p:ℝ)*1 by ring, Real.exp_nat_mul]
    exact pow_le_pow_left₀ (by positivity) Real.exp_one_lt_three.le p
  have hfirst : ((41:ℝ)*10000000000)^p * Real.exp (p:ℝ) * (2/10000000000:ℝ)^(2*k) ≤
      (123*10000000000:ℝ)^p * (2/10000000000:ℝ)^(2*k) := by
    calc
      _ ≤ ((41:ℝ)*10000000000)^p * (3:ℝ)^p * (2/10000000000:ℝ)^(2*k) := by gcongr
      _ = _ := by rw [← mul_pow]; norm_num
  apply hfirst.trans
  apply le_of_pow_le_pow_left₀ (n := 2) (by norm_num) (by positivity)
  calc
    ((123*10000000000:ℝ)^p * (2/10000000000:ℝ)^(2*k))^2 =
      (123*10000000000:ℝ)^(2*p)*(2/10000000000:ℝ)^(4*k) := by
        simp only [mul_pow, ← pow_mul, show p*2=2*p by omega, show 2*k*2=4*k by omega]
    _ ≤ (123*10000000000:ℝ)^(3*k)*(2/10000000000:ℝ)^(4*k) := by
      exact mul_le_mul_of_nonneg_right (pow_le_pow_right₀ (by norm_num) hp) (by positivity)
    _ = ((123*10000000000:ℝ)^3*(2/10000000000:ℝ)^4)^k := by simp only [mul_pow, pow_mul]
    _ ≤ ((1/16:ℝ)^2)^k := pow_le_pow_left₀ (by positivity) (by norm_num) k
    _ = ((1/16:ℝ)^k)^2 := by simp only [← pow_mul, Nat.mul_comm]

/-- A concrete fine net for which the small-ball union event has probability at most 16^-p. -/
theorem exists_shifted_small_ball_net {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {k p : ℕ} (hN : 2*p ≤ 3*k)
    (G : Ω → Matrix (Fin (2*k)) (Fin p) ℝ)
    (hG : ∀ a : Fin (2*k) × Fin p, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin (2*k) × Fin p => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : Fin (2*k) × Fin p, Measurable (fun ω => G ω a.1 a.2)) :
    ∃ s : Finset (EuclideanSpace ℝ (Fin p)), (∀ v ∈ s, ‖v‖=1) ∧
      (s.card:ℝ) ≤ (41*10000000000:ℝ)^p ∧
      (∀ x : EuclideanSpace ℝ (Fin p), ‖x‖=1 → ∃ v ∈ s, ‖x-v‖ ≤ 1/(20*10000000000:ℝ)) ∧
      μ.real {ω | ∃ v ∈ s, ‖(G ω).toEuclideanLin v‖^2 ≤ 4*(p:ℝ)/(10000000000:ℝ)^2} ≤
        (1/16:ℝ)^k := by
  obtain ⟨s,hs,hcard,hnet⟩ := exists_sphere_net_card_le (E := EuclideanSpace ℝ (Fin p))
    (η := 1/(20*10000000000:ℝ)) (by norm_num)
  have hc : (s.card:ℝ) ≤ (41*10000000000:ℝ)^p := by
    apply hcard.trans
    simp only [finrank_euclideanSpace, Fintype.card_fin]
    exact pow_le_pow_left₀ (by norm_num) (by norm_num) p
  refine ⟨s,hs,hc,hnet,?_⟩
  have h := finite_union_probability_bound s
    (fun v => {ω | ‖(G ω).toEuclideanLin v‖^2 ≤ 4*(p:ℝ)/(10000000000:ℝ)^2})
    (fun v hv => gaussian_vector_small_ball G hG hind hm v (hs v hv) (by norm_num))
  apply h.trans
  calc
    _ ≤ (41*10000000000:ℝ)^p * (Real.exp (p:ℝ)*(2/10000000000:ℝ)^(2*k)) := by gcongr
    _ = (41*10000000000:ℝ)^p * Real.exp (p:ℝ)*(2/10000000000:ℝ)^(2*k) := by ring
    _ ≤ _ := shifted_small_ball_numeric hN

/-- The fine-net complement and the upper operator-norm event imply a lower singular bound. -/
theorem shifted_net_lower_singular {N p : ℕ} (G : Matrix (Fin N) (Fin p) ℝ)
    (s : Finset (EuclideanSpace ℝ (Fin p)))
    (hnet : ∀ x : EuclideanSpace ℝ (Fin p), ‖x‖=1 → ∃ v ∈ s, ‖x-v‖ ≤ 1/(20*10000000000:ℝ))
    (hupper : ‖G.toEuclideanLin.toContinuousLinearMap‖ ≤ 10*Real.sqrt p)
    (hlower : ∀ v ∈ s, 4*(p:ℝ)/(10000000000:ℝ)^2 < ‖G.toEuclideanLin v‖^2) :
    ∀ x : EuclideanSpace ℝ (Fin p), ‖x‖=1 → Real.sqrt p/10000000000 ≤ ‖G.toEuclideanLin x‖ := by
  have hb (v) (hv : v ∈ s) : 2*Real.sqrt (p:ℝ)/10000000000 ≤ ‖G.toEuclideanLin v‖ := by
    nlinarith [hlower v hv, Real.sq_sqrt (Nat.cast_nonneg p), norm_nonneg (G.toEuclideanLin v), Real.sqrt_nonneg (p:ℝ)]
  have h := norm_lower_of_sphere_net G.toEuclideanLin.toContinuousLinearMap s (by norm_num) hupper hnet hb
  intro x hx
  have hh := h x hx
  change _ ≤ ‖G.toEuclideanLin x‖ at hh
  nlinarith [Real.sqrt_nonneg (p:ℝ)]

end SpectralComparison
