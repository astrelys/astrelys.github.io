import SpectralComparison.DiffuseConstruction

/-! Complete diffuse-tail proposition, without a construction hypothesis. -/
noncomputable section
namespace SpectralComparison

/-- Paper proposition (7.1), including both tail-mass branches and the diagonal lower bound. -/
theorem paper_proposition_diffuse {n k q : ℕ} (eig : Fin n → ℝ)
    (heig : ∀ i,0<eig i) (horder : Antitone eig) (hk : 1≤k) (hkn : k<n) (hq : 4*q≤k) :
    let s := ∑ i∈Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n),eig i
    let a := eig ⟨k-q-1,by omega⟩
    let V := (k:ℝ)*s/(64000000000000000000000000000*((q:ℝ)+Real.sqrt k)*H (8*k))
    max s (a*V/(a+V))≤worstError eig k := by
  by_cases hm : (∑ i∈Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n),eig i)/2≤
      ∑ j : Fin (min (n-k) (8*k)),eig ⟨k+j.val,by have := j.isLt; omega⟩
  · exact diffuse_bound_of_prefix_mass eig heig horder hk hkn hq hm
  · exact max_le ((le_max_left _ _).trans (paper_proposition_prefix (q:=q) eig heig horder hk hkn (by omega)))
      (diffuse_bound_of_small_prefix eig heig horder hk hkn hq (lt_of_not_ge hm))

end SpectralComparison
