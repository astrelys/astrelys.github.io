import SpectralComparison.HarmonicTheorem

noncomputable section
open Finset
namespace SpectralComparison
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Entries in the unit interval with total mass at least r dominate binomial coefficients through r. -/
theorem unit_esymm_lower (β : ι → ℝ) (hβ : ∀ i,0≤β i) (hβ1 : ∀ i,β i≤1)
    {r : ℕ} (hsum : (r:ℝ)≤∑ i,β i) {j : ℕ} (hj : j≤r) :
    (r.choose j:ℝ)≤(Finset.univ.val.map β).esymm j := by
  induction j with
  | zero => simp
  | succ j ih =>
    have hjr : j≤r := by omega
    have hprev := ih hjr
    have hstep : ((r-j:ℕ):ℝ)*(Finset.univ.val.map β).esymm j≤
        ((j:ℝ)+1)*(Finset.univ.val.map β).esymm (j+1) := by
      rw [← esymm_completion_sum,Finset.esymm_map_val,Finset.mul_sum]
      apply Finset.sum_le_sum
      intro I hI
      have hcard : I.card=j := (Finset.mem_powersetCard.mp hI).2
      have hsel : (∑ i∈I,β i)≤(j:ℝ) := by
        calc
          _ ≤∑ _i∈I,(1:ℝ) := Finset.sum_le_sum (fun i _ => hβ1 i)
          _ =_ := by simp [hcard]
      have hsplit := Finset.sum_sdiff (f:=β) (Finset.subset_univ I)
      have ht : ((r-j:ℕ):ℝ)≤∑ i∈Finset.univ\I,β i := by rw [Nat.cast_sub hjr]; linarith
      have hp := Finset.prod_nonneg (fun i (_ : i∈I) => hβ i)
      nlinarith [mul_le_mul_of_nonneg_left ht hp]
    have hchoose : ((r.choose (j+1):ℕ):ℝ)*((j:ℝ)+1)=(r.choose j:ℝ)*((r-j:ℕ):ℝ) := by
      exact_mod_cast Nat.choose_succ_right_eq r j
    have hc := mul_le_mul_of_nonneg_left hprev (Nat.cast_nonneg (α:=ℝ) (r-j))
    have hpos : 0<(j:ℝ)+1 := by positivity
    nlinarith

/-- In particular the r-th elementary coefficient is at least one. -/
theorem unit_esymm_ge_one (β : ι → ℝ) (hβ : ∀ i,0≤β i) (hβ1 : ∀ i,β i≤1)
    {r : ℕ} (hsum : (r:ℝ)≤∑ i,β i) : 1≤(Finset.univ.val.map β).esymm r := by
  simpa using unit_esymm_lower β hβ hβ1 hsum (le_refl r)

/-- The unit-cube coefficient bound with the literal exponential constant. -/
theorem unit_esymm_upper (β : ι → ℝ) (hβ : ∀ i,0≤β i) (hβ1 : ∀ i,β i≤1) (j : ℕ) :
    (Finset.univ.val.map β).esymm j≤(2:ℝ)^Fintype.card ι := by
  rw [Finset.esymm_map_val]
  calc
    _ ≤∑ _I∈(Finset.univ : Finset ι).powersetCard j,(1:ℝ) := by
      apply Finset.sum_le_sum
      intro I _
      simpa using Finset.prod_le_prod₀ (fun i (_ : i∈I) => hβ i) (fun i (_ : i∈I) => hβ1 i)
    _ = ((Finset.univ : Finset ι).powersetCard j).card := by simp
    _ ≤ ((Finset.univ : Finset ι).powerset).card := by
      exact_mod_cast Finset.card_le_card (show (Finset.univ : Finset ι).powersetCard j⊆Finset.univ.powerset from fun I hI => Finset.mem_powerset.mpr (Finset.mem_powersetCard.mp hI).1)
    _ = (2:ℝ)^Fintype.card ι := by simp

/-- Erased spectra counted by indices retain repeated equal entries correctly. -/
theorem indexed_esymm_count (β : ι → ℝ) (j : ℕ) :
    (∑ i,β i*((Finset.univ.erase i).val.map β).esymm j)=
      ((j:ℝ)+1)*(Finset.univ.val.map β).esymm (j+1) := by
  have h := esymm_weighted_count (Finset.univ.val.map β) j
  have he (i : ι) : (Finset.univ.val.map β).erase (β i)=(Finset.univ.erase i).val.map β := by
    have hh := spectrum_update_multiset β i (β i)
    rw [Function.update_eq_self] at hh
    rw [hh,Multiset.erase_cons_head]
  simpa only [Multiset.map_map,Function.comp_def,he,Finset.sum_map_val] using h

/-- Exact variance identity behind the water-level stability estimate. -/
theorem esymm_variance_identity (β : ι → ℝ) (j : ℕ) :
    (∑ i,β i*(1-β i)*((Finset.univ.erase i).val.map β).esymm j)=
      ((j:ℝ)+2)*(Finset.univ.val.map β).esymm (j+2)+
        ((j:ℝ)+1-∑ i,β i)*(Finset.univ.val.map β).esymm (j+1) := by
  have hrec (i : ι) : (Finset.univ.val.map β).esymm (j+1)=
      ((Finset.univ.erase i).val.map β).esymm (j+1)+β i*((Finset.univ.erase i).val.map β).esymm j := by
    have hh := spectrum_update_multiset β i (β i)
    rw [Function.update_eq_self] at hh
    rw [hh,esymm_cons]
  have hs : (∑ i,β i)*(Finset.univ.val.map β).esymm (j+1)=
      (∑ i,β i*((Finset.univ.erase i).val.map β).esymm (j+1))+
        ∑ i,β i^2*((Finset.univ.erase i).val.map β).esymm j := by
    rw [Finset.sum_mul,← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro i _
    rw [hrec i]
    ring
  have hc := indexed_esymm_count β j
  have hc' := indexed_esymm_count β (j+1)
  have hv : (∑ i,β i*(1-β i)*((Finset.univ.erase i).val.map β).esymm j)=
      (∑ i,β i*((Finset.univ.erase i).val.map β).esymm j)-
        ∑ i,β i^2*((Finset.univ.erase i).val.map β).esymm j := by
    rw [← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro i _
    ring
  rw [hv]
  push_cast at hc'
  nlinarith

end SpectralComparison
