import SpectralComparison.SpectralDeletion
import Mathlib.Analysis.SpecialFunctions.Log.Base

/-! Literal dyadic rounding, its original floor-log formula and exact level count. -/
noncomputable section
open Finset
namespace SpectralComparison

def dyadicRound (δ x : ℝ) : ℝ := δ*(2:ℝ)^⌊Real.logb 2 (x/δ)⌋₊

theorem dyadic_log_nonneg {δ x : ℝ} (hδ : 0<δ) (hx : δ≤x) : 0≤Real.logb 2 (x/δ) := by
  have h : Real.logb 2 1≤Real.logb 2 (x/δ) := Real.logb_le_logb_of_le (by norm_num) (by norm_num)
    ((le_div_iff₀ hδ).mpr (by simpa using hx))
  simpa using h

theorem dyadicRound_original {δ x : ℝ} (hδ : 0<δ) (hx : δ≤x) :
    dyadicRound δ x=δ*(2:ℝ)^(⌊Real.logb 2 (x/δ)⌋ : ℤ) := by
  rw [← Int.natCast_floor_eq_floor (dyadic_log_nonneg hδ hx),zpow_natCast]
  rfl

theorem dyadicRound_bounds {δ x : ℝ} (hδ : 0<δ) (hx : δ≤x) :
    0<dyadicRound δ x ∧ x/2≤dyadicRound δ x ∧ dyadicRound δ x≤x := by
  have hr : 0<x/δ := div_pos (hδ.trans_le hx) hδ
  have hl := Nat.floor_le (dyadic_log_nonneg hδ hx)
  have hu := Nat.lt_floor_add_one (Real.logb 2 (x/δ))
  have hlo : (2:ℝ)^⌊Real.logb 2 (x/δ)⌋₊≤x/δ := by
    rw [← Real.rpow_natCast]
    exact (Real.le_logb_iff_rpow_le (by norm_num : (1:ℝ)<2) hr).mp hl
  have hhi : x/δ<(2:ℝ)^(⌊Real.logb 2 (x/δ)⌋₊+1) := by
    rw [← Real.rpow_natCast]
    apply (Real.logb_lt_iff_lt_rpow (by norm_num : (1:ℝ)<2) hr).mp
    simpa only [Nat.cast_add,Nat.cast_one] using hu
  rw [pow_succ] at hhi
  have ha := (le_div_iff₀ hδ).mp hlo
  have hb := (div_lt_iff₀ hδ).mp hhi
  dsimp [dyadicRound]
  exact ⟨by positivity,by nlinarith,by nlinarith⟩

theorem dyadicRound_levels {ι : Type*} [Fintype ι] [DecidableEq ι]
    (a : ι → ℝ) {δ R : ℝ} (hδ : 0<δ) (hlo : ∀ i,δ≤a i) (hhi : ∀ i,a i/δ≤R) :
    (Finset.univ.image (fun i => dyadicRound δ (a i))).card≤1+⌊Real.logb 2 R⌋₊ := by
  classical
  let N := ⌊Real.logb 2 R⌋₊
  have hin : Finset.univ.image (fun i => dyadicRound δ (a i))⊆
      (Finset.range (N+1)).image (fun j : ℕ => δ*(2:ℝ)^j) := by
    intro z hz
    obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp hz
    refine Finset.mem_image.mpr ⟨⌊Real.logb 2 (a i/δ)⌋₊,?_,rfl⟩
    apply Finset.mem_range.mpr
    have hlog := Real.logb_le_logb_of_le (by norm_num : (1:ℝ)<2)
      (div_pos (hδ.trans_le (hlo i)) hδ) (hhi i)
    have hfloor := Nat.floor_mono hlog
    omega
  have h := (Finset.card_le_card hin).trans (Finset.card_image_le)
  simpa only [Finset.card_range,N,Nat.add_comm] using h

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

theorem worstError_pos (a : ι → ℝ) (ha : ∀ i,0<a i) {k : ℕ} (hk : k<Fintype.card ι) :
    0<worstError a k := by
  obtain ⟨I,hI,he⟩ := bestError_attained (Matrix.diagonal a) hk.le
  have hc : (Finset.univ \ I).Nonempty := by
    apply Finset.card_pos.mp
    simp only [Finset.card_sdiff,Finset.inter_univ,Finset.card_univ,hI]
    omega
  have hp := Finset.sum_pos (fun i (_ : i∈Finset.univ \ I) => ha i) hc
  rw [← diagonal_residualTrace a ha I,← he] at hp
  have hor := orbit_bestError_le_worstError a ha (1 : Matrix ι ι ℝ) (by simp) hk
  simp only [Matrix.transpose_one,Matrix.one_mul,Matrix.mul_one] at hor
  exact hp.trans_le hor

/-- Rounding alone loses at most a factor of two in y/x. -/
theorem dyadic_comparison (a : ι → ℝ) {δ : ℝ} (hδ : 0<δ) (ha : ∀ i,δ≤a i)
    {k : ℕ} (hk : 1≤k) (hkn : k<Fintype.card ι) :
    spectralMean a k/2≤spectralMean (fun i => dyadicRound δ (a i)) k ∧
    worstError (fun i => dyadicRound δ (a i)) k≤worstError a k := by
  have hp : ∀ i,0<a i := fun i => hδ.trans_le (ha i)
  have hv : ∀ i,0<dyadicRound δ (a i) := fun i => (dyadicRound_bounds hδ (ha i)).1
  constructor
  · have h := spectralMean_mono (fun i => (1/2:ℝ)*a i) (fun i => dyadicRound δ (a i))
      (fun i => mul_pos (by norm_num) (hp i)) hv (fun i => by simpa only [one_div,mul_comm,← div_eq_mul_inv] using (dyadicRound_bounds hδ (ha i)).2.1) hk hkn
    rw [spectralMean_smul a k (by norm_num : (0:ℝ)<1/2)] at h
    linarith
  · exact worstError_mono _ _ hv hp (fun i => (dyadicRound_bounds hδ (ha i)).2.2) hkn

end SpectralComparison
