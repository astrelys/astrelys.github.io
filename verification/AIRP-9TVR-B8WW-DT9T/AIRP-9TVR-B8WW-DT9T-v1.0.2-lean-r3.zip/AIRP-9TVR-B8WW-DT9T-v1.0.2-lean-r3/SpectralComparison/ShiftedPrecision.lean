import SpectralComparison.ShiftedProjection

noncomputable section
open Matrix
namespace SpectralComparison

theorem sharp_prescribed_precision_bound {n : Type*} [Fintype n] [DecidableEq n]
    (U : Matrix n n ℝ) (hU : Uᴴ*U=1) (eig : n → ℝ) (heig : ∀ i, 0<eig i)
    (I : Finset n) {a b : ℝ} (ha : 0<a) (hb : 0<b)
    (hleft : ∀ i∈I, a≤eig i) (hright : ∀ i∉I, b≤eig i) :
    (a⁻¹ • 1 + (b⁻¹-a⁻¹) • (U*Matrix.diagonal (fun i => if i∈I then (0:ℝ) else 1)*Uᴴ) -
      (U*Matrix.diagonal eig*Uᴴ)⁻¹).PosSemidef := by
  classical
  have hU' : U*Uᴴ=1 := mul_eq_one_comm.mp hU
  let d : n → ℝ := fun i => if i∈I then 0 else 1
  have hg (i : n) : 0≤a⁻¹+(b⁻¹-a⁻¹)*d i-(eig i)⁻¹ := by
    by_cases hi : i∈I
    · have ht := one_div_le_one_div_of_le ha (hleft i hi)
      simp only [one_div] at ht
      simp only [d,ite_eq_left hi,mul_zero,add_zero]
      linarith
    · have ht := one_div_le_one_div_of_le hb (hright i hi)
      simp only [one_div] at ht
      simp only [d,ite_eq_right hi,mul_one]
      linarith
  have hd : Matrix.diagonal (fun i => a⁻¹+(b⁻¹-a⁻¹)*d i-(eig i)⁻¹)=
      a⁻¹ • (1 : Matrix n n ℝ)+(b⁻¹-a⁻¹) • Matrix.diagonal d-Matrix.diagonal (fun i => (eig i)⁻¹) := by
    ext i j
    by_cases hij : i=j
    · subst j; simp
    · simp [hij]
  have h := (Matrix.PosSemidef.diagonal hg).conjTranspose_mul_mul_same Uᴴ
  rw [hd,Matrix.conjTranspose_conjTranspose,Matrix.mul_sub,Matrix.sub_mul,
    Matrix.mul_add,Matrix.add_mul,Matrix.mul_smul,Matrix.smul_mul,Matrix.mul_one,hU',
    Matrix.mul_smul,Matrix.smul_mul,← inverse_orthogonal_spectrum U hU eig heig] at h
  exact h

/-- Actual orthogonal-orbit covariance realizing a prescribed positive spectrum and precision bound. -/
theorem exists_sharp_prescribed_covariance {N : ℕ} {P : Matrix (Fin N) (Fin N) ℝ}
    (hP : P.IsHermitian) (hPP : P*P=P) (I : Finset (Fin N)) (hr : P.rank=N-I.card)
    (eig : Fin N → ℝ) (heig : ∀ i, 0<eig i) {a b : ℝ} (ha : 0<a) (hb : 0<b)
    (hleft : ∀ i∈I, a≤eig i) (hright : ∀ i∉I, b≤eig i) :
    ∃ V : Matrix (Fin N) (Fin N) ℝ, V.transpose*V=1 ∧
      (V.transpose*Matrix.diagonal eig*V).PosDef ∧
      (a⁻¹ • 1+(b⁻¹-a⁻¹) • P-(V.transpose*Matrix.diagonal eig*V)⁻¹).PosSemidef := by
  obtain ⟨U,hU,hproj⟩ := projection_basis_for_partition hP hPP I hr
  have hU' : U*Uᴴ=1 := mul_eq_one_comm.mp hU
  have ht : U.transpose=Uᴴ := by ext i j; simp
  refine ⟨Uᴴ,?_,?_,?_⟩
  · simpa only [← ht,Matrix.transpose_transpose] using hU'
  · exact orbit_posDef eig heig Uᴴ (by simpa only [← ht,Matrix.transpose_transpose] using hU')
  · have h := sharp_prescribed_precision_bound U hU eig heig I ha hb hleft hright
    rw [← hproj] at h
    simpa only [← ht,Matrix.transpose_transpose] using h

/-- Positive principal blocks allow beta=0 without an exceptional case assumption. -/
theorem matrix_regularization_nonnegative_beta {ι : Type*} [Fintype ι] [DecidableEq ι] [Nonempty ι]
    {P T : Matrix ι ι ℝ} (hP : P.PosDef) (hT : T.PosDef)
    {α β L : ℝ} (hα : 0<α) (hβ : 0≤β) (hL : 0<L) (htrace : L≤P⁻¹.trace)
    (hbound : (α • (1 : Matrix ι ι ℝ)+β • P-T).PosSemidef) :
    L/(β+α*L)≤T⁻¹.trace := by
  rcases eq_or_lt_of_le hβ with he | hb
  · subst β
    simp only [zero_smul,add_zero] at hbound
    have hQ : (α • (1 : Matrix ι ι ℝ)).PosDef := Matrix.PosDef.one.smul hα
    have ht := inverse_trace_order hT hQ hbound
    let _ : Invertible α := invertibleOfNonzero hα.ne'
    rw [Matrix.inv_smul _ α (by simp),inv_one,Matrix.trace_smul,Matrix.trace_one] at ht
    simp only [zero_add,invOf_eq_inv,smul_eq_mul] at ht ⊢
    have hc : (1:ℝ)≤Fintype.card ι := by exact_mod_cast Fintype.card_pos
    have heq : L/(α*L)=α⁻¹ := by field_simp
    rw [heq]
    exact (by nlinarith [inv_pos.mpr hα] : α⁻¹≤α⁻¹*(Fintype.card ι:ℝ)).trans ht
  · exact matrix_regularization hP.posSemidef hT hα hb hL (fun _ => htrace) hbound

end SpectralComparison
