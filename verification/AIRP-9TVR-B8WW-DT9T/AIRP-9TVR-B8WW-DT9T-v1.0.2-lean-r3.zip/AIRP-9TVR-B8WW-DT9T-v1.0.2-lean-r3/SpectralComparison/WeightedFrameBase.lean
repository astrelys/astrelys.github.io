import SpectralComparison.StrictTheorem

noncomputable section
open Matrix
namespace SpectralComparison

def weightedGamma (k m : ℕ) : ℝ := if m≤k then (k:ℝ)/(32000000000*Real.sqrt m)
  else Real.sqrt k/128000000000

/-- The exact positive two-branch constant in E.1-E.3. -/
theorem weightedGamma_pos {k m : ℕ} (hk : 1≤k) (hm : 1≤m) : 0<weightedGamma k m := by
  have hk0 : 0<(k:ℝ) := by exact_mod_cast (by omega : 0<k)
  have hm0 : 0<(m:ℝ) := by exact_mod_cast (by omega : 0<m)
  have hsk := Real.sqrt_pos.mpr hk0
  have hsm := Real.sqrt_pos.mpr hm0
  dsimp [weightedGamma]
  split <;> positivity

/-- E.4 on actual Parseval frames, including its complementary-rank shift. -/
theorem exists_weighted_prefix_base {k t : ℕ} (hk : 1≤k) (ht : 1≤t) :
    ∃ Q : Matrix (Fin (k+t)) (Fin t) ℝ,Qᴴ*Q=1 ∧
      ∀ I : Finset (Fin (k+t)),I.card=t →
        IsUnit ((Q.submatrix (fun i : I => (i:Fin (k+t))) id)ᴴ*
          Q.submatrix (fun i : I => (i:Fin (k+t))) id) →
        ((k:ℝ)+t)*Real.sqrt (min k t:ℕ)/16000000000+max ((t:ℝ)-k) 0≤
          ((Q.submatrix (fun i : I => (i:Fin (k+t))) id)ᴴ*
            Q.submatrix (fun i : I => (i:Fin (k+t))) id)⁻¹.trace := by
  obtain ⟨Q,hQ,hbound⟩ := exists_frame_complementary_rank_bound (n:=k+t) ht (by omega)
  simp only [Nat.add_sub_cancel_right,Nat.cast_add,min_comm t k] at hbound
  have hmin : ((k:ℝ)+t)*Real.sqrt (min k t:ℕ)/16000000000+max ((t:ℝ)-k) 0≤frameBasisMinimum Q := by
    by_cases htk : t≤k
    · have hr : (t:ℝ)≤k := by exact_mod_cast htk
      rw [max_eq_left (by linarith)] at hbound
      rw [max_eq_right (by linarith)]
      linarith
    · have hr : (k:ℝ)≤t := by exact_mod_cast (by omega : k≤t)
      rw [max_eq_right (by linarith)] at hbound
      rw [max_eq_left (by linarith)]
      linarith
  refine ⟨Q,hQ,?_⟩
  intro I hI hu
  let A := Q.submatrix (fun i : I => (i:Fin (k+t))) id
  have hdim : Fintype.card I=Fintype.card (Fin t) := by simpa using hI
  have hg := equal_dimension_gram_inverses A hdim
  have hp : IsUnit (principal (Q*Qᴴ) I) := by
    have hh := hg.1.mpr hu
    convert hh using 1
    ext i j
    simp [principal,A,Matrix.mul_apply]
  have hb := frameBasisMinimum_le_basis Q I hI hp
  have he : (principal (Q*Qᴴ) I)⁻¹.trace=(Aᴴ*A)⁻¹.trace := by
    have hh : principal (Q*Qᴴ) I=A*Aᴴ := by ext i j; simp [principal,A,Matrix.mul_apply]
    rw [hh,hg.2]
  change frameBasisMinimum Q≤(principal (Q*Qᴴ) I)⁻¹.trace at hb
  rw [he] at hb
  exact hmin.trans hb

end SpectralComparison
