import SpectralComparison.SignalNoise

/-! Safe diagonal noise extraction from isolated rows of a block covariance. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Diagonal mass can be removed from genuinely isolated coordinates while retaining PSD.
No off-diagonal entries of a general PSD matrix are discarded. -/
theorem isolated_diagonal_gap {n : Type*} [Fintype n] [DecidableEq n]
    {D : Matrix n n ℝ} (hD : D.PosSemidef) (L : Finset n)
    (hzero : ∀ i∈L,∀ j,i≠j → D i j=0) :
    (D-Matrix.diagonal (fun i => if i∈L then D i i else 0)).PosSemidef := by
  classical
  let c := fun i => if i∈L then (0:ℝ) else 1
  let A := Matrix.diagonal c
  have hA : A.IsHermitian := Matrix.isHermitian_diagonal c
  have hh := hD.conjTranspose_mul_mul_same A
  rw [hA.eq] at hh
  have he : A*D*A=D-Matrix.diagonal (fun i => if i∈L then D i i else 0) := by
    ext i j
    change (Matrix.diagonal c*D*Matrix.diagonal c) i j=_
    rw [Matrix.mul_diagonal,Matrix.diagonal_mul]
    simp only [Matrix.sub_apply,Matrix.diagonal_apply]
    by_cases hij : i=j
    · subst j
      by_cases hi : i∈L <;> simp [c,hi]
    · rw [ite_eq_right hij]
      by_cases hi : i∈L
      · rw [hzero i hi j hij]; simp
      · by_cases hj : j∈L
        · have hsym : D j i=D i j := by
            have hz := congrFun (congrFun hD.isHermitian.eq i) j
            simpa only [Matrix.conjTranspose_apply,star_trivial] using hz
          rw [← hsym,hzero j hj i (Ne.symm hij)]; simp
        · simp [c,hi,hj]
  rw [he] at hh
  exact hh

/-- A PSD covariance above a block covariance dominates the light-coordinate diagonal floor. -/
theorem light_diagonal_noise_gap {n : Type*} [Fintype n] [DecidableEq n]
    {C D : Matrix n n ℝ} (hD : D.PosSemidef) (hCD : (C-D).PosSemidef)
    (L : Finset n) (hzero : ∀ i∈L,∀ j,i≠j → D i j=0)
    (b : n → ℝ) (hbound : ∀ i∈L,b i≤D i i) :
    (C-Matrix.diagonal (fun i => if i∈L then b i else 0)).PosSemidef := by
  classical
  have hrest := isolated_diagonal_gap hD L hzero
  have hdiag : (Matrix.diagonal (fun i => if i∈L then D i i else 0)-
      Matrix.diagonal (fun i => if i∈L then b i else 0)).PosSemidef := by
    rw [Matrix.diagonal_sub]
    apply Matrix.PosSemidef.diagonal
    intro i
    by_cases hi : i∈L
    · simpa [hi] using sub_nonneg.mpr (hbound i hi)
    · simp [hi]
  convert (hCD.add hrest).add hdiag using 1
  abel

/-- Congruence turns the light-coordinate PSD floor into the needed predicted-noise trace floor. -/
theorem light_noise_trace_lower {n r : Type*} [Fintype n] [Fintype r]
    [DecidableEq n] [DecidableEq r] {C D : Matrix n n ℝ}
    (hD : D.PosSemidef) (hCD : (C-D).PosSemidef)
    (L : Finset n) (hzero : ∀ i∈L,∀ j,i≠j → D i j=0)
    (b : n → ℝ) (hbound : ∀ i∈L,b i≤D i i) (M : Matrix r n ℝ) :
    (M*Matrix.diagonal (fun i => if i∈L then b i else 0)*Mᴴ).trace≤(M*C*Mᴴ).trace := by
  have hh := ((light_diagonal_noise_gap hD hCD L hzero b hbound).mul_mul_conjTranspose_same M).trace_nonneg
  rw [Matrix.mul_sub,Matrix.sub_mul,Matrix.trace_sub] at hh
  linarith

end SpectralComparison
