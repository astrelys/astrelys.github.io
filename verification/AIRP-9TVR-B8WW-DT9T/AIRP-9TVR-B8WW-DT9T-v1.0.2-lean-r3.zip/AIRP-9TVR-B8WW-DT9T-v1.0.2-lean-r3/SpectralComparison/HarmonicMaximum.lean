import SpectralComparison.WaterOrientation
import Mathlib.Algebra.Order.Chebyshev

noncomputable section
open Finset
namespace SpectralComparison

def harmonicSetValue {n : ℕ} (a : Fin n → ℝ) (k : ℕ) (S : Finset (Fin n)) : ℝ :=
  (∑ i∈Finset.univ\S,a i)+((S.card:ℝ)-(k:ℝ))*((S.card:ℝ)/(∑ i∈S,(a i)⁻¹))

def spectralPrefix {n : ℕ} (q : ℕ) : Finset (Fin n) := Finset.univ.filter (fun i => i.val<q)

def harmonicPrefixValue {n : ℕ} (a : Fin n → ℝ) (k q : ℕ) : ℝ := harmonicSetValue a k (spectralPrefix q)

theorem water_min_identity {a τ : ℝ} (ha : 0<a) : min a τ=a*(1-max (1-τ/a) 0) := by
  by_cases h : a≤τ
  · rw [min_eq_left h,max_eq_right (by have hh := (one_le_div ha).mpr h; linarith)]
    ring
  · have hlt : τ<a := lt_of_not_ge h
    rw [min_eq_right hlt.le,max_eq_left (by have hh := (div_lt_one ha).mpr hlt; linarith)]
    field_simp
    ring

theorem harmonicSetValue_le_water {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i)
    (S : Finset (Fin n)) (hne : S.Nonempty)
    (hsep : ∀ i∈S,∀ j∉S,a j≤a i) {τ : ℝ} (hroot : waterSum a τ=k) :
    harmonicSetValue a k S≤∑ i,min (a i) τ := by
  let f := fun i => max (1-τ/a i) 0
  let R := ∑ i∈S,(a i)⁻¹
  let H := (S.card:ℝ)/R
  have hR : 0<R := Finset.sum_pos (fun i _ => inv_pos.mpr (ha i)) hne
  have hanti : AntivaryOn (fun i => min (a i) τ) (fun i => (a i)⁻¹) (S : Set (Fin n)) := by
    intro i _ j _ hij
    have hji : a j≤a i := by
      by_contra h
      have hh := one_div_le_one_div_of_le (ha i) (le_of_not_ge h)
      simp only [one_div] at hh
      linarith
    exact min_le_min_right τ hji
  have hcheb := hanti.card_mul_sum_le_sum_mul_sum
  have hentry (i : Fin n) : min (a i) τ*(a i)⁻¹=1-f i := by
    rw [water_min_identity (ha i)]
    dsimp [f]
    field_simp [(ha i).ne']
  simp_rw [hentry] at hcheb
  rw [Finset.sum_sub_distrib] at hcheb
  simp only [Finset.sum_const,nsmul_eq_mul,mul_one] at hcheb
  have hhead : H*((S.card:ℝ)-∑ i∈S,f i)≤∑ i∈S,min (a i) τ := by
    dsimp [H]
    rw [div_mul_eq_mul_div]
    exact (div_le_iff₀ hR).mpr hcheb
  have htailH (j : Fin n) (hj : j∉S) : a j≤H := by
    have hs : R≤(S.card:ℝ)/(a j) := by
      calc
        _ ≤∑ _i∈S,(a j)⁻¹ := Finset.sum_le_sum (fun i hi => by simpa only [one_div] using one_div_le_one_div_of_le (ha j) (hsep i hi j hj))
        _ =_ := by simp [div_eq_mul_inv]
    apply (le_div_iff₀ hR).mpr
    have hh := (le_div_iff₀ (ha j)).mp hs
    nlinarith
  have htail : (∑ i∈Finset.univ\S,a i)-H*(∑ i∈Finset.univ\S,f i)≤∑ i∈Finset.univ\S,min (a i) τ := by
    rw [Finset.mul_sum,← Finset.sum_sub_distrib]
    apply Finset.sum_le_sum
    intro i hi
    rw [water_min_identity (ha i)]
    have hh := htailH i (Finset.mem_sdiff.mp hi).2
    have hf : 0≤f i := le_max_right _ _
    change a i-H*f i≤a i*(1-f i)
    nlinarith [mul_nonneg (sub_nonneg.mpr hh) hf]
  have hsumf := Finset.sum_sdiff (f:=f) (Finset.subset_univ S)
  change (∑ i∈Finset.univ\S,f i)+(∑ i∈S,f i)=waterSum a τ at hsumf
  rw [hroot] at hsumf
  have hsumfH := congrArg (fun z : ℝ => H*z) hsumf
  have hsumm := Finset.sum_sdiff (f:=fun i => min (a i) τ) (Finset.subset_univ S)
  change (∑ i∈Finset.univ\S,a i)+((S.card:ℝ)-(k:ℝ))*H≤_
  nlinarith

theorem spectralPrefix_card {n q : ℕ} (hq : q≤n) : (spectralPrefix (n:=n) q).card=q := by
  classical
  by_cases he : q=n
  · subst q
    have hs : spectralPrefix (n:=n) n=Finset.univ := by ext i; simp [spectralPrefix]
    simp [hs]
  · have hqn : q<n := by omega
    have hs : spectralPrefix (n:=n) q=Finset.Iio (⟨q,hqn⟩ : Fin n) := by ext i; simp [spectralPrefix,Fin.lt_def]
    rw [hs,Fin.card_Iio]

theorem water_active_prefix {n : ℕ} (a : Fin n → ℝ) (horder : Antitone a) (τ : ℝ) :
    let S := Finset.univ.filter (fun i => τ<a i)
    S=spectralPrefix S.card := by
  classical
  let S := Finset.univ.filter (fun i => τ<a i)
  have hlo (i : Fin n) (hi : i∈S) : i.val<S.card := by
    have hsub : Finset.Iic i⊆S := by
      intro j hj
      apply Finset.mem_filter.mpr
      exact ⟨Finset.mem_univ _,(Finset.mem_filter.mp hi).2.trans_le (horder (Finset.mem_Iic.mp hj))⟩
    have hh := Finset.card_le_card hsub
    simp only [Fin.card_Iic] at hh
    omega
  have hhi (i : Fin n) (hi : i∉S) : S.card ≤ i.val := by
    have hsub : S⊆Finset.Iio i := by
      intro j hj
      apply Finset.mem_Iio.mpr
      by_contra h
      have hle : i≤j := le_of_not_gt h
      have hτi : a i≤τ := by simpa [S] using hi
      have hτj := (Finset.mem_filter.mp hj).2
      linarith [horder hle]
    simpa only [Fin.card_Iio] using Finset.card_le_card hsub
  change S=spectralPrefix S.card
  ext i
  conv_rhs => simp only [spectralPrefix,Finset.mem_filter,Finset.mem_univ,true_and]
  exact ⟨hlo i,fun hi => by by_contra hn; have hh := hhi i hn; omega⟩

/-- The sum of clipped values equals the active-cardinality formula q*tau+T. -/
theorem water_min_sum {n : ℕ} (a : Fin n → ℝ) (τ : ℝ) :
    let S := Finset.univ.filter (fun i => τ<a i)
    (∑ i,min (a i) τ)=(S.card:ℝ)*τ+∑ i∈Finset.univ\S,a i := by
  classical
  let S := Finset.univ.filter (fun i => τ<a i)
  have hh : (∑ i∈S,min (a i) τ)=(S.card:ℝ)*τ := by
    have he : (∑ i∈S,min (a i) τ)=∑ _i∈S,τ := Finset.sum_congr rfl (fun i hi => min_eq_right (Finset.mem_filter.mp hi).2.le)
    simpa using he
  have ht : (∑ i∈Finset.univ\S,min (a i) τ)=∑ i∈Finset.univ\S,a i := by
    apply Finset.sum_congr rfl
    intro i hi
    apply min_eq_left
    simpa [S] using (Finset.mem_sdiff.mp hi).2
  have hs := Finset.sum_sdiff (f:=fun i => min (a i) τ) (Finset.subset_univ S)
  linarith

/-- The active prefix attains the harmonic bound at exactly the water value. -/
theorem water_active_value {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i)
    (hk : 1≤k) {τ : ℝ} (hτ : 0<τ) (hroot : waterSum a τ=k) :
    let S := Finset.univ.filter (fun i => τ<a i)
    harmonicSetValue a k S=(S.card:ℝ)*τ+∑ i∈Finset.univ\S,a i := by
  let S := Finset.univ.filter (fun i => τ<a i)
  have hs := waterLevel_active a ha hτ hroot hk
  have hcardS : k<S.card := hs.1
  have hpos : 0<∑ i∈S,(a i)⁻¹ := Finset.sum_pos (fun i _ => inv_pos.mpr (ha i)) (Finset.card_pos.mp (by omega))
  have he : τ*(∑ i∈S,(a i)⁻¹)=(S.card:ℝ)-(k:ℝ) := by
    rw [Finset.mul_sum]
    simpa only [div_eq_mul_inv] using hs.2.1
  change (∑ i∈Finset.univ\S,a i)+((S.card:ℝ)-(k:ℝ))*((S.card:ℝ)/(∑ i∈S,(a i)⁻¹))=_
  have hh : ((S.card:ℝ)-(k:ℝ))*((S.card:ℝ)/(∑ i∈S,(a i)⁻¹))=(S.card:ℝ)*τ := by
    rw [← mul_div_assoc]
    apply (div_eq_iff hpos.ne').mpr
    nlinarith [he]
  rw [hh]
  ring

/-- The original max over every admissible prefix is exactly q*tau+T. -/
theorem paper_harmonic_maximum {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i) (horder : Antitone a)
    (hk : 1≤k) (hkn : k<n) {τ : ℝ} (hτ : 0<τ) (hroot : waterSum a τ=k) :
    let S := Finset.univ.filter (fun i => τ<a i)
    (Finset.Icc (k+1) n).sup' ⟨k+1,Finset.mem_Icc.mpr ⟨le_rfl,by omega⟩⟩ (harmonicPrefixValue a k)=
      (S.card:ℝ)*τ+∑ i∈Finset.univ\S,a i := by
  classical
  let S := Finset.univ.filter (fun i => τ<a i)
  have hs := waterLevel_active a ha hτ hroot hk
  have hcardS : k<S.card := hs.1
  have hc : S.card≤n := by simpa using S.card_le_univ
  apply le_antisymm
  · apply Finset.sup'_le
    intro j hj
    have hjn : j≤n := (Finset.mem_Icc.mp hj).2
    have hj0 : 0<j := by have hh: k+1≤j := (Finset.mem_Icc.mp hj).1; omega
    have hcard := spectralPrefix_card hjn
    have hne : (spectralPrefix (n:=n) j).Nonempty := Finset.card_pos.mp (by rw [hcard]; exact hj0)
    have hsep : ∀ i∈spectralPrefix (n:=n) j,∀ l∉spectralPrefix (n:=n) j,a l≤a i := by
      intro i hi l hl
      apply horder
      have hi' : i.val<j := (Finset.mem_filter.mp hi).2
      have hl' : j≤l.val := by simpa [spectralPrefix] using hl
      change i.val≤l.val
      omega
    exact (harmonicSetValue_le_water a ha _ hne hsep hroot).trans_eq (water_min_sum a τ)
  · have hmem : S.card∈Finset.Icc (k+1) n := Finset.mem_Icc.mpr ⟨by omega,hc⟩
    have hh := Finset.le_sup' (harmonicPrefixValue a k) hmem
    have heS := water_active_prefix a horder τ
    change S=spectralPrefix S.card at heS
    have he := water_active_value a ha hk hτ hroot
    change harmonicSetValue a k S=_ at he
    dsimp only [harmonicPrefixValue] at hh
    rw [← heS,he] at hh
    exact hh

end SpectralComparison
