import SpectralComparison.BalancedGaussian

noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

/-- Simultaneous balanced normalization and every square row basis. -/
theorem balanced_gaussian_exists_good_realization {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {k : ℕ} (hk : 4 ≤ k)
    (G : Ω → Matrix (Fin (2*k)) (Fin k) ℝ)
    (hG : ∀ a : Fin (2*k) × Fin k, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin (2*k) × Fin k => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : Fin (2*k) × Fin k, Measurable (fun ω => G ω a.1 a.2)) :
    ∃ ω, ‖(G ω).toEuclideanLin.toContinuousLinearMap‖ ≤ 10*Real.sqrt (k:ℝ) ∧
      (∀ x : EuclideanSpace ℝ (Fin k), ‖x‖=1 →
        Real.sqrt (k:ℝ)/2000 ≤ ‖(G ω).toEuclideanLin x‖) ∧
      ∀ J : Finset (Fin (2*k)), J.card=k →
        (k:ℝ)/(1000*Real.sqrt k) <
        ((G ω).submatrix (fun i : J => (i : Fin (2*k))) id *
        ((G ω).submatrix (fun i : J => (i : Fin (2*k))) id)ᴴ)⁻¹.trace := by
  obtain ⟨s,hnet,hsmall⟩ := exists_balanced_small_ball_net G hG hind hm
  let A := {ω | 10*Real.sqrt (k:ℝ) < ‖(G ω).toEuclideanLin.toContinuousLinearMap‖}
  let B := {ω | ∃ v ∈ s, ‖(G ω).toEuclideanLin v‖^2 ≤ (k:ℝ)/1000000}
  let C := {ω | ∃ J : Finset (Fin (2*k)), J.card=k ∧
        ((G ω).submatrix (fun i : J => (i : Fin (2*k))) id *
        ((G ω).submatrix (fun i : J => (i : Fin (2*k))) id)ᴴ)⁻¹.trace ≤
        (k:ℝ)/(1000*Real.sqrt k)}
  have hA : μ.real A ≤ Real.exp (-3*(k:ℝ)) := gaussian_opNorm_tail (le_refl _) G hG hind hm
  have hB : μ.real B ≤ (1/16:ℝ)^k := hsmall
  have hC : μ.real C ≤ 2*Real.exp (-29*(k:ℝ)) := by
    simpa [C] using gaussian_all_row_subsets_tail (q:=0) (by omega : 1 ≤ k) (by simpa using hk) (by omega : 2*k ≤ 2*(k+0)) G hG hind
  have hbad : μ.real ((A ∪ B) ∪ C) < 1 := by
    calc
      _ ≤ μ.real (A ∪ B) + μ.real C := measureReal_union_le _ _
      _ ≤ μ.real A + μ.real B + μ.real C := by gcongr; exact measureReal_union_le _ _
      _ ≤ Real.exp (-3*(k:ℝ))+(1/16:ℝ)^k+2*Real.exp (-29*(k:ℝ)) := by linarith
      _ < 1 := gaussian_good_event_budget hk
  have hex : ∃ ω, ω ∉ (A ∪ B) ∪ C := by
    by_contra! h
    have he : (A ∪ B) ∪ C = Set.univ := Set.eq_univ_of_forall h
    simp [he] at hbad
  obtain ⟨ω,hω⟩ := hex
  have hupper : ‖(G ω).toEuclideanLin.toContinuousLinearMap‖ ≤ 10*Real.sqrt (k:ℝ) := by
    have : ω ∉ A := fun h => hω (Or.inl (Or.inl h))
    exact le_of_not_gt this
  have hlower : ∀ v ∈ s, (k:ℝ)/1000000 < ‖(G ω).toEuclideanLin v‖^2 := by
    intro v hv
    exact lt_of_not_ge (fun h => hω (Or.inl (Or.inr ⟨v,hv,h⟩)))
  refine ⟨ω,hupper,balanced_net_lower_singular (G ω) s hnet hupper hlower,?_⟩
  intro J hJ
  exact lt_of_not_ge (fun h => hω (Or.inr ⟨J,hJ,h⟩))

/-- A deterministic balanced matrix realizing all quantitative estimates. -/
theorem exists_balanced_good_matrix {k : ℕ} (hk : 4 ≤ k) :
    ∃ G : Matrix (Fin (2*k)) (Fin k) ℝ,
      ‖G.toEuclideanLin.toContinuousLinearMap‖ ≤ 10*Real.sqrt (k:ℝ) ∧
      (∀ x : EuclideanSpace ℝ (Fin k), ‖x‖=1 →
        Real.sqrt (k:ℝ)/2000 ≤ ‖G.toEuclideanLin x‖) ∧
      ∀ J : Finset (Fin (2*k)), J.card=k →
        (k:ℝ)/(1000*Real.sqrt k) <
        (G.submatrix (fun i : J => (i : Fin (2*k))) id *
        (G.submatrix (fun i : J => (i : Fin (2*k))) id)ᴴ)⁻¹.trace := by
  let μ : Measure (Fin (2*k) × Fin k → ℝ) := Measure.pi (fun _ => gaussianReal 0 1)
  let G := fun (ω : Fin (2*k) × Fin k → ℝ) => Matrix.of (fun i j => ω (i,j))
  have hX : HasLaw id μ μ := HasLaw.id
  have hG := gaussian_product_entry_hasLaw id hX
  have hi := gaussian_product_independent id hX
  have hm (a : Fin (2*k) × Fin k) : Measurable (fun ω => G ω a.1 a.2) := measurable_pi_apply a
  obtain ⟨ω,hω⟩ := balanced_gaussian_exists_good_realization (μ := μ) hk G hG hi hm
  exact ⟨G ω,hω⟩

end SpectralComparison
