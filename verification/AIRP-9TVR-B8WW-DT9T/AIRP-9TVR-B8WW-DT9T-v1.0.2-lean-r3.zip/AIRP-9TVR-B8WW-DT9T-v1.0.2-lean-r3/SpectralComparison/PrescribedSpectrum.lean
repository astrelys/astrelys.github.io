import SpectralComparison.ProjectionSpectrum

/-! Assigning a prescribed spectrum to a projection and bounding its inverse. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- A projection basis can assign any chosen set of eigenvalue labels to its kernel. -/
theorem projection_basis_for_partition {N : ℕ} {P : Matrix (Fin N) (Fin N) ℝ}
    (hP : P.IsHermitian) (hPP : P*P=P) (I : Finset (Fin N)) (hr : P.rank=N-I.card) :
    ∃ U : Matrix (Fin N) (Fin N) ℝ, Uᴴ*U=1 ∧
      P=U*Matrix.diagonal (fun i => if i∈I then (0:ℝ) else 1)*Uᴴ := by
  classical
  have hIN : I.card≤N := by simpa using I.card_le_univ
  obtain ⟨V,hV,hV',hdiag⟩ := projection_split_basis (r := I.card) (by omega) hP hPP hr
  let J := Finset.univ \ I
  let eI : Fin I.card ≃ I := Fintype.equivOfCardEq (by simp)
  let eJ : Fin (N-I.card) ≃ J := Fintype.equivOfCardEq (by simp [J])
  let e : (Fin I.card ⊕ Fin (N-I.card)) ≃ Fin N := (Equiv.sumCongr eI eJ).trans (partitionEquiv I)
  let D : Matrix (Fin N) (Fin N) ℝ := Matrix.diagonal (fun i => if i∈I then (0:ℝ) else 1)
  let d : Fin I.card ⊕ Fin (N-I.card) → ℝ := Sum.elim (fun _ => 0) (fun _ => 1)
  have hd : D.submatrix e e=Matrix.diagonal d := by
    rw [Matrix.submatrix_diagonal_equiv]
    congr 1
    funext i
    cases i with
    | inl a => exact ite_eq_left (eI a).property
    | inr a => exact ite_eq_right (Finset.mem_sdiff.mp (eJ a).property).2
  have hd' : (Matrix.diagonal d).submatrix e.symm e.symm=D := by
    rw [← hd]
    ext a b
    simp
  let U := V.submatrix id e.symm
  have hU : Uᴴ*U=1 := by
    change (V.submatrix id e.symm)ᴴ*V.submatrix id e.symm=1
    rw [Matrix.conjTranspose_submatrix,← Matrix.submatrix_mul _ _ e.symm id e.symm Function.bijective_id,hV]
    exact Matrix.submatrix_one e.symm e.symm.injective
  refine ⟨U,hU,?_⟩
  change P=U*D*Uᴴ
  rw [← hd']
  change P=V.submatrix id e.symm*(Matrix.diagonal d).submatrix e.symm e.symm*(V.submatrix id e.symm)ᴴ
  rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,Matrix.submatrix_mul_equiv,Matrix.submatrix_id_id]
  exact hdiag

/-- Inverting a positive diagonal spectrum commutes with an orthogonal change of coordinates. -/
theorem inverse_orthogonal_spectrum {n : Type*} [Fintype n] [DecidableEq n]
    (U : Matrix n n ℝ) (hU : Uᴴ*U=1) (eig : n → ℝ) (heig : ∀ i, 0<eig i) :
    (U*Matrix.diagonal eig*Uᴴ)⁻¹=U*Matrix.diagonal (fun i => (eig i)⁻¹)*Uᴴ := by
  have hU' : U*Uᴴ=1 := mul_eq_one_comm.mp hU
  rw [Matrix.mul_inv_rev,Matrix.mul_inv_rev,Matrix.inv_eq_left_inv hU',Matrix.inv_eq_left_inv hU,
    positive_diagonal_inverse eig heig]
  simp only [one_div,Matrix.mul_assoc]

/-- The prescribed covariance has precision bounded by the two projection scales. -/
theorem prescribed_spectrum_precision_bound {n : Type*} [Fintype n] [DecidableEq n]
    (U : Matrix n n ℝ) (hU : Uᴴ*U=1) (eig : n → ℝ) (heig : ∀ i, 0<eig i)
    (I : Finset n) {a b : ℝ} (ha : 0<a) (hb : 0<b)
    (hleft : ∀ i∈I, a≤eig i) (hright : ∀ i∉I, b≤eig i) :
    (a⁻¹ • 1 + b⁻¹ • (U*Matrix.diagonal (fun i => if i∈I then (0:ℝ) else 1)*Uᴴ) -
      (U*Matrix.diagonal eig*Uᴴ)⁻¹).PosSemidef := by
  classical
  have hU' : U*Uᴴ=1 := mul_eq_one_comm.mp hU
  let d : n → ℝ := fun i => if i∈I then 0 else 1
  have hg (i : n) : 0≤a⁻¹+b⁻¹*d i-(eig i)⁻¹ := by
    by_cases hi : i∈I
    · have ht := one_div_le_one_div_of_le ha (hleft i hi)
      simp only [one_div] at ht
      simp only [d,ite_eq_left hi,mul_zero,add_zero]
      linarith
    · have ht := one_div_le_one_div_of_le hb (hright i hi)
      simp only [one_div] at ht
      simp only [d,ite_eq_right hi,mul_one]
      linarith [inv_pos.mpr ha]
  have hd : Matrix.diagonal (fun i => a⁻¹+b⁻¹*d i-(eig i)⁻¹)=
      a⁻¹ • (1 : Matrix n n ℝ)+b⁻¹ • Matrix.diagonal d-Matrix.diagonal (fun i => (eig i)⁻¹) := by
    ext i j
    by_cases hij : i=j
    · subst j; simp
    · simp [hij]
  have h := (Matrix.PosSemidef.diagonal hg).conjTranspose_mul_mul_same Uᴴ
  rw [hd,Matrix.conjTranspose_conjTranspose,Matrix.mul_sub,Matrix.sub_mul,
    Matrix.mul_add,Matrix.add_mul,Matrix.mul_smul,Matrix.smul_mul,Matrix.mul_one,hU',
    Matrix.mul_smul,Matrix.smul_mul,← inverse_orthogonal_spectrum U hU eig heig] at h
  exact h

/-- Actual orthogonal-orbit covariance realizing a prescribed positive spectrum and precision bound. -/
theorem exists_prescribed_covariance {N : ℕ} {P : Matrix (Fin N) (Fin N) ℝ}
    (hP : P.IsHermitian) (hPP : P*P=P) (I : Finset (Fin N)) (hr : P.rank=N-I.card)
    (eig : Fin N → ℝ) (heig : ∀ i, 0<eig i) {a b : ℝ} (ha : 0<a) (hb : 0<b)
    (hleft : ∀ i∈I, a≤eig i) (hright : ∀ i∉I, b≤eig i) :
    ∃ V : Matrix (Fin N) (Fin N) ℝ, V.transpose*V=1 ∧
      (V.transpose*Matrix.diagonal eig*V).PosDef ∧
      (a⁻¹ • 1+b⁻¹ • P-(V.transpose*Matrix.diagonal eig*V)⁻¹).PosSemidef := by
  obtain ⟨U,hU,hproj⟩ := projection_basis_for_partition hP hPP I hr
  have hU' : U*Uᴴ=1 := mul_eq_one_comm.mp hU
  have ht : U.transpose=Uᴴ := by ext i j; simp
  refine ⟨Uᴴ,?_,?_,?_⟩
  · simpa only [← ht,Matrix.transpose_transpose] using hU'
  · exact orbit_posDef eig heig Uᴴ (by simpa only [← ht,Matrix.transpose_transpose] using hU')
  · have h := prescribed_spectrum_precision_bound U hU eig heig I ha hb hleft hright
    rw [← hproj] at h
    simpa only [← ht,Matrix.transpose_transpose] using h

end SpectralComparison
