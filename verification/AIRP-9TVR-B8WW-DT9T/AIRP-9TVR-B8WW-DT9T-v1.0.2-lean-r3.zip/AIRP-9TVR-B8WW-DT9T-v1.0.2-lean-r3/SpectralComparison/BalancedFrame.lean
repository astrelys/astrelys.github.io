import SpectralComparison.BalancedRealization
import SpectralComparison.Whitening

/-! The exact square-basis Parseval construction from Appendix A. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Positive row Gram is preserved under whitening by a positive column Gram. -/
theorem whitening_row_posDef {n p j : Type*} [Fintype n] [Fintype p] [Fintype j]
    [DecidableEq p] [DecidableEq j] (G V : Matrix n p ℝ) (hG : (Gᴴ*G).PosDef)
    (hV : V*Vᴴ=G*(Gᴴ*G)⁻¹*Gᴴ) (e : j → n)
    (hrow : (G.submatrix e id*(G.submatrix e id)ᴴ).PosDef) :
    ((V*Vᴴ).submatrix e e).PosDef := by
  let A := G.submatrix e id
  have hi : Function.Injective A.vecMul := by
    intro x y hxy
    apply (Matrix.vecMul_injective_of_isUnit hrow.isUnit)
    simpa only [Matrix.vecMul_vecMul] using congrArg (fun z => z ᵥ* Aᴴ) hxy
  have h := hG.inv.mul_mul_conjTranspose_same hi
  have he : (V*Vᴴ).submatrix e e = A*(Gᴴ*G)⁻¹*Aᴴ := by
    rw [hV, Matrix.submatrix_mul _ _ e id e Function.bijective_id,
      Matrix.submatrix_mul _ _ e id id Function.bijective_id, Matrix.submatrix_id_id]
    rfl
  rwa [he]

/-- Appendix A's balanced frame: every square row basis is nonsingular and its inverse trace
is at least k*sqrt(k)/(4*10^9). This retains the original constant. -/
theorem exists_balanced_parseval_frame {k : ℕ} (hk : 4 ≤ k) :
    ∃ Q : Matrix (Fin (2*k)) (Fin k) ℝ, Qᴴ*Q=1 ∧
      ∀ J : Finset (Fin (2*k)), J.card=k →
        ((Q*Qᴴ).submatrix (fun i : J => (i : Fin (2*k))) (fun i : J => (i : Fin (2*k)))).PosDef ∧
        (k:ℝ)*Real.sqrt k/4000000000 ≤
        ((Q*Qᴴ).submatrix (fun i : J => (i : Fin (2*k))) (fun i : J => (i : Fin (2*k))))⁻¹.trace := by
  obtain ⟨G,_,hlower,hrows⟩ := exists_balanced_good_matrix hk
  have hk0 : (0:ℝ)<k := by exact_mod_cast (show 0<k by omega)
  have hs : 0<Real.sqrt (k:ℝ) := Real.sqrt_pos.mpr hk0
  have hG := gram_posDef_of_unit_norm G (div_pos hs (by norm_num)) hlower
  have hgap : (Gᴴ*G-((k:ℝ)/4000000) • (1 : Matrix (Fin k) (Fin k) ℝ)).PosSemidef := by
    have h := gram_lower_of_unit_norm G (by positivity : (0:ℝ) ≤ Real.sqrt k/2000) hlower
    have he : (Real.sqrt (k:ℝ)/2000)^2=(k:ℝ)/4000000 := by
      rw [div_pow,Real.sq_sqrt hk0.le]; norm_num
    rwa [he] at h
  obtain ⟨Q,hQ,hproj⟩ := exists_gram_whitening G hG
  refine ⟨Q,hQ,?_⟩
  intro J hJ
  let e : J → Fin (2*k) := fun i => i
  have ht := hrows J hJ
  have hp : (G.submatrix e id*(G.submatrix e id)ᴴ).PosDef :=
    posDef_of_pos_inverse_trace (posSemidef_self_mul_conjTranspose _) ((div_pos hk0 (mul_pos (by norm_num) hs)).trans ht)
  have hblock := whitening_row_posDef G Q hG hproj e hp
  refine ⟨hblock,?_⟩
  have he : (G*Gᴴ).submatrix e e = G.submatrix e id*(G.submatrix e id)ᴴ := by
    ext i j; simp [Matrix.mul_apply]
  have hh := whitening_inverse_trace_lower (L := (k:ℝ)/(1000*Real.sqrt k)) G Q hG hproj (div_pos hk0 (by norm_num)) hgap e hblock (by rw [he]; exact ht.le)
  have hnum : ((k:ℝ)/4000000)*((k:ℝ)/(1000*Real.sqrt k))=(k:ℝ)*Real.sqrt k/4000000000 := by
    field_simp
    nlinarith [Real.sq_sqrt hk0.le]
  rwa [hnum] at hh

end SpectralComparison
