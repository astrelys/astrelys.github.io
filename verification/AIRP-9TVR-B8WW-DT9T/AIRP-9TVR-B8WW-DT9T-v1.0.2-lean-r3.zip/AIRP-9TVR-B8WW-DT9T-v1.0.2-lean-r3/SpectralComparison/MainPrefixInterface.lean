import SpectralComparison.MainInterface
import SpectralComparison.PrefixBound

/-! The main comparison now needs only the diffuse-tail construction contract. -/
noncomputable section
namespace SpectralComparison

/-- Main theorem for the actual matrix objective, with the prefix construction proved internally.
Only the indexed diffuse-tail bound (7.1) remains as an extra mathematical hypothesis. -/
theorem matrix_main_from_diffuse_construction {n k : ℕ} (eig : Fin n → ℝ)
    (heig : ∀ i, 0<eig i) (horder : Antitone eig) (hk : 1≤k) (hkn : k<n)
    (hdiffuse : ∀ q : ℕ, ∀ hq : q<k, (q:ℝ)≤(k:ℝ)/4 →
      let a := eig ⟨k-q-1,by omega⟩
      let V := (k:ℝ)*(∑ i ∈ Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n),eig i)/
        ((64*10^27)*((q:ℝ)+Real.sqrt k)*H (8*k))
      a*V/(a+V)≤worstError eig k) :
    worstError eig k≤spectralMean eig k ∧
      spectralMean eig k≤
        (((k:ℝ)+1)*min 1 ((768*10^27*H (min k (n-k))+1)/Real.sqrt k))*worstError eig k := by
  apply matrix_main_from_indexed_constructions eig heig horder hk hkn ?_ hdiffuse
  intro q hqk hqR
  have hq : 2*q≤k := by exact_mod_cast (show (2:ℝ)*(q:ℝ)≤k by linarith)
  have h := paper_proposition_prefix eig heig horder hk hkn hq
  have hb := (le_max_right _ _).trans h
  dsimp only at hb ⊢
  simpa only [show (32:ℝ)*10^27=32000000000000000000000000000 by norm_num] using hb

end SpectralComparison
