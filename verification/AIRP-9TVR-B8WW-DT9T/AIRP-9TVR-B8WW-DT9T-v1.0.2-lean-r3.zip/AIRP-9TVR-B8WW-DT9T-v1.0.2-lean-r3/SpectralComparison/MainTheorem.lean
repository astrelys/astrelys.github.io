import SpectralComparison.MainBound
import SpectralComparison.MainRatios
import SpectralComparison.Attainment

/-! All three numerical conclusions of the main theorem, for arbitrary positive spectra. -/
noncomputable section
namespace SpectralComparison

/-- Complete main statement for a decreasing spectrum, with (9.1), positivity and (9.2)-(9.3). -/
theorem paper_main_sorted {n k : ℕ} (eig : Fin n → ℝ)
    (heig : ∀ i,0<eig i) (horder : Antitone eig) (hk : 1≤k) (hkn : k<n) :
    worstError eig k≤spectralMean eig k ∧
      spectralMean eig k≤(((k:ℝ)+1)*min 1 ((768*10^27*H (min k (n-k))+1)/Real.sqrt k))*worstError eig k ∧
      0<worstError eig k ∧
      spectralMean eig k/worstError eig k≤((k:ℝ)+1)*min 1 ((96*10^27*H (n-k)+1)/Real.sqrt k) ∧
      spectralMean eig k/worstError eig k≤((k:ℝ)+1)*((192*10^27*H (8*k)+1)/Real.sqrt k) := by
  obtain ⟨hl,hu⟩ := paper_equation_9_1_sorted eig heig horder hk hkn
  refine ⟨hl,hu,?_⟩
  apply matrix_ratios_from_indexed_constructions eig heig horder hk hkn
  · intro q hqk hqR
    have hq : 2*q≤k := by exact_mod_cast (show (2:ℝ)*(q:ℝ)≤k by linarith)
    have hh := (le_max_right _ _).trans (paper_proposition_prefix eig heig horder hk hkn hq)
    dsimp only at hh ⊢
    simpa only [show (32:ℝ)*10^27=32000000000000000000000000000 by norm_num] using hh
  · intro q hqk hqR
    have hq : 4*q≤k := by exact_mod_cast (show (4:ℝ)*(q:ℝ)≤k by linarith)
    have hh := (le_max_right _ _).trans (paper_proposition_diffuse eig heig horder hk hkn hq)
    dsimp only at hh ⊢
    simpa only [show (64:ℝ)*10^27=64000000000000000000000000000 by norm_num] using hh

/-- Paper main theorem (9.1)-(9.3) for every positive spectrum and 1<=k<n.
The actual residualTrace/bestError/worstError definitions are used throughout;
worstError_attained and bestError_attained establish the manuscript's max/min semantics. -/
theorem paper_main_theorem {n k : ℕ} (eig : Fin n → ℝ)
    (heig : ∀ i,0<eig i) (hk : 1≤k) (hkn : k<n) :
    worstError eig k≤spectralMean eig k ∧
      spectralMean eig k≤(((k:ℝ)+1)*min 1 ((768*10^27*H (min k (n-k))+1)/Real.sqrt k))*worstError eig k ∧
      0<worstError eig k ∧
      spectralMean eig k/worstError eig k≤((k:ℝ)+1)*min 1 ((96*10^27*H (n-k)+1)/Real.sqrt k) ∧
      spectralMean eig k/worstError eig k≤((k:ℝ)+1)*((192*10^27*H (8*k)+1)/Real.sqrt k) := by
  let e := Tuple.sort (α:=OrderDual ℝ) eig
  have ho : Antitone (eig ∘ e) := Tuple.monotone_sort (α:=OrderDual ℝ) eig
  have hh := paper_main_sorted (eig ∘ e) (fun _ => heig _) ho hk hkn
  simpa only [worstError_comp_equiv,spectralMean_comp_equiv] using hh

end SpectralComparison
