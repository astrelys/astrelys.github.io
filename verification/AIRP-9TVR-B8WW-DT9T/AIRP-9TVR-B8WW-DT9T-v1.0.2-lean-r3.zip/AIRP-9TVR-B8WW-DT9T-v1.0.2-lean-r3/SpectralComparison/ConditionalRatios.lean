import SpectralComparison.ConditionalMain

/-! The two precise ratio conclusions of the main theorem. -/
namespace SpectralComparison

/-- The threshold contracts give positivity and both sharper ratios (9.2)-(9.3). -/
theorem main_ratios_from_construction_contracts (head tail : Multiset ℝ)
    (hh : ∀ z ∈ head, 0 < z) (ht : ∀ z ∈ tail, 0 < z)
    (hk : 1 ≤ head.card) (hm : 1 ≤ tail.card) (x : ℝ)
    (hdiag : tail.sum ≤ x)
    (hprefix : ∀ a : ℝ, 0 < a →
      (((head.filter (fun z => z < a)).card:ℝ) ≤ (head.card:ℝ)/2) →
      let U := (head.card:ℝ)*tail.sum /
        ((32*10^27)*(((head.filter (fun z => z < a)).card:ℝ)+Real.sqrt head.card)*H tail.card)
      a*U/(a+U) ≤ x)
    (hdiffuse : ∀ a : ℝ, 0 < a →
      (((head.filter (fun z => z < a)).card:ℝ) ≤ (head.card:ℝ)/4) →
      let V := (head.card:ℝ)*tail.sum /
        ((64*10^27)*(((head.filter (fun z => z < a)).card:ℝ)+Real.sqrt head.card)*H (8*head.card))
      a*V/(a+V) ≤ x) :
    let F := (head+tail).esymm (head.card+1)/(head+tail).esymm head.card
    0<x ∧
      (((head.card:ℝ)+1)*F)/x≤((head.card:ℝ)+1)*min 1 ((96*10^27*H tail.card+1)/Real.sqrt head.card) ∧
      (((head.card:ℝ)+1)*F)/x≤((head.card:ℝ)+1)*((192*10^27*H (8*head.card)+1)/Real.sqrt head.card) := by
  classical
  let F := (head+tail).esymm (head.card+1)/(head+tail).esymm head.card
  let r := Real.sqrt (head.card:ℝ)
  let q := (head.filter (fun z => z < r*F)).card
  let y := ((head.card:ℝ)+1)*F
  change 0<x ∧ y/x≤((head.card:ℝ)+1)*min 1 ((96*10^27*H tail.card+1)/r) ∧
    y/x≤((head.card:ℝ)+1)*((192*10^27*H (8*head.card)+1)/r)
  have hall : ∀ w ∈ head+tail, 0 < w := by
    intro w hw
    rcases Multiset.mem_add.mp hw with hw | hw
    · exact hh w hw
    · exact ht w hw
  have hF : 0 < F := div_pos
    (esymm_pos (head+tail) hall (head.card+1) (by simp; omega))
    (esymm_pos (head+tail) hall head.card (by simp))
  have hFS : F ≤ tail.sum := symmetric_quotient_le_tail head tail hh ht
  have hx : 0 < x := lt_of_lt_of_le (hF.trans_le hFS) hdiag
  have hkR : (1:ℝ) ≤ head.card := by exact_mod_cast hk
  have hr : 1 ≤ r := Real.one_le_sqrt.mpr hkR
  have hr0 : 0 < r := by linarith
  have hr2 : r^2 = (head.card:ℝ) := Real.sq_sqrt (by positivity)
  have hq0 : (0:ℝ) ≤ q := by positivity
  have hq : (q:ℝ) ≤ (1+r)*(tail.sum/F) := by
    have hcount := multiset_threshold_count hF hr0.le head (fun z hz => (hh z hz).le)
    have hsum := symmetric_quotient_head_sum_le_tail head tail hh ht hk hm
    have hle : (q:ℝ)/(1+r) ≤ tail.sum/F := hcount.trans hsum
    have hmul := (div_le_iff₀ (show 0 < 1+r by positivity)).mp hle
    nlinarith
  have hH : 1 ≤ H tail.card := one_le_H hm
  have hH8 : 1 ≤ H (8*head.card) := one_le_H (by omega)
  have hbase : y/x ≤ (head.card:ℝ)+1 := by
    apply (div_le_iff₀ hx).2
    exact mul_le_mul_of_nonneg_left (hFS.trans hdiag) (by positivity)
  have hshort : y/x ≤ ((head.card:ℝ)+1)*((96*10^27*H tail.card+1)/r) := by
    have hcase := tail_comparison_from_inputs (r:=r) (F:=F) (s:=tail.sum)
      (q:=(q:ℝ)) (C:=32*10^27) (H:=H tail.card) (d:=4)
      (x:=x) (y:=y) (k:=(head.card:ℝ)) hr hF hFS hq0 hq
      (by norm_num) (by linarith) (by norm_num) (by nlinarith) hx hdiag
      (by positivity) rfl (by
        intro hqr
        refine ⟨r*F, le_rfl, ?_⟩
        have hqr' : (q:ℝ) ≤ (head.card:ℝ)/2 := by nlinarith [hr2]
        have hc := hprefix (r*F) (mul_pos hr0 hF) hqr'
        simpa only [hr2] using hc)
    convert hcase using 1
    ring
  have hlong : y/x ≤ ((head.card:ℝ)+1)*((192*10^27*H (8*head.card)+1)/r) := by
    have hcase := tail_comparison_from_inputs (r:=r) (F:=F) (s:=tail.sum)
      (q:=(q:ℝ)) (C:=64*10^27) (H:=H (8*head.card)) (d:=8)
      (x:=x) (y:=y) (k:=(head.card:ℝ)) hr hF hFS hq0 hq
      (by norm_num) (by linarith) (by norm_num) (by nlinarith) hx hdiag
      (by positivity) rfl (by
        intro hqr
        refine ⟨r*F, le_rfl, ?_⟩
        have hqr' : (q:ℝ) ≤ (head.card:ℝ)/4 := by nlinarith [hr2]
        have hc := hdiffuse (r*F) (mul_pos hr0 hF) hqr'
        simpa only [hr2] using hc)
    convert hcase using 1
    ring
  refine ⟨hx,?_,hlong⟩
  rw [mul_min_of_nonneg _ _ (by positivity : (0:ℝ)≤(head.card:ℝ)+1)]
  simpa only [mul_one] using le_min hbase hshort

end SpectralComparison
