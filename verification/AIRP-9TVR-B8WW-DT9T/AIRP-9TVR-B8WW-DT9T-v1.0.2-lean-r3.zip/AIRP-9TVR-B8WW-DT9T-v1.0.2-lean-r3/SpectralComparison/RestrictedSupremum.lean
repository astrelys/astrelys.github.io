import SpectralComparison.SpectralCapping
import Mathlib.Data.EReal.Operations

/-! The original unrestricted and capped global extended-real suprema. -/
noncomputable section
namespace SpectralComparison

def globalRatioSupremum : EReal :=
  ⨆ (n : ℕ) (k : ℕ) (a : Fin n → ℝ) (_ : 1≤k) (_ : k<n) (_ : ∀ i,0<a i),
    ((spectralMean a k/worstError a k : ℝ):EReal)

def cappedRatioSupremum : EReal :=
  ⨆ (n : ℕ) (k : ℕ) (a : Fin n → ℝ) (_ : 1≤k) (_ : k<n) (_ : ∀ i,0<a i)
    (_ : ∀ i,a i≤2*spectralMean a k), ((spectralMean a k/worstError a k : ℝ):EReal)

theorem ratio_le_globalSup {n k : ℕ} (a : Fin n → ℝ) (hk : 1≤k) (hkn : k<n) (ha : ∀ i,0<a i) :
    ((spectralMean a k/worstError a k:ℝ):EReal)≤globalRatioSupremum := by
  exact le_iSup_of_le n (le_iSup_of_le k (le_iSup_of_le a (le_iSup_of_le hk (le_iSup_of_le hkn (le_iSup_of_le ha le_rfl)))))

theorem ratio_le_cappedSup {n k : ℕ} (a : Fin n → ℝ) (hk : 1≤k) (hkn : k<n) (ha : ∀ i,0<a i)
    (hcap : ∀ i,a i≤2*spectralMean a k) :
    ((spectralMean a k/worstError a k:ℝ):EReal)≤cappedRatioSupremum := by
  exact le_iSup_of_le n (le_iSup_of_le k (le_iSup_of_le a (le_iSup_of_le hk (le_iSup_of_le hkn (le_iSup_of_le ha (le_iSup_of_le hcap le_rfl))))))

theorem cappedSup_le_globalSup : cappedRatioSupremum≤globalRatioSupremum := by
  apply iSup_le; intro n
  apply iSup_le; intro k
  apply iSup_le; intro a
  apply iSup_le; intro hk
  apply iSup_le; intro hkn
  apply iSup_le; intro ha
  apply iSup_le; intro _
  exact ratio_le_globalSup a hk hkn ha

theorem globalSup_le_twice_cappedSup : globalRatioSupremum≤2*cappedRatioSupremum := by
  apply iSup_le; intro n
  apply iSup_le; intro k
  apply iSup_le; intro a
  apply iSup_le; intro hk
  apply iSup_le; intro hkn
  apply iSup_le; intro ha
  let c := fun i => min (a i) (spectralMean a k)
  have h := paper_capping a ha hk hkn
  have hy : 0<spectralMean a k := (paper_main_theorem a ha hk hkn).2.2.1.trans_le (worstError_le_spectralMean a ha (by simpa using hkn))
  have hc : ∀ i,0<c i := fun i => lt_min (ha i) hy
  have hr := EReal.coe_le_coe_iff.mpr h.2.2.2
  rw [EReal.coe_mul] at hr
  exact hr.trans (mul_le_mul_of_nonneg_left (ratio_le_cappedSup c hk hkn hc h.2.2.1) (by norm_num))

theorem cappedSup_nonneg : 0≤cappedRatioSupremum := by
  let a : Fin 2 → ℝ := fun _ => 1
  have ha : ∀ i,0<a i := by intro i; norm_num [a]
  let c := fun i => min (a i) (spectralMean a 1)
  have hm := paper_main_theorem (k:=1) a ha (by omega) (by omega)
  have hc : ∀ i,0<c i := fun i => lt_min (ha i) (hm.2.2.1.trans_le hm.1)
  have h := paper_capping (k:=1) a ha (by omega) (by omega)
  have hmc := paper_main_theorem (k:=1) c hc (by omega) (by omega)
  have hp : 0≤spectralMean c 1/worstError c 1 := div_nonneg (hmc.2.2.1.le.trans hmc.1) hmc.2.2.1.le
  exact (EReal.coe_nonneg.mpr hp).trans (ratio_le_cappedSup c (by omega) (by omega) hc h.2.2.1)

/-- The complete original restricted-supremum corollary, including finiteness equivalence. -/
theorem paper_capped_supremum :
    0≤cappedRatioSupremum ∧ cappedRatioSupremum≤globalRatioSupremum ∧
      globalRatioSupremum≤2*cappedRatioSupremum ∧
      (globalRatioSupremum<⊤ ↔ cappedRatioSupremum<⊤) := by
  refine ⟨cappedSup_nonneg,cappedSup_le_globalSup,globalSup_le_twice_cappedSup,?_,?_⟩
  · intro h; exact cappedSup_le_globalSup.trans_lt h
  · intro h
    obtain ⟨M,hM,_⟩ := EReal.exists_between_coe_real h
    have hh := mul_le_mul_of_nonneg_left hM.le (by norm_num : (0:EReal)≤2)
    have ht : (2:EReal)*(M:EReal)<⊤ := by
      rw [show (2:EReal)=(2:ℝ) by norm_cast,← EReal.coe_mul]
      exact EReal.coe_lt_top _
    exact (globalSup_le_twice_cappedSup.trans hh).trans_lt ht

end SpectralComparison
