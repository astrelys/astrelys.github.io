import SpectralComparison.NormalizedShape

noncomputable section
open Filter Topology Finset
namespace SpectralComparison

/-- Vanishing normalized deficit eventually gives every requested finite head scale. -/
theorem eventual_normalized_shape {α : Type*} {l : Filter α} {n k : ℕ}
    (a : α → Fin n → ℝ) (ha : ∀ t i,0 < a t i) (horder : ∀ t,Antitone (a t))
    (hk : 1 ≤ k) (hkn : k < n) (hm : 2 ≤ n-k) (hroot : ∀ t,waterSum (a t) 1 = k)
    (hD : Tendsto (fun t => normalizedHarmonicDeficit (a t) k) l (𝓝 0))
    {L : ℝ} (hL : 1 < L) :
    ∀ᶠ t in l,(∀ i : Fin n,i.val < k → L ≤ a t i) ∧
      (∀ i,1-(n:ℝ)*normalizedHarmonicDeficit (a t) k/k ≤ a t i) := by
  have hk0 : (0:ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hn0 : (0:ℝ) < n := by exact_mod_cast (show 0 < n by omega)
  have hL0 : 0 < L := (by norm_num : (0:ℝ) < 1).trans hL
  have hsmall := hD.eventually (eventually_lt_nhds (show (0:ℝ) < (k:ℝ)/(2*n) by positivity))
  have hs : Tendsto (fun t => (2:ℝ)^(n+1)*normalizedHarmonicDeficit (a t) k) l (𝓝 0) := by
    simpa only [mul_zero] using hD.const_mul ((2:ℝ)^(n+1))
  have hexp := hs.eventually (eventually_lt_nhds (show (0:ℝ) < 1/L by positivity))
  filter_upwards [hsmall,hexp] with t ht he
  exact normalized_deficit_shape (a t) (ha t) (horder t) hk hkn hm (hroot t) hL ht he.le

/-- Vanishing deficit implies exactly the k leading coordinates diverge and all remaining coordinates tend to one. -/
theorem normalized_deficit_classification {α : Type*} {l : Filter α} {n k : ℕ}
    (a : α → Fin n → ℝ) (ha : ∀ t i,0 < a t i) (horder : ∀ t,Antitone (a t))
    (hk : 2 ≤ k) (hkn : k < n) (hm : 2 ≤ n-k) (hroot : ∀ t,waterSum (a t) 1 = k)
    (hD : Tendsto (fun t => normalizedHarmonicDeficit (a t) k) l (𝓝 0)) :
    (∀ i : Fin n,i.val < k → Tendsto (fun t => a t i) l atTop) ∧
      (∀ i : Fin n,k ≤ i.val → Tendsto (fun t => a t i) l (𝓝 1)) := by
  have hk0 : (0:ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hk1 : (1:ℝ) < k := by exact_mod_cast (show 1 < k by omega)
  constructor
  · intro i hi
    apply tendsto_atTop.2
    intro B
    have hh := eventual_normalized_shape a ha horder (by omega) hkn hm hroot hD
      (L:=max 2 B) (lt_of_lt_of_le (by norm_num : (1:ℝ) < 2) (le_max_left _ _))
    filter_upwards [hh] with t ht
    exact (le_max_right 2 B).trans (ht.1 i hi)
  · intro i hi
    apply tendsto_order.2
    constructor
    · intro y hy
      have hlower : Tendsto (fun t => 1-(n:ℝ)*normalizedHarmonicDeficit (a t) k/k) l (𝓝 1) := by
        simpa only [mul_zero,zero_div,sub_zero] using tendsto_const_nhds.sub ((hD.const_mul (n:ℝ)).div_const (k:ℝ))
      have he := hlower.eventually (eventually_gt_nhds hy)
      have hh := eventual_normalized_shape a ha horder (by omega) hkn hm hroot hD (L:=2) (by norm_num)
      filter_upwards [he,hh] with t ht hs
      exact ht.trans_le (hs.2 i)
    · intro y hy
      let δ := (y-1)/2
      have hδ : 0 < δ := by dsimp [δ]; linarith
      let L := (k:ℝ)*(1+δ)/δ
      have hLk : (k:ℝ) < L := by
        apply (lt_div_iff₀ hδ).mpr
        nlinarith
      have hL0 : 0 < L := hk0.trans hLk
      have hL1 : 1 < L := hk1.trans hLk
      have hh := eventual_normalized_shape a ha horder (by omega) hkn hm hroot hD hL1
      have he : 1/(1-(k:ℝ)/L) = 1+δ := by
        dsimp [L]
        field_simp
        ring
      filter_upwards [hh] with t ht
      have hu := normalized_tail_upper_of_head (a t) (ha t) (by omega) hkn (hroot t) hLk ht.1 i hi
      rw [he] at hu
      have hy' : 1+δ < y := by dsimp [δ]; linarith
      exact hu.trans_lt hy'

/-- The near-equality ratio forces the actual normalized deficit to vanish. -/
theorem harmonic_ratio_deficit_limit {α : Type*} {l : Filter α} {n k : ℕ}
    (a : α → Fin n → ℝ) (ha : ∀ t i,0 < a t i)
    (hk : 1 ≤ k) (hkn : k < n) (hm : 2 ≤ n-k) (hroot : ∀ t,waterSum (a t) 1 = k)
    (hratio : Tendsto (fun t => spectralMean (a t) k / normalizedHarmonicTrace (a t)) l
      (𝓝 (((k:ℝ)+1)*(n-k:ℕ)/(n:ℝ)))) :
    Tendsto (fun t => normalizedHarmonicDeficit (a t) k) l (𝓝 0) := by
  let C := ((k:ℝ)+1)*(n-k:ℕ)/(n:ℝ)
  let E := fun t => C-spectralMean (a t) k/normalizedHarmonicTrace (a t)
  have hn0 : (0:ℝ) < n := by exact_mod_cast (show 0 < n by omega)
  have hc : (0:ℝ) < (k:ℝ)+1 := by positivity
  have heq (t) : normalizedHarmonicDeficit (a t) k = normalizedHarmonicTrace (a t)/((k:ℝ)+1)*E t := by
    have hb := (normalizedHarmonicTrace_bounds (by omega) (a t) (ha t)).1
    dsimp [normalizedHarmonicDeficit,E,C]
    rw [spectralMean_eq_quotient]
    field_simp
  have hD0 (t) := normalized_deficit_nonneg (a t) (ha t) hk hkn hm (hroot t)
  have hE0 (t) : 0 ≤ E t := by
    have hb := (normalizedHarmonicTrace_bounds (by omega) (a t) (ha t)).1
    have hh := hD0 t
    rw [heq] at hh
    exact nonneg_of_mul_nonneg_right hh (div_pos hb hc)
  have hbound (t) : normalizedHarmonicDeficit (a t) k ≤ (n:ℝ)/((k:ℝ)+1)*E t := by
    rw [heq]
    exact mul_le_mul_of_nonneg_right
      (div_le_div_of_nonneg_right (normalizedHarmonicTrace_bounds (by omega) (a t) (ha t)).2 hc.le) (hE0 t)
  have hE : Tendsto E l (𝓝 0) := by
    have hh : Tendsto E l (𝓝 (C-C)) := tendsto_const_nhds.sub hratio
    simpa only [sub_self] using hh
  have hU : Tendsto (fun t => (n:ℝ)/((k:ℝ)+1)*E t) l (𝓝 0) := by
    simpa only [mul_zero] using hE.const_mul ((n:ℝ)/((k:ℝ)+1))
  exact tendsto_of_tendsto_of_tendsto_of_le_of_le tendsto_const_nhds hU hD0 hbound

/-- The unnumbered near-equality classification following D.2, with no equality-of-rates premise. -/
theorem normalized_harmonic_near_equality {α : Type*} {l : Filter α} {n k : ℕ}
    (a : α → Fin n → ℝ) (ha : ∀ t i,0 < a t i) (horder : ∀ t,Antitone (a t))
    (hk : 2 ≤ k) (hkn : k < n) (hm : 2 ≤ n-k) (hroot : ∀ t,waterSum (a t) 1 = k)
    (hratio : Tendsto (fun t => spectralMean (a t) k / normalizedHarmonicTrace (a t)) l
      (𝓝 (((k:ℝ)+1)*(n-k:ℕ)/(n:ℝ)))) :
    Tendsto (fun t => normalizedHarmonicDeficit (a t) k) l (𝓝 0) ∧
    (∀ i : Fin n,i.val < k → Tendsto (fun t => a t i) l atTop) ∧
    (∀ i : Fin n,k ≤ i.val → Tendsto (fun t => a t i) l (𝓝 1)) := by
  have hD := harmonic_ratio_deficit_limit a ha (by omega) hkn hm hroot hratio
  exact ⟨hD,normalized_deficit_classification a ha horder hk hkn hm hroot hD⟩

/-- Near equality in the original maximum harmonic-prefix comparison has the stated exact spectral classification. -/
theorem paper_harmonic_near_equality {α : Type*} {l : Filter α} {n k : ℕ}
    (a : α → Fin n → ℝ) (ha : ∀ t i,0 < a t i) (horder : ∀ t,Antitone (a t))
    (hk : 2 ≤ k) (hkn : k < n) (hm : 2 ≤ n-k) (hroot : ∀ t,waterSum (a t) 1 = k)
    (hratio : Tendsto (fun t => spectralMean (a t) k / harmonicEnvelope (a t) k hkn) l
      (𝓝 (((k:ℝ)+1)*(n-k:ℕ)/(n:ℝ)))) :
    Tendsto (fun t => normalizedHarmonicDeficit (a t) k) l (𝓝 0) ∧
    (∀ i : Fin n,i.val < k → Tendsto (fun t => a t i) l atTop) ∧
    (∀ i : Fin n,k ≤ i.val → Tendsto (fun t => a t i) l (𝓝 1)) := by
  have he (t) := harmonicEnvelope_eq_normalized (a t) (ha t) (horder t) (by omega) hkn (hroot t)
  simp_rw [he] at hratio
  exact normalized_harmonic_near_equality a ha horder hk hkn hm hroot hratio

end SpectralComparison
