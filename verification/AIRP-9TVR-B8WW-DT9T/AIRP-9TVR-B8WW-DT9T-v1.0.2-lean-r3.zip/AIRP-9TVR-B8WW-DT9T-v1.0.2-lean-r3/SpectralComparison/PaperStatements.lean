import SpectralComparison.ConditionalMain

/-! Statements in the paper's indexed-list convention. This module is a
separate semantic interface: k is the number of leading entries, and the tail
is literally drop k. Ordering is unnecessary for Lemma 8.1. -/
namespace SpectralComparison

/-- Paper Lemma 8.1 (equation 8.1) on a positive list of length n, 1 ≤ k < n.
`take k` is indices 1,...,k and `drop k` is indices k+1,...,n.
The elementary symmetric polynomial is mathlib's sum of products over all
cardinality-k submultisets, retaining multiplicity. -/
theorem paper_lemma_8_1 (eig : List ℝ) (k : ℕ)
    (hpos : ∀ z ∈ eig, 0 < z) (hk : 1 ≤ k) (hkn : k < eig.length) :
    let F := (eig : Multiset ℝ).esymm (k+1) / (eig : Multiset ℝ).esymm k
    F ≤ (eig.drop k).sum ∧
      ((eig.take k).map (fun z => F/(z+F))).sum ≤ (eig.drop k).sum/F := by
  have ht : ∀ z ∈ (eig.take k : Multiset ℝ), 0 < z := by
    intro z hz
    exact hpos z (List.mem_of_mem_take (by simpa using hz))
  have hd : ∀ z ∈ (eig.drop k : Multiset ℝ), 0 < z := by
    intro z hz
    exact hpos z (List.mem_of_mem_drop (by simpa using hz))
  have hc : (eig.take k : Multiset ℝ).card = k := by simp [Nat.min_eq_left hkn.le]
  have hdc : 1 ≤ (eig.drop k : Multiset ℝ).card := by simp; omega
  have hadd : (eig.take k : Multiset ℝ) + (eig.drop k : Multiset ℝ) = (eig : Multiset ℝ) := by
    rw [Multiset.coe_add, List.take_append_drop]
  have h := elementary_symmetric_quotient (eig.take k) (eig.drop k) ht hd
    (by simpa [hc] using hk) hdc
  simpa only [hc, hadd, Multiset.sum_coe, Multiset.map_coe] using h

end SpectralComparison
