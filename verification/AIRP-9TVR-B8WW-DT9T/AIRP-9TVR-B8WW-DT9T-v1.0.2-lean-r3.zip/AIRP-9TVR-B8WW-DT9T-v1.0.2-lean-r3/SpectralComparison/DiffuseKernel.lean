import SpectralComparison.DiffuseBlock

/-! Exact kernel of the group covariance, from its displayed prescribed spectrum. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- The orthogonal synthesis with spectrum (0,d), d>0, has precisely its first-column kernel. -/
theorem diffuse_block_kernel_iff {p : ℕ} (d : Fin p → ℝ) (hd : ∀ j,0<d j)
    (W : Matrix (Fin 1 ⊕ Fin p) (Fin 1 ⊕ Fin p) ℝ) (hW : Wᴴ*W=1)
    (x : (Fin 1 ⊕ Fin p) → ℝ) :
    (W*Matrix.diagonal (Sum.elim (fun _ : Fin 1 => (0:ℝ)) d)*Wᴴ).mulVec x=0 ↔
      ∃ c : ℝ, x=fun i => c*W i (Sum.inl 0) := by
  classical
  have hW' : W*Wᴴ=1 := mul_eq_one_comm.mp hW
  let b : Fin 1 ⊕ Fin p → ℝ := Sum.elim (fun _ => (0:ℝ)) d
  let y := Wᴴ.mulVec x
  have hxy : W.mulVec y=x := by dsimp [y]; rw [Matrix.mulVec_mulVec,hW',Matrix.one_mulVec]
  constructor
  · intro hx
    have hb : (Matrix.diagonal b).mulVec y=0 := by
      have hh := congrArg Wᴴ.mulVec hx
      change Wᴴ.mulVec ((W*Matrix.diagonal b*Wᴴ).mulVec x)=Wᴴ.mulVec 0 at hh
      rw [Matrix.mulVec_zero,Matrix.mulVec_mulVec] at hh
      have he : Wᴴ*(W*Matrix.diagonal b*Wᴴ)=Matrix.diagonal b*Wᴴ := by
        rw [← Matrix.mul_assoc,← Matrix.mul_assoc,hW,Matrix.one_mul]
      rw [he,← Matrix.mulVec_mulVec] at hh
      exact hh
    have hy (j : Fin p) : y (Sum.inr j)=0 := by
      have hh := congrFun hb (Sum.inr j)
      simp [Matrix.mulVec,dotProduct,Matrix.diagonal_apply,b] at hh
      exact hh.resolve_left (ne_of_gt (hd j))
    have hys : y=Pi.single (Sum.inl 0) (y (Sum.inl 0)) := by
      ext i
      cases i with
      | inl i => have hi : i=0 := Subsingleton.elim _ _; subst i; simp
      | inr i => simp [hy i]
    refine ⟨y (Sum.inl 0),?_⟩
    rw [← hxy,hys]
    ext i
    simp [mul_comm]
  · rintro ⟨c,rfl⟩
    have he : (fun i => c*W i (Sum.inl 0))=W.mulVec (Pi.single (Sum.inl 0) c) := by
      ext i
      simp [mul_comm]
    rw [he,Matrix.mulVec_mulVec]
    change ((W*Matrix.diagonal b*Wᴴ)*W).mulVec _=0
    rw [Matrix.mul_assoc (W*Matrix.diagonal b),hW,Matrix.mul_one,← Matrix.mulVec_mulVec,Matrix.diagonal_mulVec_single]
    simp [b]

/-- Equation (7.4), including exact kernel and nonzero entries, with one prescribed-spectrum witness. -/
theorem paper_equation_7_4 {p : ℕ} (d : Fin p → ℝ) (hd : ∀ j,0<d j) :
    ∃ W : Matrix (Fin 1 ⊕ Fin p) (Fin 1 ⊕ Fin p) ℝ,
      Wᴴ*W=1 ∧ W*Wᴴ=1 ∧
      let u := fun i => W i (Sum.inl 0)
      let D := W*Matrix.diagonal (Sum.elim (fun _ : Fin 1 => (0:ℝ)) d)*Wᴴ
      D.PosSemidef ∧ (∑ i,u i*u i)=1 ∧
      (∀ x,D.mulVec x=0 ↔ ∃ c : ℝ,x=fun i => c*u i) ∧
      (∀ i,D i i=(∑ j,d j)*(u i)^2) ∧ (∀ i,u i≠0) := by
  obtain ⟨W,hW,hW',hD,hu,_hker,hdiag,huneq⟩ := exists_diffuse_group_block d hd
  exact ⟨W,hW,hW',hD,hu,fun x => diffuse_block_kernel_iff d hd W hW x,hdiag,huneq⟩

end SpectralComparison
