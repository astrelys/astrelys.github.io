import SpectralComparison.FrameTransfer

/-! Complete uniform principal-block projection lemma, including replication and all dimensions. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- A uniform frame in every dimension N>=ceil(4p/3), with the manuscript's C0. -/
theorem exists_uniform_projection_frame {N t q : ℕ} (ht : 1 ≤ t)
    (hN : 4*(t+q) ≤ 3*N) :
    ∃ V : Matrix (Fin N) (Fin (t+q)) ℝ, Vᴴ*V=1 ∧
      ∀ J : Finset (Fin N), J.card=t → IsUnit ((V*Vᴴ).submatrix (fun i : J => (i:Fin N)) (fun i : J => (i:Fin N))) →
        (N:ℝ)*t/(4000000000000000000000000000*((q:ℝ)+Real.sqrt (t+q:ℕ))) ≤
        ((V*Vᴴ).submatrix (fun i : J => (i:Fin N)) (fun i : J => (i:Fin N)))⁻¹.trace := by
  let n := min N (2*(t+q))
  let h := N/n
  have hnpos : 0<n := by dsimp [n]; omega
  have hnN : n≤N := min_le_left _ _
  have hnp : n≤2*(t+q) := min_le_right _ _
  have hnlow : 4*(t+q)≤3*n := by dsimp [n]; omega
  have hh : 0<h := Nat.div_pos hnN hnpos
  obtain ⟨V,hV,hblocks⟩ := exists_base_frame_all_dimensions ht hnlow hnp
  let W : Matrix (Fin n × Fin h) (Fin (t+q)) ℝ := Matrix.of (fun i j => V i.1 j/Real.sqrt h)
  have hW : Wᴴ*W=1 := replicated_frame_orthonormal V hV hh
  let L : ℝ := ((t+q:ℕ):ℝ)*t/(1000000000000000000000000000*((q:ℝ)+Real.sqrt (t+q:ℕ)))
  have hWb : ∀ J : Finset (Fin n × Fin h), J.card=t → IsUnit ((W*Wᴴ).submatrix
      (fun i : J => (i:Fin n × Fin h)) (fun i : J => (i:Fin n × Fin h))) →
      (h:ℝ)*L ≤ ((W*Wᴴ).submatrix (fun i : J => (i:Fin n × Fin h)) (fun i : J => (i:Fin n × Fin h)))⁻¹.trace := by
    intro J hJ hu
    have he : W*Wᴴ=(h:ℝ)⁻¹ • (V*Vᴴ).submatrix Prod.fst Prod.fst := replicated_frame_gram V hh
    rw [he] at hu ⊢
    exact replicated_principal_inverse_trace (V*Vᴴ) (posSemidef_self_mul_conjTranspose V) hh hblocks J hJ hu
  let U := Matrix.fromRows W (0 : Matrix (Fin (N%n)) (Fin (t+q)) ℝ)
  have hU : Uᴴ*U=1 := zero_padded_frame_orthonormal W hW
  have hUb := zero_padded_principal_inverse_trace (r := Fin (N%n)) W hWb
  have hdim : n*h+N%n=N := by dsimp [h]; exact Nat.div_add_mod N n
  let e : Fin N ≃ (Fin n × Fin h) ⊕ Fin (N%n) := Fintype.equivOfCardEq (by simpa using hdim.symm)
  obtain ⟨T,hT,hTb⟩ := reindex_frame_control U hU hUb e
  refine ⟨T,hT,?_⟩
  intro J hJ hu
  apply le_trans _ (hTb J hJ hu)
  have hrem : N%n<n := Nat.mod_lt N hnpos
  have hmult : n≤n*h := by nlinarith
  have hbound : N≤4*h*(t+q) := by nlinarith
  have hnreal : (N:ℝ)≤4*(h:ℝ)*(t+q:ℕ) := by exact_mod_cast hbound
  have hd : 0 < (q:ℝ)+Real.sqrt (t+q:ℕ) := add_pos_of_nonneg_of_pos (Nat.cast_nonneg q)
    (Real.sqrt_pos.mpr (by exact_mod_cast (show 0<t+q by omega)))
  have hb := div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_right hnreal (Nat.cast_nonneg (α := ℝ) t))
    (mul_nonneg (by norm_num : (0:ℝ)≤4000000000000000000000000000) hd.le)
  convert hb using 1
  dsimp [L]
  simp only [div_eq_mul_inv,_root_.mul_inv_rev]
  ring

/-- Paper Lemma 4.1 / equation (4.1), with C0=4*10^27. Its regularization
conclusion holds even for singular principal blocks. The local T formulation
is stronger than applying it only to the principal blocks of a global T. -/
theorem uniform_projection_local_regularization {N t q : ℕ} (ht : 1 ≤ t) (hN : 4*(t+q)≤3*N) :
    ∃ P : Matrix (Fin N) (Fin N) ℝ, P.IsHermitian ∧ P*P=P ∧ P.rank=t+q ∧
      (∀ J : Finset (Fin N), J.card=t → IsUnit (P.submatrix (fun i : J => (i:Fin N)) (fun i : J => (i:Fin N))) →
        (N:ℝ)*t/(4000000000000000000000000000*((q:ℝ)+Real.sqrt (t+q:ℕ))) ≤
        (P.submatrix (fun i : J => (i:Fin N)) (fun i : J => (i:Fin N)))⁻¹.trace) ∧
      (∀ (J : Finset (Fin N)) (T : Matrix J J ℝ) (α β : ℝ), J.card=t → T.PosDef → 0<α → 0<β →
        (α • 1 + β • P.submatrix (fun i : J => (i:Fin N)) (fun i : J => (i:Fin N)) - T).PosSemidef →
        let L := (N:ℝ)*t/(4000000000000000000000000000*((q:ℝ)+Real.sqrt (t+q:ℕ)))
        L/(β+α*L) ≤ T⁻¹.trace) := by
  obtain ⟨V,hV,hblocks⟩ := exists_uniform_projection_frame ht hN
  obtain ⟨hs,hi,hr⟩ := frame_projection_properties V hV
  refine ⟨V*Vᴴ,hs,hi,by simpa using hr,hblocks,?_⟩
  intro J T α β hJ hT hα hβ hgap
  apply matrix_regularization ((posSemidef_self_mul_conjTranspose V).submatrix _) hT hα hβ
  · apply div_pos
    · exact mul_pos (by exact_mod_cast (show 0<N by omega)) (by exact_mod_cast (show 0<t by omega))
    · apply mul_pos (by norm_num)
      exact add_pos_of_nonneg_of_pos (Nat.cast_nonneg q)
        (Real.sqrt_pos.mpr (by exact_mod_cast (show 0<t+q by omega)))
  · exact hblocks J hJ
  · exact hgap

/-- Exact global-T form of paper Lemma 4.1 and its equation (2.3) consequence.
The integer hypothesis 4*(t+q)<=3*N is equivalent to N>=ceil(4*(t+q)/3). -/
theorem paper_lemma_4_1 {N t q : ℕ} (ht : 1 ≤ t) (hN : 4*(t+q)≤3*N) :
    ∃ P : Matrix (Fin N) (Fin N) ℝ, P.IsHermitian ∧ P*P=P ∧ P.rank=t+q ∧
      (∀ J : Finset (Fin N), J.card=t → IsUnit (P.submatrix (fun i : J => (i:Fin N)) (fun i : J => (i:Fin N))) →
        (N:ℝ)*t/(4000000000000000000000000000*((q:ℝ)+Real.sqrt (t+q:ℕ))) ≤
        (P.submatrix (fun i : J => (i:Fin N)) (fun i : J => (i:Fin N)))⁻¹.trace) ∧
      (∀ (T : Matrix (Fin N) (Fin N) ℝ) (α β : ℝ), T.PosDef → 0<α → 0<β →
        (α • 1 + β • P - T).PosSemidef →
        ∀ J : Finset (Fin N), J.card=t →
        let L := (N:ℝ)*t/(4000000000000000000000000000*((q:ℝ)+Real.sqrt (t+q:ℕ)))
        L/(β+α*L) ≤ (T.submatrix (fun i : J => (i:Fin N)) (fun i : J => (i:Fin N)))⁻¹.trace) := by
  obtain ⟨P,hs,hi,hr,hb,hreg⟩ := uniform_projection_local_regularization ht hN
  refine ⟨P,hs,hi,hr,hb,?_⟩
  intro T α β hT hα hβ hgap J hJ
  let e : J → Fin N := fun i => i
  have hI : (1 : Matrix (Fin N) (Fin N) ℝ).submatrix e e=1 :=
    Matrix.submatrix_one e Subtype.val_injective
  have he : (α • 1 + β • P - T).submatrix e e = α • 1 + β • P.submatrix e e - T.submatrix e e := by
    ext a b
    have hh := congrFun (congrFun hI a) b
    simp only [Matrix.submatrix_apply] at hh
    simp only [Matrix.submatrix_apply,Matrix.sub_apply,Matrix.add_apply,Matrix.smul_apply,hh]
  have hlocal := hgap.submatrix e
  rw [he] at hlocal
  exact hreg J (T.submatrix e e) α β hJ (hT.submatrix Subtype.val_injective) hα hβ hlocal

end SpectralComparison
