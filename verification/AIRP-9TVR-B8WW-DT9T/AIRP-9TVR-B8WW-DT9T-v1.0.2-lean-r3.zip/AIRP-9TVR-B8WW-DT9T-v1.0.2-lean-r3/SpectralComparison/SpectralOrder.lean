import SpectralComparison.FrameExtremum

/-! Coordinatewise spectral order and positive homogeneity for the literal matrix objective. -/
noncomputable section
open Matrix Finset
namespace SpectralComparison
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

theorem residualTrace_mono {A B : Matrix ι ι ℝ} (hA : A.PosDef) (hB : B.PosDef)
    (hAB : (B-A).PosSemidef) (I : Finset ι) : residualTrace A I≤residualTrace B I := by
  rw [nystrom_trace_inverse_complement hA,nystrom_trace_inverse_complement hB]
  apply inverse_trace_order (principal_posDef hB.inv _) (principal_posDef hA.inv _)
  exact (posDef_inverse_order hA hB hAB).submatrix _

theorem bestError_mono {A B : Matrix ι ι ℝ} (hA : A.PosDef) (hB : B.PosDef)
    (hAB : (B-A).PosSemidef) {k : ℕ} (hk : k≤Fintype.card ι) : bestError A k≤bestError B k := by
  obtain ⟨I,hI,he⟩ := bestError_attained B hk
  rw [he]
  exact (bestError_le A hI).trans (residualTrace_mono hA hB hAB I)

theorem worstError_mono (a b : ι → ℝ) (ha : ∀ i,0<a i) (hb : ∀ i,0<b i)
    (hab : ∀ i,a i≤b i) {k : ℕ} (hk : k<Fintype.card ι) : worstError a k≤worstError b k := by
  obtain ⟨U,hU,he⟩ := worstError_attained a ha hk
  rw [he]
  apply le_trans _ (orbit_bestError_le_worstError b hb U hU hk)
  apply bestError_mono (orbit_posDef a ha U hU) (orbit_posDef b hb U hU) _ hk.le
  have h := (Matrix.PosSemidef.diagonal (fun i => sub_nonneg.mpr (hab i))).conjTranspose_mul_mul_same U
  simpa only [Matrix.conjTranspose_eq_transpose_of_trivial,← Matrix.diagonal_sub,Matrix.mul_sub,Matrix.sub_mul] using h

theorem residualTrace_smul {A : Matrix ι ι ℝ} (hA : A.PosDef) {c : ℝ} (hc : 0<c)
    (I : Finset ι) : residualTrace (c • A) I=c*residualTrace A I := by
  rw [nystrom_trace_inverse_complement (hA.smul hc),nystrom_trace_inverse_complement hA]
  let _ : Invertible c := invertibleOfNonzero hc.ne'
  let _ : Invertible c⁻¹ := invertibleOfNonzero (inv_ne_zero hc.ne')
  rw [Matrix.inv_smul A c (isUnit_iff_ne_zero.mpr hA.det_pos.ne'),invOf_eq_inv]
  change ((c⁻¹ • principal A⁻¹ (Finset.univ \ I))⁻¹).trace = _
  rw [Matrix.inv_smul (principal A⁻¹ (Finset.univ \ I)) c⁻¹ (isUnit_iff_ne_zero.mpr (principal_posDef hA.inv _).det_pos.ne'),invOf_eq_inv,inv_inv,Matrix.trace_smul]
  rfl

theorem bestError_smul {A : Matrix ι ι ℝ} (hA : A.PosDef) {c : ℝ} (hc : 0<c)
    {k : ℕ} (hk : k≤Fintype.card ι) : bestError (c • A) k=c*bestError A k := by
  obtain ⟨I,hI,he⟩ := bestError_attained A hk
  apply le_antisymm
  · exact (bestError_le (c • A) hI).trans_eq (by rw [residualTrace_smul hA hc,← he])
  · apply le_bestError _ hk
    intro J hJ
    rw [residualTrace_smul hA hc]
    exact mul_le_mul_of_nonneg_left (bestError_le A hJ) hc.le

theorem worstError_smul (a : ι → ℝ) (ha : ∀ i,0<a i) {c : ℝ} (hc : 0<c)
    {k : ℕ} (hk : k<Fintype.card ι) : worstError (fun i => c*a i) k=c*worstError a k := by
  have hp : ∀ i,0<c*a i := fun i => mul_pos hc (ha i)
  have hor (U : Matrix ι ι ℝ) (hU : U.transpose*U=1) :
      bestError (U.transpose*Matrix.diagonal (fun i => c*a i)*U) k=
        c*bestError (U.transpose*Matrix.diagonal a*U) k := by
    rw [show Matrix.diagonal (fun i => c*a i)=c • Matrix.diagonal a by ext i j; by_cases h : i=j <;> simp [h],
      Matrix.mul_smul,Matrix.smul_mul,bestError_smul (orbit_posDef a ha U hU) hc hk.le]
  obtain ⟨U,hU,he⟩ := worstError_attained (fun i => c*a i) hp hk
  obtain ⟨V,hV,hv⟩ := worstError_attained a ha hk
  apply le_antisymm
  · rw [he,hor U hU]
    exact mul_le_mul_of_nonneg_left (orbit_bestError_le_worstError a ha U hU hk) hc.le
  · rw [hv,← hor V hV]
    exact orbit_bestError_le_worstError _ hp V hV hk

end SpectralComparison
