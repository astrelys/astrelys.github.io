import SpectralComparison.WaterLevel
import SpectralComparison.HarmonicBlock

noncomputable section
open Finset
namespace SpectralComparison

/-- The reciprocal quotient identity on the actual finite spectrum. -/
theorem reciprocal_quotient {ι : Type*} [Fintype ι] [DecidableEq ι]
    (a : ι → ℝ) (ha : ∀ i,0<a i) {k : ℕ} (hk : k<Fintype.card ι) :
    symmetricQuotient (Finset.univ.val.map a) k=
      (symmetricQuotient (Finset.univ.val.map (fun i => (a i)⁻¹)) (Fintype.card ι-k-1))⁻¹ := by
  let d := Fintype.card ι-k
  have hprod : (∏ i,a i)≠0 := Finset.prod_ne_zero_iff.mpr (fun i _ => (ha i).ne')
  have hn := esymm_reciprocal_duality a (fun i => (ha i).ne') (t:=d-1) (by dsimp [d]; omega)
  have hd := esymm_reciprocal_duality a (fun i => (ha i).ne') (t:=d) (by dsimp [d]; omega)
  have hn' : Fintype.card ι-(d-1)=k+1 := by dsimp [d]; omega
  have hd' : Fintype.card ι-d=k := by dsimp [d]; omega
  rw [hn'] at hn
  rw [hd'] at hd
  simp only [symmetricQuotient,hn,hd,inv_div,show Fintype.card ι-k-1+1=d by dsimp [d]; omega]
  field_simp
  rfl

/-- If positive beta_i<=1 sum to d, the elementary coefficient ratio is bounded by d. -/
theorem water_beta_coefficients {ι : Type*} [Fintype ι] [DecidableEq ι]
    (β : ι → ℝ) (hβ : ∀ i,0<β i) (hβ1 : ∀ i,β i<1)
    {d : ℕ} (hd : 1≤d) (hdn : d≤Fintype.card ι) (hsum : (∑ i,β i)=d) :
    (Finset.univ.val.map β).esymm (d-1)≤(d:ℝ)*(Finset.univ.val.map β).esymm d ∧
      (2≤d → (Finset.univ.val.map β).esymm (d-1)<(d:ℝ)*(Finset.univ.val.map β).esymm d) := by
  have hcount := esymm_completion_sum β (d-1)
  have he : d-1+1=d := by omega
  have hdr : ((d-1:ℕ):ℝ)+1=d := by exact_mod_cast he
  rw [he,hdr] at hcount
  have htail (I : Finset ι) (hI : I.card=d-1) : 1≤∑ j∈Finset.univ\I,β j := by
    have hsel : (∑ i∈I,β i)≤(d-1:ℕ) := by
      calc
        _ ≤∑ _i∈I,(1:ℝ) := Finset.sum_le_sum (fun i _ => (hβ1 i).le)
        _ =_ := by simp [hI]
    have hh := Finset.sum_sdiff (f:=β) (Finset.subset_univ I)
    rw [hsum] at hh
    linarith
  constructor
  · rw [← hcount,Finset.esymm_map_val]
    apply Finset.sum_le_sum
    intro I hI
    have hp : 0≤∏ i∈I,β i := Finset.prod_nonneg (fun i _ => (hβ i).le)
    nlinarith [mul_le_mul_of_nonneg_left (htail I (Finset.mem_powersetCard.mp hI).2) hp]
  · intro hd2
    rw [← hcount,Finset.esymm_map_val]
    apply Finset.sum_lt_sum_of_nonempty (Finset.powersetCard_nonempty.mpr (by simp only [Finset.card_univ]; omega))
    intro I hI
    have hc : I.card=d-1 := (Finset.mem_powersetCard.mp hI).2
    have hne : I.Nonempty := Finset.card_pos.mp (by omega)
    have hs : (∑ i∈I,β i)<(d-1:ℕ) := by
      have hh := Finset.sum_lt_sum_of_nonempty hne (fun i _ => hβ1 i)
      simpa [hc] using hh
    have hh := Finset.sum_sdiff (f:=β) (Finset.subset_univ I)
    rw [hsum] at hh
    have ht : 1<∑ j∈Finset.univ\I,β j := by linarith
    have hp : 0<∏ i∈I,β i := Finset.prod_pos (fun i _ => hβ i)
    nlinarith [mul_lt_mul_of_pos_left ht hp]

/-- Appending any positive entry strictly loses less than that entry in the quotient. -/
theorem quotient_cons_strict_loss (s : Multiset ℝ) (hs : ∀ z∈s,0<z) {k : ℕ}
    (hk : 1≤k) (hcard : k≤s.card) {z : ℝ} (hz : 0<z) :
    symmetricQuotient (z ::ₘ s) k<z+symmetricQuotient s k := by
  obtain ⟨j,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : k≠0)
  have hA := esymm_pos s hs (j+1) hcard
  have hB := esymm_nonneg s (fun w hw => (hs w hw).le) (j+2)
  have hD := esymm_pos s hs j (by omega)
  simp only [symmetricQuotient,Nat.succ_eq_add_one,esymm_cons]
  apply (div_lt_iff₀ (by positivity)).mpr
  have ht : (z+s.esymm (j+2)/s.esymm (j+1))*s.esymm (j+1)=z*s.esymm (j+1)+s.esymm (j+2) := by field_simp
  nlinarith [mul_pos (by positivity : 0<z+s.esymm (j+2)/s.esymm (j+1)) (mul_pos hz hD)]

/-- Any nonempty positive appended tail gives strict quotient loss. -/
theorem quotient_add_strict_loss (head tail : Multiset ℝ)
    (hh : ∀ z∈head,0<z) (ht : ∀ z∈tail,0<z) {k : ℕ} (hk : 1≤k)
    (hcard : k≤head.card) (hne : tail≠0) :
    symmetricQuotient (head+tail) k<tail.sum+symmetricQuotient head k := by
  induction tail using Multiset.induction_on with
  | empty => exact (hne rfl).elim
  | @cons z tail _ =>
    have hz : 0<z := ht z (by simp)
    have ht' : ∀ w∈tail,0<w := fun w hw => ht w (by simp [hw])
    have hall : ∀ w∈head+tail,0<w := by intro w hw; rcases Multiset.mem_add.mp hw with h|h; exact hh w h; exact ht' w h
    have hs := quotient_cons_strict_loss (head+tail) hall hk (by simp only [Multiset.card_add]; omega) hz
    have hb := symmetricQuotient_add_loss head tail hh ht' hcard
    rw [Multiset.add_cons,Multiset.sum_cons]
    linarith

end SpectralComparison
