import SpectralComparison.ShiftedBound

noncomputable section
open Filter Topology Finset
namespace SpectralComparison

/-- Every fixed nonuniform head and tail has the original shifted-rank limsup bound. -/
theorem shifted_split_limsup {k q : ℕ} (hk : 4≤k) (hq : 2*q≤k)
    (e : Fin (k-q) ⊕ Fin (k+q) ≃ Fin (2*k))
    (a : Fin (k-q) → ℝ) (b : Fin (k+q) → ℝ) (ha : ∀ i,0<a i) (hb : ∀ i,0<b i)
    {bmin : ℝ} (hbmin : 0<bmin) (hlow : ∀ j,bmin≤b j) :
    let L := (k:ℝ)^2/(100000000000000000000000*((q:ℝ)+Real.sqrt k))
    Filter.limsup (fun ε : ℝ => spectralMean (splitSpectrum e a b ε) k/worstError (splitSpectrum e a b ε) k)
      (𝓝[>] 0)≤((k:ℝ)+1)*(Finset.univ.val.map b).esymm (q+1)/(bmin*L*(Finset.univ.val.map b).esymm q) := by
  classical
  let L := (k:ℝ)^2/(100000000000000000000000*((q:ℝ)+Real.sqrt k))
  have hk0 : (0:ℝ)<k := by exact_mod_cast (by omega : 0<k)
  have hL : 0<L := by dsimp [L]; exact div_pos (sq_pos_of_pos hk0) (mul_pos (by norm_num) (add_pos_of_nonneg_of_pos (Nat.cast_nonneg _) (Real.sqrt_pos.mpr hk0)))
  obtain ⟨i0,_,hmin⟩ := (Finset.univ : Finset (Fin (k-q))).exists_min_image a
    ⟨⟨0,by omega⟩,Finset.mem_univ _⟩
  let a0 := a i0
  have ha0 : 0<a0 := ha i0
  let I := Finset.univ.map (Function.Embedding.inl.trans e.toEmbedding)
  have hI : I.card=k-q := by simp [I]
  have hi (j : Fin (k-q)) : e (Sum.inl j)∈I := by simp [I]
  have hj (j : Fin (k+q)) : e (Sum.inr j)∉I := by simp [I]
  let D := fun ε : ℝ => a0*bmin*L/(a0-ε*bmin+ε*bmin*L)
  let U := fun ε : ℝ => (spectralMean (splitSpectrum e a b ε) k/ε)/D ε
  have hcont : ContinuousAt D 0 := by
    exact continuousAt_const.div ((continuousAt_const.sub (continuousAt_id.mul continuousAt_const)).add ((continuousAt_id.mul continuousAt_const).mul continuousAt_const)) (by simpa using ha0.ne')
  have hd : Tendsto D (𝓝[>] (0:ℝ)) (𝓝 (bmin*L)) := by
    have hv : D 0=bmin*L := by dsimp [D]; simp only [zero_mul,sub_zero,add_zero]; field_simp
    simpa only [hv] using hcont.tendsto.mono_left (nhdsWithin_le_nhds (s:=Set.Ioi (0:ℝ)))
  have hy := split_spectralMean_limit (q:=q) e a b ha hb (by omega)
  rw [Nat.sub_add_cancel (by omega : q≤k)] at hy
  have hu : Tendsto U (𝓝[>] (0:ℝ))
      (𝓝 (((k:ℝ)+1)*(Finset.univ.val.map b).esymm (q+1)/(bmin*L*(Finset.univ.val.map b).esymm q))) := by
    convert hy.div hd (mul_pos hbmin hL).ne' using 1
    congr 1
    ring
  have hnoise : ∀ᶠ ε : ℝ in 𝓝[>] 0,0<ε ∧ ε≤a0/bmin := by
    filter_upwards [self_mem_nhdsWithin,(eventually_lt_nhds (div_pos ha0 hbmin)).filter_mono nhdsWithin_le_nhds] with ε hpos hlt
    exact ⟨hpos,hlt.le⟩
  have hden : ∀ᶠ ε : ℝ in 𝓝[>] 0,0<D ε := hd.eventually (eventually_gt_nhds (mul_pos hbmin hL))
  have hpos : ∀ᶠ ε : ℝ in 𝓝[>] 0,0<worstError (splitSpectrum e a b ε) k ∧ 0≤spectralMean (splitSpectrum e a b ε) k := by
    filter_upwards [hnoise] with ε hε
    have heig := splitSpectrum_pos e a b ha hb hε.1
    have hx := worstError_pos _ heig (k:=k) (by simp; omega)
    exact ⟨hx,hx.le.trans (worstError_le_spectralMean _ heig (by simp; omega))⟩
  have hbound : ∀ᶠ ε : ℝ in 𝓝[>] 0,
      spectralMean (splitSpectrum e a b ε) k/worstError (splitSpectrum e a b ε) k≤U ε := by
    filter_upwards [hnoise,hden,hpos] with ε hε hdε hpε
    have hba : ε*bmin≤a0 := (le_div_iff₀ hbmin).mp hε.2
    have hleft : ∀ i∈I,a0≤splitSpectrum e a b ε i := by
      intro i hi'
      obtain ⟨j,_,rfl⟩ := Finset.mem_map.mp hi'
      simpa [splitSpectrum] using hmin j (Finset.mem_univ _)
    have hright : ∀ i∉I,ε*bmin≤splitSpectrum e a b ε i := by
      intro i hi'
      obtain ⟨j,rfl⟩ := e.surjective i
      cases j with
      | inl j => exact (hi' (hi j)).elim
      | inr j => simpa [splitSpectrum] using mul_le_mul_of_nonneg_left (hlow j) hε.1.le
    have hx := shifted_spectral_bound hk hq _ (splitSpectrum_pos e a b ha hb hε.1) I hI ha0 (mul_pos hε.1 hbmin) hba hleft hright
    have heq : a0*(ε*bmin)*L/(a0-ε*bmin+ε*bmin*L)=ε*D ε := by dsimp [D]; ring
    change a0*(ε*bmin)*L/(a0-ε*bmin+ε*bmin*L)≤_ at hx
    rw [heq] at hx
    have hh := div_le_div_of_nonneg_left hpε.2 (mul_pos hε.1 hdε) hx
    apply hh.trans_eq
    dsimp only [U]
    rw [div_div]
  have hc : (𝓝[>] (0:ℝ)).IsCoboundedUnder (·≤·)
      (fun ε => spectralMean (splitSpectrum e a b ε) k/worstError (splitSpectrum e a b ε) k) := by
    apply isCoboundedUnder_le_of_eventually_le (𝓝[>] (0:ℝ)) (x:=(0:ℝ))
    filter_upwards [hpos] with ε hε
    exact div_nonneg hε.2 hε.1.le
  have hh := limsup_le_limsup hbound hc hu.isBoundedUnder_le
  rwa [hu.limsup_eq] at hh

/-- Counting extensions of a q-subset gives the sharp remaining-cardinality coefficient bound. -/
theorem esymm_extension_upper {m q : ℕ} (b : Fin m → ℝ) (hb : ∀ i,0≤b i)
    {M : ℝ} (hM : ∀ i,b i≤M) (_hq : q≤m) :
    ((q:ℝ)+1)*(Finset.univ.val.map b).esymm (q+1)≤(m-q:ℕ)*M*(Finset.univ.val.map b).esymm q := by
  rw [← esymm_completion_sum,Finset.esymm_map_val,Finset.mul_sum]
  apply Finset.sum_le_sum
  intro I hI
  have hc : I.card=q := (Finset.mem_powersetCard.mp hI).2
  have hsum : (∑ j∈Finset.univ\I,b j)≤(m-q:ℕ)*M := by
    calc
      _ ≤ ∑ _j∈Finset.univ\I,M := Finset.sum_le_sum (fun j _ => hM j)
      _ = _ := by simp [Finset.card_sdiff,hc]
  simpa only [mul_comm,mul_left_comm,mul_assoc] using mul_le_mul_of_nonneg_left hsum (Finset.prod_nonneg (fun i _ => hb i))

end SpectralComparison
