import SpectralComparison.RidgeCompression

/-! The rank-deficient observation branch of the diffuse lower bound. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- A singular column Gram has an actual unit column in the observation kernel. -/
theorem exists_unit_column_in_gram_kernel {n r : Type*} [Fintype n] [Fintype r]
    [DecidableEq r] (Q : Matrix n r ℝ) (hn : ¬IsUnit (Qᴴ*Q)) :
    ∃ u : Matrix r (Fin 1) ℝ,uᴴ*u=1 ∧ Q*u=0 := by
  classical
  have hP := Matrix.posSemidef_conjTranspose_mul_self Q
  obtain ⟨i,hi⟩ := singular_posSemidef_zero_eigenvalue hP (fun hp => hn hp.isUnit)
  let V : Matrix r r ℝ := hP.isHermitian.eigenvectorUnitary
  have hV : Vᴴ*V=1 := by simpa only [Matrix.star_eq_conjTranspose] using Unitary.coe_star_mul_self hP.isHermitian.eigenvectorUnitary
  have he : Vᴴ*(Qᴴ*Q)*V=Matrix.diagonal hP.isHermitian.eigenvalues := by
    conv_lhs => rw [real_spectral_decomposition hP.isHermitian]
    change Vᴴ*(V*Matrix.diagonal hP.isHermitian.eigenvalues*Vᴴ)*V=_
    simp only [← Matrix.mul_assoc,hV,Matrix.one_mul]
    rw [Matrix.mul_assoc,hV,Matrix.mul_one]
  let f : Fin 1 → r := fun _ => i
  let u := V.submatrix id f
  have hu : uᴴ*u=1 := by
    change (V.submatrix id f)ᴴ*V.submatrix id f=1
    rw [Matrix.conjTranspose_submatrix,← Matrix.submatrix_mul _ _ f id f Function.bijective_id,hV]
    exact Matrix.submatrix_one f (fun a b _ => Subsingleton.elim _ _)
  have hzero : uᴴ*(Qᴴ*Q)*u=0 := by
    have hh := congrArg (fun M : Matrix r r ℝ => M.submatrix f f) he
    rw [Matrix.submatrix_mul _ _ f id f Function.bijective_id,
      Matrix.submatrix_mul _ _ f id id Function.bijective_id,Matrix.submatrix_id_id] at hh
    change uᴴ*(Qᴴ*Q)*u=(Matrix.diagonal hP.isHermitian.eigenvalues).submatrix f f at hh
    rw [hh]
    ext a b
    change (Matrix.diagonal hP.isHermitian.eigenvalues) i i=0
    rw [Matrix.diagonal_apply_eq]
    exact hi
  refine ⟨u,hu,Matrix.conjTranspose_mul_self_eq_zero.mp ?_⟩
  simpa only [Matrix.conjTranspose_mul,Matrix.mul_assoc] using hzero

/-- If the observation Gram is singular, every predictor leaves at least one unit of signal error. -/
theorem deficient_signal_frobenius_lower {n r : Type*} [Fintype n] [Fintype r]
    [DecidableEq r] (Q : Matrix n r ℝ) (hn : ¬IsUnit (Qᴴ*Q)) (M : Matrix r n ℝ) :
    1≤(((1 : Matrix r r ℝ)-M*Q)*((1 : Matrix r r ℝ)-M*Q)ᴴ).trace := by
  obtain ⟨u,hu,hQu⟩ := exists_unit_column_in_gram_kernel Q hn
  have hh := frobenius_right_compression ((1 : Matrix r r ℝ)-M*Q) u hu
  have he : ((1 : Matrix r r ℝ)-M*Q)*u=u := by
    rw [Matrix.sub_mul,Matrix.one_mul,Matrix.mul_assoc,hQu,Matrix.mul_zero,sub_zero]
  rw [he,Matrix.trace_mul_comm,hu] at hh
  simpa using hh

/-- The rank-deficient branch with any PSD noise already gives the stronger lower bound a. -/
theorem deficient_signal_noise_lower {n r : Type*} [Fintype n] [Fintype r]
    [DecidableEq n] [DecidableEq r] (Q : Matrix n r ℝ) (hn : ¬IsUnit (Qᴴ*Q))
    {C : Matrix n n ℝ} (hC : C.PosSemidef) {a : ℝ} (ha : 0≤a) (M : Matrix r n ℝ) :
    a≤a*(((1 : Matrix r r ℝ)-M*Q)*((1 : Matrix r r ℝ)-M*Q)ᴴ).trace+(M*C*Mᴴ).trace := by
  have hs := mul_le_mul_of_nonneg_left (deficient_signal_frobenius_lower Q hn M) ha
  have hn := (hC.mul_mul_conjTranspose_same M).trace_nonneg
  linarith

end SpectralComparison
