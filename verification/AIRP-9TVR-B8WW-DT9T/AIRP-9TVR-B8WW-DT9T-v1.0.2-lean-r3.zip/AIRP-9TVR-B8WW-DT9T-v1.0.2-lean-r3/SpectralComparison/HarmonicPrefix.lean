import SpectralComparison.PrefixOrientation
import SpectralComparison.Diagonal

/-! One maximizing tail prefix pays only the harmonic loss. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- A finite positive tail has one prefix scale controlling its entire sum with H_m. -/
theorem exists_harmonic_prefix_scale {m : ℕ} (hm : 1≤m) (v : Fin m → ℝ) :
    ∃ i : Fin m, (∑ j,v j)≤H m*(((i.val:ℝ)+1)*v i) := by
  classical
  obtain ⟨i,_,hi⟩ := Finset.exists_max_image Finset.univ (fun i : Fin m => ((i.val:ℝ)+1)*v i)
    (by exact ⟨⟨0,by omega⟩,Finset.mem_univ _⟩)
  refine ⟨i,?_⟩
  let Z := ((i.val:ℝ)+1)*v i
  have h (j : Fin m) : v j≤((j.val:ℝ)+1)⁻¹*Z := by
    have hj : 0<(j.val:ℝ)+1 := by positivity
    have hh := hi j (Finset.mem_univ _)
    have hd : v j≤Z/((j.val:ℝ)+1) := (le_div_iff₀ hj).mpr (by nlinarith)
    simpa only [div_eq_mul_inv,mul_comm] using hd
  have hs : ∑ j : Fin m, ((j.val:ℝ)+1)⁻¹=H m := by
    unfold H
    exact Fin.sum_univ_eq_sum_range (fun j => ((j:ℝ)+1)⁻¹) m
  calc
    (∑ j,v j) ≤ ∑ j,((j.val:ℝ)+1)⁻¹*Z := Finset.sum_le_sum (fun j _ => h j)
    _ = H m*Z := by rw [← Finset.sum_mul,hs]

/-- The zero-based ordered tail is exactly the finite sequence following the first k entries. -/
theorem indexed_tail_sum {n k : ℕ} (hkn : k<n) (eig : Fin n → ℝ) :
    (∑ j : Fin (n-k), eig ⟨k+j.val,by omega⟩) =
      ∑ i ∈ Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n),eig i := by
  classical
  let S := Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n)
  let f : Fin (n-k) → S := fun j => ⟨⟨k+j.val,by omega⟩,by simp [S,Fin.lt_def]⟩
  have hf : Function.Bijective f := by
    constructor
    · intro a b hab
      apply Fin.ext
      have h := congrArg (fun x : S => x.val.val) hab
      change k+a.val=k+b.val at h
      omega
    · intro i
      have hi : k ≤ i.val.val := Nat.le_of_not_lt (fun h =>
        (Finset.mem_sdiff.mp i.property).2 (Finset.mem_Iio.mpr h))
      refine ⟨⟨i.val.val-k,by omega⟩,?_⟩
      apply Subtype.ext
      apply Fin.ext
      change k+(i.val.val-k)=i.val.val
      omega
  let e := Equiv.ofBijective f hf
  have h := Fintype.sum_equiv e (fun j => eig ⟨k+j.val,by omega⟩) (fun i : S => eig i.val) (fun _ => rfl)
  rw [Finset.sum_coe_sort] at h
  exact h

/-- One actual tail prefix realizes the harmonic lower scale; no orientations are averaged. -/
theorem exists_indexed_tail_prefix {n k : ℕ} (hkn : k<n) (eig : Fin n → ℝ) :
    ∃ t : ℕ, ∃ ht : 1≤t, ∃ htn : k+t≤n,
      (∑ i ∈ Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n),eig i) ≤
        H (n-k)*(t:ℝ)*eig ⟨k+t-1,by omega⟩ := by
  obtain ⟨i,hi⟩ := exists_harmonic_prefix_scale (show 1≤n-k by omega)
    (fun j : Fin (n-k) => eig ⟨k+j.val,by omega⟩)
  rw [indexed_tail_sum hkn eig] at hi
  refine ⟨i.val+1,by omega,by omega,?_⟩
  have he : (⟨k+i.val,by omega⟩ : Fin n)=⟨k+(i.val+1)-1,by omega⟩ := by
    apply Fin.ext
    change k+i.val=k+(i.val+1)-1
    omega
  simpa only [Nat.cast_add,Nat.cast_one,he,mul_assoc] using hi

end SpectralComparison
