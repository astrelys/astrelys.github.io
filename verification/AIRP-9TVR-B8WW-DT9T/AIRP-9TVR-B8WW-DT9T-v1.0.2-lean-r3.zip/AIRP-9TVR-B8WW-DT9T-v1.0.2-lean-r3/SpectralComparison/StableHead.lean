import SpectralComparison.StableVariance

noncomputable section
open Finset
namespace SpectralComparison
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Quantitative active-block loss when at least two reciprocal units remain. -/
theorem active_variance_loss (a : ι → ℝ) (ha : ∀ i,1<a i) {k : ℕ}
    (hd : 2≤Fintype.card ι-k) (hsum : (∑ i,(a i)⁻¹)=(Fintype.card ι-k:ℕ)) :
    (∑ i,(a i)⁻¹*(1-(a i)⁻¹))≤(2:ℝ)^Fintype.card ι*
      ((Fintype.card ι-k:ℕ)-symmetricQuotient (Finset.univ.val.map a) k) := by
  have hap : ∀ i,0<a i := fun i => (by norm_num : (0:ℝ)<1).trans (ha i)
  have hb : ∀ i,0<(a i)⁻¹ := fun i => inv_pos.mpr (hap i)
  have hb1 : ∀ i,(a i)⁻¹≤1 := fun i => (inv_le_one₀ (hap i)).mpr (ha i).le
  have h := unit_variance_quotient (fun i => (a i)⁻¹) hb hb1 hd (by omega) hsum
  rw [reciprocal_quotient a hap (by omega),symmetricQuotient,inv_div]
  have he : Fintype.card ι-k-1+1=Fintype.card ι-k := by omega
  rw [he]
  exact h

/-- A half-sized positive tail creates the missing quantitative loss in reciprocal mass one. -/
theorem unit_mass_tail_loss (a : ι → ℝ) (ha : ∀ i,1<a i) {k : ℕ}
    (hk : 1≤k) (hc : Fintype.card ι=k+1) (hsum : (∑ i,(a i)⁻¹)=1)
    {z : ℝ} (hz : 1/2≤z) (hz1 : z≤1) :
    symmetricQuotient (z ::ₘ (Finset.univ.val.map a)) k≤
      z+1-(∑ i,(a i)⁻¹*(1-(a i)⁻¹))/4 := by
  let β := fun i => (a i)⁻¹
  let V := ∑ i,β i*(1-β i)
  let p := ∏ i,a i
  have hap : ∀ i,0<a i := fun i => (by norm_num : (0:ℝ)<1).trans (ha i)
  have hp : 0<p := Finset.prod_pos (fun i _ => hap i)
  have hb : ∀ i,0<β i := fun i => inv_pos.mpr (hap i)
  have hb1 : ∀ i,β i≤1 := fun i => (inv_le_one₀ (hap i)).mpr (ha i).le
  have hV0 : 0≤V := Finset.sum_nonneg (fun i _ => mul_nonneg (hb i).le (sub_nonneg.mpr (hb1 i)))
  have hV1 : V≤1 := by
    calc
      _ ≤∑ i,β i := Finset.sum_le_sum (fun i _ => by nlinarith [sq_nonneg (β i)])
      _ =1 := hsum
  have hvar : V=2*(Finset.univ.val.map β).esymm 2 := unit_mass_variance β hsum
  have hn := esymm_reciprocal_duality a (fun i => (hap i).ne') (t:=0) (by omega)
  have hd := esymm_reciprocal_duality a (fun i => (hap i).ne') (t:=1) (by omega)
  have ht := esymm_reciprocal_duality a (fun i => (hap i).ne') (t:=2) (by omega)
  have hcard1 : Fintype.card ι-1=k := by omega
  have hcard2 : Fintype.card ι-2=k-1 := by omega
  simp only [Nat.sub_zero,hc,Multiset.esymm_zero,mul_one] at hn
  rw [hcard1,esymm_one,Finset.sum_map_val,hsum,mul_one] at hd
  rw [hcard2] at ht
  have ht' : (Finset.univ.val.map a).esymm (k-1)=p*(V/2) := by
    change _=p*(V/2)
    rw [ht]
    change p*(Finset.univ.val.map β).esymm 2=p*(V/2)
    congr 1
    linarith
  have hk' : k-1+1=k := by omega
  have hformula : symmetricQuotient (z ::ₘ (Finset.univ.val.map a)) k=
      (1+z)/(1+z*V/2) := by
    unfold symmetricQuotient
    rw [esymm_cons,hn,hd,← hk',esymm_cons,ht',hk',hd]
    have hz0 : 0≤z := by linarith
    have he : 1+z*V/2≠0 := ne_of_gt (by positivity)
    change (p+z*p)/(p+z*(p*(V/2)))=(1+z)/(1+z*V/2)
    field_simp
    <;> ring
  rw [hformula]
  change (1+z)/(1+z*V/2)≤z+1-V/4
  have hz0 : 0≤z := by linarith
  apply (div_le_iff₀ (by positivity : 0<1+z*V/2)).mpr
  have hcoeff : 0≤4*z+4*z^2-2-z*V := by
    have hzV := mul_le_mul_of_nonneg_left hV1 hz0
    nlinarith [sq_nonneg (z-1/2)]
  nlinarith [mul_nonneg hV0 hcoeff]

end SpectralComparison
