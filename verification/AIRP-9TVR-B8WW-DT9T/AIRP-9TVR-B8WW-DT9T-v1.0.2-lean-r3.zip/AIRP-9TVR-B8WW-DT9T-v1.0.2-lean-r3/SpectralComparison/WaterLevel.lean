import SpectralComparison.ShiftedTheorem
import Mathlib.Topology.Order.IntermediateValue

noncomputable section
open Finset
namespace SpectralComparison

def waterSum {n : ℕ} (a : Fin n → ℝ) (τ : ℝ) : ℝ := ∑ i,max (1-τ/a i) 0

theorem waterSum_continuous {n : ℕ} (a : Fin n → ℝ) : Continuous (waterSum a) := by
  apply continuous_finsetSum
  intro i _
  exact (continuous_const.sub (continuous_id.div_const _)).max continuous_const

theorem waterSum_zero {n : ℕ} (a : Fin n → ℝ) : waterSum a 0=n := by simp [waterSum]

theorem waterSum_at_upper {n : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i)
    {M : ℝ} (hM : ∀ i,a i≤M) : waterSum a M=0 := by
  apply Finset.sum_eq_zero
  intro i _
  exact max_eq_right (by have h := (one_le_div (ha i)).mpr (hM i); linarith)

/-- The water function is strictly decreasing until its last active coordinate disappears. -/
theorem waterSum_strictAnti {n : ℕ} (a : Fin n → ℝ) (hn : 0<n) (ha : ∀ i,0<a i) :
    StrictAntiOn (waterSum a) (Set.Icc 0 (finiteSpectrumMax a hn)) := by
  obtain ⟨_,_,hbound,_,⟨j,hj⟩⟩ := finiteSpectrum_extrema a hn ha
  intro x hx y hy hxy
  apply Finset.sum_lt_sum
  · intro i _
    exact max_le_max (by exact sub_le_sub_left (div_le_div_of_nonneg_right hxy.le (ha i).le) 1) le_rfl
  · refine ⟨j,Finset.mem_univ _,?_⟩
    have hyj : y≤a j := hj ▸ hy.2
    have hxj : x<a j := hxy.trans_le hyj
    have hleft : 0<1-x/a j := by have h := (div_lt_one (ha j)).mpr hxj; linarith
    have hright : 0≤1-y/a j := by have h := (div_le_one (ha j)).mpr hyj; linarith
    rw [max_eq_left hright,max_eq_left hleft.le]
    exact sub_lt_sub_left (div_lt_div_of_pos_right hxy (ha j)) 1

/-- The original positive water level exists uniquely for every interior rank. -/
theorem exists_unique_waterLevel {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i) (hk : 1≤k) (hkn : k<n) :
    ∃! τ : ℝ,0<τ ∧ waterSum a τ=k := by
  have hn : 0<n := by omega
  let M := finiteSpectrumMax a hn
  obtain ⟨_,hM,hbounds,_,_⟩ := finiteSpectrum_extrema a hn ha
  have hz := waterSum_zero a
  have hm : waterSum a M=0 := waterSum_at_upper a ha (fun i => (hbounds i).2)
  have hk0 : (0:ℝ)<k := by exact_mod_cast (by omega : 0<k)
  have hknr : (k:ℝ)<n := by exact_mod_cast hkn
  obtain ⟨τ,hτ,hroot⟩ := intermediate_value_Icc' hM.le (waterSum_continuous a).continuousOn
    (show (k:ℝ)∈Set.Icc (waterSum a M) (waterSum a 0) by rw [hm,hz]; exact ⟨hk0.le,hknr.le⟩)
  have htpos : 0<τ := by
    apply lt_of_le_of_ne hτ.1
    intro he
    have he0 : τ=0 := he.symm
    rw [he0,hz] at hroot
    linarith
  refine ⟨τ,⟨htpos,hroot⟩,?_⟩
  intro x hx
  have hxM : x≤M := by
    by_contra h
    have hh : waterSum a x=0 := waterSum_at_upper a ha (fun i => ((hbounds i).2).trans (le_of_not_ge h))
    linarith [hx.2]
  exact (waterSum_strictAnti a hn ha).injOn ⟨hx.1.le,hxM⟩ hτ (hx.2.trans hroot.symm)

/-- The active set has strictly more entries than k, and the exact reciprocal sum q-k. -/
theorem waterLevel_active {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i)
    {τ : ℝ} (hτ : 0<τ) (hroot : waterSum a τ=k) (hk : 1≤k) :
    let S := Finset.univ.filter (fun i => τ<a i)
    k<S.card ∧ (∑ i∈S,τ/a i)=(S.card:ℝ)-(k:ℝ) ∧
      (∀ i∈Finset.univ\S,a i≤τ) := by
  classical
  let S := Finset.univ.filter (fun i => τ<a i)
  have he : waterSum a τ=∑ i∈S,(1-τ/a i) := by
    calc
      waterSum a τ=∑ i∈S,max (1-τ/a i) 0 := by
        exact (Finset.sum_subset (Finset.filter_subset _ _) (by
          intro i _ hi
          have hh : a i≤τ := by simpa [S] using hi
          have hr : 1≤τ/a i := (one_le_div (ha i)).mpr hh
          exact max_eq_right (by linarith))).symm
      _ = _ := by
        apply Finset.sum_congr rfl
        intro i hi
        have hh := (Finset.mem_filter.mp hi).2
        exact max_eq_left (by have hr := (div_lt_one (ha i)).mpr hh; linarith)
  have hsum : (∑ i∈S,τ/a i)=(S.card:ℝ)-(k:ℝ) := by
    rw [Finset.sum_sub_distrib] at he
    simp only [Finset.sum_const,nsmul_eq_mul,mul_one] at he
    linarith
  have hne : S.Nonempty := by
    by_contra hn
    have hs : S=∅ := Finset.not_nonempty_iff_eq_empty.mp hn
    simp only [hs,Finset.sum_empty] at he
    have hk0 : (0:ℝ)<k := by exact_mod_cast (by omega : 0<k)
    linarith
  have hspos : 0<∑ i∈S,τ/a i := Finset.sum_pos (fun i _ => div_pos hτ (ha i)) hne
  have hc : k<S.card := by exact_mod_cast (by linarith : (k:ℝ)<S.card)
  refine ⟨hc,hsum,?_⟩
  intro i hi
  have hh := (Finset.mem_sdiff.mp hi).2
  simpa [S] using hh

end SpectralComparison
