import SpectralComparison.SelectionRidge
import SpectralComparison.Predictor

/-! The geometric selected-row estimate acts on the literal Nyström residual. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- One preselected frame bounds every literal selected-set residual in any model with the
constructed signal/noise geometry. Only its geometric and spectral hypotheses remain to instantiate. -/
theorem exists_diffuse_residual_frame {k q : ℕ} (hk : 1≤k) (hq : 4*q≤k) :
    ∃ Q0 : Matrix (Fin (2*k)) (Fin (k-q)) ℝ,Q0ᴴ*Q0=1 ∧
    ∀ (n : Type) [Fintype n] [DecidableEq n]
      (f : n → Option (Fin (2*k))) (u : n → ℝ) (Q : Matrix n (Fin (k-q)) ℝ),
      Qᴴ*Q=1 →
      (∀ i j,Q i j=match f i with | none => 0 | some a => u i*Q0 a j) →
    ∀ C D : Matrix n n ℝ,Qᴴ*C=0 → C.PosSemidef → D.PosSemidef → (C-D).PosSemidef →
      (∀ i x,f i≠f x → D i x=0) →
    ∀ mass : Fin (2*k) → ℝ,(∀ i j,f i=some j → D i i=mass j*(u i)^2) →
    ∀ a s : ℝ,0<a → 0<s → (∀ j,s/(8*k)≤mass j) →
    ∀ A : Matrix (Fin (k-q)) (Fin (k-q)) ℝ,A.PosDef → (A-a•1).PosSemidef →
      (Q*A*Qᴴ+C).PosDef →
    ∀ I : Finset n,I.card=k →
      let V := (k:ℝ)*s/(64000000000000000000000000000*((q:ℝ)+Real.sqrt k)*H (8*k))
      a*V/(a+V)≤residualTrace (Q*A*Qᴴ+C) I := by
  classical
  obtain ⟨Q0,hQ0,hselect⟩ := exists_actual_selection_ridge_frame hk hq
  refine ⟨Q0,hQ0,?_⟩
  intro n _ _ f u Q hQ hrow C D hQC hC hD hCD hcross mass hdiag a s ha hs hmass A hA hAa hK I hI
  obtain ⟨P,hP⟩ := (paper_equation_7_7 hK I).2
  rw [hP]
  let E := coordinateObservation I
  have hEQ : E*Q=Q.submatrix Subtype.val id :=
    Matrix.one_submatrix_mul _ (Equiv.refl n) Q
  have hEC : E*C*Eᴴ=C.submatrix Subtype.val Subtype.val := coordinate_observation_covariance C I
  have hCDI : (C.submatrix (fun i : I => i.val) (fun i : I => i.val)-D.submatrix (fun i : I => i.val) (fun i : I => i.val)).PosSemidef := by
    exact hCD.submatrix (fun i : I => i.val)
  have hbound := hselect I (by simpa only [Fintype.card_coe,hI] using (le_refl k))
    (fun i : I => f i.val) (fun i : I => u i.val) (Q.submatrix Subtype.val id)
    (by intro i j; cases hf : f i.val <;> simpa only [Matrix.submatrix_apply,id_eq,hf] using hrow i.val j)
    (C.submatrix Subtype.val Subtype.val) (D.submatrix Subtype.val Subtype.val)
    (hC.submatrix _) (hD.submatrix _) hCDI
    (fun i x hix => hcross i.val x.val hix) mass
    (fun i j hij => hdiag i.val j hij) a s ha hs hmass (Qᴴ*P)
  have hproj := paper_equation_7_8 hC Q hQ hQC hA ha hAa E P
  dsimp only at hproj
  rw [hEQ,hEC] at hproj
  exact hbound.trans hproj

end SpectralComparison
