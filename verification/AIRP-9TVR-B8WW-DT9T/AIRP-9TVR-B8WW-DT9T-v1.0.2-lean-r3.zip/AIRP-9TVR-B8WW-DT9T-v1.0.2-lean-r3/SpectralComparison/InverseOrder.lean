import SpectralComparison.SchurResidual

/-! Positive-definite inverse order and inverse-trace compression (Section 2). -/
noncomputable section
namespace SpectralComparison
open Matrix Finset
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Loewner order reverses under inversion, expressed without an overloaded matrix order. -/
theorem posDef_inverse_order {A B : Matrix ι ι ℝ} (hA : A.PosDef) (hB : B.PosDef)
    (hAB : (B - A).PosSemidef) : (A⁻¹ - B⁻¹).PosSemidef := by
  have h1 := hA.posSemidef.conjTranspose_mul_mul_same (A⁻¹ - B⁻¹)
  have h2 := hAB.conjTranspose_mul_mul_same B⁻¹
  simp only [Matrix.conjTranspose_sub, hA.inv.isHermitian.eq, hB.inv.isHermitian.eq] at h1 h2
  have hAi := Matrix.mul_nonsing_inv A (isUnit_iff_ne_zero.mpr hA.det_pos.ne')
  have hiA := Matrix.nonsing_inv_mul A (isUnit_iff_ne_zero.mpr hA.det_pos.ne')
  have hiB := Matrix.nonsing_inv_mul B (isUnit_iff_ne_zero.mpr hB.det_pos.ne')
  have he : (A⁻¹ - B⁻¹) * A * (A⁻¹ - B⁻¹) + B⁻¹ * (B - A) * B⁻¹ = A⁻¹ - B⁻¹ := by
    simp only [Matrix.sub_mul, Matrix.mul_sub, Matrix.mul_assoc, hAi, Matrix.mul_one]
    simp only [← Matrix.mul_assoc, hiA, hiB, Matrix.one_mul]
    abel
  rw [← he]
  exact h1.add h2

omit [DecidableEq ι] in
/-- A positive-semidefinite difference has nonnegative trace. -/
theorem trace_le_of_difference_posSemidef {A B : Matrix ι ι ℝ}
    (h : (B - A).PosSemidef) : A.trace ≤ B.trace := by
  have ht := h.trace_nonneg
  rw [Matrix.trace_sub] at ht
  linarith

/-- The inverse trace reverses positive-definite Loewner order. -/
theorem inverse_trace_order {A B : Matrix ι ι ℝ} (hA : A.PosDef) (hB : B.PosDef)
    (hAB : (B - A).PosSemidef) : B⁻¹.trace ≤ A⁻¹.trace := by
  exact trace_le_of_difference_posSemidef (posDef_inverse_order hA hB hAB)

omit [DecidableEq ι] in
/-- Orthonormal columns are injective as a linear map. -/
theorem orthonormal_mulVec_injective {κ : Type*} [Fintype κ] [DecidableEq κ]
    (U : Matrix ι κ ℝ) (hU : U.conjTranspose * U = 1) : Function.Injective U.mulVec := by
  intro x y h
  have ht := congrArg (fun z => U.conjTranspose *ᵥ z) h
  simpa only [Matrix.mulVec_mulVec, hU, Matrix.one_mulVec] using ht

omit [DecidableEq ι] in
/-- Compression by an isometry preserves positive definiteness. -/
theorem orthonormal_compression_posDef {κ : Type*} [Fintype κ] [DecidableEq κ]
    {T : Matrix ι ι ℝ} (hT : T.PosDef) (U : Matrix ι κ ℝ)
    (hU : U.conjTranspose * U = 1) : (U.conjTranspose * T * U).PosDef := by
  exact hT.conjTranspose_mul_mul_same (orthonormal_mulVec_injective U hU)

/-- Compression of an inverse dominates the inverse of the compressed matrix. -/
theorem inverse_compression_difference_posSemidef {κ : Type*} [Fintype κ] [DecidableEq κ]
    {T : Matrix ι ι ℝ} (hT : T.PosDef) (U : Matrix ι κ ℝ)
    (hU : U.conjTranspose * U = 1) :
    (U.conjTranspose * T⁻¹ * U - (U.conjTranspose * T * U)⁻¹).PosSemidef := by
  let A := U.conjTranspose * T * U
  have hA : A.PosDef := orthonormal_compression_posDef hT U hU
  let _ : Invertible T := hT.isUnit.invertible
  let _ : Invertible A := hA.isUnit.invertible
  have hs := hT.posSemidef.conjTranspose_mul_mul_same (T⁻¹ * U - U * A⁻¹)
  simp only [Matrix.conjTranspose_sub, Matrix.conjTranspose_mul,
    hT.inv.isHermitian.eq, hA.inv.isHermitian.eq] at hs
  have he : (U.conjTranspose * T⁻¹ - A⁻¹ * U.conjTranspose) * T * (T⁻¹ * U - U * A⁻¹) =
      U.conjTranspose * T⁻¹ * U - A⁻¹ := by
    simp only [Matrix.sub_mul, Matrix.mul_sub, Matrix.inv_mul_cancel_right_of_invertible]
    have h1 : U.conjTranspose * (U * A⁻¹) = A⁻¹ := by rw [← Matrix.mul_assoc, hU, Matrix.one_mul]
    have h2 : A⁻¹ * U.conjTranspose * T * (T⁻¹ * U) = A⁻¹ := by
      rw [← Matrix.mul_assoc, Matrix.mul_inv_cancel_right_of_invertible,
        Matrix.mul_assoc, hU, Matrix.mul_one]
    have h3 : A⁻¹ * U.conjTranspose * T * (U * A⁻¹) = A⁻¹ := by
      calc
        _ = A⁻¹ * A * A⁻¹ := by simp only [A, Matrix.mul_assoc]
        _ = A⁻¹ := Matrix.mul_inv_cancel_right_of_invertible A A⁻¹
    rw [h1, h2, h3]
    simp only [Matrix.mul_assoc]
    abel
  rw [he] at hs
  exact hs

/-- Trace of a PSD matrix cannot increase after an orthonormal compression. -/
theorem trace_orthonormal_compression_le {κ : Type*} [Fintype κ] [DecidableEq κ]
    {S : Matrix ι ι ℝ} (hS : S.PosSemidef) (U : Matrix ι κ ℝ)
    (hU : U.conjTranspose * U = 1) : (U.conjTranspose * S * U).trace ≤ S.trace := by
  let P : Matrix ι ι ℝ := 1 - U * U.conjTranspose
  have hP : P.conjTranspose = P := by
    simp only [P, Matrix.conjTranspose_sub, Matrix.conjTranspose_one,
      Matrix.conjTranspose_mul, Matrix.conjTranspose_conjTranspose]
  have hPP : P * P = P := by
    have hproj : (U * U.conjTranspose) * (U * U.conjTranspose) = U * U.conjTranspose := by
      rw [Matrix.mul_assoc, ← Matrix.mul_assoc U.conjTranspose U U.conjTranspose, hU, Matrix.one_mul]
    simp only [P, Matrix.sub_mul, Matrix.mul_sub, Matrix.one_mul, Matrix.mul_one, hproj]
    abel
  have hs := (hS.conjTranspose_mul_mul_same P).trace_nonneg
  rw [hP, Matrix.trace_mul_cycle, hPP] at hs
  simp only [P, Matrix.sub_mul, Matrix.one_mul, Matrix.trace_sub] at hs
  have he : (U * U.conjTranspose * S).trace = (U.conjTranspose * S * U).trace := by
    rw [Matrix.mul_assoc, Matrix.trace_mul_comm]
  rw [he] at hs
  linarith

/-- Paper equation (2.1), for any real matrix with orthonormal columns. -/
theorem inverse_trace_compression {κ : Type*} [Fintype κ] [DecidableEq κ]
    {T : Matrix ι ι ℝ} (hT : T.PosDef) (U : Matrix ι κ ℝ)
    (hU : U.conjTranspose * U = 1) :
    ((U.conjTranspose * T * U)⁻¹).trace ≤ T⁻¹.trace := by
  exact (trace_le_of_difference_posSemidef (inverse_compression_difference_posSemidef hT U hU)).trans
    (trace_orthonormal_compression_le hT.inv.posSemidef U hU)

end SpectralComparison
