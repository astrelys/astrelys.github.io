import SpectralComparison.KernelPairBounds

/-! Gaussian net estimates with the scale k separate from the column dimension. -/
noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

/-- Equation (4.2)'s explicit half-net bound, before the final numerical simplification. -/
theorem gaussian_opNorm_tail_scale_explicit {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {N p k : ℕ}
    (G : Ω → Matrix (Fin N) (Fin p) ℝ)
    (hG : ∀ a : Fin N × Fin p, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin N × Fin p => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : Fin N × Fin p, Measurable (fun ω => G ω a.1 a.2)) :
    μ.real {ω | 10*Real.sqrt k < ‖(G ω).toEuclideanLin.toContinuousLinearMap‖} ≤
      (5:ℝ)^p * (2:ℝ)^((N:ℝ)/2) * Real.exp (-25*(k:ℝ)/4) := by
  obtain ⟨s,hs,hcard,hnet⟩ := exists_sphere_net_card_le (E := EuclideanSpace ℝ (Fin p))
    (η := (1/2:ℝ)) (by norm_num)
  have h := gaussian_opNorm_net_bound G hG hind hm s (M := 5*Real.sqrt k) (z := (1/4:ℝ))
    (by norm_num) (by norm_num) (by positivity) (by norm_num) (by norm_num) hs hnet
  have hM : 5*Real.sqrt (k:ℝ)/(1-(1/2:ℝ)) = 10*Real.sqrt k := by ring
  have ha : -(1/4:ℝ)*(5*Real.sqrt (k:ℝ))^2 = -25*(k:ℝ)/4 := by
    nlinarith [Real.sq_sqrt (Nat.cast_nonneg k)]
  have hr : (1-2*(1/4:ℝ))^(-(Fintype.card (Fin N):ℝ)/2) = (2:ℝ)^((N:ℝ)/2) := by
    norm_num only [Fintype.card_fin, show 1-2*(1/4:ℝ)=1/2 by norm_num]
    rw [show -(N:ℝ)/2 = -((N:ℝ)/2) by ring, Real.rpow_neg_eq_inv_rpow]
    norm_num
  rw [hM,ha,hr] at h
  have hc : (s.card:ℝ) ≤ (5:ℝ)^p := by norm_num at hcard; exact hcard
  calc
    _ ≤ (s.card:ℝ)*(Real.exp (-25*(k:ℝ)/4)*(2:ℝ)^((N:ℝ)/2)) := h
    _ ≤ (5:ℝ)^p*(Real.exp (-25*(k:ℝ)/4)*(2:ℝ)^((N:ℝ)/2)) := by gcongr
    _ = _ := by ring

/-- The exponential form of (4.2), with the paper's operator threshold. -/
theorem gaussian_opNorm_tail_scale {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {N p k : ℕ} (hp : p≤k) (hN : N ≤ 2*k)
    (G : Ω → Matrix (Fin N) (Fin p) ℝ)
    (hG : ∀ a : Fin N × Fin p, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin N × Fin p => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : Fin N × Fin p, Measurable (fun ω => G ω a.1 a.2)) :
    μ.real {ω | 10*Real.sqrt k < ‖(G ω).toEuclideanLin.toContinuousLinearMap‖} ≤
      Real.exp (-3*(k:ℝ)) := by
  have h5 : (5:ℝ) ≤ Real.exp 2 := by
    have h := Real.sum_le_exp_of_nonneg (by norm_num : (0:ℝ) ≤ 2) 3
    norm_num [Finset.sum_range_succ] at h
    exact h
  have h2 : (2:ℝ) ≤ Real.exp 1 := Real.exp_one_gt_two.le
  have he5 : (5:ℝ)^p ≤ Real.exp (2*(p:ℝ)) := by
    calc
      _ ≤ (Real.exp 2)^p := by gcongr
      _ = _ := by rw [← Real.exp_nat_mul]; congr 1; ring
  have he2 : (2:ℝ)^((N:ℝ)/2) ≤ Real.exp ((N:ℝ)/2) := by
    calc
      _ ≤ (Real.exp 1)^((N:ℝ)/2) := Real.rpow_le_rpow (by norm_num) h2 (by positivity)
      _ = _ := by rw [← Real.exp_mul]; congr 1; ring
  apply (gaussian_opNorm_tail_scale_explicit G hG hind hm).trans
  calc
    _ ≤ Real.exp (2*(p:ℝ))*Real.exp ((N:ℝ)/2)*Real.exp (-25*(k:ℝ)/4) := by gcongr
    _ = Real.exp (2*(p:ℝ)+(N:ℝ)/2-25*(k:ℝ)/4) := by rw [← Real.exp_add, ← Real.exp_add]; congr 1; ring
    _ ≤ _ := Real.exp_le_exp.mpr (by
      have hn : (N:ℝ) ≤ 2*(k:ℝ) := by exact_mod_cast hN
      have hpk : (p:ℝ)≤k := by exact_mod_cast hp
      nlinarith)

/-- The fixed-vector lower tail at 4p/D^2, in a convenient integral-power form. -/
theorem gaussian_vector_small_ball_scale {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {N p k : ℕ}
    (G : Ω → Matrix (Fin N) (Fin p) ℝ)
    (hG : ∀ a : Fin N × Fin p, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin N × Fin p => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : Fin N × Fin p, Measurable (fun ω => G ω a.1 a.2))
    (v : EuclideanSpace ℝ (Fin p)) (hv : ‖v‖=1) {D : ℝ} (hD : 0 < D) :
    μ.real {ω | ‖(G ω).toEuclideanLin v‖^2 ≤ 4*(k:ℝ)/D^2} ≤
      Real.exp (k:ℝ)*(2/D)^N := by
  have h := gaussian_vector_norm_lower G hG hind hm v hv (4*(k:ℝ)/D^2) (-D^2/4) (by nlinarith [sq_nonneg D])
  have ha : -(-D^2/4)*(4*(k:ℝ)/D^2) = k := by field_simp
  have hx : 0 ≤ 1+D^2/2 := by positivity
  have hr : (1-2*(-D^2/4))^(-(Fintype.card (Fin N):ℝ)/2) =
      ((Real.sqrt (1+D^2/2))⁻¹)^N := by
    rw [show 1-2*(-D^2/4) = 1+D^2/2 by ring, Fintype.card_fin,
      show -(N:ℝ)/2 = -((1/2:ℝ)*(N:ℝ)) by ring,
      Real.rpow_neg hx, Real.rpow_mul hx, Real.rpow_natCast, ← Real.sqrt_eq_rpow, inv_pow]
  rw [ha,hr] at h
  have hs : (Real.sqrt (1+D^2/2))⁻¹ ≤ 2/D := by
    have hroot : D/2 ≤ Real.sqrt (1+D^2/2) := by
      nlinarith [Real.sq_sqrt hx, Real.sqrt_nonneg (1+D^2/2)]
    rw [← one_div]
    apply (div_le_div_iff₀ (Real.sqrt_pos.mpr (by positivity)) hD).mpr
    linarith
  exact h.trans (mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (by positivity) hs N) (by positivity))


/-- A concrete fine net for which the small-ball union event has probability at most 16^-p. -/
theorem exists_gaussian_small_ball_net_scale {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {N p k : ℕ} (hp : p≤k) (hN : 4*k ≤ 3*N)
    (G : Ω → Matrix (Fin N) (Fin p) ℝ)
    (hG : ∀ a : Fin N × Fin p, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin N × Fin p => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : Fin N × Fin p, Measurable (fun ω => G ω a.1 a.2)) :
    ∃ s : Finset (EuclideanSpace ℝ (Fin p)), (∀ v ∈ s, ‖v‖=1) ∧
      (s.card:ℝ) ≤ (41*1000000000000:ℝ)^k ∧
      (∀ x : EuclideanSpace ℝ (Fin p), ‖x‖=1 → ∃ v ∈ s, ‖x-v‖ ≤ 1/(20*1000000000000:ℝ)) ∧
      μ.real {ω | ∃ v ∈ s, ‖(G ω).toEuclideanLin v‖^2 ≤ 4*(k:ℝ)/(1000000000000:ℝ)^2} ≤
        (1/16:ℝ)^k := by
  obtain ⟨s,hs,hcard,hnet⟩ := exists_sphere_net_card_le (E := EuclideanSpace ℝ (Fin p))
    (η := 1/(20*1000000000000:ℝ)) (by norm_num)
  have hc : (s.card:ℝ) ≤ (41*1000000000000:ℝ)^k := by
    apply hcard.trans
    simp only [finrank_euclideanSpace, Fintype.card_fin]
    exact (pow_le_pow_left₀ (by norm_num) (by norm_num) p).trans
      (pow_le_pow_right₀ (by norm_num) hp)
  refine ⟨s,hs,hc,hnet,?_⟩
  have h := finite_union_probability_bound s
    (fun v => {ω | ‖(G ω).toEuclideanLin v‖^2 ≤ 4*(k:ℝ)/(1000000000000:ℝ)^2})
    (fun v hv => gaussian_vector_small_ball_scale G hG hind hm v (hs v hv) (by norm_num))
  apply h.trans
  calc
    _ ≤ (41*1000000000000:ℝ)^k * (Real.exp (k:ℝ)*(2/1000000000000:ℝ)^N) := by gcongr
    _ = (41*1000000000000:ℝ)^k * Real.exp (k:ℝ)*(2/1000000000000:ℝ)^N := by ring
    _ ≤ _ := small_ball_net_numeric hN

/-- The fine-net complement and the upper operator-norm event imply a lower singular bound. -/
theorem gaussian_net_lower_singular_scale {N p k : ℕ} (G : Matrix (Fin N) (Fin p) ℝ)
    (s : Finset (EuclideanSpace ℝ (Fin p)))
    (hnet : ∀ x : EuclideanSpace ℝ (Fin p), ‖x‖=1 → ∃ v ∈ s, ‖x-v‖ ≤ 1/(20*1000000000000:ℝ))
    (hupper : ‖G.toEuclideanLin.toContinuousLinearMap‖ ≤ 10*Real.sqrt k)
    (hlower : ∀ v ∈ s, 4*(k:ℝ)/(1000000000000:ℝ)^2 < ‖G.toEuclideanLin v‖^2) :
    ∀ x : EuclideanSpace ℝ (Fin p), ‖x‖=1 → Real.sqrt k/1000000000000 ≤ ‖G.toEuclideanLin x‖ := by
  have hb (v) (hv : v ∈ s) : 2*Real.sqrt (k:ℝ)/1000000000000 ≤ ‖G.toEuclideanLin v‖ := by
    nlinarith [hlower v hv, Real.sq_sqrt (Nat.cast_nonneg k), norm_nonneg (G.toEuclideanLin v), Real.sqrt_nonneg (k:ℝ)]
  have h := norm_lower_of_sphere_net G.toEuclideanLin.toContinuousLinearMap s (by norm_num) hupper hnet hb
  intro x hx
  have hh := h x hx
  change _ ≤ ‖G.toEuclideanLin x‖ at hh
  nlinarith [Real.sqrt_nonneg (k:ℝ)]

end SpectralComparison
