import SpectralComparison.StrictTheorem

noncomputable section
open Matrix Finset
namespace SpectralComparison

/-- Appending positive singleton weights preserves a weighted inverse-basis lower bound. -/
theorem weighted_singleton_extension {n p s : Type*} [Fintype n] [Fintype p] [Fintype s]
    [DecidableEq n] [DecidableEq p] [DecidableEq s]
    (Q : Matrix n p ℝ) (hQ : Qᴴ*Q=1) (b : p → ℝ) (d : s → ℝ) (hd : ∀ i,0≤d i)
    {C : ℝ} (hb : ∀ I : Finset n,I.card=Fintype.card p →
      IsUnit ((Q.submatrix (fun i : I => (i:n)) id)ᴴ*Q.submatrix (fun i : I => (i:n)) id) →
      C≤(Matrix.diagonal b*((Q.submatrix (fun i : I => (i:n)) id)ᴴ*Q.submatrix (fun i : I => (i:n)) id)⁻¹).trace) :
    let R : Matrix (n ⊕ s) (p ⊕ s) ℝ := Matrix.fromBlocks Q 0 0 1
    Rᴴ*R=1 ∧ ∀ J : Finset (n ⊕ s),J.card=Fintype.card (p ⊕ s) →
      IsUnit ((R.submatrix (fun i : J => (i:n ⊕ s)) id)ᴴ*R.submatrix (fun i : J => (i:n ⊕ s)) id) →
      C≤(Matrix.diagonal (Sum.elim b d)*
        ((R.submatrix (fun i : J => (i:n ⊕ s)) id)ᴴ*R.submatrix (fun i : J => (i:n ⊕ s)) id)⁻¹).trace := by
  classical
  let R : Matrix (n ⊕ s) (p ⊕ s) ℝ := Matrix.fromBlocks Q 0 0 1
  have hR : Rᴴ*R=1 := by
    dsimp [R]
    rw [Matrix.fromBlocks_conjTranspose,Matrix.fromBlocks_multiply]
    simp only [Matrix.conjTranspose_zero,Matrix.conjTranspose_one,Matrix.mul_zero,Matrix.zero_mul,
      Matrix.mul_one,add_zero,zero_add,hQ]
    exact Matrix.fromBlocks_one
  refine ⟨hR,?_⟩
  intro J hJ hunit
  let I := J.toLeft
  let G := (R.submatrix (fun i : J => (i:n ⊕ s)) id)ᴴ*R.submatrix (fun i : J => (i:n ⊕ s)) id
  let H := (Q.submatrix (fun i : I => (i:n)) id)ᴴ*Q.submatrix (fun i : I => (i:n)) id
  have hg : G=Matrix.fromBlocks H 0 0 (Matrix.diagonal (fun i : s => if Sum.inr i∈J then (1:ℝ) else 0)) := by
    dsimp [G,H]
    rw [row_selection_gram_eq,row_selection_gram_eq]
    have hdj : Matrix.diagonal (fun i : n ⊕ s => if i∈J then (1:ℝ) else 0)=
        Matrix.fromBlocks (Matrix.diagonal (fun i : n => if i∈I then (1:ℝ) else 0)) 0 0
          (Matrix.diagonal (fun i : s => if Sum.inr i∈J then (1:ℝ) else 0)) := by
      ext i j
      cases i <;> cases j <;> simp [I,Matrix.diagonal_apply]
    rw [hdj]
    dsimp [R]
    rw [Matrix.fromBlocks_conjTranspose,Matrix.fromBlocks_multiply,Matrix.fromBlocks_multiply]
    simp only [Matrix.conjTranspose_zero,Matrix.conjTranspose_one,Matrix.mul_zero,Matrix.zero_mul,
      Matrix.mul_one,Matrix.one_mul,add_zero,zero_add]
  have hG : G.PosDef := (posSemidef_conjTranspose_mul_self _).posDef_iff_isUnit.mpr hunit
  have hmem (j : s) : Sum.inr j∈J := by
    have hh := hG.diag_pos (i:=Sum.inr j)
    rw [hg] at hh
    by_contra hn
    simp [hn] at hh
  have htail : J.toRight=Finset.univ := by ext j; simp [hmem j]
  have hI : I.card=Fintype.card p := by
    have hh := Finset.card_toLeft_add_card_toRight (u:=J)
    rw [htail,Finset.card_univ,hJ,Fintype.card_sum] at hh
    dsimp [I]
    omega
  have hg' : G=Matrix.fromBlocks H 0 0 (1 : Matrix s s ℝ) := by
    rw [hg]
    simp only [hmem,ite_true,Matrix.diagonal_one]
  have hH : H.PosDef := by
    have hh := hG.submatrix Sum.inl_injective
    rw [hg'] at hh
    exact hh
  have hdiag : Matrix.diagonal (Sum.elim b d)=Matrix.fromBlocks (Matrix.diagonal b) 0 0 (Matrix.diagonal d) := by
    ext i j; cases i <;> cases j <;> simp [Matrix.diagonal_apply]
  have hinv : G⁻¹=Matrix.fromBlocks H⁻¹ 0 0 (1 : Matrix s s ℝ) := by
    rw [hg',block_diagonal_inverse hH.isUnit isUnit_one,inv_one]
  change C≤(Matrix.diagonal (Sum.elim b d)*G⁻¹).trace
  rw [hdiag,hinv,Matrix.fromBlocks_multiply]
  simp only [Matrix.mul_zero,Matrix.zero_mul,Matrix.mul_one,add_zero,zero_add]
  have htrace : (Matrix.fromBlocks (Matrix.diagonal b*H⁻¹) 0 0 (Matrix.diagonal d)).trace=(Matrix.diagonal b*H⁻¹).trace+∑ i,d i := by
    simp [Matrix.trace,Matrix.diag,Fintype.sum_sum_type]
  rw [htrace]
  have htail0 : 0≤∑ i,d i := Finset.sum_nonneg (fun i _ => hd i)
  have hh := hb I hI hH.isUnit
  change C≤(Matrix.diagonal b*H⁻¹).trace at hh
  linarith

end SpectralComparison
