import SpectralComparison.WorstOrientation
import Mathlib.Topology.Instances.Matrix
import Mathlib.Topology.Order.Compact
import Mathlib.Topology.Order.Lattice

/-! The outer maximum in the manuscript is attained, not merely a supremum. -/
noncomputable section
namespace SpectralComparison
open Matrix Finset
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Real orthogonal matrices form a compact set in the entrywise topology. -/
theorem orthogonal_set_isCompact : IsCompact {V : Matrix ι ι ℝ | V.transpose * V = 1} := by
  have hc : IsClosed {V : Matrix ι ι ℝ | V.transpose * V = 1} :=
    isClosed_eq (continuous_id.matrix_transpose.matrix_mul continuous_id) continuous_const
  apply (isCompact_Icc : IsCompact (Set.Icc (fun _ _ : ι => (-1:ℝ)) (fun _ _ : ι => (1:ℝ)))).of_isClosed_subset hc
  intro V hV
  change (Matrix.of V).transpose * Matrix.of V = (1 : Matrix ι ι ℝ) at hV
  have he (i j : ι) : V i j * V i j ≤ 1 := by
    have hs := congrArg (fun A : Matrix ι ι ℝ => A j j) hV
    simp only [Matrix.mul_apply, Matrix.transpose_apply, Matrix.one_apply_eq] at hs
    change (∑ l, V l j * V l j) = 1 at hs
    have h := Finset.single_le_sum (fun l (_ : l ∈ (Finset.univ : Finset ι)) => mul_self_nonneg (V l j)) (Finset.mem_univ i)
    rwa [hs] at h
  constructor <;> intro i j <;> have h := he i j <;> nlinarith

/-- Each actual residual trace is continuous at a positive definite matrix. -/
theorem continuousAt_residualTrace {K : Matrix ι ι ℝ} (hK : K.PosDef) (I : Finset ι) :
    ContinuousAt (fun A : Matrix ι ι ℝ => residualTrace A I) K := by
  have hp : Continuous (fun A : Matrix ι ι ℝ => principal A I) := continuous_id.matrix_submatrix _ _
  have hinv : ContinuousAt (fun A : Matrix ι ι ℝ => (principal A I)⁻¹) K := by
    apply (continuousAt_matrix_inv (principal K I) ?_).comp (f := fun A : Matrix ι ι ℝ => principal A I) hp.continuousAt
    rw [show (Ring.inverse : ℝ → ℝ) = (fun x : ℝ => x⁻¹) from funext Ring.inverse_eq_inv]
    exact continuousAt_inv₀ (principal_det_pos hK I).ne'
  have hl := (continuous_id.matrix_submatrix (id : ι → ι) (fun i : I => i.val)).continuousAt (x := K)
  have hr := (continuous_id.matrix_submatrix (fun i : I => i.val) (id : ι → ι)).continuousAt (x := K)
  have hm := (continuous_fst.matrix_mul continuous_snd).continuousAt.comp (hl.prodMk hinv)
  have hm' := (continuous_fst.matrix_mul continuous_snd).continuousAt.comp (hm.prodMk hr)
  exact continuous_id.matrix_trace.continuousAt.comp (continuousAt_id.sub hm')

/-- The set infimum agrees with a finite infimum, for the actual nonempty selection family. -/
theorem bestError_eq_finset_inf' (K : Matrix ι ι ℝ) {k : ℕ} (hk : k ≤ Fintype.card ι) :
    bestError K k = ((Finset.univ : Finset ι).powersetCard k).inf'
      (Finset.powersetCard_nonempty.mpr (by simpa using hk)) (residualTrace K) := by
  apply le_antisymm
  · apply Finset.le_inf'
    intro I hI
    exact bestError_le K (Finset.mem_powersetCard.mp hI).2
  · apply le_bestError K hk
    intro I hI
    exact Finset.inf'_le _ (Finset.mem_powersetCard.mpr ⟨Finset.subset_univ _, hI⟩)

/-- The best-selection objective is continuous over the orthogonal orbit. -/
theorem continuousOn_orbit_bestError (eig : ι → ℝ) (heig : ∀ i, 0 < eig i)
    {k : ℕ} (hk : k ≤ Fintype.card ι) :
    ContinuousOn (fun V : Matrix ι ι ℝ => bestError (V.transpose * Matrix.diagonal eig * V) k)
      {V | V.transpose * V = 1} := by
  simp_rw [bestError_eq_finset_inf' _ hk]
  apply ContinuousOn.finset_inf'_apply
  intro I hI V hV
  have ho : Continuous (fun V : Matrix ι ι ℝ => V.transpose * Matrix.diagonal eig * V) :=
    (continuous_id.matrix_transpose.matrix_mul continuous_const).matrix_mul continuous_id
  exact ((continuousAt_residualTrace (orbit_posDef eig heig V hV) I).comp (f := fun W : Matrix ι ι ℝ => W.transpose * Matrix.diagonal eig * W) ho.continuousAt).continuousWithinAt

/-- The supremum defining worstError is the manuscript's attained maximum. -/
theorem worstError_attained (eig : ι → ℝ) (heig : ∀ i, 0 < eig i)
    {k : ℕ} (hk : k < Fintype.card ι) :
    ∃ V : Matrix ι ι ℝ, V.transpose * V = 1 ∧
      worstError eig k = bestError (V.transpose * Matrix.diagonal eig * V) k := by
  obtain ⟨V, hV, hmax⟩ := orthogonal_set_isCompact.exists_isMaxOn
    (show ({V : Matrix ι ι ℝ | V.transpose * V = 1} : Set _).Nonempty from ⟨1, by simp⟩)
    (continuousOn_orbit_bestError eig heig hk.le)
  refine ⟨V, hV, le_antisymm ?_ (orbit_bestError_le_worstError eig heig V hV hk)⟩
  apply csSup_le (orbitErrors_nonempty eig k)
  rintro b ⟨W, hW, rfl⟩
  exact hmax hW

end SpectralComparison
