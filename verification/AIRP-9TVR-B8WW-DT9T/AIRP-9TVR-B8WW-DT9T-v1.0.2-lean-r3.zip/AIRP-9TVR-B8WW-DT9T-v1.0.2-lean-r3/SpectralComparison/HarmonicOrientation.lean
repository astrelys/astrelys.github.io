import SpectralComparison.ShiftedTheorem

noncomputable section
open Matrix Finset
namespace SpectralComparison

/-- Principal compression version of the matrix inverse order gap. -/
theorem inverse_submatrix_difference {ι κ : Type*} [Fintype ι] [Fintype κ] [DecidableEq ι] [DecidableEq κ]
    {T : Matrix ι ι ℝ} (hT : T.PosDef) (e : κ → ι) (he : Function.Injective e) :
    (T⁻¹.submatrix e e-(T.submatrix e e)⁻¹).PosSemidef := by
  let U : Matrix ι κ ℝ := (1 : Matrix ι ι ℝ).submatrix id e
  have hUt : U.conjTranspose=(1 : Matrix ι ι ℝ).submatrix e id := by simp [U]
  have hU : U.conjTranspose*U=1 := by
    rw [hUt]
    change (1 : Matrix ι ι ℝ).submatrix e (Equiv.refl ι)*U=_
    rw [Matrix.one_submatrix_mul]
    exact Matrix.submatrix_one e he
  have hcomp (A : Matrix ι ι ℝ) : U.conjTranspose*A*U=A.submatrix e e := by
    rw [hUt]
    change (1 : Matrix ι ι ℝ).submatrix e (Equiv.refl ι)*A*(1 : Matrix ι ι ℝ).submatrix (Equiv.refl ι) e=_
    rw [Matrix.one_submatrix_mul,Matrix.mul_submatrix_one]
    rfl
  simpa only [hcomp] using inverse_compression_difference_posSemidef hT U hU

/-- Every inverse diagonal dominates the reciprocal original diagonal. -/
theorem inverse_diagonal_lower {ι : Type*} [Fintype ι] [DecidableEq ι]
    {T : Matrix ι ι ℝ} (hT : T.PosDef) (i : ι) : (T i i)⁻¹≤T⁻¹ i i := by
  let e : Fin 1 → ι := fun _ => i
  have h := inverse_submatrix_difference hT e (fun _ _ _ => Subsingleton.elim _ _)
  have he : T.submatrix e e=Matrix.diagonal (fun _ : Fin 1 => T i i) := by
    ext a b
    have hh : a=b := Subsingleton.elim _ _
    subst b
    simp [e]
  rw [he,positive_diagonal_inverse _ (fun _ => hT.diag_pos)] at h
  have hh := h.diag_nonneg (i:=0)
  simpa [e,one_div] using (sub_nonneg.mp hh)

/-- The exact reciprocal precision-diagonal lower sum for any Nyström selection. -/
theorem residualTrace_precision_diagonal_lower {ι : Type*} [Fintype ι] [DecidableEq ι]
    {K : Matrix ι ι ℝ} (hK : K.PosDef) (I : Finset ι) :
    (∑ j∈Finset.univ\I,(K⁻¹ j j)⁻¹)≤residualTrace K I := by
  rw [nystrom_trace_inverse_complement hK I,← Finset.sum_coe_sort (Finset.univ\I)]
  exact Finset.sum_le_sum (fun j _ => inverse_diagonal_lower (principal_posDef hK.inv _) j)

/-- An arbitrary symmetric matrix can be orthogonally conjugated to constant diagonal. -/
theorem exists_orthogonal_constant_diagonal {n : ℕ} (hn : 0<n)
    (A : Matrix (Fin n) (Fin n) ℝ) (hA : A.IsHermitian) :
    ∃ V : Matrix (Fin n) (Fin n) ℝ,Vᴴ*V=1 ∧ ∀ i,(Vᴴ*A*V) i i=A.trace/(n:ℝ) := by
  let c := A.trace/(n:ℝ)
  have hn0 : (n:ℝ)≠0 := by exact_mod_cast (Nat.ne_of_gt hn)
  have hB : (A-c • (1 : Matrix (Fin n) (Fin n) ℝ)).IsHermitian := hA.sub (Matrix.isHermitian_one.smul (by rfl))
  have ht : (A-c • (1 : Matrix (Fin n) (Fin n) ℝ)).trace=0 := by
    rw [Matrix.trace_sub,Matrix.trace_smul,Matrix.trace_one]
    simp [c,hn0]
  obtain ⟨V,hV,hd⟩ := exists_orthogonal_zero_diagonal n _ hB ht
  refine ⟨V,hV,?_⟩
  intro i
  have hh := hd i
  have he : Vᴴ*(A-c • (1 : Matrix (Fin n) (Fin n) ℝ))*V=Vᴴ*A*V-c • 1 := by
    rw [Matrix.mul_sub,Matrix.sub_mul,Matrix.mul_smul,Matrix.smul_mul,Matrix.mul_one,hV]
  rw [he] at hh
  have hh' : (Vᴴ*A*V) i i-c=0 := by simpa using hh
  exact sub_eq_zero.mp hh'

/-- Harmonic orientation: all precision diagonals equal the reciprocal harmonic mean. -/
theorem exists_harmonic_orientation {n : ℕ} (hn : 0<n) (a : Fin n → ℝ) (ha : ∀ i,0<a i) :
    ∃ V : Matrix (Fin n) (Fin n) ℝ,V.transpose*V=1 ∧
      ∀ i,((V.transpose*Matrix.diagonal a*V)⁻¹) i i=(∑ j,(a j)⁻¹)/(n:ℝ) := by
  obtain ⟨V,hV,hd⟩ := exists_orthogonal_constant_diagonal hn (Matrix.diagonal (fun j => (a j)⁻¹))
    (Matrix.isHermitian_diagonal_iff.mpr (by intro i; rfl))
  have hVt : V.transpose*V=1 := by simpa only [Matrix.conjTranspose_eq_transpose_of_trivial] using hV
  have hVV : V*Vᴴ=1 := mul_eq_one_comm.mp hV
  refine ⟨V,hVt,?_⟩
  intro i
  have hi := inverse_orthogonal_spectrum Vᴴ (by simpa using hVV) a ha
  simp only [Matrix.conjTranspose_eq_transpose_of_trivial,Matrix.transpose_transpose] at hi
  rw [hi]
  simpa only [Matrix.trace_diagonal,Matrix.conjTranspose_eq_transpose_of_trivial] using hd i

end SpectralComparison
