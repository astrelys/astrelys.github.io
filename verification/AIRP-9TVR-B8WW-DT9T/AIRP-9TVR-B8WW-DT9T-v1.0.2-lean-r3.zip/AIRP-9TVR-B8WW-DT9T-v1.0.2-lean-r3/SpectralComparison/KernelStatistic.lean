import SpectralComparison.KernelWhitening

/-! A measurable, basis-independent kernel inverse-trace statistic. -/
noncomputable section
open Matrix MeasureTheory
namespace SpectralComparison

/-- Invert a positive block on an orthonormal subspace, extending by identity on its complement. -/
theorem inverse_orthonormal_extension {p d : Type*} [Fintype p] [Fintype d]
    [DecidableEq p] [DecidableEq d] (U : Matrix p d ℝ) (hU : Uᴴ*U=1)
    (K : Matrix d d ℝ) (hK : K.PosDef) :
    (U*K*Uᴴ+(1-U*Uᴴ))⁻¹=U*K⁻¹*Uᴴ+(1-U*Uᴴ) := by
  let F : Matrix p p ℝ := 1-U*Uᴴ
  have hFU : F*U=0 := by
    dsimp [F]
    rw [Matrix.sub_mul,Matrix.one_mul,Matrix.mul_assoc,hU,Matrix.mul_one,sub_self]
  have hUF : Uᴴ*F=0 := by
    dsimp [F]
    rw [Matrix.mul_sub,Matrix.mul_one,← Matrix.mul_assoc,hU,Matrix.one_mul,sub_self]
  have hFF : F*F=F := by
    conv_lhs => rhs; dsimp [F]
    rw [Matrix.mul_sub,Matrix.mul_one,← Matrix.mul_assoc,hFU,Matrix.zero_mul,sub_zero]
  have hKK := Matrix.mul_nonsing_inv K (isUnit_iff_ne_zero.mpr hK.det_pos.ne')
  have hmain : (U*K*Uᴴ)*(U*K⁻¹*Uᴴ)=U*Uᴴ := by
    calc
      _ = U*K*(Uᴴ*U)*K⁻¹*Uᴴ := by simp only [Matrix.mul_assoc]
      _ = _ := by rw [hU,Matrix.mul_one,Matrix.mul_assoc U K K⁻¹,hKK,Matrix.mul_one]
  have hleft : (U*K*Uᴴ)*F=0 := by rw [Matrix.mul_assoc,hUF,Matrix.mul_zero]
  have hright : F*(U*K⁻¹*Uᴴ)=0 := by rw [← Matrix.mul_assoc,← Matrix.mul_assoc,hFU,Matrix.zero_mul,Matrix.zero_mul]
  apply Matrix.inv_eq_right_inv
  change (U*K*Uᴴ+F)*(U*K⁻¹*Uᴴ+F)=1
  rw [Matrix.add_mul,Matrix.mul_add,Matrix.mul_add,hmain,hleft,hright,hFF]
  dsimp [F]
  abel

/-- The trace of the extension separates into the subspace trace and complement dimension. -/
theorem trace_inverse_orthonormal_extension {p d : Type*} [Fintype p] [Fintype d]
    [DecidableEq p] [DecidableEq d] (U : Matrix p d ℝ) (hU : Uᴴ*U=1)
    (K : Matrix d d ℝ) (hK : K.PosDef) :
    (U*K*Uᴴ+(1-U*Uᴴ))⁻¹.trace-((Fintype.card p:ℝ)-Fintype.card d)=K⁻¹.trace := by
  rw [inverse_orthonormal_extension U hU K hK,Matrix.trace_add,Matrix.trace_sub,
    Matrix.trace_mul_cycle,hU,Matrix.one_mul,Matrix.trace_one,
    Matrix.trace_mul_comm U Uᴴ,hU,Matrix.trace_one]
  ring

/-- Compression by the actual kernel projector has the same inverse trace in every orthonormal basis. -/
theorem kernel_projector_statistic_eq {h l p d : Type*} [Fintype h] [Fintype l]
    [Fintype p] [Fintype d] [DecidableEq h] [DecidableEq p] [DecidableEq d]
    (H : Matrix h p ℝ) (X : Matrix l p ℝ) (U : Matrix p d ℝ)
    (hU : Uᴴ*U=1) (hproj : U*Uᴴ=1-Hᴴ*(H*Hᴴ)⁻¹*H)
    (hd : Fintype.card d+Fintype.card h=Fintype.card p)
    (hK : ((X*U)ᴴ*(X*U)).PosDef) :
    let E := 1-Hᴴ*(H*Hᴴ)⁻¹*H
    (E*Xᴴ*X*E+(1-E))⁻¹.trace-(Fintype.card h:ℝ)=((X*U)ᴴ*(X*U))⁻¹.trace := by
  dsimp only
  rw [← hproj]
  have he : U*Uᴴ*Xᴴ*X*(U*Uᴴ)=U*((X*U)ᴴ*(X*U))*Uᴴ := by
    simp only [Matrix.conjTranspose_mul,Matrix.mul_assoc]
  have hdim : (Fintype.card p:ℝ)-Fintype.card d=Fintype.card h := by
    have hh : (Fintype.card d:ℝ)+Fintype.card h=Fintype.card p := by exact_mod_cast hd
    linarith
  rw [he,← hdim]
  exact trace_inverse_orthonormal_extension U hU _ hK

/-- A literal rational matrix statistic avoids choosing a measurable family of kernel bases. -/
def kernelInverseTrace {h l p : Type*} [Fintype h] [Fintype l] [Fintype p]
    [DecidableEq h] [DecidableEq p] (H : Matrix h p ℝ) (X : Matrix l p ℝ) : ℝ :=
  let E := 1-Hᴴ*(H*Hᴴ)⁻¹*H
  (E*Xᴴ*X*E+(1-E))⁻¹.trace-(Fintype.card h:ℝ)

/-- The basis-independent kernel statistic is measurable in both row blocks, including singular inputs. -/
theorem measurable_kernelInverseTrace {h l p : Type*} [Fintype h] [Fintype l] [Fintype p]
    [DecidableEq h] [DecidableEq p] :
    Measurable (fun z : Matrix h p ℝ × Matrix l p ℝ => kernelInverseTrace z.1 z.2) := by
  have hg : Measurable (fun z : Matrix h p ℝ × Matrix l p ℝ => z.1*z.1ᴴ) := by
    apply Measurable.of_eval_matrix
    intro i j
    simp only [Matrix.mul_apply,Matrix.conjTranspose_apply,star_trivial]
    fun_prop
  have hi := measurable_matrix_inverse.comp hg
  have he : Measurable (fun z : Matrix h p ℝ × Matrix l p ℝ => (1 : Matrix p p ℝ)-z.1ᴴ*(z.1*z.1ᴴ)⁻¹*z.1) := by
    apply Measurable.of_eval_matrix
    intro i j
    simp only [Matrix.sub_apply,Matrix.mul_apply,Matrix.conjTranspose_apply,star_trivial]
    apply measurable_const.sub
    apply Finset.measurable_sum
    intro k _
    apply Measurable.mul _ (by fun_prop)
    apply Finset.measurable_sum
    intro a _
    apply Measurable.mul (by fun_prop) hi.eval_matrix
  let E := fun z : Matrix h p ℝ × Matrix l p ℝ => (1 : Matrix p p ℝ)-z.1ᴴ*(z.1*z.1ᴴ)⁻¹*z.1
  have hb : Measurable (fun z : Matrix h p ℝ × Matrix l p ℝ => E z*z.2ᴴ*z.2*E z+(1-E z)) := by
    apply Measurable.of_eval_matrix
    intro i j
    simp only [Matrix.add_apply,Matrix.sub_apply,Matrix.mul_apply,Matrix.conjTranspose_apply,star_trivial]
    apply Measurable.add
    · apply Finset.measurable_sum
      intro a _
      apply Measurable.mul _ he.eval_matrix
      apply Finset.measurable_sum
      intro b _
      apply Measurable.mul _ (by fun_prop)
      apply Finset.measurable_sum
      intro c _
      exact he.eval_matrix.mul (by fun_prop)
    · exact measurable_const.sub he.eval_matrix
  have ht : Measurable (fun z : Matrix h p ℝ × Matrix l p ℝ => (E z*z.2ᴴ*z.2*E z+(1-E z))⁻¹.trace) := by
    exact Finset.measurable_sum _ (fun i _ => (measurable_matrix_inverse.comp hb).eval_matrix)
  exact ht.sub_const _

end SpectralComparison
