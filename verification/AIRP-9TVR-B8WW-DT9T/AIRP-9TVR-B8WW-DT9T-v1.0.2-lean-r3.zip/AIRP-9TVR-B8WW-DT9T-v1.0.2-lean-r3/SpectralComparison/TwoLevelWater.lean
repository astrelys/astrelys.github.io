import SpectralComparison.NormalizedShape

noncomputable section
open Finset Filter Topology
namespace SpectralComparison

theorem twoLevelSpectrum_antitone {k m : ℕ} {ε : ℝ} (hε : ε ≤ 1) :
    Antitone (twoLevelSpectrum k m ε) := by
  intro i j hij
  simp only [twoLevelSpectrum]
  split_ifs <;> first | rfl | exact hε | omega

theorem two_level_water_root {k m : ℕ} (hk : 1 ≤ k) (hm : 1 ≤ m)
    {ε : ℝ} (hε : 0 < ε) (hε1 : ε ≤ 1) :
    let τ := (m:ℝ)*ε/((m:ℝ)+(k:ℝ)*ε)
    0 < τ ∧ τ < ε ∧ waterSum (twoLevelSpectrum k m ε) τ = k := by
  dsimp only
  let τ := (m:ℝ)*ε/((m:ℝ)+(k:ℝ)*ε)
  have hk0 : (0:ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hm0 : (0:ℝ) < m := by exact_mod_cast (show 0 < m by omega)
  have hd : 0 < (m:ℝ)+(k:ℝ)*ε := by positivity
  have ht : 0 < τ := by dsimp [τ]; positivity
  have hte : τ < ε := by
    apply (div_lt_iff₀ hd).mpr
    nlinarith [mul_pos hk0 (sq_pos_of_pos hε)]
  refine ⟨ht,hte,?_⟩
  have ht1 : τ < 1 := hte.trans_le hε1
  have he : 0 ≤ 1-τ/ε := sub_nonneg.mpr ((div_le_one hε).mpr hte.le)
  dsimp only [waterSum]
  rw [← Equiv.sum_comp (finSumFinEquiv : Fin k ⊕ Fin m ≃ Fin (k+m))]
  simp only [Fintype.sum_sum_type,twoLevelSpectrum_inl,twoLevelSpectrum_inr,div_one,
    sum_const,card_univ,Fintype.card_fin,nsmul_eq_mul]
  change (k:ℝ)*max (1-τ) 0+(m:ℝ)*max (1-τ/ε) 0=k
  rw [max_eq_left (sub_nonneg.mpr ht1.le),max_eq_left he]
  dsimp [τ]
  field_simp
  <;> ring

theorem harmonicEnvelope_two_level {k m : ℕ} (hk : 1 ≤ k) (hm : 1 ≤ m)
    {ε : ℝ} (hε : 0 < ε) (hε1 : ε ≤ 1) :
    harmonicEnvelope (twoLevelSpectrum k m ε) k (by omega) =
      ((k+m:ℕ):ℝ)*((m:ℝ)*ε/((m:ℝ)+(k:ℝ)*ε)) := by
  have hh := two_level_water_root hk hm hε hε1
  rw [harmonicEnvelope_eq_water _ (twoLevelSpectrum_pos hε) (twoLevelSpectrum_antitone hε1) hk (by omega) hh.1 hh.2.2]
  have ht : (m:ℝ)*ε/((m:ℝ)+(k:ℝ)*ε) ≤ ε := hh.2.1.le
  have he (i : Fin (k+m)) : (m:ℝ)*ε/((m:ℝ)+(k:ℝ)*ε) ≤ twoLevelSpectrum k m ε i := by
    dsimp [twoLevelSpectrum]
    split_ifs
    · exact ht.trans hε1
    · exact ht
  simp only [min_eq_right (he _),sum_const,card_univ,Fintype.card_fin,nsmul_eq_mul]

end SpectralComparison
