import SpectralComparison.HarmonicOrientation

noncomputable section
open Matrix Finset
namespace SpectralComparison

theorem extend_prefix_precision_blocks {m n l : Type*} [Fintype m] [Fintype n] [Fintype l]
    [DecidableEq m] [DecidableEq n] [DecidableEq l]
    (e : (m ⊕ n) ≃ l) (eig : l → ℝ) (heig : ∀ i,0<eig i)
    (V : Matrix m m ℝ) (hV : V.transpose*V=1) :
    ∃ W : Matrix l l ℝ, W.transpose*W=1 ∧
      ((W.transpose*Matrix.diagonal eig*W)⁻¹).submatrix e e=
        Matrix.fromBlocks (V.transpose*Matrix.diagonal (fun i => eig (e (Sum.inl i)))*V)⁻¹ 0 0
          (Matrix.diagonal (fun i => (eig (e (Sum.inr i)))⁻¹)) := by
  let B := Matrix.fromBlocks V 0 0 (1 : Matrix n n ℝ)
  have hB : B.transpose*B=1 := block_orthogonal_extension V hV
  let W := B.submatrix e.symm e.symm
  have hW : W.transpose*W=1 := by
    change (B.submatrix e.symm e.symm).transpose*B.submatrix e.symm e.symm=1
    rw [Matrix.transpose_submatrix,Matrix.submatrix_mul_equiv,hB]
    exact Matrix.submatrix_one e.symm e.symm.injective
  let A := V.transpose*Matrix.diagonal (fun i => eig (e (Sum.inl i)))*V
  let D : Matrix n n ℝ := Matrix.diagonal (fun i => eig (e (Sum.inr i)))
  have hA : A.PosDef := orbit_posDef _ (fun i => heig _) V hV
  have hD : D.PosDef := Matrix.PosDef.diagonal (fun i => heig _)
  have he : (W.transpose*Matrix.diagonal eig*W).submatrix e e=Matrix.fromBlocks A 0 0 D := by
    have hw : W.submatrix e e=B := by ext a b; simp [W]
    have hd : (Matrix.diagonal eig).submatrix e e =
        Matrix.fromBlocks (Matrix.diagonal (fun i => eig (e (Sum.inl i)))) 0 0 D := by
      rw [Matrix.submatrix_diagonal_equiv]
      ext a b
      cases a <;> cases b <;> simp [D,Matrix.diagonal_apply]
    rw [← Matrix.submatrix_mul_equiv _ _ e e e,← Matrix.submatrix_mul_equiv _ _ e e e,
      ← Matrix.transpose_submatrix,hw,hd]
    simp only [B,Matrix.fromBlocks_transpose,Matrix.transpose_zero,Matrix.transpose_one,
      Matrix.fromBlocks_multiply,Matrix.mul_zero,Matrix.zero_mul,Matrix.mul_one,Matrix.one_mul,
      add_zero,zero_add,A]
  refine ⟨W,hW,?_⟩
  have hh := congrArg (fun M : Matrix (m ⊕ n) (m ⊕ n) ℝ => M⁻¹) he
  have hDinv : D⁻¹=Matrix.diagonal (fun i => (eig (e (Sum.inr i)))⁻¹) :=
    by simpa only [D,one_div] using positive_diagonal_inverse (fun i : n => eig (e (Sum.inr i))) (fun i => heig _)
  rw [Matrix.inv_submatrix_equiv,block_diagonal_inverse hA.isUnit hD.isUnit,hDinv] at hh
  exact hh

end SpectralComparison
