import SpectralComparison.DiffuseLabels
import SpectralComparison.SelectionResidual
import SpectralComparison.DiffusePaperGroups
import SpectralComparison.DiffusePrefix

/-! Complete prescribed-spectrum diffuse witness for the original coordinate-selection objective. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- The diffuse branch of (7.1), on the original spectrum, with one covariance for every selection. -/
theorem diffuse_bound_of_small_prefix {n k q : ℕ} (eig : Fin n → ℝ)
    (heig : ∀ i,0<eig i) (horder : Antitone eig) (hk : 1≤k) (hkn : k<n) (hq : 4*q≤k)
    (hsmall : (∑ j : Fin (min (n-k) (8*k)),eig ⟨k+j.val,by have := j.isLt; omega⟩)<
      (∑ i∈Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n),eig i)/2) :
    let s := ∑ i∈Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n),eig i
    let a := eig ⟨k-q-1,by omega⟩
    let V := (k:ℝ)*s/(64000000000000000000000000000*((q:ℝ)+Real.sqrt k)*H (8*k))
    a*V/(a+V)≤worstError eig k := by
  classical
  let s := ∑ i∈Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n),eig i
  let a := eig ⟨k-q-1,by omega⟩
  let Vscale := (k:ℝ)*s/(64000000000000000000000000000*((q:ℝ)+Real.sqrt k)*H (8*k))
  have hs : 0<s := by
    dsimp [s]
    rw [← indexed_tail_sum hkn eig]
    exact Finset.sum_pos (fun i _ => heig _) ⟨⟨0,by omega⟩,Finset.mem_univ _⟩
  obtain ⟨p,hn,hp,S,hS,hreserve,f,hf,hmass⟩ := paper_diffuse_reserve_and_groups eig heig horder hk hkn hq hsmall
  let d : ↥Sᶜ → ℝ := fun i => eig ⟨9*k+i.val.val,by have := i.val.isLt; omega⟩
  let b : S → ℝ := fun i => eig ⟨9*k+i.val.val,by have := i.val.isLt; omega⟩
  let z : Fin (q+8*k) → ℝ := fun i => eig ⟨k-q+i.val,by have := i.isLt; omega⟩
  let av : Fin (k-q) → ℝ := fun i => eig ⟨i.val,by have := i.isLt; omega⟩
  obtain ⟨Q0,hQ0,hres⟩ := exists_diffuse_residual_frame hk hq
  have hdim : Fintype.card S+Fintype.card (Fin (k-q))=Fintype.card (Fin (2*k)) := by
    simp only [Fintype.card_coe,Fintype.card_fin,hS]
    omega
  obtain ⟨V,Q,C,D,u,hV,hV',hQ,hQC,hC,hD,hCD,hrow,hcross,hdiag,hspec⟩ :=
    exists_full_group_model f d (fun _ => heig _) Q0 hQ0 hdim b (fun _ => heig _) z (fun _ => heig _)
  let N := (Σ j : Fin (2*k),Fin 1 ⊕ {i : ↥Sᶜ // f i=j}) ⊕ Fin (q+8*k)
  let group : N → Option (Fin (2*k)) := Sum.elim (fun x => some x.1) (fun _ => none)
  have hSc : S.card+(Sᶜ).card=p := by simp
  have hGroup := Fintype.card_congr (groupCoordinateEquiv f)
  simp only [Fintype.card_sum,Fintype.card_fin,Fintype.card_coe] at hGroup
  have hN : n=Fintype.card N := by
    dsimp [N]
    rw [Fintype.card_sum,Fintype.card_fin,← hGroup]
    omega
  let c : Fin n ≃ N := Fintype.equivOfCardEq (by simpa only [Fintype.card_fin] using hN)
  obtain ⟨e,her,heh,hep,hes⟩ := exists_diffuse_spectral_labels (show q≤k by omega) hn S
  have heiglab : (fun j => eig (e j))=Sum.elim (Sum.elim (Sum.elim av b) d) z := by
    funext j
    rcases j with ((j|j)|j)|j
    · exact congrArg eig (Fin.ext (her j))
    · exact congrArg eig (Fin.ext (heh j))
    · exact congrArg eig (Fin.ext (hep j))
    · exact congrArg eig (Fin.ext (hes j))
  obtain ⟨O,hO,hOK⟩ := reindex_spectral_orientation V hV hV' e c eig
  rw [heiglab,hspec av] at hOK
  let Q' := Q.submatrix c id
  let C' := C.submatrix c c
  let D' := D.submatrix c c
  let A := Matrix.diagonal av
  have hQ' : Q'ᴴ*Q'=1 := by
    rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,Matrix.submatrix_id_id,hQ]
  have hQC' : Q'ᴴ*C'=0 := by
    rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,hQC]
    rfl
  have hK : O.transpose*Matrix.diagonal eig*O=Q'*A*Q'ᴴ+C' := by
    rw [hOK]
    change (Q*A*Qᴴ+C).submatrix c c=_
    change (Q*A*Qᴴ).submatrix c c+C.submatrix c c=_
    rw [Matrix.submatrix_mul _ _ c id c Function.bijective_id,
      Matrix.submatrix_mul _ _ c id id Function.bijective_id,Matrix.submatrix_id_id]
    rfl
  have hKpd : (Q'*A*Q'ᴴ+C').PosDef := hK ▸ orbit_posDef eig heig O hO
  have hA : A.PosDef := Matrix.PosDef.diagonal (fun _ => heig _)
  have hAa : (A-a•1).PosSemidef := by
    have hval : ∀ i : Fin (k-q),0≤av i-a := by
      intro i
      apply sub_nonneg.mpr
      apply horder
      change i.val≤k-q-1
      have := i.isLt
      omega
    convert Matrix.PosSemidef.diagonal (d:=fun i : Fin (k-q) => av i-a) hval using 1
    ext i j
    by_cases hij : i=j
    · subst j; simp [A]
    · simp [A,hij]
  have hmass' (j : Fin (2*k)) : s/(8*k)≤∑ i : {i : ↥Sᶜ // f i=j},d i.val := by
    have hh := (hmass j).le
    change s/(8*k)≤∑ i : ↥Sᶜ,if f i=j then d i else 0 at hh
    simpa only [← Finset.sum_filter,← Finset.sum_subtype_eq_sum_filter,Finset.subtype_univ] using hh
  have hbound : a*Vscale/(a+Vscale)≤bestError (Q'*A*Q'ᴴ+C') k := by
    apply le_bestError _ (by simpa only [Fintype.card_fin] using hkn.le)
    intro I hI
    apply hres (Fin n) (fun i => group (c i)) (fun i => u (c i)) Q' hQ'
      (by intro i j; cases hc : c i <;> simpa [Q',group,hc] using hrow (c i) j)
      C' D' hQC' (hC.submatrix c) (hD.submatrix c) (hCD.submatrix c)
      (fun i x hix => hcross (c i) (c x) hix)
      (fun j => ∑ i : {i : ↥Sᶜ // f i=j},d i.val)
      (fun i j hij => hdiag (c i) j hij) a s (heig _) hs hmass' A hA hAa hKpd I hI
  rw [← hK] at hbound
  exact hbound.trans (orbit_bestError_le_worstError eig heig O hO (by simpa only [Fintype.card_fin] using hkn))

end SpectralComparison
