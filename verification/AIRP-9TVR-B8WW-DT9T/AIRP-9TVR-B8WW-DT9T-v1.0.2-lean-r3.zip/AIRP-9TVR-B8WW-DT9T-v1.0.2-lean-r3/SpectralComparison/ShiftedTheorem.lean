import SpectralComparison.ShiftedLimit

noncomputable section
open Filter Topology Finset
namespace SpectralComparison

def finiteSpectrumMin {m : ℕ} (b : Fin m → ℝ) (hm : 0<m) : ℝ :=
  Finset.univ.inf' ⟨⟨0,hm⟩,Finset.mem_univ _⟩ b

def finiteSpectrumMax {m : ℕ} (b : Fin m → ℝ) (hm : 0<m) : ℝ :=
  Finset.univ.sup' ⟨⟨0,hm⟩,Finset.mem_univ _⟩ b

theorem finiteSpectrum_extrema {m : ℕ} (b : Fin m → ℝ) (hm : 0<m) (hb : ∀ i,0<b i) :
    0<finiteSpectrumMin b hm ∧ 0<finiteSpectrumMax b hm ∧
      (∀ i,finiteSpectrumMin b hm≤b i ∧ b i≤finiteSpectrumMax b hm) ∧
      (∃ i,finiteSpectrumMin b hm=b i) ∧ (∃ i,finiteSpectrumMax b hm=b i) := by
  have hl : ∀ i,finiteSpectrumMin b hm≤b i := fun i => Finset.inf'_le b (Finset.mem_univ i)
  have hu : ∀ i,b i≤finiteSpectrumMax b hm := fun i => Finset.le_sup' b (Finset.mem_univ i)
  have hp : 0<finiteSpectrumMin b hm := (Finset.lt_inf'_iff _).mpr (fun i _ => hb i)
  obtain ⟨i,_,hi⟩ := Finset.exists_mem_eq_inf' (s:=Finset.univ) ⟨⟨0,hm⟩,Finset.mem_univ _⟩ b
  obtain ⟨j,_,hj⟩ := Finset.exists_mem_eq_sup' (s:=Finset.univ) ⟨⟨0,hm⟩,Finset.mem_univ _⟩ b
  exact ⟨hp,(hb ⟨0,hm⟩).trans_le (hu _),fun i => ⟨hl i,hu i⟩,⟨i,hi⟩,⟨j,hj⟩⟩

/-- The final numerical simplification in (B.2), keeping the original 10^23. -/
theorem shifted_coefficient_bound {k q : ℕ} (hk : 4≤k)
    (b : Fin (k+q) → ℝ) (hb : ∀ i,0<b i) {bmin bmax : ℝ}
    (hbmin : 0<bmin) (hbmax : 0≤bmax) (hupper : ∀ i,b i≤bmax) :
    let L := (k:ℝ)^2/(100000000000000000000000*((q:ℝ)+Real.sqrt k))
    ((k:ℝ)+1)*(Finset.univ.val.map b).esymm (q+1)/(bmin*L*(Finset.univ.val.map b).esymm q)≤
      100000000000000000000000*(bmax/bmin)*((k:ℝ)+1)/Real.sqrt k := by
  let L := (k:ℝ)^2/(100000000000000000000000*((q:ℝ)+Real.sqrt k))
  let E0 := (Finset.univ.val.map b).esymm q
  let E1 := (Finset.univ.val.map b).esymm (q+1)
  change ((k:ℝ)+1)*E1/(bmin*L*E0)≤_
  have hk0 : (0:ℝ)<k := by exact_mod_cast (by omega : 0<k)
  have hs : 0<Real.sqrt (k:ℝ) := Real.sqrt_pos.mpr hk0
  have hq0 : (0:ℝ)≤q := Nat.cast_nonneg _
  have hq1 : (0:ℝ)<(q:ℝ)+1 := by positivity
  have hL : 0<L := by dsimp [L]; positivity
  have he0 : 0<E0 := esymm_pos _ (by intro z hz; obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz; exact hb i) _ (by simp)
  have hext := esymm_extension_upper b (fun i => (hb i).le) hupper (by omega : q≤k+q)
  simp only [Nat.add_sub_cancel] at hext
  change ((q:ℝ)+1)*E1≤(k:ℝ)*bmax*E0 at hext
  have hf : (k:ℝ)/(((q:ℝ)+1)*L)≤100000000000000000000000/Real.sqrt k := by
    have hs1 : 1≤Real.sqrt (k:ℝ) := (Real.le_sqrt (by norm_num) hk0.le).mpr (by exact_mod_cast (by omega : 1≤k))
    have hsq := Real.sq_sqrt hk0.le
    have hnum : ((q:ℝ)+Real.sqrt k)*Real.sqrt k≤(k:ℝ)*((q:ℝ)+1) := by
      have hh : (q:ℝ)*Real.sqrt k≤(q:ℝ)*(k:ℝ) := mul_le_mul_of_nonneg_left (by nlinarith) hq0
      nlinarith
    have heq : (k:ℝ)/(((q:ℝ)+1)*L)=100000000000000000000000*(((q:ℝ)+Real.sqrt k)/((k:ℝ)*((q:ℝ)+1))) := by
      dsimp [L]; field_simp
    rw [heq,div_eq_mul_inv (100000000000000000000000:ℝ)]
    apply mul_le_mul_of_nonneg_left _ (by norm_num)
    rw [← one_div]
    exact (div_le_div_iff₀ (mul_pos hk0 hq1) hs).mpr (by simpa using hnum)
  have hfirst : ((k:ℝ)+1)*E1/(bmin*L*E0)≤(((k:ℝ)+1)*bmax/bmin)*((k:ℝ)/(((q:ℝ)+1)*L)) := by
    have hh := mul_le_mul_of_nonneg_left hext (by positivity : (0:ℝ)≤((k:ℝ)+1)/(bmin*L*((q:ℝ)+1)*E0))
    convert hh using 1 <;> field_simp
  apply hfirst.trans
  have hh := mul_le_mul_of_nonneg_left hf (by positivity : (0:ℝ)≤((k:ℝ)+1)*bmax/bmin)
  convert hh using 1; ring

/-- All of (B.2), with actual minimum/maximum tail entries and no spectral or filter contracts. -/
theorem shifted_limit_reindexed {k q : ℕ} (hk : 4≤k) (hq : 2*q≤k)
    (e : Fin (k-q) ⊕ Fin (k+q) ≃ Fin (2*k))
    (a : Fin (k-q) → ℝ) (b : Fin (k+q) → ℝ) (ha : ∀ i,0<a i) (hb : ∀ i,0<b i) :
    let bmin := finiteSpectrumMin b (by omega)
    let bmax := finiteSpectrumMax b (by omega)
    let L := (k:ℝ)^2/(100000000000000000000000*((q:ℝ)+Real.sqrt k))
    let C := ((k:ℝ)+1)*(Finset.univ.val.map b).esymm (q+1)/(bmin*L*(Finset.univ.val.map b).esymm q)
    Filter.limsup (fun ε : ℝ => spectralMean (splitSpectrum e a b ε) k/worstError (splitSpectrum e a b ε) k) (𝓝[>] 0)≤C ∧
      C≤100000000000000000000000*(bmax/bmin)*((k:ℝ)+1)/Real.sqrt k := by
  obtain ⟨hmin,hmax,hbounds,_,_⟩ := finiteSpectrum_extrema b (by omega) hb
  exact ⟨shifted_split_limsup hk hq e a b ha hb hmin (fun j => (hbounds j).1),
    shifted_coefficient_bound hk b hb hmin hmax.le (fun j => (hbounds j).2)⟩

/-- Canonical concatenation of the two original lists, with the proved ambient dimension. -/
def shiftedSplitEquiv (k q : ℕ) (hq : q≤k) : Fin (k-q) ⊕ Fin (k+q) ≃ Fin (2*k) :=
  finSumFinEquiv.trans (finCongr (by omega))

/-- Original B.2 for the canonical concatenated list; no equivalence is supplied by the caller. -/
theorem paper_shifted_limit {k q : ℕ} (hk : 4≤k) (hq : 2*q≤k)
    (a : Fin (k-q) → ℝ) (b : Fin (k+q) → ℝ) (ha : ∀ i,0<a i) (hb : ∀ i,0<b i) :
    let bmin := finiteSpectrumMin b (by omega)
    let bmax := finiteSpectrumMax b (by omega)
    let L := (k:ℝ)^2/(100000000000000000000000*((q:ℝ)+Real.sqrt k))
    let C := ((k:ℝ)+1)*(Finset.univ.val.map b).esymm (q+1)/(bmin*L*(Finset.univ.val.map b).esymm q)
    Filter.limsup (fun ε : ℝ => spectralMean (splitSpectrum (shiftedSplitEquiv k q (by omega)) a b ε) k/worstError (splitSpectrum (shiftedSplitEquiv k q (by omega)) a b ε) k) (𝓝[>] 0)≤C ∧
      C≤100000000000000000000000*(bmax/bmin)*((k:ℝ)+1)/Real.sqrt k := by
  exact shifted_limit_reindexed hk hq (shiftedSplitEquiv k q (by omega)) a b ha hb

end SpectralComparison
