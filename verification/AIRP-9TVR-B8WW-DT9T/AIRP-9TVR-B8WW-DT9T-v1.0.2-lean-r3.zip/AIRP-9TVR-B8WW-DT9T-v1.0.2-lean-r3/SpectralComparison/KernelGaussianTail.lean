import SpectralComparison.KernelStatistic

/-! Fixed-kernel projected-transpose tail bounds without a measurable kernel-basis choice. -/
noncomputable section
open Matrix MeasureTheory ProbabilityTheory
namespace SpectralComparison

/-- Lemma 3.1 with the column count supplied directly rather than as t+q. -/
theorem gaussian_inverse_trace_rectangular {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {d l : ℕ}
    (hd : 1≤d) (hl : 4≤l) (hdl : d≤l)
    (G : Ω → Matrix (Fin d) (Fin l) ℝ)
    (hG : ∀ a : Fin d × Fin l, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin d × Fin l => fun ω => G ω a.1 a.2) μ) :
    μ.real {ω | (G ω*(G ω)ᴴ)⁻¹.trace ≤ (d:ℝ)/(1000*((l-d:ℕ)+Real.sqrt l))} ≤
      2*Real.exp (-31*(l:ℝ)) := by
  let e : Fin (d+(l-d)) ≃ Fin l := finCongr (Nat.add_sub_of_le hdl)
  let W := fun ω => (G ω).submatrix id e
  have hw (a : Fin d × Fin (d+(l-d))) : HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ := hG (a.1,e a.2)
  have hi : iIndepFun (fun a : Fin d × Fin (d+(l-d)) => fun ω => W ω a.1 a.2) μ :=
    hind.precomp ((Equiv.refl (Fin d)).prodCongr e).injective
  have h := paper_lemma_3_1 hd (by omega) W hw hi
  have he (ω : Ω) : W ω*(W ω)ᴴ=G ω*(G ω)ᴴ := by
    dsimp [W]
    rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,Matrix.submatrix_id_id]
  simpa only [he,Nat.add_sub_of_le hdl] using h

/-- Singular PSD matrices have zero totalized inverse trace. -/
theorem inverse_trace_eq_zero_of_not_posDef {d : Type*} [Fintype d] [DecidableEq d]
    {A : Matrix d d ℝ} (hA : A.PosSemidef) (hn : ¬A.PosDef) : A⁻¹.trace=0 := by
  have hu : ¬IsUnit A := hA.posDef_iff_isUnit.not.mp hn
  have hd : ¬IsUnit A.det := by rwa [← Matrix.isUnit_iff_isUnit_det]
  rw [Matrix.nonsing_inv_apply_not_isUnit A hd,Matrix.trace_zero]

/-- Projected-transpose Gaussian tail for a fixed orthonormal column system. -/
theorem gaussian_projected_transpose_tail {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {l p d : ℕ}
    (hd : 1≤d) (hl : 4≤l) (hdl : d≤l)
    (X : Ω → Matrix (Fin l) (Fin p) ℝ)
    (hX : ∀ a : Fin l × Fin p, HasLaw (fun ω => X ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin l × Fin p => fun ω => X ω a.1 a.2) μ)
    (R : Matrix (Fin p) (Fin d) ℝ) (hR : Rᴴ*R=1) :
    μ.real {ω | ((X ω*R)ᴴ*(X ω*R))⁻¹.trace ≤ (d:ℝ)/(1000*((l-d:ℕ)+Real.sqrt l))} ≤
      2*Real.exp (-31*(l:ℝ)) := by
  have hlaw := gaussian_rows_projected_entry_hasLaw X hX hind R hR
  have hi := gaussian_rows_projected_independent X hX hind R hR
  have hg (a : Fin d × Fin l) : HasLaw (fun ω => (X ω*R)ᴴ a.1 a.2) (gaussianReal 0 1) μ := by
    simpa only [Matrix.conjTranspose_apply,star_trivial] using hlaw (a.2,a.1)
  have hgi : iIndepFun (fun a : Fin d × Fin l => fun ω => (X ω*R)ᴴ a.1 a.2) μ := by
    simpa [Matrix.conjTranspose_apply] using hi.precomp (Equiv.prodComm (Fin d) (Fin l)).injective
  simpa only [Matrix.conjTranspose_conjTranspose] using
    gaussian_inverse_trace_rectangular hd hl hdl (fun ω => (X ω*R)ᴴ) hg hgi

/-- A fixed full-rank conditioned block admits a basis-free tail bound for the remaining Gaussian rows. -/
theorem kernelInverseTrace_fiber_bound {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {h l p : ℕ}
    (H : Matrix (Fin h) (Fin p) ℝ) (hH : (H*Hᴴ).PosDef)
    (hd : 1≤p-h) (hl : 4≤l) (hdl : p-h≤l)
    (X : Ω → Matrix (Fin l) (Fin p) ℝ)
    (hX : ∀ a : Fin l × Fin p, HasLaw (fun ω => X ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin l × Fin p => fun ω => X ω a.1 a.2) μ) :
    μ.real {ω | kernelInverseTrace H (X ω) ≤ (p-h:ℕ)/(1000*((l-(p-h):ℕ)+Real.sqrt l))} ≤
      2*Real.exp (-31*(l:ℝ)) := by
  let d := Module.finrank ℝ H.toEuclideanLin.ker
  have hdim : d+h=p := by simpa only [Fintype.card_fin] using kernel_dimension_of_gram_posDef H hH
  have hdeq : d=p-h := by omega
  obtain ⟨R,hR,hproj⟩ := exists_kernel_basis_matrix H hH
  have hb := gaussian_projected_transpose_tail (by omega : 1≤d) hl (by omega : d≤l) X hX hind R hR
  have hc : (d:ℝ)/(1000*((l-d:ℕ)+Real.sqrt l)) =
      (p-h:ℕ)/(1000*((l-(p-h):ℕ)+Real.sqrt l)) := by rw [hdeq]
  rw [hc] at hb
  apply le_trans _ hb
  refine measureReal_mono ?_ (measure_ne_top _ _)
  intro ω hω
  change ((X ω*R)ᴴ*(X ω*R))⁻¹.trace ≤ (p-h:ℕ)/(1000*((l-(p-h):ℕ)+Real.sqrt l))
  by_cases hK : ((X ω*R)ᴴ*(X ω*R)).PosDef
  · have he := kernel_projector_statistic_eq H (X ω) R hR hproj (by simpa using hdim) hK
    change kernelInverseTrace H (X ω)=_ at he
    rwa [← he]
  · rw [inverse_trace_eq_zero_of_not_posDef (posSemidef_conjTranspose_mul_self (X ω*R)) hK]
    positivity

end SpectralComparison
