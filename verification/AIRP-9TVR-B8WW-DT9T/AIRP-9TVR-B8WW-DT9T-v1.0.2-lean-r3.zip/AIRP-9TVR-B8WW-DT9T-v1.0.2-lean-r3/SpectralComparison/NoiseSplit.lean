import SpectralComparison.OrthogonalNoise

/-! Locate a signal kernel inside an arbitrary finite spectral label system. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- The zero-eigenvalue part of an orthogonal synthesis is its exact kernel, under any label equivalence. -/
theorem orthogonal_noise_split {n l r p : Type*} [Fintype n] [Fintype l] [Fintype r] [Fintype p]
    [DecidableEq n] [DecidableEq l] [DecidableEq r] [DecidableEq p]
    (V : Matrix n l ℝ) (hV : Vᴴ*V=1) (hV' : V*Vᴴ=1)
    (e : (r ⊕ p) ≃ l) (a : l → ℝ)
    (hz : ∀ i,a (e (Sum.inl i))=0) (hp : ∀ i,0<a (e (Sum.inr i))) :
    let Q := V.submatrix id (fun i => e (Sum.inl i))
    let C := V*Matrix.diagonal a*Vᴴ
    Qᴴ*Q=1 ∧ C.PosSemidef ∧ Qᴴ*C=0 ∧
      ∀ x,C.mulVec x=0 ↔ ∃ y : r → ℝ,x=Q.mulVec y := by
  let U := V.submatrix id e
  have hU : Uᴴ*U=1 := by
    rw [Matrix.conjTranspose_submatrix,← Matrix.submatrix_mul _ _ e id e Function.bijective_id,hV]
    exact Matrix.submatrix_one e e.injective
  have hU' : U*Uᴴ=1 := by
    rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,hV',Matrix.submatrix_id_id]
  have hd : Matrix.diagonal (Sum.elim (fun _ : r => (0:ℝ)) (fun i => a (e (Sum.inr i))))=(Matrix.diagonal a).submatrix e e := by
    rw [Matrix.submatrix_diagonal_equiv]
    congr 1
    funext i
    cases i with
    | inl i => exact (hz i).symm
    | inr i => rfl
  have hc : U*Matrix.diagonal (Sum.elim (fun _ : r => (0:ℝ)) (fun i => a (e (Sum.inr i))))*Uᴴ=V*Matrix.diagonal a*Vᴴ := by
    rw [hd]
    change V.submatrix id e*(Matrix.diagonal a).submatrix e e*(V.submatrix id e)ᴴ=_
    rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,Matrix.submatrix_mul_equiv,Matrix.submatrix_id_id]
  have hh := orthogonal_noise_kernel U hU hU' (fun i => a (e (Sum.inr i))) hp
  dsimp only at hh ⊢
  rw [hc] at hh
  exact hh

end SpectralComparison
