import SpectralComparison.HarmonicMaximum

noncomputable section
open Finset
namespace SpectralComparison

/-- The prefix definition is exactly the manuscript's tail plus (q-k) times the harmonic mean. -/
theorem harmonicPrefixValue_original {n k q : ℕ} (a : Fin n → ℝ) (hkq : k≤q) (hqn : q≤n) :
    harmonicPrefixValue a k q=
      (∑ i∈Finset.univ.filter (fun i : Fin n => q ≤ i.val),a i)+
        (q-k:ℕ)*((q:ℝ)/(∑ i∈Finset.univ.filter (fun i : Fin n => i.val<q),(a i)⁻¹)) := by
  classical
  have he : Finset.univ\spectralPrefix (n:=n) q=Finset.univ.filter (fun i : Fin n => q ≤ i.val) := by
    ext i; simp [spectralPrefix]
  dsimp only [harmonicPrefixValue,harmonicSetValue]
  rw [spectralPrefix_card hqn,he,Nat.cast_sub hkq]
  rfl

/-- The exact original equality at the last rank. -/
theorem paper_harmonic_last_rank {n : ℕ} (hn : 2≤n) (a : Fin n → ℝ) (ha : ∀ i,0<a i) :
    worstError a (n-1)=spectralMean a (n-1) ∧ spectralMean a (n-1)=(n:ℝ)/(∑ i,(a i)⁻¹) := by
  have hk : 1≤n-1 := by omega
  have hkn : n-1<n := by omega
  obtain ⟨τ,⟨hτ,hr⟩,_⟩ := exists_unique_waterLevel a ha hk hkn
  have hc := paper_water_comparison a ha hk hkn hτ hr
  have hyx := hc.1.trans hc.2.1
  have hnm : n-(n-1)=1 := by omega
  have hnp : ((n-1:ℕ):ℝ)+1=n := by exact_mod_cast (Nat.sub_add_cancel (by omega : 1≤n))
  have hn0 : (n:ℝ)≠0 := by exact_mod_cast (by omega : n≠0)
  simp only [hnm,Nat.cast_one,hnp,mul_one,div_self hn0,one_mul] at hyx
  refine ⟨le_antisymm (worstError_le_spectralMean a ha (by simpa using hkn)) hyx,?_⟩
  rw [spectralMean_eq_quotient,reciprocal_quotient a ha (by simpa using hkn)]
  have he : Fintype.card (Fin n)-(n-1)-1=0 := by simp; omega
  simp only [he,symmetricQuotient,Nat.zero_add,esymm_one,Multiset.esymm_zero,div_one,hnp]
  change (n:ℝ)*(∑ i,(a i)⁻¹)⁻¹=(n:ℝ)/(∑ i,(a i)⁻¹)
  rw [div_eq_mul_inv]

/-- All of the harmonic-block proposition, with an internally supplied unique water level. -/
theorem paper_harmonic_blocks {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i) (horder : Antitone a)
    (hk : 1≤k) (hkn : k<n) :
    ∃ τ : ℝ,0<τ ∧ waterSum a τ=k ∧ (∀ σ : ℝ,0<σ → waterSum a σ=k → σ=τ) ∧
      let S := Finset.univ.filter (fun i => τ<a i)
      let T := ∑ i∈Finset.univ\S,a i
      let B := (Finset.Icc (k+1) n).sup' ⟨k+1,Finset.mem_Icc.mpr ⟨le_rfl,by omega⟩⟩ (harmonicPrefixValue a k)
      let C := ((k:ℝ)+1)*(((S.card-k:ℕ):ℝ)*τ+T)/B
      k+1≤S.card ∧ 1≤S.card-k ∧ B=(S.card:ℝ)*τ+T ∧ B≤worstError a k ∧
      spectralMean a k≤C*worstError a k ∧ C*worstError a k≤(((k:ℝ)+1)*(n-k:ℕ)/(n:ℝ))*worstError a k ∧
      (2≤n-k → spectralMean a k<(((k:ℝ)+1)*(n-k:ℕ)/(n:ℝ))*worstError a k) ∧
      (k=n-1 → worstError a k=spectralMean a k ∧ spectralMean a k=(n:ℝ)/(∑ i,(a i)⁻¹)) := by
  obtain ⟨τ,⟨hτ,hr⟩,hu⟩ := exists_unique_waterLevel a ha hk hkn
  refine ⟨τ,hτ,hr,fun σ hσ hroot => hu σ ⟨hσ,hroot⟩,?_⟩
  let S := Finset.univ.filter (fun i => τ<a i)
  let T := ∑ i∈Finset.univ\S,a i
  have hs := waterLevel_active a ha hτ hr hk
  have hm := paper_harmonic_maximum a ha horder hk hkn hτ hr
  have hl := water_orientation_lower a ha hk hkn hτ hr
  have hc := paper_water_comparison a ha hk hkn hτ hr
  dsimp only
  rw [hm]
  refine ⟨by have hh:=hs.1; omega,by have hh:=hs.1; omega,rfl,hl,hc.1,hc.2.1,hc.2.2,?_⟩
  intro he
  subst k
  exact paper_harmonic_last_rank (by omega) a ha

end SpectralComparison
