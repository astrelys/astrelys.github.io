import SpectralComparison.StableCoefficients

noncomputable section
open Finset
namespace SpectralComparison
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The variance is controlled by the exact coefficient deficit, including repeated entries. -/
theorem unit_variance_deficit (β : ι → ℝ) (hβ : ∀ i,0≤β i) (hβ1 : ∀ i,β i≤1)
    {d : ℕ} (hd : 2≤d) (hsum : (∑ i,β i)=d) :
    (∑ i,β i*(1-β i))≤(d:ℝ)*(Finset.univ.val.map β).esymm d-
      (Finset.univ.val.map β).esymm (d-1) := by
  have hj : d-2+2=d := by omega
  have hj' : d-2+1=d-1 := by omega
  have he (i : ι) : 1≤((Finset.univ.erase i).val.map β).esymm (d-2) := by
    let S := Finset.univ.erase i
    have hs : ((d-2:ℕ):ℝ)≤∑ l : S,β l := by
      rw [Finset.sum_coe_sort]
      have hh := Finset.sum_erase_add (Finset.univ : Finset ι) β (Finset.mem_univ i)
      rw [hsum] at hh
      dsimp [S]
      rw [Nat.cast_sub hd]
      push_cast
      linarith [hβ1 i]
    have hh := unit_esymm_ge_one (fun l : S => β l) (fun l => hβ _) (fun l => hβ1 _) hs
    rwa [restricted_spectrum_multiset] at hh
  have hvar := esymm_variance_identity β (d-2)
  rw [hj,hj',hsum,Nat.cast_sub hd] at hvar
  push_cast at hvar
  have hb : (∑ i,β i*(1-β i))≤∑ i,β i*(1-β i)*((Finset.univ.erase i).val.map β).esymm (d-2) := by
    apply Finset.sum_le_sum
    intro i _
    have hp : 0≤β i*(1-β i) := mul_nonneg (hβ i) (sub_nonneg.mpr (hβ1 i))
    nlinarith [mul_le_mul_of_nonneg_left (he i) hp]
  linarith

/-- Explicit exponential control, with no stability hypothesis left as a contract. -/
theorem unit_variance_quotient (β : ι → ℝ) (hβ : ∀ i,0<β i) (hβ1 : ∀ i,β i≤1)
    {d : ℕ} (hd : 2≤d) (hdn : d≤Fintype.card ι) (hsum : (∑ i,β i)=d) :
    (∑ i,β i*(1-β i))≤(2:ℝ)^Fintype.card ι*
      ((d:ℝ)-(Finset.univ.val.map β).esymm (d-1)/(Finset.univ.val.map β).esymm d) := by
  let E := (Finset.univ.val.map β).esymm d
  let F := (Finset.univ.val.map β).esymm (d-1)/E
  have hE : 0<E := esymm_pos _ (by
    intro z hz; obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz; exact hβ i) _ (by simpa using hdn)
  have hEF : E*F=(Finset.univ.val.map β).esymm (d-1) := by dsimp [F]; field_simp
  have hv := unit_variance_deficit β (fun i => (hβ i).le) hβ1 hd hsum
  have h0 : 0≤∑ i,β i*(1-β i) := Finset.sum_nonneg (fun i _ => mul_nonneg (hβ i).le (sub_nonneg.mpr (hβ1 i)))
  have hD : 0≤(d:ℝ)-F := by nlinarith
  have hu := unit_esymm_upper β (fun i => (hβ i).le) hβ1 d
  have hh := mul_le_mul_of_nonneg_right hu hD
  change _≤(2:ℝ)^Fintype.card ι*((d:ℝ)-F)
  nlinarith

/-- For unit total mass the second coefficient is exactly half the variance. -/
theorem unit_mass_variance (β : ι → ℝ) (hsum : (∑ i,β i)=1) :
    (∑ i,β i*(1-β i))=2*(Finset.univ.val.map β).esymm 2 := by
  have h := esymm_variance_identity β 0
  simpa [hsum] using h

/-- Nearest-endpoint rounding, with exact integer mass and explicit error control. -/
theorem unit_rounding (β : ι → ℝ) (hβ : ∀ i,0≤β i) (hβ1 : ∀ i,β i≤1)
    {d : ℕ} (hsum : (∑ i,β i)=d) (hsmall : 2*(∑ i,β i*(1-β i))<1) :
    let S := Finset.univ.filter (fun i => (1:ℝ)/2≤β i)
    S.card=d ∧ ∀ i,i∉S → β i≤2*(∑ j,β j*(1-β j)) := by
  classical
  let S := Finset.univ.filter (fun i => (1:ℝ)/2≤β i)
  let b := fun i => if i∈S then (1:ℝ) else 0
  have herr (i : ι) : |β i-b i|≤2*(β i*(1-β i)) := by
    by_cases hi : i∈S
    · have hh := (Finset.mem_filter.mp hi).2
      simp only [b,ite_eq_left hi,abs_of_nonpos (sub_nonpos.mpr (hβ1 i))]
      nlinarith [mul_nonneg (show 0≤2*β i-1 by linarith) (sub_nonneg.mpr (hβ1 i))]
    · have hh : β i<1/2 := lt_of_not_ge (fun h => hi (Finset.mem_filter.mpr ⟨Finset.mem_univ i,h⟩))
      simp only [b,ite_eq_right hi,sub_zero,abs_of_nonneg (hβ i)]
      nlinarith [mul_nonneg (hβ i) (show 0≤1-2*β i by linarith)]
  have hb : (∑ i,b i)=(S.card:ℝ) := by simp [b]
  have hbound : |(d:ℝ)-(S.card:ℝ)|≤2*(∑ i,β i*(1-β i)) := by
    calc
      _ = |∑ i,(β i-b i)| := by rw [Finset.sum_sub_distrib,hsum,hb]
      _ ≤∑ i,|β i-b i| := Finset.abs_sum_le_sum_abs _ _
      _ ≤∑ i,2*(β i*(1-β i)) := Finset.sum_le_sum (fun i _ => herr i)
      _ =_ := by rw [Finset.mul_sum]
  have hcard : S.card=d := by
    have hh := abs_lt.mp (hbound.trans_lt hsmall)
    by_contra hn
    rcases lt_or_gt_of_ne hn with h|h
    · have hc : (S.card:ℝ)+1≤(d:ℝ) := by exact_mod_cast h
      linarith [hh.2]
    · have hc : (d:ℝ)+1≤(S.card:ℝ) := by exact_mod_cast h
      linarith [hh.1]
  refine ⟨hcard,?_⟩
  intro i hi
  change i∉S at hi
  have hp (j : ι) : 0≤β j*(1-β j) := mul_nonneg (hβ j) (sub_nonneg.mpr (hβ1 j))
  have hsingle := Finset.single_le_sum (fun j (_ : j∈Finset.univ) => hp j) (Finset.mem_univ i)
  have hh := herr i
  simp only [b,ite_eq_right hi,sub_zero,abs_of_nonneg (hβ i)] at hh
  linarith

end SpectralComparison
