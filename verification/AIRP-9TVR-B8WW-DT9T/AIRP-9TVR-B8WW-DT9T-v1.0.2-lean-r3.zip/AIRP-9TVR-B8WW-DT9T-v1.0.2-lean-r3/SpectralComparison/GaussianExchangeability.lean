import SpectralComparison.GaussianRank
import SpectralComparison.SubsetAverage
import Mathlib.Analysis.Matrix.MeasurableSpace
import Mathlib.Logic.Equiv.Fintype

/-! Row exchangeability and the actual inverse-Gram subset reduction. -/
noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

/-- Nonsingular matrix inversion is measurable, including its zero value on singular matrices. -/
theorem measurable_matrix_inverse {ι : Type*} [Fintype ι] [DecidableEq ι] :
    Measurable (fun A : Matrix ι ι ℝ => A⁻¹) := by
  simp only [Matrix.inv_def, Ring.inverse_eq_inv]
  exact continuous_id.matrix_det.measurable.inv.smul continuous_id.matrix_adjugate.measurable

/-- Each diagonal entry of the inverse Gram matrix is a measurable statistic. -/
theorem measurable_inverse_gram_diagonal {ι κ : Type*} [Fintype ι] [Fintype κ]
    [DecidableEq ι] (i : ι) :
    Measurable (fun x : ι × κ → ℝ =>
      ((Matrix.of (fun a b => x (a,b))) * (Matrix.of (fun a b => x (a,b)))ᴴ)⁻¹ i i) := by
  have hm : Measurable (fun x : ι × κ → ℝ =>
      ((Matrix.of (fun a b => x (a,b))) * (Matrix.of (fun a b => x (a,b)))ᴴ)) := by
    apply Measurable.of_eval_matrix
    intro a b
    simp only [Matrix.mul_apply, Matrix.conjTranspose_apply, Matrix.of_apply, star_trivial]
    fun_prop
  exact (measurable_matrix_inverse.comp hm).eval_matrix

/-- Row permutations conjugate the inverse Gram matrix by the same permutation. -/
theorem inverse_gram_row_permutation {ι κ : Type*} [Fintype ι] [Fintype κ]
    [DecidableEq ι] (W : Matrix ι κ ℝ) (e : Equiv.Perm ι) :
    ((W.submatrix e id) * (W.submatrix e id)ᴴ)⁻¹ = (W*Wᴴ)⁻¹.submatrix e e := by
  have he : W.submatrix e id * (W.submatrix e id)ᴴ = (W*Wᴴ).submatrix e e := by
    ext i j
    simp [Matrix.mul_apply]
  rw [he, Matrix.inv_submatrix_equiv]

/-- Equal-cardinality finite subsets are related by an ambient permutation. -/
theorem finset_exists_permutation {ι : Type*} [Fintype ι] [DecidableEq ι]
    (I J : Finset ι) (h : I.card = J.card) :
    ∃ e : Equiv.Perm ι, I.map e.toEmbedding = J := by
  let f : I ≃ J := Fintype.equivOfCardEq (by simpa using h)
  refine ⟨f.extendSubtype, ?_⟩
  apply Finset.eq_of_subset_of_card_le
  · intro x hx
    obtain ⟨i, hi, rfl⟩ := Finset.mem_map.mp hx
    exact f.extendSubtype_mem i hi
  · simp [h]

/-- Relabelling independent, identically distributed Gaussian coordinates preserves their joint law. -/
theorem gaussian_reindex_hasLaw {Ω ι : Type*} [MeasurableSpace Ω] [Fintype ι]
    {μ : Measure Ω} [IsProbabilityMeasure μ] (X : ι → Ω → ℝ)
    (hX : ∀ i, HasLaw (X i) (gaussianReal 0 1) μ) (hind : iIndepFun X μ)
    (e : Equiv.Perm ι) :
    HasLaw (fun ω i => X (e i) ω) (Measure.pi (fun _ : ι => gaussianReal 0 1)) μ := by
  exact (hind.precomp e.injective).hasLaw_pi (fun i => hX (e i))

/-- The inverse-Gram subset sums of an actual Gaussian matrix have equal laws for
subsets of the same cardinality. No independence of inverse diagonal entries is assumed. -/
theorem gaussian_inverse_gram_subset_exchangeable {Ω ι κ : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype ι] [Fintype κ]
    [DecidableEq ι] (W : Ω → Matrix ι κ ℝ)
    (hW : ∀ a : ι × κ, HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : ι × κ => fun ω => W ω a.1 a.2) μ)
    (I J : Finset ι) (hIJ : I.card = J.card) (c : ℝ) :
    μ.real {ω | ∑ i ∈ I, (W ω*(W ω)ᴴ)⁻¹ i i ≤ c} =
      μ.real {ω | ∑ i ∈ J, (W ω*(W ω)ᴴ)⁻¹ i i ≤ c} := by
  obtain ⟨e, he⟩ := finset_exists_permutation I J hIJ
  let f : (ι × κ → ℝ) → ℝ := fun x => ∑ i ∈ I,
    ((Matrix.of (fun a b => x (a,b))) * (Matrix.of (fun a b => x (a,b)))ᴴ)⁻¹ i i
  have hf : Measurable f := Finset.measurable_sum I (fun i _ => measurable_inverse_gram_diagonal i)
  have h0 := (hind.hasLaw_pi hW).measureReal_eq (p := fun x => f x ≤ c) (measurableSet_le hf measurable_const)
  have h1 := (gaussian_reindex_hasLaw _ hW hind (e.prodCongr (Equiv.refl κ))).measureReal_eq (p := fun x => f x ≤ c)
    (measurableSet_le hf measurable_const)
  have hstat (ω : Ω) : f (fun a : ι × κ => W ω (e a.1) a.2) =
      ∑ i ∈ J, (W ω*(W ω)ᴴ)⁻¹ i i := by
    change (∑ i ∈ I, ((W ω).submatrix e id * ((W ω).submatrix e id)ᴴ)⁻¹ i i) = _
    rw [inverse_gram_row_permutation, ← he]
    simp [Finset.sum_map, Matrix.submatrix_apply]
  calc
    _ = (Measure.pi (fun _ : ι × κ => gaussianReal 0 1)).real {x | f x ≤ c} := h0
    _ = μ.real {ω | f (fun a : ι × κ => W ω (e a.1) a.2) ≤ c} := h1.symm
    _ = _ := by simp_rw [hstat]

/-- Equation (3.2) for the actual independent Gaussian matrix, with exchangeability
and almost-sure nonnegativity discharged from its entry laws. -/
theorem gaussian_inverse_gram_subset_bound {Ω ι κ : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype ι] [Fintype κ]
    [DecidableEq ι] [DecidableEq κ] (emb : ι ↪ κ) (W : Ω → Matrix ι κ ℝ)
    (hW : ∀ a : ι × κ, HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : ι × κ => fun ω => W ω a.1 a.2) μ)
    (hmeas : ∀ a : ι × κ, Measurable (fun ω => W ω a.1 a.2))
    {j : ℕ} (hj : 1 ≤ j) (hjn : j ≤ Fintype.card ι) {b : ℝ} (hb : 0 < b)
    (J : Finset ι) (hJ : J.card = j) :
    μ.real {ω | (W ω*(W ω)ᴴ)⁻¹.trace ≤ (Fintype.card ι:ℝ)/b} ≤
      2*μ.real {ω | ∑ i ∈ J, (W ω*(W ω)ᴴ)⁻¹ i i ≤ 2*(j:ℝ)/b} := by
  refine exchangeable_subset_trace_bound (fun i ω => (W ω*(W ω)ᴴ)⁻¹ i i) ?_ ?_ hj hjn hb J hJ ?_
  · intro i
    have hm : Measurable (fun ω (a : ι × κ) => W ω a.1 a.2) := measurable_pi_iff.mpr hmeas
    have hh := (measurable_inverse_gram_diagonal i (κ := κ)).comp hm
    convert hh using 1
    funext ω
    have he : Matrix.of (fun a b => W ω a b) = W ω := by ext a b; rfl
    dsimp only [Function.comp_def]
    rw [he]
  · filter_upwards [gaussian_gram_posDef_ae emb W hW hind] with ω hω
    exact fun i => hω.inv.posSemidef.diag_nonneg
  · intro I hI
    exact gaussian_inverse_gram_subset_exchangeable W hW hind I J (hI.trans hJ.symm) _

end SpectralComparison
