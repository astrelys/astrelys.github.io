import SpectralComparison.GaussianBlocks

/-! Integrating the fixed-block bounds for an actual independent Gaussian matrix. -/
noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

/-- The leading inverse-Gram block has the projected-dimension tail bound. This is
unconditional: full rank and the random lower-block integration are proved internally. -/
theorem gaussian_inverse_block_tail {Ω m n p : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype m] [Fintype n] [Fintype p]
    [DecidableEq m] [DecidableEq n] [DecidableEq p]
    (W : Ω → Matrix (m ⊕ n) p ℝ)
    (hW : ∀ a : (m ⊕ n) × p, HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : (m ⊕ n) × p => fun ω => W ω a.1 a.2) μ)
    (hm : 0 < Fintype.card m) (hd : Fintype.card m+Fintype.card n ≤ Fintype.card p) :
    μ.real {ω | ((W ω*(W ω)ᴴ)⁻¹.submatrix Sum.inl Sum.inl).trace ≤
      (Fintype.card m:ℝ)/(500*(Fintype.card p-Fintype.card n:ℕ))} ≤
    Real.exp (-124*((Fintype.card m:ℝ)*(Fintype.card p-Fintype.card n:ℕ))) := by
  let νU := Measure.pi (fun _ : m × p => gaussianReal 0 1)
  let νB := Measure.pi (fun _ : n × p => gaussianReal 0 1)
  let U : (m × p → ℝ) → Matrix m p ℝ := fun u => Matrix.of (fun i j => u (i,j))
  let B : (n × p → ℝ) → Matrix n p ℝ := fun b => Matrix.of (fun i j => b (i,j))
  let G : (m × p → ℝ) × (n × p → ℝ) → Matrix (m ⊕ n) p ℝ :=
    fun z => Matrix.fromRows (U z.1) (B z.2)
  let c : ℝ := (Fintype.card m:ℝ)/(500*(Fintype.card p-Fintype.card n:ℕ))
  let E := {z | (G z*(G z)ᴴ).PosDef ∧ ((G z*(G z)ᴴ)⁻¹.submatrix Sum.inl Sum.inl).trace ≤ c}
  have hGmeas (a : (m ⊕ n) × p) : Measurable (fun z => G z a.1 a.2) := by
    rcases a with ⟨i,j⟩
    cases i with
    | inl i => exact (measurable_pi_apply (i,j)).comp measurable_fst
    | inr i => exact (measurable_pi_apply (i,j)).comp measurable_snd
  have hE : MeasurableSet E := (measurableSet_gram_posDef G hGmeas).inter
    (measurableSet_le (Finset.measurable_sum _ (fun i _ =>
      measurable_inverse_gram_diagonal_of_entries G hGmeas (Sum.inl i))) measurable_const)
  have hUlaw (a : m × p) : HasLaw (fun u => U u a.1 a.2) (gaussianReal 0 1) νU :=
    ⟨(measurable_pi_apply a).aemeasurable, (measurePreserving_eval _ a).map_eq⟩
  have hBind (a : n × p) : HasLaw (fun b => B b a.1 a.2) (gaussianReal 0 1) νB :=
    ⟨(measurable_pi_apply a).aemeasurable, (measurePreserving_eval _ a).map_eq⟩
  have hiU : iIndepFun (fun a : m × p => fun u => U u a.1 a.2) νU :=
    iIndepFun_pi (X := fun _ => id) (fun _ => aemeasurable_id)
  have hiB : iIndepFun (fun a : n × p => fun b => B b a.1 a.2) νB :=
    iIndepFun_pi (X := fun _ => id) (fun _ => aemeasurable_id)
  obtain ⟨embB⟩ := Function.Embedding.nonempty_of_card_le (show Fintype.card n ≤ Fintype.card p by omega)
  have hBpos := gaussian_gram_posDef_ae embB B hBind hiB
  have hprod : (νU.prod νB).real E ≤
      Real.exp (-124*((Fintype.card m:ℝ)*(Fintype.card p-Fintype.card n:ℕ))) := by
    apply probability_le_of_fiber_bound νU νB E hE (Real.exp_pos _).le
    filter_upwards [hBpos] with b hb
    exact gaussian_inverse_block_fiber_bound U hUlaw hiU (fun a => measurable_pi_apply a)
      (B b) hb hm hd
  let split : Ω → (m × p → ℝ) × (n × p → ℝ) := fun ω =>
    ((fun a => W ω (Sum.inl a.1) a.2), (fun a => W ω (Sum.inr a.1) a.2))
  have heq (ω : Ω) : G (split ω) = W ω := by
    ext i j
    cases i <;> rfl
  have hsplit := gaussian_row_blocks_hasLaw W hW hind
  have hprob := hsplit.measureReal_eq (p := fun z => z ∈ E) hE
  change μ.real {ω | split ω ∈ E} = (νU.prod νB).real E at hprob
  obtain ⟨emb⟩ := Function.Embedding.nonempty_of_card_le
    (show Fintype.card (m ⊕ n) ≤ Fintype.card p by simpa using hd)
  have hpos := gaussian_gram_posDef_ae emb W hW hind
  have hmono : μ {ω | ((W ω*(W ω)ᴴ)⁻¹.submatrix Sum.inl Sum.inl).trace ≤ c} ≤
      μ {ω | split ω ∈ E} := by
    apply measure_mono_ae
    filter_upwards [hpos] with ω hω
    intro ht
    change (G (split ω)*(G (split ω))ᴴ).PosDef ∧ _
    rw [heq]
    exact ⟨hω, ht⟩
  exact (ENNReal.toReal_mono (measure_ne_top _ _) hmono).trans (hprob.trans_le hprod)

end SpectralComparison
