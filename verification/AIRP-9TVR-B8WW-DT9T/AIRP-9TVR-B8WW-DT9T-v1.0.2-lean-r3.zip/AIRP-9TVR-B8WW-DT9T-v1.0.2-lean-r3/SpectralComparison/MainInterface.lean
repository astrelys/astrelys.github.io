import SpectralComparison.Diagonal
import SpectralComparison.ConditionalMain

/-! Actual matrix objective and the sorted-index bridge for the main theorem.
The prefix and diffuse construction bounds remain explicit hypotheses. -/
noncomputable section
namespace SpectralComparison
open Finset

/-- A threshold cutting q of the first k decreasing entries lies below lambda_(k-q).
This handles equal eigenvalues using the strict threshold count in the paper. -/
theorem threshold_count_sorted_bound {n k : ℕ} (eig : Fin n → ℝ)
    (horder : Antitone eig) (hkn : k < n) (a : ℝ)
    (q : ℕ) (hq : ((Finset.Iio (⟨k, hkn⟩ : Fin n)).filter (fun i => eig i < a)).card = q)
    (hqk : q < k) :
    a ≤ eig ⟨k-q-1, by omega⟩ := by
  let j : Fin n := ⟨k-q-1, by omega⟩
  by_contra hn
  have hj : eig j < a := lt_of_not_ge hn
  have hsub : Finset.Ico j (⟨k,hkn⟩ : Fin n) ⊆
      (Finset.Iio (⟨k,hkn⟩ : Fin n)).filter (fun i => eig i < a) := by
    intro i hi
    obtain ⟨hji, hik⟩ := Finset.mem_Ico.mp hi
    exact Finset.mem_filter.mpr ⟨Finset.mem_Iio.mpr hik, (horder hji).trans_lt hj⟩
  have hc := Finset.card_le_card hsub
  rw [hq, Fin.card_Ico] at hc
  change k - (k-q-1) ≤ q at hc
  omega

/-- Conditional improved comparison for the actual worst-orientation Nyström error.
The only mathematical hypotheses beyond a positive decreasing spectrum are the
threshold forms of the prefix and diffuse construction bounds. -/
theorem matrix_main_from_threshold_contracts {n k : ℕ} (eig : Fin n → ℝ)
    (heig : ∀ i, 0 < eig i) (horder : Antitone eig) (hk : 1 ≤ k) (hkn : k < n)
    (hprefix : ∀ a : ℝ, 0 < a →
      let q := ((Finset.Iio (⟨k,hkn⟩ : Fin n)).filter (fun i => eig i < a)).card
      (q:ℝ) ≤ (k:ℝ)/2 →
      let U := (k:ℝ) * (∑ i ∈ Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n), eig i) /
        ((32*10^27)*((q:ℝ)+Real.sqrt k)*H (n-k))
      a*U/(a+U) ≤ worstError eig k)
    (hdiffuse : ∀ a : ℝ, 0 < a →
      let q := ((Finset.Iio (⟨k,hkn⟩ : Fin n)).filter (fun i => eig i < a)).card
      (q:ℝ) ≤ (k:ℝ)/4 →
      let V := (k:ℝ) * (∑ i ∈ Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n), eig i) /
        ((64*10^27)*((q:ℝ)+Real.sqrt k)*H (8*k))
      a*V/(a+V) ≤ worstError eig k) :
    worstError eig k ≤ spectralMean eig k ∧
      spectralMean eig k ≤
        (((k:ℝ)+1)*min 1 ((768*10^27*H (min k (n-k))+1)/Real.sqrt k)) * worstError eig k := by
  let T := Finset.Iio (⟨k,hkn⟩ : Fin n)
  let J := (Finset.univ : Finset (Fin n)) \ T
  have hc : T.card = k := Fin.card_Iio _
  have hjc : J.card = n-k := by simp [J, Finset.card_sdiff, hc]
  have hp (A : Finset (Fin n)) : ∀ z ∈ A.val.map eig, 0 < z := by
    intro z hz
    obtain ⟨i, hi, rfl⟩ := Multiset.mem_map.mp hz
    exact heig i
  have hadd : T.val.map eig + J.val.map eig = Finset.univ.val.map eig := by
    rw [← Multiset.map_add, Finset.sdiff_val,
      add_tsub_cancel_of_le (Finset.val_le_iff.mpr (Finset.subset_univ T))]
  have hs : ∀ i ∈ T, ∀ j ∉ T, eig j ≤ eig i := by
    intro i hi j hj
    exact horder (le_trans (Finset.mem_Iio.mp hi).le (not_lt.mp (by simpa [T] using hj)))
  have hdiag := tail_le_worstError eig heig T hs (by simpa only [hc, Fintype.card_fin] using hkn)
  have hcount (a : ℝ) : ((T.val.map eig).filter (fun z => z < a)).card =
      (T.filter (fun i => eig i < a)).card := by
    simp only [Multiset.filter_map, Multiset.card_map]
    rfl
  have h := main_upper_from_construction_contracts (T.val.map eig) (J.val.map eig)
    (hp T) (hp J) (by simpa only [Multiset.card_map, Finset.card_val, hc] using hk) (by simp [hjc]; omega) (worstError eig k)
    (by simpa only [Finset.sum_map_val, hc] using hdiag)
    (by intro a ha hq; simpa only [Multiset.card_map, Finset.card_val, hc, hjc,
      Finset.sum_map_val, hcount] using hprefix a ha (by simpa only [hcount, Multiset.card_map, Finset.card_val, hc] using hq))
    (by intro a ha hq; simpa only [Multiset.card_map, Finset.card_val, hc, hjc,
      Finset.sum_map_val, hcount] using hdiffuse a ha (by simpa only [hcount, Multiset.card_map, Finset.card_val, hc] using hq))
  refine ⟨worstError_le_spectralMean eig heig (by simpa using hkn), ?_⟩
  simpa only [hadd, Multiset.card_map, Finset.card_val, hc, hjc, spectralMean,
    mul_div_assoc] using h

/-- Main theorem reduced to the paper's indexed prefix (6.3) and diffuse (7.1)
construction bounds. Matrix semantics, the diagonal bound, and the sorted
threshold bridge are proved internally. This theorem is still conditional. -/
theorem matrix_main_from_indexed_constructions {n k : ℕ} (eig : Fin n → ℝ)
    (heig : ∀ i, 0 < eig i) (horder : Antitone eig) (hk : 1 ≤ k) (hkn : k < n)
    (hprefix : ∀ q : ℕ, ∀ hq : q < k, (q:ℝ) ≤ (k:ℝ)/2 →
      let a := eig ⟨k-q-1, by omega⟩
      let U := (k:ℝ) * (∑ i ∈ Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n), eig i) /
        ((32*10^27)*((q:ℝ)+Real.sqrt k)*H (n-k))
      a*U/(a+U) ≤ worstError eig k)
    (hdiffuse : ∀ q : ℕ, ∀ hq : q < k, (q:ℝ) ≤ (k:ℝ)/4 →
      let a := eig ⟨k-q-1, by omega⟩
      let V := (k:ℝ) * (∑ i ∈ Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n), eig i) /
        ((64*10^27)*((q:ℝ)+Real.sqrt k)*H (8*k))
      a*V/(a+V) ≤ worstError eig k) :
    worstError eig k ≤ spectralMean eig k ∧
      spectralMean eig k ≤
        (((k:ℝ)+1)*min 1 ((768*10^27*H (min k (n-k))+1)/Real.sqrt k)) * worstError eig k := by
  have hkR : (0:ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hs : 0 < ∑ i ∈ Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n), eig i := by
    apply Finset.sum_pos (fun i _ => heig i)
    apply Finset.card_pos.mp
    simp only [Finset.card_sdiff, Finset.inter_univ, Finset.card_univ, Fintype.card_fin, Fin.card_Iio]
    omega
  have hm : 0 < H (n-k) := lt_of_lt_of_le zero_lt_one (one_le_H (by omega))
  have h8 : 0 < H (8*k) := lt_of_lt_of_le zero_lt_one (one_le_H (by omega))
  apply matrix_main_from_threshold_contracts eig heig horder hk hkn
  · intro a ha
    dsimp only
    intro hqR
    let q := ((Finset.Iio (⟨k,hkn⟩ : Fin n)).filter (fun i => eig i < a)).card
    have hqR' : (q:ℝ) ≤ (k:ℝ)/2 := hqR
    have hqk : q < k := by exact_mod_cast (show (q:ℝ) < k by linarith)
    have hsort := threshold_count_sorted_bound eig horder hkn a q rfl hqk
    have hU : 0 < (k:ℝ) * (∑ i ∈ Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n), eig i) /
        ((32*10^27)*((q:ℝ)+Real.sqrt k)*H (n-k)) := by positivity
    exact (parallel_sum_mono ha hsort hU le_rfl).trans (hprefix q hqk hqR')
  · intro a ha
    dsimp only
    intro hqR
    let q := ((Finset.Iio (⟨k,hkn⟩ : Fin n)).filter (fun i => eig i < a)).card
    have hqR' : (q:ℝ) ≤ (k:ℝ)/4 := hqR
    have hqk : q < k := by exact_mod_cast (show (q:ℝ) < k by linarith)
    have hsort := threshold_count_sorted_bound eig horder hkn a q rfl hqk
    have hV : 0 < (k:ℝ) * (∑ i ∈ Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n), eig i) /
        ((64*10^27)*((q:ℝ)+Real.sqrt k)*H (8*k)) := by positivity
    exact (parallel_sum_mono ha hsort hV le_rfl).trans (hdiffuse q hqk hqR')

end SpectralComparison
