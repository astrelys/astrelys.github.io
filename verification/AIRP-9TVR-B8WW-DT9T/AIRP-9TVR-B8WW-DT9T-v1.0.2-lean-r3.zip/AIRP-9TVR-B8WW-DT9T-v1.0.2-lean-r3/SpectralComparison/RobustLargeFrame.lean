import SpectralComparison.KernelStatisticPositive

/-! A single large-dimensional Parseval frame with every kernel-compression estimate. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Reindex kernel coordinates to any finite column type of the required dimension. -/
theorem exists_kernel_basis_matrix_of_dimension {h p d : Type*}
    [Fintype h] [Fintype p] [Fintype d] [DecidableEq h] [DecidableEq p] [DecidableEq d]
    (H : Matrix h p ℝ) (hH : (H*Hᴴ).PosDef)
    (hd : Fintype.card d+Fintype.card h=Fintype.card p) :
    ∃ R : Matrix p d ℝ, Rᴴ*R=1 ∧ R*Rᴴ=1-Hᴴ*(H*Hᴴ)⁻¹*H := by
  obtain ⟨R,hR,hproj⟩ := exists_kernel_basis_matrix H hH
  have hk := kernel_dimension_of_gram_posDef H hH
  let e : d ≃ Fin (Module.finrank ℝ H.toEuclideanLin.ker) := Fintype.equivOfCardEq (by simp only [Fintype.card_fin]; omega)
  refine ⟨R.submatrix id e,?_,?_⟩
  · rw [Matrix.conjTranspose_submatrix]
    have he := (Matrix.submatrix_mul Rᴴ R e id e Function.bijective_id).symm
    rw [he,hR]
    exact Matrix.submatrix_one e e.injective
  · rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,Matrix.submatrix_id_id,hproj]

/-- Full column rank of a rectangular Gram forces the expected dimension inequality. -/
theorem card_columns_le_of_gram_posDef {l d : Type*} [Fintype l] [Fintype d]
    [DecidableEq d] (G : Matrix l d ℝ) (hG : (Gᴴ*G).PosDef) : Fintype.card d≤Fintype.card l := by
  have hr := Matrix.rank_of_isUnit (Gᴴ*G) hG.isUnit
  rw [Matrix.rank_conjTranspose_mul_self] at hr
  exact hr ▸ Matrix.rank_le_card_height G

/-- Equation (5.1) for k>=16, with one full-spark Parseval frame and every kernel basis.
This does not yet assert the integer-weight conclusion (5.2). -/
theorem exists_robust_parseval_large {k q : ℕ} (hk : 16≤k) (hq : 2*q≤k) :
    ∃ Q : Matrix (Fin (2*k)) (Fin (k-q)) ℝ, Qᴴ*Q=1 ∧
      (∀ J : Finset (Fin (2*k)), J.card≤k-q →
        (Q.submatrix (fun i : J => (i:Fin (2*k))) id *
          (Q.submatrix (fun i : J => (i:Fin (2*k))) id)ᴴ).PosDef) ∧
      ∀ H L : Finset (Fin (2*k)), Disjoint H L → 4*H.card≤k → H.card+L.card≤k →
        ∀ U : Matrix (Fin (k-q)) (Fin (k-q-H.card)) ℝ, Uᴴ*U=1 →
          (Q.submatrix (fun i : H => (i:Fin (2*k))) id)*U=0 →
          (((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U)ᴴ*
            ((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U)).PosDef →
          (k:ℝ)^2/(4000000000000000000000000000*((q:ℝ)+Real.sqrt k))≤
            (((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U)ᴴ*
              ((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U))⁻¹.trace := by
  obtain ⟨X,hS,hgap,hrows,hpairs⟩ := exists_robust_good_matrix hk hq
  obtain ⟨W,hW,hWSW,hWW⟩ := exists_inverse_sqrt hS
  let Q := X*W
  have hQ : Qᴴ*Q=1 := by
    simpa only [Q,Matrix.conjTranspose_mul,hW.isHermitian.eq,Matrix.mul_assoc] using hWSW
  have hsub {j : Type} (e : j → Fin (2*k)) : Q.submatrix e id=X.submatrix e id * W := by
    ext i a
    simp [Q,Matrix.mul_apply]
  refine ⟨Q,hQ,?_,?_⟩
  · intro J hJ
    rw [hsub]
    exact row_gram_posDef_mul_isUnit _ (hrows J hJ) W hW.isUnit
  · intro H L hdis hh hl U hU hHU hGU
    have hHcard : H.card≤k-q := by omega
    have hdim : Fintype.card (Fin (k-q-H.card))+Fintype.card H=Fintype.card (Fin (k-q)) := by
      simp only [Fintype.card_fin,Fintype.card_coe]
      omega
    have hLH : k-q-H.card≤L.card := by
      simpa only [Fintype.card_fin,Fintype.card_coe] using card_columns_le_of_gram_posDef _ hGU
    let XH := X.submatrix (fun i : H => (i:Fin (2*k))) id
    let XL := X.submatrix (fun i : L => (i:Fin (2*k))) id
    have hH : (XH*XHᴴ).PosDef := hrows H hHcard
    obtain ⟨R,hR,hproj⟩ := exists_kernel_basis_matrix_of_dimension (d := Fin (k-q-H.card)) XH hH hdim
    have hcpos : 0<(k:ℝ)/(4000*((q:ℝ)+Real.sqrt k)) := by
      apply div_pos
      · exact_mod_cast (show 0<k by omega)
      · apply mul_pos (by norm_num)
        exact add_pos_of_nonneg_of_pos (Nat.cast_nonneg _) (Real.sqrt_pos.mpr (by exact_mod_cast (show 0<k by omega)))
    have ht := inverse_trace_lower_of_kernelInverseTrace XH XL R hR hproj hdim hcpos
      (hpairs H L hdis hh hl hLH).le
    rw [hsub] at hHU
    have ht' := fixed_whitening_all_kernel_bases XH XL hH R hR hproj hdim hS hW hWSW
      (by positivity : 0≤(k:ℝ)/(1000000000000:ℝ)^2) hgap ht U hU hHU
    rw [hsub]
    convert ht' using 1
    simp only [div_eq_mul_inv,_root_.mul_inv_rev]
    ring

end SpectralComparison
