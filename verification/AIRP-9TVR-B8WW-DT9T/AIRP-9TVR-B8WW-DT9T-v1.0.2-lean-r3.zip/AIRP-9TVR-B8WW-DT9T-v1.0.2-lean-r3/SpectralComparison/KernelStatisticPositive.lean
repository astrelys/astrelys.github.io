import SpectralComparison.KernelTransfer

/-! Positive basis-free statistics force nonsingular compressed Grams. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- The complement of an orthogonal column projector is positive semidefinite. -/
theorem orthonormal_complement_posSemidef {p d : Type*} [Fintype p] [Fintype d]
    [DecidableEq p] [DecidableEq d] (U : Matrix p d ℝ) (hU : Uᴴ*U=1) :
    (1-U*Uᴴ).PosSemidef := by
  have hf : (1-U*Uᴴ : Matrix p p ℝ)ᴴ=1-U*Uᴴ := by simp
  have hff : (1-U*Uᴴ : Matrix p p ℝ)*(1-U*Uᴴ)=1-U*Uᴴ := by
    have hp : (U*Uᴴ)*(U*Uᴴ)=U*Uᴴ := by
      calc
        _ = U*(Uᴴ*U)*Uᴴ := by simp only [Matrix.mul_assoc]
        _ = _ := by rw [hU,Matrix.mul_one]
    simp only [Matrix.sub_mul,Matrix.mul_sub,Matrix.one_mul,Matrix.mul_one,hp]
    abel
  have hh := posSemidef_conjTranspose_mul_self (1-U*Uᴴ : Matrix p p ℝ)
  rwa [hf,hff] at hh

/-- A positive value of the literal statistic certifies a nonsingular compressed Gram. -/
theorem posDef_compression_of_kernelInverseTrace_pos {h l p d : Type*}
    [Fintype h] [Fintype l] [Fintype p] [Fintype d]
    [DecidableEq h] [DecidableEq p] [DecidableEq d]
    (H : Matrix h p ℝ) (X : Matrix l p ℝ) (U : Matrix p d ℝ)
    (hU : Uᴴ*U=1) (hproj : U*Uᴴ=1-Hᴴ*(H*Hᴴ)⁻¹*H)
    (ht : 0<kernelInverseTrace H X) : ((X*U)ᴴ*(X*U)).PosDef := by
  let K := (X*U)ᴴ*(X*U)
  let A := U*K*Uᴴ+(1-U*Uᴴ)
  have hA : A.PosSemidef := (posSemidef_conjTranspose_mul_self (X*U)).mul_mul_conjTranspose_same U |>.add
    (orthonormal_complement_posSemidef U hU)
  have hcalc : (U*Uᴴ)*Xᴴ*X*(U*Uᴴ)=U*K*Uᴴ := by
    dsimp [K]
    simp only [Matrix.conjTranspose_mul,Matrix.mul_assoc]
  have he : kernelInverseTrace H X=A⁻¹.trace-(Fintype.card h:ℝ) := by
    unfold kernelInverseTrace
    dsimp only
    rw [← hproj,hcalc]
  rw [he] at ht
  have hAp : A.PosDef := posDef_of_pos_inverse_trace hA (by linarith [Nat.cast_nonneg (α := ℝ) (Fintype.card h)])
  have hcomp : Uᴴ*A*U=K := by
    dsimp [A]
    simp only [Matrix.mul_add,Matrix.add_mul,Matrix.mul_sub,Matrix.sub_mul,
      Matrix.mul_one]
    have h1 : Uᴴ*(U*K*Uᴴ)*U=K := by
      calc
        _ = (Uᴴ*U)*K*(Uᴴ*U) := by simp only [Matrix.mul_assoc]
        _ = K := by rw [hU,Matrix.one_mul,Matrix.mul_one]
    have h2 : Uᴴ*(U*Uᴴ)*U=1 := by simp only [← Matrix.mul_assoc,hU,Matrix.one_mul]
    rw [h1,hU,h2,sub_self,add_zero]
  have hc := orthonormal_compression_posDef hAp U hU
  rwa [hcomp] at hc

/-- Recover the inverse trace in any complete old kernel basis directly from the positive statistic. -/
theorem inverse_trace_lower_of_kernelInverseTrace {h l p d : Type*}
    [Fintype h] [Fintype l] [Fintype p] [Fintype d]
    [DecidableEq h] [DecidableEq p] [DecidableEq d]
    (H : Matrix h p ℝ) (X : Matrix l p ℝ) (U : Matrix p d ℝ)
    (hU : Uᴴ*U=1) (hproj : U*Uᴴ=1-Hᴴ*(H*Hᴴ)⁻¹*H)
    (hd : Fintype.card d+Fintype.card h=Fintype.card p)
    {L : ℝ} (hL : 0<L) (ht : L≤kernelInverseTrace H X) :
    L≤((X*U)ᴴ*(X*U))⁻¹.trace := by
  have hp := posDef_compression_of_kernelInverseTrace_pos H X U hU hproj (hL.trans_le ht)
  have he := kernel_projector_statistic_eq H X U hU hproj hd hp
  change kernelInverseTrace H X=_ at he
  rwa [← he]

end SpectralComparison
