import SpectralComparison.KernelGaussianTail

/-! Unconditional projected-kernel tail, integrated without selecting random bases. -/
noncomputable section
open Matrix MeasureTheory ProbabilityTheory
namespace SpectralComparison

set_option maxHeartbeats 1200000 in
/-- Integrate the fixed-kernel tail over an independent Gaussian conditioned block. -/
theorem gaussian_kernel_inverse_trace_tail {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {h l p : ℕ}
    (W : Ω → Matrix (Fin l ⊕ Fin h) (Fin p) ℝ)
    (hW : ∀ a : (Fin l ⊕ Fin h) × Fin p,
      HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : (Fin l ⊕ Fin h) × Fin p => fun ω => W ω a.1 a.2) μ)
    (hd : 1≤p-h) (hl : 4≤l) (hdl : p-h≤l) :
    μ.real {ω | kernelInverseTrace ((W ω).submatrix Sum.inr id)
      ((W ω).submatrix Sum.inl id) ≤ (p-h:ℕ)/(1000*((l-(p-h):ℕ)+Real.sqrt l))} ≤
      2*Real.exp (-31*(l:ℝ)) := by
  let νX := Measure.pi (fun _ : Fin l × Fin p => gaussianReal 0 1)
  let νH := Measure.pi (fun _ : Fin h × Fin p => gaussianReal 0 1)
  let X : (Fin l × Fin p → ℝ) → Matrix (Fin l) (Fin p) ℝ := fun x => Matrix.of (fun i j => x (i,j))
  let H : (Fin h × Fin p → ℝ) → Matrix (Fin h) (Fin p) ℝ := fun b => Matrix.of (fun i j => b (i,j))
  let c : ℝ := (p-h:ℕ)/(1000*((l-(p-h):ℕ)+Real.sqrt l))
  let E := {z : (Fin l × Fin p → ℝ) × (Fin h × Fin p → ℝ) |
    kernelInverseTrace (H z.2) (X z.1) ≤ c}
  have hmap : Measurable (fun z : (Fin l × Fin p → ℝ) × (Fin h × Fin p → ℝ) => (H z.2,X z.1)) := by
    apply Measurable.prodMk
    · apply Measurable.of_eval_matrix
      intro i j
      exact (measurable_pi_apply (i,j)).comp measurable_snd
    · apply Measurable.of_eval_matrix
      intro i j
      exact (measurable_pi_apply (i,j)).comp measurable_fst
  have hstat := measurable_kernelInverseTrace.comp hmap
  have hE : MeasurableSet E := measurableSet_le hstat measurable_const
  have hXlaw (a : Fin l × Fin p) : HasLaw (fun x => X x a.1 a.2) (gaussianReal 0 1) νX :=
    ⟨(measurable_pi_apply a).aemeasurable,(measurePreserving_eval _ a).map_eq⟩
  have hHlaw (a : Fin h × Fin p) : HasLaw (fun b => H b a.1 a.2) (gaussianReal 0 1) νH :=
    ⟨(measurable_pi_apply a).aemeasurable,(measurePreserving_eval _ a).map_eq⟩
  have hiX : iIndepFun (fun a : Fin l × Fin p => fun x => X x a.1 a.2) νX :=
    iIndepFun_pi (X := fun _ => id) (fun _ => aemeasurable_id)
  have hiH : iIndepFun (fun a : Fin h × Fin p => fun b => H b a.1 a.2) νH :=
    iIndepFun_pi (X := fun _ => id) (fun _ => aemeasurable_id)
  let emb : Fin h ↪ Fin p := Fin.castLEEmb (by omega)
  have hHpos := gaussian_gram_posDef_ae emb H hHlaw hiH
  have hprod : (νX.prod νH).real E ≤ 2*Real.exp (-31*(l:ℝ)) := by
    apply probability_le_of_fiber_bound νX νH E hE (by positivity)
    filter_upwards [hHpos] with b hb
    exact kernelInverseTrace_fiber_bound (H b) hb hd hl hdl X hXlaw hiX
  let split : Ω → (Fin l × Fin p → ℝ) × (Fin h × Fin p → ℝ) := fun ω =>
    ((fun a => W ω (Sum.inl a.1) a.2),(fun a => W ω (Sum.inr a.1) a.2))
  have hsplit := gaussian_row_blocks_hasLaw W hW hind
  have hp := hsplit.measureReal_eq (p := fun z => z ∈ E) hE
  change μ.real {ω | split ω ∈ E} = (νX.prod νH).real E at hp
  have heq (ω : Ω) : kernelInverseTrace (H (split ω).2) (X (split ω).1) =
      kernelInverseTrace ((W ω).submatrix Sum.inr id) ((W ω).submatrix Sum.inl id) := by
    congr 1
  have hev : {ω | split ω ∈ E} = {ω | kernelInverseTrace ((W ω).submatrix Sum.inr id)
      ((W ω).submatrix Sum.inl id) ≤ c} := by
    ext ω
    change kernelInverseTrace (H (split ω).2) (X (split ω).1) ≤ c ↔ _
    simp only [heq,Set.mem_ofPred_eq]
  rw [hev] at hp
  exact hp.trans_le hprod

end SpectralComparison
