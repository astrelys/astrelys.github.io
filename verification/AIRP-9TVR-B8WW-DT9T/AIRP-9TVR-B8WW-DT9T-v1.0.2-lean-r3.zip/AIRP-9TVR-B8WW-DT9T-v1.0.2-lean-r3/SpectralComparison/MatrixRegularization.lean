import SpectralComparison.InverseOrder
import Mathlib.Analysis.Matrix.PosDef

/-! The matrix regularization step (2.3), including singular principal blocks. -/
noncomputable section
namespace SpectralComparison
open Matrix Finset
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Positive diagonal matrices invert entry by entry. -/
theorem positive_diagonal_inverse (d : ι → ℝ) (hd : ∀ i, 0 < d i) :
    (Matrix.diagonal d)⁻¹ = Matrix.diagonal (fun i => 1 / d i) := by
  apply Matrix.inv_eq_right_inv
  rw [Matrix.diagonal_mul_diagonal]
  ext i j
  by_cases h : i = j
  · subst j
    simp [(hd i).ne']
  · simp [h]

/-- Inverse trace is unchanged by a unitary change of coordinates. -/
theorem trace_inverse_unitary_conjugate (D U : Matrix ι ι ℝ)
    (hU : U.conjTranspose * U = 1) :
    (U * D * U.conjTranspose)⁻¹.trace = D⁻¹.trace := by
  have hU' : U * U.conjTranspose = 1 := mul_eq_one_comm.mp hU
  have hiU := Matrix.inv_eq_left_inv hU
  have hiUt := Matrix.inv_eq_left_inv hU'
  simp only [Matrix.mul_inv_rev, hiU, hiUt]
  rw [← Matrix.mul_assoc, Matrix.trace_mul_cycle, hU, Matrix.one_mul]

/-- Spectral theorem written as literal real unitary conjugation. -/
theorem real_spectral_decomposition {P : Matrix ι ι ℝ} (hP : P.IsHermitian) :
    P = (hP.eigenvectorUnitary : Matrix ι ι ℝ) * Matrix.diagonal hP.eigenvalues *
      (hP.eigenvectorUnitary : Matrix ι ι ℝ).conjTranspose := by
  simpa only [Unitary.conjStarAlgAut_apply, RCLike.ofReal_real_eq_id, Function.id_comp, Matrix.star_eq_conjTranspose] using hP.spectral_theorem

/-- The trace of the inverse of alpha I + beta P is its exact spectral reciprocal sum. -/
theorem trace_inverse_affine_posSemidef {P : Matrix ι ι ℝ} (hP : P.PosSemidef)
    {α β : ℝ} (hα : 0 < α) (hβ : 0 < β) :
    (α • (1 : Matrix ι ι ℝ) + β • P)⁻¹.trace =
      ∑ i, 1 / (α + β * hP.isHermitian.eigenvalues i) := by
  let U : Matrix ι ι ℝ := hP.isHermitian.eigenvectorUnitary
  have hU : U.conjTranspose * U = 1 := by
    simpa only [Matrix.star_eq_conjTranspose] using Unitary.coe_star_mul_self hP.isHermitian.eigenvectorUnitary
  have hU' : U * U.conjTranspose = 1 := mul_eq_one_comm.mp hU
  have hdiag : α • (1 : Matrix ι ι ℝ) + β • P =
      U * Matrix.diagonal (fun i => α + β * hP.isHermitian.eigenvalues i) * U.conjTranspose := by
    conv_lhs => rw [real_spectral_decomposition hP.isHermitian]
    change α • (1 : Matrix ι ι ℝ) + β • (U * Matrix.diagonal hP.isHermitian.eigenvalues * U.conjTranspose) = _
    rw [show Matrix.diagonal (fun i => α + β * hP.isHermitian.eigenvalues i) =
      α • (1 : Matrix ι ι ℝ) + β • Matrix.diagonal hP.isHermitian.eigenvalues by
        rw [← Matrix.diagonal_smul, ← Matrix.diagonal_one, ← Matrix.diagonal_smul, Matrix.diagonal_add]
        congr 1
        ext i
        simp]
    simp only [Matrix.mul_add, Matrix.add_mul, Matrix.mul_smul, Matrix.smul_mul,
      Matrix.mul_one, hU']
  rw [hdiag, trace_inverse_unitary_conjugate _ U hU, positive_diagonal_inverse]
  · simp only [Matrix.trace_diagonal]
  · intro i
    exact add_pos_of_pos_of_nonneg hα (mul_nonneg hβ.le (hP.eigenvalues_nonneg i))

/-- Positive-definite inverse trace as an exact reciprocal-eigenvalue sum. -/
theorem trace_inverse_posDef {P : Matrix ι ι ℝ} (hP : P.PosDef) :
    P⁻¹.trace = ∑ i, 1 / hP.isHermitian.eigenvalues i := by
  conv_lhs => rw [real_spectral_decomposition hP.isHermitian]
  rw [trace_inverse_unitary_conjugate _ _ (by simpa only [Matrix.star_eq_conjTranspose] using Unitary.coe_star_mul_self hP.isHermitian.eigenvectorUnitary),
    positive_diagonal_inverse _ hP.eigenvalues_pos, Matrix.trace_diagonal]

/-- The nonsingular case of the paper's matrix regularization estimate. -/
theorem regularized_inverse_trace_lower {P : Matrix ι ι ℝ} (hP : P.PosDef)
    {α β L : ℝ} (hα : 0 < α) (hβ : 0 < β) (hL : 0 ≤ L) (htrace : L ≤ P⁻¹.trace) :
    L / (β + α * L) ≤ (α • (1 : Matrix ι ι ℝ) + β • P)⁻¹.trace := by
  rw [trace_inverse_posDef hP] at htrace
  have h := sum_regularization_lower Finset.univ (fun i => 1 / hP.isHermitian.eigenvalues i)
    hα hβ (fun i _ => (one_div_pos.mpr (hP.eigenvalues_pos i)).le) hL htrace
  rw [trace_inverse_affine_posSemidef hP.posSemidef hα hβ]
  convert h using 1
  apply Finset.sum_congr rfl
  intro i _
  have hi := hP.eigenvalues_pos i
  field_simp
  ring

/-- A singular PSD matrix has a zero eigenvalue; repeated eigenvalues cause no exception. -/
theorem singular_posSemidef_zero_eigenvalue {P : Matrix ι ι ℝ} (hP : P.PosSemidef)
    (hn : ¬P.PosDef) : ∃ i, hP.isHermitian.eigenvalues i = 0 := by
  have hnot : ¬ ∀ i, 0 < hP.isHermitian.eigenvalues i := by
    intro h
    exact hn (hP.isHermitian.posDef_iff_eigenvalues_pos.mpr h)
  push Not at hnot
  obtain ⟨i, hi⟩ := hnot
  exact ⟨i, le_antisymm hi (hP.eigenvalues_nonneg i)⟩

/-- Singular blocks retain a reciprocal-alpha eigenvalue after regularization. -/
theorem singular_regularized_inverse_trace_lower {P : Matrix ι ι ℝ} (hP : P.PosSemidef)
    (hn : ¬P.PosDef) {α β : ℝ} (hα : 0 < α) (hβ : 0 < β) :
    1 / α ≤ (α • (1 : Matrix ι ι ℝ) + β • P)⁻¹.trace := by
  rw [trace_inverse_affine_posSemidef hP hα hβ]
  obtain ⟨i, hi⟩ := singular_posSemidef_zero_eigenvalue hP hn
  have hs := Finset.single_le_sum (s := (Finset.univ : Finset ι))
    (f := fun j => 1 / (α + β * hP.isHermitian.eigenvalues j))
    (fun j _ => one_div_nonneg.mpr (add_nonneg hα.le (mul_nonneg hβ.le (hP.eigenvalues_nonneg j))))
    (Finset.mem_univ i)
  simpa only [hi, mul_zero, add_zero] using hs

/-- Actual matrix version of (2.3); the inverse-trace assumption is needed only when P is nonsingular. -/
theorem matrix_regularization {P T : Matrix ι ι ℝ} (hP : P.PosSemidef) (hT : T.PosDef)
    {α β L : ℝ} (hα : 0 < α) (hβ : 0 < β) (hL : 0 < L)
    (htrace : IsUnit P → L ≤ P⁻¹.trace)
    (hbound : (α • (1 : Matrix ι ι ℝ) + β • P - T).PosSemidef) :
    L / (β + α * L) ≤ T⁻¹.trace := by
  have hQ : (α • (1 : Matrix ι ι ℝ) + β • P).PosDef :=
    (Matrix.PosDef.one.smul hα).add_posSemidef (hP.smul hβ.le)
  apply le_trans _ (inverse_trace_order hT hQ hbound)
  by_cases hp : P.PosDef
  · exact regularized_inverse_trace_lower hp hα hβ hL.le (htrace hp.isUnit)
  · exact (singular_regularization_bound hα hβ hL.le).le.trans
      (singular_regularized_inverse_trace_lower hP hp hα hβ)

omit [Fintype ι] in
/-- Paper equation (2.3) for every principal block of the specified size,
including singular blocks arising from repeated or zero rows. -/
theorem paper_equation_2_3 {P T : Matrix ι ι ℝ} (hP : P.PosSemidef) (hT : T.PosDef)
    (t : ℕ) {α β L : ℝ} (hα : 0 < α) (hβ : 0 < β) (hL : 0 < L)
    (hblocks : ∀ I : Finset ι, I.card = t → IsUnit (principal P I) → L ≤ (principal P I)⁻¹.trace)
    (hbound : (α • (1 : Matrix ι ι ℝ) + β • P - T).PosSemidef)
    (I : Finset ι) (hI : I.card = t) :
    L / (β + α * L) ≤ (principal T I)⁻¹.trace := by
  apply matrix_regularization (hP.submatrix Subtype.val) (principal_posDef hT I) hα hβ hL (hblocks I hI)
  have h := hbound.submatrix (fun i : I => i.val)
  have heq : (α • (1 : Matrix ι ι ℝ) + β • P - T).submatrix
      (fun i : I => i.val) (fun i : I => i.val) =
      α • (1 : Matrix I I ℝ) + β • principal P I - principal T I := by
    simp only [Matrix.submatrix_sub, Matrix.submatrix_add, Matrix.submatrix_smul]
    change α • ((1 : Matrix ι ι ℝ).submatrix Subtype.val Subtype.val) +
      β • principal P I - principal T I = _
    rw [Matrix.submatrix_one _ Subtype.val_injective]
  rw [heq] at h
  exact h

end SpectralComparison
