import SpectralComparison.ElementarySymmetric
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.LinearAlgebra.Matrix.SchurComplement
import Mathlib.LinearAlgebra.Matrix.Charpoly.Coeff
import Mathlib.RingTheory.Polynomial.Vieta
import Mathlib.Algebra.Order.Star.Real

/-! Actual real-matrix semantics and determinant-weighted Nystrom comparison.
No matrix identity below is introduced as an unproved assumption. -/
noncomputable section
namespace SpectralComparison
open Matrix Finset
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Principal block selected by I. -/
def principal (K : Matrix ι ι ℝ) (I : Finset ι) : Matrix I I ℝ :=
  K.submatrix Subtype.val Subtype.val

/-- The paper's literal Nystrom residual matrix. -/
def residual (K : Matrix ι ι ℝ) (I : Finset ι) : Matrix ι ι ℝ :=
  K - K.submatrix (id : ι → ι) (fun i : I => i.val) * (principal K I)⁻¹ * K.submatrix (fun i : I => i.val) (id : ι → ι)

/-- The paper's E_K(I), using finite-dimensional trace. -/
def residualTrace (K : Matrix ι ι ℝ) (I : Finset ι) : ℝ := (residual K I).trace

/-- Sum of all principal k-minors, prior to its spectral identification. -/
def minorSum (K : Matrix ι ι ℝ) (k : ℕ) : ℝ :=
  ∑ I ∈ (Finset.univ : Finset ι).powersetCard k, (principal K I).det

omit [Fintype ι] [DecidableEq ι] in
theorem principal_posDef {K : Matrix ι ι ℝ} (hK : K.PosDef) (I : Finset ι) :
    (principal K I).PosDef := by
  exact hK.submatrix Subtype.val_injective

omit [Fintype ι] in
theorem principal_det_pos {K : Matrix ι ι ℝ} (hK : K.PosDef) (I : Finset ι) :
    0 < (principal K I).det := by
  exact (principal_posDef hK I).det_pos

omit [Fintype ι] in
/-- Selected coordinates have exactly zero residual diagonal. -/
theorem residual_selected_diag {K : Matrix ι ι ℝ} (hK : K.PosDef)
    (I : Finset ι) (i : I) : residual K I i i = 0 := by
  have hunit : IsUnit (principal K I).det := isUnit_iff_ne_zero.mpr (principal_det_pos hK I).ne'
  have hrow (j : I) :
      (K.submatrix (id : ι → ι) (fun i : I => i.val) * (principal K I)⁻¹) (i : ι) j = (1 : Matrix I I ℝ) i j := by
    have h := congrArg (fun M : Matrix I I ℝ => M i j)
      (Matrix.mul_nonsing_inv (principal K I) hunit)
    simpa only [Matrix.mul_apply, principal, Matrix.submatrix_apply, id_eq] using h
  change K i i - ∑ j : I,
    (K.submatrix (id : ι → ι) (fun a : I => a.val) * (principal K I)⁻¹) (i : ι) j * K j i = 0
  simp_rw [hrow]
  simp [Matrix.one_apply]

/-- Trace can therefore be restricted to unselected indices. -/
theorem residualTrace_eq_complement_sum {K : Matrix ι ι ℝ} (hK : K.PosDef)
    (I : Finset ι) : residualTrace K I = ∑ j ∈ Finset.univ \ I, residual K I j j := by
  unfold residualTrace Matrix.trace
  symm
  apply Finset.sum_subset (Finset.sdiff_subset)
  intro j _ hj
  have hjI : j ∈ I := by simpa using hj
  exact residual_selected_diag hK I ⟨j, hjI⟩

/-- Explicit row/column reindexing for adding one coordinate. -/
def insertEquiv (I : Finset ι) (j : ι) (hj : j ∉ I) : I ⊕ Unit ≃ (insert j I : Finset ι) where
  toFun := fun x => match x with
    | Sum.inl i => ⟨i, Finset.mem_insert_of_mem i.property⟩
    | Sum.inr _ => ⟨j, Finset.mem_insert_self j I⟩
  invFun := fun x => if h : x.val ∈ I then Sum.inl ⟨x.val,h⟩ else Sum.inr ()
  left_inv := by
    intro x
    cases x with
    | inl i => simp [i.property]
    | inr u => cases u; simp [hj]
  right_inv := by
    intro x
    dsimp
    split_ifs with h
    · rfl
    · apply Subtype.ext
      have hx := Finset.mem_insert.mp x.property
      exact (hx.resolve_right h).symm

omit [Fintype ι] in
/-- One added principal minor is determinant(block) times a residual diagonal.
This is the matrix Schur-determinant step behind equation (8.4). -/
theorem det_insert_eq_det_mul_residual {K : Matrix ι ι ℝ} (hK : K.PosDef)
    (I : Finset ι) (j : ι) (hj : j ∉ I) :
    (principal K (insert j I)).det = (principal K I).det * residual K I j j := by
  let A := principal K I
  let B : Matrix I Unit ℝ := fun i _ => K i j
  let C : Matrix Unit I ℝ := fun _ i => K j i
  let D : Matrix Unit Unit ℝ := fun _ _ => K j j
  let e := insertEquiv I j hj
  have he : (principal K (insert j I)).submatrix e e = Matrix.fromBlocks A B C D := by
    ext a b
    cases a <;> cases b <;> rfl
  have hd := Matrix.det_submatrix_equiv_self e (principal K (insert j I))
  rw [he] at hd
  let _ : Invertible A := (principal_posDef hK I).isUnit.invertible
  rw [← hd, Matrix.det_fromBlocks₁₁, Matrix.invOf_eq_nonsing_inv]
  congr 1
  simp only [Matrix.det_unique, Matrix.sub_apply, Matrix.mul_apply, residual,
    Matrix.submatrix_apply, id_eq, A, B, C, D]
  rfl

/-- Equation (8.4), with actual Nystrom residuals and all unselected coordinates. -/
theorem determinant_weighted_residual {K : Matrix ι ι ℝ} (hK : K.PosDef)
    (I : Finset ι) :
    (principal K I).det * residualTrace K I =
      ∑ j ∈ Finset.univ \ I, (principal K (insert j I)).det := by
  rw [residualTrace_eq_complement_sum hK, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j hj
  exact (det_insert_eq_det_mul_residual hK I j (Finset.mem_sdiff.mp hj).2).symm

/-- Spectral minor identity, first for a diagonal matrix. -/
theorem minorSum_diagonal (eig : ι → ℝ) (k : ℕ) :
    minorSum (Matrix.diagonal eig) k = (Finset.univ.val.map eig).esymm k := by
  rw [Finset.esymm_map_val]
  apply Finset.sum_congr rfl
  intro I _
  simp only [principal, Matrix.submatrix_diagonal _ _ Subtype.val_injective,
    Matrix.det_diagonal, Function.comp_apply]
  exact Finset.prod_coe_sort I eig

/-- Principal minor sums are invariant under equal characteristic polynomials. -/
theorem minorSum_eq_of_charpoly_eq {K L : Matrix ι ι ℝ}
    (h : K.charpoly = L.charpoly) {k : ℕ} (hk : k ≤ Fintype.card ι) :
    minorSum K k = minorSum L k := by
  have hK := Matrix.charpoly_coeff_eq_sum_minors K k hk
  have hL := Matrix.charpoly_coeff_eq_sum_minors L k hk
  rw [h] at hK
  have he : (-1:ℝ)^k * minorSum K k = (-1:ℝ)^k * minorSum L k := hK.symm.trans hL
  exact mul_left_cancel₀ (by positivity : (-1:ℝ)^k ≠ 0) he

/-- Double counting each (k+1)-subset once for each of its elements. -/
theorem sum_insert_count (k : ℕ) (f : Finset ι → ℝ) :
    (∑ I ∈ (Finset.univ : Finset ι).powersetCard k,
      ∑ j ∈ Finset.univ \ I, f (insert j I)) =
    ((k : ℝ) + 1) * ∑ J ∈ (Finset.univ : Finset ι).powersetCard (k+1), f J := by
  let s := (Finset.univ : Finset ι).powersetCard k
  let t := (Finset.univ : Finset ι).powersetCard (k+1)
  have hb : (∑ a ∈ s.sigma (fun I => Finset.univ \ I), f (insert a.2 a.1)) =
      ∑ b ∈ t.sigma (fun J => J), f b.1 := by
    apply Finset.sum_bij' (fun a _ => ⟨insert a.2 a.1, a.2⟩)
      (fun b _ => ⟨b.1.erase b.2, b.2⟩)
    case hi =>
      intro a ha
      rcases Finset.mem_sigma.mp ha with ⟨ha, hj⟩
      have hc := (Finset.mem_powersetCard.mp ha).2
      have hn := (Finset.mem_sdiff.mp hj).2
      apply Finset.mem_sigma.mpr
      refine ⟨Finset.mem_powersetCard.mpr ⟨Finset.subset_univ _, ?_⟩, Finset.mem_insert_self _ _⟩
      simpa [Finset.card_insert_of_notMem hn] using hc
    case hj =>
      intro b hb
      rcases Finset.mem_sigma.mp hb with ⟨hb, hj⟩
      have hc := (Finset.mem_powersetCard.mp hb).2
      apply Finset.mem_sigma.mpr
      refine ⟨Finset.mem_powersetCard.mpr ⟨Finset.subset_univ _, ?_⟩, ?_⟩
      · rw [Finset.card_erase_of_mem hj, hc]
        omega
      · simp
    case left_neg =>
      intro a ha
      have hn := (Finset.mem_sdiff.mp (Finset.mem_sigma.mp ha).2).2
      simp [Finset.erase_insert hn]
    case right_neg =>
      intro b hb
      have hj := (Finset.mem_sigma.mp hb).2
      simp [Finset.insert_erase hj]
    case h =>
      intro a ha
      rfl
  rw [Finset.sum_sigma']
  change (∑ a ∈ s.sigma (fun I => Finset.univ \ I), f (insert a.2 a.1)) = _
  rw [hb, Finset.sum_sigma]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro J hJ
  have hc := (Finset.mem_powersetCard.mp hJ).2
  simp [hc, Nat.cast_add, Nat.cast_one]

/-- Sum of determinant-weighted actual Nystrom errors. -/
theorem sum_determinant_weighted_residual {K : Matrix ι ι ℝ} (hK : K.PosDef) (k : ℕ) :
    (∑ I ∈ (Finset.univ : Finset ι).powersetCard k,
      (principal K I).det * residualTrace K I) = ((k : ℝ)+1) * minorSum K (k+1) := by
  simp_rw [determinant_weighted_residual hK]
  exact sum_insert_count k (fun I => (principal K I).det)

/-- Positive definiteness makes the finite volume-sampling denominator positive. -/
theorem minorSum_pos {K : Matrix ι ι ℝ} (hK : K.PosDef) {k : ℕ}
    (hk : k ≤ Fintype.card ι) : 0 < minorSum K k := by
  apply Finset.sum_pos
  · intro I hI
    exact principal_det_pos hK I
  · exact Finset.powersetCard_nonempty.mpr (by simpa using hk)

/-- Some size-k principal selection is no worse than the exact volume-weighted average. -/
theorem exists_residualTrace_le_minor_ratio {K : Matrix ι ι ℝ} (hK : K.PosDef)
    {k : ℕ} (hk : k ≤ Fintype.card ι) :
    ∃ I ∈ (Finset.univ : Finset ι).powersetCard k,
      residualTrace K I ≤ ((k : ℝ)+1) * minorSum K (k+1) / minorSum K k := by
  let r := ((k : ℝ)+1) * minorSum K (k+1) / minorSum K k
  have hp := minorSum_pos hK hk
  by_contra hn
  push Not at hn
  have hs : (∑ I ∈ (Finset.univ : Finset ι).powersetCard k, (principal K I).det * r) <
      ∑ I ∈ (Finset.univ : Finset ι).powersetCard k,
        (principal K I).det * residualTrace K I := by
    apply Finset.sum_lt_sum_of_nonempty
    · exact Finset.powersetCard_nonempty.mpr (by simpa using hk)
    · intro I hI
      exact mul_lt_mul_of_pos_left (hn I hI) (principal_det_pos hK I)
  rw [← Finset.sum_mul, sum_determinant_weighted_residual hK] at hs
  change minorSum K k * r < _ at hs
  have he : minorSum K k * r = ((k : ℝ)+1) * minorSum K (k+1) := by
    dsimp [r]
    field_simp
  rw [he] at hs
  exact (lt_irrefl _ hs)

/-- Orthogonal conjugation has the specified diagonal characteristic polynomial. -/
theorem orbit_charpoly (eig : ι → ℝ) (V : Matrix ι ι ℝ)
    (hV : V * V.transpose = 1) :
    (V.transpose * Matrix.diagonal eig * V).charpoly = (Matrix.diagonal eig).charpoly := by
  rw [Matrix.charpoly_mul_comm, ← Matrix.mul_assoc, hV, Matrix.one_mul]

/-- Positive spectrum makes every real orthogonal conjugate positive definite. -/
theorem orbit_posDef (eig : ι → ℝ) (heig : ∀ i, 0 < eig i) (V : Matrix ι ι ℝ)
    (hV : V.transpose * V = 1) : (V.transpose * Matrix.diagonal eig * V).PosDef := by
  have hinj : Function.Injective V.mulVec := by
    intro x y hxy
    have h := congrArg (fun z => V.transpose *ᵥ z) hxy
    simpa only [Matrix.mulVec_mulVec, hV, Matrix.one_mulVec] using h
  have h := (Matrix.PosDef.diagonal heig).conjTranspose_mul_mul_same hinj
  simpa using h

/-- Exact spectral interpretation of every principal-minor sum on the orthogonal orbit. -/
theorem orbit_minorSum (eig : ι → ℝ) (V : Matrix ι ι ℝ)
    (hV : V * V.transpose = 1) {k : ℕ} (hk : k ≤ Fintype.card ι) :
    minorSum (V.transpose * Matrix.diagonal eig * V) k =
      (Finset.univ.val.map eig).esymm k := by
  rw [minorSum_eq_of_charpoly_eq (orbit_charpoly eig V hV) hk, minorSum_diagonal]

/-- The fixed-orientation comparison underlying x_k ≤ y_k, with literal matrix errors. -/
theorem orbit_exists_residualTrace_le_spectral_ratio (eig : ι → ℝ)
    (heig : ∀ i, 0 < eig i) (V : Matrix ι ι ℝ) (hV : V.transpose * V = 1)
    {k : ℕ} (hk : k < Fintype.card ι) :
    ∃ I ∈ (Finset.univ : Finset ι).powersetCard k,
      residualTrace (V.transpose * Matrix.diagonal eig * V) I ≤
        ((k : ℝ)+1) * (Finset.univ.val.map eig).esymm (k+1) /
          (Finset.univ.val.map eig).esymm k := by
  have hV' : V * V.transpose = 1 := mul_eq_one_comm.mp hV
  have h := exists_residualTrace_le_minor_ratio (orbit_posDef eig heig V hV) hk.le
  rwa [orbit_minorSum eig V hV' hk.le,
    orbit_minorSum eig V hV' (by omega : k+1 ≤ Fintype.card ι)] at h

/-- The actual positive volume-sampling weights normalize to one. -/
theorem determinant_weights_sum_one {K : Matrix ι ι ℝ} (hK : K.PosDef) {k : ℕ}
    (hk : k ≤ Fintype.card ι) :
    (∑ I ∈ (Finset.univ : Finset ι).powersetCard k,
      (principal K I).det / minorSum K k) = 1 := by
  rw [← Finset.sum_div]
  exact div_self (minorSum_pos hK hk).ne'

/-- Every determinant weight on the fixed-size family is strictly positive. -/
theorem determinant_weight_pos {K : Matrix ι ι ℝ} (hK : K.PosDef) {k : ℕ}
    (hk : k ≤ Fintype.card ι) (I : Finset ι) :
    0 < (principal K I).det / minorSum K k := by
  exact div_pos (principal_det_pos hK I) (minorSum_pos hK hk)

/-- The normalized weighted mean is exactly the principal-minor ratio. -/
theorem determinant_weighted_mean {K : Matrix ι ι ℝ} (hK : K.PosDef) (k : ℕ) :
    (∑ I ∈ (Finset.univ : Finset ι).powersetCard k,
      ((principal K I).det / minorSum K k) * residualTrace K I) =
      ((k : ℝ)+1) * minorSum K (k+1) / minorSum K k := by
  simp_rw [div_mul_eq_mul_div]
  rw [← Finset.sum_div, sum_determinant_weighted_residual hK]

/-- Volume-sampling on each positive orthogonal orbit has the paper's spectral mean. -/
theorem orbit_determinant_weighted_mean (eig : ι → ℝ) (heig : ∀ i, 0 < eig i)
    (V : Matrix ι ι ℝ) (hV : V.transpose * V = 1) {k : ℕ} (hk : k < Fintype.card ι) :
    let K := V.transpose * Matrix.diagonal eig * V
    (∑ I ∈ (Finset.univ : Finset ι).powersetCard k,
      ((principal K I).det / (Finset.univ.val.map eig).esymm k) * residualTrace K I) =
      ((k : ℝ)+1) * (Finset.univ.val.map eig).esymm (k+1) / (Finset.univ.val.map eig).esymm k := by
  have hV' : V * V.transpose = 1 := mul_eq_one_comm.mp hV
  have h := determinant_weighted_mean (orbit_posDef eig heig V hV) k
  rwa [orbit_minorSum eig V hV' hk.le,
    orbit_minorSum eig V hV' (by omega : k+1 ≤ Fintype.card ι)] at h

end SpectralComparison
