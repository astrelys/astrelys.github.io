import SpectralComparison.Whitening
import SpectralComparison.MatrixRegularization
import Mathlib.LinearAlgebra.Matrix.Rank

/-! The Gaussian base case of the uniform principal-block projection construction. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Equation (4.6), in the Gaussian range p>=4 and 4p/3<=N<=2p. -/
theorem exists_base_frame {N t q : ℕ} (ht : 1 ≤ t) (hp : 4 ≤ t+q)
    (hNlow : 4*(t+q) ≤ 3*N) (hNhigh : N ≤ 2*(t+q)) :
    ∃ V : Matrix (Fin N) (Fin (t+q)) ℝ, Vᴴ*V=1 ∧
      ∀ J : Finset (Fin N), J.card=t → IsUnit ((V*Vᴴ).submatrix (fun i : J => (i : Fin N)) (fun i : J => (i : Fin N))) →
        ((t+q:ℕ):ℝ)*t/(1000000000000000000000000000*((q:ℝ)+Real.sqrt (t+q:ℕ))) ≤
        ((V*Vᴴ).submatrix (fun i : J => (i : Fin N)) (fun i : J => (i : Fin N)))⁻¹.trace := by
  obtain ⟨G,hupper,hlower,hrows⟩ := exists_uniform_good_matrix ht hp hNlow hNhigh
  have hpp : (0:ℝ)<(t+q:ℕ) := by exact_mod_cast (show 0<t+q by omega)
  have hG := gram_posDef_of_unit_norm G (div_pos (Real.sqrt_pos.mpr hpp) (by norm_num)) hlower
  obtain ⟨V,hV,hproj⟩ := exists_gram_whitening G hG
  refine ⟨V,hV,?_⟩
  intro J hJ hunit
  let e : J → Fin N := fun i => i
  have hblock : ((V*Vᴴ).submatrix e e).PosDef :=
    ((posSemidef_self_mul_conjTranspose V).submatrix e).posDef_iff_isUnit.mpr hunit
  have he : (G*Gᴴ).submatrix e e = G.submatrix e id * (G.submatrix e id)ᴴ := by
    ext i j
    simp [Matrix.mul_apply]
  have htrace : (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t+q:ℕ))) ≤ ((G*Gᴴ).submatrix e e)⁻¹.trace := by
    rw [he]
    exact (hrows J hJ).le
  have hh := whitening_inverse_trace_lower G V hG hproj
    (div_pos hpp (by positivity : (0:ℝ)<(1000000000000:ℝ)^2))
    (gaussian_good_gram_lower G hlower) e hblock htrace
  convert hh using 1; simp only [div_eq_mul_inv, _root_.mul_inv_rev]; ring

/-- Orthonormal columns give an orthogonal projection of the asserted rank. -/
theorem frame_projection_properties {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p] (V : Matrix n p ℝ) (hV : Vᴴ*V=1) :
    (V*Vᴴ).IsHermitian ∧ (V*Vᴴ)*(V*Vᴴ)=V*Vᴴ ∧ (V*Vᴴ).rank=Fintype.card p := by
  refine ⟨isHermitian_mul_conjTranspose_self V,?_,?_⟩
  · calc
      (V*Vᴴ)*(V*Vᴴ) = V*(Vᴴ*V)*Vᴴ := by simp only [Matrix.mul_assoc]
      _ = V*Vᴴ := by rw [hV, Matrix.mul_one]
  · rw [Matrix.rank_self_mul_conjTranspose, ← Matrix.rank_conjTranspose_mul_self V, hV, Matrix.rank_one]

/-- The complete conclusion of Lemma 4.1 on its Gaussian base range.
The general-N replication and p<=3 cases are deliberately not hidden in hypotheses. -/
theorem paper_lemma_4_1_base_range {N t q : ℕ} (ht : 1 ≤ t) (hp : 4 ≤ t+q)
    (hNlow : 4*(t+q) ≤ 3*N) (hNhigh : N ≤ 2*(t+q)) :
    ∃ P : Matrix (Fin N) (Fin N) ℝ, P.IsHermitian ∧ P*P=P ∧ P.rank=t+q ∧
      (∀ J : Finset (Fin N), J.card=t → IsUnit (P.submatrix (fun i : J => (i : Fin N)) (fun i : J => (i : Fin N))) →
        (N:ℝ)*t/(4000000000000000000000000000*((q:ℝ)+Real.sqrt (t+q:ℕ))) ≤
        (P.submatrix (fun i : J => (i : Fin N)) (fun i : J => (i : Fin N)))⁻¹.trace) ∧
      (∀ (J : Finset (Fin N)) (T : Matrix J J ℝ) (α β : ℝ), J.card=t → T.PosDef → 0<α → 0<β →
        (α • 1 + β • P.submatrix (fun i : J => (i : Fin N)) (fun i : J => (i : Fin N)) - T).PosSemidef →
        let L := (N:ℝ)*t/(4000000000000000000000000000*((q:ℝ)+Real.sqrt (t+q:ℕ)))
        L/(β+α*L) ≤ T⁻¹.trace) := by
  obtain ⟨V,hV,hblocks⟩ := exists_base_frame ht hp hNlow hNhigh
  obtain ⟨hs,hi,hr⟩ := frame_projection_properties V hV
  have hd : 0 < (q:ℝ)+Real.sqrt (t+q:ℕ) := add_pos_of_nonneg_of_pos (Nat.cast_nonneg q)
    (Real.sqrt_pos.mpr (by exact_mod_cast (show 0<t+q by omega)))
  have hbound (J : Finset (Fin N)) (hJ : J.card=t)
      (hu : IsUnit ((V*Vᴴ).submatrix (fun i : J => (i : Fin N)) (fun i : J => (i : Fin N)))) :
      (N:ℝ)*t/(4000000000000000000000000000*((q:ℝ)+Real.sqrt (t+q:ℕ))) ≤
      ((V*Vᴴ).submatrix (fun i : J => (i : Fin N)) (fun i : J => (i : Fin N)))⁻¹.trace := by
    apply le_trans _ (hblocks J hJ hu)
    have hn : (N:ℝ) ≤ 2*(t+q:ℕ) := by exact_mod_cast hNhigh
    have hn4 : (N:ℝ) ≤ 4*(t+q:ℕ) := by nlinarith [show (0:ℝ) ≤ (t+q:ℕ) from Nat.cast_nonneg (t+q)]
    have hh := div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_right hn4 (Nat.cast_nonneg t))
      (mul_nonneg (by norm_num : (0:ℝ) ≤ 4000000000000000000000000000) hd.le)
    convert hh using 1; simp only [div_eq_mul_inv, _root_.mul_inv_rev]; ring

  refine ⟨V*Vᴴ,hs,hi,by simpa using hr,hbound,?_⟩
  intro J T α β hJ hT hα hβ hgap
  apply matrix_regularization ((posSemidef_self_mul_conjTranspose V).submatrix _) hT hα hβ
  · apply div_pos
    · exact mul_pos (by exact_mod_cast (show 0<N by omega)) (by exact_mod_cast (show 0<t by omega))
    · exact mul_pos (by norm_num) hd
  · exact hbound J hJ
  · exact hgap

end SpectralComparison
