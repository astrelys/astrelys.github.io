import SpectralComparison.ElementarySymmetric

/-! Section 9 proof reduction using the actual symmetric quotient.
This reduction takes two construction estimates as hypotheses.
The final theorem in MainBound discharges both using proved constructions.
-/
namespace SpectralComparison

/-- Multiset version of the threshold-count step, including multiplicities. -/
theorem multiset_threshold_count {F r : ℝ} (hF : 0 < F) (hr : 0 ≤ r)
    (s : Multiset ℝ) (hs : ∀ z ∈ s, 0 ≤ z) :
    ((s.filter (fun z => z < r*F)).card:ℝ) / (1+r) ≤
      (s.map (fun z => F/(z+F))).sum := by
  have hdr : 0 < 1+r := by positivity
  induction s using Multiset.induction_on with
  | empty => simp
  | @cons z s ih =>
    have hz := hs z (by simp)
    have hst : ∀ w ∈ s, 0 ≤ w := fun w hw => hs w (by simp [hw])
    have hprev := ih hst
    by_cases hlt : z < r*F
    · have hterm : 1/(1+r) ≤ F/(z+F) := by
        apply (div_le_div_iff₀ hdr (by positivity)).2
        nlinarith
      rw [Multiset.filter_cons_of_pos (p := fun z => z < r*F) s hlt]
      simp only [Multiset.card_cons,
        Nat.cast_add, Nat.cast_one, add_div, Multiset.map_cons, Multiset.sum_cons]
      linarith
    · have hterm : 0 ≤ F/(z+F) := by positivity
      rw [Multiset.filter_cons_of_neg (p := fun z => z < r*F) s hlt]
      simp only [Multiset.map_cons, Multiset.sum_cons]
      linarith

/-- Conditional form of the paper's main upper comparison (9.1).

`head` has k entries and `tail` has m entries; all entries are positive.
The actual F=e_{k+1}/e_k and the quotient estimates are proved, not assumed.
`hprefix` and `hdiffuse` are threshold-form contracts for (6.3) and (7.1):
for each threshold a, q counts head entries strictly below a. The sorted-index
bridge a ≤ a_q is proved in MainInterface, where x is instantiated by the
actual matrix objective and `hdiag` is discharged by Diagonal. MainBound
discharges both construction hypotheses. The lower comparison x ≤ y is proved in
WorstOrientation and lies outside this upper-comparison theorem.
This theorem must not be labeled as the unconditional spectral theorem.
-/
theorem main_upper_from_construction_contracts (head tail : Multiset ℝ)
    (hh : ∀ z ∈ head, 0 < z) (ht : ∀ z ∈ tail, 0 < z)
    (hk : 1 ≤ head.card) (hm : 1 ≤ tail.card) (x : ℝ)
    (hdiag : tail.sum ≤ x)
    (hprefix : ∀ a : ℝ, 0 < a →
      (((head.filter (fun z => z < a)).card:ℝ) ≤ (head.card:ℝ)/2) →
      let U := (head.card:ℝ)*tail.sum /
        ((32*10^27)*(((head.filter (fun z => z < a)).card:ℝ)+Real.sqrt head.card)*H tail.card)
      a*U/(a+U) ≤ x)
    (hdiffuse : ∀ a : ℝ, 0 < a →
      (((head.filter (fun z => z < a)).card:ℝ) ≤ (head.card:ℝ)/4) →
      let V := (head.card:ℝ)*tail.sum /
        ((64*10^27)*(((head.filter (fun z => z < a)).card:ℝ)+Real.sqrt head.card)*H (8*head.card))
      a*V/(a+V) ≤ x) :
    let F := (head+tail).esymm (head.card+1)/(head+tail).esymm head.card
    ((head.card:ℝ)+1)*F ≤
      (((head.card:ℝ)+1)*min 1 ((768*10^27*H (min head.card tail.card)+1)/Real.sqrt head.card))*x := by
  classical
  let F := (head+tail).esymm (head.card+1)/(head+tail).esymm head.card
  let r := Real.sqrt (head.card:ℝ)
  let q := (head.filter (fun z => z < r*F)).card
  let y := ((head.card:ℝ)+1)*F
  change y ≤ (((head.card:ℝ)+1)*min 1 ((768*10^27*H (min head.card tail.card)+1)/r))*x
  have hall : ∀ w ∈ head+tail, 0 < w := by
    intro w hw
    rcases Multiset.mem_add.mp hw with hw | hw
    · exact hh w hw
    · exact ht w hw
  have hF : 0 < F := div_pos
    (esymm_pos (head+tail) hall (head.card+1) (by simp; omega))
    (esymm_pos (head+tail) hall head.card (by simp))
  have hFS : F ≤ tail.sum := symmetric_quotient_le_tail head tail hh ht
  have hx : 0 < x := lt_of_lt_of_le (hF.trans_le hFS) hdiag
  have hkR : (1:ℝ) ≤ head.card := by exact_mod_cast hk
  have hr : 1 ≤ r := Real.one_le_sqrt.mpr hkR
  have hr0 : 0 < r := by linarith
  have hr2 : r^2 = (head.card:ℝ) := Real.sq_sqrt (by positivity)
  have hq0 : (0:ℝ) ≤ q := by positivity
  have hq : (q:ℝ) ≤ (1+r)*(tail.sum/F) := by
    have hcount := multiset_threshold_count hF hr0.le head (fun z hz => (hh z hz).le)
    have hsum := symmetric_quotient_head_sum_le_tail head tail hh ht hk hm
    have hle : (q:ℝ)/(1+r) ≤ tail.sum/F := hcount.trans hsum
    have hmul := (div_le_iff₀ (show 0 < 1+r by positivity)).mp hle
    nlinarith
  have hH : 1 ≤ H tail.card := one_le_H hm
  have hH8 : 1 ≤ H (8*head.card) := one_le_H (by omega)
  have hbase : y/x ≤ (head.card:ℝ)+1 := by
    apply (div_le_iff₀ hx).2
    exact mul_le_mul_of_nonneg_left (hFS.trans hdiag) (by positivity)
  have hshort : y/x ≤ ((head.card:ℝ)+1)*((96*10^27*H tail.card+1)/r) := by
    have hcase := tail_comparison_from_inputs (r:=r) (F:=F) (s:=tail.sum)
      (q:=(q:ℝ)) (C:=32*10^27) (H:=H tail.card) (d:=4)
      (x:=x) (y:=y) (k:=(head.card:ℝ)) hr hF hFS hq0 hq
      (by norm_num) (by linarith) (by norm_num) (by nlinarith) hx hdiag
      (by positivity) rfl (by
        intro hqr
        refine ⟨r*F, le_rfl, ?_⟩
        have hqr' : (q:ℝ) ≤ (head.card:ℝ)/2 := by nlinarith [hr2]
        have hc := hprefix (r*F) (mul_pos hr0 hF) hqr'
        simpa only [hr2] using hc)
    convert hcase using 1
    ring
  have hlong : y/x ≤ ((head.card:ℝ)+1)*((192*10^27*H (8*head.card)+1)/r) := by
    have hcase := tail_comparison_from_inputs (r:=r) (F:=F) (s:=tail.sum)
      (q:=(q:ℝ)) (C:=64*10^27) (H:=H (8*head.card)) (d:=8)
      (x:=x) (y:=y) (k:=(head.card:ℝ)) hr hF hFS hq0 hq
      (by norm_num) (by linarith) (by norm_num) (by nlinarith) hx hdiag
      (by positivity) rfl (by
        intro hqr
        refine ⟨r*F, le_rfl, ?_⟩
        have hqr' : (q:ℝ) ≤ (head.card:ℝ)/4 := by nlinarith [hr2]
        have hc := hdiffuse (r*F) (mul_pos hr0 hF) hqr'
        simpa only [hr2] using hc)
    convert hcase using 1
    ring
  have hfinal := main_comparison_assembly hk hbase hshort hlong
  exact (div_le_iff₀ hx).mp hfinal

end SpectralComparison
