import SpectralComparison.BalancedConditionScalar

noncomputable section
open Filter Topology
namespace SpectralComparison

theorem weightedGamma_balanced {k : ℕ} (hk : 1 ≤ k) :
    weightedGamma k k = Real.sqrt (k:ℝ)/32000000000 := by
  have hk0 : (0:ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hs : 0 < Real.sqrt (k:ℝ) := Real.sqrt_pos.mpr hk0
  rw [weightedGamma,ite_eq_left (le_refl k)]
  apply (div_eq_div_iff (ne_of_gt (by positivity : (0:ℝ) < 32000000000*Real.sqrt k)) (by norm_num)).mpr
  nlinarith [Real.sq_sqrt hk0.le]

/-- E.7, with both original finite conclusions and the literal condition-number constant. -/
theorem paper_balanced_condition {k : ℕ} (hk : 1 ≤ k)
    (eig : Fin (k+k) → ℝ) (heig : ∀ i, 0 < eig i) (horder : Antitone eig) :
    let a := eig ⟨k-1,by omega⟩
    let A := eig ⟨0,by omega⟩
    let s := ∑ i : Fin k,eig (i.natAdd k)
    spectralMean eig k ≤ ((k:ℝ)+1)*min s (Real.sqrt (A*s/k)) ∧
      spectralMean eig k / worstError eig k ≤
        ((k:ℝ)+1)*min 1 ((32000000000+Real.sqrt (A/a))/Real.sqrt k) := by
  let a := eig ⟨k-1,by omega⟩
  let A := eig ⟨0,by omega⟩
  let s := ∑ i : Fin k,eig (i.natAdd k)
  have ha : 0 < a := heig _
  have hA : 0 < A := heig _
  have hs : 0 < s := Finset.sum_pos (fun i _ => heig _) ⟨⟨0,by omega⟩,Finset.mem_univ _⟩
  have hk0 : (0:ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hsk : 0 < Real.sqrt (k:ℝ) := Real.sqrt_pos.mpr hk0
  have hyl := spectralMean_le_indexed_tail hk eig heig
  have hyq := balanced_head_spectralMean_sqrt hk eig heig hA
    (fun i => horder (by change 0 ≤ i.val; omega))
  refine ⟨?_,?_⟩
  · rw [mul_min_of_nonneg _ _ (by positivity : (0:ℝ) ≤ (k:ℝ)+1)]
    exact le_min hyl hyq
  · have hw := (paper_weighted_finite hk hk eig heig horder).1
    have hd := (le_max_left _ _).trans hw
    have hridge := (le_max_right _ _).trans hw
    have hx := worstError_pos eig heig (k:=k) (by simp; omega)
    have hy0 := hx.le.trans (worstError_le_spectralMean eig heig (by simp; omega))
    have hq2 : (Real.sqrt (A*s/k))^2 = (Real.sqrt (A/a)/Real.sqrt k)^2*a*s := by
      rw [Real.sq_sqrt (by positivity),div_pow,Real.sq_sqrt (by positivity),Real.sq_sqrt hk0.le]
      field_simp
    have hh := balanced_condition_scalar ha hs (weightedGamma_pos hk hk)
      (by positivity : (0:ℝ) ≤ (k:ℝ)+1) hy0 (Real.sqrt_nonneg (A*s/k))
      (div_nonneg (Real.sqrt_nonneg (A/a)) hsk.le) hq2 hd hridge hyl hyq
    have he : (weightedGamma k k)⁻¹+Real.sqrt (A/a)/Real.sqrt k =
        (32000000000+Real.sqrt (A/a))/Real.sqrt k := by
      rw [weightedGamma_balanced hk,inv_div]
      ring
    rwa [he] at hh

/-- The sharper balanced boundary coefficient following E.7. -/
theorem paper_balanced_condition_boundary {k : ℕ} (hk : 1 ≤ k)
    (e : Fin k ⊕ Fin k ≃ Fin (k+k)) (a b : Fin k → ℝ)
    (ha : ∀ i,0 < a i) (hb : ∀ i,0 < b i) :
    Filter.limsup (fun ε : ℝ => spectralMean (splitSpectrum e a b ε) k /
      worstError (splitSpectrum e a b ε) k) (𝓝[>] 0) ≤
        32000000000*((k:ℝ)+1)/Real.sqrt k := by
  have hh := (paper_weighted_boundary hk hk e a b ha hb).1
  rw [weightedGamma_balanced hk] at hh
  convert hh using 1 <;> field_simp <;> ring

end SpectralComparison
