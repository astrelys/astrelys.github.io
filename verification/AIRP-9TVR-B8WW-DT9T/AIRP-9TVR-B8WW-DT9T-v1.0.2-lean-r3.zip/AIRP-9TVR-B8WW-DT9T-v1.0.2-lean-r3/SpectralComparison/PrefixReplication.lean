import SpectralComparison.PrefixWeights
import SpectralComparison.FrameTransfer

/-! Repetition and zero padding for the large-prefix column-Gram bound. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Weighted control transfers to any selected normalized row family, including padded zeros. -/
theorem optional_row_inverse_trace {n j p : Type*} [Fintype n] [Fintype j] [Fintype p]
    [DecidableEq n] [DecidableEq p] [Nonempty n] (Q : Matrix n p ℝ)
    {k h : ℕ} {C : ℝ} (hh : 0<h) (hj : Fintype.card j≤k)
    (hb : ∀ w : n → ℕ, (∑ i,w i)=k → IsUnit (Qᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Q) →
      C≤(Qᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Q)⁻¹.trace)
    (f : j → Option n)
    (hu : IsUnit ((Matrix.of (fun a b => (f a).elim 0 (fun i => Q i b/Real.sqrt h)) : Matrix j p ℝ)ᴴ *
      (Matrix.of (fun a b => (f a).elim 0 (fun i => Q i b/Real.sqrt h)) : Matrix j p ℝ))) :
    (h:ℝ)*C ≤ ((Matrix.of (fun a b => (f a).elim 0 (fun i => Q i b/Real.sqrt h)) : Matrix j p ℝ)ᴴ *
      (Matrix.of (fun a b => (f a).elim 0 (fun i => Q i b/Real.sqrt h)) : Matrix j p ℝ))⁻¹.trace := by
  classical
  let w : n → ℕ := fun i => (Finset.univ.filter (fun a => f a=some i)).card
  let B := Qᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Q
  have he := optional_row_gram Q f hh
  change _=(h:ℝ)⁻¹ • B at he
  rw [he] at hu ⊢
  have hp : (0:ℝ)<h := by exact_mod_cast hh
  have hBps : B.PosSemidef := (Matrix.PosSemidef.diagonal
    (fun i => Nat.cast_nonneg (α := ℝ) (w i))).conjTranspose_mul_mul_same Q
  have hs := (hBps.smul (inv_pos.mpr hp).le).posDef_iff_isUnit.mpr hu
  have hB : B.PosDef := by
    have h := hs.smul hp
    simpa only [smul_smul,mul_inv_cancel₀ hp.ne',one_smul] using h
  have hbound := weighted_inverse_trace_le_total Q hb w ((optional_row_counts_le f).trans hj) hB.isUnit
  rw [inverse_positive_smul hB (inv_ne_zero hp.ne'),inv_inv,Matrix.trace_smul]
  exact mul_le_mul_of_nonneg_left hbound hp.le

/-- Repeat a frame, append zeros, and reindex to exactly N rows, with all selected column Grams controlled. -/
theorem replicated_column_frame_control {n p N k : ℕ} (hn : 0<n) (hnN : n≤N)
    (Q : Matrix (Fin n) (Fin p) ℝ) (hQ : Qᴴ*Q=1) {C : ℝ}
    (hb : ∀ w : Fin n → ℕ, (∑ i,w i)=k → IsUnit (Qᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Q) →
      C≤(Qᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Q)⁻¹.trace) :
    ∃ V : Matrix (Fin N) (Fin p) ℝ, Vᴴ*V=1 ∧
      ∀ J : Finset (Fin N), J.card=k →
        IsUnit ((V.submatrix (fun i : J => (i:Fin N)) id)ᴴ * V.submatrix (fun i : J => (i:Fin N)) id) →
        ((N/n:ℕ):ℝ)*C ≤ ((V.submatrix (fun i : J => (i:Fin N)) id)ᴴ *
          V.submatrix (fun i : J => (i:Fin N)) id)⁻¹.trace := by
  let h := N/n
  have hh : 0<h := Nat.div_pos hnN hn
  let W : Matrix (Fin n × Fin h) (Fin p) ℝ := Matrix.of (fun i j => Q i.1 j/Real.sqrt h)
  have hW : Wᴴ*W=1 := replicated_frame_orthonormal Q hQ hh
  let U := Matrix.fromRows W (0 : Matrix (Fin (N%n)) (Fin p) ℝ)
  have hU : Uᴴ*U=1 := zero_padded_frame_orthonormal W hW
  have hdim : n*h+N%n=N := Nat.div_add_mod N n
  let e : Fin N ≃ (Fin n × Fin h) ⊕ Fin (N%n) := Fintype.equivOfCardEq (by simpa using hdim.symm)
  let V := U.submatrix e id
  have hV : Vᴴ*V=1 := by
    change (U.submatrix e id)ᴴ*U.submatrix e id=1
    rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,hU,Matrix.submatrix_id_id]
  refine ⟨V,hV,?_⟩
  intro J hJ hu
  let f : J → Option (Fin n) := fun a => (e a.val).elim (fun i => some i.1) (fun _ => none)
  have he : V.submatrix (fun i : J => (i:Fin N)) id =
      (Matrix.of (fun a b => (f a).elim 0 (fun i => Q i b/Real.sqrt h)) : Matrix J (Fin p) ℝ) := by
    ext a b
    change U (e a.val) b = ((e a.val).elim (fun i => some i.1) (fun _ => none)).elim 0 (fun i => Q i b/Real.sqrt h)
    cases e a.val <;> rfl
  rw [he] at hu ⊢
  let : Nonempty (Fin n) := ⟨⟨0,hn⟩⟩
  exact optional_row_inverse_trace Q hh (by simpa only [Fintype.card_coe,hJ] using (Nat.le_refl k)) hb f hu

/-- The robust frame yields equation (6.2) for every nonsingular selected k-row column Gram. -/
theorem prefix_large_column_frame {k q t : ℕ} (hk : 1≤k) (hq : 2*q≤k) (htk : k≤t) :
    ∃ Q : Matrix (Fin (k+t)) (Fin (k-q)) ℝ, Qᴴ*Q=1 ∧
      ∀ I : Finset (Fin (k+t)), I.card=k →
        IsUnit ((Q.submatrix (fun i : I => (i:Fin (k+t))) id)ᴴ * Q.submatrix (fun i : I => (i:Fin (k+t))) id) →
        ((k+t:ℕ):ℝ)*k/(32000000000000000000000000000*((q:ℝ)+Real.sqrt k)) ≤
          ((Q.submatrix (fun i : I => (i:Fin (k+t))) id)ᴴ * Q.submatrix (fun i : I => (i:Fin (k+t))) id)⁻¹.trace := by
  obtain ⟨Q,hQ,_,_,hb⟩ := paper_lemma_5_1 hk hq
  obtain ⟨V,hV,hVb⟩ := replicated_column_frame_control (show 0<2*k by omega) (show 2*k≤k+t by omega) Q hQ hb
  refine ⟨V,hV,?_⟩
  intro I hI hu
  apply le_trans _ (hVb I hI hu)
  let h := (k+t)/(2*k)
  have hh : 0<h := Nat.div_pos (by omega) (by omega)
  have hrem := Nat.mod_lt (k+t) (show 0<2*k by omega)
  have hdim : 2*k*h+(k+t)%(2*k)=k+t := Nat.div_add_mod (k+t) (2*k)
  have hn : k+t≤4*k*h := by nlinarith
  have hnr : ((k+t:ℕ):ℝ)≤4*(k:ℝ)*(h:ℝ) := by exact_mod_cast hn
  have hd : 0<(q:ℝ)+Real.sqrt k := add_pos_of_nonneg_of_pos (Nat.cast_nonneg q)
    (Real.sqrt_pos.mpr (by exact_mod_cast (show 0<k by omega)))
  have hb := div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_right hnr (Nat.cast_nonneg (α := ℝ) k))
    (mul_nonneg (by norm_num : (0:ℝ)≤32000000000000000000000000000) hd.le)
  convert hb using 1
  simp only [div_eq_mul_inv,_root_.mul_inv_rev]
  ring

end SpectralComparison
