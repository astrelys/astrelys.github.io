import SpectralComparison.HarmonicPrefix

/-! Complete finite-noise prefix proposition for the literal worst-orientation error. -/
noncomputable section
namespace SpectralComparison

/-- Paper finite-noise prefix proposition, equation (6.3), with the full prescribed spectrum.
Only positive decreasing eigenvalues and the original integer dimension conditions are assumed. -/
theorem paper_proposition_prefix {n k q : ℕ} (eig : Fin n → ℝ) (heig : ∀ i,0<eig i)
    (horder : Antitone eig) (hk : 1≤k) (hkn : k<n) (hq : 2*q≤k) :
    let s := ∑ i ∈ Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n),eig i
    let a := eig ⟨k-q-1,by omega⟩
    let U := (k:ℝ)*s/(32000000000000000000000000000*((q:ℝ)+Real.sqrt k)*H (n-k))
    max s (a*U/(a+U))≤worstError eig k := by
  classical
  let S := Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n)
  let s := ∑ i∈S,eig i
  let a := eig ⟨k-q-1,by omega⟩
  let D := 32000000000000000000000000000*((q:ℝ)+Real.sqrt k)
  let U := (k:ℝ)*s/(D*H (n-k))
  have hk0 : (0:ℝ)<k := by exact_mod_cast (show 0<k by omega)
  have hD : 0<D := by
    dsimp [D]
    apply mul_pos (by norm_num)
    exact add_pos_of_nonneg_of_pos (Nat.cast_nonneg q) (Real.sqrt_pos.mpr hk0)
  have hH : 0<H (n-k) := lt_of_lt_of_le zero_lt_one (one_le_H (by omega))
  have hs : 0<s := by
    apply Finset.sum_pos (fun i _ => heig i)
    apply Finset.card_pos.mp
    simp [S,Finset.card_sdiff,Fin.card_Iio]
    omega
  have ha : 0<a := heig _
  have hU : 0<U := div_pos (mul_pos hk0 hs) (mul_pos hD hH)
  have hdiag : s≤worstError eig k := by
    have hc : (Finset.Iio (⟨k,hkn⟩ : Fin n)).card=k := Fin.card_Iio _
    have hh := tail_le_worstError eig heig (Finset.Iio (⟨k,hkn⟩ : Fin n))
      (by
        intro i hi j hj
        exact horder (le_trans (Finset.mem_Iio.mp hi).le (not_lt.mp (by simpa using hj))))
      (by simpa only [hc,Fintype.card_fin] using hkn)
    simpa only [hc] using hh
  obtain ⟨t,ht,htn,hscale⟩ := exists_indexed_tail_prefix hkn eig
  let b := eig ⟨k+t-1,by omega⟩
  let L := (k:ℝ)*t/D
  have hb : 0<b := heig _
  have hL : 0<L := div_pos (mul_pos hk0 (by exact_mod_cast (show 0<t by omega))) hD
  have hscale' : s/H (n-k)≤(t:ℝ)*b := (div_le_iff₀ hH).mpr (by
    change s≤H (n-k)*(t:ℝ)*b at hscale
    nlinarith)
  have hUbL : U≤b*L := by
    calc
      U = (k:ℝ)/D*(s/H (n-k)) := by dsimp [U]; simp only [div_eq_mul_inv,_root_.mul_inv_rev]; ring
      _ ≤ (k:ℝ)/D*((t:ℝ)*b) := mul_le_mul_of_nonneg_left hscale' (div_pos hk0 hD).le
      _ = b*L := by dsimp [L]; ring
  have hbound : a*(b*L)/(a+b*L)≤worstError eig k :=
    prefix_fixed_length_bound eig heig horder hk hq ht htn
  change max s (a*U/(a+U))≤worstError eig k
  exact max_le hdiag ((parallel_sum_mono ha le_rfl hU hUbL).trans hbound)

end SpectralComparison
