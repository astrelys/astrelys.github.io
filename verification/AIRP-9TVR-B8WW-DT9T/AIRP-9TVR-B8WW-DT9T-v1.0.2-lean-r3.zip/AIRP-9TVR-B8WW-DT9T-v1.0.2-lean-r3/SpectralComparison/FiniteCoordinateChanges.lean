import SpectralComparison.QuotientOrder

/-! Finite coordinate telescoping, applied to spectral quotient monotonicity and capping. -/
noncomputable section
open Finset
namespace SpectralComparison
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

theorem finite_coordinate_bound (Φ : (ι → ℝ) → ℝ) (a b c : ι → ℝ)
    (hstep : ∀ (s : Finset ι) (i : ι), i∉s →
      Φ (Function.update (fun j => if j∈s then b j else a j) i (b i))≤
        Φ (fun j => if j∈s then b j else a j)+c i) : Φ b≤Φ a+∑ i,c i := by
  have h (s : Finset ι) : Φ (fun j => if j∈s then b j else a j)≤Φ a+∑ i∈s,c i := by
    induction s using Finset.induction_on with
    | empty => simp
    | @insert i s hi ih =>
      have he : Function.update (fun j => if j∈s then b j else a j) i (b i)=
          (fun j => if j∈insert i s then b j else a j) := by
        funext j; by_cases hj : j=i
        · subst j; simp
        · simp [hj]
      have ht := hstep s i hi
      rw [he] at ht
      rw [Finset.sum_insert hi]
      linarith
  simpa using h Finset.univ

theorem symmetricQuotient_mono (a b : ι → ℝ) (ha : ∀ i,0<a i) (hb : ∀ i,0<b i)
    (hab : ∀ i,a i≤b i) {k : ℕ} (hk : 1≤k) (hkn : k<Fintype.card ι) :
    symmetricQuotient (Finset.univ.val.map a) k≤symmetricQuotient (Finset.univ.val.map b) k := by
  have h := finite_coordinate_bound (fun f => -symmetricQuotient (Finset.univ.val.map f) k) a b (fun _ => 0) (by
    intro s i hi
    have hp : ∀ j,0<(if j∈s then b j else a j) := by intro j; split_ifs; exact hb j; exact ha j
    have ht := spectralQuotient_update_mono (fun j => if j∈s then b j else a j) hp i
      (by simpa only [ite_eq_right hi] using hab i) hk hkn
    simpa using neg_le_neg ht)
  simpa using h

omit [DecidableEq ι] in
theorem spectralMean_eq_quotient (a : ι → ℝ) (k : ℕ) :
    spectralMean a k=((k:ℝ)+1)*symmetricQuotient (Finset.univ.val.map a) k := by
  simp only [spectralMean,symmetricQuotient,mul_div_assoc]

theorem spectralMean_mono (a b : ι → ℝ) (ha : ∀ i,0<a i) (hb : ∀ i,0<b i)
    (hab : ∀ i,a i≤b i) {k : ℕ} (hk : 1≤k) (hkn : k<Fintype.card ι) :
    spectralMean a k≤spectralMean b k := by
  rw [spectralMean_eq_quotient,spectralMean_eq_quotient]
  exact mul_le_mul_of_nonneg_left (symmetricQuotient_mono a b ha hb hab hk hkn) (by positivity)

theorem symmetricQuotient_smul (s : Multiset ℝ) (k : ℕ) {c : ℝ} (hc : 0<c) :
    symmetricQuotient (s.map (fun z => c*z)) k=c*symmetricQuotient s k := by
  have he (j : ℕ) : (s.map (fun z => c*z)).esymm j=c^j*s.esymm j :=
    (Multiset.pow_smul_esymm c j s).symm
  simp only [symmetricQuotient,he,pow_succ]
  field_simp

omit [DecidableEq ι] in
theorem spectralMean_smul (a : ι → ℝ) (k : ℕ) {c : ℝ} (hc : 0<c) :
    spectralMean (fun i => c*a i) k=c*spectralMean a k := by
  rw [spectralMean_eq_quotient,spectralMean_eq_quotient]
  have he : Finset.univ.val.map (fun i => c*a i)=(Finset.univ.val.map a).map (fun z => c*z) := by
    rw [Multiset.map_map]; rfl
  rw [he,symmetricQuotient_smul _ _ hc]
  ring

theorem spectralQuotient_cap_update (a : ι → ℝ) (ha : ∀ i,0<a i) (i : ι) {T : ℝ}
    (hT : 0<T) {k : ℕ} (hk : 1≤k) (hkn : k<Fintype.card ι) :
    (symmetricQuotient (Finset.univ.val.map (Function.update a i T)) k)⁻¹≤
      (symmetricQuotient (Finset.univ.val.map a) k)⁻¹+1/T := by
  have he : Function.update a i (a i)=a := Function.update_eq_self i a
  conv_rhs => rw [← he,spectrum_update_multiset]
  rw [spectrum_update_multiset]
  apply quotient_cap_increment _ _ hk _ (ha i) hT
  · intro w hw; obtain ⟨j,_,rfl⟩ := Multiset.mem_map.mp hw; exact ha j
  · simp only [Multiset.card_map,Finset.card_val,Finset.card_erase_of_mem (Finset.mem_univ i),Finset.card_univ]
    omega

theorem spectralQuotient_cap_telescope (a : ι → ℝ) (ha : ∀ i,0<a i) {T : ℝ}
    (hT : 0<T) {k : ℕ} (hk : 1≤k) (hkn : k<Fintype.card ι) :
    (symmetricQuotient (Finset.univ.val.map (fun i => min (a i) T)) k)⁻¹≤
      (symmetricQuotient (Finset.univ.val.map a) k)⁻¹+
        ((Finset.univ.filter (fun i => T<a i)).card:ℝ)/T := by
  have h := finite_coordinate_bound (fun f => (symmetricQuotient (Finset.univ.val.map f) k)⁻¹)
    a (fun i => min (a i) T) (fun i => if T<a i then 1/T else 0) (by
      intro s i hi
      let f := fun j => if j∈s then min (a j) T else a j
      have hp : ∀ j,0<f j := by intro j; dsimp [f]; split_ifs; exact lt_min (ha j) hT; exact ha j
      have he : f i=a i := by simp [f,hi]
      by_cases ht : T<a i
      · simp only [min_eq_right ht.le,ite_eq_left ht]
        exact spectralQuotient_cap_update f hp i hT hk hkn
      · have hu : Function.update f i (min (a i) T)=f := by
          rw [min_eq_left (le_of_not_gt ht),← he]
          exact Function.update_eq_self i f
        change _≤_+_
        rw [show (fun j => if j∈s then min (a j) T else a j)=f from rfl,hu,ite_eq_right ht,add_zero])
  simpa only [← Finset.sum_filter,Finset.sum_const, nsmul_eq_mul,mul_one_div] using h

end SpectralComparison
