import SpectralComparison.KernelIntegratedTail

/-! Completeness of orthonormal kernel columns and the quantitative whitening transfer. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- An annihilated orthonormal column system of the kernel dimension spans the whole kernel. -/
theorem orthonormal_kernel_range {h p d : Type*} [Fintype h] [Fintype p] [Fintype d]
    [DecidableEq h] [DecidableEq p] [DecidableEq d]
    (H : Matrix h p ℝ) (hH : (H*Hᴴ).PosDef) (U : Matrix p d ℝ)
    (hU : Uᴴ*U=1) (hHU : H*U=0)
    (hd : Fintype.card d+Fintype.card h=Fintype.card p) :
    LinearMap.range U.toEuclideanLin=H.toEuclideanLin.ker := by
  have hi : Function.Injective U.toEuclideanLin := by
    intro x y he
    have he' := congrArg Uᴴ.toEuclideanLin he
    have hcomp : Uᴴ.toEuclideanLin.comp U.toEuclideanLin=LinearMap.id := by
      change (Uᴴ.toLpLin 2 2).comp (U.toLpLin 2 2)=_
      rw [← Matrix.toLpLin_mul_same,hU,Matrix.toLpLin_one]
    change (Uᴴ.toEuclideanLin.comp U.toEuclideanLin) x = (Uᴴ.toEuclideanLin.comp U.toEuclideanLin) y at he'
    simpa only [hcomp,LinearMap.id_apply] using he'
  apply Submodule.eq_of_le_of_finrank_eq
  · rintro y ⟨x,rfl⟩
    change H.toEuclideanLin (U.toEuclideanLin x)=0
    change ((H.toLpLin 2 2).comp (U.toLpLin 2 2)) x=0
    rw [← Matrix.toLpLin_mul_same,hHU]
    simp
  · have hr := LinearMap.finrank_range_of_inj hi
    have hk := kernel_dimension_of_gram_posDef H hH
    simp only [finrank_euclideanSpace] at hr
    omega

/-- Every complete orthonormal kernel basis gives the same literal Schur projector. -/
theorem orthonormal_kernel_projector {h p d : Type*} [Fintype h] [Fintype p] [Fintype d]
    [DecidableEq h] [DecidableEq p] [DecidableEq d]
    (H : Matrix h p ℝ) (hH : (H*Hᴴ).PosDef) (U : Matrix p d ℝ)
    (hU : Uᴴ*U=1) (hHU : H*U=0)
    (hd : Fintype.card d+Fintype.card h=Fintype.card p) :
    U*Uᴴ=1-Hᴴ*(H*Hᴴ)⁻¹*H := by
  have hr := orthonormal_kernel_range H hH U hU hHU hd
  apply Matrix.toEuclideanLin.injective
  apply LinearMap.ext
  intro x
  have hp := congrArg (fun f : EuclideanSpace ℝ p →L[ℝ] EuclideanSpace ℝ p => f x)
    (kernel_projector_eq_starProjection H hH)
  simp only [LinearMap.coe_toContinuousLinearMap'] at hp
  rw [hp]
  symm
  apply Submodule.eq_starProjection_of_mem_of_inner_eq_zero
  · rw [← hr]
    refine ⟨Uᴴ.toEuclideanLin x,?_⟩
    change U.toEuclideanLin (Uᴴ.toEuclideanLin x)=((U*Uᴴ).toLpLin 2 2) x
    rw [Matrix.toLpLin_mul_same]
    rfl
  · intro y hy
    rw [← hr] at hy
    obtain ⟨z,rfl⟩ := hy
    have hcomp : Uᴴ.toEuclideanLin.comp U.toEuclideanLin=LinearMap.id := by
      change (Uᴴ.toLpLin 2 2).comp (U.toLpLin 2 2)=_
      rw [← Matrix.toLpLin_mul_same,hU,Matrix.toLpLin_one]
    change inner ℝ (x-(U*Uᴴ).toEuclideanLin x) (U.toEuclideanLin z)=0
    rw [← LinearMap.adjoint_inner_left,← Matrix.toEuclideanLin_conjTranspose_eq_adjoint,map_sub]
    have he : Uᴴ.toEuclideanLin ((U*Uᴴ).toEuclideanLin x)=Uᴴ.toEuclideanLin x := by
      change ((Uᴴ.toLpLin 2 2).comp ((U*Uᴴ).toLpLin 2 2)) x=(Uᴴ.toLpLin 2 2) x
      rw [← Matrix.toLpLin_mul_same,← Matrix.mul_assoc,hU,Matrix.one_mul]
    rw [he,sub_self,inner_zero_left]

/-- Whitening transfers a kernel-compressed inverse-trace lower bound with the Gram lower constant. -/
theorem whitened_kernel_trace_lower {l p d : Type*} [Fintype l] [Fintype p] [Fintype d]
    [DecidableEq p] [DecidableEq d]
    (X : Matrix l p ℝ) (R : Matrix p d ℝ) (hR : Rᴴ*R=1)
    {S : Matrix p p ℝ} (hS : S.PosDef) {C : Matrix d d ℝ}
    (hC : C.PosDef) (hCC : C*C=(Rᴴ*S*R)⁻¹) {a L : ℝ}
    (ha : 0≤a) (hgap : (S-a • (1 : Matrix p p ℝ)).PosSemidef)
    (htrace : L≤((X*R)ᴴ*(X*R))⁻¹.trace) :
    a*L≤(((X*R)*C)ᴴ*((X*R)*C))⁻¹.trace := by
  rw [inverse_trace_whitened_columns (X*R) hC hCC (orthonormal_compression_posDef hS R hR)]
  exact (mul_le_mul_of_nonneg_left htrace ha).trans
    (trace_product_lower (posSemidef_conjTranspose_mul_self (X*R)).inv (compressed_scalar_lower R hR hgap))

end SpectralComparison
