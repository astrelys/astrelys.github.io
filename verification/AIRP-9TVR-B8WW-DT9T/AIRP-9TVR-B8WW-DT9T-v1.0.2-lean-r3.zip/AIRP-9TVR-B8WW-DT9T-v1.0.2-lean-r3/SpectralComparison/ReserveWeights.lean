import SpectralComparison.BalancedPartition

/-! Reserving the smallest covariance weights without losing too much mass. -/
noncomputable section
namespace SpectralComparison

/-- A set of smallest entries has mean no greater than the whole finite list. -/
theorem smallest_subset_mass_bound {p : ℕ} (d : Fin p → ℝ) (S : Finset (Fin p))
    (hsmall : ∀ i∈S,∀ j∉S,d i≤d j) :
    (p:ℝ)*(∑ i∈S,d i)≤(S.card:ℝ)*∑ i,d i := by
  classical
  let T := Finset.univ \ S
  have hcross : (T.card:ℝ)*(∑ i∈S,d i)≤(S.card:ℝ)*(∑ j∈T,d j) := by
    calc
      (T.card:ℝ)*(∑ i∈S,d i) = ∑ i∈S,∑ _j∈T,d i := by simp [Finset.mul_sum]
      _ ≤ ∑ _i∈S,∑ j∈T,d j := Finset.sum_le_sum (fun i hi => Finset.sum_le_sum (fun j hj => hsmall i hi j (Finset.mem_sdiff.mp hj).2))
      _ = _ := by simp
  have hcard : T.card+S.card=p := by
    have hle := S.card_le_univ
    simp only [Fintype.card_fin] at hle
    simp only [T,Finset.card_sdiff,Finset.card_univ,Fintype.card_fin,Finset.inter_univ]
    omega
  have hcardR : (T.card:ℝ)+(S.card:ℝ)=p := by exact_mod_cast hcard
  have hsum : (∑ j∈T,d j)+(∑ i∈S,d i)=∑ i,d i := by
    rw [Finset.sum_sdiff (Finset.subset_univ S)]
  rw [← hcardR,← hsum]
  nlinarith

/-- The last r entries of a decreasing positive list have the stated cardinality and mass bound. -/
theorem exists_smallest_reserve {p r : ℕ} (hr : 1≤r) (hrp : r≤p)
    (d : Fin p → ℝ) (horder : Antitone d) :
    ∃ S : Finset (Fin p), S.card=r ∧
      (p:ℝ)*(∑ i∈S,d i)≤(r:ℝ)*∑ i,d i := by
  classical
  let a : Fin p := ⟨p-r,by omega⟩
  let S := Finset.Ici a
  have hcard : S.card=r := by simp only [S,Fin.card_Ici,a]; omega
  refine ⟨S,hcard,?_⟩
  rw [← hcard]
  apply smallest_subset_mass_bound
  intro i hi j hj
  have hi' : a ≤ i := Finset.mem_Ici.mp hi
  have hj' : j<a := lt_of_not_ge (fun h => hj (Finset.mem_Ici.mpr h))
  exact horder (hj'.le.trans hi')

/-- For p>8k and 4q<=k, reserving the k+q smallest weights costs strictly less than one quarter. -/
theorem exists_diffuse_reserve {k q p : ℕ} (hk : 1≤k) (hq : 4*q≤k) (hp : 8*k<p)
    (d : Fin p → ℝ) (hd : ∀ i,0<d i) (horder : Antitone d) :
    ∃ S : Finset (Fin p), S.card=k+q ∧
      (∑ i∈S,d i)<(∑ i,d i)/4 ∧
      3*(∑ i,d i)/4<(∑ i∈Finset.univ \ S,d i) := by
  classical
  have hsum : 0<∑ i,d i := Finset.sum_pos (fun i _ => hd i) ⟨⟨0,by omega⟩,Finset.mem_univ _⟩
  obtain ⟨S,hS,hbound⟩ := exists_smallest_reserve (show 1≤k+q by omega) (show k+q≤p by omega) d horder
  have hpR : (0:ℝ)<p := by exact_mod_cast (show 0<p by omega)
  have hdim : (4:ℝ)*(k+q)<p := by exact_mod_cast (show 4*(k+q)<p by omega)
  have hmass : (∑ i∈S,d i)<(∑ i,d i)/4 := by
    have hstrict := mul_lt_mul_of_pos_right hdim hsum
    norm_num only [Nat.cast_add] at hbound
    nlinarith
  refine ⟨S,hS,hmass,?_⟩
  have hh := Finset.sum_sdiff (f:=d) (Finset.subset_univ S)
  linarith

end SpectralComparison
