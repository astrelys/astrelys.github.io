import SpectralComparison.GaussianSchur
import SpectralComparison.GaussianProjection

/-! Exact kernel projection and finite-dimensional orthonormal coordinates. -/
noncomputable section
open Matrix
open scoped RealInnerProductSpace
namespace SpectralComparison

set_option maxHeartbeats 1000000 in
/-- The literal Schur residual is the orthogonal projector onto the row block's kernel. -/
theorem kernel_projector_eq_starProjection {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p] (B : Matrix n p ℝ) (hB : (B*Bᴴ).PosDef) :
    (1-Bᴴ*(B*Bᴴ)⁻¹*B).toEuclideanLin.toContinuousLinearMap =
      B.toEuclideanLin.ker.starProjection := by
  apply ContinuousLinearMap.ext
  intro x
  simp only [LinearMap.coe_toContinuousLinearMap']
  symm
  apply Submodule.eq_starProjection_of_mem_of_inner_eq_zero
  · change B.toEuclideanLin ((1-Bᴴ*(B*Bᴴ)⁻¹*B).toEuclideanLin x) = 0
    change ((B.toLpLin 2 2).comp ((1-Bᴴ*(B*Bᴴ)⁻¹*B).toLpLin 2 2)) x = 0
    rw [← Matrix.toLpLin_mul_same, kernel_projector_annihilates B hB]
    simp
  · intro y hy
    have hy0 : B.toEuclideanLin y = 0 := hy
    have he : x - (1-Bᴴ*(B*Bᴴ)⁻¹*B).toEuclideanLin x =
        Bᴴ.toEuclideanLin (((B*Bᴴ)⁻¹*B).toEuclideanLin x) := by
      simp only [Matrix.toEuclideanLin, map_sub, LinearMap.sub_apply, Matrix.toLpLin_one,
        LinearMap.id_apply, sub_sub_cancel]
      rw [Matrix.mul_assoc, Matrix.toLpLin_mul_same]
      rfl
    rw [he, Matrix.toEuclideanLin_conjTranspose_eq_adjoint, LinearMap.adjoint_inner_left, hy0]
    simp

/-- The expected kernel dimension follows from the literal right inverse of a full-row-rank block. -/
theorem kernel_dimension_of_gram_posDef {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p] (B : Matrix n p ℝ) (hB : (B*Bᴴ).PosDef) :
    Module.finrank ℝ B.toEuclideanLin.ker + Fintype.card n = Fintype.card p := by
  let _ : Invertible (B*Bᴴ) := hB.isUnit.invertible
  have hsurj : Function.Surjective B.toEuclideanLin := by
    intro y
    refine ⟨(Bᴴ*(B*Bᴴ)⁻¹).toEuclideanLin y, ?_⟩
    change ((B.toLpLin 2 2).comp ((Bᴴ*(B*Bᴴ)⁻¹).toLpLin 2 2)) y = y
    rw [← Matrix.toLpLin_mul_same, ← Matrix.mul_assoc, Matrix.mul_inv_of_invertible,
      Matrix.toLpLin_one]
    rfl
  have h := B.toEuclideanLin.finrank_range_add_finrank_ker
  rw [LinearMap.range_eq_top.mpr hsurj] at h
  simpa [add_comm] using h

/-- Every finite-dimensional subspace has orthonormal coordinates whose adjoint
implements its orthogonal projection. This is pointwise existence, not a measurable
choice of bases over a family of subspaces. -/
theorem exists_subspace_orthonormal_coordinates {E : Type*}
    [NormedAddCommGroup E] [InnerProductSpace ℝ E] [FiniteDimensional ℝ E]
    (K : Submodule ℝ E) :
    ∃ f : EuclideanSpace ℝ (Fin (Module.finrank ℝ K)) →ₗᵢ[ℝ] E,
      LinearMap.range f.toLinearMap = K ∧
      ∀ x, f (f.toContinuousLinearMap.adjoint x) = K.starProjection x := by
  let b := stdOrthonormalBasis ℝ K
  let f := K.subtypeₗᵢ.comp b.repr.symm.toLinearIsometry
  have hmem (z : EuclideanSpace ℝ (Fin (Module.finrank ℝ K))) : f z ∈ K :=
    (b.repr.symm z).property
  have hsurj (y : E) (hy : y ∈ K) : ∃ z, f z = y := by
    refine ⟨b.repr ⟨y,hy⟩, ?_⟩
    simp [f]
  refine ⟨f, ?_, ?_⟩
  · apply le_antisymm
    · rintro y ⟨z,rfl⟩
      exact hmem z
    · intro y hy
      exact hsurj y hy
  · intro x
    symm
    apply Submodule.eq_starProjection_of_mem_of_inner_eq_zero (hmem _)
    intro y hy
    obtain ⟨z,rfl⟩ := hsurj y hy
    rw [inner_sub_left, f.inner_map_map, ContinuousLinearMap.adjoint_inner_left]
    simp

/-- The kernel-coordinate projection agrees exactly with the Schur residual matrix. -/
theorem exists_kernel_orthonormal_coordinates {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p] (B : Matrix n p ℝ) (hB : (B*Bᴴ).PosDef) :
    ∃ f : EuclideanSpace ℝ (Fin (Module.finrank ℝ B.toEuclideanLin.ker)) →ₗᵢ[ℝ]
        EuclideanSpace ℝ p,
      LinearMap.range f.toLinearMap = B.toEuclideanLin.ker ∧
      ∀ x, f (f.toContinuousLinearMap.adjoint x) =
        (1-Bᴴ*(B*Bᴴ)⁻¹*B).toEuclideanLin x := by
  obtain ⟨f,hf,hproj⟩ := exists_subspace_orthonormal_coordinates B.toEuclideanLin.ker
  refine ⟨f,hf,fun x => ?_⟩
  rw [hproj, ← kernel_projector_eq_starProjection B hB]
  rfl

set_option maxHeartbeats 1000000 in
/-- A literal orthonormal kernel-basis matrix with the exact projector identity.
The dimension is expressed as finrank(kernel); kernel_dimension_of_gram_posDef gives p-n. -/
theorem exists_kernel_basis_matrix {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p] (B : Matrix n p ℝ) (hB : (B*Bᴴ).PosDef) :
    ∃ R : Matrix p (Fin (Module.finrank ℝ B.toEuclideanLin.ker)) ℝ,
      Rᴴ*R = 1 ∧ R*Rᴴ = 1-Bᴴ*(B*Bᴴ)⁻¹*B := by
  obtain ⟨f,_hf,hproj⟩ := exists_kernel_orthonormal_coordinates B hB
  let R := Matrix.toEuclideanLin.symm f.toLinearMap
  have hR : R.toEuclideanLin = f.toLinearMap := Matrix.toEuclideanLin.apply_symm_apply _
  have hRa : Rᴴ.toEuclideanLin = f.toLinearMap.adjoint := by
    rw [Matrix.toEuclideanLin_conjTranspose_eq_adjoint, hR]
  refine ⟨R,?_,?_⟩
  · apply Matrix.toEuclideanLin.injective
    change (Rᴴ*R).toLpLin 2 2 = (1 : Matrix _ _ ℝ).toLpLin 2 2
    rw [Matrix.toLpLin_mul_same, Matrix.toLpLin_one]
    change Rᴴ.toEuclideanLin.comp R.toEuclideanLin = LinearMap.id
    rw [hR,hRa]
    exact f.adjoint_comp_self'
  · apply Matrix.toEuclideanLin.injective
    apply LinearMap.ext
    intro x
    change ((R*Rᴴ).toLpLin 2 2) x = _
    rw [Matrix.toLpLin_mul_same]
    change R.toEuclideanLin (Rᴴ.toEuclideanLin x) = _
    rw [hR,hRa, LinearMap.adjoint_eq_toCLM_adjoint]
    exact hproj x

/-- The complete deterministic kernel-basis and inverse-block step for a row partition. -/
theorem exists_inverse_gram_kernel_coordinates {m n p : Type*}
    [Fintype m] [Fintype n] [Fintype p] [DecidableEq m] [DecidableEq n] [DecidableEq p]
    (U : Matrix m p ℝ) (B : Matrix n p ℝ)
    (hG : ((Matrix.fromRows U B)*(Matrix.fromRows U B)ᴴ).PosDef) :
    ∃ R : Matrix p (Fin (Module.finrank ℝ B.toEuclideanLin.ker)) ℝ,
      Rᴴ*R = 1 ∧
      Module.finrank ℝ B.toEuclideanLin.ker + Fintype.card n = Fintype.card p ∧
      (((Matrix.fromRows U B)*(Matrix.fromRows U B)ᴴ)⁻¹).submatrix Sum.inl Sum.inl =
        ((U*R)*(U*R)ᴴ)⁻¹ := by
  have he : Matrix.fromRows U B * (Matrix.fromRows U B)ᴴ =
      Matrix.fromBlocks (U*Uᴴ) (U*Bᴴ) (B*Uᴴ) (B*Bᴴ) := by
    rw [Matrix.conjTranspose_fromRows_eq_fromCols_conjTranspose, Matrix.fromRows_mul_fromCols]
  have hB : (B*Bᴴ).PosDef := by
    rw [he] at hG
    exact hG.submatrix Sum.inr_injective
  obtain ⟨R,hR,hRR⟩ := exists_kernel_basis_matrix B hB
  refine ⟨R,hR,kernel_dimension_of_gram_posDef B hB,?_⟩
  rw [inverse_gram_upper_block U B hG, ← hRR, Matrix.conjTranspose_mul]
  simp only [Matrix.mul_assoc]

end SpectralComparison
