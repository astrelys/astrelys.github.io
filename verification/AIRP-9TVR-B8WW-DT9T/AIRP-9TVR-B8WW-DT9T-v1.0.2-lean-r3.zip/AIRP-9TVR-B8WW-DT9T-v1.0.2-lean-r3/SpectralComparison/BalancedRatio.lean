import SpectralComparison.EsymmDuality
import SpectralComparison.MainTheorem

/-! Three noise regimes for the balanced two-level finite-noise comparison. -/
noncomputable section
namespace SpectralComparison

/-- Transfer a linear-in-noise upper bound across the ridge lower bound. -/
theorem ridge_linear_comparison {s L x y z : ℝ} (hs : 0<s) (hL : 0<L) (hz : 0≤z)
    (hx : s*L/(1+s*L)≤x) (hy : y≤z*s) : y≤z*(1/L+s)*x := by
  have hd : 0<1+s*L := by positivity
  have hh := mul_le_mul_of_nonneg_left ((div_le_iff₀ hd).mp hx) (div_nonneg hz hL.le)
  have he1 : (z/L)*(s*L)=z*s := by field_simp
  have he2 : (z/L)*(x*(1+s*L))=z*(1/L+s)*x := by field_simp
  rw [he1,he2] at hh
  exact hy.trans hh

/-- The paper's three-regime estimate, stated with sqrt(epsilon) as t. -/
theorem balanced_noise_comparison {a L t x y : ℝ} (ha : 1≤a) (hL : 0<L) (ht : 0<t)
    (hxdiag : a*t^2≤x) (hxridge : t^2*L/(1+t^2*L)≤x)
    (hylinear : y≤(a+1)*a*t^2) (hysqrt : y≤(a+1)*t) :
    y≤(a+1)*(a/L+1/Real.sqrt a)*x := by
  have ha0 : 0<a := by linarith
  have hr : 0<Real.sqrt a := Real.sqrt_pos.mpr ha0
  have hrsq := Real.sq_sqrt ha0.le
  have hx : 0≤x := (by positivity : (0:ℝ)≤a*t^2).trans hxdiag
  have hroot : Real.sqrt a≤a := by nlinarith [Real.sqrt_nonneg a]
  by_cases hsmall : a*t≤1
  · have hh := ridge_linear_comparison (sq_pos_of_pos ht) hL (by positivity : (0:ℝ)≤(a+1)*a) hxridge hylinear
    have hsq : (a*t)^2≤1 := by nlinarith [mul_pos ha0 ht]
    have hmul := mul_le_mul_of_nonneg_left hroot (by positivity : (0:ℝ)≤a*t^2)
    have he : a*t^2≤1/Real.sqrt a := (le_div_iff₀ hr).mpr (by nlinarith)
    have hc : (a+1)*a*(1/L+t^2)≤(a+1)*(a/L+1/Real.sqrt a) := by
      simp only [div_eq_mul_inv,one_mul] at he ⊢
      nlinarith
    exact hh.trans (mul_le_mul_of_nonneg_right hc hx)
  · by_cases hmid : Real.sqrt a*t≤1
    · have hy : y≤((a+1)/t)*t^2 := by
        convert hysqrt using 1; field_simp
      have hh := ridge_linear_comparison (sq_pos_of_pos ht) hL (by positivity : (0:ℝ)≤(a+1)/t) hxridge hy
      have he : t≤1/Real.sqrt a := (le_div_iff₀ hr).mpr (by nlinarith)
      have hd : 1/(L*t)≤a/L := by
        apply (div_le_div_iff₀ (mul_pos hL ht) hL).mpr
        nlinarith
      have hcoef : ((a+1)/t)*(1/L+t^2)=(a+1)*(1/(L*t)+t) := by field_simp
      rw [hcoef] at hh
      have hc : (a+1)*(1/(L*t)+t)≤(a+1)*(a/L+1/Real.sqrt a) := by nlinarith
      exact hh.trans (mul_le_mul_of_nonneg_right hc hx)
    · have hz : Real.sqrt a*t≤(Real.sqrt a*t)^2 := by nlinarith
      rw [mul_pow,hrsq] at hz
      have he : t≤(1/Real.sqrt a)*(a*t^2) := by
        rw [one_div,mul_comm,← div_eq_mul_inv]
        exact (le_div_iff₀ hr).mpr (by nlinarith)
      have h1 : y≤((a+1)/Real.sqrt a)*x := by
        have hh := mul_le_mul_of_nonneg_left he (by positivity : (0:ℝ)≤a+1)
        have hd := mul_le_mul_of_nonneg_left hxdiag (by positivity : (0:ℝ)≤(a+1)/Real.sqrt a)
        simp only [div_eq_mul_inv,one_mul] at hh hd ⊢
        nlinarith
      have hc : (a+1)/Real.sqrt a≤(a+1)*(a/L+1/Real.sqrt a) := by
        have : 0≤(a+1)*(a/L) := by positivity
        simp only [div_eq_mul_inv,one_mul] at this ⊢
        nlinarith
      exact h1.trans (mul_le_mul_of_nonneg_right hc hx)

/-- Equation (A.3), with the original finite-noise constant, for every 0<epsilon<=1. -/
theorem paper_two_level_finite {k : ℕ} (hk : 4≤k) {ε : ℝ} (hε : 0<ε) (hε1 : ε≤1) :
    worstError (twoLevelSpectrum k k ε) k≤spectralMean (twoLevelSpectrum k k ε) k ∧
    spectralMean (twoLevelSpectrum k k ε) k≤
      ((4000000000+1:ℝ)*((k:ℝ)+1)/Real.sqrt k)*worstError (twoLevelSpectrum k k ε) k := by
  have hk0 : (0:ℝ)<k := by exact_mod_cast (by omega : 0<k)
  have hl := balanced_two_level_worst_lower hk hε hε1
  have hy := two_level_tail_bounds (k:=k) (by omega : 1≤k) hε hε1
  have hs := balanced_spectralMean_sqrt (by omega : 1≤k) hε
  let L := (k:ℝ)*Real.sqrt k/4000000000
  have hL : 0<L := by dsimp [L]; positivity
  have hh := balanced_noise_comparison (a:=(k:ℝ)) (L:=L) (t:=Real.sqrt ε)
    (by exact_mod_cast (by omega : 1≤k)) hL (Real.sqrt_pos.mpr hε)
    (by simpa only [Real.sq_sqrt hε.le] using hy.1)
    (by simpa only [Real.sq_sqrt hε.le] using le_trans (le_max_right _ _) hl)
    (by simpa only [Real.sq_sqrt hε.le,mul_assoc] using hy.2) hs
  have he : ((k:ℝ)+1)*((k:ℝ)/L+1/Real.sqrt k)=(4000000000+1:ℝ)*((k:ℝ)+1)/Real.sqrt k := by
    dsimp [L]
    field_simp
  rw [he] at hh
  exact ⟨worstError_le_spectralMean _ (twoLevelSpectrum_pos hε) (by simp; omega),hh⟩

end SpectralComparison
