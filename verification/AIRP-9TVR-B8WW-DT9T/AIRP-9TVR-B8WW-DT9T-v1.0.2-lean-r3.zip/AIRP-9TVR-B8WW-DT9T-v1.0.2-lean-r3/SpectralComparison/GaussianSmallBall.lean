import SpectralComparison.GaussianNets

/-! A quantitative small-ball net with the manuscript's D=10^12. -/
noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

/-- The fixed-vector lower tail at 4p/D^2, in a convenient integral-power form. -/
theorem gaussian_vector_small_ball {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {N p : ℕ}
    (G : Ω → Matrix (Fin N) (Fin p) ℝ)
    (hG : ∀ a : Fin N × Fin p, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin N × Fin p => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : Fin N × Fin p, Measurable (fun ω => G ω a.1 a.2))
    (v : EuclideanSpace ℝ (Fin p)) (hv : ‖v‖=1) {D : ℝ} (hD : 0 < D) :
    μ.real {ω | ‖(G ω).toEuclideanLin v‖^2 ≤ 4*(p:ℝ)/D^2} ≤
      Real.exp (p:ℝ)*(2/D)^N := by
  have h := gaussian_vector_norm_lower G hG hind hm v hv (4*(p:ℝ)/D^2) (-D^2/4) (by nlinarith [sq_nonneg D])
  have ha : -(-D^2/4)*(4*(p:ℝ)/D^2) = p := by field_simp
  have hx : 0 ≤ 1+D^2/2 := by positivity
  have hr : (1-2*(-D^2/4))^(-(Fintype.card (Fin N):ℝ)/2) =
      ((Real.sqrt (1+D^2/2))⁻¹)^N := by
    rw [show 1-2*(-D^2/4) = 1+D^2/2 by ring, Fintype.card_fin,
      show -(N:ℝ)/2 = -((1/2:ℝ)*(N:ℝ)) by ring,
      Real.rpow_neg hx, Real.rpow_mul hx, Real.rpow_natCast, ← Real.sqrt_eq_rpow, inv_pow]
  rw [ha,hr] at h
  have hs : (Real.sqrt (1+D^2/2))⁻¹ ≤ 2/D := by
    have hroot : D/2 ≤ Real.sqrt (1+D^2/2) := by
      nlinarith [Real.sq_sqrt hx, Real.sqrt_nonneg (1+D^2/2)]
    rw [← one_div]
    apply (div_le_div_iff₀ (Real.sqrt_pos.mpr (by positivity)) hD).mpr
    linarith
  exact h.trans (mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (by positivity) hs N) (by positivity))

/-- The numerical estimate underlying (4.3). Cubing avoids fractional-exponent rounding. -/
theorem small_ball_net_numeric {N p : ℕ} (hN : 4*p ≤ 3*N) :
    ((41:ℝ)*1000000000000)^p * Real.exp (p:ℝ) * (2/1000000000000:ℝ)^N ≤ (1/16:ℝ)^p := by
  have he : Real.exp (p:ℝ) ≤ (3:ℝ)^p := by
    rw [show (p:ℝ) = (p:ℝ)*1 by ring, Real.exp_nat_mul]
    exact pow_le_pow_left₀ (by positivity) Real.exp_one_lt_three.le p
  have hfirst : ((41:ℝ)*1000000000000)^p * Real.exp (p:ℝ) * (2/1000000000000:ℝ)^N ≤
      (123*1000000000000:ℝ)^p * (2/1000000000000:ℝ)^N := by
    calc
      _ ≤ ((41:ℝ)*1000000000000)^p * (3:ℝ)^p * (2/1000000000000:ℝ)^N := by gcongr
      _ = _ := by rw [← mul_pow]; norm_num
  apply hfirst.trans
  apply le_of_pow_le_pow_left₀ (n := 3) (by norm_num) (by positivity)
  calc
    ((123*1000000000000:ℝ)^p * (2/1000000000000:ℝ)^N)^3 =
      (123*1000000000000:ℝ)^(3*p)*(2/1000000000000:ℝ)^(3*N) := by
        simp only [mul_pow, ← pow_mul, Nat.mul_comm]
    _ ≤ (123*1000000000000:ℝ)^(3*p)*(2/1000000000000:ℝ)^(4*p) :=
      mul_le_mul_of_nonneg_left (pow_le_pow_of_le_one (by norm_num) (by norm_num) hN) (by positivity)
    _ = ((123*1000000000000:ℝ)^3*(2/1000000000000:ℝ)^4)^p := by simp only [mul_pow, pow_mul]
    _ ≤ ((1/16:ℝ)^3)^p := pow_le_pow_left₀ (by positivity) (by norm_num) p
    _ = ((1/16:ℝ)^p)^3 := by simp only [← pow_mul, Nat.mul_comm]

/-- A concrete fine net for which the small-ball union event has probability at most 16^-p. -/
theorem exists_gaussian_small_ball_net {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {N p : ℕ} (hN : 4*p ≤ 3*N)
    (G : Ω → Matrix (Fin N) (Fin p) ℝ)
    (hG : ∀ a : Fin N × Fin p, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin N × Fin p => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : Fin N × Fin p, Measurable (fun ω => G ω a.1 a.2)) :
    ∃ s : Finset (EuclideanSpace ℝ (Fin p)), (∀ v ∈ s, ‖v‖=1) ∧
      (s.card:ℝ) ≤ (41*1000000000000:ℝ)^p ∧
      (∀ x : EuclideanSpace ℝ (Fin p), ‖x‖=1 → ∃ v ∈ s, ‖x-v‖ ≤ 1/(20*1000000000000:ℝ)) ∧
      μ.real {ω | ∃ v ∈ s, ‖(G ω).toEuclideanLin v‖^2 ≤ 4*(p:ℝ)/(1000000000000:ℝ)^2} ≤
        (1/16:ℝ)^p := by
  obtain ⟨s,hs,hcard,hnet⟩ := exists_sphere_net_card_le (E := EuclideanSpace ℝ (Fin p))
    (η := 1/(20*1000000000000:ℝ)) (by norm_num)
  have hc : (s.card:ℝ) ≤ (41*1000000000000:ℝ)^p := by
    apply hcard.trans
    simp only [finrank_euclideanSpace, Fintype.card_fin]
    exact pow_le_pow_left₀ (by norm_num) (by norm_num) p
  refine ⟨s,hs,hc,hnet,?_⟩
  have h := finite_union_probability_bound s
    (fun v => {ω | ‖(G ω).toEuclideanLin v‖^2 ≤ 4*(p:ℝ)/(1000000000000:ℝ)^2})
    (fun v hv => gaussian_vector_small_ball G hG hind hm v (hs v hv) (by norm_num))
  apply h.trans
  calc
    _ ≤ (41*1000000000000:ℝ)^p * (Real.exp (p:ℝ)*(2/1000000000000:ℝ)^N) := by gcongr
    _ = (41*1000000000000:ℝ)^p * Real.exp (p:ℝ)*(2/1000000000000:ℝ)^N := by ring
    _ ≤ _ := small_ball_net_numeric hN

/-- The fine-net complement and the upper operator-norm event imply a lower singular bound. -/
theorem gaussian_net_lower_singular {N p : ℕ} (G : Matrix (Fin N) (Fin p) ℝ)
    (s : Finset (EuclideanSpace ℝ (Fin p)))
    (hnet : ∀ x : EuclideanSpace ℝ (Fin p), ‖x‖=1 → ∃ v ∈ s, ‖x-v‖ ≤ 1/(20*1000000000000:ℝ))
    (hupper : ‖G.toEuclideanLin.toContinuousLinearMap‖ ≤ 10*Real.sqrt p)
    (hlower : ∀ v ∈ s, 4*(p:ℝ)/(1000000000000:ℝ)^2 < ‖G.toEuclideanLin v‖^2) :
    ∀ x : EuclideanSpace ℝ (Fin p), ‖x‖=1 → Real.sqrt p/1000000000000 ≤ ‖G.toEuclideanLin x‖ := by
  have hb (v) (hv : v ∈ s) : 2*Real.sqrt (p:ℝ)/1000000000000 ≤ ‖G.toEuclideanLin v‖ := by
    nlinarith [hlower v hv, Real.sq_sqrt (Nat.cast_nonneg p), norm_nonneg (G.toEuclideanLin v), Real.sqrt_nonneg (p:ℝ)]
  have h := norm_lower_of_sphere_net G.toEuclideanLin.toContinuousLinearMap s (by norm_num) hupper hnet hb
  intro x hx
  have hh := h x hx
  change _ ≤ ‖G.toEuclideanLin x‖ at hh
  nlinarith [Real.sqrt_nonneg (p:ℝ)]

end SpectralComparison
