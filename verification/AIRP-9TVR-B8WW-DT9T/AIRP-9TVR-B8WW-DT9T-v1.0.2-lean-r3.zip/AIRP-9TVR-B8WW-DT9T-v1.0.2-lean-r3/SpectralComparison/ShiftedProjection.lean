import SpectralComparison.ShiftedRealization

noncomputable section
open Matrix
namespace SpectralComparison

/-- The stronger normalization for balanced shifted ranks, with the exact 10^23 constant. -/
theorem exists_shifted_parseval_frame {k q : ℕ} (hk : 4≤k) (hq : 2*q≤k) :
    ∃ Q : Matrix (Fin (2*k)) (Fin (k+q)) ℝ, Qᴴ*Q=1 ∧
      ∀ J : Finset (Fin (2*k)), J.card=k →
        ((Q*Qᴴ).submatrix (fun i : J => (i : Fin (2*k))) (fun i : J => (i : Fin (2*k)))).PosDef ∧
        (k:ℝ)^2/(100000000000000000000000*((q:ℝ)+Real.sqrt k)) ≤
        ((Q*Qᴴ).submatrix (fun i : J => (i : Fin (2*k))) (fun i : J => (i : Fin (2*k))))⁻¹.trace := by
  obtain ⟨G,_,hlower,hrows⟩ := exists_shifted_good_matrix hk hq
  have hk0 : (0:ℝ)<k := by exact_mod_cast (show 0<k by omega)
  have hp0 : (0:ℝ)<(k+q:ℕ) := by exact_mod_cast (show 0<k+q by omega)
  have hs : 0<Real.sqrt (k+q:ℕ) := Real.sqrt_pos.mpr hp0
  have hden : 0<(q:ℝ)+Real.sqrt k := add_pos_of_nonneg_of_pos (Nat.cast_nonneg _) (Real.sqrt_pos.mpr hk0)
  have hG := gram_posDef_of_unit_norm G (div_pos hs (by norm_num)) hlower
  have hgap : (Gᴴ*G-((k+q:ℕ)/100000000000000000000:ℝ) • (1 : Matrix (Fin (k+q)) (Fin (k+q)) ℝ)).PosSemidef := by
    have h := gram_lower_of_unit_norm G (by positivity : (0:ℝ) ≤ Real.sqrt (k+q:ℕ)/10000000000) hlower
    have he : (Real.sqrt (k+q:ℕ)/10000000000)^2=(k+q:ℕ)/100000000000000000000 := by
      rw [div_pow,Real.sq_sqrt hp0.le]; norm_num
    rwa [he] at h
  obtain ⟨Q,hQ,hproj⟩ := exists_gram_whitening G hG
  refine ⟨Q,hQ,?_⟩
  intro J hJ
  let e : J → Fin (2*k) := fun i => i
  have ht := hrows J hJ
  have hp : (G.submatrix e id*(G.submatrix e id)ᴴ).PosDef :=
    posDef_of_pos_inverse_trace (posSemidef_self_mul_conjTranspose _) ((div_pos hk0 (mul_pos (by norm_num) hden)).trans ht)
  have hblock := whitening_row_posDef G Q hG hproj e hp
  refine ⟨hblock,?_⟩
  have he : (G*Gᴴ).submatrix e e = G.submatrix e id*(G.submatrix e id)ᴴ := by
    ext i j; simp [Matrix.mul_apply]
  have hh := whitening_inverse_trace_lower (L := (k:ℝ)/(1000*((q:ℝ)+Real.sqrt k))) G Q hG hproj
    (div_pos hp0 (by norm_num)) hgap e hblock (by rw [he]; exact ht.le)
  apply le_trans _ hh
  have hn : (k:ℝ)≤(k+q:ℕ) := by simp only [Nat.cast_add]; exact le_add_of_nonneg_right (Nat.cast_nonneg _)
  apply (div_le_iff₀ (by positivity : (0:ℝ)<100000000000000000000000*((q:ℝ)+Real.sqrt k))).mpr
  have heq : ((k+q:ℕ)/100000000000000000000:ℝ)*((k:ℝ)/(1000*((q:ℝ)+Real.sqrt k)))*(100000000000000000000000*((q:ℝ)+Real.sqrt k))=(k+q:ℕ)*(k:ℝ) := by field_simp; ring
  rw [heq]
  nlinarith

/-- First assertion of C0014: a literal orthogonal projection of rank k+q and all principal bounds. -/
theorem paper_shifted_projection {k q : ℕ} (hk : 4≤k) (hq : 2*q≤k) :
    ∃ P : Matrix (Fin (2*k)) (Fin (2*k)) ℝ, P.IsHermitian ∧ P*P=P ∧ P.rank=k+q ∧
      ∀ J : Finset (Fin (2*k)), J.card=k → (principal P J).PosDef ∧
        (k:ℝ)^2/(100000000000000000000000*((q:ℝ)+Real.sqrt k))≤(principal P J)⁻¹.trace := by
  obtain ⟨Q,hQ,hblocks⟩ := exists_shifted_parseval_frame hk hq
  obtain ⟨hP,hPP,hr⟩ := frame_projection_properties Q hQ
  exact ⟨Q*Qᴴ,hP,hPP,by simpa using hr,hblocks⟩

end SpectralComparison
