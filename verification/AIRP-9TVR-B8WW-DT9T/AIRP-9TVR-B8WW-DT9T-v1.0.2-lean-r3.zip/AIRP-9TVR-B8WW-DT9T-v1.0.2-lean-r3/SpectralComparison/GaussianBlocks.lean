import SpectralComparison.GaussianFiber

/-! Exact row-block product laws and measurable matrix statistics. -/
noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

/-- Coordinate marginals of a product Gaussian law. -/
theorem gaussian_product_entry_hasLaw {Ω ι : Type*} [MeasurableSpace Ω] [Fintype ι]
    {μ : Measure Ω} (X : Ω → (ι → ℝ))
    (hX : HasLaw X (Measure.pi (fun _ : ι => gaussianReal 0 1)) μ) (i : ι) :
    HasLaw (fun ω => X ω i) (gaussianReal 0 1) μ := by
  have h : HasLaw (fun x : ι → ℝ => x i) (gaussianReal 0 1)
      (Measure.pi (fun _ : ι => gaussianReal 0 1)) :=
    ⟨(measurable_pi_apply i).aemeasurable, (measurePreserving_eval _ i).map_eq⟩
  exact h.fun_comp hX

/-- Joint product law implies independence of all entries. -/
theorem gaussian_product_independent {Ω ι : Type*} [MeasurableSpace Ω] [Fintype ι]
    {μ : Measure Ω} [IsProbabilityMeasure μ] (X : Ω → (ι → ℝ))
    (hX : HasLaw X (Measure.pi (fun _ : ι => gaussianReal 0 1)) μ) :
    iIndepFun (fun i ω => X ω i) μ := by
  exact (iIndepFun_iff_hasLaw_pi_pi (X := fun i ω => X ω i)
    (μ := fun _ : ι => gaussianReal 0 1) (gaussian_product_entry_hasLaw X hX)).mpr hX

/-- Splitting independent Gaussian entries into two row blocks gives their product law. -/
theorem gaussian_row_blocks_hasLaw {Ω m n p : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype m] [Fintype n] [Fintype p]
    (W : Ω → Matrix (m ⊕ n) p ℝ)
    (hW : ∀ a : (m ⊕ n) × p, HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : (m ⊕ n) × p => fun ω => W ω a.1 a.2) μ) :
    HasLaw (fun ω => ((fun a : m × p => W ω (Sum.inl a.1) a.2),
      (fun a : n × p => W ω (Sum.inr a.1) a.2)))
      ((Measure.pi (fun _ : m × p => gaussianReal 0 1)).prod
       (Measure.pi (fun _ : n × p => gaussianReal 0 1))) μ := by
  let e := Equiv.sumProdDistrib m n p
  have hs := (hind.precomp e.symm.injective).hasLaw_pi (fun a => hW (e.symm a))
  have hp : HasLaw (MeasurableEquiv.sumPiEquivProdPi (fun _ : (m × p) ⊕ (n × p) => ℝ))
      ((Measure.pi (fun _ : m × p => gaussianReal 0 1)).prod
       (Measure.pi (fun _ : n × p => gaussianReal 0 1)))
      (Measure.pi (fun _ : (m × p) ⊕ (n × p) => gaussianReal 0 1)) :=
    ⟨(MeasurableEquiv.sumPiEquivProdPi _).measurable.aemeasurable,
      (measurePreserving_sumPiEquivProdPi _).map_eq⟩
  exact hp.fun_comp hs

/-- Assembling two independently sampled Gaussian row blocks gives the full entry law. -/
theorem gaussian_fromRows_hasLaw {m n p : Type*} [Fintype m] [Fintype n] [Fintype p] :
    HasLaw (fun z : (m × p → ℝ) × (n × p → ℝ) => fun a : (m ⊕ n) × p =>
      (Matrix.fromRows (Matrix.of (fun i j => z.1 (i,j)))
        (Matrix.of (fun i j => z.2 (i,j)))) a.1 a.2)
      (Measure.pi (fun _ : (m ⊕ n) × p => gaussianReal 0 1))
      ((Measure.pi (fun _ : m × p => gaussianReal 0 1)).prod
       (Measure.pi (fun _ : n × p => gaussianReal 0 1))) := by
  let e := Equiv.sumProdDistrib m n p
  have h1 := measurePreserving_sumPiEquivProdPi_symm
    (fun _ : (m × p) ⊕ (n × p) => gaussianReal 0 1)
  have h2 := measurePreserving_piCongrLeft (fun _ : (m ⊕ n) × p => gaussianReal 0 1) e.symm
  have hh : HasLaw _ _ _ := ⟨(h2.comp h1).measurable.aemeasurable, (h2.comp h1).map_eq⟩
  convert hh using 1
  funext z a
  rcases a with ⟨i,j⟩
  cases i <;> rfl

/-- The inverse-Gram diagonal remains measurable after any measurable entry map. -/
theorem measurable_inverse_gram_diagonal_of_entries {Ω m p : Type*} [MeasurableSpace Ω]
    [Fintype m] [Fintype p] [DecidableEq m] (W : Ω → Matrix m p ℝ)
    (hW : ∀ a : m × p, Measurable (fun ω => W ω a.1 a.2)) (i : m) :
    Measurable (fun ω => (W ω*(W ω)ᴴ)⁻¹ i i) := by
  have hm : Measurable (fun ω (a : m × p) => W ω a.1 a.2) := measurable_pi_iff.mpr hW
  have hh := (measurable_inverse_gram_diagonal i (κ := p)).comp hm
  convert hh using 1
  funext ω
  have he : Matrix.of (fun a b => W ω a b) = W ω := by ext a b; rfl
  dsimp only [Function.comp_def]
  rw [he]

/-- Gram positive definiteness is a measurable event, including singular inputs. -/
theorem measurableSet_gram_posDef {Ω m p : Type*} [MeasurableSpace Ω]
    [Fintype m] [Fintype p] [DecidableEq m] (W : Ω → Matrix m p ℝ)
    (hW : ∀ a : m × p, Measurable (fun ω => W ω a.1 a.2)) :
    MeasurableSet {ω | (W ω*(W ω)ᴴ).PosDef} := by
  have hg : Measurable (fun ω => W ω*(W ω)ᴴ) := by
    apply Measurable.of_eval_matrix
    intro i j
    simp only [Matrix.mul_apply, Matrix.conjTranspose_apply, star_trivial]
    exact Finset.measurable_sum _ (fun k _ => (hW (i,k)).mul (hW (j,k)))
  have hd := continuous_id.matrix_det.measurable.comp hg
  have he : {ω | (W ω*(W ω)ᴴ).PosDef} = {ω | (W ω*(W ω)ᴴ).det ≠ 0} := by
    ext ω
    exact (Matrix.posSemidef_self_mul_conjTranspose (W ω)).posDef_iff_det_ne_zero
  rw [he]
  exact (measurableSet_eq_fun hd measurable_const).compl

end SpectralComparison
