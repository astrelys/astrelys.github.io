import SpectralComparison.ProjectionBase

/-! Reindexing and normalized row replication for the uniform projection construction. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Finset-indexed principal-block control also applies to an arbitrary finite injective index map. -/
theorem principal_inverse_trace_embedding {n j : Type*} [Fintype n] [DecidableEq n]
    [Fintype j] [DecidableEq j] (P : Matrix n n ℝ) {t : ℕ} {L : ℝ}
    (h : ∀ I : Finset n, I.card=t → IsUnit (P.submatrix (fun i : I => (i:n)) (fun i : I => (i:n))) →
      L ≤ (P.submatrix (fun i : I => (i:n)) (fun i : I => (i:n)))⁻¹.trace)
    (f : j → n) (hf : Function.Injective f) (hj : Fintype.card j=t)
    (hu : IsUnit (P.submatrix f f)) : L ≤ (P.submatrix f f)⁻¹.trace := by
  classical
  let I := Finset.univ.image f
  let g : j → I := fun x => ⟨f x,Finset.mem_image.mpr ⟨x,Finset.mem_univ _,rfl⟩⟩
  have hg : Function.Bijective g := by
    constructor
    · intro a b hab
      exact hf (congrArg Subtype.val hab)
    · intro b
      obtain ⟨a,ha,he⟩ := Finset.mem_image.mp b.property
      exact ⟨a,Subtype.ext he⟩
  let e : j ≃ I := Equiv.ofBijective g hg
  have hI : I.card=t := by simpa [I,Finset.card_image_of_injective _ hf] using hj
  let Q := P.submatrix (fun i : I => (i:n)) (fun i : I => (i:n))
  have he : Q.submatrix e e=P.submatrix f f := by ext a b; rfl
  have hQ : IsUnit Q := (Matrix.isUnit_submatrix_equiv e e).mp (he ▸ hu)
  have htr : (P.submatrix f f)⁻¹.trace=Q⁻¹.trace := by
    rw [← he,Matrix.inv_submatrix_equiv]
    exact e.sum_comp (fun i => Q⁻¹ i i)
  rw [htr]
  exact h I hI hQ

/-- Repeating each row h times and scaling by 1/sqrt h preserves orthonormal columns. -/
theorem replicated_frame_orthonormal {n p : Type*} [Fintype n] [Fintype p] [DecidableEq p]
    (V : Matrix n p ℝ) (hV : Vᴴ*V=1) {h : ℕ} (hh : 0<h) :
    let W : Matrix (n × Fin h) p ℝ := Matrix.of (fun i j => V i.1 j / Real.sqrt h)
    Wᴴ*W=1 := by
  dsimp only
  have hs : Real.sqrt (h:ℝ)≠0 := (Real.sqrt_pos.mpr (by exact_mod_cast hh)).ne'
  have hsq := Real.sq_sqrt (Nat.cast_nonneg h)
  ext a b
  have hv := congrFun (congrFun hV a) b
  simp only [Matrix.mul_apply,Matrix.conjTranspose_apply,star_trivial] at hv ⊢
  simp only [Matrix.of_apply, Fintype.sum_prod_type, Finset.sum_const, Finset.card_univ,
    Fintype.card_fin, nsmul_eq_mul]
  have he (i : n) : (h:ℝ)*(V i a/Real.sqrt h*(V i b/Real.sqrt h))=V i a*V i b := by
    field_simp
    rw [hsq]
    ring
  simpa only [he] using hv

/-- Replicated row Grams are exactly a scaled pullback of the original Gram. -/
theorem replicated_frame_gram {n p : Type*} [Fintype p] (V : Matrix n p ℝ) {h : ℕ} (hh : 0<h) :
    let W : Matrix (n × Fin h) p ℝ := Matrix.of (fun i j => V i.1 j / Real.sqrt h)
    W*Wᴴ=(h:ℝ)⁻¹ • (V*Vᴴ).submatrix Prod.fst Prod.fst := by
  dsimp only
  have hs : Real.sqrt (h:ℝ)≠0 := (Real.sqrt_pos.mpr (by exact_mod_cast hh)).ne'
  have hsq := Real.sq_sqrt (Nat.cast_nonneg h)
  ext a b
  simp only [Matrix.mul_apply,Matrix.conjTranspose_apply,star_trivial,Matrix.of_apply,
    Matrix.smul_apply,Matrix.submatrix_apply,smul_eq_mul,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  have hn : (h:ℝ)≠0 := by exact_mod_cast hh.ne'
  field_simp
  rw [hsq]
  ring

/-- A nonsingular scaled pullback cannot repeat an original row. -/
theorem injective_of_isUnit_scaled_submatrix {n j : Type*} [Fintype j] [DecidableEq j]
    (P : Matrix n n ℝ) (f : j → n) (c : ℝ) (hu : IsUnit (c • P.submatrix f f)) :
    Function.Injective f := by
  have hi := (Matrix.linearIndependent_rows_of_isUnit hu).injective
  intro a b hab
  apply hi
  ext k
  simp [Matrix.row, hab]

/-- Replication multiplies the guaranteed inverse trace by h on every nonsingular block. -/
theorem replicated_principal_inverse_trace {n : Type*} [Fintype n] [DecidableEq n]
    (P : Matrix n n ℝ) (hP : P.PosSemidef) {t h : ℕ} {L : ℝ} (hh : 0<h)
    (hblocks : ∀ I : Finset n, I.card=t → IsUnit (P.submatrix (fun i : I => (i:n)) (fun i : I => (i:n))) →
      L ≤ (P.submatrix (fun i : I => (i:n)) (fun i : I => (i:n)))⁻¹.trace)
    (J : Finset (n × Fin h)) (hJ : J.card=t)
    (hu : IsUnit (((h:ℝ)⁻¹ • P.submatrix Prod.fst Prod.fst).submatrix
      (fun i : J => (i : n × Fin h)) (fun i : J => (i : n × Fin h)))) :
    (h:ℝ)*L ≤ (((h:ℝ)⁻¹ • P.submatrix Prod.fst Prod.fst).submatrix
      (fun i : J => (i : n × Fin h)) (fun i : J => (i : n × Fin h)))⁻¹.trace := by
  let f : J → n := fun i => i.val.1
  have he : (((h:ℝ)⁻¹ • P.submatrix Prod.fst Prod.fst).submatrix
      (fun i : J => (i : n × Fin h)) (fun i : J => (i : n × Fin h))) = (h:ℝ)⁻¹ • P.submatrix f f := by
    ext a b; rfl
  rw [he] at hu ⊢
  have hp : (0:ℝ)<h := by exact_mod_cast hh
  have hscaled : ((h:ℝ)⁻¹ • P.submatrix f f).PosDef :=
    ((hP.submatrix f).smul (inv_pos.mpr hp).le).posDef_iff_isUnit.mpr hu
  have hQ : (P.submatrix f f).PosDef := by
    have hs := hscaled.smul hp
    simpa only [smul_smul,mul_inv_cancel₀ hp.ne',one_smul] using hs
  have hf := injective_of_isUnit_scaled_submatrix P f (h:ℝ)⁻¹ hu
  have hb := principal_inverse_trace_embedding P hblocks f hf (by simpa using hJ) hQ.isUnit
  rw [inverse_positive_smul hQ (inv_ne_zero hp.ne'),inv_inv,Matrix.trace_smul]
  exact mul_le_mul_of_nonneg_left hb hp.le

end SpectralComparison
