import SpectralComparison.WeightedFrameBase

noncomputable section
open Finset
namespace SpectralComparison

/-- The exact square-root telescoping estimate used in the weighted prefix argument. -/
theorem inv_sqrt_step (x : ℝ) (hx : 0≤x) :
    1/Real.sqrt (x+1)≤2*(Real.sqrt (x+1)-Real.sqrt x) := by
  have ha : 0<Real.sqrt (x+1) := Real.sqrt_pos.mpr (by linarith)
  have hsa := Real.sq_sqrt (show 0≤x+1 by linarith)
  have hsb := Real.sq_sqrt hx
  apply (div_le_iff₀ ha).mpr
  nlinarith [sq_nonneg (Real.sqrt (x+1)-Real.sqrt x)]

/-- Sum t^(-1/2) through m is at most 2 sqrt m, including m=0. -/
theorem sum_inverse_sqrt (m : ℕ) :
    (∑ i∈Finset.range m,1/Real.sqrt ((i:ℝ)+1))≤2*Real.sqrt m := by
  induction m with
  | zero => simp
  | succ m ih =>
    rw [Finset.sum_range_succ,Nat.cast_add,Nat.cast_one]
    have h := inv_sqrt_step (m:ℝ) (Nat.cast_nonneg m)
    linarith

/-- The small-dimension reciprocal-weight sum, without asymptotic constants. -/
theorem weighted_denominator_small {k m : ℕ} (hk : 1≤k) (hmk : m≤k) :
    (∑ i∈Finset.range m,1/(((k:ℝ)+(i:ℝ)+1)*Real.sqrt (min k (i+1):ℕ)))≤2*Real.sqrt m/k := by
  have hk0 : 0<(k:ℝ) := by exact_mod_cast (by omega : 0<k)
  have hpoint (i : ℕ) (hi : i∈Finset.range m) :
      1/(((k:ℝ)+(i:ℝ)+1)*Real.sqrt (min k (i+1):ℕ))≤(1/Real.sqrt ((i:ℝ)+1))/k := by
    have him : i<m := Finset.mem_range.mp hi
    have hmin : min k (i+1)=i+1 := min_eq_right (by omega)
    rw [hmin,Nat.cast_add,Nat.cast_one]
    have hs : 0<Real.sqrt ((i:ℝ)+1) := Real.sqrt_pos.mpr (by positivity)
    rw [div_div]
    apply one_div_le_one_div_of_le (by positivity)
    nlinarith [Nat.cast_nonneg (α:=ℝ) i]
  calc
    _ ≤∑ i∈Finset.range m,(1/Real.sqrt ((i:ℝ)+1))/k := Finset.sum_le_sum hpoint
    _ = (∑ i∈Finset.range m,1/Real.sqrt ((i:ℝ)+1))/k := (Finset.sum_div _ _ _).symm
    _ ≤_ := div_le_div_of_nonneg_right (sum_inverse_sqrt m) hk0.le

/-- Each late block of reciprocal prefix weights is bounded by its length and left endpoint. -/
theorem weighted_denominator_block {k q : ℕ} (hk : 1≤k) (hkq : k≤q) :
    (∑ i∈Finset.range q,1/(((k:ℝ)+((q+i:ℕ):ℝ)+1)*Real.sqrt (min k (q+i+1):ℕ)))≤
      (q:ℝ)/(((k:ℝ)+q)*Real.sqrt k) := by
  have hk0 : 0<(k:ℝ) := by exact_mod_cast (by omega : 0<k)
  have hs : 0<Real.sqrt (k:ℝ) := Real.sqrt_pos.mpr hk0
  calc
    _ ≤∑ _i∈Finset.range q,1/(((k:ℝ)+q)*Real.sqrt k) := by
      apply Finset.sum_le_sum
      intro i _
      rw [min_eq_left (by omega : k≤q+i+1)]
      apply one_div_le_one_div_of_le (by positivity)
      push_cast
      nlinarith [Nat.cast_nonneg (α:=ℝ) i]
    _ =_ := by simp only [Finset.sum_const,Finset.card_range,nsmul_eq_mul]; ring

/-- An elementary three-block estimate replaces the manuscript's logarithmic bound with a stronger rational one. -/
theorem weighted_denominator_large {k h : ℕ} (hk : 1≤k) (hh : h≤8*k) :
    (∑ i∈Finset.range h,1/(((k:ℝ)+(i:ℝ)+1)*Real.sqrt (min k (i+1):ℕ)))≤4/Real.sqrt k := by
  let f := fun i : ℕ => 1/(((k:ℝ)+(i:ℝ)+1)*Real.sqrt (min k (i+1):ℕ))
  have hnon : ∀ i,0≤f i := by intro i; dsimp [f]; positivity
  have hle : (∑ i∈Finset.range h,f i)≤∑ i∈Finset.range (8*k),f i :=
    Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono hh) (fun i _ _ => hnon i)
  have hbase := weighted_denominator_small hk (le_refl k)
  have h1 := weighted_denominator_block hk (le_refl k)
  have h2 := weighted_denominator_block hk (show k≤2*k by omega)
  have h4 := weighted_denominator_block hk (show k≤4*k by omega)
  have hsplit : (∑ i∈Finset.range (8*k),f i)=
      (∑ i∈Finset.range k,f i)+(∑ i∈Finset.range k,f (k+i))+
        (∑ i∈Finset.range (2*k),f (2*k+i))+(∑ i∈Finset.range (4*k),f (4*k+i)) := by
    rw [show 8*k=4*k+4*k by omega,Finset.sum_range_add]
    rw [show 4*k=2*k+2*k by omega,Finset.sum_range_add]
    rw [show 2*k=k+k by omega,Finset.sum_range_add]
  have hk0 : 0<(k:ℝ) := by exact_mod_cast (by omega : 0<k)
  have hs : 0<Real.sqrt (k:ℝ) := Real.sqrt_pos.mpr hk0
  have hs2 := Real.sq_sqrt hk0.le
  have ht : 2*Real.sqrt k/k+(k:ℝ)/(((k:ℝ)+k)*Real.sqrt k)+
      ((2*k:ℕ):ℝ)/(((k:ℝ)+(2*k:ℕ))*Real.sqrt k)+
        ((4*k:ℕ):ℝ)/(((k:ℝ)+(4*k:ℕ))*Real.sqrt k)≤4/Real.sqrt k := by
    push_cast
    field_simp
    nlinarith
  change (∑ i∈Finset.range h,f i)≤_
  apply hle.trans
  rw [hsplit]
  exact (add_le_add (add_le_add (add_le_add hbase h1) h2) h4).trans ht

end SpectralComparison
