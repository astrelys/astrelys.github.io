import SpectralComparison.ZeroPadding

/-! Dimension transfer and the small-column cases for uniform frame bounds. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Reindexing rows by a bijection preserves the frame and all principal-block bounds. -/
theorem reindex_frame_control {n m p : Type*} [Fintype n] [Fintype m] [Fintype p]
    [DecidableEq n] [DecidableEq m] [DecidableEq p]
    (V : Matrix n p ℝ) (hV : Vᴴ*V=1) {t : ℕ} {L : ℝ}
    (hb : ∀ I : Finset n, I.card=t → IsUnit ((V*Vᴴ).submatrix (fun i : I => (i:n)) (fun i : I => (i:n))) →
      L ≤ ((V*Vᴴ).submatrix (fun i : I => (i:n)) (fun i : I => (i:n)))⁻¹.trace)
    (e : m ≃ n) :
    ∃ W : Matrix m p ℝ, Wᴴ*W=1 ∧
      ∀ J : Finset m, J.card=t → IsUnit ((W*Wᴴ).submatrix (fun i : J => (i:m)) (fun i : J => (i:m))) →
        L ≤ ((W*Wᴴ).submatrix (fun i : J => (i:m)) (fun i : J => (i:m)))⁻¹.trace := by
  let W := V.submatrix e id
  have hw : Wᴴ*W=1 := by
    change (V.submatrix e id)ᴴ*V.submatrix e id=1
    rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv, hV,Matrix.submatrix_id_id]
  refine ⟨W,hw,?_⟩
  intro J hJ hu
  let f : J → n := fun i => e i.val
  have he : ((W*Wᴴ).submatrix (fun i : J => (i:m)) (fun i : J => (i:m))) =
      (V*Vᴴ).submatrix f f := by
    ext a b
    simp [W,f,Matrix.mul_apply]
  rw [he] at hu ⊢
  exact principal_inverse_trace_embedding (V*Vᴴ) hb f (e.injective.comp Subtype.val_injective)
    (by simpa using hJ) hu

/-- Coordinate frames give inverse trace at least t for all their nonsingular t-blocks. -/
theorem exists_coordinate_frame_control {N p t : ℕ} (hNp : p ≤ N) :
    ∃ V : Matrix (Fin N) (Fin p) ℝ, Vᴴ*V=1 ∧
      ∀ J : Finset (Fin N), J.card=t → IsUnit ((V*Vᴴ).submatrix (fun i : J => (i:Fin N)) (fun i : J => (i:Fin N))) →
        (t:ℝ) ≤ ((V*Vᴴ).submatrix (fun i : J => (i:Fin N)) (fun i : J => (i:Fin N)))⁻¹.trace := by
  let V := Matrix.fromRows (1 : Matrix (Fin p) (Fin p) ℝ) (0 : Matrix (Fin (N-p)) (Fin p) ℝ)
  have hv : Vᴴ*V=1 := zero_padded_frame_orthonormal 1 (by simp)
  have hid : ∀ I : Finset (Fin p), I.card=t → IsUnit (((1 : Matrix (Fin p) (Fin p) ℝ)*1ᴴ).submatrix
      (fun i : I => (i:Fin p)) (fun i : I => (i:Fin p))) →
      (t:ℝ) ≤ (((1 : Matrix (Fin p) (Fin p) ℝ)*1ᴴ).submatrix
      (fun i : I => (i:Fin p)) (fun i : I => (i:Fin p)))⁻¹.trace := by
    intro I hI _
    rw [Matrix.conjTranspose_one,Matrix.mul_one,Matrix.submatrix_one _ Subtype.val_injective,
      inv_one,Matrix.trace_one,Fintype.card_coe,hI]
  have hb := zero_padded_principal_inverse_trace (r := Fin (N-p)) (1 : Matrix (Fin p) (Fin p) ℝ) hid
  let e : Fin N ≃ Fin p ⊕ Fin (N-p) := Fintype.equivOfCardEq (by simp; omega)
  exact reindex_frame_control V hv hb e

/-- Equation (4.6) holds also for 1<=p<=3, with a coordinate frame. -/
theorem exists_small_base_frame {N t q : ℕ} (ht : 1 ≤ t) (hp : t+q ≤ 3) (hNp : t+q ≤ N) :
    ∃ V : Matrix (Fin N) (Fin (t+q)) ℝ, Vᴴ*V=1 ∧
      ∀ J : Finset (Fin N), J.card=t → IsUnit ((V*Vᴴ).submatrix (fun i : J => (i:Fin N)) (fun i : J => (i:Fin N))) →
        ((t+q:ℕ):ℝ)*t/(1000000000000000000000000000*((q:ℝ)+Real.sqrt (t+q:ℕ))) ≤
        ((V*Vᴴ).submatrix (fun i : J => (i:Fin N)) (fun i : J => (i:Fin N)))⁻¹.trace := by
  obtain ⟨V,hV,hb⟩ := exists_coordinate_frame_control (t := t) hNp
  refine ⟨V,hV,?_⟩
  intro J hJ hu
  apply le_trans _ (hb J hJ hu)
  have hpp : (1:ℝ) ≤ (t+q:ℕ) := by exact_mod_cast (show 1≤t+q by omega)
  have hroot : 1 ≤ Real.sqrt (t+q:ℕ) := by
    nlinarith [Real.sq_sqrt (Nat.cast_nonneg (t+q)), Real.sqrt_nonneg (t+q:ℕ)]
  have hd : 0 < (q:ℝ)+Real.sqrt (t+q:ℕ) := by linarith [Nat.cast_nonneg (α := ℝ) q]
  apply (div_le_iff₀ (mul_pos (by norm_num) hd)).mpr
  have hpr : (t+q:ℕ) ≤ (3:ℝ) := by exact_mod_cast hp
  have hb : (t+q:ℕ) ≤ (1000000000000000000000000000:ℝ)*((q:ℝ)+Real.sqrt (t+q:ℕ)) := by
    linarith [Nat.cast_nonneg (α := ℝ) q]
  nlinarith [mul_le_mul_of_nonneg_right hb (Nat.cast_nonneg (α := ℝ) t)]

/-- The base frame estimate for every positive p=t+q. -/
theorem exists_base_frame_all_dimensions {N t q : ℕ} (ht : 1 ≤ t)
    (hNlow : 4*(t+q) ≤ 3*N) (hNhigh : N ≤ 2*(t+q)) :
    ∃ V : Matrix (Fin N) (Fin (t+q)) ℝ, Vᴴ*V=1 ∧
      ∀ J : Finset (Fin N), J.card=t → IsUnit ((V*Vᴴ).submatrix (fun i : J => (i:Fin N)) (fun i : J => (i:Fin N))) →
        ((t+q:ℕ):ℝ)*t/(1000000000000000000000000000*((q:ℝ)+Real.sqrt (t+q:ℕ))) ≤
        ((V*Vᴴ).submatrix (fun i : J => (i:Fin N)) (fun i : J => (i:Fin N)))⁻¹.trace := by
  by_cases hp : 4≤t+q
  · exact exists_base_frame ht hp hNlow hNhigh
  · exact exists_small_base_frame ht (by omega) (by omega)

end SpectralComparison
