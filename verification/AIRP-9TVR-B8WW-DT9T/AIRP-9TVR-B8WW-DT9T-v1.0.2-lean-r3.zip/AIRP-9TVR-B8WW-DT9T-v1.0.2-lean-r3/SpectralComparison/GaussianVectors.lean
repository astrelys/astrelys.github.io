import SpectralComparison.GaussianTail

/-! Exact one-vector Gaussian laws and both Chernoff tails of its squared norm. -/
noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

/-- Applying an independent Gaussian matrix to a fixed unit vector produces independent
standard Gaussian coordinates. The vector and matrix are literal Euclidean objects. -/
theorem gaussian_unit_vector_laws {Ω n p : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p]
    (G : Ω → Matrix n p ℝ)
    (hG : ∀ a : n × p, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : n × p => fun ω => G ω a.1 a.2) μ)
    (v : EuclideanSpace ℝ p) (hv : ‖v‖=1) :
    (∀ i, HasLaw (fun ω => (G ω).toEuclideanLin v i) (gaussianReal 0 1) μ) ∧
    iIndepFun (fun i ω => (G ω).toEuclideanLin v i) μ := by
  let R : Matrix p Unit ℝ := Matrix.of (fun i _ => v i)
  have hvsum : ∑ i, (v i)^2 = 1 := by rw [← EuclideanSpace.real_norm_sq_eq, hv]; norm_num
  have hR : Rᴴ*R=1 := by
    ext i j
    cases i; cases j
    simpa [R, Matrix.mul_apply, pow_two] using hvsum
  have he : (fun i ω => (G ω).toEuclideanLin v i) = (fun i ω => (G ω*R) i ()) := by
    funext i ω
    simp [Matrix.toLpLin_apply, Matrix.mulVec, dotProduct, Matrix.mul_apply, R]
  rw [he]
  refine ⟨fun i => gaussian_rows_projected_entry_hasLaw G hG hind R hR (i,()), ?_⟩
  exact (gaussian_rows_projected_independent G hG hind R hR).precomp
    (show Function.Injective (fun i : n => (i,())) from fun i j h => congrArg Prod.fst h)

/-- An upper Chernoff bound with arbitrary threshold and parameter, using the exact Gaussian MGF. -/
theorem gaussian_squares_upper_chernoff {Ω ι : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] (X : ι → Ω → ℝ)
    (hX : ∀ i, HasLaw (X i) (gaussianReal 0 1) μ) (hind : iIndepFun X μ)
    (hm : ∀ i, Measurable (X i)) (s : Finset ι) (a z : ℝ) (hz0 : 0 ≤ z) (hz : z < 1/2) :
    μ.real {ω | a ≤ ∑ i ∈ s, (X i ω)^2} ≤
      Real.exp (-z*a)*(1-2*z)^(-(s.card:ℝ)/2) := by
  have h := measure_ge_le_exp_mul_mgf (μ := μ) (X := fun ω => ∑ i ∈ s, (X i ω)^2)
    a hz0 (gaussian_squares_exp_integrable X hX hind hm s hz)
  rwa [paper_equation_2_4 X hX hind hm s hz] at h

/-- A lower Chernoff bound with arbitrary threshold and nonpositive parameter. -/
theorem gaussian_squares_lower_chernoff {Ω ι : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] (X : ι → Ω → ℝ)
    (hX : ∀ i, HasLaw (X i) (gaussianReal 0 1) μ) (hind : iIndepFun X μ)
    (hm : ∀ i, Measurable (X i)) (s : Finset ι) (a z : ℝ) (hz : z ≤ 0) :
    μ.real {ω | ∑ i ∈ s, (X i ω)^2 ≤ a} ≤
      Real.exp (-z*a)*(1-2*z)^(-(s.card:ℝ)/2) := by
  have h := measure_le_le_exp_mul_mgf (μ := μ) (X := fun ω => ∑ i ∈ s, (X i ω)^2)
    a hz (gaussian_squares_exp_integrable X hX hind hm s (by linarith))
  rwa [paper_equation_2_4 X hX hind hm s (by linarith)] at h

/-- Exact upper-tail bound for the squared norm of a Gaussian matrix on a fixed unit vector. -/
theorem gaussian_vector_norm_upper {Ω n p : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p] (G : Ω → Matrix n p ℝ)
    (hG : ∀ a : n × p, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : n × p => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : n × p, Measurable (fun ω => G ω a.1 a.2))
    (v : EuclideanSpace ℝ p) (hv : ‖v‖=1) (a z : ℝ) (hz0 : 0 ≤ z) (hz : z < 1/2) :
    μ.real {ω | a ≤ ‖(G ω).toEuclideanLin v‖^2} ≤
      Real.exp (-z*a)*(1-2*z)^(-(Fintype.card n:ℝ)/2) := by
  obtain ⟨hlaw,hi⟩ := gaussian_unit_vector_laws G hG hind v hv
  have hmeas (i : n) : Measurable (fun ω => (G ω).toEuclideanLin v i) := by
    simp only [Matrix.toLpLin_apply, WithLp.ofLp_toLp, Matrix.mulVec, dotProduct]
    exact Finset.measurable_sum _ (fun j _ => (hm (i,j)).mul_const _)
  have h := gaussian_squares_upper_chernoff _ hlaw hi hmeas Finset.univ a z hz0 hz
  simpa only [Finset.card_univ, ← EuclideanSpace.real_norm_sq_eq] using h

/-- Exact lower-tail bound for the squared norm of a Gaussian matrix on a fixed unit vector. -/
theorem gaussian_vector_norm_lower {Ω n p : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p] (G : Ω → Matrix n p ℝ)
    (hG : ∀ a : n × p, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : n × p => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : n × p, Measurable (fun ω => G ω a.1 a.2))
    (v : EuclideanSpace ℝ p) (hv : ‖v‖=1) (a z : ℝ) (hz : z ≤ 0) :
    μ.real {ω | ‖(G ω).toEuclideanLin v‖^2 ≤ a} ≤
      Real.exp (-z*a)*(1-2*z)^(-(Fintype.card n:ℝ)/2) := by
  obtain ⟨hlaw,hi⟩ := gaussian_unit_vector_laws G hG hind v hv
  have hmeas (i : n) : Measurable (fun ω => (G ω).toEuclideanLin v i) := by
    simp only [Matrix.toLpLin_apply, WithLp.ofLp_toLp, Matrix.mulVec, dotProduct]
    exact Finset.measurable_sum _ (fun j _ => (hm (i,j)).mul_const _)
  have h := gaussian_squares_lower_chernoff _ hlaw hi hmeas Finset.univ a z hz
  simpa only [Finset.card_univ, ← EuclideanSpace.real_norm_sq_eq] using h

end SpectralComparison
