import SpectralComparison.WeightedConcentration

noncomputable section
open Matrix
namespace SpectralComparison

/-- Congruent row scaling cancels exactly in the inverse-weighted trace. -/
theorem congruence_inverse_weighted_trace {j : Type*} [Fintype j] [DecidableEq j]
    (D P B : Matrix j j ℝ) (hD : IsUnit D) :
    ((D*P*D)⁻¹*(D*B*D)).trace=(P⁻¹*B).trace := by
  have hd := (Matrix.isUnit_iff_isUnit_det _).mp hD
  have hl := Matrix.nonsing_inv_mul D hd
  have hr := Matrix.mul_nonsing_inv D hd
  rw [Matrix.mul_inv_rev,Matrix.mul_inv_rev]
  have he : (D⁻¹*(P⁻¹*D⁻¹))*(D*B*D)=D⁻¹*(P⁻¹*B)*D := by
    calc
      _ = D⁻¹*P⁻¹*(D⁻¹*D)*B*D := by simp only [Matrix.mul_assoc]
      _ = _ := by rw [hl,Matrix.mul_one]; simp only [Matrix.mul_assoc]
  rw [he,Matrix.trace_mul_cycle,hr,Matrix.one_mul]

/-- Nonsingularity of a square congruence forces its middle factor nonsingular. -/
theorem isUnit_middle_of_congruence {j : Type*} [Fintype j] [DecidableEq j]
    (D P : Matrix j j ℝ) (h : IsUnit (D*P*D)) : IsUnit P := by
  have hh := (Matrix.isUnit_iff_isUnit_det _).mp h
  rw [Matrix.det_mul,Matrix.det_mul] at hh
  rw [Matrix.isUnit_iff_isUnit_det]
  rw [isUnit_iff_ne_zero] at hh ⊢
  intro hp
  apply hh
  rw [hp,mul_zero,zero_mul]

/-- Exact covariance group structure transfers a base inverse-cost bound through arbitrary nonzero row weights. -/
theorem grouped_weighted_inverse_lower {g j p : Type*}
    [Fintype g] [Fintype j] [Fintype p] [DecidableEq g] [DecidableEq j] [DecidableEq p]
    (Q0 : Matrix g p ℝ) (f : j → g) (u : j → ℝ) (hu : ∀ i,u i≠0)
    (C D : Matrix j j ℝ) (hCD : (C-D).PosSemidef)
    (v : g → ℝ) (hcross : ∀ i l,f i≠f l → D i l=0)
    (hdiag : ∀ i,D i i=v (f i)*u i^2) {z L : ℝ} (hz : 0≤z) (hv : ∀ i,z≤v i)
    (hbase : ∀ I : Finset g,I.card=Fintype.card j →
      IsUnit (principal (Q0*Q0ᴴ) I) → L≤(principal (Q0*Q0ᴴ) I)⁻¹.trace)
    (hunit : IsUnit (Matrix.diagonal u*(Q0*Q0ᴴ).submatrix f f*Matrix.diagonal u)) :
    z*L≤((Matrix.diagonal u*(Q0*Q0ᴴ).submatrix f f*Matrix.diagonal u)⁻¹*C).trace := by
  let U := Matrix.diagonal u
  let P := (Q0*Q0ᴴ).submatrix f f
  have hU : IsUnit U := by
    rw [Matrix.isUnit_iff_isUnit_det,Matrix.det_diagonal,isUnit_iff_ne_zero]
    exact Finset.prod_ne_zero_iff.mpr (fun i _ => hu i)
  have hP : IsUnit P := isUnit_middle_of_congruence U P hunit
  have hf : Function.Injective f := injective_of_isUnit_scaled_submatrix (Q0*Q0ᴴ) f 1 (by simpa only [one_smul] using hP)
  have hPpd : P.PosDef := ((posSemidef_self_mul_conjTranspose Q0).submatrix f).posDef_iff_isUnit.mpr hP
  have hGpd : (U*P*U).PosDef := by
    have hh := ((posSemidef_self_mul_conjTranspose Q0).submatrix f).mul_mul_conjTranspose_same U
    have hUstar : Uᴴ=U := by
      ext i l
      by_cases hil : i=l
      · subst l; simp [U]
      · simp [U,Matrix.conjTranspose_apply,Matrix.diagonal_apply,hil,Ne.symm hil]
    rw [hUstar] at hh
    exact hh.posDef_iff_isUnit.mpr hunit
  have hD : D=U*Matrix.diagonal (v ∘ f)*U := by
    ext i l
    rw [Matrix.mul_diagonal,Matrix.diagonal_mul]
    by_cases hil : i=l
    · subst l
      simp only [Matrix.diagonal_apply_eq,Function.comp_apply]
      rw [hdiag]
      ring
    · rw [hcross i l (fun hh => hil (hf hh)),Matrix.diagonal_apply_ne _ hil]
      simp
  have htrace : ((U*P*U)⁻¹*D).trace=(P⁻¹*Matrix.diagonal (v ∘ f)).trace := by
    rw [hD,congruence_inverse_weighted_trace U P _ hU]
  have hcost : L≤P⁻¹.trace := principal_inverse_trace_embedding (Q0*Q0ᴴ) hbase f hf rfl hP
  have hdiagv : (Matrix.diagonal (v ∘ f)-z • (1 : Matrix j j ℝ)).PosSemidef := by
    convert Matrix.PosSemidef.diagonal (fun i => sub_nonneg.mpr (hv (f i))) using 1
    ext i l
    by_cases hil : i=l
    · subst l; simp
    · simp [hil]
  have hlower := trace_product_lower hPpd.inv.posSemidef hdiagv
  rw [Matrix.trace_mul_comm] at hlower
  have hmon := trace_mul_posSemidef_nonneg hGpd.inv.posSemidef hCD
  rw [Matrix.mul_sub,Matrix.trace_sub,htrace] at hmon
  change z*L≤((U*P*U)⁻¹*C).trace
  have h0 := mul_le_mul_of_nonneg_left hcost hz
  linarith

end SpectralComparison
