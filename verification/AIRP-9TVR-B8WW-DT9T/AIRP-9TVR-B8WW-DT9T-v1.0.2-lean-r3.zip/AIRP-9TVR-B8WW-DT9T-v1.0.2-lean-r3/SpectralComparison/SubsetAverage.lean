import SpectralComparison.GaussianSquares
import Mathlib.Algebra.BigOperators.Group.Finset.Powerset

/-! Exact subset averaging and the Markov counting step of (3.2). -/
noncomputable section
namespace SpectralComparison
open Finset MeasureTheory ProbabilityTheory
open scoped Classical

/-- Each coordinate occurs in choose(n-1,j-1) of all j-subsets. -/
theorem sum_subset_sums {ι : Type*} [Fintype ι] [DecidableEq ι]
    (v : ι → ℝ) {j : ℕ} (hj : 1 ≤ j) :
    (∑ I ∈ (Finset.univ : Finset ι).powersetCard j, ∑ i ∈ I, v i) =
      ((Fintype.card ι-1).choose (j-1):ℝ) * ∑ i, v i := by
  classical
  calc
    _ = ∑ I ∈ (Finset.univ : Finset ι).powersetCard j, ∑ i, if i ∈ I then v i else 0 := by simp
    _ = ∑ i, ∑ I ∈ (Finset.univ : Finset ι).powersetCard j, if i ∈ I then v i else 0 := Finset.sum_comm
    _ = ∑ i, ((Fintype.card ι-1).choose (j-1):ℝ)*v i := by
      apply Finset.sum_congr rfl
      intro i _
      rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul]
      congr 1
      have hc := Finset.card_filter_powersetCard_subset ({i} : Finset ι) Finset.univ j
        (Finset.subset_univ _) (by simpa using hj)
      exact_mod_cast (show ((Finset.univ : Finset ι).powersetCard j |>.filter (fun I => i ∈ I)).card = (Fintype.card ι-1).choose (j-1) by
        simpa only [Finset.singleton_subset_iff, Finset.card_univ, Finset.card_singleton] using hc)
    _ = _ := (Finset.mul_sum _ _ _).symm

/-- The exact average identity, with denominators cleared. -/
theorem subset_sum_average_identity {ι : Type*} [Fintype ι] [DecidableEq ι]
    (v : ι → ℝ) {j : ℕ} (hj : 1 ≤ j) (hjn : j ≤ Fintype.card ι) :
    (Fintype.card ι:ℝ) * (∑ I ∈ (Finset.univ : Finset ι).powersetCard j, ∑ i ∈ I, v i) =
      (((Finset.univ : Finset ι).powersetCard j).card:ℝ)*(j:ℝ)*∑ i, v i := by
  have hn : 1 ≤ Fintype.card ι := hj.trans hjn
  have hc := Nat.add_one_mul_choose_eq (Fintype.card ι-1) (j-1)
  rw [Nat.sub_add_cancel hn, Nat.sub_add_cancel hj] at hc
  have hcR : (Fintype.card ι:ℝ)*((Fintype.card ι-1).choose (j-1):ℝ) =
      ((Fintype.card ι).choose j:ℝ)*(j:ℝ) := by exact_mod_cast hc
  rw [sum_subset_sums v hj, ← mul_assoc, hcR, Finset.card_powersetCard, Finset.card_univ]

/-- Finite Markov counting: at least half the values lie at most twice the mean bound. -/
theorem at_least_half_le_twice {ι : Type*} (s : Finset ι) (v : ι → ℝ)
    (hv : ∀ i ∈ s, 0 ≤ v i) {a : ℝ} (ha : 0 < a)
    (havg : ∑ i ∈ s, v i ≤ (s.card:ℝ)*a) :
    (s.card:ℝ) ≤ 2*((s.filter (fun i => v i ≤ 2*a)).card:ℝ) := by
  classical
  let bad := s.filter (fun i => ¬v i ≤ 2*a)
  let good := s.filter (fun i => v i ≤ 2*a)
  have hbad : (bad.card:ℝ)*(2*a) ≤ ∑ i ∈ bad, v i := by
    calc
      _ = ∑ _i ∈ bad, 2*a := by simp
      _ ≤ _ := Finset.sum_le_sum (fun i hi => (lt_of_not_ge (Finset.mem_filter.mp hi).2).le)
  have hsum : (∑ i ∈ bad, v i) ≤ ∑ i ∈ s, v i :=
    Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _) (fun i hi _ => hv i hi)
  have hc : bad.card+good.card = s.card := by
    simpa only [not_not] using Finset.card_filter_add_card_filter_not (s := s) (p := fun i => ¬v i ≤ 2*a)
  have hcR : (bad.card:ℝ)+(good.card:ℝ) = s.card := by exact_mod_cast hc
  change (s.card:ℝ) ≤ 2*(good.card:ℝ)
  nlinarith

/-- Deterministic half-subset implication behind the exchangeability reduction (3.2). -/
theorem half_subsets_trace_small {ι : Type*} [Fintype ι] [DecidableEq ι]
    (v : ι → ℝ) (hv : ∀ i, 0 ≤ v i) {j : ℕ} (hj : 1 ≤ j)
    (hjn : j ≤ Fintype.card ι) {b : ℝ} (hb : 0 < b)
    (htrace : ∑ i, v i ≤ (Fintype.card ι:ℝ)/b) :
    (((Finset.univ : Finset ι).powersetCard j).card:ℝ) ≤
      2*((((Finset.univ : Finset ι).powersetCard j).filter
        (fun I => ∑ i ∈ I, v i ≤ 2*(j:ℝ)/b)).card:ℝ) := by
  have hn : (0:ℝ) < Fintype.card ι := by exact_mod_cast (show 0 < Fintype.card ι by omega)
  have hjR : (0:ℝ) < j := by exact_mod_cast (show 0 < j by omega)
  have havg : (∑ I ∈ (Finset.univ : Finset ι).powersetCard j, ∑ i ∈ I, v i) ≤
      (((Finset.univ : Finset ι).powersetCard j).card:ℝ)*((j:ℝ)/b) := by
    apply le_of_mul_le_mul_left _ hn
    rw [subset_sum_average_identity v hj hjn]
    have h := mul_le_mul_of_nonneg_left htrace
      (show 0 ≤ (((Finset.univ : Finset ι).powersetCard j).card:ℝ)*(j:ℝ) by positivity)
    convert h using 1; ring
  have h := at_least_half_le_twice ((Finset.univ : Finset ι).powersetCard j)
    (fun I => ∑ i ∈ I, v i) (fun I _ => Finset.sum_nonneg (fun i _ => hv i)) (div_pos hjR hb) havg
  simpa only [mul_div_assoc] using h

/-- A finite family covering every point of E at least half the time gives the
probability bound used in the exchangeability step. -/
theorem measure_event_le_twice_of_half_memberships {Ω ι : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] (s : Finset ι) (hs : s.Nonempty)
    (E : Set Ω) (F : ι → Set Ω) (hE : MeasurableSet E)
    (hF : ∀ i ∈ s, MeasurableSet (F i))
    (hhalf : ∀ᵐ ω ∂μ, ω ∈ E → (s.card:ℝ) ≤ 2*((s.filter (fun i => ω ∈ F i)).card:ℝ))
    {p : ℝ} (hprob : ∀ i ∈ s, μ.real (F i) = p) : μ.real E ≤ 2*p := by
  classical
  have hiE : Integrable (E.indicator (1 : Ω → ℝ)) μ := (integrable_const 1).indicator hE
  have hiF (i : ι) (hi : i ∈ s) : Integrable ((F i).indicator (1 : Ω → ℝ)) μ :=
    (integrable_const 1).indicator (hF i hi)
  have hpoint : ∀ᵐ ω ∂μ, (s.card:ℝ)*E.indicator (1 : Ω → ℝ) ω ≤
      2*(∑ i ∈ s, (F i).indicator (1 : Ω → ℝ) ω) := by
    filter_upwards [hhalf] with ω hω
    simp only [Set.indicator_apply, Pi.one_apply, Finset.sum_boole]
    by_cases he : ω ∈ E
    · simpa only [ite_eq_left he, mul_one] using hω he
    · simp only [ite_eq_right he, mul_zero]
      positivity
  have hint := integral_mono_ae (hiE.const_mul (s.card:ℝ))
    ((integrable_finsetSum s hiF).const_mul 2) hpoint
  simp only [integral_const_mul, integral_finsetSum s hiF, integral_indicator_one hE] at hint
  have hsum : (∑ i ∈ s, ∫ ω, (F i).indicator (1 : Ω → ℝ) ω ∂μ) = (s.card:ℝ)*p := by
    calc
      _ = ∑ i ∈ s, p := Finset.sum_congr rfl (fun i hi => by rw [integral_indicator_one (hF i hi), hprob i hi])
      _ = _ := by simp
  rw [hsum] at hint
  have hn : (0:ℝ) < s.card := by exact_mod_cast Finset.card_pos.mpr hs
  nlinarith

/-- Equation (3.2)'s exchangeability argument for any nonnegative random diagonal.
Equal subset-event probabilities are explicit; no independence of diagonal entries is assumed. -/
theorem exchangeable_subset_trace_bound {Ω ι : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype ι] [DecidableEq ι]
    (v : ι → Ω → ℝ) (hv : ∀ i, Measurable (v i))
    (hnonneg : ∀ᵐ ω ∂μ, ∀ i, 0 ≤ v i ω) {j : ℕ} (hj : 1 ≤ j)
    (hjn : j ≤ Fintype.card ι) {b : ℝ} (hb : 0 < b)
    (J : Finset ι) (_hJ : J.card = j)
    (hexchange : ∀ I : Finset ι, I.card = j →
      μ.real {ω | ∑ i ∈ I, v i ω ≤ 2*(j:ℝ)/b} =
        μ.real {ω | ∑ i ∈ J, v i ω ≤ 2*(j:ℝ)/b}) :
    μ.real {ω | ∑ i, v i ω ≤ (Fintype.card ι:ℝ)/b} ≤
      2*μ.real {ω | ∑ i ∈ J, v i ω ≤ 2*(j:ℝ)/b} := by
  classical
  apply measure_event_le_twice_of_half_memberships ((Finset.univ : Finset ι).powersetCard j)
    (Finset.powersetCard_nonempty.mpr (by simpa using hjn))
    {ω | ∑ i, v i ω ≤ (Fintype.card ι:ℝ)/b}
    (fun I => {ω | ∑ i ∈ I, v i ω ≤ 2*(j:ℝ)/b})
  · exact measurableSet_le (by fun_prop : Measurable (fun ω => ∑ i, v i ω)) measurable_const
  · intro I _
    exact measurableSet_le (by fun_prop : Measurable (fun ω => ∑ i ∈ I, v i ω)) measurable_const
  · filter_upwards [hnonneg] with ω hω
    intro htrace
    exact half_subsets_trace_small (fun i => v i ω) hω hj hjn hb htrace
  · intro I hI
    exact hexchange I (Finset.mem_powersetCard.mp hI).2

end SpectralComparison
