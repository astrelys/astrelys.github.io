import SpectralComparison.RobustSmallFrame

/-! Integer repetition counts and the deterministic weighted inverse-trace reduction. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- A nonsingular weighted Gram must use at least as many nonzero weights as columns. -/
theorem weighted_gram_support_card {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p] (Q : Matrix n p ℝ) (w : n → ℕ)
    (hB : (Qᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Q).PosDef) :
    Fintype.card p≤(Finset.univ.filter (fun i => 0<w i)).card := by
  have hr := Matrix.rank_of_isUnit _ hB.isUnit
  have hb : (Qᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Q).rank≤(Matrix.diagonal (fun i => (w i:ℝ))).rank :=
    (Matrix.rank_mul_le_left _ _).trans (Matrix.rank_mul_le_right _ _)
  rw [hr,Matrix.rank_diagonal] at hb
  simpa only [ne_eq,Nat.cast_eq_zero,← Nat.pos_iff_ne_zero,Fintype.card_subtype,Finset.card_filter] using hb

/-- Large repetition counts consume two units beyond the support count. -/
theorem repetition_count_excess {n : Type*} [Fintype n] [DecidableEq n] (w : n → ℕ) :
    2*(Finset.univ.filter (fun i => 3≤w i)).card+
      (Finset.univ.filter (fun i => 0<w i)).card≤∑ i, w i := by
  classical
  have hpoint (i : n) : 2*(if 3≤w i then 1 else 0)+(if 0<w i then 1 else 0)≤w i := by
    split_ifs <;> omega
  have hh := Finset.sum_le_sum (s := Finset.univ) (fun i _ => hpoint i)
  rw [Finset.sum_add_distrib,← Finset.mul_sum] at hh
  simpa [Finset.sum_boole] using hh

/-- The positive small counts, together with the large counts, partition the support. -/
theorem repetition_support_partition {n : Type*} [Fintype n] [DecidableEq n] (w : n → ℕ) :
    Disjoint (Finset.univ.filter (fun i => 3≤w i)) (Finset.univ.filter (fun i => 0<w i ∧ w i<3)) ∧
      (Finset.univ.filter (fun i => 3≤w i)).card+
        (Finset.univ.filter (fun i => 0<w i ∧ w i<3)).card=
          (Finset.univ.filter (fun i => 0<w i)).card := by
  have hd : Disjoint (Finset.univ.filter (fun i => 3≤w i)) (Finset.univ.filter (fun i => 0<w i ∧ w i<3)) := by
    apply Finset.disjoint_left.mpr
    intro i hi hj
    simp only [Finset.mem_filter,Finset.mem_univ,true_and] at hi hj
    omega
  refine ⟨hd,?_⟩
  rw [← Finset.card_union_of_disjoint hd]
  congr 1
  ext i
  simp only [Finset.mem_union,Finset.mem_filter,Finset.mem_univ,true_and]
  omega

/-- Weighted compression on the kernel of all counts at least three is at most twice the small-count Gram. -/
theorem repetition_kernel_gram_upper {n p d : Type*} [Fintype n] [Fintype p] [Fintype d]
    [DecidableEq n] [DecidableEq p] [DecidableEq d]
    (Q : Matrix n p ℝ) (w : n → ℕ) (U : Matrix p d ℝ)
    (hHU : (Q.submatrix (fun i : (Finset.univ.filter (fun i => 3≤w i)) => (i:n)) id)*U=0) :
    let L := Finset.univ.filter (fun i => 0<w i ∧ w i<3)
    let G := (Q.submatrix (fun i : L => (i:n)) id)*U
    ((2:ℝ) • (Gᴴ*G)-Uᴴ*(Qᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Q)*U).PosSemidef := by
  classical
  let L := Finset.univ.filter (fun i => 0<w i ∧ w i<3)
  let Y := Q*U
  have hz (i : n) (hi : 3≤w i) (a : d) : Y i a=0 := by
    let j : (Finset.univ.filter (fun i => 3≤w i)) := ⟨i,by simp [hi]⟩
    have h := congrFun (congrFun hHU j) a
    simpa [Y,j,Matrix.mul_apply,Matrix.submatrix_apply,Matrix.zero_apply] using h
  let c := fun i : n => if 3≤w i then (0:ℝ) else 2*(if i∈L then 1 else 0)-(w i:ℝ)
  have hc (i) : 0≤c i := by
    dsimp [c,L]
    simp only [Finset.mem_filter,Finset.mem_univ,true_and]
    split_ifs with h1 h2
    · norm_num
    · have hw : (w i:ℝ)≤2 := by exact_mod_cast (show w i≤2 by omega)
      linarith
    · have hw : w i=0 := by omega
      simp [hw]
  have hD := (Matrix.PosSemidef.diagonal hc).conjTranspose_mul_mul_same Y
  have hGY : (Q.submatrix (fun i : L => (i:n)) id)*U=Y.submatrix (fun i : L => (i:n)) id := by
    ext a b
    simp [Y,Matrix.mul_apply]
  have he : Yᴴ*Matrix.diagonal c*Y=
      (2:ℝ) • ((Y.submatrix (fun i : L => (i:n)) id)ᴴ*(Y.submatrix (fun i : L => (i:n)) id))-
        Yᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Y := by
    rw [row_selection_gram_eq]
    ext a b
    change (∑ i, (Yᴴ*Matrix.diagonal c) a i * Y i b) =
      2*(∑ i, (Yᴴ*Matrix.diagonal (fun j => if j∈L then (1:ℝ) else 0)) a i * Y i b)-
      ∑ i, (Yᴴ*Matrix.diagonal (fun j => (w j:ℝ))) a i * Y i b
    simp only [Matrix.mul_diagonal,Matrix.conjTranspose_apply,star_trivial]
    rw [Finset.mul_sum,← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro i _
    dsimp [c]
    by_cases hi : 3≤w i
    · rw [ite_eq_left hi,hz i hi a,hz i hi b]
      ring
    · rw [ite_eq_right hi]
      ring
  rw [he] at hD
  dsimp only
  rw [hGY]
  convert hD using 1
  simp only [Y,Matrix.conjTranspose_mul,Matrix.mul_assoc]

/-- Inverse compression and inverse order give the factor one-half in (5.2). -/
theorem repetition_inverse_trace_transfer {p d l : Type*} [Fintype p] [Fintype d] [Fintype l]
    [DecidableEq p] [DecidableEq d] {B : Matrix p p ℝ} (hB : B.PosDef)
    (U : Matrix p d ℝ) (hU : Uᴴ*U=1) (G : Matrix l d ℝ)
    (hgap : ((2:ℝ) • (Gᴴ*G)-Uᴴ*B*U).PosSemidef) :
    (Gᴴ*G).PosDef ∧ (1/2:ℝ)*(Gᴴ*G)⁻¹.trace≤B⁻¹.trace := by
  have hC := orthonormal_compression_posDef hB U hU
  have htwo : ((2:ℝ) • (Gᴴ*G)).PosDef := by
    convert hC.add_posSemidef hgap using 1
    abel
  have hG : (Gᴴ*G).PosDef := by
    have h := htwo.smul (by norm_num : (0:ℝ)<1/2)
    simpa only [smul_smul,show (1/2:ℝ)*2=1 by norm_num,one_smul] using h
  have hi := inverse_trace_order hC htwo hgap
  rw [inverse_positive_smul hG (by norm_num : (2:ℝ)≠0),Matrix.trace_smul] at hi
  refine ⟨hG,?_⟩
  have hh := hi.trans (inverse_trace_compression hB U hU)
  simpa using hh

end SpectralComparison
