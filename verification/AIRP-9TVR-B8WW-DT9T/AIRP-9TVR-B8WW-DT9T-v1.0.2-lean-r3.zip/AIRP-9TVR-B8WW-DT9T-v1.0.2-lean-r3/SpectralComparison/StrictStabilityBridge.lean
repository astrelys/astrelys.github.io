import SpectralComparison.StrictFrame

noncomputable section
open Finset
namespace SpectralComparison

/-- Small harmonic deficit forces the explicit finite-frame improvement in the actual worst error. -/
theorem strict_small_deficit_error {k m : ℕ} (hk : 2≤k) (hm : 2≤m)
    (a : Fin (k+m) → ℝ) (ha : ∀ i,0<a i) (horder : Antitone a) (hroot : waterSum a 1=k) :
    let S := Finset.univ.filter (fun i => 1<a i)
    let T := ∑ i∈Finset.univ\S,a i
    let D := (m:ℝ)/((k:ℝ)+m)*((S.card:ℝ)+T)-symmetricQuotient (Finset.univ.val.map a) k
    D<strictEta k m → (k:ℝ)+m+strictGap k m/2≤worstError a k := by
  classical
  let S := Finset.univ.filter (fun i => 1<a i)
  let T := ∑ i∈Finset.univ\S,a i
  let D := (m:ℝ)/((k:ℝ)+m)*((S.card:ℝ)+T)-symmetricQuotient (Finset.univ.val.map a) k
  change D<strictEta k m → _
  intro hsmall
  obtain ⟨hg,hN,hη,hL2,hLN,hLH,hη1,hη2,hη3,hη4⟩ := strict_constants hk hm
  have hk0 : 0<(k:ℝ) := by exact_mod_cast (by omega : 0<k)
  have hm0 : 0<(m:ℝ) := by exact_mod_cast (by omega : 0<m)
  have hn0 : 0<(k:ℝ)+m := add_pos hk0 hm0
  have hLp : 0<strictL k m := lt_of_lt_of_le (by norm_num) hL2
  have hbound : D<(k:ℝ)/(2*((k:ℝ)+m)) := by
    apply hsmall.trans_le (hη1.trans _)
    exact div_le_div_of_nonneg_left hk0.le (by positivity) (by nlinarith)
  have hexp : (2:ℝ)^(k+m+1)*D≤1/strictL k m := by
    have hpow : 0<(2:ℝ)^(k+m+1) := by positivity
    have hd := (le_div_iff₀ (mul_pos hpow hLp)).mp (hsmall.le.trans hη2)
    apply (le_div_iff₀ hLp).mpr
    nlinarith
  have hshape := original_stable_shape a ha horder (by omega) (by omega) (by omega) hroot (lt_of_lt_of_le (by norm_num : (1:ℝ)<2) hL2)
  simp only [Nat.add_sub_cancel_left,Nat.cast_add] at hshape
  change D<(k:ℝ)/(2*((k:ℝ)+m)) → (2:ℝ)^(k+m+1)*D≤1/strictL k m → _ at hshape
  obtain ⟨hhead,hall⟩ := hshape hbound hexp
  let b := 1-strictGap k m/(4*strictN k m)
  have hb : 0<b := by
    have hh : strictGap k m<4*strictN k m := by dsimp [strictN] at *; linarith
    have hf := (div_lt_one (by positivity : 0<4*strictN k m)).mpr hh
    dsimp [b]
    linarith
  have hb1 : b≤1 := by
    have hh : 0≤strictGap k m/(4*strictN k m) := by positivity
    dsimp [b]
    linarith
  have hcut : b≤1-((k:ℝ)+m)*D/k := by
    have hd := (le_div_iff₀ (by positivity : 0<4*((k:ℝ)+m)*strictN k m)).mp (hsmall.le.trans hη3)
    have hscale : ((k:ℝ)+m)*D/k≤strictGap k m/(4*strictN k m) := by
      apply (div_le_div_iff₀ hk0 (by positivity)).mpr
      nlinarith
    dsimp [b]
    linarith
  have hp : ∀ i,0<strictL k m*twoLevelSpectrum k m (b/strictL k m) i := by
    intro i
    dsimp [twoLevelSpectrum]
    split <;> positivity
  have hcomp : ∀ i,strictL k m*twoLevelSpectrum k m (b/strictL k m) i≤a i := by
    intro i
    dsimp [twoLevelSpectrum]
    split_ifs with hi
    · simpa only [mul_one] using hhead i hi
    · rw [mul_div_cancel₀ _ hLp.ne']
      exact hcut.trans (hall i)
  have hmono := worstError_mono _ a hp ha hcomp (k:=k) (by simp; omega)
  have hframe := strict_finite_frame_bound hk hm hb hb1 (by linarith : 1≤strictL k m)
  have hfrac : (strictH k m)^2/strictL k m≤strictGap k m/4 := by
    have hh := (div_le_iff₀ hg).mp hLH
    apply (div_le_iff₀ hLp).mpr
    nlinarith
  have hbN : b*strictN k m=strictN k m-strictGap k m/4 := by dsimp [b]; field_simp
  have hlower : (k:ℝ)+m+strictGap k m/2≤b*strictN k m-(strictH k m)^2/strictL k m := by
    rw [hbN]
    dsimp [strictN]
    linarith
  exact hlower.trans (hframe.trans hmono)

end SpectralComparison
