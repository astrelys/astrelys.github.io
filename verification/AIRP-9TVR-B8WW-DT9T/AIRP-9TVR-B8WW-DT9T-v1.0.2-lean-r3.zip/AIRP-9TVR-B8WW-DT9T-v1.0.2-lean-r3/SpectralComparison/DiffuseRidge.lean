import SpectralComparison.RobustFrame
import SpectralComparison.Ridge

/-! The regularized ridge endpoint of the diffuse construction, including singular Grams. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- The robust inverse-trace scale and the group mass floor imply the exact diffuse ridge floor. -/
theorem diffuse_ridge_lower {l r : Type*} [Fintype l] [Fintype r] [DecidableEq l] [DecidableEq r]
    {k q : ℕ} (hk : 1≤k) (G : Matrix l r ℝ) {a s v : ℝ}
    (ha : 0<a) (hs : 0<s) (hv : s/(8*k)≤v)
    (htrace : IsUnit (Gᴴ*G) →
      (k:ℝ)^2/(4000000000000000000000000000*((q:ℝ)+Real.sqrt k))≤(Gᴴ*G)⁻¹.trace)
    (T : Matrix r l ℝ) :
    let V := (k:ℝ)*s/(64000000000000000000000000000*((q:ℝ)+Real.sqrt k)*H (8*k))
    a*V/(a+V)≤a*(((1 : Matrix r r ℝ)-T*G)*((1 : Matrix r r ℝ)-T*G)ᴴ).trace+v*(T*Tᴴ).trace := by
  have hkR : (0:ℝ)<k := by exact_mod_cast (show 0<k by omega)
  have hv0 : 0<v := lt_of_lt_of_le (by positivity) hv
  let C := 4000000000000000000000000000*((q:ℝ)+Real.sqrt k)
  let Z := (k:ℝ)*s/(8*C)
  let V := (k:ℝ)*s/(16*C*H (8*k))
  have hC : 0<C := by dsimp [C]; positivity
  have hZ : 0<Z := by dsimp [Z]; positivity
  have hH : 1≤H (8*k) := one_le_H (by omega)
  have hV : 0<V := by dsimp [V]; positivity
  have hVZ : V≤Z := by
    have he : V=Z/(2*H (8*k)) := by dsimp [V,Z]; simp only [div_eq_mul_inv,_root_.mul_inv_rev]; ring
    rw [he]
    apply (div_le_iff₀ (by positivity)).mpr
    nlinarith
  have hbound : a*Z/(a+Z)≤a*(((1 : Matrix r r ℝ)-T*G)*((1 : Matrix r r ℝ)-T*G)ᴴ).trace+v*(T*Tᴴ).trace := by
    apply ridge_error_lower G ha hv0 hZ _ T
    intro hu
    have hBps := Matrix.posSemidef_conjTranspose_mul_self G
    have hscaled := (hBps.smul (inv_pos.mpr hv0).le).posDef_iff_isUnit.mpr hu
    have hB : (Gᴴ*G).PosDef := by
      have hh := hscaled.smul hv0
      simpa only [smul_smul,mul_inv_cancel₀ hv0.ne',one_smul] using hh
    rw [inverse_positive_smul hB (inv_ne_zero hv0.ne'),inv_inv,Matrix.trace_smul]
    calc
      Z = (s/(8*k))*((k:ℝ)^2/C) := by dsimp [Z]; field_simp
      _ ≤ v*((k:ℝ)^2/C) := mul_le_mul_of_nonneg_right hv (by positivity)
      _ ≤ v*(Gᴴ*G)⁻¹.trace := mul_le_mul_of_nonneg_left (htrace hB.isUnit) hv0.le
  have hh := (parallel_sum_mono ha le_rfl hV hVZ).trans hbound
  have hVc : V=(k:ℝ)*s/(64000000000000000000000000000*((q:ℝ)+Real.sqrt k)*H (8*k)) := by
    dsimp [V,C]
    congr 1
    ring
  rw [hVc] at hh
  exact hh

/-- One Lemma 5.1 frame works for every admissible heavy/light kernel compression and predictor.
No nonsingularity condition on the compressed Gram appears in the conclusion. -/
theorem exists_diffuse_ridge_frame {k q : ℕ} (hk : 1≤k) (hq : 4*q≤k) :
    ∃ Q : Matrix (Fin (2*k)) (Fin (k-q)) ℝ, Qᴴ*Q=1 ∧
      (∀ J : Finset (Fin (2*k)),J.card≤k-q →
        (Q.submatrix (fun i : J => (i:Fin (2*k))) id*(Q.submatrix (fun i : J => (i:Fin (2*k))) id)ᴴ).PosDef) ∧
      ∀ Hs L : Finset (Fin (2*k)),Disjoint Hs L → 4*Hs.card≤k → Hs.card+L.card≤k →
      ∀ U : Matrix (Fin (k-q)) (Fin (k-q-Hs.card)) ℝ,Uᴴ*U=1 →
        Q.submatrix (fun i : Hs => (i:Fin (2*k))) id*U=0 →
      ∀ a s v : ℝ,0<a → 0<s → s/(8*k)≤v →
      ∀ T : Matrix (Fin (k-q-Hs.card)) L ℝ,
        let G := Q.submatrix (fun i : L => (i:Fin (2*k))) id*U
        let V := (k:ℝ)*s/(64000000000000000000000000000*((q:ℝ)+Real.sqrt k)*H (8*k))
        a*V/(a+V)≤a*(((1 : Matrix (Fin (k-q-Hs.card)) (Fin (k-q-Hs.card)) ℝ)-T*G)*
          ((1 : Matrix (Fin (k-q-Hs.card)) (Fin (k-q-Hs.card)) ℝ)-T*G)ᴴ).trace+v*(T*Tᴴ).trace := by
  obtain ⟨Q,hQ,hrows,hkernel,_hweights⟩ := paper_lemma_5_1 hk (show 2*q≤k by omega)
  refine ⟨Q,hQ,hrows,?_⟩
  intro Hs L hdis hh hl U hU hHU a s v ha hs hv T
  apply diffuse_ridge_lower hk _ ha hs hv _ T
  intro hu
  exact hkernel Hs L hdis hh hl U hU hHU ((Matrix.posSemidef_conjTranspose_mul_self _).posDef_iff_isUnit.mpr hu)

end SpectralComparison
