import SpectralComparison.GaussianPolynomial
import SpectralComparison.InverseTraceTail

/-! Almost-sure full row rank of rectangular independent standard Gaussian matrices. -/
noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

/-- The symbolic rectangular Gram determinant evaluates to the literal Gram determinant. -/
theorem eval_gram_determinant {ι κ : Type*} [Fintype ι] [Fintype κ] [DecidableEq ι]
    (x : ι × κ → ℝ) :
    MvPolynomial.eval x (Matrix.det
      ((Matrix.of (fun i j => MvPolynomial.X (i,j)) : Matrix ι κ (MvPolynomial (ι × κ) ℝ)) *
       (Matrix.of (fun i j => MvPolynomial.X (i,j)) : Matrix ι κ (MvPolynomial (ι × κ) ℝ))ᵀ)) =
      Matrix.det ((Matrix.of (fun i j => x (i,j))) * (Matrix.of (fun i j => x (i,j)))ᵀ) := by
  rw [RingHom.map_det]
  congr 1
  ext i j
  simp [RingHom.mapMatrix_apply, Matrix.mul_apply]

/-- Rectangular identity rows witness that the Gram determinant is a nonzero polynomial. -/
theorem gram_determinant_polynomial_ne_zero {ι κ : Type*} [Fintype ι] [Fintype κ]
    [DecidableEq ι] [DecidableEq κ] (e : ι ↪ κ) :
    Matrix.det
      ((Matrix.of (fun i j => MvPolynomial.X (i,j)) : Matrix ι κ (MvPolynomial (ι × κ) ℝ)) *
       (Matrix.of (fun i j => MvPolynomial.X (i,j)) : Matrix ι κ (MvPolynomial (ι × κ) ℝ))ᵀ) ≠ 0 := by
  intro h
  let x : ι × κ → ℝ := fun a => if e a.1 = a.2 then 1 else 0
  have hx : (Matrix.of (fun i j => x (i,j))) * (Matrix.of (fun i j => x (i,j)))ᵀ = (1 : Matrix ι ι ℝ) := by
    ext i j
    simp [x, Matrix.mul_apply, Matrix.one_apply, e.injective.eq_iff]
  have hv := congrArg (MvPolynomial.eval x) h
  rw [eval_gram_determinant, hx, Matrix.det_one, map_zero] at hv
  exact one_ne_zero hv

/-- Every rectangular Gaussian Gram matrix with at least as many columns as rows is
positive definite almost surely, with no rank hypothesis in the input. -/
theorem gaussian_gram_posDef_ae {Ω ι κ : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype ι] [Fintype κ]
    [DecidableEq ι] [DecidableEq κ] (e : ι ↪ κ) (W : Ω → Matrix ι κ ℝ)
    (hW : ∀ a : ι × κ, HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : ι × κ => fun ω => W ω a.1 a.2) μ) :
    ∀ᵐ ω ∂μ, (W ω*(W ω)ᴴ).PosDef := by
  have h := gaussian_polynomial_ae_ne_zero (fun a : ι × κ => fun ω => W ω a.1 a.2)
    hW hind _ (gram_determinant_polynomial_ne_zero e)
  filter_upwards [h] with ω hω
  rw [eval_gram_determinant] at hω
  have he : Matrix.of (fun i j => W ω i j) = W ω := by ext i j; rfl
  rw [he] at hω
  exact (Matrix.posSemidef_self_mul_conjTranspose (W ω)).posDef_iff_det_ne_zero.mpr
    (by simpa only [Matrix.conjTranspose_eq_transpose_of_trivial] using hω)

/-- Gaussian inverse-trace tail with the actual row-by-column dimension in the exponent.
The full-rank condition has been discharged internally. This local estimate is not yet
Lemma 3.1's sharper q+sqrt(p) threshold for the original matrix. -/
theorem gaussian_inverse_trace_tail_500 {Ω ι κ : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype ι] [Fintype κ]
    [DecidableEq ι] [DecidableEq κ] (e : ι ↪ κ) (W : Ω → Matrix ι κ ℝ)
    (hW : ∀ a : ι × κ, HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : ι × κ => fun ω => W ω a.1 a.2) μ)
    (hmeas : ∀ a : ι × κ, Measurable (fun ω => W ω a.1 a.2))
    (hi : 0 < Fintype.card ι) (hk : 0 < Fintype.card κ) :
    μ.real {ω | (W ω*(W ω)ᴴ)⁻¹.trace ≤ (Fintype.card ι:ℝ)/(500*(Fintype.card κ:ℝ))} ≤
      Real.exp (-124*((Fintype.card ι:ℝ)*(Fintype.card κ:ℝ))) := by
  have hpos := gaussian_gram_posDef_ae e W hW hind
  have hm : μ {ω | (W ω*(W ω)ᴴ)⁻¹.trace ≤ (Fintype.card ι:ℝ)/(500*(Fintype.card κ:ℝ))} ≤
      μ {ω | (W ω*(W ω)ᴴ).PosDef ∧
        (W ω*(W ω)ᴴ)⁻¹.trace ≤ (Fintype.card ι:ℝ)/(500*(Fintype.card κ:ℝ))} := by
    apply measure_mono_ae
    filter_upwards [hpos] with ω hω
    exact fun ht => ⟨hω,ht⟩
  exact (ENNReal.toReal_mono (measure_ne_top _ _) hm).trans
    (gaussian_inverse_trace_tail_on_posDef W hW hind hmeas hi hk)

end SpectralComparison
