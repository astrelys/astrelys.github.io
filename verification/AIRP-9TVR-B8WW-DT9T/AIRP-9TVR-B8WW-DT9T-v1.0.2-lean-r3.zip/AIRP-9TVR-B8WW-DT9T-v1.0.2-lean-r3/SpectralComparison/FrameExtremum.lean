import SpectralComparison.TwoLevelTheorem
import Mathlib.Topology.Semicontinuity.Basic

/-! Finiteness of the paper's real-valued frame supremum, without an assumed boundedness premise. -/
noncomputable section
open Matrix Filter Topology
namespace SpectralComparison

/-- Rectangular Parseval frames form a compact set in the entrywise topology. -/
theorem parseval_set_isCompact (n d : ℕ) :
    IsCompact {Q : Matrix (Fin n) (Fin d) ℝ | Qᴴ*Q=1} := by
  have hc : IsClosed {Q : Matrix (Fin n) (Fin d) ℝ | Qᴴ*Q=1} :=
    isClosed_eq (continuous_id.matrix_conjTranspose.matrix_mul continuous_id) continuous_const
  apply (isCompact_Icc : IsCompact (Set.Icc (fun (_ : Fin n) (_ : Fin d) => (-1:ℝ))
    (fun (_ : Fin n) (_ : Fin d) => (1:ℝ)))).of_isClosed_subset hc
  intro Q hQ
  change (Matrix.of Q)ᴴ*Matrix.of Q=(1 : Matrix (Fin d) (Fin d) ℝ) at hQ
  have he (i : Fin n) (j : Fin d) : Q i j*Q i j≤1 := by
    have hs := congrArg (fun A : Matrix (Fin d) (Fin d) ℝ => A j j) hQ
    simp only [Matrix.mul_apply,Matrix.conjTranspose_apply,star_trivial,Matrix.one_apply_eq] at hs
    change (∑ x, Q x j * Q x j) = 1 at hs
    have h := Finset.single_le_sum (fun l (_ : l∈(Finset.univ : Finset (Fin n))) => mul_self_nonneg (Q l j)) (Finset.mem_univ i)
    rwa [hs] at h
  constructor <;> intro i j <;> have h := he i j <;> nlinarith

/-- The admissible minimum is upper semicontinuous at a Parseval frame: use an attained nonsingular basis locally. -/
theorem frameBasisMinimum_upperSemicontinuousAt {n d : ℕ} (Q : Matrix (Fin n) (Fin d) ℝ)
    (hQ : Qᴴ*Q=1) : UpperSemicontinuousAt frameBasisMinimum Q := by
  classical
  intro b hb
  obtain ⟨I,hI,hu,he⟩ := frameBasisMinimum_attained Q hQ
  let G := fun W : Matrix (Fin n) (Fin d) ℝ =>
    (W*Wᴴ).submatrix (fun i : I => (i:Fin n)) (fun i : I => (i:Fin n))
  have hg : Continuous G := (continuous_id.matrix_mul continuous_id.matrix_conjTranspose).matrix_submatrix _ _
  have hdet : (G Q).det≠0 := isUnit_iff_ne_zero.mp ((Matrix.isUnit_iff_isUnit_det _).mp hu)
  have hi : ContinuousAt (fun W => (G W)⁻¹) Q := by
    apply (continuousAt_matrix_inv (G Q) ?_).comp hg.continuousAt
    rw [show (Ring.inverse : ℝ → ℝ)=(fun x => x⁻¹) from funext Ring.inverse_eq_inv]
    exact continuousAt_inv₀ hdet
  have ht : ContinuousAt (fun W => (G W)⁻¹.trace) Q := continuous_id.matrix_trace.continuousAt.comp hi
  have hlt : ∀ᶠ W in 𝓝 Q,(G W)⁻¹.trace<b := ht.eventually (eventually_lt_nhds (by simpa only [he] using hb))
  have hne : ∀ᶠ W in 𝓝 Q,(G W).det≠0 := hg.matrix_det.continuousAt.eventually (eventually_ne_nhds hdet)
  filter_upwards [hlt,hne] with W hw hwu
  exact (frameBasisMinimum_le_basis W I hI ((Matrix.isUnit_iff_isUnit_det _).mpr (isUnit_iff_ne_zero.mpr hwu))).trans_lt hw

/-- The real-valued h(Q) range is bounded above uniformly over every Parseval frame. -/
theorem frameBasisMinimum_bddAbove (n d : ℕ) :
    BddAbove (frameBasisMinimum '' {Q : Matrix (Fin n) (Fin d) ℝ | Qᴴ*Q=1}) := by
  apply UpperSemicontinuousOn.bddAbove_of_isCompact (parseval_set_isCompact n d)
  intro Q hQ b hb
  exact (frameBasisMinimum_upperSemicontinuousAt Q hQ b hb).filter_mono nhdsWithin_le_nhds

/-- The paper's M_(n,d), as a finite real supremum over exactly the Parseval frames. -/
def frameExtremum (n d : ℕ) : ℝ :=
  sSup (frameBasisMinimum '' {Q : Matrix (Fin n) (Fin d) ℝ | Qᴴ*Q=1})

theorem frameBasisMinimum_le_extremum {n d : ℕ} (Q : Matrix (Fin n) (Fin d) ℝ) (hQ : Qᴴ*Q=1) :
    frameBasisMinimum Q≤frameExtremum n d := by
  exact le_csSup (frameBasisMinimum_bddAbove n d) ⟨Q,hQ,rfl⟩

/-- The square-basis theorem including its real-supremum consequence, with no boundedness premise. -/
theorem paper_balanced_frame_real {k : ℕ} (hk : 4≤k) :
    (∃ Q : Matrix (Fin (2*k)) (Fin k) ℝ, Qᴴ*Q=1 ∧
      (∀ J : Finset (Fin (2*k)), J.card=k →
        IsUnit ((Q*Qᴴ).submatrix (fun i : J => (i:Fin (2*k))) (fun i : J => (i:Fin (2*k))))) ∧
      (k:ℝ)*Real.sqrt k/4000000000≤frameBasisMinimum Q) ∧
    (k:ℝ)*Real.sqrt k/4000000000≤frameExtremum (2*k) k := by
  obtain ⟨⟨Q,hQ,hrows,hmin⟩,_⟩ := paper_balanced_frame hk
  exact ⟨⟨Q,hQ,hrows,hmin⟩,hmin.trans (frameBasisMinimum_le_extremum Q hQ)⟩

/-- The first replication lower bound, with its original real-valued supremum and actual witness. -/
theorem paper_replication_lower_real {n d : ℕ} (hd : 1≤d) (hn : 2*d≤n) :
    (∃ Q : Matrix (Fin n) (Fin d) ℝ, Qᴴ*Q=1 ∧
      (n:ℝ)*Real.sqrt d/16000000000≤frameBasisMinimum Q) ∧
    (n:ℝ)*Real.sqrt d/16000000000≤frameExtremum n d := by
  obtain ⟨⟨Q,hQ,hmin⟩,_⟩ := paper_replication_lower hd hn
  exact ⟨⟨Q,hQ,hmin⟩,hmin.trans (frameBasisMinimum_le_extremum Q hQ)⟩

/-- The complementary-rank lower bound, with its original real-valued supremum and actual witness. -/
theorem paper_replication_complementary_real {n k : ℕ} (hk : 1≤k) (hkn : k<n) :
    (∃ Q : Matrix (Fin n) (Fin k) ℝ, Qᴴ*Q=1 ∧
      max (((n-k:ℕ):ℝ)-(k:ℝ)) 0+(n:ℝ)*Real.sqrt (min k (n-k):ℕ)/16000000000 ≤
      ((n-k:ℕ):ℝ)-(k:ℝ)+frameBasisMinimum Q) ∧
    max (((n-k:ℕ):ℝ)-(k:ℝ)) 0+(n:ℝ)*Real.sqrt (min k (n-k):ℕ)/16000000000 ≤
      ((n-k:ℕ):ℝ)-(k:ℝ)+frameExtremum n k := by
  obtain ⟨Q,hQ,hmin⟩ := exists_frame_complementary_rank_bound hk hkn
  exact ⟨⟨Q,hQ,hmin⟩,by linarith [frameBasisMinimum_le_extremum Q hQ]⟩

end SpectralComparison
