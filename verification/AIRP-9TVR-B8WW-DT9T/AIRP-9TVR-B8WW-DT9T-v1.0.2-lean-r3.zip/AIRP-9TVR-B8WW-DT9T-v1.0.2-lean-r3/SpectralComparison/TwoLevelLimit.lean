import SpectralComparison.TwoLevelAsymptotics
import Mathlib.Topology.Order.LiminfLimsup

/-! The asymptotic two-level ratio from actual frames and an explicit smooth upper envelope. -/
noncomputable section
open Filter Topology Matrix
namespace SpectralComparison

/-- A realized inverse-basis lower bound controls the actual error at every positive noise <=1. -/
theorem two_level_worst_lower_of_frame {k m : ℕ} (hm : 1≤m)
    (Q : Matrix (Fin (k+m)) (Fin k) ℝ) (hQ : Qᴴ*Q=1)
    {L : ℝ} (hL : 0<L)
    (hb : ∀ I : Finset (Fin (k+m)), I.card=k →
      IsUnit ((Q*Qᴴ).submatrix (fun i : I => (i:Fin (k+m))) (fun i : I => (i:Fin (k+m)))) →
      L≤((Q*Qᴴ).submatrix (fun i : I => (i:Fin (k+m))) (fun i : I => (i:Fin (k+m))))⁻¹.trace)
    {ε : ℝ} (hε : 0<ε) (hε1 : ε≤1) :
    ε*((m:ℝ)-(k:ℝ)+L/(1+ε*L))≤worstError (twoLevelSpectrum k m ε) k := by
  apply le_trans _ (two_level_frame_bestError_le hm Q hQ hε)
  apply le_bestError _ (by simp)
  intro I hI
  rw [paper_two_level_residual (by omega) Q hQ hε hε1 I hI]
  simp only [Nat.add_sub_cancel_left]
  exact mul_le_mul_of_nonneg_left (add_le_add (le_refl _) (two_level_principal_lower Q hL hε hε1 hb I hI)) hε.le

/-- A genuine one-sided limsup bound, with all boundedness conditions supplied. -/
theorem two_level_limsup_of_frame {k m : ℕ} (hm : 1≤m)
    (Q : Matrix (Fin (k+m)) (Fin k) ℝ) (hQ : Qᴴ*Q=1)
    {L : ℝ} (hL : 0<L) (hD : 0<(m:ℝ)-(k:ℝ)+L)
    (hb : ∀ I : Finset (Fin (k+m)), I.card=k →
      IsUnit ((Q*Qᴴ).submatrix (fun i : I => (i:Fin (k+m))) (fun i : I => (i:Fin (k+m)))) →
      L≤((Q*Qᴴ).submatrix (fun i : I => (i:Fin (k+m))) (fun i : I => (i:Fin (k+m))))⁻¹.trace) :
    Filter.limsup (fun ε : ℝ => spectralMean (twoLevelSpectrum k m ε) k/worstError (twoLevelSpectrum k m ε) k)
      (𝓝[>] 0)≤((k:ℝ)+1)*(m:ℝ)/((m:ℝ)-(k:ℝ)+L) := by
  let D := fun ε : ℝ => (m:ℝ)-(k:ℝ)+L/(1+ε*L)
  let U := fun ε : ℝ => (spectralMean (twoLevelSpectrum k m ε) k/ε)/D ε
  have hcont : ContinuousAt D 0 := by
    exact continuousAt_const.add (continuousAt_const.div (continuousAt_const.add (continuousAt_id.mul continuousAt_const)) (by simp))
  have hd : Tendsto D (𝓝[>] (0:ℝ)) (𝓝 ((m:ℝ)-(k:ℝ)+L)) := by
    simpa [D] using hcont.tendsto.mono_left (nhdsWithin_le_nhds (s:=Set.Ioi (0:ℝ)))
  have hu : Tendsto U (𝓝[>] (0:ℝ)) (𝓝 (((k:ℝ)+1)*(m:ℝ)/((m:ℝ)-(k:ℝ)+L))) :=
    (two_level_spectralMean_div_tendsto k m).div hd hD.ne'
  have hnoise : ∀ᶠ ε : ℝ in 𝓝[>] 0,0<ε ∧ ε≤1 := by
    filter_upwards [self_mem_nhdsWithin,(eventually_lt_nhds (by norm_num : (0:ℝ)<1)).filter_mono nhdsWithin_le_nhds] with ε hpos hlt
    exact ⟨hpos,hlt.le⟩
  have hden : ∀ᶠ ε : ℝ in 𝓝[>] 0,0<D ε := hd.eventually (eventually_gt_nhds hD)
  have hpos : ∀ᶠ ε : ℝ in 𝓝[>] 0,
      0<worstError (twoLevelSpectrum k m ε) k ∧ 0≤spectralMean (twoLevelSpectrum k m ε) k := by
    filter_upwards [hnoise] with ε hε
    have hl := (two_level_tail_bounds (k:=k) hm hε.1 hε.2).1
    have hm0 : (0:ℝ)<m := by exact_mod_cast (by omega : 0<m)
    have hx := (mul_pos hm0 hε.1).trans_le hl
    exact ⟨hx,hx.le.trans (worstError_le_spectralMean _ (twoLevelSpectrum_pos hε.1) (by simp; omega))⟩
  have hbound : ∀ᶠ ε : ℝ in 𝓝[>] 0,
      spectralMean (twoLevelSpectrum k m ε) k/worstError (twoLevelSpectrum k m ε) k≤U ε := by
    filter_upwards [hnoise,hden,hpos] with ε hε hdε hpε
    have hx := two_level_worst_lower_of_frame hm Q hQ hL hb hε.1 hε.2
    have hh := div_le_div_of_nonneg_left hpε.2 (mul_pos hε.1 hdε) hx
    apply hh.trans_eq
    dsimp only [U]
    rw [div_div]
  have hc : (𝓝[>] (0:ℝ)).IsCoboundedUnder (·≤·)
      (fun ε => spectralMean (twoLevelSpectrum k m ε) k/worstError (twoLevelSpectrum k m ε) k) := by
    apply isCoboundedUnder_le_of_eventually_le (𝓝[>] (0:ℝ)) (x:=(0:ℝ))
    filter_upwards [hpos] with ε hε
    exact div_nonneg hε.2 hε.1.le
  have h := limsup_le_limsup hbound hc hu.isBoundedUnder_le
  rwa [hu.limsup_eq] at h

end SpectralComparison
