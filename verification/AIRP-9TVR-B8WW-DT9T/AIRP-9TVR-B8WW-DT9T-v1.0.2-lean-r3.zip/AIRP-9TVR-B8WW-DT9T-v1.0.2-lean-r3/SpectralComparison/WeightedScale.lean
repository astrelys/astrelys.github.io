import SpectralComparison.WeightedSums
import SpectralComparison.WeightedPrefix

noncomputable section
open Finset Matrix
namespace SpectralComparison

/-- One actual prefix maximizes the weighted scale and pays the exact two finite-sum constants. -/
theorem exists_weighted_prefix_scale {k h : ℕ} (hk : 1≤k) (hh : 1≤h)
    (b : Fin h → ℝ) (hb : ∀ i,0<b i) :
    ∃ i : Fin h,
      let W := ((k:ℝ)+(i.val:ℝ)+1)*Real.sqrt (min k (i.val+1):ℕ)*b i
      (h≤k → (∑ j,b j)≤(2*Real.sqrt h/k)*W) ∧
      (h≤8*k → (∑ j,b j)≤(4/Real.sqrt k)*W) := by
  classical
  let A := fun i : Fin h => ((k:ℝ)+(i.val:ℝ)+1)*Real.sqrt (min k (i.val+1):ℕ)
  have hA : ∀ i,0<A i := by
    intro i
    have hn : 0<min k (i.val+1) := lt_min (by omega) (by omega)
    have hs : 0<Real.sqrt (min k (i.val+1):ℕ) := Real.sqrt_pos.mpr (by exact_mod_cast hn)
    dsimp [A]
    positivity
  obtain ⟨i,_,hi⟩ := Finset.exists_max_image Finset.univ (fun i : Fin h => A i*b i)
    ⟨⟨0,by omega⟩,Finset.mem_univ _⟩
  let W := A i*b i
  have hW : 0<W := mul_pos (hA i) (hb i)
  have hpoint (j : Fin h) : b j≤1/A j*W := by
    rw [one_div,mul_comm (A j)⁻¹ W,← div_eq_mul_inv]
    exact (le_div_iff₀ (hA j)).mpr (by simpa only [W,mul_comm] using hi j (Finset.mem_univ j))
  have hs : (∑ j,b j)≤(∑ j,1/A j)*W := by
    rw [Finset.sum_mul]
    exact Finset.sum_le_sum (fun j _ => hpoint j)
  have he : (∑ j : Fin h,1/A j)=
      ∑ j∈Finset.range h,1/(((k:ℝ)+(j:ℝ)+1)*Real.sqrt (min k (j+1):ℕ)) :=
    Fin.sum_univ_eq_sum_range (fun j => 1/(((k:ℝ)+(j:ℝ)+1)*Real.sqrt (min k (j+1):ℕ))) h
  refine ⟨i,?_,?_⟩
  · intro hhk
    have hc := weighted_denominator_small hk hhk
    rw [← he] at hc
    exact hs.trans (mul_le_mul_of_nonneg_right hc hW.le)
  · intro hh8
    have hc := weighted_denominator_large hk hh8
    rw [← he] at hc
    exact hs.trans (mul_le_mul_of_nonneg_right hc hW.le)

/-- The E.1 bound whenever all weights fit in the small-dimensional prefix regime. -/
theorem weighted_frame_small {k m : ℕ} (hk : 1≤k) (hm : 1≤m) (hmk : m≤k)
    (b : Fin m → ℝ) (hb : ∀ i,0<b i) (horder : Antitone b) :
    ∃ R : Matrix (Fin (k+m)) (Fin m) ℝ,Rᴴ*R=1 ∧
      ∀ J : Finset (Fin (k+m)),J.card=m →
        IsUnit ((R.submatrix (fun i : J => (i:Fin (k+m))) id)ᴴ*R.submatrix (fun i : J => (i:Fin (k+m))) id) →
        weightedGamma k m*(∑ i,b i)≤(Matrix.diagonal b*
          ((R.submatrix (fun i : J => (i:Fin (k+m))) id)ᴴ*R.submatrix (fun i : J => (i:Fin (k+m))) id)⁻¹).trace := by
  obtain ⟨i,hscale,_⟩ := exists_weighted_prefix_scale hk hm b hb
  have ht : i.val+1≤m := by have := i.isLt; omega
  have hhead : ∀ j : Fin (i.val+1),b i≤b (j.castLE ht) := by
    intro j
    apply horder
    change j.val ≤ i.val
    have := j.isLt
    omega
  obtain ⟨R,hR,hcost⟩ := exists_weighted_prefix_frame hk (by omega) ht b hb (hb i).le hhead
  refine ⟨R,hR,?_⟩
  intro J hJ hu
  apply le_trans _ (hcost J hJ hu)
  have hs := hscale hmk
  have hk0 : 0<(k:ℝ) := by exact_mod_cast (by omega : 0<k)
  have hm0 : 0<(m:ℝ) := by exact_mod_cast (by omega : 0<m)
  have hsm : 0<Real.sqrt (m:ℝ) := Real.sqrt_pos.mpr hm0
  dsimp only [weightedGamma]
  rw [ite_eq_left hmk]
  have hmul := (le_div_iff₀ hk0).mp (show (∑ j,b j)≤
      (2*Real.sqrt m*(((k:ℝ)+(i.val:ℝ)+1)*Real.sqrt (min k (i.val+1):ℕ)*b i))/k by convert hs using 1 <;> ring)
  rw [Nat.cast_add,Nat.cast_one]
  apply (le_div_iff₀ (by norm_num : (0:ℝ)<16000000000)).mpr
  have hleft : ((k:ℝ)/(32000000000*Real.sqrt m)*(∑ j,b j))*16000000000=
      ((k:ℝ)*(∑ j,b j))/(2*Real.sqrt m) := by field_simp; ring
  rw [hleft]
  apply (div_le_iff₀ (by positivity)).mpr
  nlinarith

end SpectralComparison
