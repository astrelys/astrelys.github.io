import SpectralComparison.SpectrumExtension

/-! The actual prescribed-spectrum orientation giving the finite-noise bound for each prefix. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- The regularized inverse bound in the covariance scales a,b is their parallel-sum expression. -/
theorem regularization_parallel_sum {a b L : ℝ} (ha : 0<a) (hb : 0<b) (hL : 0<L) :
    L/(b⁻¹+a⁻¹*L)=a*(b*L)/(a+b*L) := by
  have hd : 0<a+b*L := by positivity
  have he : 0<b⁻¹+a⁻¹*L := by positivity
  field_simp

/-- For every prefix length, construct one full-spectrum orientation controlling every original selection. -/
theorem exists_prefix_orientation {n k q t : ℕ} (eig : Fin n → ℝ) (heig : ∀ i,0<eig i)
    (horder : Antitone eig) (hk : 1≤k) (hq : 2*q≤k) (ht : 1≤t) (htn : k+t≤n) :
    ∃ V : Matrix (Fin n) (Fin n) ℝ, V.transpose*V=1 ∧
      ∀ I : Finset (Fin n), I.card=k →
      let a := eig ⟨k-q-1,by omega⟩
      let b := eig ⟨k+t-1,by omega⟩
      let L := (k:ℝ)*t/(32000000000000000000000000000*((q:ℝ)+Real.sqrt k))
      a*(b*L)/(a+b*L)≤residualTrace (V.transpose*Matrix.diagonal eig*V) I := by
  classical
  obtain ⟨P,hP,hPP,hr,hblocks,hreg⟩ := paper_lemma_6_1 hk hq ht
  let f : Fin (k+t) → Fin n := Fin.castLE htn
  let eig0 : Fin (k+t) → ℝ := fun i => eig (f i)
  let a := eig ⟨k-q-1,by omega⟩
  let b := eig ⟨k+t-1,by omega⟩
  let L := (k:ℝ)*t/(32000000000000000000000000000*((q:ℝ)+Real.sqrt k))
  have ha : 0<a := heig _
  have hb : 0<b := heig _
  have hL : 0<L := by
    dsimp [L]
    apply div_pos
    · exact mul_pos (by exact_mod_cast (show 0<k by omega)) (by exact_mod_cast (show 0<t by omega))
    · apply mul_pos (by norm_num)
      exact add_pos_of_nonneg_of_pos (Nat.cast_nonneg q) (Real.sqrt_pos.mpr (by exact_mod_cast (show 0<k by omega)))
  let I0 := Finset.Iio (⟨k-q,by omega⟩ : Fin (k+t))
  have hI0 : I0.card=k-q := Fin.card_Iio _
  have hleft : ∀ i∈I0, a≤eig0 i := by
    intro i hi
    apply horder
    have hh : i<(⟨k-q,by omega⟩ : Fin (k+t)) := Finset.mem_Iio.mp hi
    change i.val<k-q at hh
    change i.val≤k-q-1
    omega
  have hright : ∀ i∉I0, b≤eig0 i := by
    intro i _
    apply horder
    change i.val≤k+t-1
    omega
  obtain ⟨V0,hV0,hK0,hgap⟩ := exists_prescribed_covariance hP hPP I0
    (by rw [hr,hI0]; omega) eig0 (fun i => heig _) ha hb hleft hright
  let K0 := V0.transpose*Matrix.diagonal eig0*V0
  have hbound : ∀ J : Finset (Fin (k+t)), J.card=t →
      a*(b*L)/(a+b*L)≤(K0⁻¹.submatrix (fun i : J => (i:Fin (k+t))) (fun i : J => (i:Fin (k+t))))⁻¹.trace := by
    intro J hJ
    rw [← regularization_parallel_sum ha hb hL]
    exact hreg K0⁻¹ a⁻¹ b⁻¹ hK0.inv (inv_pos.mpr ha) (inv_pos.mpr hb) hgap J hJ
  let e : (Fin (k+t) ⊕ Fin (n-(k+t))) ≃ Fin n :=
    finSumFinEquiv.trans (finCongr (Nat.add_sub_of_le htn))
  have he (i : Fin (k+t)) : e (Sum.inl i)=f i := by apply Fin.ext; rfl
  obtain ⟨W,hW,hprecision⟩ := extend_prefix_orientation e eig heig V0 hV0
  have hprec : ((W.transpose*Matrix.diagonal eig*W)⁻¹).submatrix f f=K0⁻¹ := by
    simpa only [he] using hprecision
  refine ⟨W,hW,?_⟩
  intro I hI
  apply residual_lower_of_embedded_precision (orbit_posDef eig heig W hW) f (Fin.castLE_injective htn) ?_ I hI
  intro J hJ
  rw [hprec]
  exact hbound J hJ

/-- Paper equation (6.5) for every prefix, on the literal worst-orientation Nyström objective. -/
theorem prefix_fixed_length_bound {n k q t : ℕ} (eig : Fin n → ℝ) (heig : ∀ i,0<eig i)
    (horder : Antitone eig) (hk : 1≤k) (hq : 2*q≤k) (ht : 1≤t) (htn : k+t≤n) :
    let a := eig ⟨k-q-1,by omega⟩
    let b := eig ⟨k+t-1,by omega⟩
    let L := (k:ℝ)*t/(32000000000000000000000000000*((q:ℝ)+Real.sqrt k))
    a*(b*L)/(a+b*L)≤worstError eig k := by
  obtain ⟨V,hV,hb⟩ := exists_prefix_orientation eig heig horder hk hq ht htn
  exact (le_bestError _ (by simp; omega) hb).trans
    (orbit_bestError_le_worstError eig heig V hV (by simp; omega))

end SpectralComparison
