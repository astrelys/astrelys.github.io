import SpectralComparison
import Mathlib.RingTheory.MvPolynomial.Symmetric.Defs

/-! Actual elementary symmetric polynomials for positive finite multisets.
This establishes Lemma 8.1 and coefficient log-concavity (8.2),
including support edges and repeated eigenvalues. -/
namespace SpectralComparison

/-- Adding one entry to the elementary symmetric generating polynomial. -/
theorem esymm_cons (s : Multiset ℝ) (z : ℝ) (n : ℕ) :
    (z ::ₘ s).esymm (n+1) = s.esymm (n+1) + z * s.esymm n := by
  simp [Multiset.esymm, Multiset.map_map, Multiset.sum_map_mul_left]

theorem esymm_nonneg (s : Multiset ℝ) (hs : ∀ z ∈ s, 0 ≤ z) (n : ℕ) :
    0 ≤ s.esymm n := by
  induction s using Multiset.induction_on generalizing n with
  | empty =>
    cases n with
    | zero => simp
    | succ n => rw [Multiset.esymm_of_card_lt (by simp)]
  | @cons z s ih =>
    have hz : 0 ≤ z := hs z (by simp)
    have hst : ∀ w ∈ s, 0 ≤ w := fun w hw => hs w (by simp [hw])
    cases n with
    | zero => simp
    | succ n =>
      rw [esymm_cons]
      exact add_nonneg (ih hst _) (mul_nonneg hz (ih hst _))

theorem esymm_pos (s : Multiset ℝ) (hs : ∀ z ∈ s, 0 < z)
    (n : ℕ) (hn : n ≤ s.card) : 0 < s.esymm n := by
  induction s using Multiset.induction_on generalizing n with
  | empty =>
    have hn0 : n = 0 := by simpa using hn
    simp [hn0]
  | @cons z s ih =>
    have hz : 0 < z := hs z (by simp)
    have hst : ∀ w ∈ s, 0 < w := fun w hw => hs w (by simp [hw])
    cases n with
    | zero => simp
    | succ n =>
      have hn' : n ≤ s.card := by simpa using hn
      rw [esymm_cons]
      exact add_pos_of_nonneg_of_pos
        (esymm_nonneg s (fun w hw => (hst w hw).le) _) (mul_pos hz (ih hst n hn'))

/-- Equation (8.2) for every positive finite multiset, not assumed coefficients.
The index n+1 covers positive centers; the zero center has a zero left neighbor. -/
theorem esymm_logconcave (s : Multiset ℝ) (hs : ∀ z ∈ s, 0 < z) (n : ℕ) :
    s.esymm n * s.esymm (n+2) ≤ (s.esymm (n+1))^2 := by
  induction s using Multiset.induction_on generalizing n with
  | empty =>
    rw [Multiset.esymm_of_card_lt (show (0 : Multiset ℝ).card < n+2 by simp),
      Multiset.esymm_of_card_lt (show (0 : Multiset ℝ).card < n+1 by simp)]
    simp
  | @cons z s ih =>
    have hz : 0 < z := hs z (by simp)
    have hst : ∀ w ∈ s, 0 < w := fun w hw => hs w (by simp [hw])
    have hnonneg := esymm_nonneg s (fun w hw => (hst w hw).le)
    cases n with
    | zero =>
      have hprev := ih hst 0
      simp only [Multiset.esymm_zero, one_mul] at hprev
      simp only [Multiset.esymm_zero, one_mul, esymm_cons, mul_one]
      have hc1 := hnonneg 1
      nlinarith
    | succ n =>
      have hleft := ih hst n
      have hright := ih hst (n+1)
      have hcross : s.esymm n * s.esymm (n+3) ≤ s.esymm (n+2) * s.esymm (n+1) := by
        by_cases hnd : n+3 ≤ s.card
        · have hb := esymm_pos s hst (n+1) (by omega)
          have hc := esymm_pos s hst (n+2) (by omega)
          have hh := logconcavity_cross hb hc (hnonneg (n+3)) hleft hright
          nlinarith
        · have hd : s.esymm (n+3) = 0 := Multiset.esymm_of_card_lt (by omega)
          rw [hd, mul_zero]
          exact mul_nonneg (hnonneg _) (hnonneg _)
      have hstep := coefficient_append_nonnegative hz.le hright hcross hleft
      simpa only [Nat.succ_eq_add_one, Nat.add_assoc, esymm_cons] using hstep

/-- The inclusion-probability comparison in Lemma 8.1 with the actual
    elementary symmetric coefficients; n+1 is the paper's k. -/
theorem esymm_inclusion_probability_le (s : Multiset ℝ)
    (hs : ∀ w ∈ s, 0 < w) {z : ℝ} (hz : 0 < z)
    (n : ℕ) (hn : n+1 ≤ s.card) :
    z*s.esymm n / (z ::ₘ s).esymm (n+1) ≤
      z / (z + (z ::ₘ s).esymm (n+2) / (z ::ₘ s).esymm (n+1)) := by
  rw [esymm_cons, show n+2=(n+1)+1 by omega, esymm_cons]
  apply inclusion_probability_le (esymm_pos s hs (n+1) hn)
    (esymm_nonneg s (fun w hw => (hs w hw).le) _)
    (esymm_pos s hs n (by omega)) hz
  nlinarith [esymm_logconcave s hs n]


/-- Degree-one coefficient is the sum of the list. -/
theorem esymm_one (s : Multiset ℝ) : s.esymm 1 = s.sum := by
  simp [Multiset.esymm, Multiset.powersetCard_one, Multiset.map_map]

/-- Adding a nonnegative entry cannot decrease any coefficient. -/
theorem esymm_le_cons (s : Multiset ℝ) (hs : ∀ w ∈ s, 0 ≤ w)
    {z : ℝ} (hz : 0 ≤ z) (k : ℕ) : s.esymm k ≤ (z ::ₘ s).esymm k := by
  cases k with
  | zero => simp
  | succ k =>
    rw [esymm_cons]
    exact le_add_of_nonneg_right (mul_nonneg hz (esymm_nonneg s hs k))

/-- Weighted inclusion counts sum to k, before dividing by e_k.
    Multiset erasure removes one copy, so repeated eigenvalues are supported. -/
theorem esymm_weighted_count (s : Multiset ℝ) (n : ℕ) :
    (s.map (fun z => z * (s.erase z).esymm n)).sum =
      ((n:ℝ)+1) * s.esymm (n+1) := by
  classical
  induction s using Multiset.induction_on generalizing n with
  | empty =>
    rw [Multiset.esymm_of_card_lt (show (0 : Multiset ℝ).card < n+1 by simp)]
    simp
  | @cons z s ih =>
    cases n with
    | zero => simp [esymm_one]
    | succ n =>
      rw [Multiset.map_cons, Multiset.sum_cons, Multiset.erase_cons_head]
      have hmap :
          (s.map (fun w => w * ((z ::ₘ s).erase w).esymm (n+1))).sum =
          (s.map (fun w => w * (s.erase w).esymm (n+1) +
            z * (w * (s.erase w).esymm n))).sum := by
        congr 1
        apply Multiset.map_congr rfl
        intro w hw
        rw [Multiset.erase_cons_tail_of_mem hw, esymm_cons]
        ring
      rw [hmap, Multiset.sum_map_add, Multiset.sum_map_mul_left, ih, ih, esymm_cons]
      push_cast
      ring

/-- Coefficient bound obtained from any k-entry head and its complementary tail.
    This is the counting argument used for F ≤ s in Lemma 8.1. -/
theorem esymm_tail_bound (head tail : Multiset ℝ)
    (hh : ∀ z ∈ head, 0 ≤ z) (ht : ∀ z ∈ tail, 0 ≤ z) :
    (head+tail).esymm (head.card+1) ≤ tail.sum * (head+tail).esymm head.card := by
  induction tail using Multiset.induction_on with
  | empty => simp [Multiset.esymm_of_card_lt]
  | @cons z tail ih =>
    have hz : 0 ≤ z := ht z (by simp)
    have htt : ∀ w ∈ tail, 0 ≤ w := fun w hw => ht w (by simp [hw])
    have hall : ∀ w ∈ head+tail, 0 ≤ w := by
      intro w hw
      rcases Multiset.mem_add.mp hw with hw | hw
      · exact hh w hw
      · exact htt w hw
    have hs : 0 ≤ tail.sum := Multiset.sum_nonneg htt
    have hprev := ih htt
    have hmono := esymm_le_cons (head+tail) hall hz head.card
    rw [Multiset.add_cons, esymm_cons, Multiset.sum_cons]
    calc
      (head+tail).esymm (head.card+1) + z*(head+tail).esymm head.card
          ≤ (z+tail.sum)*(head+tail).esymm head.card := by nlinarith
      _ ≤ (z+tail.sum)*(z ::ₘ (head+tail)).esymm head.card :=
        mul_le_mul_of_nonneg_left hmono (add_nonneg hz hs)

/-- First assertion of (8.1), with the quotient and tail literally defined by
    elementary symmetric coefficients and a k-element head. -/
theorem symmetric_quotient_le_tail (head tail : Multiset ℝ)
    (hh : ∀ z ∈ head, 0 < z) (ht : ∀ z ∈ tail, 0 < z) :
    (head+tail).esymm (head.card+1) / (head+tail).esymm head.card ≤ tail.sum := by
  have hall : ∀ w ∈ head+tail, 0 < w := by
    intro w hw
    rcases Multiset.mem_add.mp hw with hw | hw
    · exact hh w hw
    · exact ht w hw
  have hden := esymm_pos (head+tail) hall head.card (by simp)
  apply (div_le_iff₀ hden).2
  exact esymm_tail_bound head tail (fun z hz => (hh z hz).le) (fun z hz => (ht z hz).le)


/-- Summed inclusion comparison: sum_i eig_i/(eig_i+F) ≥ k. -/
theorem symmetric_quotient_sum_lower (s : Multiset ℝ)
    (hs : ∀ z ∈ s, 0 < z) (n : ℕ) (hn : n+2 ≤ s.card) :
    (n:ℝ)+1 ≤ (s.map (fun z =>
      z / (z + s.esymm (n+2) / s.esymm (n+1)))).sum := by
  classical
  have hden := esymm_pos s hs (n+1) (by omega)
  have hterm : ∀ z ∈ s,
      z*(s.erase z).esymm n / s.esymm (n+1) ≤
        z/(z+s.esymm (n+2)/s.esymm (n+1)) := by
    intro z hz
    have hst : ∀ w ∈ s.erase z, 0 < w :=
      fun w hw => hs w (Multiset.mem_of_mem_erase hw)
    have hcard : n+1 ≤ (s.erase z).card := by
      have he := Multiset.card_erase_add_one hz
      omega
    have he := esymm_inclusion_probability_le (s.erase z) hst (hs z hz) n hcard
    simpa only [Multiset.cons_erase hz] using he
  have hh := Multiset.sum_map_le_sum_map _ _ hterm
  have hcount : (s.map (fun z => z*(s.erase z).esymm n / s.esymm (n+1))).sum =
      (n:ℝ)+1 := by
    simp only [div_eq_mul_inv, Multiset.sum_map_mul_right, esymm_weighted_count]
    field_simp
  rwa [hcount] at hh

/-- Second assertion of (8.1) for a positive head/tail decomposition.
No ordering hypothesis is needed; it therefore includes the ordered paper case. -/
theorem symmetric_quotient_head_sum_le_tail (head tail : Multiset ℝ)
    (hh : ∀ z ∈ head, 0 < z) (ht : ∀ z ∈ tail, 0 < z)
    (hk : 1 ≤ head.card) (hm : 1 ≤ tail.card) :
    let F := (head+tail).esymm (head.card+1) / (head+tail).esymm head.card
    (head.map (fun z => F/(z+F))).sum ≤ tail.sum/F := by
  classical
  let F := (head+tail).esymm (head.card+1) / (head+tail).esymm head.card
  change (head.map (fun z => F/(z+F))).sum ≤ tail.sum/F
  have hall : ∀ w ∈ head+tail, 0 < w := by
    intro w hw
    rcases Multiset.mem_add.mp hw with hw | hw
    · exact hh w hw
    · exact ht w hw
  have hF : 0 < F := div_pos
    (esymm_pos (head+tail) hall (head.card+1) (by simp; omega))
    (esymm_pos (head+tail) hall head.card (by simp))
  have hsum : (head.card:ℝ) ≤ (head.map (fun z => z/(z+F))).sum +
      (tail.map (fun z => z/(z+F))).sum := by
    obtain ⟨n, hn⟩ := Nat.exists_eq_succ_of_ne_zero (show head.card ≠ 0 by omega)
    have hc : n+2 ≤ (head+tail).card := by simp; omega
    have hp := symmetric_quotient_sum_lower (head+tail) hall n hc
    simpa [F, hn, Nat.succ_eq_add_one, Nat.add_assoc, Multiset.map_add] using hp
  have hcomplement : (head.map (fun z => F/(z+F))).sum +
      (head.map (fun z => z/(z+F))).sum = (head.card:ℝ) := by
    rw [← Multiset.sum_map_add]
    have hmap : head.map (fun z => F/(z+F)+z/(z+F)) = head.map (fun _ => (1:ℝ)) := by
      apply Multiset.map_congr rfl
      intro z hz
      have hd : z+F ≠ 0 := ne_of_gt (add_pos (hh z hz) hF)
      field_simp
      ring
    rw [hmap]
    simp
  have htail : (tail.map (fun z => z/(z+F))).sum ≤ tail.sum/F := by
    calc
      (tail.map (fun z => z/(z+F))).sum ≤ (tail.map (fun z => z/F)).sum := by
        apply Multiset.sum_map_le_sum_map
        intro z hz
        exact div_le_div_of_nonneg_left (ht z hz).le hF (le_add_of_nonneg_left (ht z hz).le)
      _ = tail.sum/F := by simp [div_eq_mul_inv, Multiset.sum_map_mul_right]
  linarith

/-- Lemma 8.1 in full, for actual elementary symmetric polynomials.
The paper uses the k largest entries as head. This stronger formulation allows
any positive head of cardinality k and any nonempty positive tail. -/
theorem elementary_symmetric_quotient (head tail : Multiset ℝ)
    (hh : ∀ z ∈ head, 0 < z) (ht : ∀ z ∈ tail, 0 < z)
    (hk : 1 ≤ head.card) (hm : 1 ≤ tail.card) :
    let F := (head+tail).esymm (head.card+1) / (head+tail).esymm head.card
    F ≤ tail.sum ∧ (head.map (fun z => F/(z+F))).sum ≤ tail.sum/F := by
  exact ⟨symmetric_quotient_le_tail head tail hh ht,
    symmetric_quotient_head_sum_le_tail head tail hh ht hk hm⟩

end SpectralComparison
