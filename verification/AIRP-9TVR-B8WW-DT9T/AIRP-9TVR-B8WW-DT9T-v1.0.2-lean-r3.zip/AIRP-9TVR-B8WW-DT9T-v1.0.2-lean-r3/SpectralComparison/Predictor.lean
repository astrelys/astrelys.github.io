import SpectralComparison.MatrixRegularization

/-! Prediction-error minimization underlying paper equation (7.7). -/
noncomputable section
namespace SpectralComparison
open Matrix Finset
variable {ι κ : Type*} [Fintype ι] [DecidableEq ι] [Fintype κ] [DecidableEq κ]

/-- Exact covariance completion of the square for an arbitrary observation matrix. -/
theorem predictor_completion_square {K : Matrix ι ι ℝ} (hK : K.PosDef)
    (E : Matrix κ ι ℝ) (hA : (E * K * E.conjTranspose).PosDef) (L : Matrix ι κ ℝ) :
    let A := E * K * E.conjTranspose
    let R := K * E.conjTranspose * A⁻¹
    ((1 : Matrix ι ι ℝ)-L*E)*K*((1 : Matrix ι ι ℝ)-L*E).conjTranspose =
      K-R*E*K + (L-R)*A*(L-R).conjTranspose := by
  let A := E * K * E.conjTranspose
  let R := K * E.conjTranspose * A⁻¹
  change ((1 : Matrix ι ι ℝ)-L*E)*K*((1 : Matrix ι ι ℝ)-L*E).conjTranspose = K-R*E*K+(L-R)*A*(L-R).conjTranspose
  let _ : Invertible A := hA.isUnit.invertible
  have hRA : R*A = K*E.conjTranspose := by
    exact Matrix.inv_mul_cancel_right_of_invertible A _
  have hA' : A.PosDef := hA
  have hRh : R.conjTranspose = A⁻¹*E*K := by
    simp only [R, Matrix.conjTranspose_mul, hA'.inv.isHermitian.eq,
      Matrix.conjTranspose_conjTranspose, hK.isHermitian.eq, Matrix.mul_assoc]
  have hARh : A*R.conjTranspose = E*K := by
    rw [hRh, Matrix.mul_assoc A⁻¹ E K]
    exact Matrix.mul_inv_cancel_left_of_invertible A _
  have hleft : ((1 : Matrix ι ι ℝ)-L*E)*K*((1 : Matrix ι ι ℝ)-L*E).conjTranspose =
      K-L*E*K-K*E.conjTranspose*L.conjTranspose+L*A*L.conjTranspose := by
    simp only [Matrix.conjTranspose_sub, Matrix.conjTranspose_one, Matrix.conjTranspose_mul,
      Matrix.sub_mul, Matrix.mul_sub, Matrix.one_mul, Matrix.mul_one, A, Matrix.mul_assoc]
    abel
  rw [hleft]
  simp only [Matrix.conjTranspose_sub, Matrix.sub_mul, Matrix.mul_sub]
  rw [Matrix.mul_assoc L A R.conjTranspose,
    Matrix.mul_assoc R A R.conjTranspose, hARh, hRA]
  simp only [Matrix.mul_assoc]
  abel

/-- The literal optimal predictor minimizes the trace, with an attained minimum. -/
theorem predictor_minimum {K : Matrix ι ι ℝ} (hK : K.PosDef)
    (E : Matrix κ ι ℝ) (hA : (E*K*E.conjTranspose).PosDef) :
    let R := K*E.conjTranspose*(E*K*E.conjTranspose)⁻¹
    (∀ L : Matrix ι κ ℝ, (K-R*E*K).trace ≤ (((1 : Matrix ι ι ℝ)-L*E)*K*((1 : Matrix ι ι ℝ)-L*E).conjTranspose).trace) ∧
    (((1 : Matrix ι ι ℝ)-R*E)*K*((1 : Matrix ι ι ℝ)-R*E).conjTranspose).trace = (K-R*E*K).trace := by
  dsimp only
  constructor
  · intro L
    rw [predictor_completion_square hK E hA L, Matrix.trace_add]
    exact le_add_of_nonneg_right
      (hA.posSemidef.mul_mul_conjTranspose_same _).trace_nonneg
  · rw [predictor_completion_square hK E hA]
    simp

/-- The coordinate observation matrix selects the rows indexed by I. -/
def coordinateObservation (I : Finset ι) : Matrix I ι ℝ :=
  (1 : Matrix ι ι ℝ).submatrix Subtype.val id

/-- Coordinate observation produces exactly the principal covariance block. -/
theorem coordinate_observation_covariance (K : Matrix ι ι ℝ) (I : Finset ι) :
    coordinateObservation I * K * (coordinateObservation I).conjTranspose = principal K I := by
  have he : (coordinateObservation I).conjTranspose = (1 : Matrix ι ι ℝ).submatrix id Subtype.val := by
    simp [coordinateObservation]
  rw [he]
  change (1 : Matrix ι ι ℝ).submatrix Subtype.val (Equiv.refl ι) * K *
    (1 : Matrix ι ι ℝ).submatrix (Equiv.refl ι) Subtype.val = _
  rw [Matrix.one_submatrix_mul, Matrix.mul_submatrix_one]
  rfl

/-- Equation (7.7): Nyström trace error is precisely the attained minimum
of the prediction covariance trace over every real predictor matrix. -/
theorem paper_equation_7_7 {K : Matrix ι ι ℝ} (hK : K.PosDef) (I : Finset ι) :
    (∀ L : Matrix ι I ℝ, residualTrace K I ≤
      (((1 : Matrix ι ι ℝ)-L*coordinateObservation I)*K*((1 : Matrix ι ι ℝ)-L*coordinateObservation I).conjTranspose).trace) ∧
    ∃ L : Matrix ι I ℝ, residualTrace K I =
      (((1 : Matrix ι ι ℝ)-L*coordinateObservation I)*K*((1 : Matrix ι ι ℝ)-L*coordinateObservation I).conjTranspose).trace := by
  let E := coordinateObservation I
  have hA : (E*K*E.conjTranspose).PosDef := by
    rw [coordinate_observation_covariance]
    exact principal_posDef hK I
  have he : E.conjTranspose = (1 : Matrix ι ι ℝ).submatrix id Subtype.val := by
    simp [E, coordinateObservation]
  have hres : K-K*E.conjTranspose*(E*K*E.conjTranspose)⁻¹*E*K = residual K I := by
    rw [coordinate_observation_covariance, he]
    have hrow : E*K = K.submatrix Subtype.val id := by
      exact Matrix.one_submatrix_mul _ (Equiv.refl ι) K
    have hcol : K*(1 : Matrix ι ι ℝ).submatrix id (fun i : I => i.val) = K.submatrix id Subtype.val := by
      exact Matrix.mul_submatrix_one (Equiv.refl ι) _ K
    rw [hcol, Matrix.mul_assoc _ E K, hrow]
    rfl
  have h := predictor_minimum hK E hA
  change (∀ L, (K-K*E.conjTranspose*(E*K*E.conjTranspose)⁻¹*E*K).trace ≤ _) ∧ _ at h
  rw [hres] at h
  exact ⟨h.1, ⟨K*E.conjTranspose*(E*K*E.conjTranspose)⁻¹, h.2.symm⟩⟩

/-- Restricting to any injectively selected coordinates decreases inverse trace. -/
theorem inverse_trace_submatrix_le {T : Matrix ι ι ℝ} (hT : T.PosDef)
    (e : κ → ι) (he : Function.Injective e) :
    (T.submatrix e e)⁻¹.trace ≤ T⁻¹.trace := by
  let U : Matrix ι κ ℝ := (1 : Matrix ι ι ℝ).submatrix id e
  have hUt : U.conjTranspose = (1 : Matrix ι ι ℝ).submatrix e id := by simp [U]
  have hU : U.conjTranspose*U = 1 := by
    rw [hUt]
    change (1 : Matrix ι ι ℝ).submatrix e (Equiv.refl ι) * U = _
    rw [Matrix.one_submatrix_mul]
    exact Matrix.submatrix_one e he
  have hcomp : U.conjTranspose*T*U = T.submatrix e e := by
    rw [hUt]
    change (1 : Matrix ι ι ℝ).submatrix e (Equiv.refl ι) * T *
      (1 : Matrix ι ι ℝ).submatrix (Equiv.refl ι) e = _
    rw [Matrix.one_submatrix_mul, Matrix.mul_submatrix_one]
    rfl
  simpa only [hcomp] using inverse_trace_compression hT U hU

omit [Fintype ι] in
/-- A nested principal inverse trace is at most that of the larger principal block. -/
theorem inverse_trace_nested_principal {T : Matrix ι ι ℝ} (hT : T.PosDef)
    {I J : Finset ι} (hIJ : I ⊆ J) :
    (principal T I)⁻¹.trace ≤ (principal T J)⁻¹.trace := by
  let e : I → J := fun i => ⟨i.val, hIJ i.property⟩
  have he : Function.Injective e := by
    intro i j h
    exact Subtype.ext (congrArg (fun z : J => (z : ι)) h)
  exact inverse_trace_submatrix_le (principal_posDef hT J) e he

/-- The inverse-precision trace on any subset of unselected coordinates
is a lower bound for the original Nyström error, as used in (6.5). -/
theorem nystrom_error_ge_principal_inverse {K : Matrix ι ι ℝ} (hK : K.PosDef)
    (I J : Finset ι) (hJ : J ⊆ Finset.univ \ I) :
    (principal K⁻¹ J)⁻¹.trace ≤ residualTrace K I := by
  rw [nystrom_trace_inverse_complement hK I]
  exact inverse_trace_nested_principal hK.inv hJ

/-- Actual Nyström errors are nonnegative, by their attained prediction representation. -/
theorem residualTrace_nonneg {K : Matrix ι ι ℝ} (hK : K.PosDef) (I : Finset ι) :
    0 ≤ residualTrace K I := by
  obtain ⟨L, hL⟩ := (paper_equation_7_7 hK I).2
  rw [hL]
  exact (hK.posSemidef.mul_mul_conjTranspose_same _).trace_nonneg

end SpectralComparison
