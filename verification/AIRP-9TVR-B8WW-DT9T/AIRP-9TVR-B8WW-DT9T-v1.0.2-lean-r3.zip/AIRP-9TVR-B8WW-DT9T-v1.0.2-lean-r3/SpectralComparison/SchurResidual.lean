import SpectralComparison.Nystrom

/-! Exact complement-inverse formula for the literal Nystrom residual (2.2). -/
noncomputable section
namespace SpectralComparison
open Matrix Finset
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- A coordinate set and its complement partition the matrix index type. -/
def partitionEquiv (I : Finset ι) : I ⊕ ↥(Finset.univ \ I) ≃ ι where
  toFun := fun x => match x with | Sum.inl i => i.val | Sum.inr j => j.val
  invFun := fun x => if h : x ∈ I then Sum.inl ⟨x,h⟩ else Sum.inr ⟨x, by simp [h]⟩
  left_inv := by
    intro x
    cases x with
    | inl i => simp [i.property]
    | inr j => simp [(Finset.mem_sdiff.mp j.property).2]
  right_inv := by
    intro x
    dsimp
    split_ifs <;> rfl

/-- The inverse of the lower-right inverse block is the Schur complement. -/
theorem schur_eq_inverse_inverse_block {m n : Type*} [Fintype m] [Fintype n]
    [DecidableEq m] [DecidableEq n] (A : Matrix m m ℝ) (B : Matrix m n ℝ)
    (C : Matrix n m ℝ) (D : Matrix n n ℝ)
    (hA : A.PosDef) (hM : (Matrix.fromBlocks A B C D).PosDef) :
    D - C * A⁻¹ * B = ((Matrix.fromBlocks A B C D)⁻¹.submatrix Sum.inr Sum.inr)⁻¹ := by
  let _ : Invertible A := hA.isUnit.invertible
  let _ : Invertible (Matrix.fromBlocks A B C D) := hM.isUnit.invertible
  let _ : Invertible (D - C * ⅟A * B) := Matrix.invertibleOfFromBlocks₁₁Invertible A B C D
  have hf := Matrix.invOf_fromBlocks₁₁_eq A B C D
  have hi := congrArg (fun M : Matrix (m ⊕ n) (m ⊕ n) ℝ => M.submatrix Sum.inr Sum.inr) hf
  change (⅟(Matrix.fromBlocks A B C D)).submatrix Sum.inr Sum.inr = ⅟(D - C * ⅟A * B) at hi
  have hS : IsUnit (D - C * A⁻¹ * B) := by
    simpa only [Matrix.invOf_eq_nonsing_inv] using (isUnit_of_invertible (D - C * ⅟A * B))
  let _ : Invertible (D - C * A⁻¹ * B) := hS.invertible
  simp only [Matrix.invOf_eq_nonsing_inv] at hi
  rw [hi, Matrix.inv_inv_of_invertible]


/-- The full unselected residual block equals the inverse of the complementary block of K inverse. -/
theorem residual_complement_eq_inverse {K : Matrix ι ι ℝ} (hK : K.PosDef) (I : Finset ι) :
    principal (residual K I) (Finset.univ \ I) = (principal K⁻¹ (Finset.univ \ I))⁻¹ := by
  let J := Finset.univ \ I
  let A := principal K I
  let B := K.submatrix (fun i : I => i.val) (fun j : J => j.val)
  let C := K.submatrix (fun j : J => j.val) (fun i : I => i.val)
  let D := principal K J
  let e := partitionEquiv I
  have he : K.submatrix e e = Matrix.fromBlocks A B C D := by
    ext a b
    cases a <;> cases b <;> rfl
  have hm : (Matrix.fromBlocks A B C D).PosDef := by
    rw [← he]
    exact hK.submatrix e.injective
  have hs := schur_eq_inverse_inverse_block A B C D (principal_posDef hK I) hm
  have hi : (Matrix.fromBlocks A B C D)⁻¹.submatrix Sum.inr Sum.inr = principal K⁻¹ J := by
    rw [← he, Matrix.inv_submatrix_equiv]
    rfl
  rw [hi] at hs
  change principal (residual K I) J = _
  rw [← hs]
  ext a b
  simp only [principal, residual, Matrix.submatrix_apply, Matrix.sub_apply,
    Matrix.mul_apply, id_eq, A, B, C, D]

/-- Paper equation (2.2), including empty selected or complementary blocks. -/
theorem nystrom_trace_inverse_complement {K : Matrix ι ι ℝ} (hK : K.PosDef) (I : Finset ι) :
    residualTrace K I = ((principal K⁻¹ (Finset.univ \ I))⁻¹).trace := by
  rw [← residual_complement_eq_inverse hK I, residualTrace_eq_complement_sum hK]
  exact (Finset.sum_coe_sort (Finset.univ \ I) (fun j => residual K I j j)).symm

end SpectralComparison
