import SpectralComparison.FrameExtremum

noncomputable section
open Matrix
namespace SpectralComparison

theorem frameExtremum_complement_le {n k d : ℕ} (hk : 1 ≤ k) (hd : 1 ≤ d) (hdim : k+d=n) :
    frameExtremum n d ≤ frameExtremum n k-(k:ℝ)+(d:ℝ) := by
  obtain ⟨⟨Q0,hQ0,_⟩,_⟩ := paper_replication_complementary_real (n:=n) hd (by omega)
  have hne : (frameBasisMinimum '' {Q : Matrix (Fin n) (Fin d) ℝ | Qᴴ*Q=1}).Nonempty :=
    ⟨_,Q0,hQ0,rfl⟩
  apply csSup_le hne
  rintro _ ⟨Q,hQ,rfl⟩
  obtain ⟨R,hR,hb⟩ := exists_complementary_frame_control hdim Q hQ
    (fun J hJ hu => frameBasisMinimum_le_basis Q J hJ hu)
  have hl := le_frameBasisMinimum R hR hb
  have hu := frameBasisMinimum_le_extremum R hR
  linarith

/-- Exact real-supremum complementary rank identity A.1. -/
theorem paper_frame_complement_identity {n k : ℕ} (hk : 1 ≤ k) (hkn : k < n) :
    frameExtremum n k = frameExtremum n (n-k)+(k:ℝ)-(n-k:ℕ) := by
  have h1 := frameExtremum_complement_le hk (show 1 ≤ n-k by omega) (show k+(n-k)=n by omega)
  have h2 := frameExtremum_complement_le (show 1 ≤ n-k by omega) hk (show (n-k)+k=n by omega)
  linarith

end SpectralComparison
