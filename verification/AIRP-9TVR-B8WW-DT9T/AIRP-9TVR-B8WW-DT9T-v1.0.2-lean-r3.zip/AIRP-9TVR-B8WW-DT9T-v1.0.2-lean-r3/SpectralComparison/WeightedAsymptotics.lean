import SpectralComparison.ShiftedPrecision

noncomputable section
open Filter Topology
namespace SpectralComparison

/-- Leading coefficient for arbitrary fixed head and scaled tail, including shifted degrees. -/
theorem scaled_tail_esymm_limit (a b : Multiset ℝ) (q : ℕ) :
    Tendsto (fun ε : ℝ => (a+b.map (fun z => ε*z)).esymm (a.card+q)/ε^q)
      (𝓝[>] 0) (𝓝 (a.prod*b.esymm q)) := by
  induction a using Multiset.induction_on generalizing q with
  | empty =>
    apply tendsto_const_nhds.congr'
    filter_upwards [self_mem_nhdsWithin] with ε hε
    have hn : ε≠0 := ne_of_gt hε
    simp only [zero_add,Multiset.card_zero,Multiset.prod_zero,one_mul]
    have he : (b.map (fun z => ε*z)).esymm q=ε^q*b.esymm q := (Multiset.pow_smul_esymm ε q b).symm
    rw [he]
    simp [hn]
  | @cons z a ih =>
    have h0 : Tendsto (fun ε : ℝ => ε) (𝓝[>] 0) (𝓝 0) := tendsto_id.mono_left nhdsWithin_le_nhds
    have h := (h0.mul (ih (q+1))).add ((ih q).const_mul z)
    simp only [zero_mul,zero_add,Multiset.prod_cons] at h ⊢
    have hh : z*(a.prod*b.esymm q)=(z*a.prod)*b.esymm q := by ring
    rw [hh] at h
    apply h.congr'
    filter_upwards [self_mem_nhdsWithin] with ε hε
    have hn : ε≠0 := ne_of_gt hε
    simp only [Multiset.card_cons,Multiset.cons_add]
    rw [show a.card+1+q=(a.card+q)+1 by omega,esymm_cons]
    have he : a.card+(q+1)=a.card+q+1 := by omega
    rw [he,pow_succ]
    field_simp

/-- Two fixed positive spectral groups, with only the second group scaled. -/
def splitSpectrum {h m n : ℕ} (e : Fin h ⊕ Fin m ≃ Fin n)
    (a : Fin h → ℝ) (b : Fin m → ℝ) (ε : ℝ) : Fin n → ℝ :=
  fun i => Sum.elim a (fun j => ε*b j) (e.symm i)

theorem splitSpectrum_multiset {h m n : ℕ} (e : Fin h ⊕ Fin m ≃ Fin n)
    (a : Fin h → ℝ) (b : Fin m → ℝ) (ε : ℝ) :
    Finset.univ.val.map (splitSpectrum e a b ε)=Finset.univ.val.map a+(Finset.univ.val.map b).map (fun z => ε*z) := by
  have he : (Finset.univ.map e.toEmbedding : Finset (Fin n))=Finset.univ := by ext i; simp
  have hh := congrArg (fun s : Finset (Fin n) => s.val.map (splitSpectrum e a b ε)) he
  rw [Finset.map_val,Multiset.map_map] at hh
  rw [← hh]
  change (Multiset.map Sum.inl (Finset.univ : Finset (Fin h)).val+
    Multiset.map Sum.inr (Finset.univ : Finset (Fin m)).val).map (splitSpectrum e a b ε ∘ e)=_
  simp only [Multiset.map_add,Multiset.map_map,Function.comp_def,splitSpectrum,Equiv.symm_apply_apply,Sum.elim_inl,Sum.elim_inr]

theorem splitSpectrum_pos {h m n : ℕ} (e : Fin h ⊕ Fin m ≃ Fin n)
    (a : Fin h → ℝ) (b : Fin m → ℝ) (ha : ∀ i,0<a i) (hb : ∀ i,0<b i)
    {ε : ℝ} (hε : 0<ε) : ∀ i,0<splitSpectrum e a b ε i := by
  intro i
  dsimp [splitSpectrum]
  cases e.symm i with
  | inl j => exact ha j
  | inr j => exact mul_pos hε (hb j)

/-- Exact normalized y limit for arbitrary heads and tails. -/
theorem split_spectralMean_limit {h m n q : ℕ} (e : Fin h ⊕ Fin m ≃ Fin n)
    (a : Fin h → ℝ) (b : Fin m → ℝ) (ha : ∀ i,0<a i) (hb : ∀ i,0<b i) (hq : q≤m) :
    Tendsto (fun ε : ℝ => spectralMean (splitSpectrum e a b ε) (h+q)/ε)
      (𝓝[>] 0) (𝓝 (((h+q:ℕ)+1:ℝ)*(Finset.univ.val.map b).esymm (q+1)/(Finset.univ.val.map b).esymm q)) := by
  let A := Finset.univ.val.map a
  let B := Finset.univ.val.map b
  have hp : 0<A.prod := Multiset.prod_pos (by intro z hz; obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz; exact ha i)
  have he : 0<B.esymm q := esymm_pos B (by intro z hz; obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz; exact hb i) q (by simpa [B] using hq)
  have hn := scaled_tail_esymm_limit A B (q+1)
  have hd := scaled_tail_esymm_limit A B q
  have hh := (hn.const_mul ((h+q:ℕ)+1:ℝ)).div hd (mul_pos hp he).ne'
  have hv : (((h+q:ℕ)+1:ℝ)*(A.prod*B.esymm (q+1)))/(A.prod*B.esymm q)=
      (((h+q:ℕ)+1:ℝ)*B.esymm (q+1))/B.esymm q := by field_simp
  rw [hv] at hh
  apply hh.congr'
  filter_upwards [self_mem_nhdsWithin] with ε hε
  have hnz : ε≠0 := ne_of_gt hε
  simp only [Pi.div_apply,spectralMean,splitSpectrum_multiset,Finset.card_val,Multiset.card_map,Finset.card_univ,Fintype.card_fin, A,B, Nat.add_assoc,pow_succ]
  field_simp

end SpectralComparison
