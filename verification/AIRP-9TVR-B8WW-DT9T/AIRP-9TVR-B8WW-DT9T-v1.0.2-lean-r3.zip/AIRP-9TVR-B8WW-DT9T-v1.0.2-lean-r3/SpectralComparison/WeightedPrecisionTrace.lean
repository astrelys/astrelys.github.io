import SpectralComparison.WeightedFrame

noncomputable section
open Matrix
namespace SpectralComparison

/-- The covariance inverse-trace is exactly the weighted column-Gram inverse-trace. -/
theorem weighted_precision_inverse_trace {j p : Type*} [Fintype j] [Fintype p]
    [DecidableEq j] [DecidableEq p] (A : Matrix j p ℝ)
    (hc : Fintype.card j = Fintype.card p) (b : p → ℝ) (hb : ∀ i, 0 < b i)
    (hu : IsUnit (A * diagonal (fun i => (b i)⁻¹) * Aᴴ)) :
    IsUnit (Aᴴ * A) ∧
      (A * diagonal (fun i => (b i)⁻¹) * Aᴴ)⁻¹.trace =
        (diagonal b * (Aᴴ * A)⁻¹).trace := by
  let e : j ≃ p := Fintype.equivOfCardEq hc
  let T := A.submatrix id e
  have ha : A * diagonal (fun i => (b i)⁻¹) * Aᴴ =
      T * diagonal (fun i => (b (e i))⁻¹) * Tᴴ := by
    have hd : diagonal (fun i => (b (e i))⁻¹) = (diagonal (fun i => (b i)⁻¹)).submatrix e e :=
      (Matrix.submatrix_diagonal_equiv (fun i : p => (b i)⁻¹) e).symm
    rw [hd]
    change _ = A.submatrix id e * _ * (A.submatrix id e)ᴴ
    rw [Matrix.conjTranspose_submatrix, Matrix.submatrix_mul_equiv,
      Matrix.submatrix_mul_equiv, Matrix.submatrix_id_id]
  have ht : IsUnit T := by
    rw [ha, Matrix.isUnit_iff_isUnit_det, Matrix.det_mul, Matrix.det_mul] at hu
    rw [Matrix.isUnit_iff_isUnit_det, isUnit_iff_ne_zero]
    rw [isUnit_iff_ne_zero] at hu
    intro hz
    apply hu
    rw [hz, zero_mul, zero_mul]
  have hg : Tᴴ * T = (Aᴴ * A).submatrix e e := by
    rw [Matrix.conjTranspose_submatrix,
      ← Matrix.submatrix_mul _ _ e id e Function.bijective_id]
  have hgu : IsUnit (Aᴴ * A) := (Matrix.isUnit_submatrix_equiv e e).mp
    (hg ▸ (((Matrix.isUnit_conjTranspose (A:=T)).mpr ht).mul ht))
  refine ⟨hgu,?_⟩
  have hbT : (diagonal (fun i : j => (b (e i))⁻¹))⁻¹ = diagonal (fun i => b (e i)) := by
    rw [positive_diagonal_inverse _ (fun i => inv_pos.mpr (hb _))]
    simp only [one_div, inv_inv]
  have he : (diagonal b * (Aᴴ * A)⁻¹).submatrix e e =
      diagonal (fun i => b (e i)) * (Tᴴ * T)⁻¹ := by
    rw [hg, Matrix.inv_submatrix_equiv]
    have hd : diagonal (fun i : j => b (e i)) = (diagonal b).submatrix e e :=
      (Matrix.submatrix_diagonal_equiv b e).symm
    rw [hd, Matrix.submatrix_mul_equiv]
  have htrace : ((diagonal b * (Aᴴ * A)⁻¹).submatrix e e).trace =
      (diagonal b * (Aᴴ * A)⁻¹).trace := e.sum_comp (fun i => (diagonal b * (Aᴴ * A)⁻¹) i i)
  rw [← htrace, he, ha, Matrix.mul_inv_rev, Matrix.mul_inv_rev, hbT,
    Matrix.mul_inv_rev]
  rw [Matrix.trace_mul_comm]
  simp only [Matrix.mul_assoc]

end SpectralComparison
