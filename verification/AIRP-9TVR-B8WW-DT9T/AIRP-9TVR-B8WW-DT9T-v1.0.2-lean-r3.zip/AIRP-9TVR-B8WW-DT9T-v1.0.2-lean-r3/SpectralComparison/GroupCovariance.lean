import SpectralComparison.GroupAssembly
import SpectralComparison.KernelSpectrumMix
import SpectralComparison.NoiseSplit

/-! Actual group covariance with the reserved spectrum mixed into its kernel. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Equations (7.5)-(7.6) on the group coordinates, with exact spectral synthesis and signal kernel.
The singleton extension and original spectral label permutation are separate finite reindexing steps. -/
theorem exists_group_covariance {g p r h : Type*}
    [Fintype g] [Fintype p] [Fintype r] [Fintype h]
    [DecidableEq g] [DecidableEq p] [DecidableEq r] [DecidableEq h]
    (f : p → g) (d : p → ℝ) (hd : ∀ i,0<d i)
    (Q0 : Matrix g r ℝ) (hQ0 : Q0ᴴ*Q0=1)
    (hdim : Fintype.card h+Fintype.card r=Fintype.card g)
    (b : h → ℝ) (hb : ∀ i,0<b i) :
    ∃ W : Matrix (Σ j : g, Fin 1 ⊕ {i : p // f i=j}) (g ⊕ p) ℝ,
    ∃ V : Matrix (Σ j : g, Fin 1 ⊕ {i : p // f i=j}) ((r ⊕ h) ⊕ p) ℝ,
      Vᴴ*V=1 ∧ V*Vᴴ=1 ∧
      (∀ x,W x (Sum.inl x.1)≠0) ∧ (∀ x j,j≠x.1 → W x (Sum.inl j)=0) ∧
      let Q := W.submatrix id Sum.inl*Q0
      let D := W*Matrix.diagonal (Sum.elim (fun _ : g => (0:ℝ)) d)*Wᴴ
      let C := V*Matrix.diagonal (Sum.elim (Sum.elim (fun _ : r => (0:ℝ)) b) d)*Vᴴ
      Qᴴ*Q=1 ∧ C.PosSemidef ∧ Qᴴ*C=0 ∧
      (∀ x,C.mulVec x=0 ↔ ∃ y : r → ℝ,x=Q.mulVec y) ∧
      D.PosSemidef ∧ (C-D).PosSemidef ∧
      (∀ x,D x x=(∑ i : {i : p // f i=x.1},d i.val)*(W x (Sum.inl x.1))^2) ∧
      (∀ x y,x.1≠y.1 → D x y=0) ∧
      ∀ a : r → ℝ,V*Matrix.diagonal (Sum.elim (Sum.elim a b) d)*Vᴴ=Q*Matrix.diagonal a*Qᴴ+C := by
  classical
  obtain ⟨W,hW,hW',hnon,hrow,hD,hdiag,hcross⟩ := exists_assembled_group_basis f d hd
  obtain ⟨R,V,hR,hQR,hV,hV',hcol,hmix⟩ := exists_kernel_spectrum_mix W hW hW' Q0 hQ0 hdim
  let Q := W.submatrix id Sum.inl*Q0
  let D := W*Matrix.diagonal (Sum.elim (fun _ : g => (0:ℝ)) d)*Wᴴ
  let C := V*Matrix.diagonal (Sum.elim (Sum.elim (fun _ : r => (0:ℝ)) b) d)*Vᴴ
  have hcore := orthogonal_noise_split V hV hV' (Equiv.sumAssoc r h p).symm
    (Sum.elim (Sum.elim (fun _ : r => (0:ℝ)) b) d) (fun _ => rfl)
    (by intro i; cases i with | inl i => exact hb i | inr i => exact hd i)
  change _ ∧ C.PosSemidef ∧ _ ∧ _ at hcore
  have hQcol : V.submatrix id (fun i => (Equiv.sumAssoc r h p).symm (Sum.inl i))=Q := hcol
  rw [hQcol] at hcore
  have hDeq : D=W.submatrix id Sum.inr*Matrix.diagonal d*(W.submatrix id Sum.inr)ᴴ := by
    have he : W=Matrix.fromCols (W.submatrix id Sum.inl) (W.submatrix id Sum.inr) := by ext i j; cases j <;> rfl
    change W*Matrix.diagonal (Sum.elim (fun _ : g => (0:ℝ)) d)*Wᴴ=_
    conv_lhs => rw [he,fromCols_spectral_synthesis]
    simp
  have hCeq : C=(W.submatrix id Sum.inl*R)*Matrix.diagonal b*(W.submatrix id Sum.inl*R)ᴴ+D := by
    dsimp [C]
    rw [hmix]
    simp only [Matrix.diagonal_zero,Matrix.mul_zero,Matrix.zero_mul,zero_add]
    rw [hDeq]
  have hgap : (C-D).PosSemidef := by
    rw [hCeq,add_sub_cancel_right]
    exact (Matrix.PosSemidef.diagonal (fun i => (hb i).le)).mul_mul_conjTranspose_same _
  refine ⟨W,V,hV,hV',hnon,hrow,hcore.1,hcore.2.1,hcore.2.2.1,hcore.2.2.2,hD,hgap,hdiag,hcross,?_⟩
  intro a
  rw [hmix,hmix]
  simp only [Matrix.diagonal_zero,Matrix.mul_zero,Matrix.zero_mul,zero_add]
  abel

end SpectralComparison
