import SpectralComparison.StableSpectrum

noncomputable section
namespace SpectralComparison

def strictH (k m : ℕ) : ℝ := (3*(k:ℝ)+m-2+Real.sqrt (((k:ℝ)+m-2)^2+4*(k:ℝ)*m))/2
def strictGap (k m : ℕ) : ℝ := strictH k m-2*k
def strictN (k m : ℕ) : ℝ := (k:ℝ)+m+strictGap k m
def strictL (k m : ℕ) : ℝ := max 2 (max (strictN k m) (4*(strictH k m)^2/strictGap k m))
def strictEta (k m : ℕ) : ℝ := min ((k:ℝ)/(4*((k:ℝ)+m)))
  (min (1/((2:ℝ)^(k+m+1)*strictL k m))
    (min ((k:ℝ)*strictGap k m/(4*((k:ℝ)+m)*strictN k m))
      ((m:ℝ)*strictGap k m/(2*((k:ℝ)+m)+strictGap k m))))

/-- Both radicals needed by the exact frame construction have positive gaps. -/
theorem strict_radical_gaps {k m : ℕ} (hk : 2≤k) (hm : 2≤m) :
    0<strictGap k m ∧ 0<strictH k m-((k:ℝ)+m) := by
  have hkr : (2:ℝ)≤k := by exact_mod_cast hk
  have hmr : (2:ℝ)≤m := by exact_mod_cast hm
  have hp : 0≤((k:ℝ)+m-2)^2+4*(k:ℝ)*m := by positivity
  have hs := Real.sq_sqrt hp
  have hs0 := Real.sqrt_nonneg (((k:ℝ)+m-2)^2+4*(k:ℝ)*m)
  have hkm : 0<(k:ℝ)*(m-1) := mul_pos (by linarith) (by linarith)
  have hmk : 0<(m:ℝ)*(k-1) := mul_pos (by linarith) (by linarith)
  have hg : (k:ℝ)-m+2<Real.sqrt (((k:ℝ)+m-2)^2+4*(k:ℝ)*m) := by
    by_contra hh
    have hh' := le_of_not_gt hh
    have hsq := sq_le_sq₀ hs0 (le_trans hs0 hh') |>.mpr hh'
    nlinarith
  have hc : (m:ℝ)-k+2<Real.sqrt (((k:ℝ)+m-2)^2+4*(k:ℝ)*m) := by
    by_contra hh
    have hh' := le_of_not_gt hh
    have hsq := sq_le_sq₀ hs0 (le_trans hs0 hh') |>.mpr hh'
    nlinarith
  dsimp [strictGap,strictH]
  constructor <;> linarith

/-- All exact minimum/maximum constraints in D.2, with positive gap and eta. -/
theorem strict_constants {k m : ℕ} (hk : 2≤k) (hm : 2≤m) :
    0<strictGap k m ∧ 0<strictN k m ∧ 0<strictEta k m ∧
      2≤strictL k m ∧ strictN k m≤strictL k m ∧
      4*(strictH k m)^2/strictGap k m≤strictL k m ∧
      strictEta k m≤(k:ℝ)/(4*((k:ℝ)+m)) ∧
      strictEta k m≤1/((2:ℝ)^(k+m+1)*strictL k m) ∧
      strictEta k m≤(k:ℝ)*strictGap k m/(4*((k:ℝ)+m)*strictN k m) ∧
      strictEta k m≤(m:ℝ)*strictGap k m/(2*((k:ℝ)+m)+strictGap k m) := by
  have hg := (strict_radical_gaps hk hm).1
  have hk0 : 0<(k:ℝ) := by exact_mod_cast (by omega : 0<k)
  have hm0 : 0<(m:ℝ) := by exact_mod_cast (by omega : 0<m)
  have hN : 0<strictN k m := by dsimp [strictN]; positivity
  have hL2 : (2:ℝ)≤strictL k m := le_max_left _ _
  have hLp : 0<strictL k m := lt_of_lt_of_le (by norm_num) hL2
  have hη : 0<strictEta k m := by dsimp [strictEta]; positivity
  refine ⟨hg,hN,hη,hL2,(le_max_left _ _).trans (le_max_right _ _),
    (le_max_right _ _).trans (le_max_right _ _),?_⟩
  dsimp only [strictEta]
  exact ⟨min_le_left _ _,(min_le_right _ _).trans (min_le_left _ _),
    (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _)),
    (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _))⟩

/-- The exact eta is strictly less than the remaining dimension. -/
theorem strictEta_lt_remaining {k m : ℕ} (hk : 2≤k) (hm : 2≤m) : strictEta k m<(m:ℝ) := by
  have h := strict_constants hk hm
  have hg := h.1
  have hk0 : 0<(k:ℝ) := by exact_mod_cast (by omega : 0<k)
  have hm0 : 0<(m:ℝ) := by exact_mod_cast (by omega : 0<m)
  have he := h.2.2.2.2.2.2.2.2.2
  apply lt_of_le_of_lt he
  apply (div_lt_iff₀ (by positivity)).mpr
  nlinarith [mul_pos hm0 (add_pos hk0 hm0)]

end SpectralComparison
