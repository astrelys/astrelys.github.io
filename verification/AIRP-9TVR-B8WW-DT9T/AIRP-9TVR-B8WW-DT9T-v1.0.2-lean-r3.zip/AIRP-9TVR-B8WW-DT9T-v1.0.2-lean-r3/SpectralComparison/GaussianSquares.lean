import Mathlib.Probability.Distributions.Gaussian.Real
import Mathlib.Probability.Moments.Basic
import Mathlib.Analysis.SpecialFunctions.Gaussian.GaussianIntegral
import SpectralComparison

/-! Gaussian-square exponential moments and their quantitative tail bound. -/
noncomputable section
namespace SpectralComparison
open MeasureTheory ProbabilityTheory Real Finset
open scoped NNReal ENNReal

/-- Multiplying the standard Gaussian density by exp(z x²) gives another Gaussian kernel. -/
theorem gaussian_square_density (z x : ℝ) :
    gaussianPDFReal 0 1 x * Real.exp (z*x^2) =
      (Real.sqrt (2*Real.pi))⁻¹ * Real.exp (-(1/2-z)*x^2) := by
  simp only [gaussianPDFReal_def, NNReal.coe_one, mul_one, sub_zero]
  rw [mul_assoc, ← Real.exp_add]
  congr 2
  ring

/-- Exponential integrability of one squared standard Gaussian for every z<1/2. -/
theorem gaussian_square_exp_integrable {z : ℝ} (hz : z < 1/2) :
    Integrable (fun x : ℝ => Real.exp (z*x^2)) (gaussianReal 0 1) := by
  rw [gaussianReal_of_var_ne_zero _ (one_ne_zero : (1 : ℝ≥0) ≠ 0),
    integrable_withDensity_iff_integrable_smul' (measurable_gaussianPDF 0 1)
      (ae_of_all _ (fun _ => gaussianPDF_lt_top))]
  simp only [toReal_gaussianPDF, smul_eq_mul, gaussian_square_density]
  exact (integrable_exp_neg_mul_sq (by linarith : 0 < (1/2:ℝ)-z)).const_mul _

/-- Exact exponential moment of a squared standard Gaussian. -/
theorem gaussian_square_mgf {z : ℝ} (hz : z < 1/2) :
    (∫ x : ℝ, Real.exp (z*x^2) ∂gaussianReal 0 1) = (Real.sqrt (1-2*z))⁻¹ := by
  rw [integral_gaussianReal_eq_integral_smul (one_ne_zero : (1 : ℝ≥0) ≠ 0)]
  simp only [smul_eq_mul, gaussian_square_density]
  rw [integral_const_mul, integral_gaussian]
  have hden : 0 < 1-2*z := by linarith
  have he : Real.pi / ((1/2:ℝ)-z) = (2*Real.pi)/(1-2*z) := by field_simp
  rw [he, Real.sqrt_div (by positivity : 0 ≤ 2*Real.pi)]
  have hs : Real.sqrt (2*Real.pi) ≠ 0 := (Real.sqrt_pos.mpr (by positivity)).ne'
  field_simp

/-- Transport of the square MGF along the actual standard Gaussian law. -/
theorem gaussian_square_mgf_hasLaw {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    {X : Ω → ℝ} (hX : HasLaw X (gaussianReal 0 1) μ) {z : ℝ} (hz : z < 1/2) :
    mgf (fun ω => (X ω)^2) μ z = (Real.sqrt (1-2*z))⁻¹ := by
  unfold mgf
  calc
    _ = ∫ x : ℝ, Real.exp (z*x^2) ∂gaussianReal 0 1 :=
      hX.integral_comp (by fun_prop)
    _ = _ := gaussian_square_mgf hz

/-- Exact MGF of a finite sum of independent squared standard Gaussian variables. -/
theorem gaussian_squares_mgf {Ω ι : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    [IsProbabilityMeasure μ] (X : ι → Ω → ℝ) (hX : ∀ i, HasLaw (X i) (gaussianReal 0 1) μ)
    (h_indep : iIndepFun X μ) (h_meas : ∀ i, Measurable (X i))
    (s : Finset ι) {z : ℝ} (hz : z < 1/2) :
    mgf (fun ω => ∑ i ∈ s, (X i ω)^2) μ z = ((Real.sqrt (1-2*z))⁻¹)^s.card := by
  classical
  have hind := h_indep.comp (fun _ (x : ℝ) => x^2) (fun _ => by fun_prop)
  have h := hind.mgf_sum (fun i => (h_meas i).pow_const 2) s (t := z)
  have he : (∑ i ∈ s, (fun x : ℝ => x^2) ∘ X i) = (fun ω => ∑ i ∈ s, (X i ω)^2) := by
    ext ω
    simp
  rw [he] at h
  simpa only [Function.comp_def, gaussian_square_mgf_hasLaw (hX _) hz, Finset.prod_const] using h

/-- Exponential integrability of the finite Gaussian square sum. -/
theorem gaussian_squares_exp_integrable {Ω ι : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    [IsProbabilityMeasure μ] (X : ι → Ω → ℝ) (hX : ∀ i, HasLaw (X i) (gaussianReal 0 1) μ)
    (h_indep : iIndepFun X μ) (h_meas : ∀ i, Measurable (X i))
    (s : Finset ι) {z : ℝ} (hz : z < 1/2) :
    Integrable (fun ω => Real.exp (z * ∑ i ∈ s, (X i ω)^2)) μ := by
  classical
  have hind := h_indep.comp (fun _ (x : ℝ) => x^2) (fun _ => by fun_prop)
  have h := hind.integrable_exp_mul_sum (fun i => (h_meas i).pow_const 2)
    (s := s) (t := z) (fun i _ => (hX i).integrable_comp (gaussian_square_exp_integrable hz))
  simpa only [Finset.sum_apply, Function.comp_apply] using h

/-- Gaussian-square upper tail at the paper's factor 500, with the exact constant 124. -/
theorem gaussian_squares_tail_500 {Ω ι : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    [IsProbabilityMeasure μ] (X : ι → Ω → ℝ) (hX : ∀ i, HasLaw (X i) (gaussianReal 0 1) μ)
    (h_indep : iIndepFun X μ) (h_meas : ∀ i, Measurable (X i)) (s : Finset ι) :
    μ.real {ω | 500*(s.card:ℝ) ≤ ∑ i ∈ s, (X i ω)^2} ≤ Real.exp (-124*(s.card:ℝ)) := by
  have h := measure_ge_le_exp_mul_mgf (μ := μ) (X := fun ω => ∑ i ∈ s, (X i ω)^2)
    (500*(s.card:ℝ)) (t := (1/4:ℝ)) (by norm_num)
    (gaussian_squares_exp_integrable X hX h_indep h_meas s (by norm_num))
  rw [gaussian_squares_mgf X hX h_indep h_meas s (by norm_num)] at h
  have hs : (Real.sqrt (1-2*(1/4:ℝ)))⁻¹ ≤ Real.exp 1 := by
    norm_num only [show (1-2*(1/4:ℝ)) = 1/2 by norm_num]
    have hr : (1/2:ℝ) ≤ Real.sqrt (1/2) := by
      nlinarith [Real.sq_sqrt (by norm_num : (0:ℝ) ≤ 1/2), Real.sqrt_nonneg (1/2)]
    have hi : (Real.sqrt (1/2))⁻¹ ≤ 2 := by
      rw [← one_div]
      apply (div_le_iff₀ (Real.sqrt_pos.mpr (by norm_num))).mpr
      linarith
    exact hi.trans (by linarith [Real.add_one_le_exp (1:ℝ)])
  calc
    _ ≤ Real.exp (-(1/4:ℝ)*(500*s.card)) * ((Real.sqrt (1-2*(1/4:ℝ)))⁻¹)^s.card := h
    _ ≤ Real.exp (-(1/4:ℝ)*(500*s.card)) * (Real.exp 1)^s.card := by
      gcongr
    _ = Real.exp (-124*(s.card:ℝ)) := by
      rw [← Real.exp_nat_mul, ← Real.exp_add]
      congr 1
      ring

/-- Paper equation (2.4), with the real exponent -d/2 exactly as in the manuscript. -/
theorem paper_equation_2_4 {Ω ι : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    [IsProbabilityMeasure μ] (X : ι → Ω → ℝ) (hX : ∀ i, HasLaw (X i) (gaussianReal 0 1) μ)
    (h_indep : iIndepFun X μ) (h_meas : ∀ i, Measurable (X i))
    (s : Finset ι) {z : ℝ} (hz : z < 1/2) :
    mgf (fun ω => ∑ i ∈ s, (X i ω)^2) μ z = (1-2*z)^(-(s.card:ℝ)/2) := by
  have hb : 0 ≤ 1-2*z := by linarith
  rw [gaussian_squares_mgf X hX h_indep h_meas s hz,
    show -(s.card:ℝ)/2 = -((1/2:ℝ)*(s.card:ℝ)) by ring,
    Real.rpow_neg hb, Real.rpow_mul hb, Real.rpow_natCast, ← Real.sqrt_eq_rpow, inv_pow]

end SpectralComparison
