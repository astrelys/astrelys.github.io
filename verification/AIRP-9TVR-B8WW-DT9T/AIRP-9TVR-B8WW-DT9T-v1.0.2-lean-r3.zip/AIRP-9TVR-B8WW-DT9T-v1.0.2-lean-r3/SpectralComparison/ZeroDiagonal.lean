import SpectralComparison.TracelessDirection

/-! Orthogonal zero-diagonal realization, proved by dimension induction. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Every finite real symmetric traceless matrix is orthogonally similar to a zero-diagonal matrix. -/
theorem exists_orthogonal_zero_diagonal (n : ℕ) (A : Matrix (Fin n) (Fin n) ℝ)
    (hA : A.IsHermitian) (htr : A.trace=0) :
    ∃ V : Matrix (Fin n) (Fin n) ℝ, Vᴴ*V=1 ∧ ∀ i,(Vᴴ*A*V) i i=0 := by
  classical
  induction n with
  | zero => exact ⟨1,by simp,fun i => Fin.elim0 i⟩
  | succ n ih =>
    obtain ⟨v,hv,hvA⟩ := exists_traceless_isotropic_column hA htr
    have hvpd : (vᴴ*v).PosDef := by rw [hv]; exact Matrix.PosDef.one
    obtain ⟨U,hU,hproj⟩ := exists_kernel_basis_matrix_of_dimension (d:=Fin n) vᴴ
      (by simpa only [Matrix.conjTranspose_conjTranspose] using hvpd) (by simp)
    have hvU : vᴴ*U=0 := kernel_columns_annihilated vᴴ
      (by simpa only [Matrix.conjTranspose_conjTranspose] using hvpd) U hU hproj
    have hUv : Uᴴ*v=0 := by simpa only [Matrix.conjTranspose_mul,Matrix.conjTranspose_conjTranspose,Matrix.conjTranspose_zero] using congrArg Matrix.conjTranspose hvU
    have hproj' : U*Uᴴ=1-v*vᴴ := by
      simpa only [Matrix.conjTranspose_conjTranspose,hv,inv_one,Matrix.mul_one] using hproj
    let C := Uᴴ*A*U
    have hC : C.IsHermitian := Matrix.isHermitian_conjTranspose_mul_mul U hA
    have hCtr : C.trace=0 := by
      change (Uᴴ*A*U).trace=0
      rw [Matrix.trace_mul_cycle,hproj',Matrix.sub_mul,Matrix.one_mul,Matrix.trace_sub,htr]
      have hz : (v*vᴴ*A).trace=0 := by rw [Matrix.mul_assoc,Matrix.trace_mul_comm,hvA,Matrix.trace_zero]
      rw [hz,sub_self]
    obtain ⟨B,hB,hBd⟩ := ih C hC hCtr
    let W := Matrix.fromCols v (U*B)
    have hW : Wᴴ*W=1 := by
      dsimp [W]
      rw [Matrix.conjTranspose_fromCols_eq_fromRows_conjTranspose,Matrix.fromRows_mul_fromCols]
      have hBUB : (U*B)ᴴ*(U*B)=1 := by
        rw [Matrix.conjTranspose_mul]
        calc
          Bᴴ*Uᴴ*(U*B)=Bᴴ*(Uᴴ*U)*B := by simp only [Matrix.mul_assoc]
          _ = 1 := by rw [hU,Matrix.mul_one,hB]
      rw [hBUB,hv,← Matrix.mul_assoc,hvU,Matrix.zero_mul,Matrix.conjTranspose_mul,Matrix.mul_assoc,hUv,Matrix.mul_zero]
      exact Matrix.fromBlocks_one
    have hWd : ∀ i,(Wᴴ*A*W) i i=0 := by
      intro i
      dsimp [W]
      rw [Matrix.conjTranspose_fromCols_eq_fromRows_conjTranspose,Matrix.fromRows_mul,Matrix.fromRows_mul_fromCols]
      cases i with
      | inl i => exact congrFun (congrFun hvA i) i
      | inr i =>
        change ((U*B)ᴴ*A*(U*B)) i i=0
        have heq : (U*B)ᴴ*A*(U*B)=Bᴴ*C*B := by simp only [Matrix.conjTranspose_mul,C,Matrix.mul_assoc]
        rw [heq]
        exact hBd i
    let e : Fin (n+1) ≃ (Fin 1 ⊕ Fin n) := (finSumFinEquiv.trans (finCongr (by omega))).symm
    refine ⟨W.submatrix id e,?_,?_⟩
    · rw [Matrix.conjTranspose_submatrix,← Matrix.submatrix_mul _ _ e id e Function.bijective_id,hW]
      exact Matrix.submatrix_one e e.injective
    · intro i
      have he : (W.submatrix id e)ᴴ*A*W.submatrix id e=(Wᴴ*A*W).submatrix e e := by
        rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul _ _ e id e Function.bijective_id,
          Matrix.submatrix_mul _ _ e id id Function.bijective_id,Matrix.submatrix_id_id]
      rw [he]
      exact hWd (e i)

/-- Reindex the zero-diagonal realization to any finite coordinate type. -/
theorem exists_orthogonal_zero_diagonal_finite {n : Type*} [Fintype n] [DecidableEq n]
    (A : Matrix n n ℝ) (hA : A.IsHermitian) (htr : A.trace=0) :
    ∃ V : Matrix n n ℝ, Vᴴ*V=1 ∧ ∀ i,(Vᴴ*A*V) i i=0 := by
  classical
  let e : Fin (Fintype.card n) ≃ n := (Fintype.equivFin n).symm
  have htr' : (A.submatrix e e).trace=0 := by
    change (∑ i,A (e i) (e i))=0
    exact (Equiv.sum_comp e (fun i => A i i)).trans htr
  obtain ⟨U,hU,hUd⟩ := exists_orthogonal_zero_diagonal (Fintype.card n) (A.submatrix e e) (hA.submatrix e) htr'
  refine ⟨U.submatrix e.symm e.symm,?_,?_⟩
  · rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,hU]
    exact Matrix.submatrix_one e.symm e.symm.injective
  · intro i
    have hAA : A=(A.submatrix e e).submatrix e.symm e.symm := by ext a b; simp
    conv_lhs => rw [hAA]
    rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,Matrix.submatrix_mul_equiv]
    exact hUd (e.symm i)

end SpectralComparison
