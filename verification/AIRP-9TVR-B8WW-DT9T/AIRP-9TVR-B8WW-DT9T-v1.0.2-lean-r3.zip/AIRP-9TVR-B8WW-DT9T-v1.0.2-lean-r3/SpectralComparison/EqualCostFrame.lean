import SpectralComparison.VariableReplication

noncomputable section
open Matrix Finset
namespace SpectralComparison

/-- A unit vector is the exact orthogonal complement of a codimension-one Parseval frame. -/
theorem exists_codimension_one_frame {g : Type*} [Fintype g] [DecidableEq g]
    {k : ℕ} (hcard : Fintype.card g=k+1) (u : g → ℝ) (hu : (∑ i,u i^2)=1) :
    ∃ W : Matrix g (Fin k) ℝ,Wᴴ*W=1 ∧ W*Wᴴ=1-Matrix.vecMulVec u u := by
  let U : Matrix g (Fin 1) ℝ := Matrix.of (fun i _ => u i)
  have hU : Uᴴ*U=1 := by
    ext i j
    fin_cases i
    fin_cases j
    simpa only [Matrix.mul_apply,Matrix.conjTranspose_apply,star_trivial,U,Matrix.of_apply,← pow_two,Matrix.one_apply_eq] using hu
  have hdim : Fintype.card (Fin k)+Fintype.card (Fin 1)=Fintype.card g := by simp [hcard]
  obtain ⟨W,hW,_,hsum,_,_⟩ := exists_orthogonal_frame_completion U hU hdim
  have hUU : U*Uᴴ=Matrix.vecMulVec u u := by ext i j; simp [U,Matrix.mul_apply,Matrix.conjTranspose_apply,Matrix.vecMulVec_apply]
  refine ⟨W,hW,?_⟩
  rw [hUU] at hsum
  apply eq_sub_iff_add_eq.mpr
  rw [add_comm]
  exact hsum

/-- Every actual invertible row basis of the variable-replication frame has the explicit omitted-group cost. -/
theorem variable_replication_basis_cost {g : Type*} [Fintype g] [DecidableEq g] {k : ℕ}
    (W : Matrix g (Fin k) ℝ) (u : g → ℝ) (hW : W*Wᴴ=1-Matrix.vecMulVec u u)
    (hu : (∑ i,u i^2)=1) (hun : ∀ i,u i≠0)
    (r : g → ℕ) (hr : ∀ i,0<r i) (hcard : Fintype.card g=k+1)
    (I : Finset (Σ i,Fin (r i))) (hI : I.card=k) :
    let Q : Matrix (Σ i,Fin (r i)) (Fin k) ℝ := Matrix.of (fun i j => W i.1 j/Real.sqrt (r i.1))
    IsUnit (principal (Q*Qᴴ) I) →
      ∃ j : g,(principal (Q*Qᴴ) I)⁻¹.trace=
        (∑ l,(r l:ℝ))-2*r j+(∑ l,(r l:ℝ)*u l^2)/(u j^2) := by
  classical
  let Q : Matrix (Σ i,Fin (r i)) (Fin k) ℝ := Matrix.of (fun i j => W i.1 j/Real.sqrt (r i.1))
  change IsUnit (principal (Q*Qᴴ) I) → _
  intro hunit
  let f : I → g := fun i => i.val.1
  have hf : Function.Injective f := variable_replication_selected_injective W r I hunit
  obtain ⟨j,hj⟩ := image_omits_one f hf (by simpa only [Fintype.card_coe,hI] using hcard)
  let D := Matrix.diagonal (fun i : I => (Real.sqrt (r (f i)))⁻¹)
  have hg : principal (Q*Qᴴ) I=D*((W*Wᴴ).submatrix f f)*D := by
    ext a b
    rw [Matrix.mul_diagonal,Matrix.diagonal_mul]
    change (Q*Qᴴ) a.val b.val=(Real.sqrt (r (f a)))⁻¹*(W*Wᴴ) (f a) (f b)*(Real.sqrt (r (f b)))⁻¹
    rw [variable_replication_gram W r]
    dsimp [f]
    ring
  have hm : (W*Wᴴ).submatrix f f=1-Matrix.vecMulVec (u ∘ f) (u ∘ f) := by
    rw [hW,Matrix.submatrix_sub]
    change (1 : Matrix g g ℝ).submatrix f f-(Matrix.vecMulVec u u).submatrix f f=_
    rw [Matrix.submatrix_one f hf]
    rfl
  refine ⟨j,?_⟩
  rw [hg,hm]
  exact omitted_group_inverse_trace u (fun l => (r l:ℝ)) hu (fun l => by exact_mod_cast hr l) f hf j hj (hun j)

/-- The exact scalar mass equation produces a Parseval frame with a uniform inverse-basis cost. -/
theorem exists_equal_cost_frame {g : Type*} [Fintype g] [DecidableEq g] {k : ℕ}
    (hcard : Fintype.card g=k+1) (r : g → ℕ) (hr : ∀ i,0<r i)
    {c : ℝ} (hc : 0<c) (hmass : (∑ i,(r i:ℝ)/(c+2*r i))=1) :
    ∃ Q : Matrix (Σ i,Fin (r i)) (Fin k) ℝ,Qᴴ*Q=1 ∧
      ∀ I : Finset (Σ i,Fin (r i)),I.card=k → IsUnit (principal (Q*Qᴴ) I) →
        (principal (Q*Qᴴ) I)⁻¹.trace=(∑ i,(r i:ℝ))+c := by
  classical
  let p := fun i => (c+2*(r i:ℝ))⁻¹
  let Z := ∑ i,p i
  let u := fun i => Real.sqrt (p i/Z)
  have hp : ∀ i,0<p i := by intro i; dsimp [p]; positivity
  have hne : Nonempty g := Fintype.card_pos_iff.mp (by omega)
  let _ := hne
  have hZ : 0<Z := Finset.sum_pos (fun i _ => hp i) Finset.univ_nonempty
  have hu2 (i : g) : u i^2=p i/Z := Real.sq_sqrt (div_pos (hp i) hZ).le
  have hu : (∑ i,u i^2)=1 := by simp_rw [hu2]; rw [← Finset.sum_div]; exact div_self hZ.ne'
  have hun : ∀ i,u i≠0 := fun i => (Real.sqrt_pos.mpr (div_pos (hp i) hZ)).ne'
  obtain ⟨W,hW,hgram⟩ := exists_codimension_one_frame hcard u hu
  let Q : Matrix (Σ i,Fin (r i)) (Fin k) ℝ := Matrix.of (fun i j => W i.1 j/Real.sqrt (r i.1))
  refine ⟨Q,variable_replication_parseval W hW r hr,?_⟩
  intro I hI hunit
  obtain ⟨j,hcost⟩ := variable_replication_basis_cost W u hgram hu hun r hr hcard I hI hunit
  change (principal (Q*Qᴴ) I)⁻¹.trace=_ at hcost
  rw [hcost]
  have hsum : (∑ l,(r l:ℝ)*u l^2)=1/Z := by
    simp_rw [hu2,← mul_div_assoc]
    rw [← Finset.sum_div]
    have hh : (∑ l,(r l:ℝ)*p l)=1 := by simpa only [p,div_eq_mul_inv] using hmass
    rw [hh]
  rw [hsum,hu2]
  have he : (1/Z)/(p j/Z)=c+2*r j := by dsimp [p]; field_simp
  rw [he]
  ring

end SpectralComparison
