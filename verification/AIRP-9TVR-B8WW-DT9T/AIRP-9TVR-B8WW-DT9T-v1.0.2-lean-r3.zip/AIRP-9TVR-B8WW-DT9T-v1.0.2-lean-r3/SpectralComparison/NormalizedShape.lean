import SpectralComparison.BalancedCondition

noncomputable section
open Finset
namespace SpectralComparison

def normalizedHarmonicTrace {n : ℕ} (a : Fin n → ℝ) : ℝ := ∑ i,min (a i) 1

def normalizedHarmonicDeficit {n : ℕ} (a : Fin n → ℝ) (k : ℕ) : ℝ :=
  (n-k:ℕ)/(n:ℝ)*normalizedHarmonicTrace a-symmetricQuotient (univ.val.map a) k

theorem normalizedHarmonicTrace_eq_active {n : ℕ} (a : Fin n → ℝ) :
    normalizedHarmonicTrace a =
      ((univ.filter (fun i => 1 < a i)).card:ℝ) + ∑ i ∈ univ \ univ.filter (fun i => 1 < a i),a i := by
  classical
  let S := univ.filter (fun i => 1 < a i)
  have he1 : (∑ i ∈ S,min (a i) 1) = S.card := by
    calc
      _ = ∑ _i ∈ S,(1:ℝ) := sum_congr rfl (fun i hi => min_eq_right (mem_filter.mp hi).2.le)
      _ = _ := by simp
  have he2 : (∑ i ∈ univ \ S,min (a i) 1) = ∑ i ∈ univ \ S,a i := by
    apply sum_congr rfl
    intro i hi
    have hn : ¬1 < a i := by intro hh; exact (mem_sdiff.mp hi).2 (mem_filter.mpr ⟨mem_univ _,hh⟩)
    exact min_eq_left (le_of_not_gt hn)
  have hh := sum_sdiff (f:=fun i => min (a i) 1) (subset_univ S)
  rw [he1,he2] at hh
  dsimp [normalizedHarmonicTrace]
  linarith

theorem normalizedHarmonicTrace_bounds {n : ℕ} (hn : 0 < n) (a : Fin n → ℝ) (ha : ∀ i,0 < a i) :
    0 < normalizedHarmonicTrace a ∧ normalizedHarmonicTrace a ≤ n := by
  constructor
  · exact sum_pos (fun i _ => lt_min (ha i) (by norm_num)) ⟨⟨0,hn⟩,mem_univ _⟩
  · calc
      _ ≤ ∑ _i : Fin n,(1:ℝ) := sum_le_sum (fun i _ => min_le_right _ _)
      _ = _ := by simp

theorem normalized_deficit_nonneg {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0 < a i)
    (hk : 1 ≤ k) (hkn : k < n) (hm : 2 ≤ n-k) (hroot : waterSum a 1 = k) :
    0 ≤ normalizedHarmonicDeficit a k := by
  dsimp [normalizedHarmonicDeficit]
  rw [normalizedHarmonicTrace_eq_active]
  exact (original_water_stability a ha hk hkn hm hroot).1

theorem normalized_deficit_shape {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0 < a i)
    (horder : Antitone a) (hk : 1 ≤ k) (hkn : k < n) (hm : 2 ≤ n-k)
    (hroot : waterSum a 1 = k) {L : ℝ} (hL : 1 < L)
    (hsmall : normalizedHarmonicDeficit a k < (k:ℝ)/(2*n))
    (hexp : (2:ℝ)^(n+1)*normalizedHarmonicDeficit a k ≤ 1/L) :
    (∀ i : Fin n,i.val < k → L ≤ a i) ∧
      (∀ i,1-(n:ℝ)*normalizedHarmonicDeficit a k/k ≤ a i) := by
  have he : normalizedHarmonicDeficit a k =
      (n-k:ℕ)/(n:ℝ)*(((univ.filter (fun i => 1 < a i)).card:ℝ)+
        ∑ i ∈ univ \ univ.filter (fun i => 1 < a i),a i)-symmetricQuotient (univ.val.map a) k := by
    rw [normalizedHarmonicDeficit,normalizedHarmonicTrace_eq_active]
  rw [he] at hsmall hexp ⊢
  exact original_stable_shape a ha horder hk hkn hm hroot hL hsmall hexp

/-- Once the leading coordinates are large, the water equation also bounds every remaining coordinate above. -/
theorem normalized_tail_upper_of_head {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0 < a i)
    (hk : 1 ≤ k) (hkn : k < n) (hroot : waterSum a 1 = k)
    {L : ℝ} (hL : (k:ℝ) < L) (hhead : ∀ i : Fin n,i.val < k → L ≤ a i)
    (i : Fin n) (hi : k ≤ i.val) : a i ≤ 1/(1-(k:ℝ)/L) := by
  classical
  let S := spectralPrefix (n:=n) k
  let w := fun j => max (1-1/a j) 0
  have hk0 : (0:ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hL0 : 0 < L := hk0.trans hL
  have hcard : S.card = k := spectralPrefix_card hkn.le
  have hin : i ∉ S := by simp [S,spectralPrefix]; omega
  have hsumS : (k:ℝ)*(1-1/L) ≤ ∑ j ∈ S,w j := by
    calc
      _ = ∑ _j ∈ S,(1-1/L) := by simp only [sum_const,hcard,nsmul_eq_mul]
      _ ≤ _ := by
        apply sum_le_sum
        intro j hj
        have hjk : j.val < k := (mem_filter.mp hj).2
        have hh := one_div_le_one_div_of_le hL0 (hhead j hjk)
        exact (sub_le_sub_left hh 1).trans (le_max_left _ _)
  have hsum : w i + ∑ j ∈ S,w j ≤ (k:ℝ) := by
    have hh := sum_le_sum_of_subset_of_nonneg (f:=w) (subset_univ (insert i S)) (fun j _ _ => le_max_right _ _)
    rw [sum_insert hin] at hh
    change w i + ∑ j ∈ S,w j ≤ waterSum a 1 at hh
    rwa [hroot] at hh
  have hwi : 1-1/a i ≤ (k:ℝ)/L := by
    have hh : 1-1/a i ≤ w i := le_max_left _ _
    have he : (k:ℝ)*(1-1/L) = k-k/L := by ring
    rw [he] at hsumS
    linarith
  have hd : 0 < 1-(k:ℝ)/L := sub_pos.mpr ((div_lt_one hL0).mpr hL)
  apply (le_div_iff₀ hd).mpr
  have hh := mul_le_mul_of_nonneg_right hwi (ha i).le
  have he : (1-1/a i)*a i = a i-1 := by field_simp [(ha i).ne']
  rw [he] at hh
  nlinarith

/-- The manuscript's maximum over all admissible harmonic prefixes. -/
def harmonicEnvelope {n : ℕ} (a : Fin n → ℝ) (k : ℕ) (hkn : k < n) : ℝ :=
  (Finset.Icc (k+1) n).sup' ⟨k+1,Finset.mem_Icc.mpr ⟨le_rfl,by omega⟩⟩ (harmonicPrefixValue a k)

theorem harmonicEnvelope_eq_water {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0 < a i)
    (horder : Antitone a) (hk : 1 ≤ k) (hkn : k < n) {τ : ℝ} (hτ : 0 < τ)
    (hroot : waterSum a τ = k) : harmonicEnvelope a k hkn = ∑ i,min (a i) τ := by
  dsimp [harmonicEnvelope]
  rw [paper_harmonic_maximum a ha horder hk hkn hτ hroot,water_min_sum]

theorem harmonicEnvelope_eq_normalized {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0 < a i)
    (horder : Antitone a) (hk : 1 ≤ k) (hkn : k < n) (hroot : waterSum a 1 = k) :
    harmonicEnvelope a k hkn = normalizedHarmonicTrace a := by
  exact harmonicEnvelope_eq_water a ha horder hk hkn (by norm_num) hroot

end SpectralComparison
