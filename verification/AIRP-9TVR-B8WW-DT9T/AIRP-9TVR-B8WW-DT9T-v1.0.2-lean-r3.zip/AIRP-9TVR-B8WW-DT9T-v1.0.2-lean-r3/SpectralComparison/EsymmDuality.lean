import SpectralComparison.TwoLevelSpectrum

/-! Complementary elementary symmetric coefficients for positive spectra. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Complementation of actual finite subsets proves reciprocal duality for elementary coefficients. -/
theorem esymm_reciprocal_duality {ι : Type*} [Fintype ι] [DecidableEq ι]
    (f : ι → ℝ) (hf : ∀ i,f i≠0) {t : ℕ} (ht : t≤Fintype.card ι) :
    (Finset.univ.val.map f).esymm (Fintype.card ι-t)=
      (∏ i,f i)*(Finset.univ.val.map (fun i => (f i)⁻¹)).esymm t := by
  rw [Finset.esymm_map_val,Finset.esymm_map_val,Finset.mul_sum]
  apply Finset.sum_bij (fun I _ => Iᶜ)
  · intro I hI
    have hc := (Finset.mem_powersetCard.mp hI).2
    apply Finset.mem_powersetCard.mpr
    refine ⟨Finset.subset_univ _,?_⟩
    rw [Finset.card_compl,hc]
    omega
  · intro I _ J _ hij
    exact compl_injective hij
  · intro J hJ
    refine ⟨Jᶜ,Finset.mem_powersetCard.mpr ⟨Finset.subset_univ _,?_⟩,by simp⟩
    rw [Finset.card_compl,(Finset.mem_powersetCard.mp hJ).2]
  · intro I _
    rw [Finset.prod_inv_distrib,← Finset.prod_mul_prod_compl I f]
    have hp : (∏ i ∈ Iᶜ,f i)≠0 := Finset.prod_ne_zero_iff.mpr (fun i _ => hf i)
    rw [mul_assoc,mul_inv_cancel₀ hp,mul_one]

/-- Simultaneous permutation of a finite list leaves all elementary coefficients unchanged. -/
theorem esymm_comp_permutation {ι : Type*} [Fintype ι] [DecidableEq ι]
    (f : ι → ℝ) (e : Equiv.Perm ι) (t : ℕ) :
    (Finset.univ.val.map (f ∘ e)).esymm t=(Finset.univ.val.map f).esymm t := by
  have he : (Finset.univ.map e.toEmbedding : Finset ι)=Finset.univ := by ext i; simp
  have hh := congrArg (fun s : Finset ι => (s.val.map f).esymm t) he
  simpa only [Finset.map_val,Multiset.map_map,Equiv.coe_toEmbedding] using hh

/-- The first k entries are one. -/
theorem twoLevelSpectrum_inl (k m : ℕ) (ε : ℝ) (i : Fin k) :
    twoLevelSpectrum k m ε (finSumFinEquiv (Sum.inl i))=1 := by
  change (if i.val<k then (1:ℝ) else ε)=1
  simp [i.isLt]

/-- The last m entries equal epsilon. -/
theorem twoLevelSpectrum_inr (k m : ℕ) (ε : ℝ) (i : Fin m) :
    twoLevelSpectrum k m ε (finSumFinEquiv (Sum.inr i))=ε := by
  change (if k+i.val<k then (1:ℝ) else ε)=ε
  simp

/-- The full product of the repeated two-level spectral list. -/
theorem twoLevelSpectrum_prod (k m : ℕ) (ε : ℝ) :
    (∏ i,twoLevelSpectrum k m ε i)=ε^m := by
  rw [← finSumFinEquiv.prod_comp (twoLevelSpectrum k m ε),Fintype.prod_sum_type]
  change (∏ i : Fin k,twoLevelSpectrum k m ε (finSumFinEquiv (Sum.inl i)))*
    (∏ i : Fin m,twoLevelSpectrum k m ε (finSumFinEquiv (Sum.inr i)))=ε^m
  simp only [twoLevelSpectrum_inl,twoLevelSpectrum_inr,Finset.prod_const,Finset.card_univ,Fintype.card_fin,one_pow,one_mul]

/-- Balanced spectra are exchanged with their epsilon-scaled reciprocals by swapping the two halves. -/
theorem balanced_spectrum_reciprocal_coeff (k t : ℕ) {ε : ℝ} (hε : ε≠0) :
    (Finset.univ.val.map (fun i => (twoLevelSpectrum k k ε i)⁻¹)).esymm t=
      (ε⁻¹)^t*(Finset.univ.val.map (twoLevelSpectrum k k ε)).esymm t := by
  let e : Equiv.Perm (Fin (k+k)) := finSumFinEquiv.symm.trans ((Equiv.sumComm (Fin k) (Fin k)).trans finSumFinEquiv)
  have he (i : Fin (k+k)) : (twoLevelSpectrum k k ε i)⁻¹=ε⁻¹*twoLevelSpectrum k k ε (e i) := by
    obtain ⟨j,rfl⟩ := finSumFinEquiv.surjective i
    cases j with
    | inl a =>
      simp only [e,Equiv.trans_apply,Equiv.symm_apply_apply,Equiv.sumComm_apply]
      simp [twoLevelSpectrum,a.isLt,hε]
    | inr a =>
      simp only [e,Equiv.trans_apply,Equiv.symm_apply_apply,Equiv.sumComm_apply]
      simp [twoLevelSpectrum,a.isLt]
  simp_rw [he]
  have hs := Multiset.pow_smul_esymm (ε⁻¹) t (Finset.univ.val.map (twoLevelSpectrum k k ε ∘ e))
  simp only [smul_eq_mul,Multiset.map_map,Function.comp_def] at hs
  rw [← hs]
  congr 1
  exact esymm_comp_permutation (twoLevelSpectrum k k ε) e t

/-- Adjacent central coefficients satisfy the exact balanced epsilon-duality. -/
theorem balanced_central_esymm_duality {k : ℕ} (hk : 1≤k) {ε : ℝ} (hε : 0<ε) :
    (Finset.univ.val.map (twoLevelSpectrum k k ε)).esymm (k+1)=
      ε*(Finset.univ.val.map (twoLevelSpectrum k k ε)).esymm (k-1) := by
  have h := esymm_reciprocal_duality (twoLevelSpectrum k k ε)
    (fun i => (twoLevelSpectrum_pos hε i).ne') (t:=k-1) (by simp; omega)
  have hd : Fintype.card (Fin (k+k))-(k-1)=k+1 := by simp; omega
  rw [hd,twoLevelSpectrum_prod,balanced_spectrum_reciprocal_coeff k (k-1) hε.ne'] at h
  rw [h]
  have hp : ε^k*(ε⁻¹)^(k-1)=ε := by
    have hpow : ε^k=ε^(k-1)*ε := by rw [← pow_succ]; congr 1; omega
    rw [hpow,inv_pow]
    field_simp
  rw [← mul_assoc,hp]

/-- The square-root quotient bound in equation (A.6), via proved log-concavity and exact duality. -/
theorem balanced_spectralMean_sqrt {k : ℕ} (hk : 1≤k) {ε : ℝ} (hε : 0<ε) :
    spectralMean (twoLevelSpectrum k k ε) k≤((k:ℝ)+1)*Real.sqrt ε := by
  let s := Finset.univ.val.map (twoLevelSpectrum k k ε)
  have hs : ∀ z∈s,0<z := by
    intro z hz
    obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz
    exact twoLevelSpectrum_pos hε i
  have hp : 0<s.esymm k := esymm_pos s hs k (by simp [s])
  have hnext : 0≤s.esymm (k+1) := esymm_nonneg s (fun z hz => (hs z hz).le) _
  have hc := esymm_logconcave s hs (k-1)
  have hd := balanced_central_esymm_duality hk hε
  change s.esymm (k+1)=ε*s.esymm (k-1) at hd
  rw [show k-1+1=k by omega,show k-1+2=k+1 by omega] at hc
  have hb : s.esymm (k+1)≤Real.sqrt ε*s.esymm k := by
    have hm := mul_le_mul_of_nonneg_left hc hε.le
    have hsq : (s.esymm (k+1))^2≤ε*(s.esymm k)^2 := by
      calc
        _ = ε*(s.esymm (k-1)*s.esymm (k+1)) := by rw [hd]; ring
        _ ≤ _ := hm
    apply (sq_le_sq₀ hnext (mul_nonneg (Real.sqrt_nonneg ε) hp.le)).mp
    simpa only [mul_pow,Real.sq_sqrt hε.le] using hsq
  change ((k:ℝ)+1)*s.esymm (k+1)/s.esymm k≤_
  apply (div_le_iff₀ hp).mpr
  nlinarith [Nat.cast_nonneg (α:=ℝ) k]

end SpectralComparison
