import SpectralComparison.GaussianBlockTail

/-! The Gaussian inverse-trace lower tail, with the paper's threshold and constants. -/
noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

/-- Reindexing the row type preserves the trace of the inverse Gram matrix. -/
theorem inverse_gram_trace_reindex {m n p : Type*} [Fintype m] [Fintype n] [Fintype p]
    [DecidableEq m] [DecidableEq n] (W : Matrix m p ℝ) (e : n ≃ m) :
    ((W.submatrix e id)*(W.submatrix e id)ᴴ)⁻¹.trace = (W*Wᴴ)⁻¹.trace := by
  have he : W.submatrix e id * (W.submatrix e id)ᴴ = (W*Wᴴ).submatrix e e := by
    ext i j
    simp [Matrix.mul_apply]
  rw [he, Matrix.inv_submatrix_equiv]
  exact e.sum_comp (fun i => (W*Wᴴ)⁻¹ i i)

/-- Subset averaging and the unconditional block tail combine for any positive upper-block size. -/
theorem gaussian_inverse_trace_partition_bound {Ω m n p : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype m] [Fintype n] [Fintype p]
    [DecidableEq m] [DecidableEq n] [DecidableEq p]
    (W : Ω → Matrix (m ⊕ n) p ℝ)
    (hW : ∀ a : (m ⊕ n) × p, HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : (m ⊕ n) × p => fun ω => W ω a.1 a.2) μ)
    (hmeas : ∀ a : (m ⊕ n) × p, Measurable (fun ω => W ω a.1 a.2))
    (hm : 0 < Fintype.card m) (hd : Fintype.card m+Fintype.card n ≤ Fintype.card p) :
    μ.real {ω | (W ω*(W ω)ᴴ)⁻¹.trace ≤
      ((Fintype.card m:ℝ)+Fintype.card n)/(1000*(Fintype.card p-Fintype.card n:ℕ))} ≤
    2*Real.exp (-124*((Fintype.card m:ℝ)*(Fintype.card p-Fintype.card n:ℕ))) := by
  obtain ⟨emb⟩ := Function.Embedding.nonempty_of_card_le
    (show Fintype.card (m ⊕ n) ≤ Fintype.card p by simpa using hd)
  let J : Finset (m ⊕ n) := Finset.univ.map Function.Embedding.inl
  have hJ : J.card = Fintype.card m := by simp [J]
  have hb : (0:ℝ) < 1000*(Fintype.card p-Fintype.card n:ℕ) := by
    have : 0 < Fintype.card p-Fintype.card n := by omega
    positivity
  have h := gaussian_inverse_gram_subset_bound emb W hW hind hmeas hm
    (by simp) hb J hJ
  have he (ω : Ω) : (∑ i ∈ J, (W ω*(W ω)ᴴ)⁻¹ i i) =
      ((W ω*(W ω)ᴴ)⁻¹.submatrix Sum.inl Sum.inl).trace := by
    simp [J, Matrix.trace, Matrix.diag, Finset.sum_map]
  have ht : 2*(Fintype.card m:ℝ)/(1000*(Fintype.card p-Fintype.card n:ℕ)) =
      (Fintype.card m:ℝ)/(500*(Fintype.card p-Fintype.card n:ℕ)) := by ring
  simp only [Fintype.card_sum, Nat.cast_add, he, ht] at h
  exact h.trans (mul_le_mul_of_nonneg_left (gaussian_inverse_block_tail W hW hind hm hd) (by norm_num))

/-- The same partition bound on an ordinary t-by-p Gaussian matrix, for any 1<=j<=t. -/
theorem gaussian_inverse_trace_chosen_rows {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {t p j : ℕ}
    (W : Ω → Matrix (Fin t) (Fin p) ℝ)
    (hW : ∀ a : Fin t × Fin p, HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin t × Fin p => fun ω => W ω a.1 a.2) μ)
    (hmeas : ∀ a : Fin t × Fin p, Measurable (fun ω => W ω a.1 a.2))
    (hj : 1 ≤ j) (hjt : j ≤ t) (htp : t ≤ p) :
    μ.real {ω | (W ω*(W ω)ᴴ)⁻¹.trace ≤ (t:ℝ)/(1000*(p-(t-j):ℕ))} ≤
      2*Real.exp (-124*((j:ℝ)*(p-(t-j):ℕ))) := by
  let e : Fin j ⊕ Fin (t-j) ≃ Fin t := finSumFinEquiv.trans (finCongr (Nat.add_sub_of_le hjt))
  let V : Ω → Matrix (Fin j ⊕ Fin (t-j)) (Fin p) ℝ := fun ω => (W ω).submatrix e id
  have hV (a : (Fin j ⊕ Fin (t-j)) × Fin p) :
      HasLaw (fun ω => V ω a.1 a.2) (gaussianReal 0 1) μ := hW (e a.1,a.2)
  have hiV : iIndepFun (fun a : (Fin j ⊕ Fin (t-j)) × Fin p => fun ω => V ω a.1 a.2) μ :=
    hind.precomp (e.prodCongr (Equiv.refl (Fin p))).injective
  have hmV (a : (Fin j ⊕ Fin (t-j)) × Fin p) : Measurable (fun ω => V ω a.1 a.2) :=
    hmeas (e a.1,a.2)
  have h := gaussian_inverse_trace_partition_bound V hV hiV hmV
    (by simp only [Fintype.card_fin]; omega) (by simp; omega)
  have he (ω : Ω) : (V ω*(V ω)ᴴ)⁻¹.trace = (W ω*(W ω)ᴴ)⁻¹.trace :=
    inverse_gram_trace_reindex (W ω) e
  have hcard : (j:ℝ)+(t-j:ℕ) = t := by exact_mod_cast Nat.add_sub_of_le hjt
  simpa only [Fintype.card_fin, he, hcard] using h

/-- Paper Lemma 3.1 / equation (3.1): the exact inverse-trace lower tail for
independent standard Gaussian entries. No full-rank or exchangeability assumption
is supplied; both are proved from the entry laws. -/
theorem gaussian_inverse_trace_tail_measurable {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {t q : ℕ} (ht : 1 ≤ t) (hp : 4 ≤ t+q)
    (G : Ω → Matrix (Fin t) (Fin (t+q)) ℝ)
    (hG : ∀ a : Fin t × Fin (t+q), HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin t × Fin (t+q) => fun ω => G ω a.1 a.2) μ)
    (hmeas : ∀ a : Fin t × Fin (t+q), Measurable (fun ω => G ω a.1 a.2)) :
    μ.real {ω | (G ω*(G ω)ᴴ)⁻¹.trace ≤ (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t+q:ℕ)))} ≤
      2*Real.exp (-31*(t+q:ℕ)) := by
  let j := min t ⌊Real.sqrt (t+q:ℕ)⌋₊
  obtain ⟨hj, hjsqrt, hdim⟩ := gaussian_tail_dimension ht hp
  have hjt : j ≤ t := min_le_left _ _
  have hjpos : (0:ℝ) < j := by exact_mod_cast (show 0 < j by omega)
  have hsub : t+q-(t-j) = q+j := by omega
  have h := gaussian_inverse_trace_chosen_rows G hG hind hmeas hj hjt (Nat.le_add_right t q)
  rw [hsub] at h
  have hden : (0:ℝ) < 1000*((q:ℝ)+j) := by positivity
  have hthresh : (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t+q:ℕ))) ≤
      (t:ℝ)/(1000*(q+j:ℕ)) := by
    simp only [Nat.cast_add]
    apply div_le_div_of_nonneg_left (by positivity) hden
    have hh : (j:ℝ) ≤ Real.sqrt (t+q:ℕ) := hjsqrt
    simp only [Nat.cast_add] at hh
    nlinarith
  have hmono : μ.real {ω | (G ω*(G ω)ᴴ)⁻¹.trace ≤ (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t+q:ℕ)))} ≤
      μ.real {ω | (G ω*(G ω)ᴴ)⁻¹.trace ≤ (t:ℝ)/(1000*(q+j:ℕ))} :=
    measureReal_mono (fun ω hω => hω.trans hthresh)
  apply (hmono.trans h).trans
  apply mul_le_mul_of_nonneg_left _ (by norm_num)
  apply Real.exp_le_exp.mpr
  have hd : (t+q:ℕ)/4 ≤ (j:ℝ)*((q:ℝ)+j) := hdim
  change -124*((j:ℝ)*(q+j:ℕ)) ≤ -31*(t+q:ℕ)
  simp only [Nat.cast_add] at hd ⊢
  nlinarith

/-- Exact Lemma 3.1 with only the independent standard Gaussian entry laws.
Almost-everywhere measurable entries are sufficient; a measurable representative is
constructed internally and the final event is unchanged almost everywhere. -/
theorem paper_lemma_3_1 {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {t q : ℕ} (ht : 1 ≤ t) (hp : 4 ≤ t+q)
    (G : Ω → Matrix (Fin t) (Fin (t+q)) ℝ)
    (hG : ∀ a : Fin t × Fin (t+q), HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin t × Fin (t+q) => fun ω => G ω a.1 a.2) μ) :
    μ.real {ω | (G ω*(G ω)ᴴ)⁻¹.trace ≤ (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t+q:ℕ)))} ≤
      2*Real.exp (-31*(t+q:ℕ)) := by
  let X := fun ω (a : Fin t × Fin (t+q)) => G ω a.1 a.2
  have hX : HasLaw X (Measure.pi (fun _ : Fin t × Fin (t+q) => gaussianReal 0 1)) μ :=
    hind.hasLaw_pi hG
  let Y := hX.aemeasurable.mk X
  have hY : HasLaw Y (Measure.pi (fun _ : Fin t × Fin (t+q) => gaussianReal 0 1)) μ :=
    hX.congr hX.aemeasurable.ae_eq_mk.symm
  let H : Ω → Matrix (Fin t) (Fin (t+q)) ℝ := fun ω => Matrix.of (fun i j => Y ω (i,j))
  have hH := gaussian_product_entry_hasLaw Y hY
  have hiH := gaussian_product_independent Y hY
  have hmH (a : Fin t × Fin (t+q)) : Measurable (fun ω => H ω a.1 a.2) :=
    (measurable_pi_apply a).comp hX.aemeasurable.measurable_mk
  have h := gaussian_inverse_trace_tail_measurable ht hp H hH hiH hmH
  have he : G =ᵐ[μ] H := by
    filter_upwards [hX.aemeasurable.ae_eq_mk] with ω hω
    ext i j
    exact congrFun hω (i,j)
  have hev : {ω | (G ω*(G ω)ᴴ)⁻¹.trace ≤ (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t+q:ℕ)))} =ᵐ[μ]
      {ω | (H ω*(H ω)ᴴ)⁻¹.trace ≤ (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t+q:ℕ)))} := by
    filter_upwards [he] with ω hω
    simp only [hω]
  exact (measureReal_congr hev).trans_le h

end SpectralComparison
