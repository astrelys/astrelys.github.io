import SpectralComparison.QuotientBalancing
import SpectralComparison.FiniteBalancing

noncomputable section
open Finset
namespace SpectralComparison

theorem spectrum_pair_decomposition {ι : Type*} [Fintype ι] [DecidableEq ι]
    (a : ι → ℝ) (i j : ι) (hij : i ≠ j) :
    univ.val.map a = a i ::ₘ a j ::ₘ ((univ.erase i).erase j).val.map a := by
  have hji : j ∈ (univ : Finset ι).erase i := by simp [Ne.symm hij]
  have he1 : (univ : Finset ι) = insert i (univ.erase i) := (insert_erase (mem_univ i)).symm
  have he2 : (univ : Finset ι).erase i = insert j ((univ.erase i).erase j) := (insert_erase hji).symm
  conv_lhs => rw [he1, insert_val_of_notMem (by simp), Multiset.map_cons, he2,
    insert_val_of_notMem (by simp), Multiset.map_cons]

theorem spectrum_pair_update {ι : Type*} [Fintype ι] [DecidableEq ι]
    (a : ι → ℝ) (i j : ι) (hij : i ≠ j) (u v : ℝ) :
    univ.val.map (Function.update (Function.update a i u) j v) =
      u ::ₘ v ::ₘ ((univ.erase i).erase j).val.map a := by
  rw [spectrum_pair_decomposition _ i j hij]
  simp only [Function.update_of_ne hij, Function.update_self]
  congr 2
  apply Multiset.map_congr rfl
  intro l hl
  have hh := Finset.mem_val.mp hl
  have hlj : l ≠ j := (mem_erase.mp hh).1
  have hli : l ≠ i := (mem_erase.mp (mem_erase.mp hh).2).1
  simp [hli,hlj]

/-- The fixed-sum pair comparison on actual indexed spectra. -/
theorem spectralQuotient_pair_balance {ι : Type*} [Fintype ι] [DecidableEq ι]
    (a : ι → ℝ) (ha : ∀ i, 0 < a i) (i j : ι) (hij : i ≠ j)
    {u v : ℝ} (hu : 0 < u) (hv : 0 < v) (hsum : a i+a j = u+v)
    (hprod : a i*a j ≤ u*v) {k : ℕ} (hk : 1 ≤ k) (hkn : k < Fintype.card ι) :
    symmetricQuotient (univ.val.map a) k ≤
      symmetricQuotient (univ.val.map (Function.update (Function.update a i u) j v)) k := by
  rw [spectrum_pair_update a i j hij, spectrum_pair_decomposition a i j hij]
  have hs : ∀ z ∈ ((univ.erase i).erase j).val.map a, 0 < z := by
    intro z hz
    obtain ⟨l,_,rfl⟩ := Multiset.mem_map.mp hz
    exact ha l
  apply quotient_pair_balancing _ hs (ha i) (ha j) hu hv hsum hprod hk
  have hji : j ∈ (univ : Finset ι).erase i := by simp [Ne.symm hij]
  simp only [Multiset.card_map,Finset.card_val,card_erase_of_mem hji,
    card_erase_of_mem (mem_univ i),card_univ]
  omega

/-- Full tail averaging follows by finite balancing, without a compactness or limit premise. -/
theorem quotient_tail_averaging {r p : Type*} [Fintype r] [Fintype p]
    [DecidableEq r] [DecidableEq p] (h : r → ℝ) (b : p → ℝ)
    (hh : ∀ i, 0 < h i) (hb : ∀ i, 0 < b i) {c : ℝ} (hc : 0 < c)
    (hsum : (∑ i,b i) = Fintype.card p*c) {k : ℕ} (hk : 1 ≤ k)
    (hkn : k < Fintype.card r + Fintype.card p) :
    symmetricQuotient (univ.val.map (Sum.elim h b)) k ≤
      symmetricQuotient (univ.val.map (Sum.elim h (fun _ : p => c))) k := by
  apply finite_balancing_bound (fun b => symmetricQuotient (univ.val.map (Sum.elim h b)) k) hc _ b hb hsum
  intro a ha i j hij u v hu hv hs hp
  have he : Sum.elim h (Function.update (Function.update a i u) j v) =
      Function.update (Function.update (Sum.elim h a) (Sum.inr i) u) (Sum.inr j) v := by
    funext l
    cases l with
    | inl l => simp only [Function.update_apply, Sum.inl_ne_inr, ite_false, Sum.elim_inl]
    | inr l =>
      simp only [Sum.elim_inr, Function.update_apply, Sum.inr.injEq]
  rw [he]
  have hpos : ∀ l,0 < Sum.elim h a l := by
    intro l
    cases l with | inl l => exact hh l | inr l => exact ha l
  apply spectralQuotient_pair_balance _ hpos (Sum.inr i) (Sum.inr j)
    (fun he => hij (Sum.inr.inj he)) hu hv hs hp hk
  simpa only [Fintype.card_sum] using hkn

end SpectralComparison
