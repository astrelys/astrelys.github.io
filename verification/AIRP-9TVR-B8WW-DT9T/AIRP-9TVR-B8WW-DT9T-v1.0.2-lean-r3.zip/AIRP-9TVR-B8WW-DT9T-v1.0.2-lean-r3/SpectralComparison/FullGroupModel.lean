import SpectralComparison.GroupCovariance
import SpectralComparison.SingletonGeometry

/-! The complete group-and-singleton model, chosen before coordinate selections. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Assemble (7.5)-(7.6) with every signal, reserved, unreserved and singleton eigenvalue.
The spectrum is still indexed by the four explicit finite label types. -/
theorem exists_full_group_model {g p r h s : Type*}
    [Fintype g] [Fintype p] [Fintype r] [Fintype h] [Fintype s]
    [DecidableEq g] [DecidableEq p] [DecidableEq r] [DecidableEq h] [DecidableEq s]
    (f : p → g) (d : p → ℝ) (hd : ∀ i,0<d i)
    (Q0 : Matrix g r ℝ) (hQ0 : Q0ᴴ*Q0=1)
    (hdim : Fintype.card h+Fintype.card r=Fintype.card g)
    (b : h → ℝ) (hb : ∀ i,0<b i) (z : s → ℝ) (hz : ∀ i,0<z i) :
    let n := (Σ j : g,Fin 1 ⊕ {i : p // f i=j}) ⊕ s
    let label := ((r ⊕ h) ⊕ p) ⊕ s
    let group : n → Option g := Sum.elim (fun x => some x.1) (fun _ => none)
    ∃ (V : Matrix n label ℝ) (Q : Matrix n r ℝ) (C D : Matrix n n ℝ) (u : n → ℝ),
      Vᴴ*V=1 ∧ V*Vᴴ=1 ∧ Qᴴ*Q=1 ∧ Qᴴ*C=0 ∧
      C.PosSemidef ∧ D.PosSemidef ∧ (C-D).PosSemidef ∧
      (∀ i j,Q i j=match group i with | none => 0 | some a => u i*Q0 a j) ∧
      (∀ i x,group i≠group x → D i x=0) ∧
      (∀ i j,group i=some j → D i i=(∑ a : {a : p // f a=j},d a.val)*(u i)^2) ∧
      ∀ a : r → ℝ,V*Matrix.diagonal (Sum.elim (Sum.elim (Sum.elim a b) d) z)*Vᴴ=
        Q*Matrix.diagonal a*Qᴴ+C := by
  classical
  obtain ⟨W,V,hV,hV',hnon,hrow,hQ,hC,hQC,hker,hD,hCD,hdiag,hcross,hspec⟩ :=
    exists_group_covariance f d hd Q0 hQ0 hdim b hb
  let Q := W.submatrix id Sum.inl*Q0
  let D := W*Matrix.diagonal (Sum.elim (fun _ : g => (0:ℝ)) d)*Wᴴ
  let C := V*Matrix.diagonal (Sum.elim (Sum.elim (fun _ : r => (0:ℝ)) b) d)*Vᴴ
  let T := Matrix.fromBlocks V 0 0 (1 : Matrix s s ℝ)
  let Q' : Matrix ((Σ j : g,Fin 1 ⊕ {i : p // f i=j}) ⊕ s) r ℝ := Matrix.fromRows Q 0
  let C' := Matrix.fromBlocks C 0 0 (Matrix.diagonal z)
  let D' := Matrix.fromBlocks D 0 0 (Matrix.diagonal z)
  let u : ((Σ j : g,Fin 1 ⊕ {i : p // f i=j}) ⊕ s) → ℝ :=
    Sum.elim (fun x => W x (Sum.inl x.1)) (fun _ => 0)
  obtain ⟨hT,hT',hTspec⟩ := rectangular_singleton_extension (s:=s) V hV hV'
  obtain ⟨hQ',hQC',hC',hD',hCD'⟩ := singleton_signal_geometry Q hQ C D hQC hC hD hCD z (fun i => (hz i).le)
  refine ⟨T,Q',C',D',u,hT,hT',hQ',hQC',hC',hD',hCD',?_,?_,?_,?_⟩
  · intro i j
    cases i with
    | inl x =>
      change (∑ a : g,W x (Sum.inl a)*Q0 a j)=W x (Sum.inl x.1)*Q0 x.1 j
      apply Finset.sum_eq_single x.1
      · intro b _ hb
        rw [hrow x b hb,zero_mul]
      · simp
    | inr x => rfl
  · intro i x hix
    cases i with
    | inl i =>
      cases x with
      | inl x => exact hcross i x (fun hh => hix (congrArg some hh))
      | inr x => rfl
    | inr i =>
      cases x with
      | inl x => rfl
      | inr x => exact False.elim (hix rfl)
  · intro i j hij
    cases i with
    | inl i =>
      have hh : i.1=j := Option.some.inj hij
      subst j
      exact hdiag i
    | inr i => cases hij
  · intro a
    change T*Matrix.diagonal (Sum.elim (Sum.elim (Sum.elim a b) d) z)*Tᴴ=_
    rw [hTspec,hspec]
    exact singleton_signal_synthesis Q (Matrix.diagonal a) C (Matrix.diagonal z)

end SpectralComparison
