import SpectralComparison.RobustLargeFrame

/-! A unit isotropic direction for every nonempty real symmetric traceless matrix. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Zero-sum real diagonal data have a unit vector with zero quadratic form. -/
theorem zero_sum_unit_isotropic {n : Type*} [Fintype n] [DecidableEq n] [Nonempty n]
    (d : n → ℝ) (hd : ∑ i,d i=0) :
    ∃ x : n → ℝ, (∑ i,x i*x i)=1 ∧ (∑ i,d i*x i*x i)=0 := by
  classical
  by_cases hz : ∃ i,d i=0
  · obtain ⟨i,hi⟩ := hz
    exact ⟨fun j => if j=i then 1 else 0,by simp,by simp [hi]⟩
  have hp : ∃ p,0<d p := by
    by_contra! hn
    have hneg : ∑ i,d i<0 := Finset.sum_neg (fun i _ => lt_of_le_of_ne (hn i) (by intro h; exact hz ⟨i,h⟩)) Finset.univ_nonempty
    linarith
  have hn : ∃ p,d p<0 := by
    by_contra! hp'
    have hpos : 0<∑ i,d i := Finset.sum_pos (fun i _ => lt_of_le_of_ne (hp' i) (by intro h; exact hz ⟨i,h.symm⟩)) Finset.univ_nonempty
    linarith
  obtain ⟨p,hp⟩ := hp
  obtain ⟨q,hq⟩ := hn
  have hpq : p≠q := by intro h; subst q; linarith
  have hdiff : 0<d p-d q := by linarith
  let c := Real.sqrt (-d q/(d p-d q))
  let e := Real.sqrt (d p/(d p-d q))
  have hc : c*c= -d q/(d p-d q) := by dsimp [c]; rw [← sq,Real.sq_sqrt (div_nonneg (neg_nonneg.mpr hq.le) hdiff.le)]
  have he : e*e= d p/(d p-d q) := by dsimp [e]; rw [← sq,Real.sq_sqrt (by positivity)]
  let x := fun i => (if i=p then c else 0)+(if i=q then e else 0)
  have hnorm : (∑ i,x i*x i)=c*c+e*e := by
    simp [x,mul_add,add_mul,Finset.sum_add_distrib,hpq,Ne.symm hpq]
  have hquad : (∑ i,d i*x i*x i)=d p*(c*c)+d q*(e*e) := by
    simp [x,mul_add,add_mul,Finset.sum_add_distrib,hpq,Ne.symm hpq,mul_assoc]
  refine ⟨x,?_,?_⟩
  · rw [hnorm,hc,he,← add_div]
    apply (div_eq_one_iff_eq (ne_of_gt hdiff)).mpr
    ring
  · rw [hquad,hc,he]
    field_simp
    ring

/-- A real symmetric trace-zero matrix in positive dimension has a unit isotropic column. -/
theorem exists_traceless_isotropic_column {n : Type*} [Fintype n] [DecidableEq n] [Nonempty n]
    {A : Matrix n n ℝ} (hA : A.IsHermitian) (htr : A.trace=0) :
    ∃ v : Matrix n (Fin 1) ℝ, vᴴ*v=1 ∧ vᴴ*A*v=0 := by
  classical
  have hd : ∑ i,hA.eigenvalues i=0 := by simpa using hA.trace_eq_sum_eigenvalues.symm.trans htr
  obtain ⟨x,hx,hxd⟩ := zero_sum_unit_isotropic hA.eigenvalues hd
  let U : Matrix n n ℝ := hA.eigenvectorUnitary
  have hU : Uᴴ*U=1 := by simpa only [Matrix.star_eq_conjTranspose] using Unitary.coe_star_mul_self hA.eigenvectorUnitary
  have he : Uᴴ*A*U=Matrix.diagonal hA.eigenvalues := by
    conv_lhs => rw [real_spectral_decomposition hA]
    change Uᴴ*(U*Matrix.diagonal hA.eigenvalues*Uᴴ)*U=_
    simp only [← Matrix.mul_assoc,hU,Matrix.one_mul]
    rw [Matrix.mul_assoc,hU,Matrix.mul_one]
  let B : Matrix n (Fin 1) ℝ := Matrix.of (fun i _ => x i)
  have hB : Bᴴ*B=1 := by
    ext i j
    have hi : i=0 := Subsingleton.elim _ _
    have hj : j=0 := Subsingleton.elim _ _
    subst i; subst j
    simpa [B,Matrix.mul_apply,Matrix.conjTranspose_apply] using hx
  have hBd : Bᴴ*Matrix.diagonal hA.eigenvalues*B=0 := by
    ext i j
    change (∑ a,(Bᴴ*Matrix.diagonal hA.eigenvalues) i a*B a j)=0
    simp only [Matrix.mul_diagonal,Matrix.conjTranspose_apply,star_trivial,B,Matrix.of_apply]
    simpa only [mul_comm,mul_left_comm,mul_assoc] using hxd
  refine ⟨U*B,?_,?_⟩
  · rw [Matrix.conjTranspose_mul]
    calc
      Bᴴ*Uᴴ*(U*B)=Bᴴ*(Uᴴ*U)*B := by simp only [Matrix.mul_assoc]
      _ = 1 := by rw [hU,Matrix.mul_one,hB]
  · rw [Matrix.conjTranspose_mul]
    calc
      Bᴴ*Uᴴ*A*(U*B)=Bᴴ*(Uᴴ*A*U)*B := by simp only [Matrix.mul_assoc]
      _ = 0 := by rw [he,hBd]

end SpectralComparison
