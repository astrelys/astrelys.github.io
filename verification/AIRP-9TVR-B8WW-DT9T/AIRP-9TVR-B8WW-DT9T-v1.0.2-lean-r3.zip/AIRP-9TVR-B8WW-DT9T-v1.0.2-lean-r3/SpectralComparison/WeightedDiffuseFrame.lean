import SpectralComparison.WeightedGroupFrame
import SpectralComparison.DiffuseGroups
import SpectralComparison.DiffuseLabels
import SpectralComparison.BalancedFrame

noncomputable section
open Matrix
namespace SpectralComparison

/-- Diffuse weights produce the actual weighted frame, with the original Fin labels and stronger cost. -/
theorem weighted_frame_diffuse_large {k p : ℕ} (hk : 4 ≤ k)
    (d : Fin (8*k+p) → ℝ) (hd : ∀ i, 0 < d i) (horder : Antitone d)
    (hhead : (∑ i : Fin (8*k), d (i.castAdd p)) < (∑ i,d i)/2) :
    ∃ R : Matrix (Fin (k+(8*k+p))) (Fin (8*k+p)) ℝ, Rᴴ * R = 1 ∧
      ∀ J : Finset (Fin (k+(8*k+p))), J.card = 8*k+p →
        IsUnit ((R.submatrix (fun i : J => (i : Fin (k+(8*k+p)))) id)ᴴ *
          R.submatrix (fun i : J => (i : Fin (k+(8*k+p)))) id) →
        Real.sqrt k / 128000000000 * (∑ i,d i) ≤ (diagonal d *
          ((R.submatrix (fun i : J => (i : Fin (k+(8*k+p)))) id)ᴴ *
            R.submatrix (fun i : J => (i : Fin (k+(8*k+p)))) id)⁻¹).trace := by
  classical
  obtain ⟨S,hS,_,f,_,hmass⟩ := exists_diffuse_reserve_and_groups (q:=0) (by omega) (by omega) d hd horder hhead
  obtain ⟨Q0,hQ0,hbase⟩ := exists_balanced_parseval_frame hk
  let b := fun i : S => d (i.val.natAdd (8*k))
  let a := fun i : ↥Sᶜ => d (i.val.natAdd (8*k))
  let z := fun i : Fin (8*k) => d (i.castAdd p)
  let w : (S ⊕ ↥Sᶜ) ⊕ Fin (8*k) → ℝ := Sum.elim (Sum.elim b a) z
  have hdim : Fintype.card S + Fintype.card (Fin k) = Fintype.card (Fin (2*k)) := by
    simp only [Fintype.card_coe, Fintype.card_fin]
    omega
  have hs : 0 < ∑ i,d i := Finset.sum_pos (fun i _ => hd i) ⟨⟨0,by omega⟩,Finset.mem_univ _⟩
  have hk0 : (0 : ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hm (j : Fin (2*k)) : (∑ i,d i)/(8*k) ≤ ∑ i : {i : ↥Sᶜ // f i = j}, a i.val := by
    have hh := (hmass j).le
    change (∑ i,d i)/(8*k) ≤ ∑ i : ↥Sᶜ, if f i = j then a i else 0 at hh
    simpa only [← Finset.sum_filter, ← Finset.sum_subtype_eq_sum_filter, Finset.subtype_univ] using hh
  obtain ⟨R,hR,hcost⟩ := exists_weighted_group_frame f a (fun i => hd _) Q0 hQ0 hdim
    b (fun i => hd _) z (fun i => hd _)
    (by positivity : 0 ≤ (∑ i,d i)/(8*k)) hm
    (L := (k:ℝ)*Real.sqrt k/4000000000)
    (fun H hH _ => (hbase H (by simpa using hH)).2)
  let et : ((S ⊕ ↥Sᶜ) ⊕ Fin (8*k)) ≃ Fin (8*k+p) :=
    (Equiv.sumCongr (reservePartitionEquiv S) (Equiv.refl _)).trans
      ((Equiv.sumComm _ _).trans finSumFinEquiv)
  have hweight : w = d ∘ et := by
    funext i
    rcases i with (i | i) | i <;> rfl
  have hsum : (∑ i,w i) = ∑ i,d i := by rw [hweight]; exact et.sum_comp d
  let n := (Σ j : Fin (2*k), Fin 1 ⊕ {i : ↥Sᶜ // f i = j}) ⊕ Fin (8*k)
  have hnc : Fintype.card n = k+(8*k+p) := by
    have hh := Fintype.card_congr (groupCoordinateEquiv f)
    have hc : Fintype.card ↥Sᶜ = p-S.card := by simp
    dsimp [n]
    simp only [Fintype.card_sum, Fintype.card_fin] at hh ⊢
    have hsp : S.card ≤ p := by simpa using S.card_le_univ
    omega
  let er : Fin (k+(8*k+p)) ≃ n := (finCongr hnc.symm).trans (Fintype.equivFin n).symm
  have hri := weighted_frame_reindex R hR w hcost er et.symm
  have hw : w ∘ et.symm = d := by rw [hweight]; funext i; simp
  rw [hw] at hri
  refine ⟨R.submatrix er et.symm,hri.1,?_⟩
  intro J hJ hu
  apply le_trans _ (hri.2 J (by simpa using hJ) hu)
  change _ ≤ (∑ i,w i) + (∑ i,d i)/(8*k)*((k:ℝ)*Real.sqrt k/4000000000)
  rw [hsum]
  have he : (∑ i,d i)/(8*k)*((k:ℝ)*Real.sqrt k/4000000000) =
      Real.sqrt k/32000000000*(∑ i,d i) := by field_simp; ring
  rw [he]
  have hsqrt := Real.sqrt_nonneg (k:ℝ)
  nlinarith

end SpectralComparison
