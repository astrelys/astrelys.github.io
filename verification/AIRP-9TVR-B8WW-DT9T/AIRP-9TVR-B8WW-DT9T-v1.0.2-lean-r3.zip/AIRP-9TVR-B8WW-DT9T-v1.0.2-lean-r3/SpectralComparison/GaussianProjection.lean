import Mathlib.Probability.Distributions.Gaussian.Multivariate
import SpectralComparison.GaussianSquares

/-! Fixed orthogonal projections of actual standard Gaussian measures. -/
noncomputable section
open MeasureTheory ProbabilityTheory Matrix
open scoped RealInnerProductSpace
namespace SpectralComparison

/-- The adjoint of an isometric embedding sends a standard Gaussian to a standard Gaussian.
This is a fixed-map law; it does not assert a conditional law for a random kernel basis. -/
theorem stdGaussian_map_adjoint_isometry
    {E F : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]
    [NormedAddCommGroup F] [InnerProductSpace ℝ F] [FiniteDimensional ℝ F]
    [MeasurableSpace F] [BorelSpace F] (f : F →ₗᵢ[ℝ] E) :
    (stdGaussian E).map f.toContinuousLinearMap.adjoint = stdGaussian F := by
  apply Measure.ext_of_charFun
  ext t
  rw [charFun_apply, integral_map (by fun_prop) (by fun_prop)]
  simp_rw [ContinuousLinearMap.adjoint_inner_left]
  change charFun (stdGaussian E) (f t) = charFun (stdGaussian F) t
  rw [charFun_stdGaussian, charFun_stdGaussian, f.norm_map]

/-- Coordinates of a Euclidean standard Gaussian have the literal product Gaussian law. -/
theorem stdGaussian_coordinates_hasLaw {ι : Type*} [Fintype ι] :
    HasLaw (WithLp.ofLp : EuclideanSpace ℝ ι → (ι → ℝ))
      (Measure.pi (fun _ : ι => gaussianReal 0 1)) (stdGaussian (EuclideanSpace ℝ ι)) := by
  refine ⟨by fun_prop, ?_⟩
  rw [← map_pi_eq_stdGaussian, Measure.map_map (by fun_prop) (by fun_prop)]
  simp only [Function.comp_def, Measure.map_id']

/-- A fixed orthogonal projection has independent standard Gaussian coordinates. -/
theorem projected_gaussian_coordinates_hasLaw
    {E Ω ι : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]
    [MeasurableSpace Ω] [Fintype ι] {μ : Measure Ω}
    (X : Ω → E) (hX : HasLaw X (stdGaussian E) μ)
    (f : EuclideanSpace ℝ ι →ₗᵢ[ℝ] E) :
    HasLaw (fun ω => WithLp.ofLp (f.toContinuousLinearMap.adjoint (X ω)))
      (Measure.pi (fun _ : ι => gaussianReal 0 1)) μ := by
  have hf : HasLaw f.toContinuousLinearMap.adjoint (stdGaussian (EuclideanSpace ℝ ι))
      (stdGaussian E) := ⟨by fun_prop, stdGaussian_map_adjoint_isometry f⟩
  exact stdGaussian_coordinates_hasLaw.fun_comp (hf.fun_comp hX)

/-- Fubini transports the fixed projection law through an independently sampled base.
Joint measurability of the supplied family is explicit; existence of a measurable kernel
basis for a random matrix is not asserted here. -/
theorem stdGaussian_random_projection_map
    {E F B : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]
    [NormedAddCommGroup F] [InnerProductSpace ℝ F] [FiniteDimensional ℝ F]
    [MeasurableSpace F] [BorelSpace F] [MeasurableSpace B]
    (ν : Measure B) [IsProbabilityMeasure ν] (f : B → F →ₗᵢ[ℝ] E)
    (hm : Measurable (fun x : B × E => (f x.1).toContinuousLinearMap.adjoint x.2)) :
    (ν.prod (stdGaussian E)).map
      (fun x : B × E => (f x.1).toContinuousLinearMap.adjoint x.2) = stdGaussian F := by
  ext s hs
  rw [Measure.map_apply hm hs, Measure.prod_apply (hm hs)]
  have hb (b : B) : (stdGaussian E) ((f b).toContinuousLinearMap.adjoint ⁻¹' s) =
      stdGaussian F s := by
    rw [← Measure.map_apply (by fun_prop) hs, stdGaussian_map_adjoint_isometry]
  change (∫⁻ b, (stdGaussian E) ((f b).toContinuousLinearMap.adjoint ⁻¹' s) ∂ν) = _
  simp_rw [hb]
  simp

/-- Literal matrices with orthonormal columns preserve Euclidean inner products. -/
theorem orthonormal_matrix_preserves_inner {ι κ : Type*} [Fintype ι] [Fintype κ]
    [DecidableEq ι] [DecidableEq κ] (R : Matrix ι κ ℝ) (hR : Rᴴ*R = 1)
    (x y : EuclideanSpace ℝ κ) :
    ⟪R.toEuclideanLin x, R.toEuclideanLin y⟫ = ⟪x,y⟫ := by
  rw [← LinearMap.adjoint_inner_right, ← Matrix.toEuclideanLin_conjTranspose_eq_adjoint]
  change ⟪x, ((Rᴴ.toLpLin 2 2).comp (R.toLpLin 2 2)) y⟫ = _
  rw [← Matrix.toLpLin_mul_same, hR, Matrix.toLpLin_one]
  rfl

/-- A fixed matrix with orthonormal columns sends a standard Gaussian row to a
standard Gaussian in the smaller coordinate space. -/
theorem orthonormal_matrix_gaussian_map {ι κ : Type*} [Fintype ι] [Fintype κ]
    [DecidableEq ι] [DecidableEq κ] (R : Matrix ι κ ℝ) (hR : Rᴴ*R = 1) :
    (stdGaussian (EuclideanSpace ℝ ι)).map Rᴴ.toEuclideanLin =
      stdGaussian (EuclideanSpace ℝ κ) := by
  let f := R.toEuclideanLin.isometryOfInner (orthonormal_matrix_preserves_inner R hR)
  have hf : f.toContinuousLinearMap.adjoint = Rᴴ.toEuclideanLin.toContinuousLinearMap := by
    rw [Matrix.toEuclideanLin_conjTranspose_eq_adjoint, LinearMap.adjoint_toContinuousLinearMap]
    rfl
  have h := stdGaussian_map_adjoint_isometry f
  rw [hf] at h
  exact h

end SpectralComparison
