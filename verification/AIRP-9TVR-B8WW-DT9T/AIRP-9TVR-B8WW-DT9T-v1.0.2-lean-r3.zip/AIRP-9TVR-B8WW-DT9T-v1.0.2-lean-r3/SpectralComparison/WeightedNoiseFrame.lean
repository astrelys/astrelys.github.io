import SpectralComparison.WeightedSelectionCost
import SpectralComparison.NoiseSplit

noncomputable section
open Matrix
namespace SpectralComparison

/-- Extract the actual complementary noise frame from a simultaneous spectral synthesis. -/
theorem weighted_noise_frame {n r p : Type*} [Fintype n] [Fintype r] [Fintype p]
    [DecidableEq n] [DecidableEq r] [DecidableEq p]
    (V : Matrix n (r ⊕ p) ℝ) (hV : Vᴴ * V = 1) (hV' : V * Vᴴ = 1)
    (Q : Matrix n r ℝ) (C : Matrix n n ℝ) (b : p → ℝ)
    (hs0 : V * diagonal (Sum.elim (fun _ : r => 0) b) * Vᴴ = C)
    (hs1 : V * diagonal (Sum.elim (fun _ : r => 1) b) * Vᴴ = Q * Qᴴ + C) :
    ∃ R : Matrix n p ℝ, Rᴴ * R = 1 ∧ Q * Qᴴ + R * Rᴴ = 1 ∧
      R * diagonal b * Rᴴ = C := by
  let A := V.submatrix id Sum.inl
  let R := V.submatrix id Sum.inr
  have hv : V = Matrix.fromCols A R := by ext i j; cases j <;> rfl
  have hr : Rᴴ * R = 1 := by
    rw [Matrix.conjTranspose_submatrix,
      ← Matrix.submatrix_mul _ _ Sum.inr id Sum.inr Function.bijective_id, hV]
    exact Matrix.submatrix_one Sum.inr Sum.inr_injective
  have hc : R * diagonal b * Rᴴ = C := by
    rw [hv, fromCols_spectral_synthesis] at hs0
    simpa using hs0
  have ha : A * Aᴴ = Q * Qᴴ := by
    rw [hv, fromCols_spectral_synthesis] at hs1
    simp only [Matrix.diagonal_one, Matrix.mul_one] at hs1
    rw [hc] at hs1
    exact add_right_cancel hs1
  refine ⟨R, hr, ?_, hc⟩
  rw [hv, Matrix.conjTranspose_fromCols_eq_fromRows_conjTranspose, Matrix.fromCols_mul_fromRows] at hV'
  rw [ha] at hV'
  exact hV'

/-- Complementary weighted trace identity with the selected noise rows as the direct argument. -/
theorem weighted_complement_trace_selected {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p] (R : Matrix n p ℝ) (hR : Rᴴ * R = 1)
    (B : Matrix p p ℝ) (J : Finset n)
    (hu : IsUnit ((R.submatrix (fun i : J => (i : n)) id)ᴴ *
      R.submatrix (fun i : J => (i : n)) id)) :
    IsUnit (principal (1 - R * Rᴴ) Jᶜ) ∧
    (B * ((R.submatrix (fun i : J => (i : n)) id)ᴴ *
      R.submatrix (fun i : J => (i : n)) id)⁻¹).trace =
      B.trace + ((principal (1 - R * Rᴴ) Jᶜ)⁻¹ *
        principal (R * B * Rᴴ) Jᶜ).trace := by
  let E := R.submatrix (fun i : ↥(Jᶜ) => (i : n)) id
  have he : (R.submatrix (fun i : J => (i : n)) id)ᴴ *
      R.submatrix (fun i : J => (i : n)) id = 1 - Eᴴ * E := by
    have hh := parseval_complement_row_gram R hR J
    change Eᴴ * E = 1 - _ at hh
    rw [hh]; abel
  have hp : principal (1 - R * Rᴴ) Jᶜ = 1 - E * Eᴴ :=
    complementary_projection_block R Jᶜ
  have hc : principal (R * B * Rᴴ) Jᶜ = E * B * Eᴴ := by
    dsimp [principal, E]
    rw [Matrix.submatrix_mul _ _ _ id _ Function.bijective_id,
      Matrix.submatrix_mul _ _ _ id id Function.bijective_id, Matrix.submatrix_id_id]
    rfl
  rw [he] at hu ⊢
  have hunit : IsUnit (1 - E * Eᴴ) := (complement_gram_isUnit_iff E).mpr hu
  refine ⟨hp.symm ▸ hunit, ?_⟩
  have hinv := complement_gram_inverse Eᴴ
    (by simpa only [Matrix.conjTranspose_conjTranspose] using hunit)
  simp only [Matrix.conjTranspose_conjTranspose] at hinv
  rw [hinv, Matrix.mul_add, Matrix.mul_one, Matrix.trace_add, hp, hc]
  congr 1
  rw [← Matrix.mul_assoc, ← Matrix.mul_assoc, Matrix.trace_mul_cycle]
  simpa only [Matrix.mul_assoc] using Matrix.trace_mul_comm (E * B * Eᴴ) (1 - E * Eᴴ)⁻¹

end SpectralComparison
