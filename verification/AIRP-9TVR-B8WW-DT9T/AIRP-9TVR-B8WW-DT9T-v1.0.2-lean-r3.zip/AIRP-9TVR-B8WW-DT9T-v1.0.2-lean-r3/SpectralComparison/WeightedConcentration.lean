import SpectralComparison.WeightedScale

noncomputable section
open Finset Matrix
namespace SpectralComparison

/-- The E.1 bound in the large-dimensional branch when the first min(m,8k) weights carry half the mass. -/
theorem weighted_frame_concentrated {k m : ℕ} (hk : 1≤k) (hkm : k<m)
    (b : Fin m → ℝ) (hb : ∀ i,0<b i) (horder : Antitone b)
    (hprefix : (∑ i,b i)/2≤∑ i : Fin (min m (8*k)),b (i.castLE (min_le_left _ _))) :
    ∃ R : Matrix (Fin (k+m)) (Fin m) ℝ,Rᴴ*R=1 ∧
      ∀ J : Finset (Fin (k+m)),J.card=m →
        IsUnit ((R.submatrix (fun i : J => (i:Fin (k+m))) id)ᴴ*R.submatrix (fun i : J => (i:Fin (k+m))) id) →
        weightedGamma k m*(∑ i,b i)≤(Matrix.diagonal b*
          ((R.submatrix (fun i : J => (i:Fin (k+m))) id)ᴴ*R.submatrix (fun i : J => (i:Fin (k+m))) id)⁻¹).trace := by
  let h := min m (8*k)
  have hpos : 1≤h := le_min (by omega) (by omega)
  let v := fun i : Fin h => b (i.castLE (min_le_left _ _))
  obtain ⟨i,_,hscale⟩ := exists_weighted_prefix_scale hk hpos v (fun i => hb _)
  let j : Fin m := i.castLE (min_le_left _ _)
  have ht : i.val+1≤m := by have hi:=i.isLt; have hh:=min_le_left m (8*k); dsimp [h] at hi; omega
  have hhead : ∀ l : Fin (i.val+1),b j≤b (l.castLE ht) := by
    intro l
    apply horder
    change l.val ≤ i.val
    have := l.isLt
    omega
  obtain ⟨R,hR,hcost⟩ := exists_weighted_prefix_frame hk (by omega) ht b hb (hb j).le hhead
  refine ⟨R,hR,?_⟩
  intro J hJ hu
  apply le_trans _ (hcost J hJ hu)
  have hs := hprefix.trans (hscale (min_le_right _ _))
  have hk0 : 0<(k:ℝ) := by exact_mod_cast (by omega : 0<k)
  have hsk : 0<Real.sqrt (k:ℝ) := Real.sqrt_pos.mpr hk0
  have hmul := (le_div_iff₀ hsk).mp (show (∑ l,b l)/2≤
      (4*(((k:ℝ)+(i.val:ℝ)+1)*Real.sqrt (min k (i.val+1):ℕ)*b j))/Real.sqrt k by
        change (∑ l,b l)/2≤_ at hs
        convert hs using 1 <;> ring)
  dsimp only [weightedGamma]
  rw [ite_eq_right (by omega : ¬m≤k),Nat.cast_add,Nat.cast_one]
  apply (le_div_iff₀ (by norm_num : (0:ℝ)<16000000000)).mpr
  have he : (Real.sqrt k/128000000000*(∑ l,b l))*16000000000=Real.sqrt k*(∑ l,b l)/8 := by ring
  rw [he]
  nlinarith

end SpectralComparison
