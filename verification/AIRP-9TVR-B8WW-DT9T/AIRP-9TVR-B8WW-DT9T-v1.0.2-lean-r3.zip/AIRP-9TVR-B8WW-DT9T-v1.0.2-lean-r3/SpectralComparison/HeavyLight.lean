import SpectralComparison.RobustWeights

/-! Exact counting constraints for the heavy/light selection split in (7.9). -/
noncomputable section
namespace SpectralComparison

/-- Each heavy group spends at least one selection beyond the support count. -/
theorem heavy_group_count_excess {n : Type*} [Fintype n] [DecidableEq n] (w : n → ℕ) :
    (Finset.univ.filter (fun i => 2≤w i)).card+
      (Finset.univ.filter (fun i => 0<w i)).card≤∑ i,w i := by
  classical
  have hpoint (i : n) : (if 2≤w i then 1 else 0)+(if 0<w i then 1 else 0)≤w i := by
    split_ifs <;> omega
  have hh := Finset.sum_le_sum (s:=Finset.univ) (fun i _ => hpoint i)
  rw [Finset.sum_add_distrib] at hh
  simpa [Finset.sum_boole] using hh

/-- Heavy and light groups partition the nonempty groups. -/
theorem heavy_light_support_partition {n : Type*} [Fintype n] [DecidableEq n] (w : n → ℕ) :
    Disjoint (Finset.univ.filter (fun i => 2≤w i)) (Finset.univ.filter (fun i => w i=1)) ∧
      (Finset.univ.filter (fun i => 2≤w i)).card+
        (Finset.univ.filter (fun i => w i=1)).card=(Finset.univ.filter (fun i => 0<w i)).card := by
  classical
  have hdis : Disjoint (Finset.univ.filter (fun i => 2≤w i)) (Finset.univ.filter (fun i => w i=1)) := by
    apply Finset.disjoint_left.mpr
    intro i hi hj
    simp only [Finset.mem_filter,Finset.mem_univ,true_and] at hi hj
    omega
  refine ⟨hdis,?_⟩
  rw [← Finset.card_union_of_disjoint hdis]
  congr 1
  ext i
  simp only [Finset.mem_union,Finset.mem_filter,Finset.mem_univ,true_and]
  omega

/-- Equation (7.9)'s counting conclusions, including the exact hypotheses for Lemma 5.1. -/
theorem heavy_light_card_bounds {n : Type*} [Fintype n] [DecidableEq n] {k q : ℕ}
    (hq : 4*q≤k) (w : n → ℕ) (hsum : ∑ i,w i≤k)
    (hsupport : k-q≤(Finset.univ.filter (fun i => 0<w i)).card) :
    let H := Finset.univ.filter (fun i => 2≤w i)
    let L := Finset.univ.filter (fun i => w i=1)
    Disjoint H L ∧ H.card≤q ∧ 4*H.card≤k ∧ H.card+L.card≤k := by
  obtain ⟨hdis,hpart⟩ := heavy_light_support_partition w
  have hexcess := heavy_group_count_excess w
  exact ⟨hdis,by omega,by omega,by omega⟩

end SpectralComparison
