import SpectralComparison.WeightedRankOne

noncomputable section
open Matrix Finset
namespace SpectralComparison
variable {g p : Type*} [Fintype g] [Fintype p] [DecidableEq g] [DecidableEq p]

/-- Different positive replication counts still preserve Parseval columns. -/
theorem variable_replication_parseval (W : Matrix g p ℝ) (hW : Wᴴ*W=1)
    (r : g → ℕ) (hr : ∀ i,0<r i) :
    let Q : Matrix (Σ i,Fin (r i)) p ℝ := Matrix.of (fun i j => W i.1 j/Real.sqrt (r i.1))
    Qᴴ*Q=1 := by
  dsimp only
  ext a b
  have h := congrFun (congrFun hW a) b
  simp only [Matrix.mul_apply,Matrix.conjTranspose_apply,Matrix.of_apply,star_trivial] at h ⊢
  rw [Fintype.sum_sigma]
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
  have he (i : g) : (r i:ℝ)*(W i a/Real.sqrt (r i)*(W i b/Real.sqrt (r i)))=W i a*W i b := by
    have hp : 0<(r i:ℝ) := by exact_mod_cast hr i
    have hs := Real.sq_sqrt hp.le
    have hn : Real.sqrt (r i)≠0 := (Real.sqrt_pos.mpr hp).ne'
    field_simp
    rw [hs]
    ring
  simpa only [he] using h

/-- The actual replicated Gram is a diagonally scaled pullback. -/
theorem variable_replication_gram (W : Matrix g p ℝ) (r : g → ℕ) :
    let Q : Matrix (Σ i,Fin (r i)) p ℝ := Matrix.of (fun i j => W i.1 j/Real.sqrt (r i.1))
    ∀ i j,(Q*Qᴴ) i j=(W*Wᴴ) i.1 j.1/(Real.sqrt (r i.1)*Real.sqrt (r j.1)) := by
  dsimp only
  intro i j
  simp only [Matrix.mul_apply,Matrix.conjTranspose_apply,Matrix.of_apply,star_trivial,Finset.sum_div]
  apply Finset.sum_congr rfl
  intro l _
  ring

/-- Every nonsingular selected block uses distinct original groups. -/
theorem variable_replication_selected_injective (W : Matrix g p ℝ) (r : g → ℕ)
    (I : Finset (Σ i,Fin (r i)))
    (hI : IsUnit (principal
      ((Matrix.of (fun (i : Σ l,Fin (r l)) (j : p) => W i.1 j/Real.sqrt (r i.1)))*(Matrix.of (fun (i : Σ l,Fin (r l)) (j : p) => W i.1 j/Real.sqrt (r i.1)))ᴴ) I)) :
    Function.Injective (fun i : I => i.val.1) := by
  have hi := (Matrix.linearIndependent_rows_of_isUnit hI).injective
  intro a b hab
  apply hi
  ext j
  simp only [Matrix.row,principal,Matrix.submatrix_apply,Matrix.mul_apply,Matrix.conjTranspose_apply,Matrix.of_apply,star_trivial]
  simp only [hab]

/-- A k-element image in k+1 groups omits exactly one group. -/
theorem image_omits_one {j : Type*} [Fintype j] [DecidableEq j]
    (f : j → g) (hf : Function.Injective f) (hc : Fintype.card g=Fintype.card j+1) :
    ∃ i : g,Finset.univ.image f=Finset.univ.erase i := by
  let S := Finset.univ.image f
  have hS : S.card=Fintype.card j := by simp [S,Finset.card_image_of_injective _ hf]
  have hcard : (Finset.univ\S).card=1 := by
    rw [Finset.card_sdiff_of_subset (Finset.subset_univ S),Finset.card_univ,hc,hS]
    omega
  obtain ⟨i,hi⟩ := Finset.card_eq_one.mp hcard
  refine ⟨i,?_⟩
  ext l
  have hh := congrArg (fun T : Finset g => l∈T) hi
  simp only [Finset.mem_sdiff,Finset.mem_univ,true_and,Finset.mem_singleton] at hh
  change l∈S ↔ l∈Finset.univ.erase i
  simp only [Finset.mem_erase,Finset.mem_univ,and_true]
  tauto

end SpectralComparison
