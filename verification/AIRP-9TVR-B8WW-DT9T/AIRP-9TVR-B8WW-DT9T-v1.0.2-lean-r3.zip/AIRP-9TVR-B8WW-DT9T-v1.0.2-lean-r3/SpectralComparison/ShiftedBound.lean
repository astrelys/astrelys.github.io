import SpectralComparison.WeightedAsymptotics

noncomputable section
open Matrix Finset
namespace SpectralComparison

/-- The sharp spectral envelope for any partition with k-q leading labels. -/
theorem shifted_spectral_bound {k q : ℕ} (hk : 4≤k) (hq : 2*q≤k)
    (eig : Fin (2*k) → ℝ) (heig : ∀ i,0<eig i) (I : Finset (Fin (2*k))) (hI : I.card=k-q)
    {a b : ℝ} (ha : 0<a) (hb : 0<b) (hba : b≤a)
    (hleft : ∀ i∈I,a≤eig i) (hright : ∀ i∉I,b≤eig i) :
    let L := (k:ℝ)^2/(100000000000000000000000*((q:ℝ)+Real.sqrt k))
    a*b*L/(a-b+b*L)≤worstError eig k := by
  classical
  let L := (k:ℝ)^2/(100000000000000000000000*((q:ℝ)+Real.sqrt k))
  have hk0 : (0:ℝ)<k := by exact_mod_cast (by omega : 0<k)
  have hL : 0<L := by dsimp [L]; exact div_pos (sq_pos_of_pos hk0) (mul_pos (by norm_num) (add_pos_of_nonneg_of_pos (Nat.cast_nonneg _) (Real.sqrt_pos.mpr hk0)))
  have hbeta : 0≤b⁻¹-a⁻¹ := sub_nonneg.mpr (by simpa only [one_div] using one_div_le_one_div_of_le hb hba)
  obtain ⟨P,hP,hPP,hr,hblocks⟩ := paper_shifted_projection hk hq
  obtain ⟨V,hV,hK,hgap⟩ := exists_sharp_prescribed_covariance hP hPP I
    (by rw [hr,hI]; omega) eig heig ha hb hleft hright
  have hmain : a*b*L/(a-b+b*L)≤bestError (V.transpose*Matrix.diagonal eig*V) k := by
    apply le_bestError _ (by simp; omega)
    intro J hJ
    let S := Finset.univ\J
    have hS : S.card=k := by
      dsimp [S]
      rw [Finset.card_sdiff_of_subset (Finset.subset_univ _),Finset.card_univ,Fintype.card_fin,hJ]
      omega
    let _ : Nonempty S := Finset.nonempty_coe_sort.mpr (Finset.card_pos.mp (by omega))
    have hblk := hblocks S hS
    have hbnd := hgap.submatrix (fun i : S => (i : Fin (2*k)))
    have heqb : (a⁻¹ • (1 : Matrix (Fin (2*k)) (Fin (2*k)) ℝ)+(b⁻¹-a⁻¹) • P-(V.transpose*Matrix.diagonal eig*V)⁻¹).submatrix (fun i : S => (i : Fin (2*k))) (fun i : S => (i : Fin (2*k))) =
        a⁻¹ • (1 : Matrix S S ℝ)+(b⁻¹-a⁻¹) • principal P S-principal (V.transpose*Matrix.diagonal eig*V)⁻¹ S := by
      simp only [Matrix.submatrix_sub,Matrix.submatrix_add,Matrix.submatrix_smul]
      change a⁻¹ • ((1 : Matrix (Fin (2*k)) (Fin (2*k)) ℝ).submatrix Subtype.val Subtype.val)+(b⁻¹-a⁻¹) • principal P S-principal (V.transpose*Matrix.diagonal eig*V)⁻¹ S=_
      rw [Matrix.submatrix_one _ Subtype.val_injective]
    rw [heqb] at hbnd
    have h := matrix_regularization_nonnegative_beta hblk.1 (principal_posDef hK.inv S)
      (inv_pos.mpr ha) hbeta hL hblk.2 hbnd
    have he : L/(b⁻¹-a⁻¹+a⁻¹*L)=a*b*L/(a-b+b*L) := by field_simp
    rw [he] at h
    rw [nystrom_trace_inverse_complement hK J]
    exact h
  exact hmain.trans (orbit_bestError_le_worstError eig heig V hV (by simp; omega))

/-- The complete original finite-noise conclusion (B.1), including the diagonal tail. -/
theorem paper_shifted_envelope {k q : ℕ} (hk : 4≤k) (hq : 2*q≤k)
    (eig : Fin (2*k) → ℝ) (heig : ∀ i,0<eig i) (horder : Antitone eig) :
    let a := eig ⟨k-q-1,by omega⟩
    let b := eig ⟨2*k-1,by omega⟩
    let L := (k:ℝ)^2/(100000000000000000000000*((q:ℝ)+Real.sqrt k))
    max (∑ i ∈ Finset.univ\Finset.Iio (⟨k,by omega⟩ : Fin (2*k)),eig i)
      (a*b*L/(a-b+b*L))≤worstError eig k := by
  dsimp only
  apply max_le
  · have h := tail_le_worstError eig heig (Finset.Iio (⟨k,by omega⟩ : Fin (2*k)))
      (by intro i hi j hj; apply horder; simp only [Finset.mem_Iio,not_lt] at hi hj; exact hi.le.trans hj)
      (by simp; omega)
    simpa using h
  · apply shifted_spectral_bound hk hq eig heig (Finset.Iio (⟨k-q,by omega⟩ : Fin (2*k)))
      (by simp) (heig _) (heig _) (horder (by change k-q-1≤2*k-1; omega))
    · intro i hi
      apply horder
      have hh := Finset.mem_Iio.mp hi
      change i.val≤k-q-1
      change i.val<k-q at hh
      omega
    · intro i _
      apply horder
      change i.val≤2*k-1
      omega

end SpectralComparison
