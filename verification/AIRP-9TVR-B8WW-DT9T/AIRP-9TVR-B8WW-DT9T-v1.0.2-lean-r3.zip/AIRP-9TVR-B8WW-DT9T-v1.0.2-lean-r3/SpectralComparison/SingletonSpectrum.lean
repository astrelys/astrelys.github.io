import SpectralComparison.FrameCompletion
import SpectralComparison.WorstOrientation

/-! Add singleton covariance coordinates to a rectangularly indexed orthogonal basis. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Extend a bijective orthogonal basis by singleton coordinates, preserving the literal spectrum. -/
theorem rectangular_singleton_extension {n l s : Type*} [Fintype n] [Fintype l] [Fintype s]
    [DecidableEq n] [DecidableEq l] [DecidableEq s]
    (V : Matrix n l ℝ) (hV : Vᴴ*V=1) (hV' : V*Vᴴ=1) :
    let W := Matrix.fromBlocks V 0 0 (1 : Matrix s s ℝ)
    Wᴴ*W=1 ∧ W*Wᴴ=1 ∧ ∀ a : l → ℝ,∀ b : s → ℝ,
      W*Matrix.diagonal (Sum.elim a b)*Wᴴ=
        Matrix.fromBlocks (V*Matrix.diagonal a*Vᴴ) 0 0 (Matrix.diagonal b) := by
  classical
  dsimp only
  constructor
  · simp only [Matrix.fromBlocks_conjTranspose,Matrix.conjTranspose_zero,Matrix.conjTranspose_one,
      Matrix.fromBlocks_multiply,Matrix.mul_zero,Matrix.zero_mul,Matrix.one_mul,zero_add,add_zero,hV]
    exact Matrix.fromBlocks_one
  constructor
  · simp only [Matrix.fromBlocks_conjTranspose,Matrix.conjTranspose_zero,Matrix.conjTranspose_one,
      Matrix.fromBlocks_multiply,Matrix.mul_zero,Matrix.zero_mul,Matrix.one_mul,zero_add,add_zero,hV']
    exact Matrix.fromBlocks_one
  · intro a b
    have hd : Matrix.diagonal (Sum.elim a b)=Matrix.fromBlocks (Matrix.diagonal a) 0 0 (Matrix.diagonal b) := by
      ext i j; cases i <;> cases j <;> simp [Matrix.diagonal_apply]
    rw [hd]
    simp only [Matrix.fromBlocks_conjTranspose,Matrix.conjTranspose_zero,Matrix.conjTranspose_one,
      Matrix.fromBlocks_multiply,Matrix.mul_zero,Matrix.zero_mul,Matrix.one_mul,Matrix.mul_one,zero_add,add_zero]

/-- Relabel a complete rectangularly indexed spectral synthesis as the literal original orthogonal orbit. -/
theorem reindex_spectral_orientation {n l : Type*} [Fintype n] [Fintype l]
    [DecidableEq n] [DecidableEq l] {N : ℕ}
    (V : Matrix n l ℝ) (hV : Vᴴ*V=1) (_hV' : V*Vᴴ=1)
    (e : l ≃ Fin N) (c : Fin N ≃ n) (eig : Fin N → ℝ) :
    ∃ O : Matrix (Fin N) (Fin N) ℝ,O.transpose*O=1 ∧
      O.transpose*Matrix.diagonal eig*O=
        (V*Matrix.diagonal (fun j => eig (e j))*Vᴴ).submatrix c c := by
  let U := V.submatrix c e.symm
  have hU : Uᴴ*U=1 := by
    rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,hV]
    exact Matrix.submatrix_one e.symm e.symm.injective
  have hU' : U*Uᴴ=1 := mul_eq_one_comm.mp hU
  have ht : U.transpose=Uᴴ := by ext i j; simp
  refine ⟨U.transpose,?_,?_⟩
  · rw [Matrix.transpose_transpose,ht,hU']
  · rw [Matrix.transpose_transpose,ht]
    have hd : Matrix.diagonal eig=(Matrix.diagonal (fun j => eig (e j))).submatrix e.symm e.symm := by
      rw [Matrix.submatrix_diagonal_equiv]
      congr 1
      funext i
      simp
    rw [hd]
    change V.submatrix c e.symm*(Matrix.diagonal (fun j => eig (e j))).submatrix e.symm e.symm*(V.submatrix c e.symm)ᴴ=_
    rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,Matrix.submatrix_mul_equiv]

end SpectralComparison
