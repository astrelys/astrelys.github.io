import SpectralComparison.WeightedConstants

noncomputable section
open Finset
namespace SpectralComparison
set_option maxHeartbeats 800000

theorem sum_tail_natAdd {k m : ℕ} (hm : 1 ≤ m) (eig : Fin (k+m) → ℝ) :
    (∑ i : Fin m, eig (i.natAdd k)) =
      ∑ i ∈ Finset.univ \ Finset.Iio (⟨k,by omega⟩ : Fin (k+m)), eig i := by
  have hh := indexed_tail_sum (k:=k) (n:=k+m) (by omega) eig
  let e : Fin m ≃ Fin (k+m-k) := finCongr (by omega)
  have he : (∑ i : Fin m, eig (i.natAdd k)) = ∑ j : Fin (k+m-k), eig ⟨k+j.val,by omega⟩ := by
    exact Fintype.sum_equiv e _ _ (fun i => rfl)
  exact he.trans hh

theorem spectralMean_le_indexed_tail {k m : ℕ} (hm : 1 ≤ m)
    (eig : Fin (k+m) → ℝ) (heig : ∀ i, 0 < eig i) :
    spectralMean eig k ≤ ((k:ℝ)+1) * ∑ i : Fin m, eig (i.natAdd k) := by
  have hh := spectralMean_le_tail eig heig (Finset.Iio (⟨k,by omega⟩ : Fin (k+m)))
  simpa only [Fin.card_Iio, ← sum_tail_natAdd hm eig] using hh

/-- E.2 with its exact diagonal/ridge maximum and the stated minimum ratio. -/
theorem paper_weighted_finite {k m : ℕ} (hk : 1 ≤ k) (hm : 1 ≤ m)
    (eig : Fin (k+m) → ℝ) (heig : ∀ i, 0 < eig i) (horder : Antitone eig) :
    let a := eig ⟨k-1,by omega⟩
    let s := ∑ i : Fin m, eig (i.natAdd k)
    max s (a*(weightedGamma k m*s)/(a+weightedGamma k m*s)) ≤ worstError eig k ∧
    spectralMean eig k / worstError eig k ≤
      ((k:ℝ)+1)*min 1 ((weightedGamma k m)⁻¹+s/a) := by
  let a := eig ⟨k-1,by omega⟩
  let s := ∑ i : Fin m, eig (i.natAdd k)
  have ha : 0 < a := heig _
  have hs : 0 < s := Finset.sum_pos (fun i _ => heig _) ⟨⟨0,by omega⟩,Finset.mem_univ _⟩
  have hx : 0 < worstError eig k := worstError_pos eig heig (by simp; omega)
  have hdiag : s ≤ worstError eig k := by
    change (∑ i : Fin m,eig (i.natAdd k)) ≤ _
    rw [sum_tail_natAdd hm eig]
    have hh := tail_le_worstError eig heig (Finset.Iio (⟨k,by omega⟩ : Fin (k+m)))
      (by intro i hi j hj; apply horder; simp only [Finset.mem_Iio,not_lt] at hi hj; exact hi.le.trans hj)
      (by simp; omega)
    simpa only [Fin.card_Iio] using hh
  have hl := weighted_worst_lower hk hm eig heig ha (by
    intro i
    apply horder
    change i.val ≤ k-1
    have := i.isLt
    omega)
  have hy := spectralMean_le_indexed_tail hm eig heig
  refine ⟨max_le hdiag hl,?_⟩
  rw [mul_min_of_nonneg _ _ (by positivity : (0:ℝ) ≤ (k:ℝ)+1)]
  apply le_min
  · rw [mul_one]
    apply (div_le_iff₀ hx).mpr
    exact hy.trans (mul_le_mul_of_nonneg_left hdiag (by positivity))
  · exact weighted_ratio_from_lower ha hs (weightedGamma_pos hk hm) (by positivity) hx hl hy

/-- The finite small-tail consequence with the original 256*10^9+1 constant. -/
theorem paper_weighted_small_tail {k m : ℕ} (hk : 1 ≤ k) (hm : 1 ≤ m)
    (eig : Fin (k+m) → ℝ) (heig : ∀ i, 0 < eig i) (horder : Antitone eig)
    (hsmall : (∑ i : Fin m, eig (i.natAdd k)) / eig ⟨k-1,by omega⟩ ≤
      Real.sqrt (min k m : ℕ) / ((k:ℝ)+1)) :
    spectralMean eig k / worstError eig k ≤ 256000000001 * Real.sqrt (min k m : ℕ) := by
  have hh := (paper_weighted_finite hk hm eig heig horder).2
  have hupper := mul_le_mul_of_nonneg_left (min_le_right (1:ℝ) ((weightedGamma k m)⁻¹+(∑ i : Fin m,eig (i.natAdd k))/eig ⟨k-1,by omega⟩)) (by positivity : (0:ℝ) ≤ (k:ℝ)+1)
  have hc := weighted_gamma_coefficient hk hm
  have hsmall' := (le_div_iff₀ (by positivity : (0:ℝ) < (k:ℝ)+1)).mp hsmall
  have hx := hh.trans hupper
  simp only [div_eq_mul_inv] at hc
  nlinarith

end SpectralComparison
