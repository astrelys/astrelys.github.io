import SpectralComparison.MainTheorem
import SpectralComparison.FrameExtremum
import Mathlib.NumberTheory.Harmonic.Bounds

noncomputable section
namespace SpectralComparison

theorem H_le_one_add_log (n : ℕ) : H n ≤ 1+Real.log n := by
  have he : H n = (harmonic n:ℝ) := by
    simp [H,harmonic,Rat.cast_sum,Rat.cast_inv,Rat.cast_add,Rat.cast_natCast]
  rw [he]
  exact harmonic_le_one_add_log n

/-- An explicit uniform version of the manuscript's O(sqrt(k)*(1+log(min(k,n-k)))) consequence. -/
theorem paper_logarithmic_comparison {n k : ℕ} (eig : Fin n → ℝ)
    (heig : ∀ i,0 < eig i) (hk : 1 ≤ k) (hkn : k < n) :
    spectralMean eig k/worstError eig k ≤
      (2*(768*10^27+1))*Real.sqrt k*(1+Real.log ((min k (n-k):ℕ):ℝ)) := by
  have hh := paper_main_theorem eig heig hk hkn
  have hx := hh.2.2.1
  have hk0 : (0:ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hr : 1 ≤ min k (n-k) := by omega
  have hr0 : (1:ℝ) ≤ (min k (n-k):ℕ) := by exact_mod_cast hr
  have hlog := Real.log_nonneg hr0
  have hs : 0 < Real.sqrt (k:ℝ) := Real.sqrt_pos.2 hk0
  have hs2 := Real.sq_sqrt hk0.le
  have hratio : spectralMean eig k/worstError eig k ≤
      ((k:ℝ)+1)*((768*10^27*H (min k (n-k))+1)/Real.sqrt k) := by
    apply (div_le_iff₀ hx).mpr
    exact hh.2.1.trans (mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_left (min_le_right _ _) (by positivity)) hx.le)
  have hH := H_le_one_add_log (min k (n-k))
  have hcoef : 768*10^27*H (min k (n-k))+1 ≤
      (768*10^27+1)*(1+Real.log ((min k (n-k):ℕ):ℝ)) := by nlinarith
  have hknR : (1:ℝ) ≤ k := by exact_mod_cast hk
  have hfactor : ((k:ℝ)+1)/Real.sqrt k ≤ 2*Real.sqrt k := by
    apply (div_le_iff₀ hs).mpr
    nlinarith
  calc
    _ ≤ ((k:ℝ)+1)*((768*10^27*H (min k (n-k))+1)/Real.sqrt k) := hratio
    _ = (((k:ℝ)+1)/Real.sqrt k)*(768*10^27*H (min k (n-k))+1) := by ring
    _ ≤ (2*Real.sqrt k)*((768*10^27+1)*(1+Real.log ((min k (n-k):ℕ):ℝ))) :=
      mul_le_mul hfactor hcoef (by positivity [H_nonneg (min k (n-k))]) (by positivity)
    _ = _ := by ring

/-- The appendix frame extremum cannot have a uniform little-o upper bound of order k^(3/2). -/
theorem paper_frame_not_littleO :
    ¬ Asymptotics.IsLittleO Filter.atTop (fun k : ℕ => frameExtremum (2*k) k)
      (fun k : ℕ => (k:ℝ)*Real.sqrt k) := by
  intro hh
  have hb := Asymptotics.isLittleO_iff.mp hh (show (0:ℝ) < 1/8000000000 by norm_num)
  have he : ∀ᶠ k : ℕ in Filter.atTop,4 ≤ k := Filter.eventually_ge_atTop 4
  obtain ⟨k,hk,hbound⟩ := (he.and hb).exists
  have hlow := (paper_balanced_frame_real hk).2
  have hk0 : (0:ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hf : 0 < (k:ℝ)*Real.sqrt k := mul_pos hk0 (Real.sqrt_pos.2 hk0)
  have hM : 0 ≤ frameExtremum (2*k) k := (by positivity : 0 ≤ (k:ℝ)*Real.sqrt k/4000000000).trans hlow
  simp only [Real.norm_eq_abs,abs_of_nonneg hM,abs_of_nonneg hf.le] at hbound
  linarith

end SpectralComparison
