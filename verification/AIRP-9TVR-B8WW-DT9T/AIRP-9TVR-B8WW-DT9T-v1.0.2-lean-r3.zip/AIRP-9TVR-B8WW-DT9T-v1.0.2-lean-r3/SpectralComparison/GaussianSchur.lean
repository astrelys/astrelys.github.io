import SpectralComparison.SchurResidual
import Mathlib.Data.Matrix.ColumnRowPartitioned

/-! The deterministic Schur-complement step in the Gaussian inverse-trace proof. -/
noncomputable section
namespace SpectralComparison
open Matrix

/-- Upper-left block of a block inverse, with positive definiteness hypotheses. -/
theorem inverse_upper_block_eq_schur {m n : Type*} [Fintype m] [Fintype n]
    [DecidableEq m] [DecidableEq n] (A : Matrix m m ℝ) (B : Matrix m n ℝ)
    (C : Matrix n m ℝ) (D : Matrix n n ℝ)
    (hD : D.PosDef) (hM : (Matrix.fromBlocks A B C D).PosDef) :
    (Matrix.fromBlocks A B C D)⁻¹.submatrix Sum.inl Sum.inl =
      (A - B * D⁻¹ * C)⁻¹ := by
  let _ : Invertible D := hD.isUnit.invertible
  let _ : Invertible (Matrix.fromBlocks A B C D) := hM.isUnit.invertible
  let _ : Invertible (A - B * ⅟D * C) := Matrix.invertibleOfFromBlocks₂₂Invertible A B C D
  have hf := Matrix.invOf_fromBlocks₂₂_eq A B C D
  have hi := congrArg (fun M : Matrix (m ⊕ n) (m ⊕ n) ℝ => M.submatrix Sum.inl Sum.inl) hf
  change (⅟(Matrix.fromBlocks A B C D)).submatrix Sum.inl Sum.inl = ⅟(A - B * ⅟D * C) at hi
  simpa only [Matrix.invOf_eq_nonsing_inv] using hi

/-- Exact projected-Gram expression for the leading inverse-Gram block.
The lower block may be empty. -/
theorem inverse_gram_upper_block {m n p : Type*} [Fintype m] [Fintype n] [Fintype p]
    [DecidableEq m] [DecidableEq n] [DecidableEq p]
    (U : Matrix m p ℝ) (B : Matrix n p ℝ)
    (hG : ((Matrix.fromRows U B) * (Matrix.fromRows U B)ᴴ).PosDef) :
    (((Matrix.fromRows U B) * (Matrix.fromRows U B)ᴴ)⁻¹).submatrix Sum.inl Sum.inl =
      (U * (1 - Bᴴ * (B * Bᴴ)⁻¹ * B) * Uᴴ)⁻¹ := by
  have he : Matrix.fromRows U B * (Matrix.fromRows U B)ᴴ =
      Matrix.fromBlocks (U*Uᴴ) (U*Bᴴ) (B*Uᴴ) (B*Bᴴ) := by
    rw [Matrix.conjTranspose_fromRows_eq_fromCols_conjTranspose, Matrix.fromRows_mul_fromCols]
  rw [he] at hG ⊢
  have hD : (B * Bᴴ).PosDef := by
    exact hG.submatrix Sum.inr_injective
  rw [inverse_upper_block_eq_schur _ _ _ _ hD hG]
  congr 1
  simp only [Matrix.mul_sub, Matrix.sub_mul, Matrix.mul_one, Matrix.mul_assoc]

/-- The residual projector annihilates the row block. -/
theorem kernel_projector_annihilates {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p] (B : Matrix n p ℝ) (hB : (B*Bᴴ).PosDef) :
    B * (1 - Bᴴ * (B*Bᴴ)⁻¹ * B) = 0 := by
  let _ : Invertible (B*Bᴴ) := hB.isUnit.invertible
  rw [Matrix.mul_sub, Matrix.mul_one]
  simp only [← Matrix.mul_assoc]
  rw [Matrix.mul_inv_of_invertible, Matrix.one_mul, sub_self]

end SpectralComparison
