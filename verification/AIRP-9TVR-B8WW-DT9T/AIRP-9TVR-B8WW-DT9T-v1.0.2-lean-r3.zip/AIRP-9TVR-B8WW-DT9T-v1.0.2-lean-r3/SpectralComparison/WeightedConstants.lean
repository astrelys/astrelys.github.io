import SpectralComparison.WeightedWorst

noncomputable section
namespace SpectralComparison

/-- The original gamma yields the paper's dimension-uniform coefficient. -/
theorem weighted_gamma_coefficient {k m : ℕ} (hk : 1 ≤ k) (hm : 1 ≤ m) :
    ((k:ℝ)+1) / weightedGamma k m ≤ 256000000000 * Real.sqrt (min k m : ℕ) := by
  have hk0 : (0:ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hm0 : (0:ℝ) < m := by exact_mod_cast (show 0 < m by omega)
  have hk1 : (1:ℝ) ≤ k := by exact_mod_cast hk
  have hsk : 0 < Real.sqrt (k:ℝ) := Real.sqrt_pos.mpr hk0
  have hsm : 0 < Real.sqrt (m:ℝ) := Real.sqrt_pos.mpr hm0
  apply (div_le_iff₀ (weightedGamma_pos hk hm)).mpr
  by_cases hmk : m ≤ k
  · rw [weightedGamma, ite_eq_left hmk, min_eq_right hmk]
    have he : 256000000000 * Real.sqrt (m:ℝ) * ((k:ℝ)/(32000000000*Real.sqrt m)) = 8*k := by field_simp <;> ring
    rw [he]
    linarith
  · rw [weightedGamma, ite_eq_right hmk, min_eq_left (by omega : k ≤ m)]
    have he : 256000000000 * Real.sqrt (k:ℝ) * (Real.sqrt k/128000000000) = 2*k := by
      nlinarith [Real.sq_sqrt hk0.le]
    rw [he]
    linarith

/-- Scalar transfer of a weighted ridge lower bound to a spectral ratio. -/
theorem weighted_ratio_from_lower {a s g c x y : ℝ} (ha : 0 < a) (hs : 0 < s)
    (hg : 0 < g) (hc : 0 ≤ c) (hx : 0 < x)
    (hl : a*(g*s)/(a+g*s) ≤ x) (hy : y ≤ c*s) :
    y/x ≤ c*(g⁻¹+s/a) := by
  have hz : 0 ≤ c*(g⁻¹+s/a) := by positivity
  have hh := mul_le_mul_of_nonneg_left hl hz
  have he : (c*(g⁻¹+s/a))*(a*(g*s)/(a+g*s)) = c*s := by field_simp <;> ring
  rw [he] at hh
  exact (div_le_iff₀ hx).mpr (by nlinarith)

end SpectralComparison
