import SpectralComparison.ReplicationTheorem
import SpectralComparison.Nystrom

/-! Exact finite-noise Nystrom residual for two-level projection covariances. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- A quadratic matrix identity reduces the literal Nystrom trace to one inverse principal trace. -/
theorem residualTrace_of_quadratic {n : Type*} [Fintype n] [DecidableEq n]
    (K : Matrix n n ℝ) (hK : K.PosDef) {a b : ℝ} (hpoly : K*K=a • K+b • 1)
    (I : Finset n) :
    residualTrace K I=K.trace-a*(I.card:ℝ)-b*(principal K I)⁻¹.trace := by
  let f : I → n := fun i => i
  let B := principal K I
  have hB := principal_posDef hK I
  have hp : (K*K).submatrix f f=a • B+b • (1 : Matrix I I ℝ) := by
    rw [hpoly]
    change a • K.submatrix f f+b • (1 : Matrix n n ℝ).submatrix f f=_
    rw [Matrix.submatrix_one f Subtype.val_injective]
    rfl
  have hmul : K.submatrix f id*K.submatrix id f=(K*K).submatrix f f :=
    (Matrix.submatrix_mul K K f id f Function.bijective_id).symm
  have ht : (K.submatrix id f*B⁻¹*K.submatrix f id).trace=(B⁻¹*(K*K).submatrix f f).trace := by
    rw [Matrix.trace_mul_cycle]
    rw [hmul,Matrix.trace_mul_comm]
  change (K-K.submatrix id f*B⁻¹*K.submatrix f id).trace=_
  rw [Matrix.trace_sub,ht,hp,Matrix.mul_add,Matrix.mul_smul,Matrix.mul_smul,
    Matrix.nonsing_inv_mul B (Matrix.isUnit_iff_isUnit_det _ |>.mp hB.isUnit),Matrix.mul_one,
    Matrix.trace_add,Matrix.trace_smul,Matrix.trace_smul,Matrix.trace_one,Fintype.card_coe]
  simp only [smul_eq_mul]
  ring

/-- The covariance epsilon I+(1-epsilon)QQ^T is positive at every 0<epsilon<=1. -/
theorem two_level_covariance_posDef {n d : Type*} [Fintype n] [Fintype d] [DecidableEq n]
    (Q : Matrix n d ℝ) {ε : ℝ} (hε : 0<ε) (hε1 : ε≤1) :
    (ε • (1 : Matrix n n ℝ)+(1-ε) • (Q*Qᴴ)).PosDef := by
  exact (Matrix.PosDef.one.smul hε).add_posSemidef
    ((posSemidef_self_mul_conjTranspose Q).smul (by linarith))

/-- Direct multiplication gives the exact quadratic identity for a two-level covariance. -/
theorem two_level_covariance_quadratic {n d : Type*} [Fintype n] [Fintype d]
    [DecidableEq n] [DecidableEq d] (Q : Matrix n d ℝ) (hQ : Qᴴ*Q=1) (ε : ℝ) :
    let K := ε • (1 : Matrix n n ℝ)+(1-ε) • (Q*Qᴴ)
    K*K=(1+ε) • K+(-ε) • 1 := by
  have hP : (Q*Qᴴ)*(Q*Qᴴ)=Q*Qᴴ := by
    rw [Matrix.mul_assoc Q,← Matrix.mul_assoc Qᴴ,hQ,Matrix.one_mul]
  dsimp only
  simp only [Matrix.add_mul,Matrix.mul_add,Matrix.smul_mul,Matrix.mul_smul,
    Matrix.one_mul,Matrix.mul_one,smul_smul,hP,smul_add]
  module

/-- Equation (A.4), for every actual selection, including singular unregularized row bases. -/
theorem paper_two_level_residual {n k : ℕ} (hk : k≤n)
    (Q : Matrix (Fin n) (Fin k) ℝ) (hQ : Qᴴ*Q=1)
    {ε : ℝ} (hε : 0<ε) (hε1 : ε≤1) (I : Finset (Fin n)) (hI : I.card=k) :
    let K := ε • (1 : Matrix (Fin n) (Fin n) ℝ)+(1-ε) • (Q*Qᴴ)
    residualTrace K I=ε*(((n-k:ℕ):ℝ)-(k:ℝ)+(principal K I)⁻¹.trace) := by
  let K := ε • (1 : Matrix (Fin n) (Fin n) ℝ)+(1-ε) • (Q*Qᴴ)
  have h := residualTrace_of_quadratic K (two_level_covariance_posDef Q hε hε1)
    (two_level_covariance_quadratic Q hQ ε) I
  have ht : K.trace=ε*(n:ℝ)+(1-ε)*(k:ℝ) := by
    dsimp [K]
    rw [Matrix.trace_add,Matrix.trace_smul,Matrix.trace_smul,Matrix.trace_mul_comm Q Qᴴ,hQ,Matrix.trace_one,Matrix.trace_one]
    simp
  change residualTrace K I=_
  rw [h,ht,hI,Nat.cast_sub hk]
  ring

/-- Uniform inverse-basis control regularizes every principal block, also when that basis is singular. -/
theorem two_level_principal_lower {n k : ℕ} (Q : Matrix (Fin n) (Fin k) ℝ)
    {L ε : ℝ} (hL : 0<L) (hε : 0<ε) (hε1 : ε≤1)
    (hb : ∀ I : Finset (Fin n), I.card=k →
      IsUnit ((Q*Qᴴ).submatrix (fun i : I => (i:Fin n)) (fun i : I => (i:Fin n))) →
      L≤((Q*Qᴴ).submatrix (fun i : I => (i:Fin n)) (fun i : I => (i:Fin n)))⁻¹.trace)
    (I : Finset (Fin n)) (hI : I.card=k) :
    L/(1+ε*L)≤(principal (ε • (1 : Matrix (Fin n) (Fin n) ℝ)+(1-ε) • (Q*Qᴴ)) I)⁻¹.trace := by
  let K := ε • (1 : Matrix (Fin n) (Fin n) ℝ)+(1-ε) • (Q*Qᴴ)
  let P := (Q*Qᴴ).submatrix (fun i : I => (i:Fin n)) (fun i : I => (i:Fin n))
  have hK := two_level_covariance_posDef Q hε hε1
  have hP : P.PosSemidef := (posSemidef_self_mul_conjTranspose Q).submatrix _
  have hgap : (ε • (1 : Matrix I I ℝ)+(1:ℝ) • P-principal K I).PosSemidef := by
    have he : ε • (1 : Matrix I I ℝ)+(1:ℝ) • P-principal K I=ε • P := by
      have hi := Matrix.submatrix_one (α:=ℝ) (fun i : I => (i:Fin n)) Subtype.val_injective
      ext i j
      have hij := congrFun (congrFun hi i) j
      simp only [Matrix.submatrix_apply] at hij
      simp only [principal,K,P,Matrix.submatrix_apply,Matrix.sub_apply,Matrix.add_apply,
        Matrix.smul_apply,smul_eq_mul,hij]
      ring
    rw [he]
    exact hP.smul hε.le
  have hr := matrix_regularization hP (principal_posDef hK I) hε (by norm_num : (0:ℝ)<1) hL (hb I hI) hgap
  exact hr

/-- Balanced finite-noise lower bound epsilon L/(1+epsilon L), with singular bases included. -/
theorem balanced_two_level_residual_lower {n k : ℕ} (hn : n=2*k) (Q : Matrix (Fin n) (Fin k) ℝ)
    (hQ : Qᴴ*Q=1) {L ε : ℝ} (hL : 0<L) (hε : 0<ε) (hε1 : ε≤1)
    (hb : ∀ I : Finset (Fin n), I.card=k →
      IsUnit ((Q*Qᴴ).submatrix (fun i : I => (i:Fin n)) (fun i : I => (i:Fin n))) →
      L≤((Q*Qᴴ).submatrix (fun i : I => (i:Fin n)) (fun i : I => (i:Fin n)))⁻¹.trace)
    (I : Finset (Fin n)) (hI : I.card=k) :
    ε*L/(1+ε*L)≤residualTrace (ε • (1 : Matrix (Fin n) (Fin n) ℝ)+(1-ε) • (Q*Qᴴ)) I := by
  let K := ε • (1 : Matrix (Fin n) (Fin n) ℝ)+(1-ε) • (Q*Qᴴ)
  let P := (Q*Qᴴ).submatrix (fun i : I => (i:Fin n)) (fun i : I => (i:Fin n))
  have hK := two_level_covariance_posDef Q hε hε1
  have hP : P.PosSemidef := (posSemidef_self_mul_conjTranspose Q).submatrix _
  have hgap : (ε • (1 : Matrix I I ℝ)+(1:ℝ) • P-principal K I).PosSemidef := by
    have he : ε • (1 : Matrix I I ℝ)+(1:ℝ) • P-principal K I=ε • P := by
      have hi := Matrix.submatrix_one (α:=ℝ) (fun i : I => (i:Fin n)) Subtype.val_injective
      ext i j
      have hij := congrFun (congrFun hi i) j
      simp only [Matrix.submatrix_apply] at hij
      simp only [principal,K,P,Matrix.submatrix_apply,Matrix.sub_apply,Matrix.add_apply,
        Matrix.smul_apply,smul_eq_mul,hij]
      ring
    rw [he]
    exact hP.smul hε.le
  have hr := matrix_regularization hP (principal_posDef hK I) hε (by norm_num : (0:ℝ)<1) hL (hb I hI) hgap
  have he := paper_two_level_residual (by omega : k≤n) Q hQ hε hε1 I hI
  have hd : n-k=k := by omega
  rw [hd] at he
  simp only [sub_self,zero_add] at he
  change _≤residualTrace K I
  rw [he]
  convert mul_le_mul_of_nonneg_left hr hε.le using 1
  ring

end SpectralComparison
