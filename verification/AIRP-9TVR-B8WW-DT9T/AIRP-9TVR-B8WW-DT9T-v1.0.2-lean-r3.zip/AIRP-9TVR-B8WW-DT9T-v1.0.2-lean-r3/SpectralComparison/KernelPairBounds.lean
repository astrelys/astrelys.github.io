import SpectralComparison.KernelRowPairs

/-! Uniform control over every eligible disjoint pair in the robust-frame construction. -/
noncomputable section
open Matrix MeasureTheory ProbabilityTheory
namespace SpectralComparison

/-- The dimension and threshold comparisons used to apply Lemma 3.1 after conditioning. -/
theorem robust_pair_threshold {k q h l : ℕ} (hk : 16≤k) (hq : 2*q≤k)
    (hh : 4*h≤k) (hl : h+l≤k) (hd : k-q-h≤l) :
    1≤k-q-h ∧ 4≤l ∧
      (k:ℝ)/(4000*((q:ℝ)+Real.sqrt k)) ≤
        (k-q-h:ℕ)/(1000*((l-(k-q-h):ℕ)+Real.sqrt l)) := by
  have hdim : 4*(k-q-h)≥k := by omega
  have hlk : l≤k := by omega
  have hgap : l-(k-q-h)≤q := by omega
  refine ⟨by omega,by omega,?_⟩
  have hdimr : (k:ℝ)≤4*(k-q-h:ℕ) := by exact_mod_cast hdim
  have hg : ((l-(k-q-h):ℕ):ℝ)≤q := by exact_mod_cast hgap
  have hr : Real.sqrt (l:ℝ)≤Real.sqrt k := Real.sqrt_le_sqrt (by exact_mod_cast hlk)
  have hA : 0<((l-(k-q-h):ℕ):ℝ)+Real.sqrt l := add_pos_of_nonneg_of_pos (Nat.cast_nonneg _)
    (Real.sqrt_pos.mpr (by exact_mod_cast (show 0<l by omega)))
  have hB : 0<(q:ℝ)+Real.sqrt k := add_pos_of_nonneg_of_pos (Nat.cast_nonneg _)
    (Real.sqrt_pos.mpr (by exact_mod_cast (show 0<k by omega)))
  apply (div_le_div_iff₀ (by positivity) (by positivity)).mpr
  have hm : (k:ℝ)*(((l-(k-q-h):ℕ):ℝ)+Real.sqrt l) ≤
      (4*(k-q-h:ℕ))*((q:ℝ)+Real.sqrt k) :=
    mul_le_mul hdimr (by linarith) hA.le (by positivity)
  nlinarith

/-- The common robust-frame threshold has a uniform tail over a single eligible pair. -/
theorem gaussian_robust_pair_tail {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {k q : ℕ} (hk : 16≤k) (hq : 2*q≤k)
    (X : Ω → Matrix (Fin (2*k)) (Fin (k-q)) ℝ)
    (hX : ∀ a : Fin (2*k) × Fin (k-q), HasLaw (fun ω => X ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin (2*k) × Fin (k-q) => fun ω => X ω a.1 a.2) μ)
    (H L : Finset (Fin (2*k))) (hdis : Disjoint H L) (hh : 4*H.card≤k)
    (hl : H.card+L.card≤k) (hd : k-q-H.card≤L.card) :
    μ.real {ω | kernelInverseTrace ((X ω).submatrix (fun i : H => (i:Fin (2*k))) id)
      ((X ω).submatrix (fun i : L => (i:Fin (2*k))) id) ≤
        (k:ℝ)/(4000*((q:ℝ)+Real.sqrt k))} ≤ 2*Real.exp (-31*(k:ℝ)/4) := by
  obtain ⟨hdpos,hl4,hthreshold⟩ := robust_pair_threshold hk hq hh hl hd
  have ht := gaussian_disjoint_row_pair_tail X hX hind H L hdis hdpos hl4 hd
  have hm : μ.real {ω | kernelInverseTrace ((X ω).submatrix (fun i : H => (i:Fin (2*k))) id)
      ((X ω).submatrix (fun i : L => (i:Fin (2*k))) id) ≤
        (k:ℝ)/(4000*((q:ℝ)+Real.sqrt k))} ≤
      μ.real {ω | kernelInverseTrace ((X ω).submatrix (fun i : H => (i:Fin (2*k))) id)
      ((X ω).submatrix (fun i : L => (i:Fin (2*k))) id) ≤
      (k-q-H.card:ℕ)/(1000*((L.card-(k-q-H.card):ℕ)+Real.sqrt L.card))} := by
    refine measureReal_mono ?_ (measure_ne_top _ _)
    intro ω hω
    exact hω.trans hthreshold
  apply (hm.trans ht).trans
  have hdim : k≤4*L.card := by omega
  have hdimr : (k:ℝ)≤4*(L.card:ℝ) := by exact_mod_cast hdim
  gcongr
  linarith

/-- A conservative count of all pairs suffices for the paper's exact final exponential bound. -/
theorem robust_pair_union_numeric (k : ℕ) :
    (16:ℝ)^k*(2*Real.exp (-31*(k:ℝ)/4)) ≤ 2*Real.exp (-4*(k:ℝ)) := by
  have he : (16:ℝ)≤Real.exp 3 := by
    have h : (27/10:ℝ)≤Real.exp 1 := by linarith [Real.exp_one_gt_d9]
    have hpow := pow_le_pow_left₀ (by norm_num : (0:ℝ)≤27/10) h 3
    have heq : Real.exp (3:ℝ)=(Real.exp 1)^3 := by simp [← Real.exp_nat_mul]
    rw [heq]
    norm_num at hpow
    linarith
  have hp : (16:ℝ)^k≤Real.exp (3*(k:ℝ)) := by
    calc
      _ ≤ (Real.exp 3)^k := pow_le_pow_left₀ (by norm_num) he _
      _ = _ := by rw [← Real.exp_nat_mul]; congr 1; ring
  calc
    _ ≤ Real.exp (3*(k:ℝ))*(2*Real.exp (-31*(k:ℝ)/4)) := by gcongr
    _ = 2*Real.exp (-19*(k:ℝ)/4) := by
      rw [show Real.exp (3*(k:ℝ))*(2*Real.exp (-31*(k:ℝ)/4))=
        2*(Real.exp (3*(k:ℝ))*Real.exp (-31*(k:ℝ)/4)) by ring,← Real.exp_add]
      congr 2
      ring
    _ ≤ _ := by gcongr; nlinarith [Nat.cast_nonneg (α := ℝ) k]

/-- Equation (5.3): a single measurable, basis-free failure event covers every eligible pair. -/
theorem gaussian_all_robust_pairs_tail {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {k q : ℕ} (hk : 16≤k) (hq : 2*q≤k)
    (X : Ω → Matrix (Fin (2*k)) (Fin (k-q)) ℝ)
    (hX : ∀ a : Fin (2*k) × Fin (k-q), HasLaw (fun ω => X ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin (2*k) × Fin (k-q) => fun ω => X ω a.1 a.2) μ) :
    μ.real {ω | ∃ H L : Finset (Fin (2*k)), Disjoint H L ∧ 4*H.card≤k ∧
      H.card+L.card≤k ∧ k-q-H.card≤L.card ∧
      kernelInverseTrace ((X ω).submatrix (fun i : H => (i:Fin (2*k))) id)
        ((X ω).submatrix (fun i : L => (i:Fin (2*k))) id) ≤
          (k:ℝ)/(4000*((q:ℝ)+Real.sqrt k))} ≤ 2*Real.exp (-4*(k:ℝ)) := by
  classical
  let E := fun z : Finset (Fin (2*k)) × Finset (Fin (2*k)) =>
    {ω | Disjoint z.1 z.2 ∧ 4*z.1.card≤k ∧ z.1.card+z.2.card≤k ∧ k-q-z.1.card≤z.2.card ∧
      kernelInverseTrace ((X ω).submatrix (fun i : z.1 => (i:Fin (2*k))) id)
        ((X ω).submatrix (fun i : z.2 => (i:Fin (2*k))) id) ≤ (k:ℝ)/(4000*((q:ℝ)+Real.sqrt k))}
  have hb (z) : μ.real (E z)≤2*Real.exp (-31*(k:ℝ)/4) := by
    by_cases hz : Disjoint z.1 z.2 ∧ 4*z.1.card≤k ∧ z.1.card+z.2.card≤k ∧ k-q-z.1.card≤z.2.card
    · rcases hz with ⟨hdis,hh,hl,hd⟩
      simpa only [E,hdis,hh,hl,hd,true_and] using gaussian_robust_pair_tail hk hq X hX hind z.1 z.2 hdis hh hl hd
    · have he : E z=∅ := by ext ω; simp only [E,Set.mem_ofPred_eq,Set.mem_empty_iff_false,iff_false]; tauto
      rw [he,measureReal_empty]
      positivity
  have hu := finite_union_probability_bound (μ := μ) Finset.univ E (fun z _ => hb z)
  have he : {ω | ∃ z ∈ (Finset.univ : Finset (Finset (Fin (2*k)) × Finset (Fin (2*k)))), ω ∈ E z} =
      {ω | ∃ H L : Finset (Fin (2*k)), Disjoint H L ∧ 4*H.card≤k ∧ H.card+L.card≤k ∧ k-q-H.card≤L.card ∧
      kernelInverseTrace ((X ω).submatrix (fun i : H => (i:Fin (2*k))) id)
        ((X ω).submatrix (fun i : L => (i:Fin (2*k))) id) ≤ (k:ℝ)/(4000*((q:ℝ)+Real.sqrt k))} := by
    ext ω
    simp [E]
  rw [he] at hu
  have hc : ((Finset.univ : Finset (Finset (Fin (2*k)) × Finset (Fin (2*k)))).card:ℝ)=(16:ℝ)^k := by
    simp only [Finset.card_univ,Fintype.card_prod,Fintype.card_finset,Fintype.card_fin,Nat.cast_mul,Nat.cast_pow,Nat.cast_ofNat]
    rw [pow_mul]
    norm_num
    rw [← mul_pow]
    norm_num
  rw [hc] at hu
  exact hu.trans (robust_pair_union_numeric k)

end SpectralComparison
