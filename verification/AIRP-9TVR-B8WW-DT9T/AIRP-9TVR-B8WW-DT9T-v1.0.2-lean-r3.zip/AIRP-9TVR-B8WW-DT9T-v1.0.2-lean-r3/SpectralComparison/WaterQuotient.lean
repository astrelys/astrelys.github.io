import SpectralComparison.WaterCoefficients

noncomputable section
open Finset
namespace SpectralComparison

/-- The water-level bound on a strictly active spectrum, with the precise strictness condition. -/
theorem active_water_quotient {ι : Type*} [Fintype ι] [DecidableEq ι]
    (a : ι → ℝ) (ha : ∀ i,0<a i) {k : ℕ} (hk : k<Fintype.card ι)
    {τ : ℝ} (hτ : 0<τ) (hact : ∀ i,τ<a i)
    (hsum : (∑ i,τ/a i)=(Fintype.card ι-k:ℕ)) :
    symmetricQuotient (Finset.univ.val.map a) k≤(Fintype.card ι-k:ℕ)*τ ∧
      (2≤Fintype.card ι-k → symmetricQuotient (Finset.univ.val.map a) k<(Fintype.card ι-k:ℕ)*τ) := by
  let β := fun i => τ/a i
  let d := Fintype.card ι-k
  have hd : 1≤d := by dsimp [d]; omega
  have hb : ∀ i,0<β i := fun i => div_pos hτ (ha i)
  have hb1 : ∀ i,β i<1 := fun i => (div_lt_one (ha i)).mpr (hact i)
  have hc := water_beta_coefficients β hb hb1 hd (by dsimp [d]; omega) hsum
  have hepos : 0<(Finset.univ.val.map β).esymm d := esymm_pos _ (by
    intro z hz; obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz; exact hb i) _ (by simp only [Multiset.card_map,Finset.card_val,Finset.card_univ]; dsimp [d]; omega)
  have hscale : symmetricQuotient (Finset.univ.val.map β) (d-1)=
      τ*symmetricQuotient (Finset.univ.val.map (fun i => (a i)⁻¹)) (d-1) := by
    have hh := symmetricQuotient_smul (Finset.univ.val.map (fun i => (a i)⁻¹)) (d-1) hτ
    simpa only [Multiset.map_map,Function.comp_def,β,div_eq_mul_inv] using hh
  have heq : symmetricQuotient (Finset.univ.val.map a) k=
      τ*((Finset.univ.val.map β).esymm (d-1)/(Finset.univ.val.map β).esymm d) := by
    rw [reciprocal_quotient a ha hk]
    have he : d-1+1=d := by omega
    have hi := congrArg Inv.inv hscale
    simp only [symmetricQuotient,he,inv_div,mul_inv_rev] at hi
    simp only [symmetricQuotient,inv_div]
    rw [show Fintype.card ι-k-1+1=d by dsimp [d]; omega]
    change (Finset.univ.val.map (fun i => (a i)⁻¹)).esymm (d-1)/(Finset.univ.val.map (fun i => (a i)⁻¹)).esymm d=τ*((Finset.univ.val.map β).esymm (d-1)/(Finset.univ.val.map β).esymm d)
    rw [hi]
    field_simp
  rw [heq]
  constructor
  · have hh := (div_le_iff₀ hepos).mpr hc.1
    nlinarith [mul_le_mul_of_nonneg_left hh hτ.le]
  · intro hd2
    have hh := (div_lt_iff₀ hepos).mpr (hc.2 hd2)
    nlinarith [mul_lt_mul_of_pos_left hh hτ]

/-- The original full-spectrum water quotient, with strictness whenever at least two coordinates remain. -/
theorem water_quotient_bound {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i)
    (hk : 1≤k) (hkn : k<n) {τ : ℝ} (hτ : 0<τ) (hroot : waterSum a τ=k) :
    let S := Finset.univ.filter (fun i => τ<a i)
    let T := ∑ i∈Finset.univ\S,a i
    symmetricQuotient (Finset.univ.val.map a) k≤(S.card-k:ℕ)*τ+T ∧
      (2≤n-k → symmetricQuotient (Finset.univ.val.map a) k<(S.card-k:ℕ)*τ+T) := by
  classical
  let S := Finset.univ.filter (fun i => τ<a i)
  let O := Finset.univ\S
  let head := S.val.map a
  let tail := O.val.map a
  have hS := waterLevel_active a ha hτ hroot hk
  change k<S.card ∧ (∑ i∈S,τ/a i)=(S.card:ℝ)-(k:ℝ) ∧ _ at hS
  have hh : ∀ z∈head,0<z := by intro z hz; obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz; exact ha i
  have ht : ∀ z∈tail,0<z := by intro z hz; obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz; exact ha i
  have hc : k<head.card := by simpa [head] using hS.1
  have hsum : (∑ i : S,τ/a i)=(Fintype.card S-k:ℕ) := by
    calc
      (∑ i : S,τ/a i)=∑ i∈S,τ/a i := Finset.sum_coe_sort S (fun i => τ/a i)
      _ =_ := by rw [Fintype.card_coe,Nat.cast_sub hS.1.le]; exact hS.2.1
  have hb := active_water_quotient (fun i : S => a i) (fun i => ha _)
    (by simpa using hS.1) hτ (fun i => (Finset.mem_filter.mp i.property).2) hsum
  have hm : Finset.univ.val.map (fun i : S => a i)=head := restricted_spectrum_multiset a S
  rw [hm] at hb
  simp only [Fintype.card_coe] at hb
  have he : head+tail=Finset.univ.val.map a := spectrum_partition_multiset a S
  have htSum : tail.sum=∑ i∈O,a i := rfl
  have hbound := symmetricQuotient_add_loss head tail hh ht hc.le
  change symmetricQuotient (Finset.univ.val.map a) k≤(S.card-k:ℕ)*τ+∑ i∈O,a i ∧ _
  constructor
  · rw [← he]
    linarith [hb.1]
  · intro hm2
    by_cases hd : 2≤S.card-k
    · rw [← he]
      linarith [hb.2 hd]
    · have hO : 0<O.card := by
        dsimp [O]
        rw [Finset.card_sdiff_of_subset (Finset.subset_univ _),Finset.card_univ,Fintype.card_fin]
        omega
      have hne : tail≠0 := by
        intro hz
        have hzcard := congrArg Multiset.card hz
        simp only [tail,Multiset.card_map,Finset.card_val,Multiset.card_zero] at hzcard
        omega
      have hs := quotient_add_strict_loss head tail hh ht hk hc.le hne
      rw [← he]
      linarith [hb.1]

end SpectralComparison
