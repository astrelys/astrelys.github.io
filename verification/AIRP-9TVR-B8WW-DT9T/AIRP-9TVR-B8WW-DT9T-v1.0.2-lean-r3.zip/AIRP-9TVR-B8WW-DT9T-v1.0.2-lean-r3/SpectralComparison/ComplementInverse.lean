import SpectralComparison.RobustFrame
import Mathlib.LinearAlgebra.Matrix.SchurComplement

/-! Algebraic inverse and trace identities for complementary row and column Grams. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Complementary rectangular Gram resolvents are nonsingular together. -/
theorem complement_gram_isUnit_iff {m n : Type*} [Fintype m] [Fintype n]
    [DecidableEq m] [DecidableEq n] (A : Matrix m n ℝ) :
    IsUnit (1-A*Aᴴ) ↔ IsUnit (1-Aᴴ*A) := by
  rw [Matrix.isUnit_iff_isUnit_det, Matrix.isUnit_iff_isUnit_det,
    Matrix.det_one_sub_mul_comm]

/-- The complementary resolvent inverse, proved by multiplication rather than SVD. -/
theorem complement_gram_inverse {m n : Type*} [Fintype m] [Fintype n]
    [DecidableEq m] [DecidableEq n] (A : Matrix m n ℝ) (h : IsUnit (1-Aᴴ*A)) :
    (1-A*Aᴴ)⁻¹=1+A*(1-Aᴴ*A)⁻¹*Aᴴ := by
  have hi := Matrix.nonsing_inv_mul (1-Aᴴ*A) ((Matrix.isUnit_iff_isUnit_det _).mp h)
  have hc : (1-Aᴴ*A)⁻¹ - (1-Aᴴ*A)⁻¹*(Aᴴ*A)=1 := by
    simpa only [Matrix.mul_sub,Matrix.mul_one] using hi
  apply Matrix.inv_eq_left_inv
  calc
    (1+A*(1-Aᴴ*A)⁻¹*Aᴴ)*(1-A*Aᴴ) =
      1-A*Aᴴ + A*((1-Aᴴ*A)⁻¹-(1-Aᴴ*A)⁻¹*(Aᴴ*A))*Aᴴ := by
        simp only [Matrix.add_mul,Matrix.mul_sub,Matrix.sub_mul,Matrix.one_mul,Matrix.mul_one,Matrix.mul_assoc]
        abel
    _ = 1 := by rw [hc,Matrix.mul_one]; abel

/-- Exact inverse-trace shift between complementary row and column Grams. -/
theorem complement_gram_inverse_trace {m n : Type*} [Fintype m] [Fintype n]
    [DecidableEq m] [DecidableEq n] (A : Matrix m n ℝ) (h : IsUnit (1-Aᴴ*A)) :
    (1-A*Aᴴ)⁻¹.trace=(Fintype.card m:ℝ)-(Fintype.card n:ℝ)+(1-Aᴴ*A)⁻¹.trace := by
  have hi := Matrix.nonsing_inv_mul (1-Aᴴ*A) ((Matrix.isUnit_iff_isUnit_det _).mp h)
  have hc : (1-Aᴴ*A)⁻¹*(Aᴴ*A)=(1-Aᴴ*A)⁻¹-1 := by
    rw [Matrix.mul_sub,Matrix.mul_one] at hi
    apply eq_sub_iff_add_eq.mpr
    rw [add_comm]
    exact (sub_eq_iff_eq_add.mp hi).symm
  rw [complement_gram_inverse A h,Matrix.trace_add,Matrix.trace_one,
    Matrix.trace_mul_cycle,Matrix.trace_mul_comm, hc,Matrix.trace_sub,Matrix.trace_one]
  ring

/-- An orthonormal frame has a complementary projection of the complementary rank. -/
theorem complementary_frame_projection {N r : ℕ} (Q : Matrix (Fin N) (Fin r) ℝ)
    (hQ : Qᴴ*Q=1) (hr : r≤N) :
    (1-Q*Qᴴ).PosSemidef ∧ (1-Q*Qᴴ)*(1-Q*Qᴴ)=1-Q*Qᴴ ∧ (1-Q*Qᴴ).rank=N-r := by
  have hH : (Qᴴ*(Qᴴ)ᴴ).PosDef := by rw [Matrix.conjTranspose_conjTranspose,hQ]; exact Matrix.PosDef.one
  obtain ⟨U,hU,hproj⟩ := exists_kernel_basis_matrix_of_dimension (d := Fin (N-r)) Qᴴ hH
    (by simp only [Fintype.card_fin]; omega)
  have he : U*Uᴴ=1-Q*Qᴴ := by
    simpa only [Matrix.conjTranspose_conjTranspose,hQ,inv_one,Matrix.mul_one] using hproj
  rw [← he]
  obtain ⟨_,hi,hRank⟩ := frame_projection_properties U hU
  exact ⟨posSemidef_self_mul_conjTranspose U,hi,by simpa using hRank⟩

end SpectralComparison
