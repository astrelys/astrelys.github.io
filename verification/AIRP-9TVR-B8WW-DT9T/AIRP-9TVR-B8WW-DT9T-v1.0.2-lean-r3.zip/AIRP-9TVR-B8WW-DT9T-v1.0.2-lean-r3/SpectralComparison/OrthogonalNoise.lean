import SpectralComparison.FrameCompletion

/-! Exact signal and noise subspaces of one orthogonal spectral realization. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Splitting an orthogonal basis at the zero noise eigenvalues gives exact signal/noise orthogonality and kernel. -/
theorem orthogonal_noise_kernel {n r p : Type*} [Fintype n] [Fintype r] [Fintype p]
    [DecidableEq n] [DecidableEq r] [DecidableEq p]
    (V : Matrix n (r ⊕ p) ℝ) (hV : Vᴴ*V=1) (hV' : V*Vᴴ=1)
    (d : p → ℝ) (hd : ∀ i,0<d i) :
    let Q := V.submatrix id Sum.inl
    let C := V*Matrix.diagonal (Sum.elim (fun _ : r => (0:ℝ)) d)*Vᴴ
    Qᴴ*Q=1 ∧ C.PosSemidef ∧ Qᴴ*C=0 ∧
      ∀ x,C.mulVec x=0 ↔ ∃ y : r → ℝ,x=Q.mulVec y := by
  classical
  let Q := V.submatrix id Sum.inl
  let b : r ⊕ p → ℝ := Sum.elim (fun _ => 0) d
  let C := V*Matrix.diagonal b*Vᴴ
  have hQ : Qᴴ*Q=1 := by
    rw [Matrix.conjTranspose_submatrix,← Matrix.submatrix_mul _ _ Sum.inl id Sum.inl Function.bijective_id,hV]
    exact Matrix.submatrix_one Sum.inl Sum.inl_injective
  have hC : C.PosSemidef := by
    have hh := (Matrix.PosSemidef.diagonal (show ∀ i,0≤b i by intro i; cases i with | inl i => exact le_rfl | inr i => exact (hd i).le)).conjTranspose_mul_mul_same Vᴴ
    simpa only [Matrix.conjTranspose_conjTranspose] using hh
  have hVQ : Vᴴ*Q=(1 : Matrix (r ⊕ p) (r ⊕ p) ℝ).submatrix id Sum.inl := by
    have hh := congrArg (fun M : Matrix (r ⊕ p) (r ⊕ p) ℝ => M.submatrix id Sum.inl) hV
    rw [Matrix.submatrix_mul _ _ id id Sum.inl Function.bijective_id,Matrix.submatrix_id_id] at hh
    exact hh
  have hCQ : C*Q=0 := by
    change (V*Matrix.diagonal b*Vᴴ)*Q=0
    rw [Matrix.mul_assoc (V*Matrix.diagonal b),hVQ,Matrix.mul_assoc]
    have hz : Matrix.diagonal b*(1 : Matrix (r ⊕ p) (r ⊕ p) ℝ).submatrix id Sum.inl=0 := by
      ext i j
      rw [Matrix.diagonal_mul]
      cases i <;> simp [b,Matrix.submatrix_apply,Matrix.one_apply]
    rw [hz,Matrix.mul_zero]
  have hQC : Qᴴ*C=0 := by
    simpa only [Matrix.conjTranspose_mul,hC.isHermitian.eq,Matrix.conjTranspose_zero] using congrArg Matrix.conjTranspose hCQ
  refine ⟨hQ,hC,hQC,?_⟩
  intro x
  let y := Vᴴ.mulVec x
  have hxy : V.mulVec y=x := by dsimp [y]; rw [Matrix.mulVec_mulVec,hV',Matrix.one_mulVec]
  constructor
  · intro hx
    have hb : (Matrix.diagonal b).mulVec y=0 := by
      have hh := congrArg Vᴴ.mulVec hx
      change Vᴴ.mulVec ((V*Matrix.diagonal b*Vᴴ).mulVec x)=Vᴴ.mulVec 0 at hh
      rw [Matrix.mulVec_zero,Matrix.mulVec_mulVec] at hh
      have he : Vᴴ*(V*Matrix.diagonal b*Vᴴ)=Matrix.diagonal b*Vᴴ := by
        rw [← Matrix.mul_assoc,← Matrix.mul_assoc,hV,Matrix.one_mul]
      rw [he,← Matrix.mulVec_mulVec] at hh
      exact hh
    have hy (j : p) : y (Sum.inr j)=0 := by
      have hh := congrFun hb (Sum.inr j)
      simp [Matrix.mulVec,dotProduct,Matrix.diagonal_apply,b] at hh
      exact hh.resolve_left (ne_of_gt (hd j))
    refine ⟨fun i => y (Sum.inl i),?_⟩
    rw [← hxy]
    ext i
    simp [Matrix.mulVec,dotProduct,Fintype.sum_sum_type,hy]
  · rintro ⟨z,rfl⟩
    rw [Matrix.mulVec_mulVec,hCQ,Matrix.zero_mulVec]

end SpectralComparison
