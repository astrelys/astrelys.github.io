import SpectralComparison.SingletonSpectrum
import SpectralComparison.NoiseSplit

/-! PSD and signal geometry survive adding the positive singleton coordinates. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- The direct sum of two PSD covariance blocks is PSD. -/
theorem block_pair_posSemidef {n s : Type*} [Fintype n] [Fintype s]
    [DecidableEq n] [DecidableEq s] {A : Matrix n n ℝ} {B : Matrix s s ℝ}
    (hA : A.PosSemidef) (hB : B.PosSemidef) :
    (Matrix.fromBlocks A 0 0 B).PosSemidef := by
  let E : Matrix (n ⊕ s) n ℝ := Matrix.fromRows 1 0
  let F : Matrix (n ⊕ s) s ℝ := Matrix.fromRows 0 1
  have hh := (hA.mul_mul_conjTranspose_same E).add (hB.mul_mul_conjTranspose_same F)
  convert hh using 1
  dsimp [E,F]
  rw [Matrix.conjTranspose_fromRows_eq_fromCols_conjTranspose,
    Matrix.conjTranspose_fromRows_eq_fromCols_conjTranspose]
  simp only [Matrix.conjTranspose_one,Matrix.conjTranspose_zero]
  rw [Matrix.fromRows_mul (1 : Matrix n n ℝ) 0 A,Matrix.fromRows_mul 0 (1 : Matrix s s ℝ) B]
  rw [Matrix.fromRows_mul_fromCols,Matrix.fromRows_mul_fromCols]
  simp only [Matrix.one_mul,Matrix.zero_mul,Matrix.mul_one,Matrix.mul_zero,
    Matrix.fromBlocks_add,add_zero,zero_add]

/-- Appending zero signal rows and positive singleton noise preserves all projection hypotheses. -/
theorem singleton_signal_geometry {n r s : Type*} [Fintype n] [Fintype r] [Fintype s]
    [DecidableEq n] [DecidableEq r] [DecidableEq s]
    (Q : Matrix n r ℝ) (hQ : Qᴴ*Q=1) (C D : Matrix n n ℝ)
    (hQC : Qᴴ*C=0) (hC : C.PosSemidef) (hD : D.PosSemidef) (hCD : (C-D).PosSemidef)
    (b : s → ℝ) (hb : ∀ i,0≤b i) :
    let Q' : Matrix (n ⊕ s) r ℝ := Matrix.fromRows Q 0
    let C' := Matrix.fromBlocks C 0 0 (Matrix.diagonal b)
    let D' := Matrix.fromBlocks D 0 0 (Matrix.diagonal b)
    Q'ᴴ*Q'=1 ∧ Q'ᴴ*C'=0 ∧ C'.PosSemidef ∧ D'.PosSemidef ∧ (C'-D').PosSemidef := by
  dsimp only
  refine ⟨?_,?_,block_pair_posSemidef hC (Matrix.PosSemidef.diagonal hb),
    block_pair_posSemidef hD (Matrix.PosSemidef.diagonal hb),?_⟩
  · rw [Matrix.conjTranspose_fromRows_eq_fromCols_conjTranspose,Matrix.fromCols_mul_fromRows]
    simp only [Matrix.conjTranspose_zero,Matrix.zero_mul,add_zero,hQ]
  · rw [Matrix.conjTranspose_fromRows_eq_fromCols_conjTranspose,Matrix.fromCols_mul_fromBlocks]
    simp only [Matrix.conjTranspose_zero,Matrix.zero_mul,Matrix.mul_zero,add_zero,hQC,Matrix.fromCols_zero]
  · have he : Matrix.fromBlocks C 0 0 (Matrix.diagonal b)-Matrix.fromBlocks D 0 0 (Matrix.diagonal b)=
        Matrix.fromBlocks (C-D) 0 0 (0 : Matrix s s ℝ) := by
      ext i j; cases i <;> cases j <;> simp
    rw [he]
    exact block_pair_posSemidef hCD Matrix.PosSemidef.zero

/-- Literal signal-plus-noise synthesis on appended singleton coordinates. -/
theorem singleton_signal_synthesis {n r s : Type*} [Fintype n] [Fintype r] [Fintype s]
    (Q : Matrix n r ℝ) (A : Matrix r r ℝ) (C : Matrix n n ℝ) (B : Matrix s s ℝ) :
    Matrix.fromBlocks (Q*A*Qᴴ+C) 0 0 B=
      (Matrix.fromRows Q (0 : Matrix s r ℝ))*A*(Matrix.fromRows Q (0 : Matrix s r ℝ))ᴴ+
        Matrix.fromBlocks C 0 0 B := by
  rw [Matrix.conjTranspose_fromRows_eq_fromCols_conjTranspose,Matrix.fromRows_mul,
    Matrix.fromRows_mul_fromCols]
  simp only [Matrix.conjTranspose_zero,Matrix.mul_zero,Matrix.zero_mul,
    Matrix.fromBlocks_add,zero_add]

end SpectralComparison
