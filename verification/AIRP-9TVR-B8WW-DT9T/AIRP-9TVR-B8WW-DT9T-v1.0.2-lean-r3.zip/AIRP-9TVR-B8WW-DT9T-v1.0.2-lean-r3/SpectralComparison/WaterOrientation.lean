import SpectralComparison.WaterQuotient

noncomputable section
open Matrix Finset
namespace SpectralComparison

/-- The active water-level block realizes q*tau+T as an actual orbit lower bound. -/
theorem water_orientation_lower {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i)
    (hk : 1≤k) (hkn : k<n) {τ : ℝ} (hτ : 0<τ) (hroot : waterSum a τ=k) :
    let S := Finset.univ.filter (fun i => τ<a i)
    (S.card:ℝ)*τ+(∑ i∈Finset.univ\S,a i)≤worstError a k := by
  classical
  let S := Finset.univ.filter (fun i => τ<a i)
  let O := Finset.univ\S
  have hs := waterLevel_active a ha hτ hroot hk
  change k<S.card ∧ (∑ i∈S,τ/a i)=(S.card:ℝ)-(k:ℝ) ∧ _ at hs
  have hc : S.card≤n := by simpa using S.card_le_univ
  let eI : Fin S.card ≃ S := Fintype.equivOfCardEq (by simp)
  let eJ : Fin (n-S.card) ≃ O := Fintype.equivOfCardEq (by simp [O])
  let e : Fin S.card ⊕ Fin (n-S.card) ≃ Fin n := (Equiv.sumCongr eI eJ).trans (partitionEquiv S)
  have hhead (i : Fin S.card) : e (Sum.inl i)=(eI i : Fin n) := rfl
  have htail (j : Fin (n-S.card)) : e (Sum.inr j)=(eJ j : Fin n) := rfl
  have hsep : ∀ i : Fin S.card,∀ j : Fin (n-S.card),a (e (Sum.inr j))≤a (e (Sum.inl i)) := by
    intro i j
    exact (hs.2.2 (eJ j) (eJ j).property).trans ((Finset.mem_filter.mp (eI i).property).2.le)
  have hb := harmonic_block_lower e a ha (by omega) hs.1.le hkn hsep
  have hsum : (∑ i : Fin S.card,(a (e (Sum.inl i)))⁻¹)=∑ i∈S,(a i)⁻¹ := by
    simp only [hhead]
    exact (eI.sum_comp (fun i : S => (a i)⁻¹)).trans (Finset.sum_coe_sort S (fun i => (a i)⁻¹))
  have htSum : (∑ j : Fin (n-S.card),a (e (Sum.inr j)))=∑ j∈O,a j := by
    simp only [htail]
    exact (eJ.sum_comp (fun i : O => a i)).trans (Finset.sum_coe_sort O a)
  have hp : 0<∑ i∈S,(a i)⁻¹ := Finset.sum_pos (fun i _ => inv_pos.mpr (ha i)) (Finset.card_pos.mp (by omega))
  have hnorm : τ*(∑ i∈S,(a i)⁻¹)=(S.card-k:ℕ) := by
    rw [Finset.mul_sum,Nat.cast_sub hs.1.le]
    simpa only [div_eq_mul_inv] using hs.2.1
  have hH : (S.card-k:ℕ)*harmonicMean (fun i => a (e (Sum.inl i)))=(S.card:ℝ)*τ := by
    dsimp [harmonicMean]
    rw [hsum]
    rw [← mul_div_assoc]
    apply (div_eq_iff hp.ne').mpr
    nlinarith
  rw [htSum,hH] at hb
  change (S.card:ℝ)*τ+(∑ i∈O,a i)≤worstError a k
  linarith

/-- The scalar water tail has its original dimension-dependent upper bound. -/
theorem water_tail_bound {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i)
    (hk : 1≤k) {τ : ℝ} (hτ : 0<τ) (hroot : waterSum a τ=k) :
    let S := Finset.univ.filter (fun i => τ<a i)
    0≤(∑ i∈Finset.univ\S,a i) ∧ (∑ i∈Finset.univ\S,a i)≤(n-S.card:ℕ)*τ := by
  let S := Finset.univ.filter (fun i => τ<a i)
  have hs := waterLevel_active a ha hτ hroot hk
  refine ⟨Finset.sum_nonneg (fun i _ => (ha i).le),?_⟩
  calc
    _ ≤∑ _i∈Finset.univ\S,τ := Finset.sum_le_sum (fun i hi => hs.2.2 i hi)
    _ =_ := by simp [S,Finset.card_sdiff,Finset.inter_univ]

/-- All numerical inequalities in D.1, including pointwise strictness, on the original objectives. -/
theorem paper_water_comparison {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i)
    (hk : 1≤k) (hkn : k<n) {τ : ℝ} (hτ : 0<τ) (hroot : waterSum a τ=k) :
    let S := Finset.univ.filter (fun i => τ<a i)
    let T := ∑ i∈Finset.univ\S,a i
    let B := (S.card:ℝ)*τ+T
    let C := ((k:ℝ)+1)*(((S.card-k:ℕ):ℝ)*τ+T)/B
    spectralMean a k≤C*worstError a k ∧
      C*worstError a k≤(((k:ℝ)+1)*(n-k:ℕ)/(n:ℝ))*worstError a k ∧
      (2≤n-k → spectralMean a k<(((k:ℝ)+1)*(n-k:ℕ)/(n:ℝ))*worstError a k) := by
  let S := Finset.univ.filter (fun i => τ<a i)
  let T := ∑ i∈Finset.univ\S,a i
  let B := (S.card:ℝ)*τ+T
  let C := ((k:ℝ)+1)*(((S.card-k:ℕ):ℝ)*τ+T)/B
  have hs := waterLevel_active a ha hτ hroot hk
  have ht := water_tail_bound a ha hk hτ hroot
  have hf := water_quotient_bound a ha hk hkn hτ hroot
  have hx := water_orientation_lower a ha hk hkn hτ hroot
  change B≤worstError a k at hx
  change 0≤T ∧ T≤(n-S.card:ℕ)*τ at ht
  change symmetricQuotient (Finset.univ.val.map a) k≤(S.card-k:ℕ)*τ+T ∧ _ at hf
  have hcard : k<S.card := hs.1
  have hqn : S.card≤n := by simpa using S.card_le_univ
  have hn : (0:ℝ)<n := by exact_mod_cast (by omega : 0<n)
  have hB : 0<B := add_pos_of_pos_of_nonneg (mul_pos (by exact_mod_cast (by omega : 0<S.card)) hτ) ht.1
  have hC : 0≤C := div_nonneg (mul_nonneg (by positivity) (add_nonneg (by positivity) ht.1)) hB.le
  have hfact : C≤((k:ℝ)+1)*(n-k:ℕ)/(n:ℝ) := by
    dsimp [C,B]
    apply (div_le_div_iff₀ hB hn).mpr
    rw [Nat.cast_sub hcard.le,Nat.cast_sub hkn.le]
    have htt : T≤((n:ℝ)-(S.card:ℝ))*τ := by simpa only [Nat.cast_sub hqn] using ht.2
    have hk0 : (0:ℝ)≤k := Nat.cast_nonneg _
    nlinarith [mul_nonneg hk0 (sub_nonneg.mpr htt)]
  have hy : spectralMean a k≤C*worstError a k := by
    rw [spectralMean_eq_quotient]
    calc
      _ ≤((k:ℝ)+1)*((S.card-k:ℕ)*τ+T) := mul_le_mul_of_nonneg_left hf.1 (by positivity)
      _ =C*B := by dsimp [C]; field_simp
      _ ≤_ := mul_le_mul_of_nonneg_left hx hC
  have hxpos := worstError_pos a ha (k:=k) (by simpa using hkn)
  have hlast : C*worstError a k≤(((k:ℝ)+1)*(n-k:ℕ)/(n:ℝ))*worstError a k := mul_le_mul_of_nonneg_right hfact hxpos.le
  refine ⟨hy,hlast,?_⟩
  intro hm
  have hystrict : spectralMean a k<C*worstError a k := by
    rw [spectralMean_eq_quotient]
    calc
      _ <((k:ℝ)+1)*((S.card-k:ℕ)*τ+T) := mul_lt_mul_of_pos_left (hf.2 hm) (by positivity)
      _ =C*B := by dsimp [C]; field_simp
      _ ≤_ := mul_le_mul_of_nonneg_left hx hC
  exact hystrict.trans_le hlast

end SpectralComparison
