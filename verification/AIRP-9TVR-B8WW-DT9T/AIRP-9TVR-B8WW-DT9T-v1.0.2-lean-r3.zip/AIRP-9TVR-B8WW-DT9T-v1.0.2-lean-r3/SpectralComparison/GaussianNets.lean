import SpectralComparison.FiniteNets
import SpectralComparison.GaussianVectors
import Mathlib.Analysis.Complex.ExponentialBounds

/-! Finite-net Gaussian operator-norm and small-ball probability estimates. -/
noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

/-- Finite union bound in real-valued probability. -/
theorem finite_union_probability_bound {Ω ι : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] (s : Finset ι) (E : ι → Set Ω)
    {c : ℝ} (hc : ∀ i ∈ s, μ.real (E i) ≤ c) :
    μ.real {ω | ∃ i ∈ s, ω ∈ E i} ≤ (s.card:ℝ)*c := by
  have he : {ω | ∃ i ∈ s, ω ∈ E i} = ⋃ i ∈ s, E i := by ext; simp
  rw [he]
  exact (measureReal_biUnion_finset_le s E).trans
    (by simpa using Finset.sum_le_sum hc)

/-- A sphere-net union bound for the operator norm of an actual Gaussian matrix. -/
theorem gaussian_opNorm_net_bound {Ω n p : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p] (G : Ω → Matrix n p ℝ)
    (hG : ∀ a : n × p, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : n × p => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : n × p, Measurable (fun ω => G ω a.1 a.2))
    (s : Finset (EuclideanSpace ℝ p)) {η M z : ℝ}
    (hη0 : 0 ≤ η) (hη1 : η < 1) (hM : 0 ≤ M) (hz0 : 0 ≤ z) (hz : z < 1/2)
    (hs : ∀ v ∈ s, ‖v‖=1)
    (hnet : ∀ x : EuclideanSpace ℝ p, ‖x‖=1 → ∃ v ∈ s, ‖x-v‖ ≤ η) :
    μ.real {ω | M/(1-η) < ‖(G ω).toEuclideanLin.toContinuousLinearMap‖} ≤
      (s.card:ℝ)*(Real.exp (-z*M^2)*(1-2*z)^(-(Fintype.card n:ℝ)/2)) := by
  have hsub : {ω | M/(1-η) < ‖(G ω).toEuclideanLin.toContinuousLinearMap‖} ⊆
      {ω | ∃ v ∈ s, M^2 ≤ ‖(G ω).toEuclideanLin v‖^2} := by
    intro ω hω
    change ∃ v ∈ s, M^2 ≤ ‖(G ω).toEuclideanLin v‖^2
    by_contra! hnone
    have hb (v) (hv : v ∈ s) : ‖(G ω).toEuclideanLin.toContinuousLinearMap v‖ ≤ M := by
      have := hnone v hv
      change ‖(G ω).toEuclideanLin v‖ ≤ M
      nlinarith [norm_nonneg ((G ω).toEuclideanLin v)]
    exact hω.not_ge (opNorm_le_of_sphere_net _ s hη0 hη1 hM hnet hb)
  exact (measureReal_mono hsub).trans (finite_union_probability_bound s
    (fun v => {ω | M^2 ≤ ‖(G ω).toEuclideanLin v‖^2})
    (fun v hv => gaussian_vector_norm_upper G hG hind hm v (hs v hv) _ _ hz0 hz))

/-- Equation (4.2)'s explicit half-net bound, before the final numerical simplification. -/
theorem gaussian_opNorm_tail_explicit {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {N p : ℕ}
    (G : Ω → Matrix (Fin N) (Fin p) ℝ)
    (hG : ∀ a : Fin N × Fin p, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin N × Fin p => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : Fin N × Fin p, Measurable (fun ω => G ω a.1 a.2)) :
    μ.real {ω | 10*Real.sqrt p < ‖(G ω).toEuclideanLin.toContinuousLinearMap‖} ≤
      (5:ℝ)^p * (2:ℝ)^((N:ℝ)/2) * Real.exp (-25*(p:ℝ)/4) := by
  obtain ⟨s,hs,hcard,hnet⟩ := exists_sphere_net_card_le (E := EuclideanSpace ℝ (Fin p))
    (η := (1/2:ℝ)) (by norm_num)
  have h := gaussian_opNorm_net_bound G hG hind hm s (M := 5*Real.sqrt p) (z := (1/4:ℝ))
    (by norm_num) (by norm_num) (by positivity) (by norm_num) (by norm_num) hs hnet
  have hM : 5*Real.sqrt (p:ℝ)/(1-(1/2:ℝ)) = 10*Real.sqrt p := by ring
  have ha : -(1/4:ℝ)*(5*Real.sqrt (p:ℝ))^2 = -25*(p:ℝ)/4 := by
    nlinarith [Real.sq_sqrt (Nat.cast_nonneg p)]
  have hr : (1-2*(1/4:ℝ))^(-(Fintype.card (Fin N):ℝ)/2) = (2:ℝ)^((N:ℝ)/2) := by
    norm_num only [Fintype.card_fin, show 1-2*(1/4:ℝ)=1/2 by norm_num]
    rw [show -(N:ℝ)/2 = -((N:ℝ)/2) by ring, Real.rpow_neg_eq_inv_rpow]
    norm_num
  rw [hM,ha,hr] at h
  have hc : (s.card:ℝ) ≤ (5:ℝ)^p := by norm_num at hcard; exact hcard
  calc
    _ ≤ (s.card:ℝ)*(Real.exp (-25*(p:ℝ)/4)*(2:ℝ)^((N:ℝ)/2)) := h
    _ ≤ (5:ℝ)^p*(Real.exp (-25*(p:ℝ)/4)*(2:ℝ)^((N:ℝ)/2)) := by gcongr
    _ = _ := by ring

/-- The exponential form of (4.2), with the paper's operator threshold. -/
theorem gaussian_opNorm_tail {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {N p : ℕ} (hN : N ≤ 2*p)
    (G : Ω → Matrix (Fin N) (Fin p) ℝ)
    (hG : ∀ a : Fin N × Fin p, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin N × Fin p => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : Fin N × Fin p, Measurable (fun ω => G ω a.1 a.2)) :
    μ.real {ω | 10*Real.sqrt p < ‖(G ω).toEuclideanLin.toContinuousLinearMap‖} ≤
      Real.exp (-3*(p:ℝ)) := by
  have h5 : (5:ℝ) ≤ Real.exp 2 := by
    have h := Real.sum_le_exp_of_nonneg (by norm_num : (0:ℝ) ≤ 2) 3
    norm_num [Finset.sum_range_succ] at h
    exact h
  have h2 : (2:ℝ) ≤ Real.exp 1 := Real.exp_one_gt_two.le
  have he5 : (5:ℝ)^p ≤ Real.exp (2*(p:ℝ)) := by
    calc
      _ ≤ (Real.exp 2)^p := by gcongr
      _ = _ := by rw [← Real.exp_nat_mul]; congr 1; ring
  have he2 : (2:ℝ)^((N:ℝ)/2) ≤ Real.exp ((N:ℝ)/2) := by
    calc
      _ ≤ (Real.exp 1)^((N:ℝ)/2) := Real.rpow_le_rpow (by norm_num) h2 (by positivity)
      _ = _ := by rw [← Real.exp_mul]; congr 1; ring
  apply (gaussian_opNorm_tail_explicit G hG hind hm).trans
  calc
    _ ≤ Real.exp (2*(p:ℝ))*Real.exp ((N:ℝ)/2)*Real.exp (-25*(p:ℝ)/4) := by gcongr
    _ = Real.exp (2*(p:ℝ)+(N:ℝ)/2-25*(p:ℝ)/4) := by rw [← Real.exp_add, ← Real.exp_add]; congr 1; ring
    _ ≤ _ := Real.exp_le_exp.mpr (by
      have hn : (N:ℝ) ≤ 2*(p:ℝ) := by exact_mod_cast hN
      nlinarith)

end SpectralComparison
