import SpectralComparison.DiffuseKernel

/-! Orthogonal assembly of all diffuse groups, with exact spectrum and row support. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Group coordinates consist of one kernel coordinate per group and every original weight once. -/
def groupCoordinateEquiv {g p : Type*} (f : p → g) :
    (g ⊕ p) ≃ (Σ j : g, Fin 1 ⊕ {i : p // f i=j}) where
  toFun := Sum.elim (fun j => ⟨j,Sum.inl 0⟩) (fun i => ⟨f i,Sum.inr ⟨i,rfl⟩⟩)
  invFun := fun x => x.2.elim (fun _ => Sum.inl x.1) (fun i => Sum.inr i.val)
  left_inv := by intro x; cases x <;> rfl
  right_inv := by
    rintro ⟨j,a⟩
    cases a with
    | inl a => have ha : a=0 := Subsingleton.elim _ _; subst a; rfl
    | inr a => rcases a with ⟨i,hi⟩; subst j; rfl

/-- Assemble the actual prescribed-spectrum group covariance before any selected set is given. -/
theorem exists_assembled_group_basis {g p : Type*} [Fintype g] [Fintype p]
    [DecidableEq g] [DecidableEq p] (f : p → g) (d : p → ℝ) (hd : ∀ i,0<d i) :
    ∃ W : Matrix (Σ j : g, Fin 1 ⊕ {i : p // f i=j}) (g ⊕ p) ℝ,
      Wᴴ*W=1 ∧ W*Wᴴ=1 ∧
      (∀ x,W x (Sum.inl x.1)≠0) ∧
      (∀ x j,j≠x.1 → W x (Sum.inl j)=0) ∧
      let D := W*Matrix.diagonal (Sum.elim (fun _ : g => (0:ℝ)) d)*Wᴴ
      D.PosSemidef ∧
      (∀ x,D x x=(∑ i : {i : p // f i=x.1},d i.val)*(W x (Sum.inl x.1))^2) ∧
      (∀ x y,x.1≠y.1 → D x y=0) := by
  classical
  choose V hV hV' hD hu hker hdiag hnonzero using
    fun j : g => exists_diffuse_group_block (fun i : {i : p // f i=j} => d i.val) (fun i => hd i.val)
  let B := Matrix.blockDiagonal' V
  have hB : Bᴴ*B=1 := by
    dsimp [B]
    rw [Matrix.blockDiagonal'_conjTranspose,← Matrix.blockDiagonal'_mul]
    simp only [hV]
    change Matrix.blockDiagonal' (1 : ∀ j : g, Matrix (Fin 1 ⊕ {i : p // f i=j}) (Fin 1 ⊕ {i : p // f i=j}) ℝ)=1
    exact Matrix.blockDiagonal'_one
  have hB' : B*Bᴴ=1 := mul_eq_one_comm.mp hB
  let e := groupCoordinateEquiv f
  let W := B.submatrix id e
  have hW : Wᴴ*W=1 := by
    rw [Matrix.conjTranspose_submatrix,← Matrix.submatrix_mul _ _ e id e Function.bijective_id,hB]
    exact Matrix.submatrix_one e e.injective
  have hW' : W*Wᴴ=1 := by
    rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,hB',Matrix.submatrix_id_id]
  have hentry (j : g) (a : Fin 1 ⊕ {i : p // f i=j}) : W ⟨j,a⟩ (Sum.inl j)=V j a (Sum.inl 0) := by
    simp [W,B,e,groupCoordinateEquiv,Matrix.blockDiagonal'_apply]
  have hsupport (x) (j : g) (hj : j≠x.1) : W x (Sum.inl j)=0 := by
    rcases x with ⟨i,a⟩
    simp [W,B,e,groupCoordinateEquiv,Matrix.blockDiagonal'_apply,Ne.symm hj]
  let b : (Σ j : g, Fin 1 ⊕ {i : p // f i=j}) → ℝ := fun x => x.2.elim (fun _ => 0) (fun i => d i.val)
  have hspec : Matrix.diagonal (Sum.elim (fun _ : g => (0:ℝ)) d)=(Matrix.diagonal b).submatrix e e := by
    rw [Matrix.submatrix_diagonal_equiv]
    congr 1
    funext a
    cases a <;> rfl
  have hcov : W*Matrix.diagonal (Sum.elim (fun _ : g => (0:ℝ)) d)*Wᴴ=
      Matrix.blockDiagonal' (fun j => V j*Matrix.diagonal (Sum.elim (fun _ : Fin 1 => (0:ℝ)) (fun i : {i : p // f i=j} => d i.val))*(V j)ᴴ) := by
    rw [hspec]
    change B.submatrix id e*(Matrix.diagonal b).submatrix e e*(B.submatrix id e)ᴴ=_
    rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,Matrix.submatrix_mul_equiv,Matrix.submatrix_id_id]
    change Matrix.blockDiagonal' V*Matrix.diagonal b*(Matrix.blockDiagonal' V)ᴴ=_
    rw [show Matrix.diagonal b=Matrix.blockDiagonal' (fun j => Matrix.diagonal (Sum.elim (fun _ : Fin 1 => (0:ℝ)) (fun i : {i : p // f i=j} => d i.val))) by exact (Matrix.blockDiagonal'_diagonal (fun j : g => Sum.elim (fun _ : Fin 1 => (0:ℝ)) (fun i : {i : p // f i=j} => d i.val))).symm]
    rw [Matrix.blockDiagonal'_conjTranspose,← Matrix.blockDiagonal'_mul,← Matrix.blockDiagonal'_mul]
  refine ⟨W,hW,hW',?_,hsupport,?_,?_,?_⟩
  · rintro ⟨j,a⟩
    rw [hentry]
    exact hnonzero j a
  · have hh := (Matrix.PosSemidef.diagonal (show ∀ a,0≤Sum.elim (fun _ : g => (0:ℝ)) d a by intro a; cases a with | inl j => exact le_rfl | inr i => exact (hd i).le)).conjTranspose_mul_mul_same Wᴴ
    simpa only [Matrix.conjTranspose_conjTranspose] using hh
  · rintro ⟨j,a⟩
    rw [hcov,hentry]
    simpa only [Matrix.blockDiagonal'_apply_eq] using hdiag j a
  · rintro ⟨i,a⟩ ⟨j,b⟩ hij
    rw [hcov]
    simp [Matrix.blockDiagonal'_apply,hij]

end SpectralComparison
