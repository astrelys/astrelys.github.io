import SpectralComparison.WeightedNoiseFrame
import SpectralComparison.FullGroupModel

noncomputable section
open Matrix
namespace SpectralComparison

/-- The grouped covariance gives a genuine complementary weighted frame, with all labels retained. -/
theorem exists_weighted_group_frame {g p r h s : Type*}
    [Fintype g] [Fintype p] [Fintype r] [Fintype h] [Fintype s]
    [DecidableEq g] [DecidableEq p] [DecidableEq r] [DecidableEq h] [DecidableEq s]
    (f : p → g) (d : p → ℝ) (hd : ∀ i, 0 < d i)
    (Q0 : Matrix g r ℝ) (hQ0 : Q0ᴴ * Q0 = 1)
    (hdim : Fintype.card h + Fintype.card r = Fintype.card g)
    (b : h → ℝ) (hb : ∀ i, 0 < b i) (z : s → ℝ) (hz : ∀ i, 0 < z i)
    {v L : ℝ} (hv : 0 ≤ v)
    (hmass : ∀ j, v ≤ ∑ a : {a : p // f a = j}, d a.val)
    (hbase : ∀ H : Finset g, H.card = Fintype.card r →
      IsUnit (principal (Q0 * Q0ᴴ) H) → L ≤ (principal (Q0 * Q0ᴴ) H)⁻¹.trace) :
    let n := (Σ j : g, Fin 1 ⊕ {i : p // f i = j}) ⊕ s
    let t := (h ⊕ p) ⊕ s
    let w : t → ℝ := Sum.elim (Sum.elim b d) z
    ∃ R : Matrix n t ℝ, Rᴴ * R = 1 ∧
      ∀ J : Finset n, J.card = Fintype.card t →
        IsUnit ((R.submatrix (fun i : J => (i : n)) id)ᴴ *
          R.submatrix (fun i : J => (i : n)) id) →
        (∑ i, w i) + v * L ≤ (diagonal w *
          ((R.submatrix (fun i : J => (i : n)) id)ᴴ *
            R.submatrix (fun i : J => (i : n)) id)⁻¹).trace := by
  classical
  let n := (Σ j : g, Fin 1 ⊕ {i : p // f i = j}) ⊕ s
  let t := (h ⊕ p) ⊕ s
  let w : t → ℝ := Sum.elim (Sum.elim b d) z
  let group : n → Option g := Sum.elim (fun x => some x.1) (fun _ => none)
  obtain ⟨V,Q,C,D,u,hV,hV',hQ,hQC,hC,hD,hCD,hrow,hcross,hdiag,hspec⟩ :=
    exists_full_group_model f d hd Q0 hQ0 hdim b hb z hz
  let e : (r ⊕ t) ≃ (((r ⊕ h) ⊕ p) ⊕ s) :=
    (Equiv.sumAssoc r (h ⊕ p) s).symm.trans
      (Equiv.sumCongr (Equiv.sumAssoc r h p).symm (Equiv.refl s))
  let U := V.submatrix id e
  have hU : Uᴴ * U = 1 := by
    rw [Matrix.conjTranspose_submatrix,
      ← Matrix.submatrix_mul _ _ e id e Function.bijective_id, hV]
    exact Matrix.submatrix_one e e.injective
  have hU' : U * Uᴴ = 1 := by
    rw [Matrix.conjTranspose_submatrix, Matrix.submatrix_mul_equiv, hV', Matrix.submatrix_id_id]
  have hs (a : r → ℝ) : U * diagonal (Sum.elim a w) * Uᴴ = Q * diagonal a * Qᴴ + C := by
    have he : diagonal (Sum.elim a w) =
        (diagonal (Sum.elim (Sum.elim (Sum.elim a b) d) z)).submatrix e e := by
      rw [Matrix.submatrix_diagonal_equiv]
      congr 1
      funext i
      rcases i with i | ((i | i) | i) <;> rfl
    rw [he]
    change V.submatrix id e * _ * (V.submatrix id e)ᴴ = _
    rw [Matrix.conjTranspose_submatrix, Matrix.submatrix_mul_equiv,
      Matrix.submatrix_mul_equiv, Matrix.submatrix_id_id]
    exact hspec a
  obtain ⟨R,hR,hcomp,hnoise⟩ := weighted_noise_frame U hU hU' Q C w
    (by simpa using hs (fun _ => 0))
    (by simpa using hs (fun _ => 1))
  have hnc : Fintype.card n = Fintype.card r + Fintype.card t := by
    have hh := Fintype.card_congr (groupCoordinateEquiv f)
    dsimp [n,t]
    simp only [Fintype.card_sum] at hh ⊢
    omega
  have hp : Q * Qᴴ = 1 - R * Rᴴ := by rw [← hcomp]; abel
  refine ⟨R,hR,?_⟩
  intro J hJ hu
  obtain ⟨hunit,htrace⟩ := weighted_complement_trace_selected R hR (diagonal w) J hu
  have hJc : Jᶜ.card = Fintype.card r := by
    change J.card = Fintype.card t at hJ
    rw [Finset.card_compl, hJ, hnc]
    omega
  have hh := actual_grouped_weighted_lower Q0 Q group u hrow C D hCD
    (fun j => ∑ a : {a : p // f a = j}, d a.val) hcross hdiag hv hmass hbase
    Jᶜ hJc (by rwa [hp])
  rw [htrace, hnoise, ← hp]
  rw [Matrix.trace_diagonal]
  change (∑ i,w i) + v * L ≤ (∑ i,w i) + _
  linarith

end SpectralComparison
