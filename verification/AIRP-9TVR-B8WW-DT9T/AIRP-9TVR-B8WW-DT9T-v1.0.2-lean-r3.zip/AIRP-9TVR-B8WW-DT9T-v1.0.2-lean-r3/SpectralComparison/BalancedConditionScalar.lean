import SpectralComparison.BalancedSqrt

noncomputable section
namespace SpectralComparison

/-- The finite balanced scalar comparison, retaining the square-root head condition factor. -/
theorem balanced_condition_scalar {a s g c x y q r : ℝ}
    (ha : 0 < a) (hs : 0 < s) (hg : 0 < g) (hc : 0 ≤ c)
    (hy0 : 0 ≤ y) (hq : 0 ≤ q) (hr : 0 ≤ r) (hq2 : q^2 = r^2*a*s)
    (hdiag : s ≤ x) (hridge : a*(g*s)/(a+g*s) ≤ x)
    (hylinear : y ≤ c*s) (hysqrt : y ≤ c*q) :
    y/x ≤ c*min 1 (g⁻¹+r) := by
  have hx : 0 < x := hs.trans_le hdiag
  rw [mul_min_of_nonneg _ _ hc]
  apply le_min
  · rw [mul_one]
    apply (div_le_iff₀ hx).mpr
    exact hylinear.trans (mul_le_mul_of_nonneg_left hdiag hc)
  · by_cases hsa : s ≤ a
    · have hqa : q ≤ r*a := by
        apply (sq_le_sq₀ hq (mul_nonneg hr ha.le)).mp
        rw [hq2,mul_pow]
        have hh := mul_le_mul_of_nonneg_left hsa (mul_nonneg (sq_nonneg r) ha.le)
        nlinarith
      have hyy := hysqrt.trans (mul_le_mul_of_nonneg_left hqa hc)
      have hd : 0 < a*(g*s)/(a+g*s) := by positivity
      have hh := div_le_div_of_nonneg_left hy0 hd hridge
      have he : y/(a*(g*s)/(a+g*s)) = y/(g*s)+y/a := by field_simp
      rw [he] at hh
      have h1 : y/(g*s) ≤ c/g := by
        apply (div_le_iff₀ (mul_pos hg hs)).mpr
        have he : c/g*(g*s) = c*s := by field_simp
        rwa [he]
      have h2 : y/a ≤ c*r := (div_le_iff₀ ha).mpr (by nlinarith [hyy])
      simp only [div_eq_mul_inv] at h1 hh h2 ⊢
      nlinarith
    · have has : a ≤ s := le_of_not_ge hsa
      have hqs : q ≤ r*s := by
        apply (sq_le_sq₀ hq (mul_nonneg hr hs.le)).mp
        rw [hq2,mul_pow]
        have hh := mul_le_mul_of_nonneg_right has (mul_nonneg (sq_nonneg r) hs.le)
        nlinarith
      have hyy := hysqrt.trans (mul_le_mul_of_nonneg_left hqs hc)
      have hh := div_le_div_of_nonneg_left hy0 hs hdiag
      have h2 : y/s ≤ c*r := (div_le_iff₀ hs).mpr (by nlinarith [hyy])
      have hpos : 0 ≤ c*g⁻¹ := by positivity
      nlinarith

end SpectralComparison
