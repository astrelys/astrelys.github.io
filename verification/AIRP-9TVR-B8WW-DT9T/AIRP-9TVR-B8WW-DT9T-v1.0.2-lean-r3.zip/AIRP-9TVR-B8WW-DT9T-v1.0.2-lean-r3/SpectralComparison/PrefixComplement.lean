import SpectralComparison.PrefixReplication
import SpectralComparison.ComplementInverse

/-! Complementing the repeated Parseval frame proves the large-prefix projection bound. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Column Grams of complementary row sets partition the Parseval identity. -/
theorem parseval_complement_row_gram {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p] (Q : Matrix n p ℝ) (hQ : Qᴴ*Q=1) (J : Finset n) :
    (Q.submatrix (fun i : ↥(Jᶜ) => (i:n)) id)ᴴ*Q.submatrix (fun i : ↥(Jᶜ) => (i:n)) id =
      1-(Q.submatrix (fun i : J => (i:n)) id)ᴴ*Q.submatrix (fun i : J => (i:n)) id := by
  rw [row_selection_gram_eq,row_selection_gram_eq]
  have hd : Matrix.diagonal (fun i : n => if i∈Jᶜ then (1:ℝ) else 0) =
      1-Matrix.diagonal (fun i : n => if i∈J then (1:ℝ) else 0) := by
    ext a b
    by_cases hab : a=b
    · subst b; simp only [Matrix.diagonal_apply_eq,Matrix.sub_apply,Matrix.one_apply_eq]
      by_cases ha : a∈J <;> simp [ha]
    · simp [hab]
  rw [hd,Matrix.mul_sub,Matrix.sub_mul,Matrix.mul_one,hQ]

/-- Restriction of the complementary projection is the complementary row Gram. -/
theorem complementary_projection_block {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq n] (Q : Matrix n p ℝ) (J : Finset n) :
    (1-Q*Qᴴ).submatrix (fun i : J => (i:n)) (fun i : J => (i:n)) =
      1-Q.submatrix (fun i : J => (i:n)) id*(Q.submatrix (fun i : J => (i:n)) id)ᴴ := by
  have hI := Matrix.submatrix_one (α := ℝ) (fun i : J => (i:n)) Subtype.val_injective
  ext a b
  have hi := congrFun (congrFun hI a) b
  simp only [Matrix.submatrix_apply] at hi
  simp only [Matrix.submatrix_apply,Matrix.sub_apply,Matrix.mul_apply,Matrix.conjTranspose_apply,hi]
  rfl

/-- Full unregularized prefix projection statement for t >= k, with no construction assumptions. -/
theorem prefix_projection_large {k q t : ℕ} (hk : 1≤k) (hq : 2*q≤k) (htk : k≤t) :
    ∃ P : Matrix (Fin (k+t)) (Fin (k+t)) ℝ, P.PosSemidef ∧ P*P=P ∧ P.rank=t+q ∧
      ∀ J : Finset (Fin (k+t)), J.card=t →
        IsUnit (P.submatrix (fun i : J => (i:Fin (k+t))) (fun i : J => (i:Fin (k+t)))) →
        (k:ℝ)*t/(32000000000000000000000000000*((q:ℝ)+Real.sqrt k)) ≤
        (P.submatrix (fun i : J => (i:Fin (k+t))) (fun i : J => (i:Fin (k+t))))⁻¹.trace := by
  obtain ⟨Q,hQ,hb⟩ := prefix_large_column_frame hk hq htk
  obtain ⟨hP,hi,hr⟩ := complementary_frame_projection Q hQ (show k-q≤k+t by omega)
  refine ⟨1-Q*Qᴴ,hP,hi,by rw [hr]; omega,?_⟩
  intro J hJ hu
  let A := Q.submatrix (fun i : J => (i:Fin (k+t))) id
  let B := (Q.submatrix (fun i : ↥(Jᶜ) => (i:Fin (k+t))) id)ᴴ *
    Q.submatrix (fun i : ↥(Jᶜ) => (i:Fin (k+t))) id
  have he : B=1-Aᴴ*A := parseval_complement_row_gram Q hQ J
  rw [complementary_projection_block] at hu ⊢
  change IsUnit (1-A*Aᴴ) at hu
  change _≤(1-A*Aᴴ)⁻¹.trace
  have hbu := (complement_gram_isUnit_iff A).mp hu
  have hJc : Jᶜ.card=k := by rw [Finset.card_compl,hJ]; simp
  have hl : ((k+t:ℕ):ℝ)*k/(32000000000000000000000000000*((q:ℝ)+Real.sqrt k))≤B⁻¹.trace :=
    hb Jᶜ hJc (by change IsUnit B; rw [he]; exact hbu)
  have htrace := complement_gram_inverse_trace A hbu
  rw [← he] at htrace
  simp only [Fintype.card_coe,hJ,Fintype.card_fin] at htrace
  rw [htrace]
  have hdim : ((k-q:ℕ):ℝ)≤t := by exact_mod_cast (show k-q≤t by omega)
  have hn : (k:ℝ)*t≤((k+t:ℕ):ℝ)*k := by push_cast; nlinarith [Nat.cast_nonneg (α := ℝ) k]
  have hc := div_le_div_of_nonneg_right hn
    (show (0:ℝ)≤32000000000000000000000000000*((q:ℝ)+Real.sqrt k) by positivity)
  linarith

end SpectralComparison
