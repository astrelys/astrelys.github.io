import SpectralComparison.StableSplit

noncomputable section
open Finset
namespace SpectralComparison

/-- D.3 and the quantitative variance bound for the original normalized spectrum. -/
theorem original_water_stability {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i)
    (hk : 1≤k) (hkn : k<n) (hm : 2≤n-k) (hroot : waterSum a 1=k) :
    let S := Finset.univ.filter (fun i => 1<a i)
    let T := ∑ i∈Finset.univ\S,a i
    let U := ((n-S.card:ℕ):ℝ)-T
    let D := (n-k:ℕ)/(n:ℝ)*((S.card:ℝ)+T)-symmetricQuotient (Finset.univ.val.map a) k
    0≤D ∧ U≤(n:ℝ)*D/k ∧
      (D<(k:ℝ)/(2*n) → (∑ i∈S,(a i)⁻¹*(1-(a i)⁻¹))≤(2:ℝ)^n*D) := by
  classical
  let S := Finset.univ.filter (fun i => 1<a i)
  let O := Finset.univ\S
  have hs := waterLevel_active a ha (by norm_num : (0:ℝ)<1) hroot hk
  change k<S.card ∧ (∑ i∈S,1/a i)=(S.card:ℝ)-(k:ℝ) ∧ _ at hs
  have hsc : S.card≤n := by simpa using Finset.card_le_card (Finset.subset_univ S)
  have hoc : O.card=n-S.card := by dsimp [O]; simp [Finset.card_sdiff_of_subset (Finset.subset_univ S)]
  have hn : Fintype.card S+(O.val.map a).card=n := by simp only [Fintype.card_coe,Multiset.card_map,Finset.card_val,hoc]; omega
  have ht : ∀ z∈O.val.map a,0<z ∧ z≤1 := by
    intro z hz
    obtain ⟨i,hi,rfl⟩ := Multiset.mem_map.mp hz
    exact ⟨ha i,hs.2.2 i hi⟩
  have hsum : (∑ i : S,(a i)⁻¹)=(Fintype.card S-k:ℕ) := by
    rw [Finset.sum_coe_sort S (fun i => (a i)⁻¹),Fintype.card_coe,Nat.cast_sub hs.1.le]
    simpa only [one_div] using hs.2.1
  have h := split_water_stability (fun i : S => a i) (fun i => (Finset.mem_filter.mp i.property).2)
    (O.val.map a) ht hk (by simpa using hs.1) (by rw [hn]; exact hm) hsum
  dsimp only at h ⊢
  rw [hn,restricted_spectrum_multiset,spectrum_partition_multiset] at h
  simp only [Fintype.card_coe,Multiset.card_map,Finset.card_val,hoc] at h
  have he : (O.val.map a).sum=∑ i∈O,a i := rfl
  rw [he,Finset.sum_coe_sort S (fun i => (a i)⁻¹*(1-(a i)⁻¹))] at h
  exact h

/-- Ordered finite spectra inherit a lower head bound from any k-element subset. -/
theorem ordered_head_of_subset {n k : ℕ} (a : Fin n → ℝ) (horder : Antitone a)
    (J : Finset (Fin n)) (hJ : J.card=k) {L : ℝ} (hL : ∀ i∈J,L≤a i) :
    ∀ i : Fin n,i.val<k → L≤a i := by
  intro i hi
  by_contra hn
  have ha : a i<L := lt_of_not_ge hn
  have hsub : J⊆spectralPrefix i.val := by
    intro j hj
    have hv : j.val < i.val := by
      by_contra hh
      have hle : i≤j := Fin.le_iff_val_le_val.mpr (by omega)
      have ho := horder hle
      linarith [hL j hj]
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ j,hv⟩
  have hc := Finset.card_le_card hsub
  rw [hJ,spectralPrefix_card i.isLt.le] at hc
  omega

/-- The original D.4 spectral shape, with every counting and rounding step proved internally. -/
theorem original_stable_shape {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i)
    (horder : Antitone a) (hk : 1≤k) (hkn : k<n) (hm : 2≤n-k) (hroot : waterSum a 1=k)
    {L : ℝ} (hL : 1<L) :
    let S := Finset.univ.filter (fun i => 1<a i)
    let T := ∑ i∈Finset.univ\S,a i
    let D := (n-k:ℕ)/(n:ℝ)*((S.card:ℝ)+T)-symmetricQuotient (Finset.univ.val.map a) k
    D<(k:ℝ)/(2*n) → (2:ℝ)^(n+1)*D≤1/L →
      (∀ i : Fin n,i.val<k → L≤a i) ∧ (∀ i,1-(n:ℝ)*D/k≤a i) := by
  classical
  let S := Finset.univ.filter (fun i => 1<a i)
  let O := Finset.univ\S
  let T := ∑ i∈O,a i
  let U := ((n-S.card:ℕ):ℝ)-T
  let D := (n-k:ℕ)/(n:ℝ)*((S.card:ℝ)+T)-symmetricQuotient (Finset.univ.val.map a) k
  let β := fun i : S => (a i)⁻¹
  let V := ∑ i : S,β i*(1-β i)
  change D<(k:ℝ)/(2*n) → (2:ℝ)^(n+1)*D≤1/L → _
  intro hsmall hexp
  have hs := waterLevel_active a ha (by norm_num : (0:ℝ)<1) hroot hk
  change k<S.card ∧ (∑ i∈S,1/a i)=(S.card:ℝ)-(k:ℝ) ∧ _ at hs
  have hb : ∀ i : S,0≤β i := fun i => (inv_pos.mpr (ha i)).le
  have hb1 : ∀ i : S,β i≤1 := fun i => (inv_le_one₀ (ha i)).mpr (Finset.mem_filter.mp i.property).2.le
  have hsum : (∑ i : S,β i)=(S.card-k:ℕ) := by
    change (∑ i : S,(a i)⁻¹)=_
    rw [Finset.sum_coe_sort S (fun i => (a i)⁻¹),Nat.cast_sub hs.1.le]
    simpa only [β,one_div] using hs.2.1
  have hst := original_water_stability a ha hk hkn hm hroot
  change 0≤D ∧ U≤(n:ℝ)*D/k ∧ _ at hst
  have hv : V≤(2:ℝ)^n*D := by
    have hh := hst.2.2 hsmall
    rw [← Finset.sum_coe_sort S (fun i => (a i)⁻¹*(1-(a i)⁻¹))] at hh
    exact hh
  have h2V : 2*V≤1/L := by rw [pow_succ] at hexp; nlinarith
  have hL0 : 0<L := (by norm_num : (0:ℝ)<1).trans hL
  have hiL : 1/L<1 := (div_lt_one hL0).mpr hL
  have hround := unit_rounding β hb hb1 hsum (h2V.trans_lt hiL)
  let R := Finset.univ.filter (fun i : S => (1:ℝ)/2≤β i)
  change R.card=S.card-k ∧ (∀ i : S,i∉R → β i≤2*V) at hround
  let Z := (Finset.univ : Finset S)\R
  let J := Z.image (fun i : S => (i:Fin n))
  have hJ : J.card=k := by
    rw [Finset.card_image_of_injective _ Subtype.val_injective,Finset.card_sdiff_of_subset (Finset.subset_univ R),Finset.card_univ,Fintype.card_coe,hround.1]
    omega
  have hJbound : ∀ i∈J,L≤a i := by
    intro i hi
    obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp hi
    have hz : j∉R := (Finset.mem_sdiff.mp hj).2
    have hbnd := (hround.2 j hz).trans h2V
    change (a j)⁻¹≤1/L at hbnd
    have hh := (inv_le_inv₀ (ha j) hL0).mp (by simpa only [one_div] using hbnd)
    exact hh
  refine ⟨ordered_head_of_subset a horder J hJ hJbound,?_⟩
  intro i
  have hND : 0≤(n:ℝ)*D/k := by have hD:=hst.1; positivity
  by_cases hi : i∈S
  · have hai := (Finset.mem_filter.mp hi).2
    linarith
  · have hmem : i∈O := Finset.mem_sdiff.mpr ⟨Finset.mem_univ i,hi⟩
    have hsumU : (∑ j∈O,(1-a j))=U := by
      rw [Finset.sum_sub_distrib]
      dsimp [U,T,O]
      simp [Finset.card_sdiff_of_subset (Finset.subset_univ S)]
    have hu : 1-a i≤U := by
      rw [← hsumU]
      exact Finset.single_le_sum (fun j hj => sub_nonneg.mpr (hs.2.2 j hj)) hmem
    linarith [hst.2.1]

end SpectralComparison
