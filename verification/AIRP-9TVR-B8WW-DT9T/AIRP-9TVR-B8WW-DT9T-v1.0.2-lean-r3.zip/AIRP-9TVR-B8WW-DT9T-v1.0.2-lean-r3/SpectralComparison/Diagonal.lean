import SpectralComparison.WorstOrientation

/-! Diagonal-orientation lower bounds, with actual coordinate residuals. -/
noncomputable section
namespace SpectralComparison
open Matrix Finset
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

omit [Fintype ι] in
/-- Outside selected coordinates, a diagonal matrix keeps its original diagonal. -/
theorem diagonal_residual_outside (eig : ι → ℝ) (I : Finset ι) (j : ι) (hj : j ∉ I) :
    residual (Matrix.diagonal eig) I j j = eig j := by
  have hn (i : I) : (i : ι) ≠ j := by
    intro h
    exact hj (h ▸ i.property)
  simp [residual, Matrix.sub_apply, Matrix.mul_apply, Matrix.submatrix_apply,
    Matrix.diagonal_apply, hn]

/-- For diagonal orientation the error is the sum of unselected eigenvalues. -/
theorem diagonal_residualTrace (eig : ι → ℝ) (heig : ∀ i, 0 < eig i) (I : Finset ι) :
    residualTrace (Matrix.diagonal eig) I = ∑ j ∈ Finset.univ \ I, eig j := by
  rw [residualTrace_eq_complement_sum (Matrix.PosDef.diagonal heig)]
  apply Finset.sum_congr rfl
  intro j hj
  exact diagonal_residual_outside eig I j (Finset.mem_sdiff.mp hj).2

omit [Fintype ι] in
/-- A separated top set maximizes the sum among all subsets of equal cardinality. -/
theorem sum_le_sum_top_set (eig : ι → ℝ) (T I : Finset ι) (hc : I.card = T.card)
    (hsep : ∀ i ∈ T, ∀ j ∉ T, eig j ≤ eig i) :
    (∑ i ∈ I, eig i) ≤ ∑ i ∈ T, eig i := by
  let e : ↥(I \ T) ≃ ↥(T \ I) := Finset.equivOfCardEq (Finset.card_sdiff_comm hc)
  have hle : (∑ j ∈ I \ T, eig j) ≤ ∑ i ∈ T \ I, eig i := by
    rw [← Finset.sum_coe_sort (I \ T) eig, ← Finset.sum_coe_sort (T \ I) eig]
    calc
      (∑ j : ↥(I \ T), eig j) ≤ ∑ j : ↥(I \ T), eig (e j) := by
        apply Finset.sum_le_sum
        intro j _
        exact hsep (e j) (Finset.mem_sdiff.mp (e j).property).1 j (Finset.mem_sdiff.mp j.property).2
      _ = ∑ i : ↥(T \ I), eig i := Fintype.sum_equiv e _ _ (fun _ => rfl)
  have he := (Finset.sum_sdiff_sub_sum_sdiff (s₁ := T) (s₂ := I) (f := eig))
  linarith

/-- The exact best error of the diagonal orientation is the tail beyond any separated top set. -/
theorem diagonal_bestError (eig : ι → ℝ) (heig : ∀ i, 0 < eig i) (T : Finset ι)
    (hsep : ∀ i ∈ T, ∀ j ∉ T, eig j ≤ eig i) :
    bestError (Matrix.diagonal eig) T.card = ∑ j ∈ Finset.univ \ T, eig j := by
  apply le_antisymm
  · simpa only [diagonal_residualTrace eig heig] using (bestError_le (Matrix.diagonal eig) (I := T) rfl)
  · apply le_bestError _ (by simpa using T.card_le_univ)
    intro I hI
    rw [diagonal_residualTrace eig heig]
    have hle := sum_le_sum_top_set eig T I hI hsep
    have hT := Finset.sum_sdiff (f := eig) (Finset.subset_univ T)
    have hJ := Finset.sum_sdiff (f := eig) (Finset.subset_univ I)
    linarith

/-- The actual worst-orientation error is at least the diagonal tail. -/
theorem tail_le_worstError (eig : ι → ℝ) (heig : ∀ i, 0 < eig i) (T : Finset ι)
    (hsep : ∀ i ∈ T, ∀ j ∉ T, eig j ≤ eig i) (hk : T.card < Fintype.card ι) :
    (∑ j ∈ Finset.univ \ T, eig j) ≤ worstError eig T.card := by
  have h := orbit_bestError_le_worstError eig heig (1 : Matrix ι ι ℝ) (by simp) hk
  simpa only [Matrix.transpose_one, Matrix.one_mul, Matrix.mul_one,
    diagonal_bestError eig heig T hsep] using h

/-- The elementary quotient gives y_k at most (k+1) times any complementary tail. -/
theorem spectralMean_le_tail (eig : ι → ℝ) (heig : ∀ i, 0 < eig i) (T : Finset ι) :
    spectralMean eig T.card ≤ ((T.card : ℝ)+1) * ∑ j ∈ Finset.univ \ T, eig j := by
  have hp (A : Finset ι) : ∀ z ∈ A.val.map eig, 0 < z := by
    intro z hz
    obtain ⟨i, hi, rfl⟩ := Multiset.mem_map.mp hz
    exact heig i
  have hs : T.val.map eig + ((Finset.univ : Finset ι) \ T).val.map eig =
      (Finset.univ.val.map eig) := by
    rw [← Multiset.map_add, Finset.sdiff_val,
      add_tsub_cancel_of_le (Finset.val_le_iff.mpr (Finset.subset_univ T))]
  have h := symmetric_quotient_le_tail (T.val.map eig) (((Finset.univ : Finset ι) \ T).val.map eig)
    (hp T) (hp _)
  simp only [hs, Multiset.card_map, Finset.card_val, Finset.sum_map_val] at h
  unfold spectralMean
  rw [mul_div_assoc]
  exact mul_le_mul_of_nonneg_left h (by positivity)

/-- Complete determinant-weighted comparison for a separated top set. -/
theorem determinant_weighted_comparison (eig : ι → ℝ) (heig : ∀ i, 0 < eig i) (T : Finset ι)
    (hsep : ∀ i ∈ T, ∀ j ∉ T, eig j ≤ eig i) (hk : T.card < Fintype.card ι) :
    (∑ j ∈ Finset.univ \ T, eig j) ≤ worstError eig T.card ∧
      worstError eig T.card ≤ spectralMean eig T.card ∧
      spectralMean eig T.card ≤ ((T.card : ℝ)+1) * worstError eig T.card := by
  have hs := tail_le_worstError eig heig T hsep hk
  exact ⟨hs, worstError_le_spectralMean eig heig hk,
    (spectralMean_le_tail eig heig T).trans (mul_le_mul_of_nonneg_left hs (by positivity))⟩

/-- Paper Lemma 8.3 for a decreasing positive spectrum, with 0-based Fin n indices.
The condition k ≤ i.val is exactly the paper's 1-based i = k+1,...,n tail. -/
theorem paper_lemma_8_3 {n k : ℕ} (eig : Fin n → ℝ) (heig : ∀ i, 0 < eig i)
    (horder : Antitone eig) (_hk : 1 ≤ k) (hkn : k < n) :
    (∑ i ∈ Finset.univ.filter (fun i : Fin n => k ≤ i.val), eig i) ≤ worstError eig k ∧
      worstError eig k ≤ spectralMean eig k ∧
      spectralMean eig k ≤ ((k : ℝ)+1) * worstError eig k := by
  let a : Fin n := ⟨k, hkn⟩
  have hs : ∀ i ∈ Finset.Iio a, ∀ j ∉ Finset.Iio a, eig j ≤ eig i := by
    intro i hi j hj
    exact horder (le_trans (Finset.mem_Iio.mp hi).le (not_lt.mp (by simpa using hj)))
  have hc : (Finset.Iio a).card = k := Fin.card_Iio a
  have ht : Finset.univ \ Finset.Iio a = Finset.univ.filter (fun i : Fin n => k ≤ i.val) := by
    ext i
    simp [a, Fin.lt_def]
  have h := determinant_weighted_comparison eig heig (Finset.Iio a) hs (by simpa [hc] using hkn)
  simpa only [ht, hc] using h

end SpectralComparison
