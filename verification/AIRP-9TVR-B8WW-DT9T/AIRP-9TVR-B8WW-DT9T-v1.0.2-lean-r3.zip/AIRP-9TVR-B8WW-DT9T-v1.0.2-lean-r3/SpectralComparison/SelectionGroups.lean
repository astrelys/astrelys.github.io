import SpectralComparison.HeavyLight
import SpectralComparison.FrameCompletion

/-! Actual selected-row counts and their rank constraint. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Every selected row belongs to at most one group; singleton rows use `none`. -/
theorem selected_group_count_le {n g : Type*} [Fintype n] [Fintype g]
    [DecidableEq n] [DecidableEq g] (f : n → Option g) :
    (∑ j : g,(Finset.univ.filter (fun i => f i=some j)).card)≤Fintype.card n := by
  classical
  simp only [Finset.card_eq_sum_ones,Finset.sum_filter]
  rw [Finset.sum_comm]
  calc
    (∑ i : n,∑ j : g,if f i=some j then (1:ℕ) else 0) ≤ ∑ _i : n,1 := by
      apply Finset.sum_le_sum
      intro i _
      cases hf : f i with
      | none => simp
      | some j => simp
    _ = Fintype.card n := by simp

/-- A light group has exactly one actual selected row. -/
theorem selected_light_unique {n g : Type*} [Fintype n] [DecidableEq n] [DecidableEq g]
    (f : n → Option g) {j : g}
    (hj : (Finset.univ.filter (fun i => f i=some j)).card=1)
    {i x : n} (hi : f i=some j) (hx : f x=some j) : i=x := by
  exact Finset.card_le_one.mp hj.le i (by simp [hi]) x (by simp [hx])

/-- Full column rank forces sufficiently many nonempty groups in the actual selection.
No lower bound on the nonzero amplitudes is required. -/
theorem selected_group_support_rank {n g r : Type*}
    [Fintype n] [Fintype g] [Fintype r]
    [DecidableEq n] [DecidableEq g] [DecidableEq r]
    (f : n → Option g) (u : n → ℝ) (Q0 : Matrix g r ℝ)
    (Q : Matrix n r ℝ)
    (hrow : ∀ i j,Q i j=match f i with | none => 0 | some a => u i*Q0 a j)
    (hfull : IsUnit (Qᴴ*Q)) :
    Fintype.card r≤(Finset.univ.filter (fun j => 0<(Finset.univ.filter (fun i => f i=some j)).card)).card := by
  classical
  let S := Finset.univ.filter (fun j => 0<(Finset.univ.filter (fun i => f i=some j)).card)
  let E : Matrix n S ℝ := Matrix.of (fun i j => if f i=some j.val then u i else 0)
  let B : Matrix S r ℝ := Q0.submatrix Subtype.val id
  have hfac : Q=E*B := by
    ext i j
    rw [hrow,Matrix.mul_apply]
    cases hf : f i with
    | none => simp [E,hf]
    | some a =>
      have ha : a∈S := by
        simp only [S,Finset.mem_filter,Finset.mem_univ,true_and]
        exact Finset.card_pos.mpr ⟨i,by simp [hf]⟩
      have heq : (∑ x : S,E i x*B x j)=E i ⟨a,ha⟩*B ⟨a,ha⟩ j := by
        apply Finset.sum_eq_single (⟨a,ha⟩ : S)
        · intro b _ hb
          have hba : a≠b.val := by intro hh; apply hb; exact Subtype.ext hh.symm
          simp [E,hf,hba]
        · simp
      rw [heq]
      simp [E,B,hf]
  have h1 : Fintype.card r≤Q.rank := by
    rw [← Matrix.rank_of_isUnit (Qᴴ*Q) hfull]
    exact Matrix.rank_mul_le_right _ _
  have h2 : Q.rank≤Fintype.card S := by
    rw [hfac]
    exact (Matrix.rank_mul_le_left _ _).trans (Matrix.rank_le_card_width _)
  change Fintype.card r≤S.card
  exact h1.trans (h2.trans_eq (Fintype.card_coe S))

/-- The heavy/light cardinality bounds now follow from the selected rows and their actual Gram. -/
theorem actual_selection_heavy_light {n g : Type*} [Fintype n] [Fintype g]
    [DecidableEq n] [DecidableEq g] {k q : ℕ} (hq : 4*q≤k)
    (hn : Fintype.card n≤k) (f : n → Option g) (u : n → ℝ)
    (Q0 : Matrix g (Fin (k-q)) ℝ) (Q : Matrix n (Fin (k-q)) ℝ)
    (hrow : ∀ i j,Q i j=match f i with | none => 0 | some a => u i*Q0 a j)
    (hfull : IsUnit (Qᴴ*Q)) :
    let w := fun j => (Finset.univ.filter (fun i => f i=some j)).card
    let H := Finset.univ.filter (fun j => 2≤w j)
    let L := Finset.univ.filter (fun j => w j=1)
    Disjoint H L ∧ H.card≤q ∧ 4*H.card≤k ∧ H.card+L.card≤k := by
  apply heavy_light_card_bounds hq _ ((selected_group_count_le f).trans hn)
  simpa using selected_group_support_rank f u Q0 Q hrow hfull

end SpectralComparison
