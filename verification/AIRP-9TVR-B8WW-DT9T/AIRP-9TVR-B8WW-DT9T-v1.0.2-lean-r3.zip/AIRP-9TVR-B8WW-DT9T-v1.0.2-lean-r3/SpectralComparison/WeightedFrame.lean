import SpectralComparison.WeightedDiffuseFrame

noncomputable section
open Matrix
namespace SpectralComparison

theorem sum_initial_eq {t q m : ℕ} (h : t ≤ m) (hqm : q ≤ m) (he : t = q)
    (b : Fin m → ℝ) : (∑ i : Fin t, b (i.castLE h)) = ∑ i : Fin q, b (i.castLE hqm) := by
  subst q
  rfl

/-- Small signal dimensions require only the universal total-weight lower bound. -/
theorem weighted_frame_small_signal {k m : ℕ} (hk : 1 ≤ k) (hk3 : k ≤ 3) (hkm : k < m)
    (b : Fin m → ℝ) (hb : ∀ i, 0 < b i) :
    ∃ R : Matrix (Fin (k+m)) (Fin m) ℝ, Rᴴ * R = 1 ∧
      ∀ J : Finset (Fin (k+m)), J.card = m →
        IsUnit ((R.submatrix (fun i : J => (i : Fin (k+m))) id)ᴴ *
          R.submatrix (fun i : J => (i : Fin (k+m))) id) →
        weightedGamma k m * (∑ i,b i) ≤ (diagonal b *
          ((R.submatrix (fun i : J => (i : Fin (k+m))) id)ᴴ *
            R.submatrix (fun i : J => (i : Fin (k+m))) id)⁻¹).trace := by
  obtain ⟨R,hR,_⟩ := exists_coordinate_frame_control (t:=m) (N:=k+m) (p:=m) (by omega)
  refine ⟨R,hR,?_⟩
  intro J _ hu
  have hh := weighted_basis_trace_lower R hR (diagonal b)
    (Matrix.PosSemidef.diagonal (fun i => (hb i).le)) J hu
  rw [Matrix.trace_diagonal] at hh
  apply le_trans _ hh
  have hs : 0 ≤ ∑ i,b i := Finset.sum_nonneg (fun i _ => (hb i).le)
  have hsk : Real.sqrt (k:ℝ) ≤ 2 := (Real.sqrt_le_iff).mpr ⟨by norm_num,by exact_mod_cast (show k ≤ 2^2 by omega)⟩
  dsimp [weightedGamma]
  rw [ite_eq_right (by omega : ¬m ≤ k)]
  nlinarith

/-- E.1 for decreasing positive weights, including both concentrated and diffuse regimes. -/
theorem weighted_frame_sorted {k m : ℕ} (hk : 1 ≤ k) (hm : 1 ≤ m)
    (b : Fin m → ℝ) (hb : ∀ i, 0 < b i) (horder : Antitone b) :
    ∃ R : Matrix (Fin (k+m)) (Fin m) ℝ, Rᴴ * R = 1 ∧
      ∀ J : Finset (Fin (k+m)), J.card = m →
        IsUnit ((R.submatrix (fun i : J => (i : Fin (k+m))) id)ᴴ *
          R.submatrix (fun i : J => (i : Fin (k+m))) id) →
        weightedGamma k m * (∑ i,b i) ≤ (diagonal b *
          ((R.submatrix (fun i : J => (i : Fin (k+m))) id)ᴴ *
            R.submatrix (fun i : J => (i : Fin (k+m))) id)⁻¹).trace := by
  by_cases hmk : m ≤ k
  · exact weighted_frame_small hk hm hmk b hb horder
  have hkm : k < m := by omega
  by_cases hk3 : k ≤ 3
  · exact weighted_frame_small_signal hk hk3 hkm b hb
  by_cases hprefix : (∑ i,b i)/2 ≤ ∑ i : Fin (min m (8*k)), b (i.castLE (min_le_left _ _))
  · exact weighted_frame_concentrated hk hkm b hb horder hprefix
  have hs : 0 < ∑ i,b i := Finset.sum_pos (fun i _ => hb i) ⟨⟨0,by omega⟩,Finset.mem_univ _⟩
  have h8 : 8*k ≤ m := by
    by_contra! hn
    have hm8 : m ≤ 8*k := by omega
    have he := sum_initial_eq (min_le_left m (8*k)) (le_refl m) (min_eq_left hm8) b
    rw [he] at hprefix
    simp only [Fin.castLE_refl] at hprefix
    linarith
  obtain ⟨p,rfl⟩ := Nat.exists_eq_add_of_le h8
  have hhead : (∑ i : Fin (8*k), b (i.castAdd p)) < (∑ i,b i)/2 := by
    have hh := lt_of_not_ge hprefix
    have he := sum_initial_eq (min_le_left (8*k+p) (8*k)) (show 8*k ≤ 8*k+p by omega)
      (min_eq_right (show 8*k ≤ 8*k+p by omega)) b
    rw [he] at hh
    exact hh
  obtain ⟨R,hR,hcost⟩ := weighted_frame_diffuse_large (by omega) b hb horder hhead
  refine ⟨R,hR,?_⟩
  intro J hJ hu
  simpa only [weightedGamma, ite_eq_right (by omega : ¬8*k+p ≤ k)] using hcost J hJ hu

/-- E.1: every positive diagonal weight matrix admits an actual real Parseval frame with the stated uniform basis cost. -/
theorem paper_weighted_frame {k m : ℕ} (hk : 1 ≤ k) (hm : 1 ≤ m)
    (b : Fin m → ℝ) (hb : ∀ i, 0 < b i) :
    ∃ R : Matrix (Fin (k+m)) (Fin m) ℝ, Rᴴ * R = 1 ∧
      ∀ J : Finset (Fin (k+m)), J.card = m →
        IsUnit ((R.submatrix (fun i : J => (i : Fin (k+m))) id)ᴴ *
          R.submatrix (fun i : J => (i : Fin (k+m))) id) →
        weightedGamma k m * (∑ i,b i) ≤ (diagonal b *
          ((R.submatrix (fun i : J => (i : Fin (k+m))) id)ᴴ *
            R.submatrix (fun i : J => (i : Fin (k+m))) id)⁻¹).trace := by
  let e := Tuple.sort (α:=OrderDual ℝ) b
  obtain ⟨Q,hQ,hcost⟩ := weighted_frame_sorted hk hm (b ∘ e) (fun _ => hb _)
    (Tuple.monotone_sort (α:=OrderDual ℝ) b)
  have hr := weighted_frame_reindex Q hQ (b ∘ e) (by simpa only [Fintype.card_fin] using hcost) (Equiv.refl _) e.symm
  have he : (b ∘ e) ∘ e.symm = b := by funext i; simp
  rw [he] at hr
  have hsum : (∑ i,(b ∘ e) i) = ∑ i,b i := Equiv.sum_comp e b
  rw [hsum] at hr
  exact ⟨Q.submatrix (Equiv.refl _) e.symm, hr.1, by simpa only [Fintype.card_fin] using hr.2⟩

end SpectralComparison
