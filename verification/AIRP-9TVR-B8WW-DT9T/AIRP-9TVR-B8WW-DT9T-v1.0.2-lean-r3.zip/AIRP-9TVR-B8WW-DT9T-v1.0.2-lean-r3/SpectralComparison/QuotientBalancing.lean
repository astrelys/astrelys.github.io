import SpectralComparison.WeightedLimit

noncomputable section
namespace SpectralComparison

theorem esymm_cross_adjacent (s : Multiset ℝ) (hs : ∀ z ∈ s, 0 < z) (j : ℕ) :
    s.esymm j * s.esymm (j+3) ≤ s.esymm (j+1) * s.esymm (j+2) := by
  by_cases hc : j+3 ≤ s.card
  · have hh := logconcavity_cross (esymm_pos s hs (j+1) (by omega))
      (esymm_pos s hs (j+2) (by omega)) (esymm_nonneg s (fun z hz => (hs z hz).le) (j+3))
      (esymm_logconcave s hs j) (esymm_logconcave s hs (j+1))
    nlinarith
  · rw [Multiset.esymm_of_card_lt (show s.card < j+3 by omega), mul_zero]
    exact mul_nonneg (esymm_nonneg s (fun z hz => (hs z hz).le) _) (esymm_nonneg s (fun z hz => (hs z hz).le) _)

theorem esymm_pair (s : Multiset ℝ) (x y : ℝ) (j : ℕ) :
    (x ::ₘ y ::ₘ s).esymm (j+2) =
      s.esymm (j+2)+(x+y)*s.esymm (j+1)+(x*y)*s.esymm j := by
  rw [show j+2 = (j+1)+1 by omega, esymm_cons, esymm_cons, esymm_cons]
  ring

/-- Moving two positive coordinates closer at fixed sum increases the elementary quotient. -/
theorem quotient_pair_balancing (s : Multiset ℝ) (hs : ∀ z ∈ s, 0 < z)
    {x y u v : ℝ} (hx : 0 < x) (hy : 0 < y) (hu : 0 < u) (hv : 0 < v)
    (hsum : x+y = u+v) (hprod : x*y ≤ u*v) {k : ℕ} (hk : 1 ≤ k)
    (hc : k ≤ s.card+2) :
    symmetricQuotient (x ::ₘ y ::ₘ s) k ≤ symmetricQuotient (u ::ₘ v ::ₘ s) k := by
  have hd1 : 0 < (x ::ₘ y ::ₘ s).esymm k := esymm_pos _ (by
    intro z hz
    rcases Multiset.mem_cons.mp hz with rfl | hz
    · exact hx
    rcases Multiset.mem_cons.mp hz with rfl | hz
    · exact hy
    exact hs z hz) k (by simpa using hc)
  have hd2 : 0 < (u ::ₘ v ::ₘ s).esymm k := esymm_pos _ (by
    intro z hz
    rcases Multiset.mem_cons.mp hz with rfl | hz
    · exact hu
    rcases Multiset.mem_cons.mp hz with rfl | hz
    · exact hv
    exact hs z hz) k (by simpa using hc)
  by_cases hk1 : k = 1
  · subst k
    have hden : (x ::ₘ y ::ₘ s).esymm 1 = (u ::ₘ v ::ₘ s).esymm 1 := by
      simp only [esymm_cons, Multiset.esymm_zero, mul_one]
      linarith
    dsimp [symmetricQuotient]
    rw [hden]
    apply div_le_div_of_nonneg_right _ hd2.le
    rw [show 2 = 0+2 by omega, esymm_pair, esymm_pair]
    simp only [zero_add, Multiset.esymm_zero, mul_one]
    rw [hsum]
    linarith
  · obtain ⟨j,hj⟩ := Nat.exists_eq_add_of_le (show 2 ≤ k by omega)
    have he : k = j+2 := by omega
    subst k
    rw [he] at hd1 hd2 ⊢
    dsimp [symmetricQuotient]
    apply (div_le_div_iff₀ hd1 hd2).mpr
    rw [show j+2+1 = (j+1)+2 by omega, esymm_pair, esymm_pair, esymm_pair, esymm_pair]
    simp only [Nat.add_assoc]
    rw [hsum]
    have hgap : 0 ≤ s.esymm (j+1)*s.esymm (j+2)-s.esymm j*s.esymm (j+3)+
        (u+v)*((s.esymm (j+1))^2-s.esymm j*s.esymm (j+2)) := by
      have h1 := sub_nonneg.mpr (esymm_cross_adjacent s hs j)
      have h2 := sub_nonneg.mpr (esymm_logconcave s hs j)
      exact add_nonneg h1 (mul_nonneg (by positivity) h2)
    have hmul := mul_nonneg (sub_nonneg.mpr hprod) hgap
    nlinarith only [hmul]

end SpectralComparison
