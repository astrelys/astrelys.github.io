import SpectralComparison.GramBounds

/-! Positive Gram whitening and quantitative principal-block inverse control. -/
noncomputable section
open Matrix
open scoped MatrixOrder
namespace SpectralComparison

/-- A positive definite matrix has a symmetric positive definite inverse square root. -/
theorem exists_inverse_sqrt {p : Type*} [Fintype p] [DecidableEq p]
    {A : Matrix p p ℝ} (hA : A.PosDef) :
    ∃ B : Matrix p p ℝ, B.PosDef ∧ B*A*B=1 ∧ B*B=A⁻¹ := by
  let S := CFC.sqrt A
  have hS : S.PosDef := (CFC.sqrt_nonneg A).posSemidef.posDef_iff_isUnit.mpr
    ((CFC.isUnit_sqrt_iff A hA.posSemidef.nonneg).mpr hA.isUnit)
  have hSS : S*S=A := CFC.sqrt_mul_sqrt_self A hA.posSemidef.nonneg
  have hsi : S⁻¹*S=1 := Matrix.nonsing_inv_mul S (isUnit_iff_ne_zero.mpr hS.det_pos.ne')
  have his : S*S⁻¹=1 := Matrix.mul_nonsing_inv S (isUnit_iff_ne_zero.mpr hS.det_pos.ne')
  refine ⟨S⁻¹,hS.inv,?_,?_⟩
  · rw [← hSS, ← Matrix.mul_assoc, hsi, Matrix.one_mul, his]
  · rw [← hSS, Matrix.mul_inv_rev]

/-- Whitening constructs an actual matrix with orthonormal columns and its exact projection. -/
theorem exists_gram_whitening {n p : Type*} [Fintype n] [Fintype p] [DecidableEq p]
    (G : Matrix n p ℝ) (hG : (Gᴴ*G).PosDef) :
    ∃ V : Matrix n p ℝ, Vᴴ*V=1 ∧ V*Vᴴ=G*(Gᴴ*G)⁻¹*Gᴴ := by
  obtain ⟨B,hB,hBAB,hBB⟩ := exists_inverse_sqrt hG
  refine ⟨G*B,?_,?_⟩
  · simpa only [Matrix.conjTranspose_mul, hB.isHermitian.eq, Matrix.mul_assoc] using hBAB
  · simp only [Matrix.conjTranspose_mul, hB.isHermitian.eq]
    calc
      G*B*(B*Gᴴ) = G*(B*B)*Gᴴ := by simp only [Matrix.mul_assoc]
      _ = _ := by rw [hBB]

/-- A scalar multiple of the identity has its expected inverse. -/
theorem inverse_scalar_identity {p : Type*} [Fintype p] [DecidableEq p]
    {a : ℝ} (ha : a≠0) : (a • (1 : Matrix p p ℝ))⁻¹ = a⁻¹ • (1 : Matrix p p ℝ) := by
  apply Matrix.inv_eq_right_inv
  simp [smul_smul, ha]

/-- The whitened projection is bounded above by the unnormalized Gram matrix. -/
theorem whitened_projection_upper {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq p] (G V : Matrix n p ℝ) (hG : (Gᴴ*G).PosDef)
    (hV : V*Vᴴ=G*(Gᴴ*G)⁻¹*Gᴴ) {a : ℝ} (ha : 0<a)
    (hgap : (Gᴴ*G-a • (1 : Matrix p p ℝ)).PosSemidef) :
    (a⁻¹ • (G*Gᴴ)-V*Vᴴ).PosSemidef := by
  have h := posDef_inverse_order (Matrix.PosDef.one.smul ha) hG hgap
  rw [inverse_scalar_identity ha.ne'] at h
  have hh := h.mul_mul_conjTranspose_same G
  simpa only [Matrix.mul_sub, Matrix.sub_mul, Matrix.mul_smul, Matrix.smul_mul,
    Matrix.mul_one, ← hV] using hh

/-- Nonzero inverse trace rules out the singular PSD branch of totalized inversion. -/
theorem posDef_of_pos_inverse_trace {n : Type*} [Fintype n] [DecidableEq n]
    {A : Matrix n n ℝ} (hA : A.PosSemidef) (ht : 0 < A⁻¹.trace) : A.PosDef := by
  apply hA.posDef_iff_isUnit.mpr
  rw [Matrix.isUnit_iff_isUnit_det]
  by_contra h
  rw [Matrix.nonsing_inv_apply_not_isUnit A h, Matrix.trace_zero] at ht
  exact (lt_irrefl 0) ht

/-- The inverse of a nonzero real scaling of a positive definite matrix. -/
theorem inverse_positive_smul {n : Type*} [Fintype n] [DecidableEq n]
    {A : Matrix n n ℝ} (hA : A.PosDef) {a : ℝ} (ha : a≠0) :
    (a • A)⁻¹=a⁻¹ • A⁻¹ := by
  apply Matrix.inv_eq_right_inv
  simp only [Matrix.smul_mul, Matrix.mul_smul, smul_smul,
    Matrix.mul_nonsing_inv A (isUnit_iff_ne_zero.mpr hA.det_pos.ne'), inv_mul_cancel₀ ha, one_smul]

/-- Quantitative inverse trace after whitening, for any nonsingular row block. -/
theorem whitening_inverse_trace_lower {n p j : Type*} [Fintype n] [Fintype p]
    [Fintype j] [DecidableEq p] [DecidableEq j]
    (G V : Matrix n p ℝ) (hG : (Gᴴ*G).PosDef)
    (hV : V*Vᴴ=G*(Gᴴ*G)⁻¹*Gᴴ) {a L : ℝ} (ha : 0<a)
    (hgap : (Gᴴ*G-a • (1 : Matrix p p ℝ)).PosSemidef)
    (e : j → n) (hblock : ((V*Vᴴ).submatrix e e).PosDef)
    (htrace : L ≤ ((G*Gᴴ).submatrix e e)⁻¹.trace) :
    a*L ≤ ((V*Vᴴ).submatrix e e)⁻¹.trace := by
  let A := (V*Vᴴ).submatrix e e
  let Q := (G*Gᴴ).submatrix e e
  have hg : (a⁻¹ • Q-A).PosSemidef := by
    have he : (a⁻¹ • (G*Gᴴ)-V*Vᴴ).submatrix e e = a⁻¹ • Q-A := by
      ext i k
      rfl
    rw [← he]
    exact (whitened_projection_upper G V hG hV ha hgap).submatrix e
  have hscaled : (a⁻¹ • Q).PosDef := by
    convert hblock.add_posSemidef hg using 1; dsimp [A]; abel
  have hQ : Q.PosDef := by
    have hh := hscaled.smul ha
    simpa only [smul_smul, mul_inv_cancel₀ ha.ne', one_smul] using hh
  have h := inverse_trace_order hblock hscaled hg
  rw [inverse_positive_smul hQ (inv_ne_zero ha.ne'), inv_inv, Matrix.trace_smul] at h
  exact (mul_le_mul_of_nonneg_left htrace ha.le).trans h

end SpectralComparison
