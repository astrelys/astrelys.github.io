import SpectralComparison.PrescribedSpectrum
import SpectralComparison.WorstOrientation

/-! Any original selection leaves enough coordinates in an embedded prefix. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- A k-coordinate selection misses at least t coordinates in every embedded (k+t)-prefix. -/
theorem embedded_unselected_card {n : Type*} [Fintype n] [DecidableEq n]
    {k t : ℕ} (f : Fin (k+t) → n) (hf : Function.Injective f)
    (I : Finset n) (hI : I.card=k) :
    t≤(Finset.univ.filter (fun i => f i∉I)).card := by
  classical
  let A := Finset.univ.filter (fun i => f i∈I)
  let g : A → I := fun i => ⟨f i.val,(Finset.mem_filter.mp i.property).2⟩
  have hg : Function.Injective g := by
    intro a b hab
    exact Subtype.ext (hf (congrArg Subtype.val hab))
  have hc := Fintype.card_le_of_injective g hg
  simp only [Fintype.card_coe,hI] at hc
  have he : Finset.univ.filter (fun i => f i∉I)=(Finset.univ : Finset (Fin (k+t))) \ A := by
    ext i; simp [A]
  rw [he]
  simp only [Finset.card_sdiff,Finset.inter_univ,Finset.card_univ,Fintype.card_fin]
  omega

/-- A uniform t-block precision bound in one embedded prefix applies to every original k-selection. -/
theorem residual_lower_of_embedded_precision {n : Type*} [Fintype n] [DecidableEq n]
    {k t : ℕ} {K : Matrix n n ℝ} (hK : K.PosDef)
    (f : Fin (k+t) → n) (hf : Function.Injective f) {C : ℝ}
    (hb : ∀ J : Finset (Fin (k+t)), J.card=t →
      C≤(((K⁻¹).submatrix f f).submatrix (fun i : J => (i:Fin (k+t))) (fun i : J => (i:Fin (k+t))))⁻¹.trace)
    (I : Finset n) (hI : I.card=k) : C≤residualTrace K I := by
  classical
  obtain ⟨J,hJS,hJ⟩ := Finset.exists_subset_card_eq (embedded_unselected_card f hf I hI)
  let g : J → ↥(Finset.univ \ I) := fun j => ⟨f j.val,by
    have h := Finset.mem_filter.mp (hJS j.property)
    exact Finset.mem_sdiff.mpr ⟨Finset.mem_univ _,h.2⟩⟩
  have hg : Function.Injective g := by intro a b hab; exact Subtype.ext (hf (congrArg Subtype.val hab))
  have h := inverse_trace_submatrix_le (principal_posDef hK.inv (Finset.univ \ I)) g hg
  rw [nystrom_trace_inverse_complement hK I]
  exact (hb J hJ).trans h

end SpectralComparison
