import SpectralComparison.RobustNets

/-! One Gaussian realization simultaneously controls every kernel row pair and all row ranks. -/
noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

/-- Every row subset no larger than the column dimension is independent, simultaneously almost surely. -/
theorem gaussian_all_row_grams_posDef_ae {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {N p : ℕ}
    (X : Ω → Matrix (Fin N) (Fin p) ℝ)
    (hX : ∀ a : Fin N × Fin p, HasLaw (fun ω => X ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin N × Fin p => fun ω => X ω a.1 a.2) μ) :
    ∀ᵐ ω ∂μ, ∀ J : Finset (Fin N), J.card≤p →
      ((X ω).submatrix (fun i : J => (i:Fin N)) id *
        ((X ω).submatrix (fun i : J => (i:Fin N)) id)ᴴ).PosDef := by
  classical
  apply ae_all_iff.mpr
  intro J
  by_cases hJ : J.card≤p
  · obtain ⟨emb⟩ := Function.Embedding.nonempty_of_card_le
      (show Fintype.card J≤Fintype.card (Fin p) by simpa using hJ)
    let W := fun ω => (X ω).submatrix (fun i : J => (i:Fin N)) id
    have hw (a : J × Fin p) : HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ := hX (a.1,a.2)
    have hi : iIndepFun (fun a : J × Fin p => fun ω => W ω a.1 a.2) μ :=
      hind.precomp (Subtype.val_injective.prodMap Function.injective_id)
    filter_upwards [gaussian_gram_posDef_ae emb W hw hi] with ω hω
    exact fun _ => hω
  · exact Filter.Eventually.of_forall (fun _ h => False.elim (hJ h))

/-- The robust-frame exceptional-event estimates sum to less than one. -/
theorem robust_good_event_budget {k : ℕ} (hk : 16≤k) :
    Real.exp (-3*(k:ℝ))+(1/16:ℝ)^k+2*Real.exp (-4*(k:ℝ))<1 := by
  have hkr : (16:ℝ)≤k := by exact_mod_cast hk
  have hsmall : Real.exp (-3*(k:ℝ))≤1/2 := by
    have he : Real.exp (-1:ℝ)<1/2 := by
      rw [Real.exp_neg]
      exact (inv_lt_comm₀ (by positivity) (by norm_num)).mpr (by simpa using Real.exp_one_gt_two)
    exact (Real.exp_le_exp.mpr (by linarith)).trans he.le
  have hlast : Real.exp (-4*(k:ℝ))<1/8 := by
    have he : (8:ℝ)<Real.exp 3 := by
      have h := pow_lt_pow_left₀ Real.exp_one_gt_two (by norm_num : (0:ℝ)≤2) (by norm_num : (3:ℕ)≠0)
      have heq : Real.exp (3:ℝ)=(Real.exp 1)^3 := by simp [← Real.exp_nat_mul]
      rw [heq]
      norm_num at h ⊢
      exact h
    have hh : Real.exp (-3:ℝ)<1/8 := by
      rw [Real.exp_neg]
      exact (inv_lt_comm₀ (by positivity) (by norm_num)).mpr (by simpa using he)
    exact (Real.exp_le_exp.mpr (by linarith)).trans_lt hh
  have hmid : (1/16:ℝ)^k≤1/16 := by
    simpa using pow_le_pow_of_le_one (by norm_num : (0:ℝ)≤1/16) (by norm_num : (1/16:ℝ)≤1) (show 1≤k by omega)
  linarith

/-- The full set of large-k Gaussian requirements holds for a single outcome. -/
theorem gaussian_exists_robust_realization {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {k q : ℕ} (hk : 16≤k) (hq : 2*q≤k)
    (X : Ω → Matrix (Fin (2*k)) (Fin (k-q)) ℝ)
    (hX : ∀ a : Fin (2*k) × Fin (k-q), HasLaw (fun ω => X ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin (2*k) × Fin (k-q) => fun ω => X ω a.1 a.2) μ)
    (hm : ∀ a : Fin (2*k) × Fin (k-q), Measurable (fun ω => X ω a.1 a.2)) :
    ∃ ω, (∀ x : EuclideanSpace ℝ (Fin (k-q)), ‖x‖=1 →
      Real.sqrt k/1000000000000≤‖(X ω).toEuclideanLin x‖) ∧
      (∀ J : Finset (Fin (2*k)), J.card≤k-q →
        ((X ω).submatrix (fun i : J => (i:Fin (2*k))) id *
          ((X ω).submatrix (fun i : J => (i:Fin (2*k))) id)ᴴ).PosDef) ∧
      ∀ H L : Finset (Fin (2*k)), Disjoint H L → 4*H.card≤k →
        H.card+L.card≤k → k-q-H.card≤L.card →
        (k:ℝ)/(4000*((q:ℝ)+Real.sqrt k)) <
          kernelInverseTrace ((X ω).submatrix (fun i : H => (i:Fin (2*k))) id)
            ((X ω).submatrix (fun i : L => (i:Fin (2*k))) id) := by
  obtain ⟨s,hs,hcard,hnet,hsmall⟩ := exists_gaussian_small_ball_net_scale (show k-q≤k by omega)
    (show 4*k≤3*(2*k) by omega) X hX hind hm
  let A := {ω | 10*Real.sqrt k < ‖(X ω).toEuclideanLin.toContinuousLinearMap‖}
  let B := {ω | ∃ v ∈ s, ‖(X ω).toEuclideanLin v‖^2≤4*(k:ℝ)/(1000000000000:ℝ)^2}
  let C := {ω | ∃ H L : Finset (Fin (2*k)), Disjoint H L ∧ 4*H.card≤k ∧ H.card+L.card≤k ∧
    k-q-H.card≤L.card ∧ kernelInverseTrace ((X ω).submatrix (fun i : H => (i:Fin (2*k))) id)
      ((X ω).submatrix (fun i : L => (i:Fin (2*k))) id)≤(k:ℝ)/(4000*((q:ℝ)+Real.sqrt k))}
  let D := {ω | ¬∀ J : Finset (Fin (2*k)), J.card≤k-q →
    ((X ω).submatrix (fun i : J => (i:Fin (2*k))) id *
      ((X ω).submatrix (fun i : J => (i:Fin (2*k))) id)ᴴ).PosDef}
  have hA : μ.real A≤Real.exp (-3*(k:ℝ)) := gaussian_opNorm_tail_scale (by omega) (by omega) X hX hind hm
  have hB : μ.real B≤(1/16:ℝ)^k := hsmall
  have hC : μ.real C≤2*Real.exp (-4*(k:ℝ)) := gaussian_all_robust_pairs_tail hk hq X hX hind
  have hD : μ.real D=0 := by
    have hd : μ D=0 := measure_eq_zero_iff_ae_notMem.mpr (by
      filter_upwards [gaussian_all_row_grams_posDef_ae X hX hind] with ω hω
      exact fun hn => hn hω)
    simp [Measure.real,hd]
  have hbad : μ.real (((A ∪ B) ∪ C) ∪ D)<1 := by
    calc
      _ ≤ μ.real ((A ∪ B) ∪ C)+μ.real D := measureReal_union_le _ _
      _ ≤ μ.real (A ∪ B)+μ.real C+μ.real D := by gcongr; exact measureReal_union_le _ _
      _ ≤ μ.real A+μ.real B+μ.real C+μ.real D := by gcongr; exact measureReal_union_le _ _
      _ ≤ Real.exp (-3*(k:ℝ))+(1/16:ℝ)^k+2*Real.exp (-4*(k:ℝ)) := by linarith
      _ < 1 := robust_good_event_budget hk
  have hex : ∃ ω, ω ∉ ((A ∪ B) ∪ C) ∪ D := by
    by_contra! h
    have he : ((A ∪ B) ∪ C) ∪ D=Set.univ := Set.eq_univ_of_forall h
    simp [he] at hbad
  obtain ⟨ω,hω⟩ := hex
  have hupper : ‖(X ω).toEuclideanLin.toContinuousLinearMap‖≤10*Real.sqrt k :=
    le_of_not_gt (fun h => hω (Or.inl (Or.inl (Or.inl h))))
  have hlower : ∀ v ∈ s, 4*(k:ℝ)/(1000000000000:ℝ)^2<‖(X ω).toEuclideanLin v‖^2 := by
    intro v hv
    exact lt_of_not_ge (fun h => hω (Or.inl (Or.inl (Or.inr ⟨v,hv,h⟩))))
  refine ⟨ω,gaussian_net_lower_singular_scale (X ω) s hnet hupper hlower,?_,?_⟩
  · by_contra hn
    exact hω (Or.inr hn)
  · intro H L hdis hh hl hd
    exact lt_of_not_ge (fun ht => hω (Or.inl (Or.inr ⟨H,L,hdis,hh,hl,hd,ht⟩)))

/-- Deterministic existence of a full-spark matrix with simultaneous kernel and Gram estimates. -/
theorem exists_robust_good_matrix {k q : ℕ} (hk : 16≤k) (hq : 2*q≤k) :
    ∃ X : Matrix (Fin (2*k)) (Fin (k-q)) ℝ,
      (Xᴴ*X).PosDef ∧
      (Xᴴ*X-((k:ℝ)/(1000000000000:ℝ)^2) • (1 : Matrix (Fin (k-q)) (Fin (k-q)) ℝ)).PosSemidef ∧
      (∀ J : Finset (Fin (2*k)), J.card≤k-q →
        (X.submatrix (fun i : J => (i:Fin (2*k))) id *
          (X.submatrix (fun i : J => (i:Fin (2*k))) id)ᴴ).PosDef) ∧
      ∀ H L : Finset (Fin (2*k)), Disjoint H L → 4*H.card≤k → H.card+L.card≤k →
        k-q-H.card≤L.card → (k:ℝ)/(4000*((q:ℝ)+Real.sqrt k)) <
        kernelInverseTrace (X.submatrix (fun i : H => (i:Fin (2*k))) id)
          (X.submatrix (fun i : L => (i:Fin (2*k))) id) := by
  let μ : Measure (Fin (2*k) × Fin (k-q) → ℝ) := Measure.pi (fun _ => gaussianReal 0 1)
  let X := fun (ω : Fin (2*k) × Fin (k-q) → ℝ) => Matrix.of (fun i j => ω (i,j))
  have hid : HasLaw id μ μ := HasLaw.id
  have hX := gaussian_product_entry_hasLaw id hid
  have hi := gaussian_product_independent id hid
  have hm (a : Fin (2*k) × Fin (k-q)) : Measurable (fun ω => X ω a.1 a.2) := measurable_pi_apply a
  obtain ⟨ω,hnorm,hrows,hpairs⟩ := gaussian_exists_robust_realization hk hq X hX hi hm
  have ha : 0<Real.sqrt (k:ℝ)/1000000000000 := by positivity
  have hs := gram_posDef_of_unit_norm (X ω) ha hnorm
  have hg := gram_lower_of_unit_norm (X ω) ha.le hnorm
  have he : (Real.sqrt (k:ℝ)/1000000000000)^2=(k:ℝ)/(1000000000000:ℝ)^2 := by
    rw [div_pow,Real.sq_sqrt (Nat.cast_nonneg k)]
  rw [he] at hg
  exact ⟨X ω,hs,hg,hrows,hpairs⟩

end SpectralComparison
