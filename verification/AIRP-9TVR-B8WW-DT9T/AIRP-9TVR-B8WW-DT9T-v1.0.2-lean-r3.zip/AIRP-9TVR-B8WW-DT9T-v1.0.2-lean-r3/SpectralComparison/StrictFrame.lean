import SpectralComparison.EqualCostFrame

noncomputable section
open Matrix Finset
namespace SpectralComparison

/-- The manuscript's explicit radical solves the required positive mass equation. -/
theorem strict_frame_mass {k m : ℕ} (hk : 2≤k) (hm : 2≤m) :
    let c := strictH k m-((k:ℝ)+m)
    0<c ∧ (m:ℝ)/(c+2*m)+(k:ℝ)/(c+2)=1 := by
  let c := strictH k m-((k:ℝ)+m)
  have hc : 0<c := (strict_radical_gaps hk hm).2
  refine ⟨hc,?_⟩
  change (m:ℝ)/(c+2*m)+(k:ℝ)/(c+2)=1
  have hk0 : 0<(k:ℝ) := by exact_mod_cast (by omega : 0<k)
  have hm0 : 0<(m:ℝ) := by exact_mod_cast (by omega : 0<m)
  have hd1 : c+2*m≠0 := ne_of_gt (by positivity)
  have hd2 : c+2≠0 := ne_of_gt (by positivity)
  have hs := Real.sq_sqrt (show 0≤((k:ℝ)+m-2)^2+4*(k:ℝ)*m by positivity)
  have he : c^2+((m:ℝ)-k+2)*c+2*m-2*(k:ℝ)*m=0 := by dsimp [c,strictH]; nlinarith
  field_simp
  nlinarith

/-- An actual real (k+m)-by-k Parseval frame attains the exact inverse-basis cost H. -/
theorem exists_strict_frame {k m : ℕ} (hk : 2≤k) (hm : 2≤m) :
    ∃ Q : Matrix (Fin (k+m)) (Fin k) ℝ,Qᴴ*Q=1 ∧
      ∀ I : Finset (Fin (k+m)),I.card=k → IsUnit (principal (Q*Qᴴ) I) →
        strictH k m≤(principal (Q*Qᴴ) I)⁻¹.trace := by
  let r : Option (Fin k) → ℕ := fun i => i.elim m (fun _ => 1)
  let c := strictH k m-((k:ℝ)+m)
  have hr : ∀ i,0<r i := by intro i; cases i <;> simp [r]; omega
  have hcard : Fintype.card (Option (Fin k))=k+1 := by simp
  have hmss : (∑ i,(r i:ℝ)/(c+2*r i))=1 := by
    have h := (strict_frame_mass hk hm).2
    simpa [r,c,Fintype.sum_option,div_eq_mul_inv] using h
  obtain ⟨Q,hQ,hb⟩ := exists_equal_cost_frame hcard r hr (strict_frame_mass hk hm).1 hmss
  have hsum : (∑ i,(r i:ℝ))=(k:ℝ)+m := by simp [r,Fintype.sum_option,add_comm]
  have hb' : ∀ I : Finset (Σ i,Fin (r i)),I.card=k → IsUnit (principal (Q*Qᴴ) I) →
      strictH k m≤(principal (Q*Qᴴ) I)⁻¹.trace := by
    intro I hI hu
    rw [hb I hI hu,hsum]
    linarith
  let e : Fin (k+m) ≃ (Σ i,Fin (r i)) := Fintype.equivOfCardEq (by simp [r,Fintype.card_sigma,Fintype.sum_option,add_comm])
  exact reindex_frame_control Q hQ hb' e

/-- D.5 for the literal finite two-level spectrum, derived from the exact frame and scalar regularization. -/
theorem strict_finite_frame_bound {k m : ℕ} (hk : 2≤k) (hm : 2≤m)
    {L a : ℝ} (ha : 0<a) (ha1 : a≤1) (hL : 1≤L) :
    a*strictN k m-(strictH k m)^2/L≤
      worstError (fun i => L*twoLevelSpectrum k m (a/L) i) k := by
  have hLp : 0<L := lt_of_lt_of_le (by norm_num) hL
  have hε : 0<a/L := div_pos ha hLp
  have hε1 : a/L≤1 := (div_le_one hLp).mpr (ha1.trans hL)
  have hH : 0<strictH k m := by
    have hg := (strict_constants hk hm).1
    dsimp [strictGap] at hg
    have hk0 : (0:ℝ)≤k := Nat.cast_nonneg k
    linarith
  obtain ⟨Q,hQ,hb⟩ := exists_strict_frame hk hm
  have hw := two_level_worst_lower_of_frame (by omega) Q hQ hH hb hε hε1
  have hp : ∀ i,0<twoLevelSpectrum k m (a/L) i := by intro i; dsimp [twoLevelSpectrum]; split <;> positivity
  rw [worstError_smul _ hp hLp (by simp; omega)]
  have hbnd := mul_le_mul_of_nonneg_left hw hLp.le
  have hfrac : strictH k m-(a/L)*(strictH k m)^2≤strictH k m/(1+(a/L)*strictH k m) := by
    apply (le_div_iff₀ (by positivity)).mpr
    nlinarith [sq_nonneg ((a/L)*strictH k m),mul_nonneg (sq_nonneg ((a/L)*strictH k m)) hH.le]
  have he : L*(a/L)=a := by field_simp
  have hN : (m:ℝ)-k+strictH k m=strictN k m := by dsimp [strictN,strictGap]; ring
  have hmid : a*strictN k m-a^2*(strictH k m)^2/L≤
      L*((a/L)*((m:ℝ)-k+strictH k m/(1+(a/L)*strictH k m))) := by
    rw [← mul_assoc,he]
    have hx := mul_le_mul_of_nonneg_left hfrac ha.le
    rw [← hN]
    convert add_le_add_left hx (a*((m:ℝ)-k)) using 1 <;> ring
  have hsq : a^2≤1 := by nlinarith
  have hlast := mul_le_mul_of_nonneg_right hsq (div_nonneg (sq_nonneg (strictH k m)) hLp.le)
  have hfinal : a*strictN k m-(strictH k m)^2/L≤a*strictN k m-a^2*(strictH k m)^2/L := by
    convert sub_le_sub_left hlast (a*strictN k m) using 1 <;> ring
  exact hfinal.trans (hmid.trans hbnd)

end SpectralComparison
