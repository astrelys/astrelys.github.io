import SpectralComparison.RobustLargeFrame

/-! Complete one fixed Parseval frame to a square orthogonal coordinate system. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- An orthonormal column family admits an orthonormal complement of the specified dimension. -/
theorem exists_orthogonal_frame_completion {g r h : Type*} [Fintype g] [Fintype r] [Fintype h]
    [DecidableEq g] [DecidableEq r] [DecidableEq h]
    (Q : Matrix g r ℝ) (hQ : Qᴴ*Q=1) (hdim : Fintype.card h+Fintype.card r=Fintype.card g) :
    ∃ R : Matrix g h ℝ,Rᴴ*R=1 ∧ Qᴴ*R=0 ∧ Q*Qᴴ+R*Rᴴ=1 ∧
      (Matrix.fromCols Q R)ᴴ*Matrix.fromCols Q R=1 ∧
      Matrix.fromCols Q R*(Matrix.fromCols Q R)ᴴ=1 := by
  have hpd : (Qᴴ*(Qᴴ)ᴴ).PosDef := by rw [Matrix.conjTranspose_conjTranspose,hQ]; exact Matrix.PosDef.one
  obtain ⟨R,hR,hproj⟩ := exists_kernel_basis_matrix_of_dimension (d:=h) Qᴴ hpd hdim
  have hQR := kernel_columns_annihilated Qᴴ hpd R hR hproj
  have hRQ : Rᴴ*Q=0 := by simpa only [Matrix.conjTranspose_mul,Matrix.conjTranspose_conjTranspose,Matrix.conjTranspose_zero] using congrArg Matrix.conjTranspose hQR
  have hsum : Q*Qᴴ+R*Rᴴ=1 := by
    rw [hproj,Matrix.conjTranspose_conjTranspose,hQ,inv_one,Matrix.mul_one]
    abel
  refine ⟨R,hR,hQR,hsum,?_,?_⟩
  · rw [Matrix.conjTranspose_fromCols_eq_fromRows_conjTranspose,Matrix.fromRows_mul_fromCols,hQ,hQR,hRQ,hR]
    exact Matrix.fromBlocks_one
  · rw [Matrix.conjTranspose_fromCols_eq_fromRows_conjTranspose,Matrix.fromCols_mul_fromRows,hsum]

/-- Spectral synthesis through a concatenated column family splits into its two covariance terms. -/
theorem fromCols_spectral_synthesis {n r h : Type*} [Fintype r] [Fintype h]
    [DecidableEq r] [DecidableEq h] (Q : Matrix n r ℝ) (R : Matrix n h ℝ)
    (a : r → ℝ) (b : h → ℝ) :
    Matrix.fromCols Q R*Matrix.diagonal (Sum.elim a b)*(Matrix.fromCols Q R)ᴴ=
      Q*Matrix.diagonal a*Qᴴ+R*Matrix.diagonal b*Rᴴ := by
  have hd : Matrix.diagonal (Sum.elim a b)=Matrix.fromBlocks (Matrix.diagonal a) 0 0 (Matrix.diagonal b) := by
    ext i j
    cases i <;> cases j <;> simp [Matrix.diagonal_apply]
  rw [hd,Matrix.conjTranspose_fromCols_eq_fromRows_conjTranspose,Matrix.fromCols_mul_fromBlocks]
  simp only [Matrix.mul_zero,zero_add,add_zero,Matrix.fromCols_mul_fromRows]

end SpectralComparison
