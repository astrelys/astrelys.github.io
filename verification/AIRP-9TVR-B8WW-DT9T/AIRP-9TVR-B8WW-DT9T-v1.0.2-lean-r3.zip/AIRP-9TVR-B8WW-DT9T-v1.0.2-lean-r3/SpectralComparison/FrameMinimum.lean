import SpectralComparison.BalancedFrame
import SpectralComparison.Ridge
import Mathlib.Data.EReal.Basic

/-! Literal square-row-basis minima and the frame supremum. Singular bases are omitted. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Inverse row-Gram trace is exactly squared Frobenius norm of the square inverse. -/
theorem inverse_gram_trace_frobenius {j : Type*} [Fintype j] [DecidableEq j]
    (A : Matrix j j ℝ) : (A*Aᴴ)⁻¹.trace=∑ i, ∑ l, (A⁻¹ i l)^2 := by
  rw [Matrix.mul_inv_rev,← Matrix.conjTranspose_nonsing_inv,Matrix.trace_mul_comm]
  exact frobenius_trace_formula A⁻¹

/-- Choosing any order on a square row subset gives precisely the paper's determinant and norm. -/
theorem square_row_basis_semantics {n d : ℕ} (Q : Matrix (Fin n) (Fin d) ℝ)
    (J : Finset (Fin n)) (e : Fin d ≃ J) :
    let A := Q.submatrix (fun i => ((e i : J):Fin n)) id
    (IsUnit ((Q*Qᴴ).submatrix (fun i : J => (i:Fin n)) (fun i : J => (i:Fin n))) ↔ A.det≠0) ∧
    ((Q*Qᴴ).submatrix (fun i : J => (i:Fin n)) (fun i : J => (i:Fin n)))⁻¹.trace=
      ∑ i, ∑ l, (A⁻¹ i l)^2 := by
  let W := Q.submatrix (fun i : J => (i:Fin n)) id
  have hg : (Q*Qᴴ).submatrix (fun i : J => (i:Fin n)) (fun i : J => (i:Fin n))=W*Wᴴ := by
    ext i l; simp [W,Matrix.mul_apply]
  let A := W.submatrix e id
  have hA : A*Aᴴ=(W*Wᴴ).submatrix e e := by
    ext i l; simp [A,Matrix.mul_apply]
  change (IsUnit _ ↔ A.det≠0) ∧ _=∑ i, ∑ l, (A⁻¹ i l)^2
  rw [hg]
  constructor
  · rw [← Matrix.isUnit_submatrix_equiv e e,← hA,Matrix.isUnit_iff_isUnit_det,Matrix.det_mul,Matrix.det_conjTranspose]
    simp
  · rw [← inverse_gram_trace_reindex W e]
    exact inverse_gram_trace_frobenius A

/-- The original k^(3/2) notation equals k*sqrt(k). -/
theorem balanced_power_three_halves (k : ℕ) :
    (k:ℝ)^(3/2:ℝ)=(k:ℝ)*Real.sqrt k := by
  rw [show (3/2:ℝ)=1+1/2 by ring,Real.rpow_add' (by positivity) (by norm_num),Real.rpow_one,Real.sqrt_eq_rpow]

/-- Costs of exactly d-row nonsingular bases; the use of row Gram avoids choosing a row order. -/
def frameBasisCosts {n d : ℕ} (Q : Matrix (Fin n) (Fin d) ℝ) : Set ℝ :=
  {x | ∃ J : Finset (Fin n), J.card=d ∧
    IsUnit ((Q*Qᴴ).submatrix (fun i : J => (i:Fin n)) (fun i : J => (i:Fin n))) ∧
    x=((Q*Qᴴ).submatrix (fun i : J => (i:Fin n)) (fun i : J => (i:Fin n)))⁻¹.trace}

/-- The paper's h(Q), with its actual finite minimum proved below. -/
def frameBasisMinimum {n d : ℕ} (Q : Matrix (Fin n) (Fin d) ℝ) : ℝ := sInf (frameBasisCosts Q)

/-- The supremum in the extended reals, so no unproved boundedness premise is implicit. -/
def frameBasisSupremum (n d : ℕ) : EReal :=
  ⨆ (Q : Matrix (Fin n) (Fin d) ℝ) (_ : Qᴴ*Q=1), (frameBasisMinimum Q : EReal)

/-- A Parseval frame has at least one nonsingular square row basis. -/
theorem parseval_exists_row_basis {n d : ℕ} (Q : Matrix (Fin n) (Fin d) ℝ)
    (hQ : Qᴴ*Q=1) : ∃ J : Finset (Fin n), J.card=d ∧
      IsUnit ((Q*Qᴴ).submatrix (fun i : J => (i:Fin n)) (fun i : J => (i:Fin n))) := by
  classical
  have hsur : Function.Surjective Q.vecMul := by
    intro x
    refine ⟨x ᵥ* Qᴴ,?_⟩
    change (x ᵥ* Qᴴ) ᵥ* Q=x
    rw [Matrix.vecMul_vecMul,hQ,Matrix.vecMul_one]
  have hspan : Submodule.span ℝ (Set.range Q.row)=⊤ := by
    rw [← range_vecMulLinear]
    exact LinearMap.range_eq_top.mpr hsur
  obtain ⟨κ,a,ha,hsp,hi⟩ := exists_linearIndependent' ℝ Q.row
  let : Fintype κ := Fintype.ofInjective a ha
  let b := Module.Basis.mk hi (by rw [hsp,hspan])
  have hc : Fintype.card κ=d := by
    have hh := Module.finrank_eq_card_basis b
    simpa using hh.symm
  let J := Finset.univ.image a
  let e : κ ≃ J := Equiv.ofBijective (fun x => (⟨a x,Finset.mem_image.mpr ⟨x,Finset.mem_univ _,rfl⟩⟩:J)) (by
    constructor
    · intro x y h; exact ha (congrArg Subtype.val h)
    · intro y; obtain ⟨x,_,hx⟩ := Finset.mem_image.mp y.property; exact ⟨x,Subtype.ext hx⟩)
  have hj : J.card=d := by simpa [J,Finset.card_image_of_injective _ ha] using hc
  let A := Q.submatrix (fun i : J => (i:Fin n)) id
  have haeq : A.row=(Q.row ∘ a) ∘ e.symm := by
    funext i
    have hh := congrArg Subtype.val (e.apply_symm_apply i)
    exact congrArg Q.row hh.symm
  have hai : Function.Injective A.vecMul := Matrix.vecMul_injective_iff.mpr (haeq ▸ hi.comp e.symm e.symm.injective)
  have hp := Matrix.PosDef.mul_conjTranspose_self A hai
  have he : (Q*Qᴴ).submatrix (fun i : J => (i:Fin n)) (fun i : J => (i:Fin n))=A*Aᴴ := by
    ext i j; simp [A,Matrix.mul_apply]
  exact ⟨J,hj,he ▸ hp.isUnit⟩

theorem frameBasisCosts_finite {n d : ℕ} (Q : Matrix (Fin n) (Fin d) ℝ) :
    (frameBasisCosts Q).Finite := by
  apply (Set.finite_range (fun J : Finset (Fin n) =>
    ((Q*Qᴴ).submatrix (fun i : J => (i:Fin n)) (fun i : J => (i:Fin n)))⁻¹.trace)).subset
  rintro x ⟨J,_,_,rfl⟩
  exact ⟨J,rfl⟩

theorem frameBasisCosts_nonempty {n d : ℕ} (Q : Matrix (Fin n) (Fin d) ℝ) (hQ : Qᴴ*Q=1) :
    (frameBasisCosts Q).Nonempty := by
  obtain ⟨J,hJ,hu⟩ := parseval_exists_row_basis Q hQ
  exact ⟨_,J,hJ,hu,rfl⟩

/-- The infimum is attained at an admissible basis, not at a singular block. -/
theorem frameBasisMinimum_attained {n d : ℕ} (Q : Matrix (Fin n) (Fin d) ℝ) (hQ : Qᴴ*Q=1) :
    frameBasisMinimum Q ∈ frameBasisCosts Q := by
  classical
  let s := (frameBasisCosts_finite Q).toFinset
  have hs : s.Nonempty := by simpa [s] using frameBasisCosts_nonempty Q hQ
  obtain ⟨x,hx,hmin⟩ := s.exists_min_image id hs
  have hxmem : x ∈ frameBasisCosts Q := by simpa [s] using hx
  have he : frameBasisMinimum Q=x := by
    apply le_antisymm (csInf_le (frameBasisCosts_finite Q).bddBelow hxmem)
    apply le_csInf (frameBasisCosts_nonempty Q hQ)
    intro y hy
    exact hmin y (by simpa [s] using hy)
  rw [he]
  exact hxmem

/-- The attained minimum is no larger than the cost of any nonsingular square basis. -/
theorem frameBasisMinimum_le_basis {n d : ℕ} (Q : Matrix (Fin n) (Fin d) ℝ)
    (I : Finset (Fin n)) (hI : I.card=d)
    (hu : IsUnit ((Q*Qᴴ).submatrix (fun i : I => (i:Fin n)) (fun i : I => (i:Fin n)))) :
    frameBasisMinimum Q≤((Q*Qᴴ).submatrix (fun i : I => (i:Fin n)) (fun i : I => (i:Fin n)))⁻¹.trace := by
  exact csInf_le (frameBasisCosts_finite Q).bddBelow ⟨I,hI,hu,rfl⟩

/-- Uniform admissible-basis control gives the exact h(Q) lower bound. -/
theorem le_frameBasisMinimum {n d : ℕ} (Q : Matrix (Fin n) (Fin d) ℝ) (hQ : Qᴴ*Q=1)
    {L : ℝ} (hb : ∀ J : Finset (Fin n), J.card=d →
      IsUnit ((Q*Qᴴ).submatrix (fun i : J => (i:Fin n)) (fun i : J => (i:Fin n))) →
      L≤((Q*Qᴴ).submatrix (fun i : J => (i:Fin n)) (fun i : J => (i:Fin n)))⁻¹.trace) :
    L≤frameBasisMinimum Q := by
  apply le_csInf (frameBasisCosts_nonempty Q hQ)
  rintro x ⟨J,hJ,hu,rfl⟩
  exact hb J hJ hu

/-- A concrete frame supplies a lower bound for the frame supremum. -/
theorem frameBasisMinimum_le_supremum {n d : ℕ} (Q : Matrix (Fin n) (Fin d) ℝ) (hQ : Qᴴ*Q=1) :
    (frameBasisMinimum Q : EReal) ≤ frameBasisSupremum n d := by
  exact le_iSup_of_le Q (le_iSup_of_le hQ le_rfl)

/-- The complete square-basis construction, its attained minimum, and supremum lower bound. -/
theorem paper_balanced_frame {k : ℕ} (hk : 4 ≤ k) :
    (∃ Q : Matrix (Fin (2*k)) (Fin k) ℝ, Qᴴ*Q=1 ∧
      (∀ J : Finset (Fin (2*k)), J.card=k →
        IsUnit ((Q*Qᴴ).submatrix (fun i : J => (i:Fin (2*k))) (fun i : J => (i:Fin (2*k))))) ∧
      (k:ℝ)*Real.sqrt k/4000000000≤frameBasisMinimum Q) ∧
    (((k:ℝ)*Real.sqrt k/4000000000:ℝ):EReal) ≤ frameBasisSupremum (2*k) k := by
  obtain ⟨Q,hQ,hb⟩ := exists_balanced_parseval_frame hk
  have hmin := le_frameBasisMinimum Q hQ (fun J hJ _ => (hb J hJ).2)
  exact ⟨⟨Q,hQ,fun J hJ => (hb J hJ).1.isUnit,hmin⟩,
    (EReal.coe_le_coe_iff.mpr hmin).trans (frameBasisMinimum_le_supremum Q hQ)⟩

end SpectralComparison
