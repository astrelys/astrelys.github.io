import SpectralComparison.GaussianExchangeability
import Mathlib.Data.Matrix.Block

/-! Joint Gaussian laws for several rows projected by one fixed orthonormal matrix. -/
noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

/-- Coordinate form of a fixed orthogonal projection, stated for a literal product law. -/
theorem orthonormal_coordinates_hasLaw {Ω κ η : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [Fintype κ] [Fintype η] [DecidableEq κ] [DecidableEq η]
    (X : Ω → (κ → ℝ)) (hX : HasLaw X (Measure.pi (fun _ : κ => gaussianReal 0 1)) μ)
    (R : Matrix κ η ℝ) (hR : Rᴴ*R = 1) :
    HasLaw (fun ω => Rᴴ *ᵥ X ω) (Measure.pi (fun _ : η => gaussianReal 0 1)) μ := by
  have he : HasLaw (WithLp.toLp 2 : (κ → ℝ) → EuclideanSpace ℝ κ)
      (stdGaussian (EuclideanSpace ℝ κ)) (Measure.pi (fun _ : κ => gaussianReal 0 1)) :=
    ⟨by fun_prop, map_pi_eq_stdGaussian⟩
  have hr : HasLaw Rᴴ.toEuclideanLin (stdGaussian (EuclideanSpace ℝ η))
      (stdGaussian (EuclideanSpace ℝ κ)) := ⟨by fun_prop, orthonormal_matrix_gaussian_map R hR⟩
  exact stdGaussian_coordinates_hasLaw.fun_comp (hr.fun_comp (he.fun_comp hX))

/-- Repeating an orthonormal-column matrix along the block diagonal preserves orthonormality. -/
theorem blockDiagonal_orthonormal {ι κ η : Type*} [Fintype ι] [Fintype κ] [Fintype η]
    [DecidableEq ι] [DecidableEq κ] [DecidableEq η] (R : Matrix κ η ℝ) (hR : Rᴴ*R = 1) :
    (Matrix.blockDiagonal (fun _ : ι => R))ᴴ * Matrix.blockDiagonal (fun _ : ι => R) = 1 := by
  rw [Matrix.blockDiagonal_conjTranspose, ← Matrix.blockDiagonal_mul]
  simp_rw [hR]
  exact Matrix.blockDiagonal_one

/-- All rows projected by a fixed orthonormal matrix retain a joint product Gaussian law.
The output is indexed column first only to match the block diagonal coordinate convention. -/
theorem gaussian_rows_projected_hasLaw {Ω ι κ η : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype ι] [Fintype κ] [Fintype η]
    [DecidableEq ι] [DecidableEq κ] [DecidableEq η]
    (W : Ω → Matrix ι κ ℝ)
    (hW : ∀ a : ι × κ, HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : ι × κ => fun ω => W ω a.1 a.2) μ)
    (R : Matrix κ η ℝ) (hR : Rᴴ*R = 1) :
    HasLaw (fun ω (a : η × ι) => (W ω*R) a.2 a.1)
      (Measure.pi (fun _ : η × ι => gaussianReal 0 1)) μ := by
  have hx : HasLaw (fun ω (a : κ × ι) => W ω a.2 a.1)
      (Measure.pi (fun _ : κ × ι => gaussianReal 0 1)) μ :=
    (hind.precomp (Equiv.prodComm κ ι).injective).hasLaw_pi (fun a => hW (a.2,a.1))
  have h := orthonormal_coordinates_hasLaw _ hx (Matrix.blockDiagonal (fun _ : ι => R))
    (blockDiagonal_orthonormal R hR)
  convert h using 1
  ext ω a
  simp [Matrix.mulVec, dotProduct, Matrix.conjTranspose_apply, Matrix.blockDiagonal_apply,
    Fintype.sum_prod_type, Matrix.mul_apply, mul_comm]

/-- Each entry of the projected matrix has the standard normal law. -/
theorem gaussian_rows_projected_entry_hasLaw {Ω ι κ η : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype ι] [Fintype κ] [Fintype η]
    [DecidableEq ι] [DecidableEq κ] [DecidableEq η]
    (W : Ω → Matrix ι κ ℝ)
    (hW : ∀ a : ι × κ, HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : ι × κ => fun ω => W ω a.1 a.2) μ)
    (R : Matrix κ η ℝ) (hR : Rᴴ*R = 1) (a : ι × η) :
    HasLaw (fun ω => (W ω*R) a.1 a.2) (gaussianReal 0 1) μ := by
  have he : HasLaw (fun x : η × ι → ℝ => x (a.2,a.1)) (gaussianReal 0 1)
      (Measure.pi (fun _ : η × ι => gaussianReal 0 1)) :=
    ⟨(measurable_pi_apply _).aemeasurable, (measurePreserving_eval (fun _ : η × ι => gaussianReal 0 1) (a.2,a.1)).map_eq⟩
  exact he.fun_comp (gaussian_rows_projected_hasLaw W hW hind R hR)

/-- The projected entries are jointly independent, across both rows and columns. -/
theorem gaussian_rows_projected_independent {Ω ι κ η : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype ι] [Fintype κ] [Fintype η]
    [DecidableEq ι] [DecidableEq κ] [DecidableEq η]
    (W : Ω → Matrix ι κ ℝ)
    (hW : ∀ a : ι × κ, HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : ι × κ => fun ω => W ω a.1 a.2) μ)
    (R : Matrix κ η ℝ) (hR : Rᴴ*R = 1) :
    iIndepFun (fun a : ι × η => fun ω => (W ω*R) a.1 a.2) μ := by
  have hc : iIndepFun (fun a : η × ι => fun ω => (W ω*R) a.2 a.1) μ :=
    (iIndepFun_iff_hasLaw_pi_pi
      (X := fun a : η × ι => fun ω => (W ω*R) a.2 a.1)
      (μ := fun _ : η × ι => gaussianReal 0 1)
      (fun a => gaussian_rows_projected_entry_hasLaw W hW hind R hR (a.2,a.1))).mpr
      (gaussian_rows_projected_hasLaw W hW hind R hR)
  exact hc.precomp (Equiv.prodComm ι η).injective

end SpectralComparison
