import SpectralComparison.SelectionFactor
import SpectralComparison.DiffuseRidge
import SpectralComparison.DeficientSignal

/-! One robust frame controls all actual selected-row signal/noise objectives. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- A single frame works for every selected-row model satisfying the constructed block geometry.
Both the full-rank and deficient branches are included, with the exact constant of (7.1). -/
theorem exists_actual_selection_ridge_frame {k q : ℕ} (hk : 1≤k) (hq : 4*q≤k) :
    ∃ Q0 : Matrix (Fin (2*k)) (Fin (k-q)) ℝ,Q0ᴴ*Q0=1 ∧
    ∀ (t : Type) [Fintype t] [DecidableEq t],Fintype.card t≤k →
    ∀ (f : t → Option (Fin (2*k))) (u : t → ℝ)
      (Q : Matrix t (Fin (k-q)) ℝ),
      (∀ i j,Q i j=match f i with | none => 0 | some a => u i*Q0 a j) →
    ∀ C D : Matrix t t ℝ,C.PosSemidef → D.PosSemidef → (C-D).PosSemidef →
      (∀ i x,f i≠f x → D i x=0) →
    ∀ mass : Fin (2*k) → ℝ,(∀ i j,f i=some j → D i i=mass j*(u i)^2) →
    ∀ a s : ℝ,0<a → 0<s → (∀ j,s/(8*k)≤mass j) →
    ∀ M : Matrix (Fin (k-q)) t ℝ,
      let V := (k:ℝ)*s/(64000000000000000000000000000*((q:ℝ)+Real.sqrt k)*H (8*k))
      a*V/(a+V)≤a*(((1 : Matrix (Fin (k-q)) (Fin (k-q)) ℝ)-M*Q)*
        ((1 : Matrix (Fin (k-q)) (Fin (k-q)) ℝ)-M*Q)ᴴ).trace+(M*C*Mᴴ).trace := by
  classical
  obtain ⟨Q0,hQ0,hrows,hridge⟩ := exists_diffuse_ridge_frame hk hq
  refine ⟨Q0,hQ0,?_⟩
  intro t _ _ hn f u Q hrow C D hC hD hCD hcross mass hdiag a s ha hs hmass M
  let V := (k:ℝ)*s/(64000000000000000000000000000*((q:ℝ)+Real.sqrt k)*H (8*k))
  have hkR : (0:ℝ)<k := by exact_mod_cast (show 0<k by omega)
  have hH : 0<H (8*k) := lt_of_lt_of_le zero_lt_one (one_le_H (by omega))
  have hV : 0<V := by dsimp [V]; positivity
  by_cases hfull : IsUnit (Qᴴ*Q)
  · let w := fun j => (Finset.univ.filter (fun i => f i=some j)).card
    let Hs := Finset.univ.filter (fun j => 2≤w j)
    let L := Finset.univ.filter (fun j => w j=1)
    obtain ⟨hdis,hhq,hh,hl⟩ := actual_selection_heavy_light hq hn f u Q0 Q (by intro i j; cases hf : f i <;> simpa only [hf] using hrow i j) hfull
    change Disjoint Hs L at hdis
    change Hs.card≤q at hhq
    change 4*Hs.card≤k at hh
    change Hs.card+L.card≤k at hl
    let QH := Q0.submatrix (fun i : Hs => i.val) id
    have hHpd : (QH*QHᴴ).PosDef := hrows Hs (by omega)
    have hdim : Fintype.card (Fin (k-q-Hs.card))+Fintype.card Hs=Fintype.card (Fin (k-q)) := by
      simp only [Fintype.card_fin,Fintype.card_coe]
      omega
    obtain ⟨U,hU,hproj⟩ := exists_kernel_basis_matrix_of_dimension (d:=Fin (k-q-Hs.card)) QH hHpd hdim
    have hHU := kernel_columns_annihilated QH hHpd U hU hproj
    have hheavy : ∀ j,2≤w j → ∀ x,(Q0*U) j x=0 := by
      intro j hj x
      have hjH : j∈Hs := by simp [Hs,hj]
      exact congrFun (congrFun hHU (⟨j,hjH⟩ : Hs)) x
    let E : Matrix t L ℝ := Matrix.of (fun i j => if f i=some j.val then u i else 0)
    let G := Q0.submatrix (fun i : L => i.val) id*U
    have hfac : Q*U=E*G := actual_selection_signal_factor f u Q0 Q (by intro i j; cases hf : f i <;> simpa only [hf] using hrow i j) U hheavy
    have hnoise : (C-(s/(8*k))•(E*Eᴴ)).PosSemidef :=
      actual_selection_noise_floor f u L (fun j hj => (Finset.mem_filter.mp hj).2)
        C D hD hCD hcross mass hdiag (s/(8*k)) (fun j _ => hmass j)
    have hcomp := signal_noise_ridge_compression Q U hU E G hfac ha.le
      (show 0≤s/(8*k) by positivity) hnoise M
    exact (hridge Hs L hdis hh hl U hU hHU a s (s/(8*k)) ha hs le_rfl (Uᴴ*M*E)).trans hcomp
  · have hsmall : a*V/(a+V)≤a := by
      apply (div_le_iff₀ (by positivity)).mpr
      nlinarith [sq_nonneg a]
    exact hsmall.trans (deficient_signal_noise_lower Q hfull hC ha.le M)

end SpectralComparison
