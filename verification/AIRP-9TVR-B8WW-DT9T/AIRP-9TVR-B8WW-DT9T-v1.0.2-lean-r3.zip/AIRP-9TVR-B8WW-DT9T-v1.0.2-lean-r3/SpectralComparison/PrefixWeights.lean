import SpectralComparison.RobustFrame

/-! Extending repetition counts and expressing repeated-row column Grams. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Adding nonnegative counts increases the weighted Gram. -/
theorem weighted_gram_mono {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq n] (Q : Matrix n p ℝ) (w v : n → ℕ) (h : ∀ i, w i≤v i) :
    (Qᴴ*Matrix.diagonal (fun i => (v i:ℝ))*Q - Qᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Q).PosSemidef := by
  have hd := Matrix.PosSemidef.diagonal (fun i => sub_nonneg.mpr (show (w i:ℝ)≤v i by exact_mod_cast h i))
  have he : Matrix.diagonal (fun i => (v i:ℝ)-(w i:ℝ)) =
      Matrix.diagonal (fun i => (v i:ℝ))-Matrix.diagonal (fun i => (w i:ℝ)) := by ext a b; simp [Matrix.diagonal_apply]; split_ifs <;> ring
  rw [he] at hd
  simpa only [Matrix.mul_sub,Matrix.sub_mul] using hd.conjTranspose_mul_mul_same Q

/-- The exact-total inverse bound also holds when some selected rows are zero padding. -/
theorem weighted_inverse_trace_le_total {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p] [Nonempty n] (Q : Matrix n p ℝ) {k : ℕ} {C : ℝ}
    (hb : ∀ v : n → ℕ, (∑ i, v i)=k → IsUnit (Qᴴ*Matrix.diagonal (fun i => (v i:ℝ))*Q) →
      C≤(Qᴴ*Matrix.diagonal (fun i => (v i:ℝ))*Q)⁻¹.trace)
    (w : n → ℕ) (hw : (∑ i, w i)≤k) (hu : IsUnit (Qᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Q)) :
    C≤(Qᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Q)⁻¹.trace := by
  classical
  let a : n := Classical.choice inferInstance
  let v : n → ℕ := fun i => w i + if i=a then k-∑ j,w j else 0
  have hv : (∑ i,v i)=k := by simp [v,Finset.sum_add_distrib]; omega
  have hwv : ∀ i,w i≤v i := by intro i; dsimp [v]; omega
  have hW := ((Matrix.PosSemidef.diagonal (fun i => Nat.cast_nonneg (α := ℝ) (w i))).conjTranspose_mul_mul_same Q).posDef_iff_isUnit.mpr hu
  have hgap := weighted_gram_mono Q w v hwv
  have hV : (Qᴴ*Matrix.diagonal (fun i => (v i:ℝ))*Q).PosDef := by
    have hh := hW.add_posSemidef hgap
    rw [add_comm,sub_add_cancel] at hh
    exact hh
  exact (hb v hv hV.isUnit).trans (inverse_trace_order hW hV hgap)

/-- Summing a family with optional row types counts each nonzero type exactly. -/
theorem sum_optional_row_types {n j : Type*} [Fintype n] [Fintype j] [DecidableEq n]
    (f : j → Option n) (g : n → ℝ) :
    (∑ a, (f a).elim 0 g) = ∑ i, ((Finset.univ.filter (fun a => f a=some i)).card:ℝ)*g i := by
  classical
  have h (a : j) : (f a).elim 0 g = ∑ i, if f a=some i then g i else 0 := by
    cases he : f a with
    | none => simp
    | some i => simp
  simp_rw [h]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i _
  simp [← Finset.sum_filter]

/-- Nonzero repetition counts never exceed the number of selected rows. -/
theorem optional_row_counts_le {n j : Type*} [Fintype n] [Fintype j] [DecidableEq n]
    (f : j → Option n) :
    (∑ i, (Finset.univ.filter (fun a => f a=some i)).card) ≤ Fintype.card j := by
  classical
  have h := sum_optional_row_types f (fun _ => 1)
  have hl : (∑ a, (f a).elim (0:ℝ) (fun _ => 1))≤Fintype.card j := by
    calc
      _ ≤ ∑ _a : j, (1:ℝ) := Finset.sum_le_sum (fun a _ => by cases f a <;> norm_num)
      _ = _ := by simp
  simp only [mul_one] at h
  rw [h] at hl
  exact_mod_cast hl

/-- A normalized family with optional row types has exactly the weighted column Gram. -/
theorem optional_row_gram {n j p : Type*} [Fintype n] [Fintype j] [Fintype p]
    [DecidableEq n] (Q : Matrix n p ℝ) (f : j → Option n) {h : ℕ} (hh : 0<h) :
    let V : Matrix j p ℝ := Matrix.of (fun a b => (f a).elim 0 (fun i => Q i b / Real.sqrt h))
    Vᴴ*V=(h:ℝ)⁻¹ • (Qᴴ*Matrix.diagonal
      (fun i => ((Finset.univ.filter (fun a => f a=some i)).card:ℝ))*Q) := by
  classical
  dsimp only
  have hs : Real.sqrt (h:ℝ)≠0 := (Real.sqrt_pos.mpr (by exact_mod_cast hh)).ne'
  have hsq := Real.sq_sqrt (Nat.cast_nonneg h)
  ext a b
  change (∑ x, (f x).elim 0 (fun i => Q i a/Real.sqrt h) *
      (f x).elim 0 (fun i => Q i b/Real.sqrt h)) =
      (h:ℝ)⁻¹ * ∑ i, (Qᴴ*Matrix.diagonal (fun i => ((Finset.univ.filter (fun x => f x=some i)).card:ℝ))) a i * Q i b
  have he (x : j) : (f x).elim 0 (fun i => Q i a/Real.sqrt h) *
      (f x).elim 0 (fun i => Q i b/Real.sqrt h) =
      (h:ℝ)⁻¹ * (f x).elim 0 (fun i => Q i a*Q i b) := by
    cases f x with
    | none => simp
    | some i => simp only [Option.elim_some]; field_simp; rw [hsq]; ring
  simp_rw [he]
  rw [← Finset.mul_sum,sum_optional_row_types]
  congr 1
  apply Finset.sum_congr rfl
  intro i _
  simp only [Matrix.mul_diagonal,Matrix.conjTranspose_apply,star_trivial]
  ring

end SpectralComparison
