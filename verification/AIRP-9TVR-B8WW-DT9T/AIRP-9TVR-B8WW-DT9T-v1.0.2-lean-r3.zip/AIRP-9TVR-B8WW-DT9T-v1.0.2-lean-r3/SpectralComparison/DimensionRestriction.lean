import SpectralComparison.RestrictedSupremum

/-! Restricting a spectrum to any coordinate sublist cannot increase the worst error.
The proof uses embedded precision; no unproved greedy-selection contract is needed. -/
noncomputable section
open Matrix Finset
namespace SpectralComparison

variable {ι κ : Type*} [Fintype ι] [Fintype κ] [DecidableEq ι] [DecidableEq κ]

omit [Fintype ι] in
theorem unselected_embedding_card (f : κ → ι) (hf : Function.Injective f)
    (I : Finset ι) {k : ℕ} (hI : I.card=k) :
    Fintype.card κ-k≤(Finset.univ.filter (fun j => f j∉I)).card := by
  let A := Finset.univ.filter (fun j => f j∈I)
  let g : A → I := fun j => ⟨f j.val,(Finset.mem_filter.mp j.property).2⟩
  have hg : Function.Injective g := by intro a b h; exact Subtype.ext (hf (congrArg Subtype.val h))
  have hc := Fintype.card_le_of_injective g hg
  simp only [Fintype.card_coe,hI] at hc
  have he : Finset.univ.filter (fun j => f j∉I)=(Finset.univ : Finset κ) \ A := by ext j; simp [A]
  rw [he]
  simp only [Finset.card_sdiff,Finset.inter_univ,Finset.card_univ]
  omega

theorem embedded_bestError_le_residual {K : Matrix ι ι ℝ} {H : Matrix κ κ ℝ}
    (hK : K.PosDef) (hH : H.PosDef) (f : κ → ι) (hf : Function.Injective f)
    (he : K⁻¹.submatrix f f=H⁻¹) {k : ℕ} (hk : k≤Fintype.card κ)
    (I : Finset ι) (hI : I.card=k) : bestError H k≤residualTrace K I := by
  obtain ⟨J,hJS,hJ⟩ := Finset.exists_subset_card_eq (unselected_embedding_card f hf I hI)
  let g : J → ↥(Finset.univ \ I) := fun j => ⟨f j.val,by
    have h := Finset.mem_filter.mp (hJS j.property)
    exact Finset.mem_sdiff.mpr ⟨Finset.mem_univ _,h.2⟩⟩
  have hg : Function.Injective g := by intro a b h; exact Subtype.ext (hf (congrArg Subtype.val h))
  have hjc : (Finset.univ \ J).card=k := by simp only [Finset.card_sdiff,Finset.inter_univ,Finset.card_univ,hJ]; omega
  have hb := bestError_le H hjc
  rw [nystrom_trace_inverse_complement hH,show Finset.univ \ (Finset.univ \ J)=J by ext j; simp] at hb
  have ht := inverse_trace_submatrix_le (principal_posDef hK.inv (Finset.univ \ I)) g hg
  have hm : (principal K⁻¹ (Finset.univ \ I)).submatrix g g=principal H⁻¹ J := by
    rw [← he]; rfl
  rw [hm] at ht
  rw [nystrom_trace_inverse_complement hK I]
  exact hb.trans ht

/-- Literal objective monotonicity under deleting any subset of eigenvalues, retaining more than k. -/
theorem worstError_restrict (a : ι → ℝ) (ha : ∀ i,0<a i) (S : Finset ι) {k : ℕ}
    (hk : k<S.card) : worstError (fun i : S => a i) k≤worstError a k := by
  have hkn : k<Fintype.card ι := hk.trans_le (by simpa using S.card_le_univ)
  obtain ⟨V,hV,hmax⟩ := worstError_attained (fun i : S => a i) (fun i => ha i) (by simpa using hk)
  obtain ⟨W,hW,he⟩ := extend_prefix_orientation (partitionEquiv S) a ha V hV
  rw [hmax]
  apply le_trans _ (orbit_bestError_le_worstError a ha W hW hkn)
  apply le_bestError _ hkn.le
  intro I hI
  apply embedded_bestError_le_residual (orbit_posDef a ha W hW)
    (orbit_posDef (fun i : S => a i) (fun i => ha i) V hV) (fun i : S => (i:ι)) Subtype.val_injective
    he (by simpa using hk.le) I hI

end SpectralComparison
