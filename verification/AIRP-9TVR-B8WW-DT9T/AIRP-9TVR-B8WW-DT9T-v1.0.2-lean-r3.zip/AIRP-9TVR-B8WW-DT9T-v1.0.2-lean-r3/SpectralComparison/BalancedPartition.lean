import SpectralComparison.DiffusePrefix

/-! Finite greedy load balancing for diffuse-tail weights. -/
noncomputable section
namespace SpectralComparison

/-- Assign bounded nonnegative weights to positive-many groups with spread at most the cap. -/
theorem exists_balanced_partition {g p : ℕ} (hg : 0<g) {w : ℝ} (hw : 0≤w)
    (d : Fin p → ℝ) (hd : ∀ i,0≤d i) (hcap : ∀ i,d i≤w) :
    ∃ f : Fin p → Fin g, ∀ i j,
      (∑ a,if f a=i then d a else 0)≤(∑ a,if f a=j then d a else 0)+w := by
  classical
  induction p with
  | zero => exact ⟨Fin.elim0,by simpa using fun _ _ => hw⟩
  | succ p ih =>
    obtain ⟨f,hf⟩ := ih (fun a => d a.castSucc) (fun a => hd a.castSucc) (fun a => hcap a.castSucc)
    let L := fun j => ∑ a,if f a=j then d a.castSucc else 0
    obtain ⟨j,hj,hmin⟩ := (Finset.univ : Finset (Fin g)).exists_min_image L ⟨⟨0,hg⟩,Finset.mem_univ _⟩
    let f' : Fin (p+1) → Fin g := Fin.lastCases j f
    have hload (i : Fin g) : (∑ a,if f' a=i then d a else 0)=L i+(if j=i then d (Fin.last p) else 0) := by
      rw [Fin.sum_univ_castSucc]
      simp [f',L]
    refine ⟨f',?_⟩
    intro a b
    rw [hload,hload]
    by_cases ha : j=a
    · subst a
      by_cases hb : j=b
      · subst b; simp; exact hw
      · simp only [ite_eq_left,ite_eq_right hb,add_zero]
        have hh := hmin b (Finset.mem_univ _)
        linarith [hcap (Fin.last p)]
    · by_cases hb : j=b
      · subst b
        simp only [ite_eq_right ha,ite_eq_left,add_zero]
        have hh := hf a j
        change L a≤L j+w at hh
        linarith [hd (Fin.last p)]
      · simp only [ite_eq_right ha,ite_eq_right hb,add_zero]
        exact hf a b

/-- A partition preserves the total mass, even with empty groups. -/
theorem partition_weight_sum {g p : ℕ} (f : Fin p → Fin g) (d : Fin p → ℝ) :
    (∑ j,∑ i,if f i=j then d i else 0)=∑ i,d i := by
  rw [Finset.sum_comm]
  simp

/-- Every group in a balanced partition has mass at least the average minus the weight cap. -/
theorem balanced_partition_lower {g p : ℕ} (hg : 0<g) (f : Fin p → Fin g) (d : Fin p → ℝ)
    {w : ℝ} (hspread : ∀ i j,(∑ a,if f a=i then d a else 0)≤(∑ a,if f a=j then d a else 0)+w)
    (j : Fin g) : (∑ i,d i)/(g:ℝ)-w≤∑ a,if f a=j then d a else 0 := by
  have hgR : (0:ℝ)<g := by exact_mod_cast hg
  have hh := Finset.sum_le_sum (fun i (_ : i∈Finset.univ) => hspread i j)
  rw [partition_weight_sum] at hh
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] at hh
  have hdiv : (∑ i,d i)/(g:ℝ)≤(∑ a,if f a=j then d a else 0)+w :=
    (div_le_iff₀ hgR).mpr (by simpa only [mul_comm] using hh)
  linarith

/-- The exact s/(8k) lower bound needed in (7.3), after reserve selection. -/
theorem exists_diffuse_weight_partition {k p : ℕ} (hk : 1≤k) {s : ℝ} (hs : 0<s)
    (d : Fin p → ℝ) (hd : ∀ i,0≤d i) (hcap : ∀ i,d i≤s/(16*k))
    (htotal : 3*s/8<∑ i,d i) :
    ∃ f : Fin p → Fin (2*k), ∀ j,s/(8*k)<∑ a,if f a=j then d a else 0 := by
  have hkR : (0:ℝ)<k := by exact_mod_cast (show 0<k by omega)
  obtain ⟨f,hf⟩ := exists_balanced_partition (show 0<2*k by omega) (by positivity) d hd hcap
  refine ⟨f,fun j => ?_⟩
  have hlow := balanced_partition_lower (show 0<2*k by omega) f d hf j
  have havg : 3*s/(16*k)<(∑ i,d i)/(2*k) := by
    apply (lt_div_iff₀ (by positivity)).mpr
    convert htotal using 1
    field_simp
    ring
  norm_num only [Nat.cast_mul,Nat.cast_ofNat] at hlow
  have hid : 3*s/(16*k)-s/(16*k)=s/(8*k) := by field_simp; ring
  linarith

end SpectralComparison
