import SpectralComparison.FrameCompletion

/-! Rotate the group-kernel coordinates while retaining every positive covariance weight. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- A fixed kernel frame and its complement mix only the zero eigenspace of the assembled groups.
The resulting orthogonal basis gives the exact signal/reserved/unreserved spectral sum. -/
theorem exists_kernel_spectrum_mix {n g p r h : Type*}
    [Fintype n] [Fintype g] [Fintype p] [Fintype r] [Fintype h]
    [DecidableEq n] [DecidableEq g] [DecidableEq p] [DecidableEq r] [DecidableEq h]
    (W : Matrix n (g ⊕ p) ℝ) (hW : Wᴴ*W=1) (hW' : W*Wᴴ=1)
    (Q : Matrix g r ℝ) (hQ : Qᴴ*Q=1) (hdim : Fintype.card h+Fintype.card r=Fintype.card g) :
    ∃ R : Matrix g h ℝ,∃ V : Matrix n ((r ⊕ h) ⊕ p) ℝ,
      Rᴴ*R=1 ∧ Qᴴ*R=0 ∧ Vᴴ*V=1 ∧ V*Vᴴ=1 ∧
      V.submatrix id (fun i => Sum.inl (Sum.inl i))=W.submatrix id Sum.inl*Q ∧
      ∀ (a : r → ℝ) (b : h → ℝ) (d : p → ℝ),
        V*Matrix.diagonal (Sum.elim (Sum.elim a b) d)*Vᴴ=
          (W.submatrix id Sum.inl*Q)*Matrix.diagonal a*(W.submatrix id Sum.inl*Q)ᴴ+
          (W.submatrix id Sum.inl*R)*Matrix.diagonal b*(W.submatrix id Sum.inl*R)ᴴ+
          W.submatrix id Sum.inr*Matrix.diagonal d*(W.submatrix id Sum.inr)ᴴ := by
  obtain ⟨R,hR,hQR,_hsum,hH,hH'⟩ := exists_orthogonal_frame_completion Q hQ hdim
  let H := Matrix.fromCols Q R
  change Hᴴ*H=1 at hH
  change H*Hᴴ=1 at hH'
  let E : Matrix (g ⊕ p) ((r ⊕ h) ⊕ p) ℝ := Matrix.fromBlocks H 0 0 1
  have hE : Eᴴ*E=1 := by
    dsimp [E]
    rw [Matrix.fromBlocks_conjTranspose,Matrix.fromBlocks_multiply]
    simp only [Matrix.conjTranspose_zero,Matrix.conjTranspose_one,Matrix.mul_zero,Matrix.zero_mul,zero_add,add_zero,Matrix.one_mul,hH]
    exact Matrix.fromBlocks_one
  have hE' : E*Eᴴ=1 := by
    dsimp [E]
    rw [Matrix.fromBlocks_conjTranspose,Matrix.fromBlocks_multiply]
    simp only [Matrix.conjTranspose_zero,Matrix.conjTranspose_one,Matrix.mul_zero,Matrix.zero_mul,zero_add,add_zero,Matrix.one_mul,hH']
    exact Matrix.fromBlocks_one
  let V := W*E
  have hV : Vᴴ*V=1 := by
    dsimp [V]
    rw [Matrix.conjTranspose_mul]
    calc
      Eᴴ*Wᴴ*(W*E)=Eᴴ*(Wᴴ*W)*E := by simp only [Matrix.mul_assoc]
      _ = 1 := by rw [hW,Matrix.mul_one,hE]
  have hV' : V*Vᴴ=1 := by
    dsimp [V]
    rw [Matrix.conjTranspose_mul]
    calc
      W*E*(Eᴴ*Wᴴ)=W*(E*Eᴴ)*Wᴴ := by simp only [Matrix.mul_assoc]
      _ = 1 := by rw [hE',Matrix.mul_one,hW']
  let S := W.submatrix id Sum.inl
  let B := W.submatrix id Sum.inr
  have hWB : W=Matrix.fromCols S B := by ext i j; cases j <;> rfl
  have hVF : V=Matrix.fromCols (Matrix.fromCols (S*Q) (S*R)) B := by
    dsimp [V,E]
    rw [hWB,Matrix.fromCols_mul_fromBlocks]
    simp only [Matrix.mul_zero,Matrix.mul_one,zero_add,add_zero]
    rw [show H=Matrix.fromCols Q R from rfl,Matrix.mul_fromCols]
  refine ⟨R,V,hR,hQR,hV,hV',?_,?_⟩
  · rw [hVF]
    rfl
  · intro a b d
    rw [hVF,fromCols_spectral_synthesis,fromCols_spectral_synthesis]

end SpectralComparison
