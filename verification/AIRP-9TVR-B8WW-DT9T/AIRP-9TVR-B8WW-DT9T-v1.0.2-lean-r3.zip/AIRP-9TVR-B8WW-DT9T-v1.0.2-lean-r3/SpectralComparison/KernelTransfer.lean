import SpectralComparison.RobustGoodMatrix

/-! Complete deterministic transfer of kernel inverse traces through any fixed positive whitening. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- A full-row-rank matrix remains so after an invertible right multiplication. -/
theorem row_gram_posDef_mul_isUnit {h p : Type*} [Fintype h] [Fintype p]
    [DecidableEq h] [DecidableEq p] (H : Matrix h p ℝ) (hH : (H*Hᴴ).PosDef)
    (W : Matrix p p ℝ) (hW : IsUnit W) : ((H*W)*(H*W)ᴴ).PosDef := by
  have hHi : Function.Injective Hᴴ.mulVec := by
    intro x y hxy
    apply (Matrix.mulVec_injective_iff_isUnit.mpr hH.isUnit)
    simpa only [Matrix.mulVec_mulVec] using congrArg H.mulVec hxy
  have hWi : Function.Injective Wᴴ.mulVec := Matrix.mulVec_injective_iff_isUnit.mpr hW.star
  have hi : Function.Injective (H*W)ᴴ.mulVec := by
    intro x y hxy
    apply hHi
    apply hWi
    simpa only [Matrix.conjTranspose_mul,Matrix.mulVec_mulVec] using hxy
  simpa only [Matrix.conjTranspose_conjTranspose] using Matrix.PosDef.conjTranspose_mul_self (H*W)ᴴ hi

/-- The literal kernel projector yields annihilation of its orthonormal coordinates. -/
theorem kernel_columns_annihilated {h p d : Type*} [Fintype h] [Fintype p] [Fintype d]
    [DecidableEq h] [DecidableEq p] [DecidableEq d] (H : Matrix h p ℝ)
    (hH : (H*Hᴴ).PosDef) (R : Matrix p d ℝ) (hR : Rᴴ*R=1)
    (hproj : R*Rᴴ=1-Hᴴ*(H*Hᴴ)⁻¹*H) : H*R=0 := by
  have hz : H*(R*Rᴴ)=0 := by rw [hproj]; exact kernel_projector_annihilates H hH
  calc
    H*R=H*(R*Rᴴ)*R := by simp only [Matrix.mul_assoc,hR,Matrix.mul_one]
    _ = 0 := by rw [hz,Matrix.zero_mul]

/-- Any fixed positive whitening transforms the old kernel coordinates into new orthonormal ones. -/
theorem fixed_whitening_kernel_columns {h l p d : Type*} [Fintype h] [Fintype l]
    [Fintype p] [Fintype d] [DecidableEq p] [DecidableEq d]
    (H : Matrix h p ℝ) (X : Matrix l p ℝ) (R : Matrix p d ℝ)
    (hR : Rᴴ*R=1) (hHR : H*R=0) {S W : Matrix p p ℝ}
    (hS : S.PosDef) (hW : W.PosDef) (hWSW : W*S*W=1) :
    ∃ (U : Matrix p d ℝ) (C : Matrix d d ℝ),
      Uᴴ*U=1 ∧ (H*W)*U=0 ∧ C.PosDef ∧ C*C=(Rᴴ*S*R)⁻¹ ∧ (X*W)*U=(X*R)*C := by
  have hwi := Matrix.mul_nonsing_inv W (isUnit_iff_ne_zero.mpr hW.det_pos.ne')
  have hiw := Matrix.nonsing_inv_mul W (isUnit_iff_ne_zero.mpr hW.det_pos.ne')
  have hAA : W⁻¹*W⁻¹=S := by
    calc
      _ = W⁻¹*(W*S*W)*W⁻¹ := by rw [hWSW,Matrix.mul_one]
      _ = (W⁻¹*W)*S*(W*W⁻¹) := by simp only [Matrix.mul_assoc]
      _ = S := by rw [hiw,hwi,Matrix.one_mul,Matrix.mul_one]
  obtain ⟨C,hC,hCBC,hCC⟩ := exists_inverse_sqrt (orthonormal_compression_posDef hS R hR)
  refine ⟨W⁻¹*R*C,C,?_,?_,hC,hCC,?_⟩
  · simp only [Matrix.conjTranspose_mul,hC.isHermitian.eq,hW.inv.isHermitian.eq]
    calc
      C*(Rᴴ*W⁻¹)*(W⁻¹*R*C)=C*(Rᴴ*(W⁻¹*W⁻¹)*R)*C := by simp only [Matrix.mul_assoc]
      _ = 1 := by rw [hAA,hCBC]
  · calc
      H*W*(W⁻¹*R*C)=H*(W*W⁻¹)*R*C := by simp only [Matrix.mul_assoc]
      _ = 0 := by rw [hwi,Matrix.mul_one,hHR,Matrix.zero_mul]
  · calc
      X*W*(W⁻¹*R*C)=X*(W*W⁻¹)*R*C := by simp only [Matrix.mul_assoc]
      _ = _ := by rw [hwi,Matrix.mul_one]

/-- Every orthonormal basis of the whitened kernel obeys the transferred bound.
The raw inverse-trace hypothesis is preserved even with totalized matrix inversion. -/
theorem fixed_whitening_all_kernel_bases {h l p d : Type*} [Fintype h] [Fintype l]
    [Fintype p] [Fintype d] [DecidableEq h] [DecidableEq p] [DecidableEq d]
    (H : Matrix h p ℝ) (X : Matrix l p ℝ) (hH : (H*Hᴴ).PosDef)
    (R : Matrix p d ℝ) (hR : Rᴴ*R=1) (hproj : R*Rᴴ=1-Hᴴ*(H*Hᴴ)⁻¹*H)
    (hd : Fintype.card d+Fintype.card h=Fintype.card p)
    {S W : Matrix p p ℝ} (hS : S.PosDef) (hW : W.PosDef) (hWSW : W*S*W=1)
    {a L : ℝ} (ha : 0≤a) (hgap : (S-a • (1 : Matrix p p ℝ)).PosSemidef)
    (ht : L≤((X*R)ᴴ*(X*R))⁻¹.trace)
    (V : Matrix p d ℝ) (hV : Vᴴ*V=1) (hHV : (H*W)*V=0) :
    a*L≤((X*W*V)ᴴ*(X*W*V))⁻¹.trace := by
  obtain ⟨U,C,hU,hHU,hC,hCC,hXU⟩ := fixed_whitening_kernel_columns H X R hR
    (kernel_columns_annihilated H hH R hR hproj) hS hW hWSW
  have hHW := row_gram_posDef_mul_isUnit H hH W hW.isUnit
  have hprojU := orthonormal_kernel_projector (H*W) hHW U hU hHU hd
  have hprojV := orthonormal_kernel_projector (H*W) hHW V hV hHV hd
  have he := kernel_basis_inverse_trace_invariant (X*W) U V hU hV (hprojU.trans hprojV.symm)
  rw [← he,hXU]
  exact whitened_kernel_trace_lower X R hR hS hC hCC ha hgap ht

end SpectralComparison
