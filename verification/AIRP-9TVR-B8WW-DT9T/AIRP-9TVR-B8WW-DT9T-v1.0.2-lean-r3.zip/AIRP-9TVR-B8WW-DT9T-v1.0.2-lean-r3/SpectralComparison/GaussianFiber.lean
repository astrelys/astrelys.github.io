import SpectralComparison.GaussianRows
import SpectralComparison.KernelProjection

/-! Pointwise-in-the-lower-block estimates and a measurable Fubini interface. -/
noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

/-- A uniform almost-everywhere fiber bound integrates to the same product-probability bound.
Only the event is measurable: no measurable selection of witnesses is required. -/
theorem probability_le_of_fiber_bound {A B : Type*} [MeasurableSpace A] [MeasurableSpace B]
    (μ : Measure A) (ν : Measure B) [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    (E : Set (A × B)) (hE : MeasurableSet E) {c : ℝ} (hc : 0 ≤ c)
    (hfiber : ∀ᵐ b ∂ν, μ.real {a | (a,b) ∈ E} ≤ c) : (μ.prod ν).real E ≤ c := by
  have hbound : (μ.prod ν) E ≤ ENNReal.ofReal c := by
    rw [Measure.prod_apply_symm hE]
    calc
      _ ≤ ∫⁻ _b, ENNReal.ofReal c ∂ν := by
        apply lintegral_mono_ae
        filter_upwards [hfiber] with b hb
        calc
          _ = ENNReal.ofReal (μ.real {a | (a,b) ∈ E}) := (ENNReal.ofReal_toReal (measure_ne_top _ _)).symm
          _ ≤ _ := ENNReal.ofReal_le_ofReal hb
      _ = _ := by simp
  exact (ENNReal.toReal_mono ENNReal.ofReal_ne_top hbound).trans_eq (ENNReal.toReal_ofReal hc)

/-- With the lower row block fixed and full rank, its kernel coordinates turn the
leading inverse-Gram block into a Gaussian inverse-Gram tail. The event includes full
rank of the assembled matrix; that null exceptional set is removed after integration. -/
theorem gaussian_inverse_block_fiber_bound {Ω m n p : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype m] [Fintype n] [Fintype p]
    [DecidableEq m] [DecidableEq n] [DecidableEq p]
    (U : Ω → Matrix m p ℝ)
    (hU : ∀ a : m × p, HasLaw (fun ω => U ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : m × p => fun ω => U ω a.1 a.2) μ)
    (hmeas : ∀ a : m × p, Measurable (fun ω => U ω a.1 a.2))
    (B : Matrix n p ℝ) (hB : (B*Bᴴ).PosDef)
    (hm : 0 < Fintype.card m) (hd : Fintype.card m + Fintype.card n ≤ Fintype.card p) :
    μ.real {ω | ((Matrix.fromRows (U ω) B)*(Matrix.fromRows (U ω) B)ᴴ).PosDef ∧
      ((((Matrix.fromRows (U ω) B)*(Matrix.fromRows (U ω) B)ᴴ)⁻¹).submatrix Sum.inl Sum.inl).trace ≤
        (Fintype.card m:ℝ)/(500*(Fintype.card p-Fintype.card n:ℕ))} ≤
      Real.exp (-124*((Fintype.card m:ℝ)*(Fintype.card p-Fintype.card n:ℕ))) := by
  let d := Module.finrank ℝ B.toEuclideanLin.ker
  have hdim : d + Fintype.card n = Fintype.card p := kernel_dimension_of_gram_posDef B hB
  have hdEq : d = Fintype.card p-Fintype.card n := by omega
  have hmd : Fintype.card m ≤ Fintype.card (Fin d) := by simp only [Fintype.card_fin]; omega
  obtain ⟨emb⟩ := Function.Embedding.nonempty_of_card_le hmd
  obtain ⟨R,hR,hRR⟩ := exists_kernel_basis_matrix B hB
  have hentry := gaussian_rows_projected_entry_hasLaw U hU hind R hR
  have hindR := gaussian_rows_projected_independent U hU hind R hR
  have hmeasR (a : m × Fin d) : Measurable (fun ω => (U ω*R) a.1 a.2) := by
    simp only [Matrix.mul_apply]
    exact Finset.measurable_sum _ (fun i _ => (hmeas (a.1,i)).mul_const _)
  have ht := gaussian_inverse_trace_tail_500 emb (fun ω => U ω*R) hentry hindR hmeasR hm
    (by simp only [Fintype.card_fin]; omega)
  simp only [Fintype.card_fin, hdEq] at ht
  apply le_trans _ ht
  refine measureReal_mono ?_ (measure_ne_top _ _)
  intro ω hω
  have he := inverse_gram_upper_block (U ω) B hω.1
  rw [← hRR] at he
  have he' : ((((Matrix.fromRows (U ω) B)*(Matrix.fromRows (U ω) B)ᴴ)⁻¹).submatrix Sum.inl Sum.inl) =
      ((U ω*R)*(U ω*R)ᴴ)⁻¹ := by simpa only [Matrix.conjTranspose_mul, Matrix.mul_assoc] using he
  simpa only [Set.mem_ofPred_eq, he'] using hω.2

end SpectralComparison
