import SpectralComparison.WeightedPrecisionTrace

noncomputable section
open Matrix
namespace SpectralComparison

/-- Orthogonal synthesis with arbitrary equivalent finite label types inverts entrywise. -/
theorem rectangular_orthogonal_inverse {n l : Type*} [Fintype n] [Fintype l]
    [DecidableEq n] [DecidableEq l] (U : Matrix n l ℝ)
    (hU : Uᴴ * U = 1) (hU' : U * Uᴴ = 1) (d : l → ℝ) (hd : ∀ i, 0 < d i) :
    (U * diagonal d * Uᴴ)⁻¹ = U * diagonal (fun i => (d i)⁻¹) * Uᴴ := by
  apply Matrix.inv_eq_right_inv
  have hdiag : diagonal d * diagonal (fun i => (d i)⁻¹) = 1 := by
    rw [Matrix.diagonal_mul_diagonal]
    ext i j
    by_cases hij : i = j
    · subst j; simp [(hd i).ne']
    · simp [hij]
  calc
    _ = U * diagonal d * (Uᴴ * U) * diagonal (fun i => (d i)⁻¹) * Uᴴ := by simp only [Matrix.mul_assoc]
    _ = U * (diagonal d * diagonal (fun i => (d i)⁻¹)) * Uᴴ := by rw [hU, Matrix.mul_one]; simp only [Matrix.mul_assoc]
    _ = 1 := by rw [hdiag, Matrix.mul_one, hU']

/-- The actual precision is bounded by a scalar identity plus the weighted noise precision. -/
theorem weighted_signal_precision_bound {n r p : Type*} [Fintype n] [Fintype r] [Fintype p]
    [DecidableEq n] [DecidableEq r] [DecidableEq p]
    (Q : Matrix n r ℝ) (R : Matrix n p ℝ)
    (hU : (Matrix.fromCols Q R)ᴴ * Matrix.fromCols Q R = 1)
    (hU' : Matrix.fromCols Q R * (Matrix.fromCols Q R)ᴴ = 1)
    (h : r → ℝ) (b : p → ℝ) (hh : ∀ i, 0 < h i) (hb : ∀ i, 0 < b i)
    {a : ℝ} (ha : 0 < a) (hhead : ∀ i, a ≤ h i) :
    (a⁻¹ • (1 : Matrix n n ℝ) + R * diagonal (fun i => (b i)⁻¹) * Rᴴ -
      (Q * diagonal h * Qᴴ + R * diagonal b * Rᴴ)⁻¹).PosSemidef := by
  have hi := rectangular_orthogonal_inverse (Matrix.fromCols Q R) hU hU'
    (Sum.elim h b) (by intro i; cases i with | inl i => exact hh i | inr i => exact hb i)
  rw [fromCols_spectral_synthesis] at hi
  have he : (fun i => ((Sum.elim h b) i)⁻¹) = Sum.elim (fun i => (h i)⁻¹) (fun i => (b i)⁻¹) := by funext i; cases i <;> rfl
  rw [he, fromCols_spectral_synthesis] at hi
  have hcomp : Q * Qᴴ + R * Rᴴ = 1 := by
    rwa [Matrix.conjTranspose_fromCols_eq_fromRows_conjTranspose, Matrix.fromCols_mul_fromRows] at hU'
  have hg : ∀ i, 0 ≤ a⁻¹ - (h i)⁻¹ := by
    intro i
    have hh := one_div_le_one_div_of_le ha (hhead i)
    simpa only [one_div] using sub_nonneg.mpr hh
  have hpos := (Matrix.PosSemidef.diagonal hg).conjTranspose_mul_mul_same Qᴴ
  rw [Matrix.conjTranspose_conjTranspose] at hpos
  have hdiag : diagonal (fun i => a⁻¹ - (h i)⁻¹) =
      a⁻¹ • (1 : Matrix r r ℝ) - diagonal (fun i => (h i)⁻¹) := by
    ext i j
    by_cases hij : i = j
    · subst j; simp
    · simp [hij]
  rw [hdiag, Matrix.mul_sub, Matrix.sub_mul, Matrix.mul_smul, Matrix.mul_one, Matrix.smul_mul] at hpos
  have hnoise := (posSemidef_self_mul_conjTranspose R).smul (inv_nonneg.mpr ha.le)
  rw [hi, ← hcomp, smul_add]
  convert hpos.add hnoise using 1 <;> abel

end SpectralComparison
