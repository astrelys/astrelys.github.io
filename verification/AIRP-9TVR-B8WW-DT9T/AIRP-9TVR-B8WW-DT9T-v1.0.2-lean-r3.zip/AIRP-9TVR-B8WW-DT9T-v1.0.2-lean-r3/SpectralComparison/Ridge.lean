import SpectralComparison.Predictor

/-! Exact matrix ridge minimization, including rank-deficient observations (7.12). -/
noncomputable section
namespace SpectralComparison
open Matrix Finset
variable {ι κ : Type*} [Fintype ι] [DecidableEq ι] [Fintype κ] [DecidableEq κ]

omit [Fintype ι] [DecidableEq ι] in
/-- Completion of a matrix quadratic with a positive-definite observation Hessian. -/
theorem matrix_quadratic_completion {B : Matrix κ κ ℝ} (hB : B.PosDef)
    (D : Matrix ι ι ℝ) (C T : Matrix ι κ ℝ) :
    D-T*C.conjTranspose-C*T.conjTranspose+T*B*T.conjTranspose =
      D-C*B⁻¹*C.conjTranspose +
        (T-C*B⁻¹)*B*(T-C*B⁻¹).conjTranspose := by
  let _ : Invertible B := hB.isUnit.invertible
  simp only [Matrix.conjTranspose_sub, Matrix.conjTranspose_mul, hB.inv.isHermitian.eq,
    Matrix.sub_mul, Matrix.mul_sub, Matrix.inv_mul_cancel_right_of_invertible]
  simp only [Matrix.mul_assoc, Matrix.mul_inv_cancel_left_of_invertible]
  abel

/-- Woodbury identity specialized to strictly positive signal and noise variances. -/
theorem ridge_inverse_identity (G : Matrix κ ι ℝ) {a v : ℝ} (ha : 0 < a) (hv : 0 < v) :
    (a⁻¹ • (1 : Matrix ι ι ℝ) + v⁻¹ • (G.conjTranspose*G))⁻¹ =
      a • (1 : Matrix ι ι ℝ) -
        (a • G.conjTranspose)*(v • (1 : Matrix κ κ ℝ)+a • (G*G.conjTranspose))⁻¹*
          (a • G.conjTranspose).conjTranspose := by
  have hAi : (a⁻¹ • (1 : Matrix ι ι ℝ))⁻¹ = a • (1 : Matrix ι ι ℝ) := by
    apply Matrix.inv_eq_right_inv
    simp [smul_smul, ha.ne']
  have hCi : (v⁻¹ • (1 : Matrix κ κ ℝ))⁻¹ = v • (1 : Matrix κ κ ℝ) := by
    apply Matrix.inv_eq_right_inv
    simp [smul_smul, hv.ne']
  have hA : (a⁻¹ • (1 : Matrix ι ι ℝ)).PosDef := Matrix.PosDef.one.smul (inv_pos.mpr ha)
  have hC : (v⁻¹ • (1 : Matrix κ κ ℝ)).PosDef := Matrix.PosDef.one.smul (inv_pos.mpr hv)
  have hB : (v • (1 : Matrix κ κ ℝ)+a • (G*G.conjTranspose)).PosDef :=
    (Matrix.PosDef.one.smul hv).add_posSemidef ((Matrix.posSemidef_self_mul_conjTranspose G).smul ha.le)
  have hw := Matrix.add_mul_mul_inv_eq_sub (a⁻¹ • (1 : Matrix ι ι ℝ))
    G.conjTranspose (v⁻¹ • (1 : Matrix κ κ ℝ)) G hA.isUnit hC.isUnit
    (by simpa only [hAi, hCi, Matrix.mul_smul, Matrix.smul_mul, Matrix.mul_one] using hB.isUnit)
  simpa only [hAi, hCi, Matrix.mul_smul, Matrix.smul_mul, Matrix.mul_one,
    Matrix.one_mul, Matrix.conjTranspose_smul, star_trivial, Matrix.conjTranspose_conjTranspose,
    Matrix.mul_assoc, smul_smul] using hw

/-- The ridge objective equals the inverse precision plus a PSD quadratic remainder. -/
theorem matrix_ridge_completion (G : Matrix κ ι ℝ) {a v : ℝ} (ha : 0 < a) (hv : 0 < v)
    (T : Matrix ι κ ℝ) :
    let B := v • (1 : Matrix κ κ ℝ)+a • (G*G.conjTranspose)
    let R := (a • G.conjTranspose)*B⁻¹
    a • (((1 : Matrix ι ι ℝ)-T*G)*((1 : Matrix ι ι ℝ)-T*G).conjTranspose) +
      v • (T*T.conjTranspose) =
      (a⁻¹ • (1 : Matrix ι ι ℝ)+v⁻¹ • (G.conjTranspose*G))⁻¹ +
        (T-R)*B*(T-R).conjTranspose := by
  let B := v • (1 : Matrix κ κ ℝ)+a • (G*G.conjTranspose)
  have hB : B.PosDef :=
    (Matrix.PosDef.one.smul hv).add_posSemidef ((Matrix.posSemidef_self_mul_conjTranspose G).smul ha.le)
  dsimp only
  rw [ridge_inverse_identity G ha hv]
  rw [← matrix_quadratic_completion hB]
  simp only [B, Matrix.conjTranspose_sub, Matrix.conjTranspose_one, Matrix.conjTranspose_mul,
    Matrix.conjTranspose_smul, star_trivial, Matrix.conjTranspose_conjTranspose,
    Matrix.mul_sub, Matrix.sub_mul, Matrix.mul_add, Matrix.add_mul, Matrix.one_mul,
    Matrix.mul_one, Matrix.mul_smul, Matrix.smul_mul, smul_sub, Matrix.mul_assoc]
  abel

/-- Paper equation (7.12), as an attained trace minimum. No rank condition on G is used.
Trace(M M^T) is the squared Frobenius norm of the corresponding real matrix. -/
theorem paper_equation_7_12 (G : Matrix κ ι ℝ) {a v : ℝ} (ha : 0 < a) (hv : 0 < v) :
    let value := (a⁻¹ • (1 : Matrix ι ι ℝ)+v⁻¹ • (G.conjTranspose*G))⁻¹.trace
    (∀ T : Matrix ι κ ℝ, value ≤
      a * (((1 : Matrix ι ι ℝ)-T*G)*((1 : Matrix ι ι ℝ)-T*G).conjTranspose).trace +
        v * (T*T.conjTranspose).trace) ∧
    ∃ T : Matrix ι κ ℝ, value =
      a * (((1 : Matrix ι ι ℝ)-T*G)*((1 : Matrix ι ι ℝ)-T*G).conjTranspose).trace +
        v * (T*T.conjTranspose).trace := by
  let B := v • (1 : Matrix κ κ ℝ)+a • (G*G.conjTranspose)
  have hB : B.PosDef :=
    (Matrix.PosDef.one.smul hv).add_posSemidef ((Matrix.posSemidef_self_mul_conjTranspose G).smul ha.le)
  have htrace (T : Matrix ι κ ℝ) := congrArg Matrix.trace (matrix_ridge_completion G ha hv T)
  simp only [Matrix.trace_add, Matrix.trace_smul, smul_eq_mul] at htrace
  constructor
  · intro T
    rw [htrace T]
    exact le_add_of_nonneg_right (hB.posSemidef.mul_mul_conjTranspose_same _).trace_nonneg
  · refine ⟨(a • G.conjTranspose)*B⁻¹, ?_⟩
    rw [htrace]
    simp only [B, sub_self, Matrix.zero_mul, Matrix.trace_zero, add_zero]

omit [DecidableEq ι] [DecidableEq κ] in
/-- Trace of X X^T is literally the sum of squared real entries. -/
theorem frobenius_trace_formula (X : Matrix ι κ ℝ) :
    (X*X.conjTranspose).trace = ∑ i, ∑ j, (X i j)^2 := by
  simp only [Matrix.trace, Matrix.diag_apply, Matrix.mul_apply, Matrix.conjTranspose_apply, star_trivial, pow_two]

/-- Every ridge predictor has the regularized lower bound used after (7.13).
Only nonsingular Gram matrices need an inverse-trace assumption; singular ones
are covered by the zero-eigenvalue branch of matrix regularization. -/
theorem ridge_error_lower (G : Matrix κ ι ℝ) {a v Z : ℝ}
    (ha : 0 < a) (hv : 0 < v) (hZ : 0 < Z)
    (htrace : IsUnit (v⁻¹ • (G.conjTranspose*G)) →
      Z ≤ (v⁻¹ • (G.conjTranspose*G))⁻¹.trace) (T : Matrix ι κ ℝ) :
    a*Z/(a+Z) ≤
      a*(((1 : Matrix ι ι ℝ)-T*G)*((1 : Matrix ι ι ℝ)-T*G).conjTranspose).trace+
        v*(T*T.conjTranspose).trace := by
  let P := v⁻¹ • (G.conjTranspose*G)
  have hP : P.PosSemidef := (Matrix.posSemidef_conjTranspose_mul_self G).smul (inv_pos.mpr hv).le
  have hQ : (a⁻¹ • (1 : Matrix ι ι ℝ)+P).PosDef :=
    (Matrix.PosDef.one.smul (inv_pos.mpr ha)).add_posSemidef hP
  have h := matrix_regularization hP hQ (inv_pos.mpr ha) zero_lt_one hZ htrace (by simpa using (Matrix.PosSemidef.zero : (0 : Matrix ι ι ℝ).PosSemidef))
  have he : Z/(1+a⁻¹*Z) = a*Z/(a+Z) := by
    field_simp
  rw [he] at h
  exact h.trans ((paper_equation_7_12 G ha hv).1 T)

end SpectralComparison
