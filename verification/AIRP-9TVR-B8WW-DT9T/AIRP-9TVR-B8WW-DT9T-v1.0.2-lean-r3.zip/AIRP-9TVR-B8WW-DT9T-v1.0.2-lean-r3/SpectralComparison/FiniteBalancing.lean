import SpectralComparison.WeightedLimit

noncomputable section
open Finset
namespace SpectralComparison

/-- A finite sequence of fixed-sum pair balances reaches the constant mean. -/
theorem finite_balancing_bound {ι : Type*} [Fintype ι] [DecidableEq ι]
    (Φ : (ι → ℝ) → ℝ) {c : ℝ} (hc : 0 < c)
    (hstep : ∀ (b : ι → ℝ), (∀ i, 0 < b i) → ∀ i j, i ≠ j →
      ∀ u v : ℝ, 0 < u → 0 < v → b i+b j = u+v → b i*b j ≤ u*v →
      Φ b ≤ Φ (Function.update (Function.update b i u) j v))
    (b : ι → ℝ) (hb : ∀ i, 0 < b i) (hsum : (∑ i,b i) = Fintype.card ι*c) :
    Φ b ≤ Φ (fun _ => c) := by
  classical
  generalize hn : ((univ : Finset ι).filter (fun i => b i ≠ c)).card = N
  induction N using Nat.strong_induction_on generalizing b with
  | h N ih =>
    by_cases heq : ∀ i,b i = c
    · have he : b = fun _ => c := funext heq
      rw [he]
    have hbad : ∃ i,b i ≠ c := not_forall.mp heq
    have hlo : ∃ i,b i < c := by
      by_contra! hnone
      obtain ⟨i,hi⟩ := hbad
      have hlt : c < b i := lt_of_le_of_ne (hnone i) (Ne.symm hi)
      have hh := Finset.sum_lt_sum (s:=univ) (fun l _ => hnone l) ⟨i,mem_univ _,hlt⟩
      simp only [sum_const,card_univ,nsmul_eq_mul,hsum] at hh
      exact (lt_irrefl _) hh
    have hhi : ∃ j,c < b j := by
      by_contra! hnone
      obtain ⟨i,hi⟩ := hbad
      have hlt : b i < c := lt_of_le_of_ne (hnone i) hi
      have hh := Finset.sum_lt_sum (s:=univ) (fun l _ => hnone l) ⟨i,mem_univ _,hlt⟩
      simp only [sum_const,card_univ,nsmul_eq_mul,hsum] at hh
      exact (lt_irrefl _) hh
    obtain ⟨i,hi⟩ := hlo
    obtain ⟨j,hj⟩ := hhi
    have hij : i ≠ j := by intro he; subst j; linarith
    let t := min (c-b i) (b j-c)
    let u := b i+t
    let v := b j-t
    have ht : 0 < t := lt_min (by linarith) (by linarith)
    have hti : t ≤ c-b i := min_le_left _ _
    have htj : t ≤ b j-c := min_le_right _ _
    have hu : 0 < u := by dsimp [u]; linarith [hb i]
    have hv : 0 < v := by dsimp [v]; linarith
    have huv : b i+b j = u+v := by dsimp [u,v]; ring
    have hprod : b i*b j ≤ u*v := by
      have hh := mul_nonneg ht.le (show 0 ≤ b j-b i-t by linarith)
      dsimp [u,v]
      nlinarith
    let g := Function.update (Function.update b i u) j v
    have hg : ∀ l,0 < g l := by
      intro l
      by_cases hlj : l = j
      · subst l; simpa [g] using hv
      by_cases hli : l = i
      · subst l; simpa [g,hij] using hu
      simpa [g,hlj,hli] using hb l
    have hdelta (l : ι) : g l = b l+(if l=i then u-b i else 0)+(if l=j then v-b j else 0) := by
      by_cases hli : l=i
      · subst l; simp [g,hij]
      by_cases hlj : l=j
      · subst l; simp [g,Ne.symm hij]
      simp [g,hli,hlj]
    have hsumg : (∑ l,g l) = Fintype.card ι*c := by
      simp_rw [hdelta]
      rw [sum_add_distrib,sum_add_distrib]
      simp only [sum_ite_eq',mem_univ,ite_true]
      rw [hsum]
      linarith
    have hsub : univ.filter (fun l => g l ≠ c) ⊆ univ.filter (fun l => b l ≠ c) := by
      intro l hl
      refine mem_filter.mpr ⟨mem_univ _,?_⟩
      intro hlc
      have hli : l ≠ i := by intro he; subst l; linarith
      have hlj : l ≠ j := by intro he; subst l; linarith
      exact (mem_filter.mp hl).2 (by simpa [g,hli,hlj] using hlc)
    have hw : ∃ l,b l ≠ c ∧ g l = c := by
      rcases le_total (c-b i) (b j-c) with hh | hh
      · refine ⟨i,ne_of_lt hi,?_⟩
        simp [g,hij,u,t,min_eq_left hh]
      · refine ⟨j,ne_of_gt hj,?_⟩
        simp [g,v,t,min_eq_right hh]
    have hstrict : univ.filter (fun l => g l ≠ c) ⊂ univ.filter (fun l => b l ≠ c) := by
      refine (Finset.ssubset_iff_subset_ne).mpr ⟨hsub,?_⟩
      intro he
      obtain ⟨l,hb,hg⟩ := hw
      have hh : l ∈ univ.filter (fun l => g l ≠ c) := he ▸ mem_filter.mpr ⟨mem_univ _,hb⟩
      exact (mem_filter.mp hh).2 hg
    have hlt : (univ.filter (fun l => g l ≠ c)).card < N := by
      rw [← hn]
      exact card_lt_card hstrict
    exact (hstep b hb i j hij u v hu hv huv hprod).trans (ih _ hlt g hg hsumg rfl)

end SpectralComparison
