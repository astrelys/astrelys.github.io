import SpectralComparison.WeightedPrecision

noncomputable section
open Matrix
namespace SpectralComparison

/-- The E.1 weighted frame gives the exact finite-noise lower bound in the original orthogonal orbit. -/
theorem weighted_worst_lower {k m : ℕ} (hk : 1 ≤ k) (hm : 1 ≤ m)
    (eig : Fin (k+m) → ℝ) (heig : ∀ i, 0 < eig i) {a : ℝ} (ha : 0 < a)
    (hhead : ∀ i : Fin k, a ≤ eig (i.castAdd m)) :
    let s := ∑ i : Fin m, eig (i.natAdd k)
    a * (weightedGamma k m * s) / (a + weightedGamma k m * s) ≤ worstError eig k := by
  classical
  let b := fun i : Fin m => eig (i.natAdd k)
  let h := fun i : Fin k => eig (i.castAdd m)
  let L := weightedGamma k m * ∑ i,b i
  have hL : 0 < L := mul_pos (weightedGamma_pos hk hm)
    (Finset.sum_pos (fun i _ => heig _) ⟨⟨0,by omega⟩,Finset.mem_univ _⟩)
  obtain ⟨R,hR,hcost⟩ := paper_weighted_frame hk hm b (fun i => heig _)
  obtain ⟨Q,hQ,hRQ,hcomp,hV,hV'⟩ := exists_orthogonal_frame_completion (h:=Fin k) R hR
    (by simp only [Fintype.card_fin])
  have hQR : Qᴴ * R = 0 := by
    simpa only [Matrix.conjTranspose_mul, Matrix.conjTranspose_conjTranspose, Matrix.conjTranspose_zero]
      using congrArg Matrix.conjTranspose hRQ
  have hU : (Matrix.fromCols Q R)ᴴ * Matrix.fromCols Q R = 1 := by
    rw [Matrix.conjTranspose_fromCols_eq_fromRows_conjTranspose, Matrix.fromRows_mul_fromCols,
      hQ,hQR,hRQ,hR]
    exact Matrix.fromBlocks_one
  have hU' : Matrix.fromCols Q R * (Matrix.fromCols Q R)ᴴ = 1 := by
    rw [Matrix.conjTranspose_fromCols_eq_fromRows_conjTranspose, Matrix.fromCols_mul_fromRows]
    exact (add_comm _ _).trans hcomp
  have hlabels : (fun j : Fin k ⊕ Fin m => eig (finSumFinEquiv j)) = Sum.elim h b := by
    funext j
    cases j <;> rfl
  obtain ⟨O,hO,hOK⟩ := reindex_spectral_orientation (Matrix.fromCols Q R) hU hU'
    finSumFinEquiv (Equiv.refl _) eig
  simp only [Equiv.coe_refl, Matrix.submatrix_id_id, hlabels] at hOK
  rw [fromCols_spectral_synthesis] at hOK
  let K := O.transpose * diagonal eig * O
  let P := R * diagonal (fun i => (b i)⁻¹) * Rᴴ
  have hK : K.PosDef := orbit_posDef eig heig O hO
  have hP : P.PosSemidef := by
    simpa only [Matrix.conjTranspose_conjTranspose] using
      (Matrix.PosSemidef.diagonal (fun i => inv_nonneg.mpr (heig _).le)).conjTranspose_mul_mul_same Rᴴ
  have hgap : (a⁻¹ • (1 : Matrix (Fin (k+m)) (Fin (k+m)) ℝ) + P - K⁻¹).PosSemidef := by
    dsimp [K]
    rw [hOK]
    exact weighted_signal_precision_bound Q R hU hU' h b (fun i => heig _) (fun i => heig _) ha hhead
  have hblocks : ∀ J : Finset (Fin (k+m)), J.card = m → IsUnit (principal P J) →
      L ≤ (principal P J)⁻¹.trace := by
    intro J hJ hu
    let A := R.submatrix (fun i : J => (i : Fin (k+m))) id
    have hp : principal P J = A * diagonal (fun i => (b i)⁻¹) * Aᴴ := by
      dsimp [principal,P,A]
      rw [Matrix.submatrix_mul _ _ _ id _ Function.bijective_id,
        Matrix.submatrix_mul _ _ _ id id Function.bijective_id, Matrix.submatrix_id_id]
      rfl
    rw [hp] at hu ⊢
    obtain ⟨hgram,htrace⟩ := weighted_precision_inverse_trace A (by simpa only [Fintype.card_coe, Fintype.card_fin] using hJ) b (fun i => heig _) hu
    rw [htrace]
    exact hcost J hJ hgram
  have hbest : a * L / (a+L) ≤ bestError K k := by
    apply le_bestError _ (by simp)
    intro I hI
    let J := Finset.univ \ I
    have hJ : J.card = m := by
      dsimp [J]
      rw [Finset.card_sdiff_of_subset (Finset.subset_univ _), Finset.card_univ, Fintype.card_fin, hI]
      omega
    have hh := paper_equation_2_3 hP hK.inv m (inv_pos.mpr ha) (by norm_num : (0:ℝ) < 1)
      hL hblocks (by simpa only [one_smul] using hgap) J hJ
    have he : L/(1+a⁻¹*L) = a*L/(a+L) := by field_simp
    rw [he] at hh
    rw [nystrom_trace_inverse_complement hK I]
    exact hh
  exact hbest.trans (orbit_bestError_le_worstError eig heig O hO (by simp <;> omega))

end SpectralComparison
