import SpectralComparison.FullGroupModel

/-! Exact bookkeeping of every original spectral index in the diffuse model. -/
noncomputable section
namespace SpectralComparison

/-- Reorder the four disjoint spectral roles without changing any label. -/
def fourSpectralLabels {r h p s : Type*} : (((r ⊕ h) ⊕ p) ⊕ s) ≃ ((r ⊕ s) ⊕ (h ⊕ p)) where
  toFun := Sum.elim (Sum.elim (Sum.elim (fun i => Sum.inl (Sum.inl i))
    (fun i => Sum.inr (Sum.inl i))) (fun i => Sum.inr (Sum.inr i))) (fun i => Sum.inl (Sum.inr i))
  invFun := Sum.elim (Sum.elim (fun i => Sum.inl (Sum.inl (Sum.inl i))) (fun i => Sum.inr i))
    (Sum.elim (fun i => Sum.inl (Sum.inl (Sum.inr i))) (fun i => Sum.inl (Sum.inr i)))
  left_inv := by intro i; rcases i with ((i|i)|i)|i <;> rfl
  right_inv := by intro i; rcases i with (i|i)|(i|i) <;> rfl

/-- The reserve and its complement exhaust the remaining original labels exactly once. -/
def reservePartitionEquiv {p : ℕ} (S : Finset (Fin p)) : (S ⊕ ↥Sᶜ) ≃ Fin p where
  toFun := Sum.elim Subtype.val Subtype.val
  invFun := fun i => if hi : i∈S then Sum.inl ⟨i,hi⟩ else Sum.inr ⟨i,Finset.mem_compl.mpr hi⟩
  left_inv := by
    intro i
    cases i with
    | inl i => simp [i.property]
    | inr i => simp [Finset.mem_compl.mp i.property]
  right_inv := by intro i; dsimp only; split_ifs <;> rfl

/-- Signal, reserve, grouped tail and singleton labels map to their exact original spectrum indices. -/
theorem exists_diffuse_spectral_labels {n k q p : ℕ} (hq : q≤k) (hn : n=9*k+p)
    (S : Finset (Fin p)) :
    ∃ e : ((((Fin (k-q) ⊕ S) ⊕ ↥Sᶜ) ⊕ Fin (q+8*k))) ≃ Fin n,
      (∀ i,(e (Sum.inl (Sum.inl (Sum.inl i)))).val=i.val) ∧
      (∀ i,(e (Sum.inl (Sum.inl (Sum.inr i)))).val=9*k+i.val.val) ∧
      (∀ i,(e (Sum.inl (Sum.inr i))).val=9*k+i.val.val) ∧
      (∀ i,(e (Sum.inr i)).val=k-q+i.val) := by
  let a : (Fin (k-q) ⊕ Fin (q+8*k)) ≃ Fin (9*k) :=
    finSumFinEquiv.trans (finCongr (by omega))
  let e := (fourSpectralLabels (r:=Fin (k-q)) (h:=S) (p:=↥Sᶜ) (s:=Fin (q+8*k))).trans
    ((Equiv.sumCongr a (reservePartitionEquiv S)).trans (finSumFinEquiv.trans (finCongr hn.symm)))
  refine ⟨e,?_,?_,?_,?_⟩ <;> intro i <;> rfl

end SpectralComparison
