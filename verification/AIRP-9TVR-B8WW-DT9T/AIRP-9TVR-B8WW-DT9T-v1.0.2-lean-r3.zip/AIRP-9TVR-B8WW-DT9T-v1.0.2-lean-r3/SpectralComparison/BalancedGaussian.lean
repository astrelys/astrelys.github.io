import SpectralComparison.GaussianUniform

/-! Sharper normalization for the balanced square-basis construction. -/
noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

/-- The balanced 2k by k lower tail with the manuscript's parameter 10^6. -/
theorem balanced_vector_small_ball {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {k : ℕ}
    (G : Ω → Matrix (Fin (2*k)) (Fin k) ℝ)
    (hG : ∀ a : Fin (2*k) × Fin k, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin (2*k) × Fin k => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : Fin (2*k) × Fin k, Measurable (fun ω => G ω a.1 a.2))
    (v : EuclideanSpace ℝ (Fin k)) (hv : ‖v‖=1) :
    μ.real {ω | ‖(G ω).toEuclideanLin v‖^2 ≤ (k:ℝ)/1000000} ≤
      (3/2000000:ℝ)^k := by
  have h := gaussian_vector_norm_lower G hG hind hm v hv ((k:ℝ)/1000000) (-1000000) (by norm_num)
  have he : -(-1000000:ℝ)*((k:ℝ)/1000000) = k := by ring
  have hr : (1-2*(-1000000:ℝ))^(-(Fintype.card (Fin (2*k)):ℝ)/2) =
      ((2000001:ℝ)⁻¹)^k := by
    norm_num only [Fintype.card_fin, Nat.cast_mul, Nat.cast_ofNat]
    rw [show -(2*(k:ℝ))/2 = -(k:ℝ) by ring, Real.rpow_neg (by norm_num), Real.rpow_natCast]
    simp only [one_div, inv_pow]
  rw [he, hr] at h
  apply h.trans
  calc
    _ ≤ (3:ℝ)^k * ((2000001:ℝ)⁻¹)^k := by
      gcongr
      rw [show (k:ℝ)=(k:ℝ)*1 by ring, Real.exp_nat_mul]
      exact pow_le_pow_left₀ (by positivity) Real.exp_one_lt_three.le k
    _ = (3*(2000001:ℝ)⁻¹)^k := by rw [mul_pow]
    _ ≤ _ := pow_le_pow_left₀ (by positivity) (by norm_num) k

/-- A 1/20000 net has a simultaneous small-ball failure probability at most 16^-k. -/
theorem exists_balanced_small_ball_net {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {k : ℕ}
    (G : Ω → Matrix (Fin (2*k)) (Fin k) ℝ)
    (hG : ∀ a : Fin (2*k) × Fin k, HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin (2*k) × Fin k => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : Fin (2*k) × Fin k, Measurable (fun ω => G ω a.1 a.2)) :
    ∃ s : Finset (EuclideanSpace ℝ (Fin k)),
      (∀ x : EuclideanSpace ℝ (Fin k), ‖x‖=1 → ∃ v ∈ s, ‖x-v‖ ≤ 1/20000) ∧
      μ.real {ω | ∃ v ∈ s, ‖(G ω).toEuclideanLin v‖^2 ≤ (k:ℝ)/1000000} ≤ (1/16:ℝ)^k := by
  obtain ⟨s,hs,hcard,hnet⟩ := exists_sphere_net_card_le (E := EuclideanSpace ℝ (Fin k))
    (η := (1/20000:ℝ)) (by norm_num)
  have hc : (s.card:ℝ) ≤ (40001:ℝ)^k := by norm_num at hcard; exact hcard
  refine ⟨s,hnet,?_⟩
  have h := finite_union_probability_bound s
    (fun v => {ω | ‖(G ω).toEuclideanLin v‖^2 ≤ (k:ℝ)/1000000})
    (fun v hv => balanced_vector_small_ball G hG hind hm v (hs v hv))
  apply h.trans
  calc
    _ ≤ (40001:ℝ)^k*(3/2000000:ℝ)^k := by gcongr
    _ = (40001*(3/2000000:ℝ))^k := by rw [mul_pow]
    _ ≤ _ := pow_le_pow_left₀ (by positivity) (by norm_num) k

/-- The balanced fine net and operator bound give the exact sqrt(k)/2000 lower singular bound. -/
theorem balanced_net_lower_singular {k : ℕ} (G : Matrix (Fin (2*k)) (Fin k) ℝ)
    (s : Finset (EuclideanSpace ℝ (Fin k)))
    (hnet : ∀ x : EuclideanSpace ℝ (Fin k), ‖x‖=1 → ∃ v ∈ s, ‖x-v‖ ≤ 1/20000)
    (hupper : ‖G.toEuclideanLin.toContinuousLinearMap‖ ≤ 10*Real.sqrt k)
    (hlower : ∀ v ∈ s, (k:ℝ)/1000000 < ‖G.toEuclideanLin v‖^2) :
    ∀ x : EuclideanSpace ℝ (Fin k), ‖x‖=1 → Real.sqrt k/2000 ≤ ‖G.toEuclideanLin x‖ := by
  have hb (v) (hv : v ∈ s) : Real.sqrt (k:ℝ)/1000 ≤ ‖G.toEuclideanLin v‖ := by
    nlinarith [hlower v hv, Real.sq_sqrt (Nat.cast_nonneg k), norm_nonneg (G.toEuclideanLin v), Real.sqrt_nonneg (k:ℝ)]
  have h := norm_lower_of_sphere_net G.toEuclideanLin.toContinuousLinearMap s (by norm_num) hupper hnet hb
  intro x hx
  have hh := h x hx
  change _ ≤ ‖G.toEuclideanLin x‖ at hh
  linarith

end SpectralComparison
