import SpectralComparison.TwoLevelResidual
import SpectralComparison.SingletonSpectrum
import SpectralComparison.Diagonal

/-! Actual two-level spectra, their orthogonal realizations, and diagonal tail bounds. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- The spectral list (1^k,epsilon^m), with repetitions represented by Fin indices. -/
def twoLevelSpectrum (k m : ℕ) (ε : ℝ) : Fin (k+m) → ℝ :=
  fun i => if i.val<k then 1 else ε

theorem twoLevelSpectrum_pos {k m : ℕ} {ε : ℝ} (hε : 0<ε) :
    ∀ i,0<twoLevelSpectrum k m ε i := by
  intro i
  unfold twoLevelSpectrum
  split_ifs <;> positivity

/-- Every Parseval k-frame realizes the stated two-level spectrum in the original orthogonal orbit. -/
theorem two_level_covariance_orientation {k m : ℕ}
    (Q : Matrix (Fin (k+m)) (Fin k) ℝ) (hQ : Qᴴ*Q=1) (ε : ℝ) :
    ∃ O : Matrix (Fin (k+m)) (Fin (k+m)) ℝ,O.transpose*O=1 ∧
      O.transpose*Matrix.diagonal (twoLevelSpectrum k m ε)*O=
        ε • (1 : Matrix (Fin (k+m)) (Fin (k+m)) ℝ)+(1-ε) • (Q*Qᴴ) := by
  obtain ⟨R,_,_,hQR,hV,hV'⟩ := exists_orthogonal_frame_completion (h:=Fin m) Q hQ
    (by simp only [Fintype.card_fin]; omega)
  let V := Matrix.fromCols Q R
  have heig : (fun j : Fin k ⊕ Fin m => twoLevelSpectrum k m ε (finSumFinEquiv j))=
      Sum.elim (fun _ : Fin k => (1:ℝ)) (fun _ : Fin m => ε) := by
    funext j
    cases j with
    | inl i => simp [twoLevelSpectrum,finSumFinEquiv,i.isLt]
    | inr i => simp [twoLevelSpectrum,finSumFinEquiv]
  obtain ⟨O,hO,he⟩ := reindex_spectral_orientation V hV hV' finSumFinEquiv
    (Equiv.refl (Fin (k+m))) (twoLevelSpectrum k m ε)
  refine ⟨O,hO,?_⟩
  rw [he]
  simp only [Equiv.coe_refl,Matrix.submatrix_id_id,heig]
  rw [fromCols_spectral_synthesis]
  have h1 : Matrix.diagonal (fun _ : Fin k => (1:ℝ))=1 := Matrix.diagonal_one
  have hε : Matrix.diagonal (fun _ : Fin m => ε)=ε • (1 : Matrix (Fin m) (Fin m) ℝ) := by
    ext i j; simp [Matrix.diagonal_apply,Matrix.one_apply]
  rw [h1,hε,Matrix.mul_one,Matrix.mul_smul,Matrix.smul_mul,Matrix.mul_one]
  have hR : R*Rᴴ=1-Q*Qᴴ := eq_sub_of_add_eq' hQR
  rw [hR,smul_sub]
  module

/-- The literal minimum for a constructed frame is below the original worst orientation. -/
theorem two_level_frame_bestError_le {k m : ℕ} (hm : 1≤m)
    (Q : Matrix (Fin (k+m)) (Fin k) ℝ) (hQ : Qᴴ*Q=1)
    {ε : ℝ} (hε : 0<ε) :
    bestError (ε • (1 : Matrix (Fin (k+m)) (Fin (k+m)) ℝ)+(1-ε) • (Q*Qᴴ)) k ≤
      worstError (twoLevelSpectrum k m ε) k := by
  obtain ⟨O,hO,he⟩ := two_level_covariance_orientation Q hQ ε
  rw [← he]
  exact orbit_bestError_le_worstError _ (twoLevelSpectrum_pos hε) O hO (by simp; omega)

/-- Diagonal lower and elementary-quotient upper bounds with exactly m tail entries. -/
theorem two_level_tail_bounds {k m : ℕ} (hm : 1≤m) {ε : ℝ} (hε : 0<ε) (hε1 : ε≤1) :
    (m:ℝ)*ε≤worstError (twoLevelSpectrum k m ε) k ∧
    spectralMean (twoLevelSpectrum k m ε) k≤((k:ℝ)+1)*(m:ℝ)*ε := by
  let T := Finset.Iio (⟨k,by omega⟩ : Fin (k+m))
  have hT : T.card=k := Fin.card_Iio _
  have hmem (i : Fin (k+m)) : i∈T ↔ i.val<k := by simp [T,Fin.lt_def]
  have he (i : Fin (k+m)) (hi : i∉T) : twoLevelSpectrum k m ε i=ε := by
    simp [twoLevelSpectrum,show ¬i.val<k from fun h => hi ((hmem i).mpr h)]
  have hsum : (∑ j ∈ Finset.univ \ T,twoLevelSpectrum k m ε j)=(m:ℝ)*ε := by
    calc
      _ = ∑ _j ∈ Finset.univ \ T,ε := Finset.sum_congr rfl (fun j hj => he j (Finset.mem_sdiff.mp hj).2)
      _ = _ := by simp [Finset.card_sdiff,hT]
  have hsep : ∀ i∈T,∀ j∉T,twoLevelSpectrum k m ε j≤twoLevelSpectrum k m ε i := by
    intro i hi j hj
    rw [he j hj]
    simpa [twoLevelSpectrum,(hmem i).mp hi] using hε1
  have hl := tail_le_worstError _ (twoLevelSpectrum_pos hε) T hsep (by rw [hT]; simp; omega)
  have hu := spectralMean_le_tail _ (twoLevelSpectrum_pos hε) T
  rw [hT,hsum] at hl hu
  exact ⟨hl,by nlinarith [hu]⟩

/-- The non-diagonal part of equation (A.5), proved for the actual worst-orientation objective. -/
theorem balanced_two_level_worst_lower {k : ℕ} (hk : 4≤k) {ε : ℝ} (hε : 0<ε) (hε1 : ε≤1) :
    let L := (k:ℝ)*Real.sqrt k/4000000000
    max ((k:ℝ)*ε) (ε*L/(1+ε*L))≤worstError (twoLevelSpectrum k k ε) k := by
  obtain ⟨V,hV,hb⟩ := exists_balanced_parseval_frame hk
  obtain ⟨Q,hQ,hQb⟩ := reindex_frame_control V hV (fun J hJ _ => (hb J hJ).2)
    (finCongr (by omega : k+k=2*k))
  have hL : 0<(k:ℝ)*Real.sqrt k/4000000000 := by
    have : (0:ℝ)<k := by exact_mod_cast (by omega : 0<k)
    positivity
  have hl : ε*((k:ℝ)*Real.sqrt k/4000000000)/(1+ε*((k:ℝ)*Real.sqrt k/4000000000))≤
      bestError (ε • (1 : Matrix (Fin (k+k)) (Fin (k+k)) ℝ)+(1-ε) • (Q*Qᴴ)) k := by
    apply le_bestError _ (by simp)
    intro I hI
    exact balanced_two_level_residual_lower (by omega) Q hQ hL hε hε1 hQb I hI

  exact max_le (two_level_tail_bounds (by omega : 1≤k) hε hε1).1
    (hl.trans (two_level_frame_bestError_le (by omega : 1≤k) Q hQ hε))

end SpectralComparison
