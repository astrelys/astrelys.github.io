import SpectralComparison.ZeroDiagonal

/-! The zero-diagonal group block used in equation (7.4). -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Diagonal entries of an orthogonal spectral synthesis are weighted row squares. -/
theorem spectral_synthesis_diagonal {n : Type*} [Fintype n] [DecidableEq n]
    (W : Matrix n n ℝ) (d : n → ℝ) (i : n) :
    (W*Matrix.diagonal d*Wᴴ) i i=∑ j,d j*(W i j)^2 := by
  simp only [Matrix.mul_apply,Matrix.diagonal_apply,Matrix.conjTranspose_apply,star_trivial]
  simp [sq,mul_comm,mul_left_comm]

/-- A positive-weight group admits the exact diagonal balance and a nowhere-zero kernel direction.
The displayed orthogonal synthesis retains its full prescribed spectrum (0,d). -/
theorem exists_diffuse_group_block {p : Type*} [Fintype p] [DecidableEq p] (d : p → ℝ) (hd : ∀ j,0<d j) :
    ∃ W : Matrix (Fin 1 ⊕ p) (Fin 1 ⊕ p) ℝ,
      Wᴴ*W=1 ∧ W*Wᴴ=1 ∧
      let u := fun i => W i (Sum.inl 0)
      let D := W*Matrix.diagonal (Sum.elim (fun _ : Fin 1 => (0:ℝ)) d)*Wᴴ
      D.PosSemidef ∧ (∑ i,u i*u i)=1 ∧ D.mulVec u=0 ∧
      (∀ i,D i i=(∑ j,d j)*(u i)^2) ∧ (∀ i,u i≠0) := by
  classical
  let v := ∑ j,d j
  let a : Fin 1 ⊕ p → ℝ := Sum.elim (fun _ => -v) d
  have htr : (Matrix.diagonal a).trace=0 := by simp [a,v,Matrix.trace_diagonal,Fintype.sum_sum_type]
  obtain ⟨V,hV,hVd⟩ := exists_orthogonal_zero_diagonal_finite (Matrix.diagonal a)
    (Matrix.isHermitian_diagonal a) htr
  let W := Vᴴ
  have hW : Wᴴ*W=1 := by simpa only [W,Matrix.conjTranspose_conjTranspose] using mul_eq_one_comm.mp hV
  have hW' : W*Wᴴ=1 := by simpa only [W,Matrix.conjTranspose_conjTranspose] using hV
  let u := fun i => W i (Sum.inl 0)
  let b : Fin 1 ⊕ p → ℝ := Sum.elim (fun _ => (0:ℝ)) d
  let D := W*Matrix.diagonal b*Wᴴ
  have hD : D.PosSemidef := by
    have hh := (Matrix.PosSemidef.diagonal (show ∀ i,0≤b i by intro i; cases i with | inl i => exact le_rfl | inr i => exact (hd i).le)).conjTranspose_mul_mul_same Wᴴ
    simpa only [Matrix.conjTranspose_conjTranspose] using hh
  have hu : (∑ i,u i*u i)=1 := by
    have hh := congrFun (congrFun hW (Sum.inl 0)) (Sum.inl 0)
    simpa [u,Matrix.mul_apply,Matrix.conjTranspose_apply] using hh
  have hdiag (i) : D i i=v*(u i)^2 := by
    have hz := hVd i
    change (W*Matrix.diagonal a*Wᴴ) i i=0 at hz
    rw [spectral_synthesis_diagonal] at hz
    simp only [a,Fintype.sum_sum_type,Sum.elim_inl,Sum.elim_inr,Fin.sum_univ_one] at hz
    change (W*Matrix.diagonal b*Wᴴ) i i=_
    rw [spectral_synthesis_diagonal]
    simp only [b,Fintype.sum_sum_type,Sum.elim_inl,Sum.elim_inr,zero_mul,Finset.sum_const_zero,zero_add]
    dsimp [u]
    linarith
  have huneq (i) : u i≠0 := by
    intro hz
    have hzero : ∑ j : p,d j*(W i (Sum.inr j))^2=0 := by
      have hh := hdiag i
      rw [hz,pow_two,mul_zero,mul_zero] at hh
      change (W*Matrix.diagonal b*Wᴴ) i i=0 at hh
      rw [spectral_synthesis_diagonal] at hh
      simpa [b,Fintype.sum_sum_type] using hh
    have hall : ∀ j,W i (Sum.inr j)=0 := by
      intro j
      have hn := (Finset.sum_eq_zero_iff_of_nonneg (fun j _ => mul_nonneg (hd j).le (sq_nonneg _))).mp hzero j (Finset.mem_univ j)
      have hs := (mul_eq_zero.mp hn).resolve_left (ne_of_gt (hd j))
      nlinarith [sq_nonneg (W i (Sum.inr j))]
    have hh := congrFun (congrFun hW' i) i
    have hleft : W i (Sum.inl (0:Fin 1))=0 := hz
    simp [Matrix.mul_apply,Fintype.sum_sum_type,hleft,hall] at hh
  have hker : D.mulVec u=0 := by
    have he : u=W.mulVec (Pi.single (Sum.inl 0) 1) := by ext i; simp [u]
    rw [he]
    change (W*Matrix.diagonal b*Wᴴ).mulVec (W.mulVec _)=0
    rw [Matrix.mulVec_mulVec]
    have hh : (W*Matrix.diagonal b*Wᴴ)*W=W*Matrix.diagonal b := by
      rw [Matrix.mul_assoc (W*Matrix.diagonal b),hW,Matrix.mul_one]
    rw [hh,← Matrix.mulVec_mulVec,Matrix.diagonal_mulVec_single]
    simp [b]
  exact ⟨W,hW,hW',hD,hu,hker,hdiag,huneq⟩

end SpectralComparison
