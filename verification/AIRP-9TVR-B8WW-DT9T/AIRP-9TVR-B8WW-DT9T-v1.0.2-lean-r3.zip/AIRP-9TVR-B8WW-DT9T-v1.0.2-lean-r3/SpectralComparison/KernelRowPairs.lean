import SpectralComparison.KernelGeometry

/-! Literal disjoint row sets inherit the unconditional projected-kernel tail. -/
noncomputable section
open Matrix MeasureTheory ProbabilityTheory
namespace SpectralComparison

/-- The basis-free statistic is invariant under independent row enumerations. -/
theorem kernelInverseTrace_row_reindex {h h' l l' p : Type*}
    [Fintype h] [Fintype h'] [Fintype l] [Fintype l'] [Fintype p]
    [DecidableEq h] [DecidableEq h'] [DecidableEq p]
    (H : Matrix h p ℝ) (X : Matrix l p ℝ) (e : h' ≃ h) (f : l' ≃ l) :
    kernelInverseTrace (H.submatrix e id) (X.submatrix f id)=kernelInverseTrace H X := by
  have hE : (H.submatrix e id)ᴴ*((H.submatrix e id)*(H.submatrix e id)ᴴ)⁻¹*(H.submatrix e id)=Hᴴ*(H*Hᴴ)⁻¹*H := by
    have hg : H.submatrix e id * Hᴴ.submatrix id e=(H*Hᴴ).submatrix e e :=
      (Matrix.submatrix_mul H Hᴴ e id e Function.bijective_id).symm
    rw [Matrix.conjTranspose_submatrix,hg,Matrix.inv_submatrix_equiv,
      Matrix.submatrix_mul_equiv,Matrix.submatrix_mul_equiv,Matrix.submatrix_id_id]
  unfold kernelInverseTrace
  rw [hE]
  have hdim : Fintype.card h'=Fintype.card h := Fintype.card_congr e
  rw [hdim]
  have hX : (X.submatrix f id)ᴴ*(X.submatrix f id)=Xᴴ*X := by
    rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,Matrix.submatrix_id_id]
  simp only [Matrix.mul_assoc]
  rw [← Matrix.mul_assoc (X.submatrix f id)ᴴ, hX]
  simp only [Matrix.mul_assoc]

set_option maxHeartbeats 1200000 in
/-- An arbitrary disjoint pair of row subsets obeys the sharp fixed-pair tail bound. -/
theorem gaussian_disjoint_row_pair_tail {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {N p : ℕ}
    (X : Ω → Matrix (Fin N) (Fin p) ℝ)
    (hX : ∀ a : Fin N × Fin p, HasLaw (fun ω => X ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin N × Fin p => fun ω => X ω a.1 a.2) μ)
    (H L : Finset (Fin N)) (hdis : Disjoint H L)
    (hd : 1≤p-H.card) (hl : 4≤L.card) (hdl : p-H.card≤L.card) :
    μ.real {ω | kernelInverseTrace ((X ω).submatrix (fun i : H => (i:Fin N)) id)
      ((X ω).submatrix (fun i : L => (i:Fin N)) id) ≤
      (p-H.card:ℕ)/(1000*((L.card-(p-H.card):ℕ)+Real.sqrt L.card))} ≤
      2*Real.exp (-31*(L.card:ℝ)) := by
  let e : Fin H.card ≃ H := (finCongr (Fintype.card_coe H).symm).trans (Fintype.equivFin H).symm
  let f : Fin L.card ≃ L := (finCongr (Fintype.card_coe L).symm).trans (Fintype.equivFin L).symm
  let g : Fin L.card ⊕ Fin H.card → Fin N := Sum.elim (fun i => (f i:Fin N)) (fun j => (e j:Fin N))
  have hg : Function.Injective g := by
    intro a b hab
    cases a with
    | inl a =>
      cases b with
      | inl b => exact congrArg Sum.inl (f.injective (Subtype.ext hab))
      | inr b =>
        change (f a:Fin N)=(e b:Fin N) at hab
        exact False.elim (Finset.disjoint_left.mp hdis (e b).property (hab ▸ (f a).property))
    | inr a =>
      cases b with
      | inl b =>
        change (e a:Fin N)=(f b:Fin N) at hab
        exact False.elim (Finset.disjoint_left.mp hdis (e a).property (hab.symm ▸ (f b).property))
      | inr b => exact congrArg Sum.inr (e.injective (Subtype.ext hab))
  let W := fun ω => (X ω).submatrix g id
  have hw (a : (Fin L.card ⊕ Fin H.card) × Fin p) :
      HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ := hX (g a.1,a.2)
  have hi : iIndepFun (fun a : (Fin L.card ⊕ Fin H.card) × Fin p => fun ω => W ω a.1 a.2) μ :=
    hind.precomp (hg.prodMap Function.injective_id)
  have hb := gaussian_kernel_inverse_trace_tail W hw hi hd hl hdl
  have heq (ω : Ω) : kernelInverseTrace ((W ω).submatrix Sum.inr id) ((W ω).submatrix Sum.inl id) =
      kernelInverseTrace ((X ω).submatrix (fun i : H => (i:Fin N)) id)
        ((X ω).submatrix (fun i : L => (i:Fin N)) id) :=
    kernelInverseTrace_row_reindex
      ((X ω).submatrix (fun i : H => (i:Fin N)) id)
      ((X ω).submatrix (fun i : L => (i:Fin N)) id) e f
  simpa only [heq] using hb

end SpectralComparison
