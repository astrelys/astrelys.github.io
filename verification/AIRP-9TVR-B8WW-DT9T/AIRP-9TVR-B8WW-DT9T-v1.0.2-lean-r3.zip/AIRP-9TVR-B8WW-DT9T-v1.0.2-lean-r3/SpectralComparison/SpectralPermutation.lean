import SpectralComparison.SingletonSpectrum
import Mathlib.Data.Fin.Tuple.Sort

/-! Spectral order is an internal choice, not a restriction on the main theorem. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Permuting eigenvalue labels leaves the entire set of orthogonal-orbit best errors unchanged. -/
theorem orbitErrors_comp_equiv {n : ℕ} (eig : Fin n → ℝ) (e : Equiv.Perm (Fin n)) (k : ℕ) :
    orbitErrors (eig ∘ e) k=orbitErrors eig k := by
  have hsub (eig : Fin n → ℝ) (e : Equiv.Perm (Fin n)) : orbitErrors (eig ∘ e) k⊆orbitErrors eig k := by
    rintro b ⟨V,hV,rfl⟩
    change V.transpose*V=1 at hV
    have ht : V.transpose=Vᴴ := by ext i j; simp
    have horth : Vᴴ*V=1 := by simpa only [ht] using hV
    have horth' : V*Vᴴ=1 := mul_eq_one_comm.mp horth
    obtain ⟨O,hO,hcov⟩ := reindex_spectral_orientation Vᴴ
      (by simpa only [Matrix.conjTranspose_conjTranspose] using horth')
      (by simpa only [Matrix.conjTranspose_conjTranspose] using horth) e (Equiv.refl (Fin n)) eig
    refine ⟨O,hO,?_⟩
    dsimp only
    rw [hcov]
    simp only [Equiv.coe_refl,Matrix.submatrix_id_id,Matrix.conjTranspose_conjTranspose,ht,Function.comp_def]
  apply Set.Subset.antisymm (hsub eig e)
  have hh := hsub (eig ∘ e) e.symm
  simpa only [Function.comp_def,Equiv.apply_symm_apply] using hh

/-- The literal worst-orientation objective is invariant under spectral permutations. -/
theorem worstError_comp_equiv {n : ℕ} (eig : Fin n → ℝ) (e : Equiv.Perm (Fin n)) (k : ℕ) :
    worstError (eig ∘ e) k=worstError eig k := by
  exact congrArg sSup (orbitErrors_comp_equiv eig e k)

/-- The determinant-weighted spectral mean is invariant under spectral permutations. -/
theorem spectralMean_comp_equiv {n : ℕ} (eig : Fin n → ℝ) (e : Equiv.Perm (Fin n)) (k : ℕ) :
    spectralMean (eig ∘ e) k=spectralMean eig k := by
  have hm : Finset.univ.val.map (eig ∘ e)=Finset.univ.val.map eig := by
    have he : (Finset.univ.map e.toEmbedding : Finset (Fin n))=Finset.univ := by ext i; simp
    have hh := congrArg (fun s : Finset (Fin n) => s.val.map eig) he
    simpa only [Finset.map_val,Multiset.map_map,Equiv.coe_toEmbedding] using hh
  simp only [spectralMean,hm]

end SpectralComparison
