import SpectralComparison.UniformProjection

/-! Deterministic kernel whitening and basis invariance for the robust frame lemma. -/
noncomputable section
open Matrix
open scoped MatrixOrder
namespace SpectralComparison

/-- The trace of a product of positive-semidefinite matrices is nonnegative. -/
theorem trace_mul_posSemidef_nonneg {p : Type*} [Fintype p] [DecidableEq p]
    {A B : Matrix p p ℝ} (hA : A.PosSemidef) (hB : B.PosSemidef) : 0 ≤ (A*B).trace := by
  let R := CFC.sqrt B
  have hR : R.IsHermitian := (CFC.sqrt_nonneg B).posSemidef.isHermitian
  have hRR : R*R=B := CFC.sqrt_mul_sqrt_self B hB.nonneg
  have h := (hA.conjTranspose_mul_mul_same R).trace_nonneg
  rw [hR.eq,Matrix.trace_mul_cycle, hRR] at h
  rwa [Matrix.trace_mul_comm] at h

/-- A scalar Loewner lower bound transfers through a positive inverse in a trace product. -/
theorem trace_product_lower {p : Type*} [Fintype p] [DecidableEq p]
    {A B : Matrix p p ℝ} (hB : B.PosSemidef) {a : ℝ}
    (hA : (A-a • (1 : Matrix p p ℝ)).PosSemidef) : a*B.trace ≤ (A*B).trace := by
  have h := trace_mul_posSemidef_nonneg hA hB
  simp only [Matrix.sub_mul,Matrix.smul_mul,Matrix.one_mul,Matrix.trace_sub,Matrix.trace_smul,
    smul_eq_mul] at h
  linarith

/-- Orthonormal compression preserves a scalar positive-semidefinite lower bound. -/
theorem compressed_scalar_lower {p d : Type*} [Fintype p] [Fintype d]
    [DecidableEq p] [DecidableEq d] (R : Matrix p d ℝ) (hR : Rᴴ*R=1)
    {S : Matrix p p ℝ} {a : ℝ} (hS : (S-a • (1 : Matrix p p ℝ)).PosSemidef) :
    (Rᴴ*S*R-a • (1 : Matrix d d ℝ)).PosSemidef := by
  simpa only [Matrix.mul_sub,Matrix.sub_mul,Matrix.mul_smul,Matrix.smul_mul,
    Matrix.mul_one,hR] using hS.conjTranspose_mul_mul_same R

/-- The inverse square root gives the expected inverse-Gram trace identity. -/
theorem inverse_trace_whitened_columns {l d : Type*} [Fintype l] [Fintype d]
    [DecidableEq d] (A : Matrix l d ℝ) {B C : Matrix d d ℝ}
    (hC : C.PosDef) (hCC : C*C=B⁻¹) (hB : B.PosDef) :
    ((A*C)ᴴ*(A*C))⁻¹.trace = (B*(Aᴴ*A)⁻¹).trace := by
  let _ : Invertible B := hB.isUnit.invertible
  have hiCC : C⁻¹*C⁻¹=B := by
    rw [← Matrix.mul_inv_rev,hCC,Matrix.inv_inv_of_invertible]
  have he : (A*C)ᴴ*(A*C)=C*(Aᴴ*A)*C := by
    simp only [Matrix.conjTranspose_mul,hC.isHermitian.eq,Matrix.mul_assoc]
  have hei : (C*(Aᴴ*A)*C)⁻¹=C⁻¹*(Aᴴ*A)⁻¹*C⁻¹ := by
    rw [Matrix.mul_inv_rev (C*(Aᴴ*A)) C,Matrix.mul_inv_rev C (Aᴴ*A),Matrix.mul_assoc]
  rw [he,hei,Matrix.trace_mul_cycle,hiCC]

/-- Equal orthogonal projectors induce an orthogonal change of basis. -/
theorem kernel_basis_change {p d : Type*} [Fintype p] [Fintype d] [DecidableEq d]
    (U V : Matrix p d ℝ) (_hU : Uᴴ*U=1) (hV : Vᴴ*V=1) (hUV : U*Uᴴ=V*Vᴴ) :
    ∃ O : Matrix d d ℝ, Oᴴ*O=1 ∧ V=U*O := by
  let O := Uᴴ*V
  have hrecover : U*O=V := by
    dsimp [O]
    rw [← Matrix.mul_assoc,hUV,Matrix.mul_assoc,hV,Matrix.mul_one]
  refine ⟨O,?_,hrecover.symm⟩
  dsimp [O]
  rw [Matrix.conjTranspose_mul,Matrix.conjTranspose_conjTranspose]
  calc
    Vᴴ*U*(Uᴴ*V)=Vᴴ*(U*Uᴴ)*V := by simp only [Matrix.mul_assoc]
    _ = Vᴴ*(V*Vᴴ)*V := by rw [hUV]
    _ = 1 := by simp only [← Matrix.mul_assoc,hV,Matrix.one_mul]

/-- The compressed inverse-Gram trace is invariant under the orthonormal kernel basis. -/
theorem kernel_basis_inverse_trace_invariant {l p d : Type*} [Fintype l] [Fintype p]
    [Fintype d] [DecidableEq d] (X : Matrix l p ℝ) (U V : Matrix p d ℝ)
    (hU : Uᴴ*U=1) (hV : Vᴴ*V=1) (hUV : U*Uᴴ=V*Vᴴ) :
    ((X*U)ᴴ*(X*U))⁻¹.trace=((X*V)ᴴ*(X*V))⁻¹.trace := by
  obtain ⟨O,hO,rfl⟩ := kernel_basis_change U V hU hV hUV
  have hO' : O*Oᴴ=1 := mul_eq_one_comm.mp hO
  have h := trace_inverse_unitary_conjugate ((X*U)ᴴ*(X*U)) Oᴴ
    (by simpa only [Matrix.conjTranspose_conjTranspose] using hO')
  simpa only [Matrix.conjTranspose_mul,Matrix.conjTranspose_conjTranspose,Matrix.mul_assoc] using h.symm

/-- Build the orthonormal basis after whitening, and preserve the compressed data exactly.
Only annihilation is asserted here; completeness of the kernel basis is a separate dimension step. -/
theorem exists_whitened_kernel_columns {h l p d : Type*} [Fintype h] [Fintype l]
    [Fintype p] [Fintype d] [DecidableEq p] [DecidableEq d]
    (H : Matrix h p ℝ) (X : Matrix l p ℝ) (R : Matrix p d ℝ)
    (hR : Rᴴ*R=1) (hHR : H*R=0) {S : Matrix p p ℝ} (hS : S.PosDef) :
    ∃ (W : Matrix p p ℝ) (U : Matrix p d ℝ) (C : Matrix d d ℝ),
      W.PosDef ∧ W*S*W=1 ∧ W*W=S⁻¹ ∧ Uᴴ*U=1 ∧ (H*W)*U=0 ∧
      C.PosDef ∧ C*C=(Rᴴ*S*R)⁻¹ ∧ (X*W)*U=(X*R)*C := by
  let A := CFC.sqrt S
  have hA : A.PosDef := (CFC.sqrt_nonneg S).posSemidef.posDef_iff_isUnit.mpr
    ((CFC.isUnit_sqrt_iff S hS.posSemidef.nonneg).mpr hS.isUnit)
  have hAA : A*A=S := CFC.sqrt_mul_sqrt_self S hS.posSemidef.nonneg
  have hai : A⁻¹*A=1 := Matrix.nonsing_inv_mul A (isUnit_iff_ne_zero.mpr hA.det_pos.ne')
  have hia : A*A⁻¹=1 := Matrix.mul_nonsing_inv A (isUnit_iff_ne_zero.mpr hA.det_pos.ne')
  have hB := orthonormal_compression_posDef hS R hR
  obtain ⟨C,hC,hCBC,hCC⟩ := exists_inverse_sqrt hB
  refine ⟨A⁻¹,A*R*C,C,hA.inv,?_,?_,?_,?_,hC,hCC,?_⟩
  · rw [← hAA,← Matrix.mul_assoc,hai,Matrix.one_mul,hia]
  · rw [← hAA,Matrix.mul_inv_rev]
  · simp only [Matrix.conjTranspose_mul,hC.isHermitian.eq,hA.isHermitian.eq]
    calc
      C*(Rᴴ*A)*(A*R*C) = C*(Rᴴ*(A*A)*R)*C := by simp only [Matrix.mul_assoc]
      _ = 1 := by rw [hAA,hCBC]
  · calc
      H*A⁻¹*(A*R*C) = H*(A⁻¹*A)*R*C := by simp only [Matrix.mul_assoc]
      _ = 0 := by rw [hai,Matrix.mul_one,hHR,Matrix.zero_mul]
  · calc
      X*A⁻¹*(A*R*C) = X*(A⁻¹*A)*R*C := by simp only [Matrix.mul_assoc]
      _ = _ := by rw [hai,Matrix.mul_one]

end SpectralComparison
