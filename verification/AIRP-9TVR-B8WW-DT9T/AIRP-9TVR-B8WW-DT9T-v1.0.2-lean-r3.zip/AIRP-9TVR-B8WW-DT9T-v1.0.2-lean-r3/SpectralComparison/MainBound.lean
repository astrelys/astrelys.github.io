import SpectralComparison.DiffuseBound
import SpectralComparison.MainPrefixInterface
import SpectralComparison.SpectralPermutation

/-! Unconditional uniform comparison for the actual matrix objective. -/
noncomputable section
namespace SpectralComparison

/-- Equation (9.1) for decreasing positive eigenvalues, with both constructions proved internally. -/
theorem paper_equation_9_1_sorted {n k : ℕ} (eig : Fin n → ℝ)
    (heig : ∀ i,0<eig i) (horder : Antitone eig) (hk : 1≤k) (hkn : k<n) :
    worstError eig k≤spectralMean eig k ∧
      spectralMean eig k≤(((k:ℝ)+1)*min 1 ((768*10^27*H (min k (n-k))+1)/Real.sqrt k))*worstError eig k := by
  apply matrix_main_from_diffuse_construction eig heig horder hk hkn
  intro q hqk hqR
  have hq : 4*q≤k := by exact_mod_cast (show (4:ℝ)*(q:ℝ)≤k by linarith)
  have hh := (le_max_right _ _).trans (paper_proposition_diffuse eig heig horder hk hkn hq)
  dsimp only at hh ⊢
  simpa only [show (64:ℝ)*10^27=64000000000000000000000000000 by norm_num] using hh

/-- The main uniform bound (9.1) for every positive spectrum, without sorting or construction hypotheses. -/
theorem paper_equation_9_1 {n k : ℕ} (eig : Fin n → ℝ)
    (heig : ∀ i,0<eig i) (hk : 1≤k) (hkn : k<n) :
    worstError eig k≤spectralMean eig k ∧
      spectralMean eig k≤(((k:ℝ)+1)*min 1 ((768*10^27*H (min k (n-k))+1)/Real.sqrt k))*worstError eig k := by
  let e := Tuple.sort (α:=OrderDual ℝ) eig
  have ho : Antitone (eig ∘ e) := Tuple.monotone_sort (α:=OrderDual ℝ) eig
  have hh := paper_equation_9_1_sorted (eig ∘ e) (fun _ => heig _) ho hk hkn
  simpa only [worstError_comp_equiv,spectralMean_comp_equiv] using hh

end SpectralComparison
