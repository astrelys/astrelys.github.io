import SpectralComparison.GaussianSmallBall

/-! Simultaneous control of all row subsets and the Gaussian realization for Lemma 4.1. -/
noncomputable section
open MeasureTheory ProbabilityTheory Matrix
namespace SpectralComparison

/-- Apply Lemma 3.1 to one row subset without assuming any new random-matrix law. -/
theorem gaussian_row_subset_tail {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {N t q : ℕ} (ht : 1 ≤ t) (hp : 4 ≤ t+q)
    (G : Ω → Matrix (Fin N) (Fin (t+q)) ℝ)
    (hG : ∀ a : Fin N × Fin (t+q), HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin N × Fin (t+q) => fun ω => G ω a.1 a.2) μ)
    (J : Finset (Fin N)) (hJ : J.card=t) :
    μ.real {ω | ((G ω).submatrix (fun i : J => (i : Fin N)) id *
      ((G ω).submatrix (fun i : J => (i : Fin N)) id)ᴴ)⁻¹.trace ≤
      (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t+q:ℕ)))} ≤ 2*Real.exp (-31*(t+q:ℕ)) := by
  let e : Fin t ≃ J := (finCongr (by simpa using hJ.symm)).trans (Fintype.equivFin J).symm
  let f : Fin t → Fin N := fun i => (e i : Fin N)
  have hf : Function.Injective f := Subtype.val_injective.comp e.injective
  let W := fun ω => (G ω).submatrix f id
  have hw (a : Fin t × Fin (t+q)) : HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ := hG (f a.1,a.2)
  have hmap : Function.Injective (fun a : Fin t × Fin (t+q) => (f a.1,a.2)) := by
    intro a b hab
    have h1 : f a.1 = f b.1 := congrArg (fun z : Fin N × Fin (t+q) => z.1) hab
    have h2 : a.2 = b.2 := congrArg (fun z : Fin N × Fin (t+q) => z.2) hab
    exact Prod.ext (hf h1) h2
  have hi : iIndepFun (fun a : Fin t × Fin (t+q) => fun ω => W ω a.1 a.2) μ :=
    hind.precomp hmap
  have h := paper_lemma_3_1 ht hp W hw hi
  have he (ω : Ω) : (W ω*(W ω)ᴴ)⁻¹.trace =
      ((G ω).submatrix (fun i : J => (i : Fin N)) id *
      ((G ω).submatrix (fun i : J => (i : Fin N)) id)ᴴ)⁻¹.trace :=
    inverse_gram_trace_reindex ((G ω).submatrix (fun i : J => (i : Fin N)) id) e
  simpa only [he] using h

/-- Equation (4.5): a single event controls every t-row subset. -/
theorem gaussian_all_row_subsets_tail {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {N t q : ℕ} (ht : 1 ≤ t) (hp : 4 ≤ t+q)
    (hN : N ≤ 2*(t+q)) (G : Ω → Matrix (Fin N) (Fin (t+q)) ℝ)
    (hG : ∀ a : Fin N × Fin (t+q), HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin N × Fin (t+q) => fun ω => G ω a.1 a.2) μ) :
    μ.real {ω | ∃ J : Finset (Fin N), J.card=t ∧
      ((G ω).submatrix (fun i : J => (i : Fin N)) id *
      ((G ω).submatrix (fun i : J => (i : Fin N)) id)ᴴ)⁻¹.trace ≤
      (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t+q:ℕ)))} ≤ 2*Real.exp (-29*(t+q:ℕ)) := by
  classical
  let s := (Finset.univ : Finset (Fin N)).powersetCard t
  have h := finite_union_probability_bound (μ := μ) s
    (fun J => {ω | ((G ω).submatrix (fun i : J => (i : Fin N)) id *
      ((G ω).submatrix (fun i : J => (i : Fin N)) id)ᴴ)⁻¹.trace ≤
      (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t+q:ℕ)))})
    (fun J hJ => gaussian_row_subset_tail ht hp G hG hind J (Finset.mem_powersetCard.mp hJ).2)
  have hev : {ω | ∃ J ∈ s, ((G ω).submatrix (fun i : J => (i : Fin N)) id *
      ((G ω).submatrix (fun i : J => (i : Fin N)) id)ᴴ)⁻¹.trace ≤
      (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t+q:ℕ)))} =
      {ω | ∃ J : Finset (Fin N), J.card=t ∧ ((G ω).submatrix (fun i : J => (i : Fin N)) id *
      ((G ω).submatrix (fun i : J => (i : Fin N)) id)ᴴ)⁻¹.trace ≤
      (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t+q:ℕ)))} := by
    ext ω
    simp [s]
  simp only [Set.mem_ofPred_eq] at h
  rw [hev] at h
  have hc : (s.card:ℝ) ≤ (4:ℝ)^(t+q) := by
    have hn : s.card ≤ 2^N := by
      calc
        s.card ≤ (Finset.univ : Finset (Fin N)).powerset.card :=
          Finset.card_le_card (fun _ h => Finset.mem_powerset.mpr (Finset.mem_powersetCard.mp h).1)
        _ = 2^N := by simp
    have hpow : (2:ℝ)^N ≤ 2^(2*(t+q)) := pow_le_pow_right₀ (by norm_num) hN
    calc
      _ ≤ (2:ℝ)^N := by exact_mod_cast hn
      _ ≤ _ := hpow
      _ = (4:ℝ)^(t+q) := by rw [pow_mul]; norm_num
  have hfour : (4:ℝ)^(t+q) ≤ Real.exp (2*(t+q:ℕ)) := by
    have h4 : (4:ℝ) ≤ Real.exp 2 := by
      have h2 := Real.exp_one_gt_two.le
      calc
        (4:ℝ) = 2*2 := by norm_num
        _ ≤ Real.exp 1 * Real.exp 1 := mul_le_mul h2 h2 (by norm_num) (by positivity)
        _ = Real.exp 2 := by rw [← Real.exp_add]; norm_num
    calc
      _ ≤ (Real.exp 2)^(t+q) := pow_le_pow_left₀ (by norm_num) h4 _
      _ = Real.exp (2*(t+q:ℕ)) := by rw [← Real.exp_nat_mul]; congr 1; ring
  apply h.trans
  calc
    _ ≤ (4:ℝ)^(t+q)*(2*Real.exp (-31*(t+q:ℕ))) := by gcongr
    _ ≤ Real.exp (2*(t+q:ℕ))*(2*Real.exp (-31*(t+q:ℕ))) := by gcongr
    _ = 2*Real.exp (-29*(t+q:ℕ)) := by
      rw [show Real.exp (2*(t+q:ℕ))*(2*Real.exp (-31*(t+q:ℕ))) =
        2*(Real.exp (2*(t+q:ℕ))*Real.exp (-31*(t+q:ℕ))) by ring, ← Real.exp_add]
      congr 2
      ring

/-- The three exceptional-event bounds have total probability strictly below one. -/
theorem gaussian_good_event_budget {p : ℕ} (hp : 4 ≤ p) :
    Real.exp (-3*(p:ℝ))+(1/16:ℝ)^p+2*Real.exp (-29*(p:ℝ)) < 1 := by
  have hpr : (4:ℝ) ≤ p := by exact_mod_cast hp
  have hsmall : Real.exp (-3*(p:ℝ)) ≤ 1/2 := by
    have he : Real.exp (-1:ℝ) < 1/2 := by
      rw [Real.exp_neg]
      exact (inv_lt_comm₀ (by positivity) (by norm_num)).mpr (by simpa using Real.exp_one_gt_two)
    exact (Real.exp_le_exp.mpr (by linarith)).trans he.le
  have hlast : Real.exp (-29*(p:ℝ)) < 1/8 := by
    have he : (8:ℝ) < Real.exp 3 := by
      have h := pow_lt_pow_left₀ Real.exp_one_gt_two (by norm_num : (0:ℝ) ≤ 2) (by norm_num : (3:ℕ) ≠ 0)
      have heq : Real.exp (3:ℝ) = (Real.exp 1)^3 := by
        simp [← Real.exp_nat_mul]
      rw [heq]
      norm_num at h ⊢
      exact h
    have hh : Real.exp (-3:ℝ) < 1/8 := by
      rw [Real.exp_neg]
      exact (inv_lt_comm₀ (by positivity) (by norm_num)).mpr (by simpa using he)
    exact (Real.exp_le_exp.mpr (by linarith)).trans_lt hh
  have hmid : (1/16:ℝ)^p ≤ 1/16 := by
    simpa using pow_le_pow_of_le_one (by norm_num : (0:ℝ) ≤ 1/16) (by norm_num : (1/16:ℝ) ≤ 1) (show 1 ≤ p by omega)
  linarith

/-- The random-matrix realization used in the p>=4 part of Lemma 4.1. All
row-subset bounds and both singular-value estimates hold simultaneously. -/
theorem gaussian_exists_good_realization {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {N t q : ℕ} (ht : 1 ≤ t) (hp : 4 ≤ t+q)
    (hNlow : 4*(t+q) ≤ 3*N) (hNhigh : N ≤ 2*(t+q))
    (G : Ω → Matrix (Fin N) (Fin (t+q)) ℝ)
    (hG : ∀ a : Fin N × Fin (t+q), HasLaw (fun ω => G ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : Fin N × Fin (t+q) => fun ω => G ω a.1 a.2) μ)
    (hm : ∀ a : Fin N × Fin (t+q), Measurable (fun ω => G ω a.1 a.2)) :
    ∃ ω, ‖(G ω).toEuclideanLin.toContinuousLinearMap‖ ≤ 10*Real.sqrt (t+q:ℕ) ∧
      (∀ x : EuclideanSpace ℝ (Fin (t+q)), ‖x‖=1 →
        Real.sqrt (t+q:ℕ)/1000000000000 ≤ ‖(G ω).toEuclideanLin x‖) ∧
      ∀ J : Finset (Fin N), J.card=t →
        (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t+q:ℕ))) <
        ((G ω).submatrix (fun i : J => (i : Fin N)) id *
        ((G ω).submatrix (fun i : J => (i : Fin N)) id)ᴴ)⁻¹.trace := by
  obtain ⟨s,hs,hcard,hnet,hsmall⟩ := exists_gaussian_small_ball_net hNlow G hG hind hm
  let A := {ω | 10*Real.sqrt (t+q:ℕ) < ‖(G ω).toEuclideanLin.toContinuousLinearMap‖}
  let B := {ω | ∃ v ∈ s, ‖(G ω).toEuclideanLin v‖^2 ≤ 4*(t+q:ℕ)/(1000000000000:ℝ)^2}
  let C := {ω | ∃ J : Finset (Fin N), J.card=t ∧
        ((G ω).submatrix (fun i : J => (i : Fin N)) id *
        ((G ω).submatrix (fun i : J => (i : Fin N)) id)ᴴ)⁻¹.trace ≤
        (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t+q:ℕ)))}
  have hA : μ.real A ≤ Real.exp (-3*(t+q:ℕ)) := gaussian_opNorm_tail hNhigh G hG hind hm
  have hB : μ.real B ≤ (1/16:ℝ)^(t+q) := hsmall
  have hC : μ.real C ≤ 2*Real.exp (-29*(t+q:ℕ)) := gaussian_all_row_subsets_tail ht hp hNhigh G hG hind
  have hbad : μ.real ((A ∪ B) ∪ C) < 1 := by
    calc
      _ ≤ μ.real (A ∪ B) + μ.real C := measureReal_union_le _ _
      _ ≤ μ.real A + μ.real B + μ.real C := by gcongr; exact measureReal_union_le _ _
      _ ≤ Real.exp (-3*(t+q:ℕ))+(1/16:ℝ)^(t+q)+2*Real.exp (-29*(t+q:ℕ)) := by linarith
      _ < 1 := gaussian_good_event_budget hp
  have hex : ∃ ω, ω ∉ (A ∪ B) ∪ C := by
    by_contra! h
    have he : (A ∪ B) ∪ C = Set.univ := Set.eq_univ_of_forall h
    simp [he] at hbad
  obtain ⟨ω,hω⟩ := hex
  have hupper : ‖(G ω).toEuclideanLin.toContinuousLinearMap‖ ≤ 10*Real.sqrt (t+q:ℕ) := by
    have : ω ∉ A := fun h => hω (Or.inl (Or.inl h))
    exact le_of_not_gt this
  have hlower : ∀ v ∈ s, 4*(t+q:ℕ)/(1000000000000:ℝ)^2 < ‖(G ω).toEuclideanLin v‖^2 := by
    intro v hv
    exact lt_of_not_ge (fun h => hω (Or.inl (Or.inr ⟨v,hv,h⟩)))
  refine ⟨ω,hupper,gaussian_net_lower_singular (G ω) s hnet hupper hlower,?_⟩
  intro J hJ
  exact lt_of_not_ge (fun h => hω (Or.inr ⟨J,hJ,h⟩))

/-- A deterministic matrix exists with the joint estimates; no random matrix or
probability-law assumption remains in this conclusion. -/
theorem exists_uniform_good_matrix {N t q : ℕ} (ht : 1 ≤ t) (hp : 4 ≤ t+q)
    (hNlow : 4*(t+q) ≤ 3*N) (hNhigh : N ≤ 2*(t+q)) :
    ∃ G : Matrix (Fin N) (Fin (t+q)) ℝ,
      ‖G.toEuclideanLin.toContinuousLinearMap‖ ≤ 10*Real.sqrt (t+q:ℕ) ∧
      (∀ x : EuclideanSpace ℝ (Fin (t+q)), ‖x‖=1 →
        Real.sqrt (t+q:ℕ)/1000000000000 ≤ ‖G.toEuclideanLin x‖) ∧
      ∀ J : Finset (Fin N), J.card=t →
        (t:ℝ)/(1000*((q:ℝ)+Real.sqrt (t+q:ℕ))) <
        (G.submatrix (fun i : J => (i : Fin N)) id *
        (G.submatrix (fun i : J => (i : Fin N)) id)ᴴ)⁻¹.trace := by
  let μ : Measure (Fin N × Fin (t+q) → ℝ) := Measure.pi (fun _ => gaussianReal 0 1)
  let G := fun (ω : Fin N × Fin (t+q) → ℝ) => Matrix.of (fun i j => ω (i,j))
  have hX : HasLaw id μ μ := HasLaw.id
  have hG := gaussian_product_entry_hasLaw id hX
  have hi := gaussian_product_independent id hX
  have hm (a : Fin N × Fin (t+q)) : Measurable (fun ω => G ω a.1 a.2) := measurable_pi_apply a
  obtain ⟨ω,hω⟩ := gaussian_exists_good_realization (μ := μ) ht hp hNlow hNhigh G hG hi hm
  exact ⟨G ω,hω⟩

end SpectralComparison
