import SpectralComparison.StrictTheorem

noncomputable section
open Matrix
namespace SpectralComparison

/-- E.6 as an exact weighted trace identity on complementary row sets. -/
theorem weighted_complement_trace {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p] (R : Matrix n p ℝ) (hR : Rᴴ*R=1)
    (B : Matrix p p ℝ) (I : Finset n)
    (hu : IsUnit ((R.submatrix (fun i : ↥(Iᶜ) => (i:n)) id)ᴴ*
      R.submatrix (fun i : ↥(Iᶜ) => (i:n)) id)) :
    (B*((R.submatrix (fun i : ↥(Iᶜ) => (i:n)) id)ᴴ*
      R.submatrix (fun i : ↥(Iᶜ) => (i:n)) id)⁻¹).trace=
      B.trace+((principal (1-R*Rᴴ) I)⁻¹*principal (R*B*Rᴴ) I).trace := by
  let E := R.submatrix (fun i : I => (i:n)) id
  have he : (R.submatrix (fun i : ↥(Iᶜ) => (i:n)) id)ᴴ*
      R.submatrix (fun i : ↥(Iᶜ) => (i:n)) id=1-Eᴴ*E := parseval_complement_row_gram R hR I
  have hp : principal (1-R*Rᴴ) I=1-E*Eᴴ := complementary_projection_block R I
  have hc : principal (R*B*Rᴴ) I=E*B*Eᴴ := by
    dsimp [principal,E]
    rw [Matrix.submatrix_mul _ _ _ id _ Function.bijective_id,
      Matrix.submatrix_mul _ _ _ id id Function.bijective_id,Matrix.submatrix_id_id]
    rfl
  rw [he] at hu ⊢
  have hunit : IsUnit (1-E*Eᴴ) := (complement_gram_isUnit_iff E).mpr hu
  have hinv := complement_gram_inverse Eᴴ (by simpa only [Matrix.conjTranspose_conjTranspose] using hunit)
  simp only [Matrix.conjTranspose_conjTranspose] at hinv
  rw [hinv,Matrix.mul_add,Matrix.mul_one,Matrix.trace_add,hp,hc]
  congr 1
  rw [← Matrix.mul_assoc,← Matrix.mul_assoc,Matrix.trace_mul_cycle]
  simpa only [Matrix.mul_assoc] using Matrix.trace_mul_comm (E*B*Eᴴ) (1-E*Eᴴ)⁻¹

/-- Weighting every selected basis of a Parseval frame costs at least the total positive weight. -/
theorem weighted_basis_trace_lower {n p : Type*} [Fintype n] [Fintype p]
    [DecidableEq n] [DecidableEq p] (R : Matrix n p ℝ) (hR : Rᴴ*R=1)
    (B : Matrix p p ℝ) (hB : B.PosSemidef) (J : Finset n)
    (hu : IsUnit ((R.submatrix (fun i : J => (i:n)) id)ᴴ*R.submatrix (fun i : J => (i:n)) id)) :
    B.trace≤(B*((R.submatrix (fun i : J => (i:n)) id)ᴴ*R.submatrix (fun i : J => (i:n)) id)⁻¹).trace := by
  let G := (R.submatrix (fun i : J => (i:n)) id)ᴴ*R.submatrix (fun i : J => (i:n)) id
  have hG : G.PosDef := (posSemidef_conjTranspose_mul_self _).posDef_iff_isUnit.mpr hu
  have hgap : (1-G).PosSemidef := by
    rw [← parseval_complement_row_gram R hR J]
    exact posSemidef_conjTranspose_mul_self _
  have hi := posDef_inverse_order hG Matrix.PosDef.one hgap
  rw [inv_one] at hi
  have ht := trace_mul_posSemidef_nonneg hB hi
  rw [Matrix.mul_sub,Matrix.mul_one,Matrix.trace_sub] at ht
  change B.trace≤(B*G⁻¹).trace
  linarith

/-- A lower scalar bound on diagonal weights transfers a basis inverse-trace bound exactly. -/
theorem weighted_basis_min_lower {p : Type*} [Fintype p] [DecidableEq p]
    (b : p → ℝ) {z L : ℝ} (hb : ∀ i,z≤b i) {G : Matrix p p ℝ}
    (hG : G.PosDef) (hL : L≤G⁻¹.trace) (hz : 0≤z) :
    z*L≤(Matrix.diagonal b*G⁻¹).trace := by
  have hdiag : (Matrix.diagonal b-z • (1 : Matrix p p ℝ)).PosSemidef := by
    convert Matrix.PosSemidef.diagonal (fun i => sub_nonneg.mpr (hb i)) using 1
    ext i j
    by_cases hij : i=j
    · subst j; simp
    · simp [hij]
  exact (mul_le_mul_of_nonneg_left hL hz).trans (trace_product_lower hG.inv.posSemidef hdiag)

end SpectralComparison
