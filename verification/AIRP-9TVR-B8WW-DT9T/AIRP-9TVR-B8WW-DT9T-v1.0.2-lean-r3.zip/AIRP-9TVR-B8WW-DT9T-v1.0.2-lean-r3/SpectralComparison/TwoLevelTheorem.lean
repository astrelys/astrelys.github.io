import SpectralComparison.TwoLevelLimit

/-! The two-level asymptotic comparison with both original numerical bounds. -/
noncomputable section
open Filter Topology
namespace SpectralComparison

/-- The denominator in (A.2) is strictly positive in every nontrivial dimension. -/
theorem two_level_denominator_pos {k m : ℕ} (hk : 1≤k) (hm : 1≤m) :
    0<max ((m:ℝ)-(k:ℝ)) 0+(k+m:ℕ)*Real.sqrt (min k m:ℕ)/16000000000 := by
  have hr : (0:ℝ)<(min k m:ℕ) := by exact_mod_cast (by omega : 0<min k m)
  have hn : (0:ℝ)<(k+m:ℕ) := by exact_mod_cast (by omega : 0<k+m)
  exact add_pos_of_nonneg_of_pos (le_max_right _ _) (by positivity)

/-- The final dimension-only simplification of (A.2). -/
theorem two_level_ratio_dimension_bound {k m : ℕ} (hk : 1≤k) (hm : 1≤m) :
    ((k:ℝ)+1)*(m:ℝ)/(max ((m:ℝ)-(k:ℝ)) 0+(k+m:ℕ)*Real.sqrt (min k m:ℕ)/16000000000) ≤
      16000000000*(Real.sqrt (min k m:ℕ)+1/Real.sqrt (min k m:ℕ)) := by
  have hr : (0:ℝ)<(min k m:ℕ) := by exact_mod_cast (by omega : 0<min k m)
  have hs : 0<Real.sqrt (min k m:ℕ) := Real.sqrt_pos.mpr hr
  have hn : ((k:ℝ)+1)*(m:ℝ)≤(k+m:ℕ)*((min k m:ℕ)+1) := by
    by_cases hkm : k≤m
    · rw [min_eq_left hkm]
      push_cast
      nlinarith [Nat.cast_nonneg (α:=ℝ) k]
    · rw [min_eq_right (by omega)]
      push_cast
      nlinarith [Nat.cast_nonneg (α:=ℝ) m,Nat.cast_nonneg (α:=ℝ) k]
  have he : 16000000000*(Real.sqrt (min k m:ℕ)+1/Real.sqrt (min k m:ℕ))*
      ((k+m:ℕ)*Real.sqrt (min k m:ℕ)/16000000000)=(k+m:ℕ)*((min k m:ℕ)+1) := by
    field_simp
    nlinarith [Real.sq_sqrt hr.le]
  apply (div_le_iff₀ (two_level_denominator_pos hk hm)).mpr
  have hnon : 0≤16000000000*(Real.sqrt (min k m:ℕ)+1/Real.sqrt (min k m:ℕ)) := by positivity
  have hd : (k+m:ℕ)*Real.sqrt (min k m:ℕ)/16000000000≤
      max ((m:ℝ)-(k:ℝ)) 0+(k+m:ℕ)*Real.sqrt (min k m:ℕ)/16000000000 := by
    linarith [le_max_right ((m:ℝ)-(k:ℝ)) 0]
  rw [← he] at hn
  exact hn.trans (mul_le_mul_of_nonneg_left hd hnon)

/-- Equation (A.2), a right-hand limsup statement for the actual spectral comparison ratio. -/
theorem paper_two_level_limit {k m : ℕ} (hk : 1≤k) (hm : 1≤m) :
    (Filter.limsup (fun ε : ℝ => spectralMean (twoLevelSpectrum k m ε) k/worstError (twoLevelSpectrum k m ε) k)
      (𝓝[>] 0)≤((k:ℝ)+1)*(m:ℝ)/(max ((m:ℝ)-(k:ℝ)) 0+(k+m:ℕ)*Real.sqrt (min k m:ℕ)/16000000000)) ∧
    ((k:ℝ)+1)*(m:ℝ)/(max ((m:ℝ)-(k:ℝ)) 0+(k+m:ℕ)*Real.sqrt (min k m:ℕ)/16000000000)≤
      16000000000*(Real.sqrt (min k m:ℕ)+1/Real.sqrt (min k m:ℕ)) := by
  refine ⟨?_,two_level_ratio_dimension_bound hk hm⟩
  obtain ⟨Q,hQ,hb⟩ := exists_frame_complementary_rank_bound (n:=k+m) hk (by omega)
  rw [show k+m-k=m by omega] at hb
  have hr : (0:ℝ)<(min k m:ℕ) := by exact_mod_cast (by omega : 0<min k m)
  have hn : (0:ℝ)<(k+m:ℕ) := by exact_mod_cast (by omega : 0<k+m)
  have hC : 0<(k+m:ℕ)*Real.sqrt (min k m:ℕ)/16000000000 := by positivity
  have hL : 0<frameBasisMinimum Q := by linarith [le_max_left ((m:ℝ)-(k:ℝ)) 0]
  have hD := two_level_denominator_pos hk hm
  have hx := two_level_limsup_of_frame hm Q hQ hL (hD.trans_le hb)
    (fun I hI hu => frameBasisMinimum_le_basis Q I hI hu)
  exact hx.trans (div_le_div_of_nonneg_left (by positivity) hD hb)

end SpectralComparison
