import SpectralComparison.RobustWeights

/-! Complete robust Parseval-frame lemma, including all natural repetition weights. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- The robust kernel property implies the weighted inverse-trace property for every integer tuple. -/
theorem weighted_inverse_trace_of_robust_kernel {k q : ℕ} (hk : 1≤k) (hq : 2*q≤k)
    (Q : Matrix (Fin (2*k)) (Fin (k-q)) ℝ)
    (hrows : ∀ J : Finset (Fin (2*k)), J.card≤k-q →
      (Q.submatrix (fun i : J => (i:Fin (2*k))) id *
        (Q.submatrix (fun i : J => (i:Fin (2*k))) id)ᴴ).PosDef)
    {C : ℝ} (hkernel : ∀ H L : Finset (Fin (2*k)), Disjoint H L → 4*H.card≤k → H.card+L.card≤k →
      ∀ U : Matrix (Fin (k-q)) (Fin (k-q-H.card)) ℝ, Uᴴ*U=1 →
        (Q.submatrix (fun i : H => (i:Fin (2*k))) id)*U=0 →
        (((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U)ᴴ*
          ((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U)).PosDef →
        C≤(((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U)ᴴ*
          ((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U))⁻¹.trace)
    (w : Fin (2*k) → ℕ) (hw : ∑ i, w i=k)
    (hunit : IsUnit (Qᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Q)) :
    (1/2:ℝ)*C≤(Qᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Q)⁻¹.trace := by
  classical
  let B := Qᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Q
  have hB : B.PosDef := ((Matrix.PosSemidef.diagonal (fun i => Nat.cast_nonneg (α := ℝ) (w i))).conjTranspose_mul_mul_same Q).posDef_iff_isUnit.mpr hunit
  let H := Finset.univ.filter (fun i => 3≤w i)
  let L := Finset.univ.filter (fun i => 0<w i ∧ w i<3)
  let s := (Finset.univ.filter (fun i => 0<w i)).card
  have hs : k-q≤s := by simpa only [Fintype.card_fin] using weighted_gram_support_card Q w hB
  have he : 2*H.card+s≤k := by simpa only [hw] using repetition_count_excess w
  obtain ⟨hdis,hpart⟩ := repetition_support_partition w
  change Disjoint H L at hdis
  change H.card+L.card=s at hpart
  have hh : 4*H.card≤k := by omega
  have hl : H.card+L.card≤k := by omega
  have hHcard : H.card≤k-q := by omega
  let QH := Q.submatrix (fun i : H => (i:Fin (2*k))) id
  let QL := Q.submatrix (fun i : L => (i:Fin (2*k))) id
  have hH : (QH*QHᴴ).PosDef := hrows H hHcard
  have hdim : Fintype.card (Fin (k-q-H.card))+Fintype.card H=Fintype.card (Fin (k-q)) := by
    simp only [Fintype.card_fin,Fintype.card_coe]
    omega
  obtain ⟨U,hU,hproj⟩ := exists_kernel_basis_matrix_of_dimension (d := Fin (k-q-H.card)) QH hH hdim
  have hHU := kernel_columns_annihilated QH hH U hU hproj
  have hgap := repetition_kernel_gram_upper Q w U hHU
  change ((2:ℝ) • ((QL*U)ᴴ*(QL*U))-Uᴴ*B*U).PosSemidef at hgap
  obtain ⟨hG,htransfer⟩ := repetition_inverse_trace_transfer hB U hU (QL*U) hgap
  exact (mul_le_mul_of_nonneg_left (hkernel H L hdis hh hl U hU hHU hG) (by norm_num : (0:ℝ)≤1/2)).trans htransfer

/-- Paper Lemma 5.1, equations (5.1) and (5.2), with exact constants and all stated dimensions.
Full-rank row and compressed Gram conditions are expressed as positive definiteness,
which is equivalent to nonsingularity for these positive-semidefinite Gram matrices. -/
theorem paper_lemma_5_1 {k q : ℕ} (hk : 1≤k) (hq : 2*q≤k) :
    ∃ Q : Matrix (Fin (2*k)) (Fin (k-q)) ℝ, Qᴴ*Q=1 ∧
      (∀ J : Finset (Fin (2*k)), J.card≤k-q →
        (Q.submatrix (fun i : J => (i:Fin (2*k))) id *
          (Q.submatrix (fun i : J => (i:Fin (2*k))) id)ᴴ).PosDef) ∧
      (∀ H L : Finset (Fin (2*k)), Disjoint H L → 4*H.card≤k → H.card+L.card≤k →
        ∀ U : Matrix (Fin (k-q)) (Fin (k-q-H.card)) ℝ, Uᴴ*U=1 →
          (Q.submatrix (fun i : H => (i:Fin (2*k))) id)*U=0 →
          (((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U)ᴴ*
            ((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U)).PosDef →
          (k:ℝ)^2/(4000000000000000000000000000*((q:ℝ)+Real.sqrt k))≤
            (((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U)ᴴ*
              ((Q.submatrix (fun i : L => (i:Fin (2*k))) id)*U))⁻¹.trace) ∧
      ∀ w : Fin (2*k) → ℕ, (∑ i, w i)=k →
        IsUnit (Qᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Q) →
        (k:ℝ)^2/(8000000000000000000000000000*((q:ℝ)+Real.sqrt k))≤
          (Qᴴ*Matrix.diagonal (fun i => (w i:ℝ))*Q)⁻¹.trace := by
  obtain ⟨Q,hQ,hrows,hkernel⟩ := exists_robust_parseval_kernel hk hq
  refine ⟨Q,hQ,hrows,hkernel,?_⟩
  intro w hw hunit
  have ht := weighted_inverse_trace_of_robust_kernel hk hq Q hrows hkernel w hw hunit
  convert ht using 1
  simp only [div_eq_mul_inv,_root_.mul_inv_rev]
  ring

end SpectralComparison
