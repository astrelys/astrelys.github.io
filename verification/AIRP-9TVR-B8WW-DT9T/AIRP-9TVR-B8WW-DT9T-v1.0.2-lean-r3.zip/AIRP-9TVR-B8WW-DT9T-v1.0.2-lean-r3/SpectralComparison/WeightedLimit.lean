import SpectralComparison.WeightedFinite
import SpectralComparison.WeightedAsymptotics

noncomputable section
open Filter Topology Finset
namespace SpectralComparison

/-- E.3 for arbitrary positive fixed head and tail lists, under any original spectral labelling. -/
theorem paper_weighted_boundary {k m : ℕ} (hk : 1 ≤ k) (hm : 1 ≤ m)
    (e : Fin k ⊕ Fin m ≃ Fin (k+m)) (a : Fin k → ℝ) (b : Fin m → ℝ)
    (ha : ∀ i, 0 < a i) (hb : ∀ i, 0 < b i) :
    Filter.limsup (fun ε : ℝ => spectralMean (splitSpectrum e a b ε) k /
      worstError (splitSpectrum e a b ε) k) (𝓝[>] 0) ≤ ((k:ℝ)+1)/weightedGamma k m ∧
    ((k:ℝ)+1)/weightedGamma k m ≤ 256000000000 * Real.sqrt (min k m : ℕ) := by
  classical
  refine ⟨?_, weighted_gamma_coefficient hk hm⟩
  obtain ⟨i0,_,hmin⟩ := (Finset.univ : Finset (Fin k)).exists_min_image a
    ⟨⟨0,by omega⟩,Finset.mem_univ _⟩
  let a0 := a i0
  let s := ∑ i,b i
  let U := fun ε : ℝ => ((k:ℝ)+1)*((weightedGamma k m)⁻¹+ε*s/a0)
  have ha0 : 0 < a0 := ha i0
  have hs : 0 < s := Finset.sum_pos (fun i _ => hb i) ⟨⟨0,by omega⟩,Finset.mem_univ _⟩
  have hcont : ContinuousAt U 0 := by dsimp [U]; fun_prop
  have hu : Tendsto U (𝓝[>] (0:ℝ)) (𝓝 (((k:ℝ)+1)/weightedGamma k m)) := by
    have he : U 0 = ((k:ℝ)+1)/weightedGamma k m := by simp [U,div_eq_mul_inv]
    simpa only [he] using hcont.tendsto.mono_left (nhdsWithin_le_nhds (s:=Set.Ioi (0:ℝ)))
  have hbound : ∀ᶠ ε : ℝ in 𝓝[>] 0,
      spectralMean (splitSpectrum e a b ε) k / worstError (splitSpectrum e a b ε) k ≤ U ε := by
    filter_upwards [self_mem_nhdsWithin] with ε hε
    let f := splitSpectrum (finSumFinEquiv : Fin k ⊕ Fin m ≃ Fin (k+m)) a b ε
    have hf : ∀ i, 0 < f i := splitSpectrum_pos _ a b ha hb hε
    have htail : (∑ i : Fin m, f (i.natAdd k)) = ε*s := by
      change (∑ i : Fin m, Sum.elim a (fun j => ε*b j) (finSumFinEquiv.symm (i.natAdd k))) = _
      have he (i : Fin m) : finSumFinEquiv.symm (i.natAdd k) = Sum.inr i := by
        exact finSumFinEquiv.symm_apply_apply (Sum.inr i)
      simp only [he, Sum.elim_inr, ← Finset.mul_sum]
      rfl
    have hhead : ∀ i : Fin k, a0 ≤ f (i.castAdd m) := by
      intro i
      have he : finSumFinEquiv.symm (i.castAdd m) = Sum.inl i :=
        finSumFinEquiv.symm_apply_apply (Sum.inl i)
      simpa only [f,splitSpectrum,he,Sum.elim_inl] using hmin i (Finset.mem_univ _)
    have hl := weighted_worst_lower hk hm f hf ha0 hhead
    have hy := spectralMean_le_indexed_tail hm f hf
    rw [htail] at hl hy
    have hx : 0 < worstError f k := worstError_pos f hf (by simp; omega)
    have hh := weighted_ratio_from_lower ha0 (mul_pos hε hs) (weightedGamma_pos hk hm)
      (by positivity : (0:ℝ) ≤ (k:ℝ)+1) hx hl hy
    let p : Equiv.Perm (Fin (k+m)) := e.symm.trans finSumFinEquiv
    have he : splitSpectrum e a b ε = f ∘ p := by
      funext i
      simp [f,splitSpectrum,p]
    rw [he,worstError_comp_equiv,spectralMean_comp_equiv]
    exact hh
  have hc : (𝓝[>] (0:ℝ)).IsCoboundedUnder (·≤·)
      (fun ε => spectralMean (splitSpectrum e a b ε) k / worstError (splitSpectrum e a b ε) k) := by
    apply isCoboundedUnder_le_of_eventually_le (𝓝[>] (0:ℝ)) (x:=(0:ℝ))
    filter_upwards [self_mem_nhdsWithin] with ε hε
    have hf := splitSpectrum_pos e a b ha hb hε
    have hx := worstError_pos _ hf (k:=k) (by simp; omega)
    have hy := hx.le.trans (worstError_le_spectralMean _ hf (by simp; omega))
    exact div_nonneg hy hx.le
  have hh := limsup_le_limsup hbound hc hu.isBoundedUnder_le
  rwa [hu.limsup_eq] at hh

end SpectralComparison
