import SpectralComparison.GaussianSquares
import SpectralComparison.Ridge

/-! Deterministic inverse-trace and dimension steps of the Gaussian lower-tail proof. -/
noncomputable section
namespace SpectralComparison
open Matrix Finset MeasureTheory ProbabilityTheory Real

/-- Cauchy–Schwarz for the actual positive eigenvalues and their reciprocals. -/
theorem trace_mul_inverse_trace_ge_card_sq {ι : Type*} [Fintype ι] [DecidableEq ι]
    {A : Matrix ι ι ℝ} (hA : A.PosDef) :
    (Fintype.card ι:ℝ)^2 ≤ A.trace*A⁻¹.trace := by
  rw [hA.isHermitian.trace_eq_sum_eigenvalues, trace_inverse_posDef hA]
  have h := Finset.sum_sq_le_sum_mul_sum_of_sq_le_mul (R := ℝ) Finset.univ
    (r := fun _ : ι => 1) (f := hA.isHermitian.eigenvalues)
    (g := fun i => 1/hA.isHermitian.eigenvalues i)
    (fun i _ => (hA.eigenvalues_pos i).le)
    (fun i _ => (one_div_pos.mpr (hA.eigenvalues_pos i)).le)
    (fun i _ => by simp [(hA.eigenvalues_pos i).ne'])
  simpa using h

/-- A small inverse Gram trace forces a large sum of squared matrix entries. -/
theorem inverse_gram_small_implies_frobenius_large {ι κ : Type*}
    [Fintype ι] [DecidableEq ι] [Fintype κ] (W : Matrix ι κ ℝ)
    (hW : (W*W.conjTranspose).PosDef) (hj : 0 < Fintype.card ι)
    {b : ℝ} (hb : 0 < b)
    (htrace : (W*W.conjTranspose)⁻¹.trace ≤ (Fintype.card ι:ℝ)/b) :
    b*(Fintype.card ι:ℝ) ≤ ∑ i, ∑ j, (W i j)^2 := by
  have hcs := trace_mul_inverse_trace_ge_card_sq hW
  have htr : 0 ≤ (W*W.conjTranspose).trace := hW.posSemidef.trace_nonneg
  have hc : (0:ℝ) < Fintype.card ι := by exact_mod_cast hj
  have hm := mul_le_mul_of_nonneg_left htrace htr
  have hh : (Fintype.card ι:ℝ)^2 ≤ (W*W.conjTranspose).trace*((Fintype.card ι:ℝ)/b) := hcs.trans hm
  have hh' : (Fintype.card ι:ℝ)^2*b ≤ (W*W.conjTranspose).trace*(Fintype.card ι:ℝ) := by
    apply (le_div_iff₀ hb).mp
    simpa only [mul_div_assoc] using hh
  rw [← frobenius_trace_formula W]
  nlinarith

/-- The integer choice j=min(t,floor(sqrt p)) used in Lemma 3.1 has
1<=j<=sqrt p and j(q+j)>=p/4 whenever p=t+q>=4. -/
theorem gaussian_tail_dimension {t q : ℕ} (ht : 1 ≤ t) (hp : 4 ≤ t+q) :
    let p := t+q
    let j := min t ⌊Real.sqrt (p:ℝ)⌋₊
    1 ≤ j ∧ (j:ℝ) ≤ Real.sqrt p ∧ (p:ℝ)/4 ≤ (j:ℝ)*(q+j) := by
  let p := t+q
  let r := Real.sqrt (p:ℝ)
  let f := ⌊r⌋₊
  have hpR : (4:ℝ) ≤ p := by exact_mod_cast hp
  have hr : 2 ≤ r := by
    dsimp [r]
    exact (Real.le_sqrt (by norm_num) (by positivity)).mpr (by nlinarith)
  have hfR : (f:ℝ) ≤ r := Nat.floor_le (by positivity)
  have hrf : r < (f:ℝ)+1 := Nat.lt_floor_add_one r
  have hf : 1 ≤ f := (Nat.one_le_floor_iff r).mpr (by linarith)
  have hhalf : r/2 ≤ (f:ℝ) := by linarith
  have hr2 : r^2 = (p:ℝ) := Real.sq_sqrt (by positivity)
  change 1 ≤ min t f ∧ ((min t f:ℕ):ℝ) ≤ r ∧ (p:ℝ)/4 ≤ ((min t f:ℕ):ℝ)*(q+min t f)
  have hjf : ((min t f:ℕ):ℝ) ≤ (f:ℝ) := by exact_mod_cast (min_le_right t f)
  refine ⟨le_min ht hf, hjf.trans hfR, ?_⟩
  by_cases htf : t ≤ f
  · rw [min_eq_left htf]
    have htR : (1:ℝ) ≤ t := by exact_mod_cast ht
    have hpq : (p:ℝ) = (t:ℝ)+(q:ℝ) := by simp [p]
    nlinarith
  · rw [min_eq_right (le_of_not_ge htf)]
    have hf0 : (0:ℝ) ≤ f := by positivity
    have hq0 : (0:ℝ) ≤ q := by positivity
    nlinarith [sq_nonneg ((f:ℝ)-r/2), mul_nonneg hf0 hq0]

/-- Actual independent Gaussian entries satisfy the small inverse-trace bound on the
positive-definite Gram event. Almost-sure full rank is deliberately not assumed or concluded. -/
theorem gaussian_inverse_trace_tail_on_posDef {Ω ι κ : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [Fintype ι] [DecidableEq ι] [Fintype κ]
    (W : Ω → Matrix ι κ ℝ)
    (hW : ∀ a : ι × κ, HasLaw (fun ω => W ω a.1 a.2) (gaussianReal 0 1) μ)
    (hind : iIndepFun (fun a : ι × κ => fun ω => W ω a.1 a.2) μ)
    (hmeas : ∀ a : ι × κ, Measurable (fun ω => W ω a.1 a.2))
    (hi : 0 < Fintype.card ι) (hk : 0 < Fintype.card κ) :
    μ.real {ω | (W ω*(W ω)ᴴ).PosDef ∧
      (W ω*(W ω)ᴴ)⁻¹.trace ≤ (Fintype.card ι:ℝ)/(500*(Fintype.card κ:ℝ))} ≤
      Real.exp (-124*((Fintype.card ι:ℝ)*(Fintype.card κ:ℝ))) := by
  have h := gaussian_squares_tail_500 (fun a : ι × κ => fun ω => W ω a.1 a.2)
    hW hind hmeas Finset.univ
  simp only [Finset.card_univ, Fintype.card_prod, Nat.cast_mul,
    Fintype.sum_prod_type] at h
  refine (measureReal_mono (fun ω hω => ?_)).trans h
  have hc : (0:ℝ) < Fintype.card κ := by exact_mod_cast hk
  have hb : (0:ℝ) < 500*(Fintype.card κ:ℝ) := by positivity
  have hf := inverse_gram_small_implies_frobenius_large (W ω) hω.1 hi hb hω.2
  change 500*((Fintype.card ι:ℝ)*(Fintype.card κ:ℝ)) ≤ ∑ i, ∑ j, (W ω i j)^2
  nlinarith

end SpectralComparison
