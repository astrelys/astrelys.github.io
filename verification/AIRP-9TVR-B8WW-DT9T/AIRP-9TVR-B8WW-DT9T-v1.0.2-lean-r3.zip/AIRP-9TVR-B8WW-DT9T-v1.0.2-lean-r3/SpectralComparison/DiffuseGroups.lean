import SpectralComparison.DiffuseTailSplit

/-! Reserve selection and one nonempty diffuse grouping, before any coordinate selection. -/
noncomputable section
namespace SpectralComparison

/-- A reserve and one grouping realize (7.3), for the explicit small-head tail decomposition. -/
theorem exists_diffuse_reserve_and_groups {k q p : ℕ} (hk : 1≤k) (hq : 4*q≤k)
    (d : Fin (8*k+p) → ℝ) (hd : ∀ i,0<d i) (horder : Antitone d)
    (hhead : (∑ i : Fin (8*k),d (i.castAdd p))<(∑ i,d i)/2) :
    ∃ S : Finset (Fin p), S.card=k+q ∧
      (∑ i∈S,d (i.natAdd (8*k)))<(∑ i : Fin p,d (i.natAdd (8*k)))/4 ∧
      ∃ f : ↥(Sᶜ) → Fin (2*k), Function.Surjective f ∧
        ∀ j,(∑ i,d i)/(8*k)<∑ a : ↥(Sᶜ),if f a=j then d (a.val.natAdd (8*k)) else 0 := by
  classical
  obtain ⟨hp,hT,hcap⟩ := diffuse_tail_weight_bounds hk d hd horder hhead
  let t := fun i : Fin p => d (i.natAdd (8*k))
  have htorder : Antitone t := fun i j hij => horder (by simpa only [Fin.le_def,Fin.val_natAdd] using Nat.add_le_add_left hij (8*k))
  obtain ⟨S,hS,hSmass,hremain⟩ := exists_diffuse_reserve hk hq hp t (fun i => hd _) htorder
  let e : Fin (Fintype.card ↥(Sᶜ)) ≃ ↥(Sᶜ) := (Fintype.equivFin ↥(Sᶜ)).symm
  let v := fun a : Fin (Fintype.card ↥(Sᶜ)) => t (e a).val
  have hsum : (∑ a,v a)=∑ i∈Sᶜ,t i := by
    have hh := Equiv.sum_comp e (fun i : ↥(Sᶜ) => t i.val)
    rw [Finset.sum_coe_sort] at hh
    exact hh
  have htotal : 3*(∑ i,d i)/8<∑ a,v a := by
    rw [hsum]
    have hcomp : Sᶜ=Finset.univ \ S := Finset.compl_eq_univ_sdiff S
    rw [hcomp]
    dsimp [t] at hremain
    linarith
  have hs : 0<∑ i,d i := Finset.sum_pos (fun i _ => hd i) ⟨⟨0,by omega⟩,Finset.mem_univ _⟩
  obtain ⟨f0,hf0⟩ := exists_diffuse_weight_partition hk hs v (fun i => (hd _).le) (fun i => (hcap _).le) htotal
  let f := fun a : ↥(Sᶜ) => f0 (e.symm a)
  have hmass (j) : (∑ i,d i)/(8*k)<∑ a : ↥(Sᶜ),if f a=j then t a.val else 0 := by
    have hh := Equiv.sum_comp e (fun a : ↥(Sᶜ) => if f a=j then t a.val else 0)
    simp only [f,Equiv.symm_apply_apply] at hh
    rw [← hh]
    exact hf0 j
  have hsurj : Function.Surjective f := by
    intro j
    by_contra! hn
    have hh := hmass j
    simp only [ite_eq_right (hn _),Finset.sum_const_zero] at hh
    have hpos : 0<(∑ i,d i)/(8*k) := by positivity
    linarith
  exact ⟨S,hS,hSmass,f,hsurj,hmass⟩

end SpectralComparison
