import SpectralComparison.SelectionGroups
import SpectralComparison.LightNoise

/-! The actual selected light rows provide the PSD noise floor of (7.10). -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- The amplitude matrix of singleton-selected groups has a diagonal row Gram. -/
theorem selected_light_gram {n g : Type*} [Fintype n] [Fintype g]
    [DecidableEq n] [DecidableEq g]
    (f : n → Option g) (u : n → ℝ) (L : Finset g)
    (hL : ∀ j∈L,(Finset.univ.filter (fun i => f i=some j)).card=1) :
    let E : Matrix n L ℝ := Matrix.of (fun i j => if f i=some j.val then u i else 0)
    E*Eᴴ=Matrix.diagonal (fun i => if ∃ j∈L,f i=some j then (u i)^2 else 0) := by
  classical
  dsimp only
  ext i x
  rw [Matrix.mul_apply]
  simp only [Matrix.conjTranspose_apply,star_trivial,Matrix.of_apply,Matrix.diagonal_apply]
  by_cases hix : i=x
  · subst x
    rw [ite_eq_left rfl]
    by_cases hi : ∃ j∈L,f i=some j
    · obtain ⟨j,hj,hf⟩ := hi
      rw [ite_eq_left ⟨j,hj,hf⟩]
      rw [Finset.sum_eq_single (⟨j,hj⟩ : L)]
      · simp [hf,pow_two]
      · intro a _ ha
        have hja : j≠a.val := by intro hh; apply ha; exact Subtype.ext hh.symm
        simp [hf,hja]
      · simp
    · rw [ite_eq_right hi]
      apply Finset.sum_eq_zero
      intro j _
      have hf : f i≠some j.val := by intro hh; exact hi ⟨j.val,j.property,hh⟩
      simp [hf]
  · rw [ite_eq_right hix]
    apply Finset.sum_eq_zero
    intro j _
    by_cases hi : f i=some j.val
    · have hx : f x≠some j.val := by
        intro hx
        exact hix (selected_light_unique f (hL j.val j.property) hi hx)
      simp [hx]
    · simp [hi]

/-- Light-row isolation follows from group isolation and the actual selection count. -/
theorem selected_light_isolated {n g : Type*} [Fintype n] [Fintype g]
    [DecidableEq n] [DecidableEq g]
    (f : n → Option g) (L : Finset g)
    (hL : ∀ j∈L,(Finset.univ.filter (fun i => f i=some j)).card=1)
    (D : Matrix n n ℝ) (hcross : ∀ i x,f i≠f x → D i x=0) :
    ∀ i,(∃ j∈L,f i=some j) → ∀ x,i≠x → D i x=0 := by
  intro i hi x hix
  obtain ⟨j,hj,hf⟩ := hi
  apply hcross
  intro heq
  exact hix (selected_light_unique f (hL j hj) hf (heq.symm.trans hf))

/-- Equation (7.10)'s PSD floor for an actual selection, including arbitrary singleton rows.
Only genuinely isolated light coordinates are removed from the block covariance. -/
theorem actual_selection_noise_floor {n g : Type*} [Fintype n] [Fintype g]
    [DecidableEq n] [DecidableEq g]
    (f : n → Option g) (u : n → ℝ) (L : Finset g)
    (hL : ∀ j∈L,(Finset.univ.filter (fun i => f i=some j)).card=1)
    (C D : Matrix n n ℝ) (hD : D.PosSemidef) (hCD : (C-D).PosSemidef)
    (hcross : ∀ i x,f i≠f x → D i x=0)
    (mass : g → ℝ) (hdiag : ∀ i j,f i=some j → D i i=mass j*(u i)^2)
    (v : ℝ) (hv : ∀ j∈L,v≤mass j) :
    let E : Matrix n L ℝ := Matrix.of (fun i j => if f i=some j.val then u i else 0)
    (C-v•(E*Eᴴ)).PosSemidef := by
  classical
  let A := Finset.univ.filter (fun i => ∃ j∈L,f i=some j)
  have hiso := selected_light_isolated f L hL D hcross
  have hb : ∀ i∈A,v*(u i)^2≤D i i := by
    intro i hi
    obtain ⟨j,hj,hf⟩ := (Finset.mem_filter.mp hi).2
    rw [hdiag i j hf]
    exact mul_le_mul_of_nonneg_right (hv j hj) (sq_nonneg _)
  have hgap := light_diagonal_noise_gap hD hCD A
    (fun i hi => hiso i ((Finset.mem_filter.mp hi).2)) (fun i => v*(u i)^2) hb
  dsimp only
  rw [selected_light_gram f u L hL]
  convert hgap using 2
  ext i x
  simp only [Matrix.smul_apply,Matrix.diagonal_apply,smul_eq_mul]
  by_cases hix : i=x
  · subst x
    by_cases hi : ∃ j∈L,f i=some j <;> simp [A,hi]
  · simp [hix]

end SpectralComparison
