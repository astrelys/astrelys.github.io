import SpectralComparison.GaussianProjection
import Mathlib.Topology.Algebra.MvPolynomial
import Mathlib.Algebra.MvPolynomial.Equiv
import Mathlib.Algebra.Polynomial.Roots

/-! Nonzero polynomials vanish on a null set under independent atomless coordinates. -/
noncomputable section
open MeasureTheory ProbabilityTheory
namespace SpectralComparison

/-- A univariate nonzero polynomial has an atomless-null zero set. -/
theorem polynomial_ae_ne_zero (μ : Measure ℝ) [NullSingletonClass μ]
    (p : Polynomial ℝ) (hp : p ≠ 0) : ∀ᵐ x ∂μ, p.eval x ≠ 0 := by
  apply ae_iff.mpr
  simpa only [not_not, Polynomial.IsRoot] using (Polynomial.finite_setOfPred_isRoot hp).measure_zero μ

/-- The multivariable zero-set assertion used for Gaussian rank arguments, for Fin-indexed
independent coordinates. Atomlessness is enough; the proof does not assume a density formula. -/
theorem mvPolynomial_fin_ae_ne_zero (μ : Measure ℝ) [IsProbabilityMeasure μ]
    [NullSingletonClass μ] (n : ℕ) (p : MvPolynomial (Fin n) ℝ) (hp : p ≠ 0) :
    ∀ᵐ x ∂(Measure.pi (fun _ : Fin n => μ)), MvPolynomial.eval x p ≠ 0 := by
  induction n with
  | zero =>
    apply ae_of_all
    intro x h
    apply hp
    rw [MvPolynomial.eq_C_of_isEmpty p] at h ⊢
    simpa using h
  | succ n ih =>
    let q := MvPolynomial.finSuccEquiv ℝ n p
    have hq : q ≠ 0 := by simpa [q] using hp
    obtain ⟨k, hk⟩ : ∃ k, q.coeff k ≠ 0 := by
      by_contra! h
      apply hq
      apply Polynomial.ext
      intro k
      simpa using h k
    let e := MeasurableEquiv.piFinSuccAbove (fun _ : Fin (n+1) => ℝ) 0
    have hm : Measurable (fun z : ℝ × (Fin n → ℝ) => MvPolynomial.eval (e.symm z) p) :=
      p.continuous_eval.measurable.comp e.symm.measurable
    have he (x : ℝ) (y : Fin n → ℝ) : e.symm (x,y) = Fin.cons x y := by
      ext i
      simp [e, MeasurableEquiv.piFinSuccAbove_symm_apply, Fin.insertNthEquiv]
    have hprod : ∀ᵐ z ∂(μ.prod (Measure.pi (fun _ : Fin n => μ))),
        MvPolynomial.eval (e.symm z) p ≠ 0 := by
      apply (Measure.ae_prod_iff_ae_ae (measurableSet_eq_fun hm measurable_const).compl).mpr
      rw [Measure.ae_ae_comm (measurableSet_eq_fun hm measurable_const).compl]
      filter_upwards [ih (q.coeff k) hk] with y hy
      have hqy : Polynomial.map (MvPolynomial.eval y) q ≠ 0 := by
        intro h
        have hc := congrArg (fun r : Polynomial ℝ => r.coeff k) h
        simp only [Polynomial.coeff_map, Polynomial.coeff_zero] at hc
        exact hy hc
      have ht := polynomial_ae_ne_zero μ (Polynomial.map (MvPolynomial.eval y) q) hqy
      simpa only [he, MvPolynomial.eval_eq_eval_mv_eval', q] using ht
    have ht := (measurePreserving_piFinSuccAbove (fun _ : Fin (n+1) => μ) 0).quasiMeasurePreserving.ae hprod
    simpa only [e, MeasurableEquiv.symm_apply_apply] using ht

/-- Finite index types can be reindexed without changing the independent-coordinate law. -/
theorem mvPolynomial_ae_ne_zero {ι : Type*} [Fintype ι] (μ : Measure ℝ)
    [IsProbabilityMeasure μ] [NullSingletonClass μ]
    (p : MvPolynomial ι ℝ) (hp : p ≠ 0) :
    ∀ᵐ x ∂(Measure.pi (fun _ : ι => μ)), MvPolynomial.eval x p ≠ 0 := by
  let e := Fintype.equivFin ι
  have hq : MvPolynomial.rename e p ≠ 0 := by
    intro h0
    apply hp
    apply MvPolynomial.rename_injective e e.injective
    simpa using h0
  have h := mvPolynomial_fin_ae_ne_zero μ (Fintype.card ι) (MvPolynomial.rename e p) hq
  have ht := (measurePreserving_piCongrLeft (fun _ : Fin (Fintype.card ι) => μ) e).quasiMeasurePreserving.ae h
  simpa [MeasurableEquiv.coe_piCongrLeft, Equiv.piCongrLeft_apply,
    MvPolynomial.eval_rename, Function.comp_def] using ht

/-- The manuscript's nonzero-polynomial assertion for any independent standard Gaussians. -/
theorem gaussian_polynomial_ae_ne_zero {Ω ι : Type*} [MeasurableSpace Ω] [Fintype ι]
    {μ : Measure Ω} [IsProbabilityMeasure μ] (X : ι → Ω → ℝ)
    (hX : ∀ i, HasLaw (X i) (gaussianReal 0 1) μ) (hind : iIndepFun X μ)
    (p : MvPolynomial ι ℝ) (hp : p ≠ 0) :
    ∀ᵐ ω ∂μ, MvPolynomial.eval (fun i => X i ω) p ≠ 0 := by
  let _ : NullSingletonClass (gaussianReal 0 1) := nullSingletonClass_gaussianReal (by simp)
  have h := mvPolynomial_ae_ne_zero (gaussianReal 0 1) p hp
  exact ae_of_ae_map (hind.hasLaw_pi hX).aemeasurable
    (p := fun x => MvPolynomial.eval x p ≠ 0) (by
      rw [(hind.hasLaw_pi hX).map_eq]
      exact h)

end SpectralComparison
