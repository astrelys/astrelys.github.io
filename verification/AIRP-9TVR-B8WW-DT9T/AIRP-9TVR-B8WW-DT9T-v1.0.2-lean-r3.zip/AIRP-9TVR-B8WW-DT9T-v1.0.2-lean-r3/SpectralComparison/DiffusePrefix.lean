import SpectralComparison.PrefixBound

/-! The concentrated-prefix branch of the diffuse-tail proposition. -/
noncomputable section
namespace SpectralComparison

/-- Equation (7.1) whenever the first min(m,8k) tail entries carry at least half the tail mass. -/
theorem diffuse_bound_of_prefix_mass {n k q : ℕ} (eig : Fin n → ℝ) (heig : ∀ i,0<eig i)
    (horder : Antitone eig) (hk : 1≤k) (hkn : k<n) (hq : 4*q≤k)
    (hmass : (∑ i ∈ Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n),eig i)/2 ≤
      ∑ j : Fin (min (n-k) (8*k)),eig ⟨k+j.val,by have := j.isLt; omega⟩) :
    let s := ∑ i ∈ Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n),eig i
    let a := eig ⟨k-q-1,by omega⟩
    let V := (k:ℝ)*s/(64000000000000000000000000000*((q:ℝ)+Real.sqrt k)*H (8*k))
    max s (a*V/(a+V))≤worstError eig k := by
  classical
  let s := ∑ i ∈ Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n),eig i
  let a := eig ⟨k-q-1,by omega⟩
  let D := 32000000000000000000000000000*((q:ℝ)+Real.sqrt k)
  let V := (k:ℝ)*s/(2*D*H (8*k))
  have hk0 : (0:ℝ)<k := by exact_mod_cast (show 0<k by omega)
  have hD : 0<D := by dsimp [D]; positivity
  have hH : 0<H (8*k) := lt_of_lt_of_le zero_lt_one (one_le_H (by omega))
  have hs : 0<s := by
    dsimp [s]
    rw [← indexed_tail_sum hkn eig]
    apply Finset.sum_pos (fun i _ => heig _)
    exact ⟨⟨0,by omega⟩,Finset.mem_univ _⟩
  have ha : 0<a := heig _
  have hV : 0<V := by dsimp [V]; positivity
  obtain ⟨i,hi⟩ := exists_harmonic_prefix_scale (show 1≤min (n-k) (8*k) by omega)
    (fun j : Fin (min (n-k) (8*k)) => eig ⟨k+j.val,by have := j.isLt; omega⟩)
  let t := i.val+1
  have ht : 1≤t := by dsimp [t]; omega
  have htn : k+t≤n := by have := i.isLt; dsimp [t]; omega
  let b := eig ⟨k+t-1,by omega⟩
  let L := (k:ℝ)*t/D
  have hb : 0<b := heig _
  have hL : 0<L := div_pos (mul_pos hk0 (by exact_mod_cast (show 0<t by omega))) hD
  have hbval : eig ⟨k+i.val,by have := i.isLt; omega⟩=b := by congr 1
  have hscale : s/2≤H (8*k)*(t:ℝ)*b := by
    apply hmass.trans
    apply hi.trans
    rw [hbval]
    have hhh := mul_le_mul_of_nonneg_right (H_mono (min_le_right (n-k) (8*k)))
      (mul_pos (by positivity : (0:ℝ)<(i.val:ℝ)+1) hb).le
    simpa only [t,Nat.cast_add,Nat.cast_one,mul_assoc] using hhh
  have hscale' : s/(2*H (8*k))≤(t:ℝ)*b := (div_le_iff₀ (by positivity)).mpr (by nlinarith)
  have hVbL : V≤b*L := by
    calc
      V = (k:ℝ)/D*(s/(2*H (8*k))) := by dsimp [V]; simp only [div_eq_mul_inv,_root_.mul_inv_rev]; ring
      _ ≤ (k:ℝ)/D*((t:ℝ)*b) := mul_le_mul_of_nonneg_left hscale' (div_pos hk0 hD).le
      _ = b*L := by dsimp [L]; ring
  have hbound : a*(b*L)/(a+b*L)≤worstError eig k :=
    prefix_fixed_length_bound eig heig horder hk (by omega) ht htn
  have hdiag : s≤worstError eig k := (le_max_left _ _).trans (paper_proposition_prefix eig heig horder hk hkn (show 2*q≤k by omega))
  have h := max_le hdiag ((parallel_sum_mono ha le_rfl hV hVbL).trans hbound)
  convert h using 1
  dsimp [V,D,s,a]
  congr 1
  ring

end SpectralComparison
