import SpectralComparison.BalancedReplication
import SpectralComparison.FrameCompletion
import SpectralComparison.PrefixComplement

/-! Exact complementary-basis costs and their transfer to actual frames. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Equally sized rectangular index types have simultaneous invertible Grams and equal inverse traces. -/
theorem equal_dimension_gram_inverses {j p : Type*} [Fintype j] [Fintype p]
    [DecidableEq j] [DecidableEq p] (A : Matrix j p ℝ) (hd : Fintype.card j=Fintype.card p) :
    (IsUnit (A*Aᴴ) ↔ IsUnit (Aᴴ*A)) ∧ (A*Aᴴ)⁻¹.trace=(Aᴴ*A)⁻¹.trace := by
  classical
  let e : p ≃ j := Fintype.equivOfCardEq hd.symm
  let B := A.submatrix e id
  have hr : B*Bᴴ=(A*Aᴴ).submatrix e e := by ext i l; simp [B,Matrix.mul_apply]
  have hc : Bᴴ*B=Aᴴ*A := by
    dsimp [B]
    rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,Matrix.submatrix_id_id]
  constructor
  · rw [← Matrix.isUnit_submatrix_equiv e e,← hr,← hc,Matrix.isUnit_iff_isUnit_det,Matrix.isUnit_iff_isUnit_det,
      Matrix.det_mul,Matrix.det_mul]
    rw [mul_comm]
  · rw [← inverse_gram_trace_reindex A e,← hc,Matrix.mul_inv_rev,Matrix.mul_inv_rev,Matrix.trace_mul_comm]

/-- Complementary square row bases are nonsingular together; inverse costs differ by k-d. -/
theorem complementary_frame_basis_cost {n k d : ℕ} (hdim : k+d=n)
    (Q : Matrix (Fin n) (Fin d) ℝ) (R : Matrix (Fin n) (Fin k) ℝ)
    (hQ : Qᴴ*Q=1) (hQR : Q*Qᴴ+R*Rᴴ=1)
    (I : Finset (Fin n)) (hI : I.card=k) :
    let P := (R*Rᴴ).submatrix (fun i : I => (i:Fin n)) (fun i : I => (i:Fin n))
    let S := (Q*Qᴴ).submatrix (fun i : ↥(Iᶜ) => (i:Fin n)) (fun i : ↥(Iᶜ) => (i:Fin n))
    (IsUnit P ↔ IsUnit S) ∧
    (IsUnit P → P⁻¹.trace=(k:ℝ)-(d:ℝ)+S⁻¹.trace) := by
  let A := Q.submatrix (fun i : I => (i:Fin n)) id
  let B := Q.submatrix (fun i : ↥(Iᶜ) => (i:Fin n)) id
  have hR : R*Rᴴ=1-Q*Qᴴ := eq_sub_of_add_eq' hQR
  have hp : (R*Rᴴ).submatrix (fun i : I => (i:Fin n)) (fun i : I => (i:Fin n))=1-A*Aᴴ := by
    rw [hR,complementary_projection_block]
  have hs : (Q*Qᴴ).submatrix (fun i : ↥(Iᶜ) => (i:Fin n)) (fun i : ↥(Iᶜ) => (i:Fin n))=B*Bᴴ := by
    ext i l; simp [B,Matrix.mul_apply]
  have hb : Bᴴ*B=1-Aᴴ*A := parseval_complement_row_gram Q hQ I
  have hIc : Iᶜ.card=d := by rw [Finset.card_compl,hI]; simp only [Fintype.card_fin]; omega
  have hdimB : Fintype.card ↥(Iᶜ)=Fintype.card (Fin d) := by simp only [Fintype.card_coe,Fintype.card_fin]; exact hIc
  obtain ⟨hunit,htrace⟩ := equal_dimension_gram_inverses B hdimB
  dsimp only
  rw [hp,hs]
  constructor
  · rw [hunit,hb]; exact complement_gram_isUnit_iff A
  · intro hu
    have h := complement_gram_inverse_trace A ((complement_gram_isUnit_iff A).mp hu)
    rw [← hb,← htrace] at h
    simpa only [Fintype.card_coe,hI,Fintype.card_fin] using h

/-- Any uniform d-basis bound transfers to a complementary k-frame with exact dimension shift. -/
theorem exists_complementary_frame_control {n k d : ℕ} (hdim : k+d=n)
    (Q : Matrix (Fin n) (Fin d) ℝ) (hQ : Qᴴ*Q=1) {L : ℝ}
    (hb : ∀ J : Finset (Fin n), J.card=d →
      IsUnit ((Q*Qᴴ).submatrix (fun i : J => (i:Fin n)) (fun i : J => (i:Fin n))) →
      L≤((Q*Qᴴ).submatrix (fun i : J => (i:Fin n)) (fun i : J => (i:Fin n)))⁻¹.trace) :
    ∃ R : Matrix (Fin n) (Fin k) ℝ, Rᴴ*R=1 ∧
      ∀ I : Finset (Fin n), I.card=k →
      IsUnit ((R*Rᴴ).submatrix (fun i : I => (i:Fin n)) (fun i : I => (i:Fin n))) →
      (k:ℝ)-(d:ℝ)+L≤((R*Rᴴ).submatrix (fun i : I => (i:Fin n)) (fun i : I => (i:Fin n)))⁻¹.trace := by
  obtain ⟨R,hR,_,hQR,_,_⟩ := exists_orthogonal_frame_completion (h:=Fin k) Q hQ (by simpa using hdim)
  refine ⟨R,hR,?_⟩
  intro I hI hu
  obtain ⟨hi,ht⟩ := complementary_frame_basis_cost hdim Q R hQ hQR I hI
  have hIc : Iᶜ.card=d := by rw [Finset.card_compl,hI]; simp only [Fintype.card_fin]; omega
  rw [ht hu]
  linarith [hb Iᶜ hIc (hi.mp hu)]

end SpectralComparison
