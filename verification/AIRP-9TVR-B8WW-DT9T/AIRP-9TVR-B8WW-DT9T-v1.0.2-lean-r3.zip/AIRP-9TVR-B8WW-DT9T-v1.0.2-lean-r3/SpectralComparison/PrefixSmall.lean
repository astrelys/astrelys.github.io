import SpectralComparison.RobustFrame
import SpectralComparison.UniformProjection

/-! The short-prefix branch of the exact prefix projection bound. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Comparison of the literal manuscript constants in the branch t <= k. -/
theorem prefix_short_constant_comparison {k q t : ℕ} (hk : 1≤k) (hq : 2*q≤k)
    (ht : 1≤t) (htk : t≤k) :
    (k:ℝ)*t/(32000000000000000000000000000*((q:ℝ)+Real.sqrt k)) ≤
    ((k+t:ℕ):ℝ)*t/(4000000000000000000000000000*((q:ℝ)+Real.sqrt (t+q:ℕ))) := by
  have hk0 : (0:ℝ)<k := by exact_mod_cast hk
  have hq0 := Nat.cast_nonneg (α := ℝ) q
  have ht0 := Nat.cast_nonneg (α := ℝ) t
  have hkt : (t+q:ℕ) ≤ (4:ℝ)*k := by exact_mod_cast (show t+q≤4*k by omega)
  have hroot : Real.sqrt (t+q:ℕ) ≤ 2*Real.sqrt k := by
    nlinarith [Real.sq_sqrt (Nat.cast_nonneg (t+q)), Real.sq_sqrt hk0.le,
      Real.sqrt_nonneg (t+q:ℕ), Real.sqrt_nonneg (k:ℝ)]
  have hd : 0 < (q:ℝ)+Real.sqrt k := add_pos_of_nonneg_of_pos hq0 (Real.sqrt_pos.mpr hk0)
  have he : 0 < (q:ℝ)+Real.sqrt (t+q:ℕ) := add_pos_of_nonneg_of_pos hq0
    (Real.sqrt_pos.mpr (by exact_mod_cast (show 0<t+q by omega)))
  apply (div_le_div_iff₀ (mul_pos (by norm_num) hd) (mul_pos (by norm_num) he)).mpr
  have hc : (4000000000000000000000000000:ℝ)*((q:ℝ)+Real.sqrt (t+q:ℕ)) ≤
      32000000000000000000000000000*((q:ℝ)+Real.sqrt k) := by nlinarith [Real.sqrt_nonneg (k:ℝ)]
  have hn : (k:ℝ)*t ≤ ((k+t:ℕ):ℝ)*t := by push_cast; nlinarith
  exact (mul_le_mul_of_nonneg_left hc (mul_nonneg hk0.le ht0)).trans
    (mul_le_mul_of_nonneg_right hn (by positivity))

/-- The full unregularized prefix projection statement for t <= k. -/
theorem prefix_projection_short {k q t : ℕ} (hk : 1≤k) (hq : 2*q≤k)
    (ht : 1≤t) (htk : t≤k) :
    ∃ P : Matrix (Fin (k+t)) (Fin (k+t)) ℝ, P.PosSemidef ∧ P*P=P ∧ P.rank=t+q ∧
      ∀ J : Finset (Fin (k+t)), J.card=t →
        IsUnit (P.submatrix (fun i : J => (i:Fin (k+t))) (fun i : J => (i:Fin (k+t)))) →
        (k:ℝ)*t/(32000000000000000000000000000*((q:ℝ)+Real.sqrt k)) ≤
        (P.submatrix (fun i : J => (i:Fin (k+t))) (fun i : J => (i:Fin (k+t))))⁻¹.trace := by
  obtain ⟨V,hV,hb⟩ := exists_uniform_projection_frame ht (show 4*(t+q)≤3*(k+t) by omega)
  obtain ⟨_,hi,hr⟩ := frame_projection_properties V hV
  refine ⟨V*Vᴴ,posSemidef_self_mul_conjTranspose V,hi,by simpa using hr,?_⟩
  intro J hJ hu
  exact (prefix_short_constant_comparison hk hq ht htk).trans (hb J hJ hu)

end SpectralComparison
