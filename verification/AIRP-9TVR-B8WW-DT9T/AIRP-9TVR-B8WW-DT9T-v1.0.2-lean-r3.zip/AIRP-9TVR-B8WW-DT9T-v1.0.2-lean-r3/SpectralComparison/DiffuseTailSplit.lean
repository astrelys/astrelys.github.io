import SpectralComparison.ReserveWeights

/-! The small-head branch leaves many individually small positive tail weights. -/
noncomputable section
namespace SpectralComparison

/-- Removing the first 8k tail entries leaves mass above s/2, more than 8k entries,
and each remaining entry below s/(16k). Coordinates are the explicit head-plus-tail split. -/
theorem diffuse_tail_weight_bounds {k p : ℕ} (hk : 1≤k)
    (d : Fin (8*k+p) → ℝ) (hd : ∀ i,0<d i) (horder : Antitone d)
    (hhead : (∑ i : Fin (8*k),d (i.castAdd p))<(∑ i,d i)/2) :
    8*k<p ∧ (∑ i,d i)/2<(∑ j : Fin p,d (j.natAdd (8*k))) ∧
      ∀ j : Fin p,d (j.natAdd (8*k))<(∑ i,d i)/(16*k) := by
  have hkR : (0:ℝ)<k := by exact_mod_cast (show 0<k by omega)
  let s := ∑ i,d i
  let A := ∑ i : Fin (8*k),d (i.castAdd p)
  let T := ∑ j : Fin p,d (j.natAdd (8*k))
  have hs : 0<s := Finset.sum_pos (fun i _ => hd i) ⟨⟨0,by omega⟩,Finset.mem_univ _⟩
  have hsplit : s=A+T := Fin.sum_univ_add d
  have hT : s/2<T := by dsimp [s,A,T] at *; linarith
  have hcap (j : Fin p) : d (j.natAdd (8*k))<s/(16*k) := by
    have hh : (8*k:ℝ)*d (j.natAdd (8*k))≤A := by
      have hb := Finset.sum_le_sum (s:=Finset.univ) (fun (i : Fin (8*k)) _ =>
        horder (show i.castAdd p≤j.natAdd (8*k) by change i.val≤8*k+j.val; have := i.isLt; omega))
      simpa only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,Nat.cast_mul,Nat.cast_ofNat] using hb
    apply (lt_div_iff₀ (by positivity)).mpr
    change A<s/2 at hhead
    nlinarith
  have hp : 8*k<p := by
    by_contra! hn
    have hpR : (p:ℝ)≤8*k := by exact_mod_cast hn
    have hh : T≤(p:ℝ)*(s/(16*k)) := by
      have hh := Finset.sum_le_sum (s:=Finset.univ) (fun j _ => (hcap j).le)
      simpa only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] using hh
    have hc : (p:ℝ)*(s/(16*k))≤(8*k)*(s/(16*k)) := mul_le_mul_of_nonneg_right hpR (by positivity)
    have hid : (8*k:ℝ)*(s/(16*k))=s/2 := by field_simp; ring
    rw [hid] at hc
    linarith
  exact ⟨hp,hT,hcap⟩

end SpectralComparison
