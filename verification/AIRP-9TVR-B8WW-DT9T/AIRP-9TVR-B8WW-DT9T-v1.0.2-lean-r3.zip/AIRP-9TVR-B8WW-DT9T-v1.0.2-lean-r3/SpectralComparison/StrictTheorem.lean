import SpectralComparison.StrictStabilityBridge

noncomputable section
open Finset
namespace SpectralComparison

/-- The final deficit dichotomy is quantitative and uses the exact eta constraint. -/
theorem strict_deficit_dichotomy {n m η g B D F X : ℝ}
    (hn : 0<n) (hη : 0<η) (hηm : η<m) (hg : 0<g)
    (hB : B≤n) (hBX : B≤X) (hD : 0≤D) (he : n*F=m*B-n*D)
    (hηg : η≤m*g/(2*n+g)) (hsmall : D<η → n+g/2≤X) :
    F≤(m-η)/n*X := by
  have hm : 0<m := hη.trans hηm
  have hc : 0≤(m-η)/n := div_nonneg (sub_nonneg.mpr hηm.le) hn.le
  by_cases hlarge : η≤D
  · have hηB := mul_le_mul_of_nonneg_left hB hη.le
    have hnD := mul_le_mul_of_nonneg_left hlarge hn.le
    have hf : F≤(m-η)/n*B := by
      rw [div_mul_eq_mul_div]
      apply (le_div_iff₀ hn).mpr
      nlinarith
    exact hf.trans (mul_le_mul_of_nonneg_left hBX hc)
  · have hx := hsmall (lt_of_not_ge hlarge)
    have hf : F≤m := by
      have hmB := mul_le_mul_of_nonneg_left hB hm.le
      have hnD : 0≤n*D := mul_nonneg hn.le hD
      nlinarith
    have hgη := (le_div_iff₀ (by positivity : 0<2*n+g)).mp hηg
    have hmid : m≤(m-η)/n*(n+g/2) := by
      rw [div_mul_eq_mul_div]
      apply (le_div_iff₀ hn).mpr
      nlinarith
    exact hf.trans (hmid.trans (mul_le_mul_of_nonneg_left hx hc))

/-- D.2 on normalized ordered spectra, with the literal manuscript constants. -/
theorem strict_normalized_sorted {k m : ℕ} (hk : 2≤k) (hm : 2≤m)
    (a : Fin (k+m) → ℝ) (ha : ∀ i,0<a i) (horder : Antitone a) (hroot : waterSum a 1=k) :
    spectralMean a k≤(((k:ℝ)+1)*((m:ℝ)-strictEta k m)/((k:ℝ)+m))*worstError a k := by
  let S := Finset.univ.filter (fun i => 1<a i)
  let T := ∑ i∈Finset.univ\S,a i
  let B := (S.card:ℝ)+T
  let F := symmetricQuotient (Finset.univ.val.map a) k
  let D := (m:ℝ)/((k:ℝ)+m)*B-F
  obtain ⟨hg,hN,hη,hL2,hLN,hLH,hη1,hη2,hη3,hη4⟩ := strict_constants hk hm
  have hn : 0<(k:ℝ)+m := by positivity
  have ht := water_tail_bound a ha (by omega) (by norm_num : (0:ℝ)<1) hroot
  have hcard : S.card≤k+m := by simpa using S.card_le_univ
  have hB : B≤(k:ℝ)+m := by
    change 0≤T ∧ T≤(k+m-S.card:ℕ)*1 at ht
    rw [Nat.cast_sub hcard,Nat.cast_add,mul_one] at ht
    dsimp [B]
    linarith [ht.2]
  have hBX := water_orientation_lower a ha (by omega) (by omega) (by norm_num : (0:ℝ)<1) hroot
  simp only [mul_one] at hBX
  change B≤worstError a k at hBX
  have hD := (original_water_stability a ha (by omega) (by omega) (by omega) hroot).1
  simp only [Nat.add_sub_cancel_left,Nat.cast_add] at hD
  change 0≤D at hD
  have he : ((k:ℝ)+m)*F=(m:ℝ)*B-((k:ℝ)+m)*D := by dsimp [D]; field_simp; ring
  have hsmall : D<strictEta k m → (k:ℝ)+m+strictGap k m/2≤worstError a k :=
    strict_small_deficit_error hk hm a ha horder hroot
  have h := strict_deficit_dichotomy hn hη (strictEta_lt_remaining hk hm) hg hB hBX hD he hη4 hsmall
  rw [spectralMean_eq_quotient]
  change ((k:ℝ)+1)*F≤_
  have hh := mul_le_mul_of_nonneg_left h (by positivity : 0≤(k:ℝ)+1)
  convert hh using 1 <;> ring

/-- Homogeneity removes the water normalization without any additional spectral hypotheses. -/
theorem strict_sorted {k m : ℕ} (hk : 2≤k) (hm : 2≤m)
    (a : Fin (k+m) → ℝ) (ha : ∀ i,0<a i) (horder : Antitone a) :
    spectralMean a k≤(((k:ℝ)+1)*((m:ℝ)-strictEta k m)/((k:ℝ)+m))*worstError a k := by
  obtain ⟨τ,⟨hτ,hr⟩,_⟩ := exists_unique_waterLevel (k:=k) a ha (by omega) (by omega)
  let b := fun i => τ⁻¹*a i
  have hb : ∀ i,0<b i := fun i => mul_pos (inv_pos.mpr hτ) (ha i)
  have ho : Antitone b := fun i j hij => mul_le_mul_of_nonneg_left (horder hij) (inv_pos.mpr hτ).le
  have hroot : waterSum b 1=k := by
    have he : waterSum b 1=waterSum a τ := by
      unfold waterSum
      apply Finset.sum_congr rfl
      intro i _
      congr 2
      dsimp [b]
      field_simp
    rw [he,hr]
  have h := strict_normalized_sorted hk hm b hb ho hroot
  rw [spectralMean_smul a k (inv_pos.mpr hτ),worstError_smul a ha (inv_pos.mpr hτ) (by simp; omega)] at h
  have hh : τ⁻¹*spectralMean a k≤τ⁻¹*((((k:ℝ)+1)*((m:ℝ)-strictEta k m)/((k:ℝ)+m))*worstError a k) := by
    convert h using 1 <;> ring
  exact (mul_le_mul_iff_right₀ (inv_pos.mpr hτ)).mp hh

/-- Complete original D.2: exact positive constants and uniform strict improvement for every positive spectrum. -/
theorem paper_uniform_strict {k m : ℕ} (hk : 2≤k) (hm : 2≤m)
    (a : Fin (k+m) → ℝ) (ha : ∀ i,0<a i) :
    0<strictGap k m ∧ 0<strictEta k m ∧
      spectralMean a k≤(((k:ℝ)+1)*((m:ℝ)-strictEta k m)/((k:ℝ)+m))*worstError a k ∧
      (((k:ℝ)+1)*((m:ℝ)-strictEta k m)/((k:ℝ)+m))*worstError a k<
        (((k:ℝ)+1)*(m:ℝ)/((k:ℝ)+m))*worstError a k := by
  let e := Tuple.sort (α:=OrderDual ℝ) a
  have ho : Antitone (a ∘ e) := Tuple.monotone_sort (α:=OrderDual ℝ) a
  have hb := strict_sorted hk hm (a ∘ e) (fun _ => ha _) ho
  simp only [worstError_comp_equiv,spectralMean_comp_equiv] at hb
  have h := strict_constants hk hm
  have hη := h.2.2.1
  refine ⟨h.1,hη,hb,?_⟩
  have hx : 0<worstError a k := worstError_pos a ha (by simp; omega)
  apply mul_lt_mul_of_pos_right _ hx
  apply (div_lt_div_iff_of_pos_right (by positivity : 0<(k:ℝ)+m)).mpr
  nlinarith [mul_pos (by positivity : 0<(k:ℝ)+1) hη]

end SpectralComparison
