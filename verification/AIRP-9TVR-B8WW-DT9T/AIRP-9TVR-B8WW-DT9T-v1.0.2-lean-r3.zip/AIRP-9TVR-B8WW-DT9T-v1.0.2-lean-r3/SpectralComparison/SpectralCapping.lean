import SpectralComparison.FiniteCoordinateChanges

/-! Actual spectral capping at the original spectral mean, equation (C.1). -/
noncomputable section
open Finset Matrix
namespace SpectralComparison
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

theorem esymm_completion_sum (a : ι → ℝ) (k : ℕ) :
    (∑ I∈(Finset.univ : Finset ι).powersetCard k,(∏ i∈I,a i)*(∑ j∈Finset.univ \ I,a j))=
      ((k:ℝ)+1)*(Finset.univ.val.map a).esymm (k+1) := by
  rw [Finset.esymm_map_val]
  have he : (∑ I∈(Finset.univ : Finset ι).powersetCard k,(∏ i∈I,a i)*(∑ j∈Finset.univ \ I,a j))=
      ∑ I∈(Finset.univ : Finset ι).powersetCard k,∑ j∈Finset.univ \ I,∏ l∈insert j I,a l := by
    apply Finset.sum_congr rfl
    intro I _
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j hj
    rw [Finset.prod_insert (Finset.mem_sdiff.mp hj).2]
    ring
  rw [he]
  exact sum_insert_count k (fun I => ∏ i∈I,a i)

theorem count_above_spectralMean (a : ι → ℝ) (ha : ∀ i,0<a i) {k : ℕ}
    (hk : k<Fintype.card ι) : (Finset.univ.filter (fun i => spectralMean a k<a i)).card≤k := by
  by_contra hn
  let S := Finset.univ.filter (fun i => spectralMean a k<a i)
  have hc : k<S.card := by exact lt_of_not_ge hn
  have ht (I : Finset ι) (hI : I.card=k) : spectralMean a k<∑ j∈Finset.univ \ I,a j := by
    have hnot : ¬S⊆I := by intro h; have hcard := Finset.card_le_card h; omega
    obtain ⟨j,hj,hji⟩ := Finset.not_subset.mp hnot
    exact (Finset.mem_filter.mp hj).2.trans_le (Finset.single_le_sum (fun l _ => (ha l).le) (by simp [hji]))
  have hsum : spectralMean a k*(Finset.univ.val.map a).esymm k<
      ((k:ℝ)+1)*(Finset.univ.val.map a).esymm (k+1) := by
    rw [← esymm_completion_sum,Finset.esymm_map_val,Finset.mul_sum]
    apply Finset.sum_lt_sum_of_nonempty (Finset.powersetCard_nonempty.mpr (by simpa using hk.le))
    intro I hI
    have hp : 0<∏ i∈I,a i := Finset.prod_pos (fun i _ => ha i)
    have hh := mul_lt_mul_of_pos_left (ht I (Finset.mem_powersetCard.mp hI).2) hp
    simpa only [mul_comm] using hh
  have hpos : 0<(Finset.univ.val.map a).esymm k := esymm_pos _ (by
    intro z hz; obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz; exact ha i) _ (by simpa using hk.le)
  have he : spectralMean a k*(Finset.univ.val.map a).esymm k=
      ((k:ℝ)+1)*(Finset.univ.val.map a).esymm (k+1) := by
    unfold spectralMean; field_simp
  linarith

theorem spectralQuotient_capped_half (a : ι → ℝ) (ha : ∀ i,0<a i) {k : ℕ}
    (hk : 1≤k) (hkn : k<Fintype.card ι) :
    symmetricQuotient (Finset.univ.val.map a) k/2≤
      symmetricQuotient (Finset.univ.val.map (fun i => min (a i) (spectralMean a k))) k := by
  let F := symmetricQuotient (Finset.univ.val.map a) k
  have hF : 0<F := symmetricQuotient_pos _ (by
    intro z hz; obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz; exact ha i) (by simpa using hkn)
  have hT : 0<spectralMean a k := by rw [spectralMean_eq_quotient]; exact mul_pos (by positivity) hF
  have hp : ∀ i,0<min (a i) (spectralMean a k) := fun i => lt_min (ha i) hT
  have hFc := symmetricQuotient_pos (Finset.univ.val.map (fun i => min (a i) (spectralMean a k)))
    (by intro z hz; obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz; exact hp i) (by simpa using hkn)
  have ht := spectralQuotient_cap_telescope a ha hT hk hkn
  have hc : ((Finset.univ.filter (fun i => spectralMean a k<a i)).card:ℝ)≤(k:ℝ) := by
    exact_mod_cast count_above_spectralMean a ha hkn
  have hsum : ((Finset.univ.filter (fun i => spectralMean a k<a i)).card:ℝ)/spectralMean a k≤1/F := by
    apply (div_le_div_iff₀ hT hF).mpr
    conv_rhs => rw [spectralMean_eq_quotient]
    change _≤1*(((k:ℝ)+1)*F)
    nlinarith [mul_le_mul_of_nonneg_right hc hF.le]
  have hrec : 1/symmetricQuotient (Finset.univ.val.map (fun i => min (a i) (spectralMean a k))) k≤2/F := by
    calc
      _ ≤ 1/F+((Finset.univ.filter (fun i => spectralMean a k<a i)).card:ℝ)/spectralMean a k := by
        simpa only [one_div] using ht
      _ ≤ 1/F+1/F := add_le_add_right hsum _
      _ = 2/F := by ring
  have hh := (div_le_div_iff₀ hFc hF).mp hrec
  change F/2≤_
  linarith

/-- All four conclusions of (C.1), with the original cap T=y_k(lambda). -/
theorem paper_capping {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i) (hk : 1≤k) (hkn : k<n) :
    let c := fun i => min (a i) (spectralMean a k)
    spectralMean a k/2≤spectralMean c k ∧ worstError c k≤worstError a k ∧
      (∀ i,c i≤2*spectralMean c k) ∧
      spectralMean a k/worstError a k≤2*(spectralMean c k/worstError c k) := by
  let c := fun i => min (a i) (spectralMean a k)
  have hy : 0<spectralMean a k := (paper_main_theorem a ha hk hkn).2.2.1.trans_le (worstError_le_spectralMean a ha (by simpa using hkn))
  have hc : ∀ i,0<c i := fun i => lt_min (ha i) hy
  have half : spectralMean a k/2≤spectralMean c k := by
    rw [spectralMean_eq_quotient,spectralMean_eq_quotient]
    have h := mul_le_mul_of_nonneg_left (spectralQuotient_capped_half a ha hk (by simpa using hkn)) (by positivity : 0≤(k:ℝ)+1)
    simpa only [mul_div_assoc] using h
  have hx := worstError_mono c a hc ha (fun i => min_le_left _ _) (by simpa using hkn)
  have hxa := (paper_main_theorem a ha hk hkn).2.2.1
  have hxc := (paper_main_theorem c hc hk hkn).2.2.1
  refine ⟨half,hx,?_,?_⟩
  · intro i; exact (min_le_right _ _).trans (by linarith)
  · calc
      spectralMean a k/worstError a k≤(2*spectralMean c k)/worstError a k :=
        div_le_div_of_nonneg_right (by linarith) hxa.le
      _ ≤(2*spectralMean c k)/worstError c k := div_le_div_of_nonneg_left (by linarith) hxc hx
      _ =2*(spectralMean c k/worstError c k) := by ring

end SpectralComparison
