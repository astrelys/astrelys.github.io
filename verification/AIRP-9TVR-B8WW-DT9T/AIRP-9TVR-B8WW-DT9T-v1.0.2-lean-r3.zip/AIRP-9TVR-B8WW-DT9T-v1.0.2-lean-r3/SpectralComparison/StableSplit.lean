import SpectralComparison.StableHead

noncomputable section
open Finset
namespace SpectralComparison
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Full normalized split-spectrum stability, retaining all tail entries and the original deficit. -/
theorem split_water_stability (a : ι → ℝ) (ha : ∀ i,1<a i)
    (tail : Multiset ℝ) (ht : ∀ z∈tail,0<z ∧ z≤1) {k : ℕ}
    (hk : 1≤k) (hkq : k<Fintype.card ι) (hm : 2≤Fintype.card ι+tail.card-k)
    (hsum : (∑ i,(a i)⁻¹)=(Fintype.card ι-k:ℕ)) :
    let n := Fintype.card ι+tail.card
    let U := (tail.card:ℝ)-tail.sum
    let D := (n-k:ℕ)/(n:ℝ)*((Fintype.card ι:ℝ)+tail.sum)-symmetricQuotient (Finset.univ.val.map a+tail) k
    0≤D ∧ U≤(n:ℝ)*D/k ∧
      (D<(k:ℝ)/(2*n) → (∑ i,(a i)⁻¹*(1-(a i)⁻¹))≤(2:ℝ)^n*D) := by
  let n := Fintype.card ι+tail.card
  let d := Fintype.card ι-k
  let head := Finset.univ.val.map a
  let U := (tail.card:ℝ)-tail.sum
  let F := symmetricQuotient (head+tail) k
  let D := (n-k:ℕ)/(n:ℝ)*((Fintype.card ι:ℝ)+tail.sum)-F
  let V := ∑ i,(a i)⁻¹*(1-(a i)⁻¹)
  have hap : ∀ i,0<a i := fun i => (by norm_num : (0:ℝ)<1).trans (ha i)
  have hh : ∀ z∈head,0<z := by intro z hz; obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz; exact hap i
  have htp : ∀ z∈tail,0<z := fun z hz => (ht z hz).1
  have htail : tail.sum≤(tail.card:ℝ) := by
    simpa using Multiset.sum_le_card_nsmul tail (1:ℝ) (fun z hz => (ht z hz).2)
  have hU : 0≤U := sub_nonneg.mpr htail
  have hnp : 0<(n:ℝ) := by
    have h : 0<n := by dsimp [n]; omega
    exact_mod_cast h
  have hkp : 0<(k:ℝ) := by exact_mod_cast (by omega : 0<k)
  have hnk : k≤n := by dsimp [n]; omega
  have hab := active_water_quotient a hap hkq (by norm_num : (0:ℝ)<1) ha (by simpa only [one_div] using hsum)
  simp only [mul_one] at hab
  have hadd := symmetricQuotient_add_loss head tail hh htp (by simpa [head] using hkq.le)
  have hgap : 0≤(d:ℝ)+tail.sum-F := by dsimp [F,d]; linarith [hab.1]
  have hid : D=(k:ℝ)/(n:ℝ)*U+((d:ℝ)+tail.sum-F) := by
    dsimp [D,U,d]
    rw [Nat.cast_sub hnk,Nat.cast_sub hkq.le]
    have hn : (n:ℝ)=(Fintype.card ι:ℝ)+tail.card := by dsimp [n]; push_cast; rfl
    field_simp
    nlinarith
  have hD : 0≤D := by rw [hid]; positivity
  have hUD : U≤(n:ℝ)*D/k := by
    apply (le_div_iff₀ hkp).mpr
    have hmul := mul_le_mul_of_nonneg_left (show (k:ℝ)/(n:ℝ)*U≤D by linarith [hid]) hnp.le
    have he : (n:ℝ)*((k:ℝ)/(n:ℝ)*U)=(k:ℝ)*U := by field_simp
    rw [he] at hmul
    nlinarith
  change 0≤D ∧ U≤(n:ℝ)*D/k ∧ (D<(k:ℝ)/(2*n) → V≤(2:ℝ)^n*D)
  refine ⟨hD,hUD,?_⟩
  intro hsmall
  by_cases hd : 2≤d
  · have hv := active_variance_loss a ha hd hsum
    have hp : (2:ℝ)^Fintype.card ι≤(2:ℝ)^n := pow_le_pow_right₀ (by norm_num) (by dsimp [n]; omega)
    have hhead : (d:ℝ)-symmetricQuotient head k≤D := by
      have hm0 : 0≤(k:ℝ)/(n:ℝ)*U := by positivity
      linarith [hid]
    have hx := mul_le_mul_of_nonneg_left hhead (by positivity : 0≤(2:ℝ)^Fintype.card ι)
    have hy := mul_le_mul_of_nonneg_right hp hD
    change V≤_ at hv
    exact hv.trans (hx.trans hy)
  · have hd1 : d=1 := by dsimp [d] at *; omega
    have hc : Fintype.card ι=k+1 := by dsimp [d] at hd1; omega
    have hsum1 : (∑ i,(a i)⁻¹)=1 := by simpa only [show Fintype.card ι-k=1 from hd1,Nat.cast_one] using hsum
    have hne : tail≠0 := by intro hz; simp [hz,hc] at hm
    obtain ⟨z,hzmem⟩ := Multiset.exists_mem_of_ne_zero hne
    obtain ⟨rest,he⟩ := Multiset.exists_cons_of_mem hzmem
    have hz : 0<z ∧ z≤1 := ht z (by rw [he]; simp)
    have hr : ∀ w∈rest,0<w ∧ w≤1 := fun w hw => ht w (by rw [he]; simp [hw])
    have hrest : rest.sum≤(rest.card:ℝ) := by
      simpa using Multiset.sum_le_card_nsmul rest (1:ℝ) (fun w hw => (hr w hw).2)
    have hUhalf : U<1/2 := by
      have hs := (lt_div_iff₀ (by positivity : 0<(2:ℝ)*n)).mp hsmall
      have hu := (le_div_iff₀ hkp).mp hUD
      nlinarith
    have hzhalf : 1/2≤z := by
      have hu : U=1-z+((rest.card:ℝ)-rest.sum) := by dsimp [U]; rw [he]; simp; ring
      linarith
    have hfirst := unit_mass_tail_loss a ha hk hc hsum1 hzhalf hz.2
    have hheadp : ∀ w∈z ::ₘ head,0<w := by intro w hw; rcases Multiset.mem_cons.mp hw with rfl|hw; exact hz.1; exact hh w hw
    have hnext := symmetricQuotient_add_loss (k:=k) (z ::ₘ head) rest hheadp (fun w hw => (hr w hw).1) (by simp only [Multiset.card_cons,Multiset.card_map,Finset.card_val,Finset.card_univ,head,hc]; omega)
    have hF : F=symmetricQuotient ((z ::ₘ head)+rest) k := by dsimp [F]; rw [he]; simp [Multiset.cons_add,Multiset.add_cons]
    have htSum : tail.sum=z+rest.sum := by rw [he,Multiset.sum_cons]
    have hvar : V≤4*D := by
      have hm0 : 0≤(k:ℝ)/(n:ℝ)*U := by positivity
      rw [hF] at hid
      rw [hd1,Nat.cast_one,htSum] at hid
      change symmetricQuotient (z ::ₘ head) k≤z+1-V/4 at hfirst
      nlinarith
    have hn2 : 2≤n := by dsimp [n]; omega
    have hpow : (4:ℝ)≤(2:ℝ)^n := by
      have hh := pow_le_pow_right₀ (a:=(2:ℝ)) (by norm_num) hn2
      norm_num at hh ⊢
      exact hh
    exact hvar.trans (mul_le_mul_of_nonneg_right hpow hD)

end SpectralComparison
