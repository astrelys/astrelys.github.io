import SpectralComparison.WeightedSingleton
import SpectralComparison.WeightedComplement
import SpectralComparison.WeightedFrameBase

noncomputable section
open Matrix
namespace SpectralComparison

/-- A weighted basis guarantee is independent of the injective row-label type. -/
theorem weighted_basis_embedding {n p j : Type*} [Fintype n] [Fintype p] [Fintype j]
    [DecidableEq n] [DecidableEq p] [DecidableEq j]
    (Q : Matrix n p ℝ) (b : p → ℝ) {C : ℝ}
    (hb : ∀ I : Finset n,I.card=Fintype.card p →
      IsUnit ((Q.submatrix (fun i : I => (i:n)) id)ᴴ*Q.submatrix (fun i : I => (i:n)) id) →
      C≤(Matrix.diagonal b*((Q.submatrix (fun i : I => (i:n)) id)ᴴ*Q.submatrix (fun i : I => (i:n)) id)⁻¹).trace)
    (f : j → n) (hf : Function.Injective f) (hj : Fintype.card j=Fintype.card p)
    (hu : IsUnit ((Q.submatrix f id)ᴴ*Q.submatrix f id)) :
    C≤(Matrix.diagonal b*((Q.submatrix f id)ᴴ*Q.submatrix f id)⁻¹).trace := by
  classical
  let I := Finset.univ.image f
  let e : j ≃ I := Equiv.ofBijective (fun x => ⟨f x,Finset.mem_image.mpr ⟨x,Finset.mem_univ _,rfl⟩⟩)
    (by
      constructor
      · intro a b hab; exact hf (congrArg Subtype.val hab)
      · intro y; obtain ⟨x,_,hx⟩ := Finset.mem_image.mp y.property; exact ⟨x,Subtype.ext hx⟩)
  let A := Q.submatrix (fun i : I => (i:n)) id
  have he : Q.submatrix f id=A.submatrix e id := rfl
  have hg : (Q.submatrix f id)ᴴ*Q.submatrix f id=Aᴴ*A := by
    rw [he,Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,Matrix.submatrix_id_id]
  rw [hg] at hu ⊢
  exact hb I (by simpa [I,Finset.card_image_of_injective _ hf] using hj) hu

/-- Row and column equivalences preserve the actual weighted basis inequality. -/
theorem weighted_frame_reindex {n p n' p' : Type*}
    [Fintype n] [Fintype p] [Fintype n'] [Fintype p']
    [DecidableEq n] [DecidableEq p] [DecidableEq n'] [DecidableEq p']
    (Q : Matrix n p ℝ) (hQ : Qᴴ*Q=1) (b : p → ℝ) {C : ℝ}
    (hb : ∀ I : Finset n,I.card=Fintype.card p →
      IsUnit ((Q.submatrix (fun i : I => (i:n)) id)ᴴ*Q.submatrix (fun i : I => (i:n)) id) →
      C≤(Matrix.diagonal b*((Q.submatrix (fun i : I => (i:n)) id)ᴴ*Q.submatrix (fun i : I => (i:n)) id)⁻¹).trace)
    (er : n' ≃ n) (ec : p' ≃ p) :
    let R := Q.submatrix er ec
    Rᴴ*R=1 ∧ ∀ J : Finset n',J.card=Fintype.card p' →
      IsUnit ((R.submatrix (fun i : J => (i:n')) id)ᴴ*R.submatrix (fun i : J => (i:n')) id) →
      C≤(Matrix.diagonal (b ∘ ec)*
        ((R.submatrix (fun i : J => (i:n')) id)ᴴ*R.submatrix (fun i : J => (i:n')) id)⁻¹).trace := by
  let R := Q.submatrix er ec
  have hR : Rᴴ*R=1 := by
    dsimp [R]
    rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,hQ,Matrix.submatrix_one ec ec.injective]
  refine ⟨hR,?_⟩
  intro J hJ hu
  let f : J → n := fun i => er i.val
  let A := Q.submatrix f id
  have he : R.submatrix (fun i : J => (i:n')) id=A.submatrix id ec := rfl
  have hg : (R.submatrix (fun i : J => (i:n')) id)ᴴ*R.submatrix (fun i : J => (i:n')) id=(Aᴴ*A).submatrix ec ec := by
    rw [he,Matrix.conjTranspose_submatrix,Matrix.submatrix_mul _ _ ec id ec Function.bijective_id]
  change IsUnit ((R.submatrix (fun i : J => (i:n')) id)ᴴ*R.submatrix (fun i : J => (i:n')) id) at hu
  rw [hg] at hu ⊢
  have huA := (Matrix.isUnit_submatrix_equiv ec ec).mp hu
  have hbA := weighted_basis_embedding Q b hb f (er.injective.comp Subtype.val_injective)
    (by simp only [Fintype.card_coe,hJ]; exact Fintype.card_congr ec) huA
  have hd : Matrix.diagonal (b ∘ ec)=(Matrix.diagonal b).submatrix ec ec := (Matrix.submatrix_diagonal_equiv _ ec).symm
  rw [hd,Matrix.inv_submatrix_equiv,Matrix.submatrix_mul_equiv]
  have ht : ((Matrix.diagonal b*(Aᴴ*A)⁻¹).submatrix ec ec).trace=(Matrix.diagonal b*(Aᴴ*A)⁻¹).trace := ec.sum_comp (fun i => (Matrix.diagonal b*(Aᴴ*A)⁻¹) i i)
  rw [ht]
  exact hbA

end SpectralComparison
