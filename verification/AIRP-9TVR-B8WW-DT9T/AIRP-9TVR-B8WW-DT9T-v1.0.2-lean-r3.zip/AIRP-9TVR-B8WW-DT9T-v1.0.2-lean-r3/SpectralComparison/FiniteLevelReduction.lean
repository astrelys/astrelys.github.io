import SpectralComparison.DyadicRounding

/-! The factor-eight finite-level reduction with the original dimension in its level count. -/
noncomputable section
open Finset
namespace SpectralComparison

/-- Equation (C.3), including positivity, the literal integer-floor formula and exact level count.
Together with paper_capping and paper_deletion this is the entire original C0015 statement. -/
theorem paper_dyadic_reduction {n k : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i) (hk : 1≤k) (hkn : k<n) :
    let F := symmetricQuotient (Finset.univ.val.map a) k
    let T := spectralMean a k
    let δ := F/(4*n)
    let c := fun i => min (a i) T
    let S := Finset.univ.filter (fun i => δ≤c i)
    let v := fun i : S => dyadicRound δ (c i)
    (∀ i,0<v i ∧ v i=δ*(2:ℝ)^(⌊Real.logb 2 (c i/δ)⌋ : ℤ)) ∧
      (Finset.univ.image v).card≤1+⌊Real.logb 2 (4*(n:ℝ)*((k:ℝ)+1))⌋₊ ∧
      spectralMean a k/worstError a k≤8*(spectralMean v k/worstError v k) := by
  let F := symmetricQuotient (Finset.univ.val.map a) k
  let T := spectralMean a k
  let δ := F/(4*n)
  let c := fun i => min (a i) T
  let S := Finset.univ.filter (fun i => δ≤c i)
  let v := fun i : S => dyadicRound δ (c i)
  change (∀ i,0<v i ∧ v i=δ*(2:ℝ)^(⌊Real.logb 2 (c i/δ)⌋ : ℤ)) ∧
    (Finset.univ.image v).card≤1+⌊Real.logb 2 (4*(n:ℝ)*((k:ℝ)+1))⌋₊ ∧
    spectralMean a k/worstError a k≤8*(spectralMean v k/worstError v k)
  have hF : 0<F := symmetricQuotient_pos _ (by intro z hz; obtain ⟨i,_,rfl⟩ := Multiset.mem_map.mp hz; exact ha i) (by simpa using hkn)
  have hn : (0:ℝ)<n := by exact_mod_cast (by omega : 0<n)
  have hd : 0<δ := by dsimp [δ]; positivity
  have hdel := paper_deletion a ha hk hkn
  change k<S.card ∧ S.card≤n ∧ (∀ i : S,δ≤c i ∧ c i≤T) ∧
    spectralMean a k/4≤spectralMean (fun i : S => c i) k ∧ worstError (fun i : S => c i) k≤worstError a k at hdel
  have hmu : ∀ i : S,δ≤c i := fun i => (hdel.2.2.1 i).1
  have hround := dyadic_comparison (fun i : S => c i) hd hmu hk (by simpa using hdel.1)
  have hv : ∀ i,0<v i := fun i => (dyadicRound_bounds hd (hmu i)).1
  have hratio : T/δ=4*(n:ℝ)*((k:ℝ)+1) := by
    dsimp [T,δ]
    rw [spectralMean_eq_quotient]
    change (((k:ℝ)+1)*F)/(F/(4*n))=_
    field_simp
  refine ⟨fun i => ⟨hv i,dyadicRound_original hd (hmu i)⟩,?_,?_⟩
  · apply dyadicRound_levels (fun i : S => c i) hd hmu
    intro i
    rw [← hratio]
    exact div_le_div_of_nonneg_right (hdel.2.2.1 i).2 hd.le
  · have hxv := worstError_pos v hv (by simpa using hdel.1)
    have hxa := worstError_pos a ha (by simpa using hkn)
    have hy : spectralMean a k≤8*spectralMean v k := by linarith [hround.1,hdel.2.2.2.1]
    have hx : worstError v k≤worstError a k := hround.2.trans hdel.2.2.2.2
    have hyv : 0<spectralMean v k := hxv.trans_le (worstError_le_spectralMean v hv (by simpa using hdel.1))
    calc
      spectralMean a k/worstError a k≤(8*spectralMean v k)/worstError a k := div_le_div_of_nonneg_right hy hxa.le
      _ ≤(8*spectralMean v k)/worstError v k := div_le_div_of_nonneg_left (by positivity) hxv hx
      _ =8*(spectralMean v k/worstError v k) := by ring

end SpectralComparison
