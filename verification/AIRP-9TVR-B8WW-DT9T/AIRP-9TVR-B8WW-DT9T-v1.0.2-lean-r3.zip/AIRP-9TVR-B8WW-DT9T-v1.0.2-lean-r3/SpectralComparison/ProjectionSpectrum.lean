import SpectralComparison.PrefixProjection

/-! Orthonormal coordinates adapted to the kernel and range of a projection. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Every eigenvalue of a real orthogonal projection is zero or one. -/
theorem projection_eigenvalues_zero_one {n : Type*} [Fintype n] [DecidableEq n]
    {P : Matrix n n ℝ} (hP : P.IsHermitian) (hPP : P*P=P) (i : n) :
    hP.eigenvalues i=0 ∨ hP.eigenvalues i=1 := by
  let U : Matrix n n ℝ := hP.eigenvectorUnitary
  have hU : Uᴴ*U=1 := by simpa only [Matrix.star_eq_conjTranspose] using Unitary.coe_star_mul_self hP.eigenvectorUnitary
  have he : Uᴴ*P*U=Matrix.diagonal hP.eigenvalues := by
    conv_lhs => rw [real_spectral_decomposition hP]
    change Uᴴ*(U*Matrix.diagonal hP.eigenvalues*Uᴴ)*U=_
    simp only [← Matrix.mul_assoc,hU,Matrix.one_mul]
    rw [Matrix.mul_assoc, hU,Matrix.mul_one]
  have hU' : U*Uᴴ=1 := mul_eq_one_comm.mp hU
  have hd : (Uᴴ*P*U)*(Uᴴ*P*U)=Uᴴ*P*U := by
    calc
      _ = Uᴴ*P*(U*Uᴴ)*P*U := by simp only [Matrix.mul_assoc]
      _ = Uᴴ*(P*P)*U := by rw [hU',Matrix.mul_one]; simp only [Matrix.mul_assoc]
      _ = _ := by rw [hPP]
  rw [he] at hd
  have hh := congrFun (congrFun hd i) i
  simp only [Matrix.diagonal_mul_diagonal,Matrix.diagonal_apply_eq] at hh
  have hf : hP.eigenvalues i*(hP.eigenvalues i-1)=0 := by nlinarith
  rcases mul_eq_zero.mp hf with h | h
  · exact Or.inl h
  · exact Or.inr (by linarith)

/-- A rank-p orthogonal projection admits one orthogonal basis with r kernel columns and p range columns. -/
theorem projection_split_basis {N r p : ℕ} (hdim : r+p=N)
    {P : Matrix (Fin N) (Fin N) ℝ} (hP : P.IsHermitian) (hPP : P*P=P) (hrank : P.rank=p) :
    ∃ U : Matrix (Fin N) (Fin r ⊕ Fin p) ℝ, Uᴴ*U=1 ∧ U*Uᴴ=1 ∧
      P=U*Matrix.diagonal (Sum.elim (fun _ : Fin r => (0:ℝ)) (fun _ : Fin p => 1))*Uᴴ := by
  classical
  let Z : Finset (Fin N) := Finset.univ.filter (fun i => hP.eigenvalues i=0)
  let O := Finset.univ \ Z
  have ho : O=Finset.univ.filter (fun i => hP.eigenvalues i≠0) := by ext i; simp [O,Z]
  have hO : O.card=p := by
    have h := hP.rank_eq_card_non_zero_eigs
    rw [hrank] at h
    simpa only [ho,Fintype.card_subtype] using h.symm
  have hZ : Z.card=r := by
    have h : O.card=N-Z.card := by simp [O,Finset.card_sdiff]
    have hz := Z.card_le_univ
    simp only [Fintype.card_fin] at hz
    omega
  let eZ : Fin r ≃ Z := Fintype.equivOfCardEq (by simpa using hZ.symm)
  let eO : Fin p ≃ O := Fintype.equivOfCardEq (by simpa using hO.symm)
  let e : (Fin r ⊕ Fin p) ≃ Fin N := (Equiv.sumCongr eZ eO).trans (partitionEquiv Z)
  have heig (i : Fin r ⊕ Fin p) : hP.eigenvalues (e i)=Sum.elim (fun _ : Fin r => (0:ℝ)) (fun _ : Fin p => 1) i := by
    cases i with
    | inl a => exact (Finset.mem_filter.mp (eZ a).property).2
    | inr a =>
      have hn : hP.eigenvalues (e (Sum.inr a))=0 → False := by
        intro hz
        exact (Finset.mem_sdiff.mp (eO a).property).2 (Finset.mem_filter.mpr ⟨Finset.mem_univ _,hz⟩)
      exact (projection_eigenvalues_zero_one hP hPP (e (Sum.inr a))).resolve_left hn
  let V : Matrix (Fin N) (Fin N) ℝ := hP.eigenvectorUnitary
  have hV : Vᴴ*V=1 := by simpa only [Matrix.star_eq_conjTranspose] using Unitary.coe_star_mul_self hP.eigenvectorUnitary
  have hV' : V*Vᴴ=1 := mul_eq_one_comm.mp hV
  let U := V.submatrix id e
  have hU : Uᴴ*U=1 := by
    change (V.submatrix id e)ᴴ*V.submatrix id e=1
    rw [Matrix.conjTranspose_submatrix,← Matrix.submatrix_mul _ _ e id e Function.bijective_id,hV]
    exact Matrix.submatrix_one e e.injective
  have hU' : U*Uᴴ=1 := by
    change V.submatrix id e*(V.submatrix id e)ᴴ=1
    rw [Matrix.conjTranspose_submatrix,Matrix.submatrix_mul_equiv,hV',Matrix.submatrix_id_id]
  have he : Vᴴ*P*V=Matrix.diagonal hP.eigenvalues := by
    conv_lhs => rw [real_spectral_decomposition hP]
    change Vᴴ*(V*Matrix.diagonal hP.eigenvalues*Vᴴ)*V=_
    simp only [← Matrix.mul_assoc,hV,Matrix.one_mul]
    rw [Matrix.mul_assoc,hV,Matrix.mul_one]
  have hd : Uᴴ*P*U=Matrix.diagonal (Sum.elim (fun _ : Fin r => (0:ℝ)) (fun _ : Fin p => 1)) := by
    have hh := congrArg (fun M : Matrix (Fin N) (Fin N) ℝ => M.submatrix e e) he
    rw [Matrix.submatrix_mul _ _ e id e Function.bijective_id,
      Matrix.submatrix_mul _ _ e id id Function.bijective_id,Matrix.submatrix_id_id] at hh
    change Uᴴ*P*U=(Matrix.diagonal hP.eigenvalues).submatrix e e at hh
    rw [hh,Matrix.submatrix_diagonal_equiv]
    congr 1
    funext i
    exact heig i
  refine ⟨U,hU,hU',?_⟩
  rw [← hd]
  calc
    P = (U*Uᴴ)*P*(U*Uᴴ) := by rw [hU',Matrix.one_mul,Matrix.mul_one]
    _ = _ := by simp only [Matrix.mul_assoc]

end SpectralComparison
