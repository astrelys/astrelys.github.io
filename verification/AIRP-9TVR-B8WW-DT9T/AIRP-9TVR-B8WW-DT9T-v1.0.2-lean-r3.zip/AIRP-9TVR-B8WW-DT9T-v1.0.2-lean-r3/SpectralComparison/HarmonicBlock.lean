import SpectralComparison.HarmonicExtension

noncomputable section
open Matrix Finset
namespace SpectralComparison

def harmonicMean {q : ℕ} (a : Fin q → ℝ) : ℝ := (q:ℝ)/(∑ i,(a i)⁻¹)

theorem harmonicMean_pos {q : ℕ} (a : Fin q → ℝ) (hq : 0<q) (ha : ∀ i,0<a i) : 0<harmonicMean a := by
  have hq0 : (0:ℝ)<q := by exact_mod_cast hq
  have hsum : 0<∑ i,(a i)⁻¹ := Finset.sum_pos (fun i _ => inv_pos.mpr (ha i)) ⟨⟨0,hq⟩,Finset.mem_univ _⟩
  exact div_pos hq0 hsum

theorem harmonicMean_ge_lower {q : ℕ} (a : Fin q → ℝ) (hq : 0<q) (ha : ∀ i,0<a i)
    {t : ℝ} (ht : 0<t) (hle : ∀ i,t≤a i) : t≤harmonicMean a := by
  have hsum : 0<∑ i,(a i)⁻¹ := Finset.sum_pos (fun i _ => inv_pos.mpr (ha i)) ⟨⟨0,hq⟩,Finset.mem_univ _⟩
  have hh : (∑ i,(a i)⁻¹)≤(q:ℝ)/t := by
    calc
      _ ≤∑ _i : Fin q,t⁻¹ := Finset.sum_le_sum (fun i _ => by simpa only [one_div] using one_div_le_one_div_of_le ht (hle i))
      _ = _ := by simp [div_eq_mul_inv]
  apply (le_div_iff₀ hsum).mpr
  have he := (le_div_iff₀ ht).mp hh
  nlinarith

/-- Harmonic covariance block with singleton tail: a lower bound for the original worst orientation. -/
theorem harmonic_block_lower {n q k : ℕ} (e : Fin q ⊕ Fin (n-q) ≃ Fin n)
    (a : Fin n → ℝ) (ha : ∀ i,0<a i) (hq : 0<q) (hkq : k≤q) (hkn : k<n)
    (hsep : ∀ i : Fin q,∀ j : Fin (n-q),a (e (Sum.inr j))≤a (e (Sum.inl i))) :
    (∑ j : Fin (n-q),a (e (Sum.inr j)))+(q-k:ℕ)*harmonicMean (fun i => a (e (Sum.inl i)))≤worstError a k := by
  let a0 := fun i : Fin q => a (e (Sum.inl i))
  let H := harmonicMean a0
  have hH : 0<H := harmonicMean_pos a0 hq (fun i => ha _)
  obtain ⟨V,hV,hd⟩ := exists_harmonic_orientation hq a0 (fun i => ha _)
  obtain ⟨W,hW,hblocks⟩ := extend_prefix_precision_blocks e a ha V hV
  let K := W.transpose*Matrix.diagonal a*W
  have hK : K.PosDef := orbit_posDef a ha W hW
  let R := fun i => (K⁻¹ i i)⁻¹
  have hhead (i : Fin q) : R (e (Sum.inl i))=H := by
    have hh := congrFun (congrFun hblocks (Sum.inl i)) (Sum.inl i)
    change K⁻¹ (e (Sum.inl i)) (e (Sum.inl i))=(V.transpose*Matrix.diagonal a0*V)⁻¹ i i at hh
    dsimp [R]
    rw [hh,hd]
    simp only [H,harmonicMean,inv_div]
  have htail (j : Fin (n-q)) : R (e (Sum.inr j))=a (e (Sum.inr j)) := by
    have hh := congrFun (congrFun hblocks (Sum.inr j)) (Sum.inr j)
    have hh' : K⁻¹ (e (Sum.inr j)) (e (Sum.inr j))=(a (e (Sum.inr j)))⁻¹ := by simpa only [Matrix.submatrix_apply,Matrix.fromBlocks_apply₂₂,Matrix.diagonal_apply_eq] using hh
    dsimp [R]
    rw [hh',inv_inv]
  have htailH (j : Fin (n-q)) : a (e (Sum.inr j))≤H :=
    harmonicMean_ge_lower a0 hq (fun i => ha _) (ha _) (fun i => hsep i j)
  have hR : ∀ i,R i≤H := by
    intro i
    obtain ⟨j,rfl⟩ := e.surjective i
    cases j with
    | inl j => exact (hhead j).le
    | inr j => rw [htail]; exact htailH j
  have htotal : (∑ i,R i)=(q:ℝ)*H+∑ j : Fin (n-q),a (e (Sum.inr j)) := by
    rw [← e.sum_comp R,Fintype.sum_sum_type]
    simp only [hhead,htail,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
  apply le_trans _ (orbit_bestError_le_worstError a ha W hW (by simpa using hkn))
  apply le_bestError _ (by simp; omega)
  intro I hI
  apply le_trans _ (residualTrace_precision_diagonal_lower hK I)
  have hi : (∑ i∈I,R i)≤(k:ℝ)*H := by
    calc
      _ ≤∑ _i∈I,H := Finset.sum_le_sum (fun i _ => hR i)
      _ =_ := by simp [hI]
  have ht := Finset.sum_sdiff (f:=R) (Finset.subset_univ I)
  have hc : ((q-k:ℕ):ℝ)=(q:ℝ)-(k:ℝ) := Nat.cast_sub hkq
  change _≤∑ i∈Finset.univ\I,R i
  rw [hc]
  linarith

/-- Canonical ordered-prefix version of the harmonic block bound. -/
theorem paper_harmonic_prefix {n k q : ℕ} (a : Fin n → ℝ) (ha : ∀ i,0<a i) (horder : Antitone a)
    (hk : 1≤k) (hkq : k<q) (hqn : q≤n) :
    let e := finSumFinEquiv.trans (finCongr (Nat.add_sub_of_le hqn))
    (∑ j : Fin (n-q),a (e (Sum.inr j)))+(q-k:ℕ)*harmonicMean (fun i => a (e (Sum.inl i)))≤worstError a k := by
  apply harmonic_block_lower _ a ha (by omega) hkq.le (by omega)
  intro i j
  apply horder
  change i.val≤q+j.val
  omega

end SpectralComparison
