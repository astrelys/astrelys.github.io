import SpectralComparison.DiffuseGroups

/-! Original manuscript tail indices for the reserve/group construction. -/
noncomputable section
namespace SpectralComparison

/-- The failure of (7.2) gives the original-tail reserve and nonempty groups of (7.3).
The choices depend only on the spectrum, before any selected coordinate set. -/
theorem paper_diffuse_reserve_and_groups {n k q : ℕ} (eig : Fin n → ℝ)
    (heig : ∀ i,0<eig i) (horder : Antitone eig) (hk : 1≤k) (hkn : k<n) (hq : 4*q≤k)
    (hsmall : (∑ j : Fin (min (n-k) (8*k)),eig ⟨k+j.val,by have := j.isLt; omega⟩)<
      (∑ i∈Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n),eig i)/2) :
    ∃ p : ℕ, ∃ hdim : n=9*k+p, 8*k<p ∧
      ∃ S : Finset (Fin p), S.card=k+q ∧
      (∑ i∈S,eig ⟨9*k+i.val,by have := i.isLt; omega⟩)<
        (∑ i : Fin p,eig ⟨9*k+i.val,by have := i.isLt; omega⟩)/4 ∧
      ∃ f : ↥(Sᶜ) → Fin (2*k), Function.Surjective f ∧
        ∀ j,(∑ i∈Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n),eig i)/(8*k)<
          ∑ a : ↥(Sᶜ),if f a=j then eig ⟨9*k+a.val.val,by have := a.val.isLt; omega⟩ else 0 := by
  classical
  let s := ∑ i∈Finset.univ \ Finset.Iio (⟨k,hkn⟩ : Fin n),eig i
  have hs : 0<s := by
    dsimp [s]
    rw [← indexed_tail_sum hkn eig]
    exact Finset.sum_pos (fun i _ => heig _) ⟨⟨0,by omega⟩,Finset.mem_univ _⟩
  have hm : 8*k<n-k := by
    by_contra! hm
    have heq : (∑ j : Fin (min (n-k) (8*k)),eig ⟨k+j.val,by have := j.isLt; omega⟩)=s := by
      let e : Fin (min (n-k) (8*k)) ≃ Fin (n-k) := finCongr (min_eq_left hm)
      have hh := Fintype.sum_equiv e
        (fun j : Fin (min (n-k) (8*k)) => eig ⟨k+j.val,by have := j.isLt; omega⟩)
        (fun j : Fin (n-k) => eig ⟨k+j.val,by omega⟩) (fun _ => rfl)
      exact hh.trans (indexed_tail_sum hkn eig)
    rw [heq] at hsmall
    change s<s/2 at hsmall
    linarith
  let p := n-k-8*k
  have hdim : n=9*k+p := by dsimp [p]; omega
  have htaildim : 8*k+p=n-k := by dsimp [p]; omega
  let d : Fin (8*k+p) → ℝ := fun i => eig ⟨k+i.val,by have := i.isLt; omega⟩
  have hd : ∀ i,0<d i := fun i => heig _
  have hdorder : Antitone d := fun i j hij => horder (by change k+i.val≤k+j.val; exact Nat.add_le_add_left hij k)
  have hsum : (∑ i,d i)=s := by
    let e : Fin (8*k+p) ≃ Fin (n-k) := finCongr htaildim
    have hh := Fintype.sum_equiv e d (fun j : Fin (n-k) => eig ⟨k+j.val,by omega⟩) (fun i => by rfl)
    exact hh.trans (indexed_tail_sum hkn eig)
  have hhead : (∑ i : Fin (8*k),d (i.castAdd p))<(∑ i,d i)/2 := by
    rw [hsum]
    have heq : (∑ j : Fin (min (n-k) (8*k)),eig ⟨k+j.val,by have := j.isLt; omega⟩)=
        ∑ i : Fin (8*k),d (i.castAdd p) := by
      let e : Fin (min (n-k) (8*k)) ≃ Fin (8*k) := finCongr (min_eq_right hm.le)
      exact Fintype.sum_equiv e _ _ (fun _ => rfl)
    rw [heq] at hsmall
    exact hsmall
  obtain ⟨hp,_,_⟩ := diffuse_tail_weight_bounds hk d hd hdorder hhead
  obtain ⟨S,hS,hreserve,f,hf,hmass⟩ := exists_diffuse_reserve_and_groups hk hq d hd hdorder hhead
  have hdval (i : Fin p) : d (i.natAdd (8*k))=eig ⟨9*k+i.val,by have := i.isLt; omega⟩ := by
    dsimp [d]
    congr 1
    apply Fin.ext
    change k+(8*k+i.val)=9*k+i.val
    omega
  refine ⟨p,hdim,hp,S,hS,?_,f,hf,?_⟩
  · simpa only [hdval] using hreserve
  · intro j
    simpa only [hsum,hdval] using hmass j

end SpectralComparison
