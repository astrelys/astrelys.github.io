import SpectralComparison.SpectralOrder

/-! Coordinate changes of the actual symmetric quotient, including capping increments. -/
noncomputable section
open Finset
namespace SpectralComparison

def symmetricQuotient (s : Multiset ℝ) (k : ℕ) : ℝ := s.esymm (k+1)/s.esymm k

theorem symmetricQuotient_pos (s : Multiset ℝ) (hs : ∀ z∈s,0<z) {k : ℕ} (hk : k<s.card) :
    0<symmetricQuotient s k := div_pos (esymm_pos s hs _ (by omega)) (esymm_pos s hs _ hk.le)

theorem quotient_cons_mono (s : Multiset ℝ) (hs : ∀ z∈s,0<z) {k : ℕ} (hk : 1≤k)
    (hcard : k≤s.card) {a b : ℝ} (ha : 0<a) (hab : a≤b) :
    symmetricQuotient (a ::ₘ s) k≤symmetricQuotient (b ::ₘ s) k := by
  obtain ⟨j,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : k≠0)
  have hA := esymm_pos s hs (j+1) hcard
  have hB := esymm_nonneg s (fun z hz => (hs z hz).le) (j+2)
  have hD := esymm_pos s hs j (by omega)
  have hLC := esymm_logconcave s hs j
  have hb : 0<b := ha.trans_le hab
  simp only [symmetricQuotient,Nat.succ_eq_add_one,esymm_cons]
  apply (div_le_div_iff₀ (by positivity) (by positivity)).mpr
  nlinarith [mul_nonneg (sub_nonneg.mpr hab) (sub_nonneg.mpr hLC)]

theorem quotient_cap_increment (s : Multiset ℝ) (hs : ∀ z∈s,0<z) {k : ℕ} (hk : 1≤k)
    (hcard : k≤s.card) {a T : ℝ} (ha : 0<a) (hT : 0<T) :
    (symmetricQuotient (T ::ₘ s) k)⁻¹≤(symmetricQuotient (a ::ₘ s) k)⁻¹+1/T := by
  obtain ⟨j,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : k≠0)
  have hA := esymm_pos s hs (j+1) hcard
  have hB := esymm_nonneg s (fun z hz => (hs z hz).le) (j+2)
  have hD := esymm_pos s hs j (by omega)
  have hLC := esymm_logconcave s hs j
  have h1 : (s.esymm (j+1)+T*s.esymm j)/(s.esymm (j+2)+T*s.esymm (j+1))≤
      s.esymm j/s.esymm (j+1)+1/T := by
    apply (div_le_iff₀ (by positivity)).mpr
    field_simp
    nlinarith [mul_nonneg hB (by positivity : 0≤T*s.esymm j+s.esymm (j+1))]
  have h2 : s.esymm j/s.esymm (j+1)≤
      (s.esymm (j+1)+a*s.esymm j)/(s.esymm (j+2)+a*s.esymm (j+1)) := by
    apply (div_le_div_iff₀ hA (by positivity)).mpr
    nlinarith
  simp only [symmetricQuotient,Nat.succ_eq_add_one,esymm_cons,inv_div]
  linarith

theorem quotient_delete_loss (s : Multiset ℝ) (hs : ∀ z∈s,0<z) {k : ℕ}
    (hk : k≤s.card) {z : ℝ} (hz : 0<z) :
    symmetricQuotient (z ::ₘ s) k≤z+symmetricQuotient s k := by
  have hA := esymm_pos s hs k hk
  have hB := esymm_nonneg s (fun w hw => (hs w hw).le) (k+1)
  cases k with
  | zero => simp [symmetricQuotient,esymm_one]
  | succ j =>
    have hD := esymm_nonneg s (fun w hw => (hs w hw).le) j
    simp only [symmetricQuotient,esymm_cons]
    apply (div_le_iff₀ (by positivity)).mpr
    have ht : (z+s.esymm (j+2)/s.esymm (j+1))*s.esymm (j+1)=z*s.esymm (j+1)+s.esymm (j+2) := by field_simp
    nlinarith [mul_nonneg (by positivity : 0≤z+s.esymm (j+2)/s.esymm (j+1)) (mul_nonneg hz.le hD)]

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

theorem spectrum_update_multiset (a : ι → ℝ) (i : ι) (z : ℝ) :
    Finset.univ.val.map (Function.update a i z)=z ::ₘ ((Finset.univ.erase i).val.map a) := by
  have he : (Finset.univ : Finset ι)=insert i (Finset.univ.erase i) := (Finset.insert_erase (Finset.mem_univ i)).symm
  conv_lhs => rw [he]
  rw [Finset.insert_val_of_notMem (show i ∉ Finset.univ.erase i by simp),Multiset.map_cons,Function.update_self]
  congr 1
  apply Multiset.map_congr rfl
  intro j hj
  exact Function.update_of_ne (Finset.mem_erase.mp (Finset.mem_val.mp hj)).1 _ _

theorem spectralQuotient_update_mono (a : ι → ℝ) (ha : ∀ i,0<a i) (i : ι) {z : ℝ}
    (haz : a i≤z) {k : ℕ} (hk : 1≤k) (hkn : k<Fintype.card ι) :
    symmetricQuotient (Finset.univ.val.map a) k≤
      symmetricQuotient (Finset.univ.val.map (Function.update a i z)) k := by
  have he : Function.update a i (a i)=a := Function.update_eq_self i a
  conv_lhs => rw [← he,spectrum_update_multiset]
  rw [spectrum_update_multiset]
  apply quotient_cons_mono _ _ hk _ (ha i) haz
  · intro w hw; obtain ⟨j,_,rfl⟩ := Multiset.mem_map.mp hw; exact ha j
  · simp only [Multiset.card_map,Finset.card_val,Finset.card_erase_of_mem (Finset.mem_univ i),Finset.card_univ]
    omega

end SpectralComparison
