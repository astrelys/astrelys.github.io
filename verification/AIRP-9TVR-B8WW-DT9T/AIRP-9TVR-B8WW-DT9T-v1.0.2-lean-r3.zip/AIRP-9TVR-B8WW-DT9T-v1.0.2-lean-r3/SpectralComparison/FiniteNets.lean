import SpectralComparison.GaussianTail
import Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar
import Mathlib.Order.Lattice.Nat

/-! Quantitative sphere nets and deterministic operator-norm estimates. -/
noncomputable section
open MeasureTheory Metric Module
open scoped Function ENNReal
namespace SpectralComparison

/-- The disjoint-ball volume bound for an eta-separated subset of the unit ball. -/
theorem separated_unit_ball_card_le {E : Type*} [NormedAddCommGroup E]
    [NormedSpace ℝ E] [FiniteDimensional ℝ E] (s : Finset E) {η : ℝ} (hη : 0 < η)
    (hs : ∀ x ∈ s, ‖x‖ ≤ 1)
    (hsep : ∀ x ∈ s, ∀ y ∈ s, x ≠ y → η < ‖x-y‖) :
    (s.card:ℝ) ≤ (1+2/η)^finrank ℝ E := by
  borelize E
  let μ : Measure E := Measure.addHaar
  let δ : ℝ := η/2
  let ρ : ℝ := 1+η/2
  have hδ : 0 < δ := by dsimp [δ]; positivity
  have hρ : 0 < ρ := by dsimp [ρ]; positivity
  have hd : Set.Pairwise (s : Set E) (Disjoint on fun x => ball x δ) := by
    intro x hx y hy hxy
    apply ball_disjoint_ball
    rw [dist_eq_norm]
    have := hsep x hx y hy hxy
    dsimp [δ]
    linarith
  have hsub : (⋃ x ∈ s, ball x δ) ⊆ ball (0 : E) ρ := by
    refine Set.iUnion₂_subset (fun x hx => ball_subset_ball' ?_)
    rw [dist_zero_right]
    dsimp [δ,ρ]
    linarith [hs x hx]
  have hi : (s.card:ℝ≥0∞)*ENNReal.ofReal (δ^finrank ℝ E)*μ (ball 0 1) ≤
      ENNReal.ofReal (ρ^finrank ℝ E)*μ (ball 0 1) := by
    calc
      _ = μ (⋃ x ∈ s, ball x δ) := by
        rw [measure_biUnion_finset hd (fun _ _ => measurableSet_ball)]
        simp only [μ.addHaar_ball_of_pos _ hδ, Finset.sum_const, nsmul_eq_mul, mul_assoc]
      _ ≤ μ (ball (0:E) ρ) := measure_mono hsub
      _ = _ := μ.addHaar_ball_of_pos _ hρ
  have hj := (ENNReal.mul_le_mul_iff_left (measure_ball_pos μ (0:E) zero_lt_one).ne'
    measure_ball_lt_top.ne).mp hi
  have hk : (s.card:ℝ)*δ^finrank ℝ E ≤ ρ^finrank ℝ E := by
    simpa only [ENNReal.toReal_mul, ENNReal.toReal_natCast, ENNReal.toReal_ofReal (pow_nonneg hδ.le _)]
      using ENNReal.toReal_le_of_le_ofReal (pow_nonneg hρ.le _) hj
  have hb := (le_div_iff₀ (pow_pos hδ (finrank ℝ E))).mpr hk
  rw [← div_pow] at hb
  have he : ρ/δ = 1+2/η := by dsimp [ρ,δ]; field_simp; ring
  rwa [he] at hb

/-- A finite eta-net of the unit sphere with the manuscript's exact volumetric cardinality. -/
theorem exists_sphere_net_card_le {E : Type*} [NormedAddCommGroup E]
    [NormedSpace ℝ E] [FiniteDimensional ℝ E] {η : ℝ} (hη : 0 < η) :
    ∃ s : Finset E, (∀ x ∈ s, ‖x‖ = 1) ∧
      (s.card:ℝ) ≤ (1+2/η)^finrank ℝ E ∧
      ∀ x : E, ‖x‖ = 1 → ∃ v ∈ s, ‖x-v‖ ≤ η := by
  classical
  let C : Set ℕ := {k | ∃ s : Finset E, s.card=k ∧ (∀ x ∈ s, ‖x‖=1) ∧
    (∀ x ∈ s, ∀ y ∈ s, x ≠ y → η < ‖x-y‖)}
  have hc : C.Nonempty := ⟨0, ∅, by simp⟩
  have hb : BddAbove C := by
    refine ⟨⌊(1+2/η)^finrank ℝ E⌋₊, ?_⟩
    rintro k ⟨s,rfl,hs,hsep⟩
    exact Nat.le_floor (separated_unit_ball_card_le s hη (fun x hx => (hs x hx).le) hsep)
  obtain ⟨s,hsn,hs,hsep⟩ := Nat.sSup_mem hc hb
  refine ⟨s,hs,separated_unit_ball_card_le s hη (fun x hx => (hs x hx).le) hsep,?_⟩
  intro x hx
  by_contra! hn
  have hxnot : x ∉ s := by
    intro hxmem
    have := hn x hxmem
    simp only [sub_self, norm_zero] at this
    linarith
  have hnew : (insert x s).card ∈ C := by
    refine ⟨insert x s,rfl,?_,?_⟩
    · intro y hy
      rcases Finset.mem_insert.mp hy with rfl | hy
      · exact hx
      · exact hs y hy
    · intro y hy z hz hyz
      rcases Finset.mem_insert.mp hy with hyx | hyS
      · subst y
        exact hn z (Finset.mem_of_mem_insert_of_ne hz hyz.symm)
      · rcases Finset.mem_insert.mp hz with hzx | hzS
        · subst z
          simpa only [norm_sub_rev] using hn y hyS
        · exact hsep y hyS z hzS hyz
  have hncard := le_csSup hb hnew
  rw [Finset.card_insert_of_notMem hxnot, hsn] at hncard
  omega

/-- Equation (2.5), in the equivalent form using any upper bound on the net values. -/
theorem opNorm_le_of_sphere_net {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] (Z : E →L[ℝ] F)
    (s : Finset E) {η M : ℝ} (hη0 : 0 ≤ η) (hη1 : η < 1) (hM : 0 ≤ M)
    (hnet : ∀ x : E, ‖x‖=1 → ∃ v ∈ s, ‖x-v‖ ≤ η)
    (hbound : ∀ v ∈ s, ‖Z v‖ ≤ M) : ‖Z‖ ≤ M/(1-η) := by
  have hunit (x : E) (hx : ‖x‖=1) : ‖Z x‖ ≤ M+‖Z‖*η := by
    obtain ⟨v,hv,hd⟩ := hnet x hx
    calc
      ‖Z x‖ ≤ ‖Z v‖+‖Z (x-v)‖ := by simpa only [map_sub, add_sub_cancel] using norm_add_le (Z v) (Z x-Z v)
      _ ≤ M+‖Z‖*η := add_le_add (hbound v hv) ((Z.le_opNorm _).trans (mul_le_mul_of_nonneg_left hd (norm_nonneg _)))
  have hn : ‖Z‖ ≤ M+‖Z‖*η := ContinuousLinearMap.opNorm_le_of_unit_norm (by positivity) hunit
  apply (le_div_iff₀ (by linarith : 0 < 1-η)).mpr
  nlinarith

/-- A lower bound on net values and an operator-norm upper bound control every unit vector. -/
theorem norm_lower_of_sphere_net {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] (Z : E →L[ℝ] F)
    (s : Finset E) {η M b : ℝ} (_hη : 0 ≤ η) (hM : ‖Z‖ ≤ M)
    (hnet : ∀ x : E, ‖x‖=1 → ∃ v ∈ s, ‖x-v‖ ≤ η)
    (hlower : ∀ v ∈ s, b ≤ ‖Z v‖) : ∀ x : E, ‖x‖=1 → b-η*M ≤ ‖Z x‖ := by
  intro x hx
  obtain ⟨v,hv,hd⟩ := hnet x hx
  have hdiff : ‖Z v-Z x‖ ≤ M*η := by
    rw [← map_sub]
    exact (Z.le_opNorm _).trans (mul_le_mul hM (by simpa only [norm_sub_rev] using hd)
      (norm_nonneg _) ((norm_nonneg _).trans hM))
  have htri : ‖Z v‖ ≤ ‖Z x‖+‖Z v-Z x‖ := by
    simpa only [add_sub_cancel] using norm_add_le (Z x) (Z v-Z x)
  nlinarith [hlower v hv]

end SpectralComparison
