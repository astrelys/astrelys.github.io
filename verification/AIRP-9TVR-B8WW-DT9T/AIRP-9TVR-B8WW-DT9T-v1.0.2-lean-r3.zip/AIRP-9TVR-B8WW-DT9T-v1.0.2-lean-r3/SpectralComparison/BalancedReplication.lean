import SpectralComparison.FrameMinimum
import SpectralComparison.FrameTransfer

/-! Quantitative replication of the balanced square-basis lower bound. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- Repeat a frame floor(N/n) times and pad with zeros to the exact target dimension. -/
theorem replicate_frame_to_dimension {N n d : ℕ} (hnpos : 0<n) (hnN : n≤N)
    (V : Matrix (Fin n) (Fin d) ℝ) (hV : Vᴴ*V=1) {L : ℝ}
    (hb : ∀ J : Finset (Fin n), J.card=d →
      IsUnit ((V*Vᴴ).submatrix (fun i : J => (i:Fin n)) (fun i : J => (i:Fin n))) →
      L≤((V*Vᴴ).submatrix (fun i : J => (i:Fin n)) (fun i : J => (i:Fin n)))⁻¹.trace) :
    ∃ T : Matrix (Fin N) (Fin d) ℝ, Tᴴ*T=1 ∧
      ∀ J : Finset (Fin N), J.card=d →
      IsUnit ((T*Tᴴ).submatrix (fun i : J => (i:Fin N)) (fun i : J => (i:Fin N))) →
      (N/n:ℕ)*L≤((T*Tᴴ).submatrix (fun i : J => (i:Fin N)) (fun i : J => (i:Fin N)))⁻¹.trace := by
  let h := N/n
  have hh : 0<h := Nat.div_pos hnN hnpos
  let W : Matrix (Fin n × Fin h) (Fin d) ℝ := Matrix.of (fun i j => V i.1 j/Real.sqrt h)
  have hW : Wᴴ*W=1 := replicated_frame_orthonormal V hV hh

  have hWb : ∀ J : Finset (Fin n × Fin h), J.card=d → IsUnit ((W*Wᴴ).submatrix
      (fun i : J => (i:Fin n × Fin h)) (fun i : J => (i:Fin n × Fin h))) →
      (h:ℝ)*L ≤ ((W*Wᴴ).submatrix (fun i : J => (i:Fin n × Fin h)) (fun i : J => (i:Fin n × Fin h)))⁻¹.trace := by
    intro J hJ hu
    have he : W*Wᴴ=(h:ℝ)⁻¹ • (V*Vᴴ).submatrix Prod.fst Prod.fst := replicated_frame_gram V hh
    rw [he] at hu ⊢
    exact replicated_principal_inverse_trace (V*Vᴴ) (posSemidef_self_mul_conjTranspose V) hh hb J hJ hu
  let U := Matrix.fromRows W (0 : Matrix (Fin (N%n)) (Fin d) ℝ)
  have hU : Uᴴ*U=1 := zero_padded_frame_orthonormal W hW
  have hUb := zero_padded_principal_inverse_trace (r := Fin (N%n)) W hWb
  have hdim : n*h+N%n=N := by dsimp [h]; exact Nat.div_add_mod N n
  let e : Fin N ≃ (Fin n × Fin h) ⊕ Fin (N%n) := Fintype.equivOfCardEq (by simpa using hdim.symm)
  obtain ⟨T,hT,hTb⟩ := reindex_frame_control U hU hUb e
  exact ⟨T,hT,hTb⟩

/-- For n<=N, the floor replication retains at least half the target rows. -/
theorem floor_replication_half {N n : ℕ} (hn : 0<n) (hN : n≤N) :
    N≤2*n*(N/n) := by
  have hh := Nat.div_pos hN hn
  have hrem := Nat.mod_lt N hn
  have he := Nat.div_add_mod N n
  have hm : n≤n*(N/n) := by nlinarith
  nlinarith

/-- Actual n by d frames with the first bound of the replication proposition, in all d>=1. -/
theorem exists_replicated_balanced_frame {n d : ℕ} (hd : 1≤d) (hn : 2*d≤n) :
    ∃ Q : Matrix (Fin n) (Fin d) ℝ, Qᴴ*Q=1 ∧
      ∀ J : Finset (Fin n), J.card=d →
      IsUnit ((Q*Qᴴ).submatrix (fun i : J => (i:Fin n)) (fun i : J => (i:Fin n))) →
      (n:ℝ)*Real.sqrt d/16000000000≤
        ((Q*Qᴴ).submatrix (fun i : J => (i:Fin n)) (fun i : J => (i:Fin n)))⁻¹.trace := by
  by_cases hd4 : 4≤d
  · obtain ⟨V,hV,hb⟩ := exists_balanced_parseval_frame hd4
    obtain ⟨Q,hQ,hQb⟩ := replicate_frame_to_dimension (by omega : 0<2*d) hn V hV
      (fun J hJ _ => (hb J hJ).2)
    refine ⟨Q,hQ,?_⟩
    intro J hJ hu
    apply le_trans _ (hQb J hJ hu)
    have hf := floor_replication_half (by omega : 0<2*d) hn
    have hfr : (n:ℝ)≤4*(d:ℝ)*(n/(2*d):ℕ) := by exact_mod_cast (by nlinarith : n≤4*d*(n/(2*d)))
    have hmul := mul_le_mul_of_nonneg_right hfr (Real.sqrt_nonneg (d:ℝ))
    nlinarith
  · obtain ⟨V,hV,hb⟩ := exists_coordinate_frame_control (N:=d) (p:=d) (t:=d) le_rfl
    obtain ⟨Q,hQ,hQb⟩ := replicate_frame_to_dimension (by omega : 0<d) (by omega : d≤n) V hV hb
    refine ⟨Q,hQ,?_⟩
    intro J hJ hu
    apply le_trans _ (hQb J hJ hu)
    have hf := floor_replication_half (by omega : 0<d) (by omega : d≤n)
    have hfr : (n:ℝ)≤2*(d:ℝ)*(n/d:ℕ) := by exact_mod_cast hf
    have hdr : (d:ℝ)≤3 := by exact_mod_cast (by omega : d≤3)
    have hs : Real.sqrt (d:ℝ)≤2 := by nlinarith [Real.sq_sqrt (Nat.cast_nonneg d),Real.sqrt_nonneg (d:ℝ)]
    have hm := mul_le_mul_of_nonneg_left hs (Nat.cast_nonneg (α:=ℝ) n)
    have hnon : (0:ℝ)≤(d:ℝ)*(n/d:ℕ) := by positivity
    nlinarith

/-- The first half of Proposition A.2, including realization and the supremum consequence. -/
theorem paper_replication_lower {n d : ℕ} (hd : 1≤d) (hn : 2*d≤n) :
    (∃ Q : Matrix (Fin n) (Fin d) ℝ, Qᴴ*Q=1 ∧
      (n:ℝ)*Real.sqrt d/16000000000≤frameBasisMinimum Q) ∧
    (((n:ℝ)*Real.sqrt d/16000000000:ℝ):EReal)≤frameBasisSupremum n d := by
  obtain ⟨Q,hQ,hb⟩ := exists_replicated_balanced_frame hd hn
  have hmin := le_frameBasisMinimum Q hQ hb
  exact ⟨⟨Q,hQ,hmin⟩,(EReal.coe_le_coe_iff.mpr hmin).trans (frameBasisMinimum_le_supremum Q hQ)⟩

end SpectralComparison
