import SpectralComparison.WeightedGroupCost

noncomputable section
open Matrix
namespace SpectralComparison

/-- Optional zero rows and repeated groups are handled for every actual nonsingular selection. -/
theorem actual_grouped_weighted_lower {n g p : Type*}
    [Fintype n] [Fintype g] [Fintype p] [DecidableEq n] [DecidableEq g] [DecidableEq p]
    (Q0 : Matrix g p ℝ) (Q : Matrix n p ℝ) (group : n → Option g) (u : n → ℝ)
    (hrow : ∀ i j,Q i j=match group i with | none => 0 | some a => u i*Q0 a j)
    (C D : Matrix n n ℝ) (hCD : (C-D).PosSemidef)
    (v : g → ℝ) (hcross : ∀ i l,group i≠group l → D i l=0)
    (hdiag : ∀ i j,group i=some j → D i i=v j*u i^2)
    {z L : ℝ} (hz : 0≤z) (hv : ∀ i,z≤v i)
    (hbase : ∀ H : Finset g,H.card=Fintype.card p →
      IsUnit (principal (Q0*Q0ᴴ) H) → L≤(principal (Q0*Q0ᴴ) H)⁻¹.trace)
    (I : Finset n) (hI : I.card=Fintype.card p) (hunit : IsUnit (principal (Q*Qᴴ) I)) :
    z*L≤((principal (Q*Qᴴ) I)⁻¹*principal C I).trace := by
  classical
  have hG : (principal (Q*Qᴴ) I).PosDef :=
    ((posSemidef_self_mul_conjTranspose Q).submatrix (fun i : I => (i:n))).posDef_iff_isUnit.mpr hunit
  have hnonrow (i : I) : ¬∀ j,Q i j=0 := by
    intro hzero
    have hh := hG.diag_pos (i:=i)
    change 0<(Q*Qᴴ) i i at hh
    simp only [Matrix.mul_apply,Matrix.conjTranspose_apply,star_trivial,hzero,zero_mul,Finset.sum_const_zero] at hh
    exact (lt_irrefl 0) hh
  have hsome (i : I) : ∃ a,group i=some a := by
    cases he : group i with
    | none =>
      exact (hnonrow i (fun j => by rw [hrow,he])).elim
    | some a => exact ⟨a,rfl⟩
  let f := fun i : I => Classical.choose (hsome i)
  have hf (i : I) : group i=some (f i) := Classical.choose_spec (hsome i)
  have hu (i : I) : u i≠0 := by
    intro hz
    exact hnonrow i (fun j => by
      rw [hrow,hf]
      change u i*Q0 (f i) j=0
      rw [hz,zero_mul])
  let U := Matrix.diagonal (fun i : I => u i)
  let A := Q0.submatrix f id
  have hsel : Q.submatrix (fun i : I => (i:n)) id=U*A := by
    ext i j
    rw [Matrix.diagonal_mul]
    exact (hrow i j).trans (by rw [hf]; rfl)
  have hUstar : Uᴴ=U := by
    ext i j
    by_cases hij : i=j
    · subst j; simp [U]
    · simp [U,Matrix.conjTranspose_apply,Matrix.diagonal_apply,hij,Ne.symm hij]
  have hgram : principal (Q*Qᴴ) I=U*(Q0*Q0ᴴ).submatrix f f*U := by
    have h0 : principal (Q*Qᴴ) I=
        Q.submatrix (fun i : I => (i:n)) id*(Q.submatrix (fun i : I => (i:n)) id)ᴴ := by
      ext i j; simp [principal,Matrix.mul_apply]
    rw [h0,hsel,Matrix.conjTranspose_mul,hUstar]
    have hA : A*Aᴴ=(Q0*Q0ᴴ).submatrix f f := by ext i j; simp [A,Matrix.mul_apply]
    rw [Matrix.mul_assoc U,← Matrix.mul_assoc A,hA,← Matrix.mul_assoc]
  have hgap : (principal C I-principal D I).PosSemidef := by
    exact hCD.submatrix (fun i : I => (i:n))
  have hc : ∀ i l : I,f i≠f l → principal D I i l=0 := by
    intro i l hil
    exact hcross i l (by rw [hf,hf]; exact fun h => hil (Option.some.inj h))
  have hd : ∀ i : I,principal D I i i=v (f i)*(u i)^2 := fun i => hdiag i (f i) (hf i)
  have hb : ∀ H : Finset g,H.card=Fintype.card I →
      IsUnit (principal (Q0*Q0ᴴ) H) → L≤(principal (Q0*Q0ᴴ) H)⁻¹.trace := by
    intro H hH hu
    exact hbase H (by simpa only [Fintype.card_coe,hI] using hH) hu
  rw [hgram] at hunit ⊢
  exact grouped_weighted_inverse_lower Q0 f (fun i : I => u i) hu
    (principal C I) (principal D I) hgap v hc hd hz hv hb hunit

end SpectralComparison
