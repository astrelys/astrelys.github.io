import SpectralComparison.QuotientAveraging

noncomputable section
namespace SpectralComparison

theorem spectralMean_equiv {ι κ : Type*} [Fintype ι] [Fintype κ]
    (a : κ → ℝ) (e : ι ≃ κ) (k : ℕ) : spectralMean (a ∘ e) k = spectralMean a k := by
  classical
  have hm : Finset.univ.val.map (a ∘ e) = Finset.univ.val.map a := by
    have he : (Finset.univ.map e.toEmbedding : Finset κ) = Finset.univ := by ext i; simp
    have hh := congrArg (fun s : Finset κ => s.val.map a) he
    simpa only [Finset.map_val, Multiset.map_map, Equiv.coe_toEmbedding] using hh
  simp only [spectralMean, hm]

/-- The additional square-root upper bound for any balanced spectrum with a bounded head. -/
theorem balanced_head_spectralMean_sqrt {k : ℕ} (hk : 1 ≤ k)
    (eig : Fin (k+k) → ℝ) (heig : ∀ i, 0 < eig i) {A : ℝ} (hA : 0 < A)
    (hhead : ∀ i : Fin k, eig (i.castAdd k) ≤ A) :
    spectralMean eig k ≤ ((k:ℝ)+1)*Real.sqrt (A*(∑ i : Fin k,eig (i.natAdd k))/k) := by
  let e : Fin k ⊕ Fin k ≃ Fin (k+k) := finSumFinEquiv
  let b := fun i : Fin k => eig (i.natAdd k)
  let s := ∑ i,b i
  let c := s/(k:ℝ)
  have hk0 : (0:ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hs : 0 < s := Finset.sum_pos (fun i _ => heig _) ⟨⟨0,by omega⟩,Finset.mem_univ _⟩
  have hc : 0 < c := div_pos hs hk0
  have hp : ∀ j,0 < Sum.elim (fun _ : Fin k => A) b j := by
    intro j
    cases j with | inl j => exact hA | inr j => exact heig _
  have hraise : spectralMean (eig ∘ e) k ≤ spectralMean (Sum.elim (fun _ : Fin k => A) b) k := by
    apply spectralMean_mono _ _ (fun i => heig _) hp _ hk (by simp; omega)
    intro j
    cases j with
    | inl j => exact hhead j
    | inr j => exact le_rfl
  have hav := quotient_tail_averaging (fun _ : Fin k => A) b (fun _ => hA)
    (fun _ => heig _) hc (by simp only [Fintype.card_fin]; dsimp [c,s]; field_simp)
    hk (by simp; omega)
  have hav' : spectralMean (Sum.elim (fun _ : Fin k => A) b) k ≤
      spectralMean (Sum.elim (fun _ : Fin k => A) (fun _ : Fin k => c)) k := by
    rw [spectralMean_eq_quotient,spectralMean_eq_quotient]
    exact mul_le_mul_of_nonneg_left hav (by positivity)
  let ε := c/A
  have hε : 0 < ε := div_pos hc hA
  have hscale := mul_le_mul_of_nonneg_left (balanced_spectralMean_sqrt hk hε) hA.le
  rw [← spectralMean_smul _ k hA] at hscale
  have he : (fun i => A*twoLevelSpectrum k k ε i) ∘ e =
      Sum.elim (fun _ : Fin k => A) (fun _ : Fin k => c) := by
    funext j
    cases j with
    | inl j => change A*twoLevelSpectrum k k ε (finSumFinEquiv (Sum.inl j)) = A; rw [twoLevelSpectrum_inl,mul_one]
    | inr j =>
      change A*twoLevelSpectrum k k ε (finSumFinEquiv (Sum.inr j)) = c
      rw [twoLevelSpectrum_inr]
      dsimp [ε]
      field_simp
  have heq : spectralMean (Sum.elim (fun _ : Fin k => A) (fun _ : Fin k => c)) k =
      spectralMean (fun i => A*twoLevelSpectrum k k ε i) k := by
    rw [← he]
    exact spectralMean_equiv _ e k
  have hsqrt : A*Real.sqrt ε = Real.sqrt (A*s/k) := by
    have he : A*s/k = A^2*ε := by dsimp [ε,c]; field_simp
    rw [he,Real.sqrt_mul (sq_nonneg A),Real.sqrt_sq hA.le]
  have hall := ((spectralMean_equiv eig e k).symm.le.trans hraise).trans hav'
  rw [heq] at hall
  apply (hall.trans hscale).trans_eq
  rw [← mul_assoc, mul_comm A ((k:ℝ)+1), mul_assoc, hsqrt]

end SpectralComparison
