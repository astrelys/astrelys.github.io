import SpectralComparison.BalancedRatio
import Mathlib.Analysis.Calculus.Deriv.Slope
import Mathlib.Analysis.Calculus.Deriv.Mul

/-! Exact first-order symmetric-quotient asymptotics of the repeated two-level list. -/
noncomputable section
open Filter Topology
namespace SpectralComparison

/-- The Fin-indexed spectrum is the literal repeated multiset from the paper. -/
theorem twoLevelSpectrum_multiset (k m : ℕ) (ε : ℝ) :
    Finset.univ.val.map (twoLevelSpectrum k m ε)=Multiset.replicate k 1+Multiset.replicate m ε := by
  have he : (Finset.univ.map (finSumFinEquiv.toEmbedding) : Finset (Fin (k+m)))=Finset.univ := by ext i; simp
  have hh := congrArg (fun s : Finset (Fin (k+m)) => s.val.map (twoLevelSpectrum k m ε)) he
  rw [Finset.map_val,Multiset.map_map] at hh
  rw [← hh]
  change (Multiset.map Sum.inl (Finset.univ : Finset (Fin k)).val+
    Multiset.map Sum.inr (Finset.univ : Finset (Fin m)).val).map
      (twoLevelSpectrum k m ε ∘ finSumFinEquiv)=_
  simp only [Multiset.map_add,Multiset.map_map,Function.comp_def,twoLevelSpectrum_inl,twoLevelSpectrum_inr,
    Multiset.map_const',Finset.card_val,Finset.card_univ,Fintype.card_fin]

/-- Appending zero entries leaves every elementary coefficient unchanged. -/
theorem esymm_add_zeros (s : Multiset ℝ) (m t : ℕ) :
    (s+Multiset.replicate m 0).esymm t=s.esymm t := by
  induction m generalizing t with
  | zero => simp
  | succ m ih =>
    cases t with
    | zero => simp
    | succ t => simp [Multiset.replicate_succ,Multiset.add_cons,esymm_cons,ih]

/-- First derivative at zero after appending m identical variable entries. -/
theorem esymm_repeated_tail_hasDerivAt (s : Multiset ℝ) (m t : ℕ) :
    HasDerivAt (fun ε : ℝ => (s+Multiset.replicate m ε).esymm t)
      ((m:ℝ)*(if t=0 then 0 else s.esymm (t-1))) 0 := by
  induction m generalizing t with
  | zero => simpa using hasDerivAt_const (0:ℝ) (s.esymm t)
  | succ m ih =>
    cases t with
    | zero => simpa using hasDerivAt_const (0:ℝ) (1:ℝ)
    | succ t =>
      have hfun : (fun ε : ℝ => (s+Multiset.replicate (m+1) ε).esymm (t+1))=
          fun ε => (s+Multiset.replicate m ε).esymm (t+1)+ε*(s+Multiset.replicate m ε).esymm t := by
        funext ε
        simp [Multiset.replicate_succ,Multiset.add_cons,esymm_cons]
      rw [hfun]
      convert (ih (t+1)).add ((hasDerivAt_id (0:ℝ)).mul (ih t)) using 1
      · rfl
      · simp only [esymm_add_zeros,Nat.add_one_ne_zero,ite_false,Nat.add_sub_cancel,Nat.cast_add,Nat.cast_one,one_mul,id_eq,zero_mul,add_zero]
        ring

/-- The full-degree elementary coefficient of k ones is exactly one. -/
theorem esymm_replicate_one_top (k : ℕ) : (Multiset.replicate k (1:ℝ)).esymm k=1 := by
  have hp := Multiset.powersetCard_self (Multiset.replicate k (1:ℝ))
  simp only [Multiset.card_replicate] at hp
  rw [Multiset.esymm,hp]
  simp

/-- For fixed k,m, e_k tends to one as epsilon tends to zero. -/
theorem two_level_denominator_tendsto (k m : ℕ) :
    Tendsto (fun ε : ℝ => (Finset.univ.val.map (twoLevelSpectrum k m ε)).esymm k) (𝓝 0) (𝓝 1) := by
  have h := (esymm_repeated_tail_hasDerivAt (Multiset.replicate k 1) m k).continuousAt.tendsto
  have he : (Multiset.replicate k (1:ℝ)).esymm k=1 := esymm_replicate_one_top k
  simpa only [twoLevelSpectrum_multiset,esymm_add_zeros,he] using h

/-- For fixed k,m, e_(k+1)/epsilon tends to m from the right. -/
theorem two_level_numerator_tendsto (k m : ℕ) :
    Tendsto (fun ε : ℝ => (Finset.univ.val.map (twoLevelSpectrum k m ε)).esymm (k+1)/ε)
      (𝓝[>] 0) (𝓝 (m:ℝ)) := by
  have h := (esymm_repeated_tail_hasDerivAt (Multiset.replicate k 1) m (k+1)).tendsto_slope_zero_right
  have he : (Multiset.replicate k (1:ℝ)).esymm k=1 := esymm_replicate_one_top k
  have hz : (Multiset.replicate k (1:ℝ)).esymm (k+1)=0 := Multiset.esymm_of_card_lt (by simp)
  simp only [twoLevelSpectrum_multiset]
  simpa only [zero_add,esymm_add_zeros,hz,sub_zero,he,Nat.add_sub_cancel,Nat.add_one_ne_zero,ite_false,mul_one,smul_eq_mul,div_eq_mul_inv,mul_comm] using h

/-- The exact y_k/epsilon limit appearing in the two-level asymptotic comparison. -/
theorem two_level_spectralMean_div_tendsto (k m : ℕ) :
    Tendsto (fun ε : ℝ => spectralMean (twoLevelSpectrum k m ε) k/ε)
      (𝓝[>] 0) (𝓝 (((k:ℝ)+1)*(m:ℝ))) := by
  have hnum := (two_level_numerator_tendsto k m).const_mul ((k:ℝ)+1)
  have hden := (two_level_denominator_tendsto k m).mono_left (nhdsWithin_le_nhds (s:=Set.Ioi (0:ℝ)))
  have h := hnum.div hden (by norm_num : (1:ℝ)≠0)
  convert h using 1
  · funext ε
    dsimp only [spectralMean,Pi.div_apply]
    ring
  · simp

end SpectralComparison
