import SpectralComparison.GaussianUniform
import SpectralComparison.InverseOrder
import Mathlib.Analysis.Matrix.Order

/-! Convert the Gaussian singular estimates into Loewner bounds for whitening. -/
noncomputable section
open Matrix
namespace SpectralComparison

/-- A uniform unit-vector lower bound extends homogeneously to all vectors. -/
theorem norm_lower_of_unit_lower {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] (T : E →ₗ[ℝ] F) {a : ℝ}
    (h : ∀ x, ‖x‖=1 → a ≤ ‖T x‖) (x : E) : a*‖x‖ ≤ ‖T x‖ := by
  by_cases hx : x=0
  · simp [hx]
  have hn : 0 < ‖x‖ := norm_pos_iff.mpr hx
  have hu : ‖(‖x‖⁻¹:ℝ) • x‖=1 := by rw [norm_smul, Real.norm_eq_abs, abs_of_pos (inv_pos.mpr hn), inv_mul_cancel₀ hn.ne']
  have hh := h ((‖x‖⁻¹:ℝ) • x) hu
  rw [map_smul, norm_smul, Real.norm_eq_abs, abs_of_pos (inv_pos.mpr hn)] at hh
  have := mul_le_mul_of_nonneg_right hh hn.le
  simpa only [mul_assoc, inv_mul_cancel₀ hn.ne', mul_one, mul_left_comm ‖x‖⁻¹] using this

/-- The quadratic form of a column Gram matrix is the Euclidean image norm squared. -/
theorem column_gram_quadratic {n p : Type*} [Fintype n] [Fintype p] [DecidableEq p]
    (G : Matrix n p ℝ) (x : p → ℝ) :
    star x ⬝ᵥ ((Gᴴ*G)*ᵥ x) = ‖G.toEuclideanLin (WithLp.toLp 2 x)‖^2 := by
  rw [← Matrix.mulVec_mulVec, dotProduct_mulVec, vecMul_conjTranspose, star_star,
    EuclideanSpace.real_norm_sq_eq]
  simp [dotProduct, Matrix.toEuclideanLin, Matrix.toLpLin_apply, pow_two]

/-- A singular-value lower bound gives the exact positive-semidefinite Gram gap. -/
theorem gram_lower_of_unit_norm {n p : Type*} [Fintype n] [Fintype p] [DecidableEq p]
    (G : Matrix n p ℝ) {a : ℝ} (ha : 0 ≤ a)
    (h : ∀ x : EuclideanSpace ℝ p, ‖x‖=1 → a ≤ ‖G.toEuclideanLin x‖) :
    (Gᴴ*G-a^2 • (1 : Matrix p p ℝ)).PosSemidef := by
  apply Matrix.PosSemidef.of_dotProduct_mulVec_nonneg
  · exact (isHermitian_conjTranspose_mul_self G).sub (Matrix.isHermitian_one.smul (by rfl))
  intro x
  have hh := norm_lower_of_unit_lower G.toEuclideanLin h (WithLp.toLp 2 x)
  have hsq := mul_self_le_mul_self (mul_nonneg ha (norm_nonneg _)) hh
  have he : star x ⬝ᵥ ((a^2 • (1 : Matrix p p ℝ))*ᵥ x) = a^2*‖WithLp.toLp 2 x‖^2 := by
    rw [EuclideanSpace.real_norm_sq_eq]
    simp only [Matrix.smul_mulVec, Matrix.one_mulVec, dotProduct, Pi.smul_apply, smul_eq_mul,
      Pi.star_apply, star_trivial, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    ring
  rw [Matrix.sub_mulVec, dotProduct_sub, column_gram_quadratic, he]
  nlinarith

/-- A positive uniform lower bound implies positive definiteness of the column Gram. -/
theorem gram_posDef_of_unit_norm {n p : Type*} [Fintype n] [Fintype p] [DecidableEq p]
    (G : Matrix n p ℝ) {a : ℝ} (ha : 0 < a)
    (h : ∀ x : EuclideanSpace ℝ p, ‖x‖=1 → a ≤ ‖G.toEuclideanLin x‖) :
    (Gᴴ*G).PosDef := by
  have hgap := gram_lower_of_unit_norm G ha.le h
  have hbase : (a^2 • (1 : Matrix p p ℝ)).PosDef := Matrix.PosDef.one.smul (sq_pos_of_pos ha)
  convert hbase.add_posSemidef hgap using 1; abel

/-- Equation (4.4) as a matrix inequality, with the paper's numerical D. -/
theorem gaussian_good_gram_lower {N p : ℕ} (G : Matrix (Fin N) (Fin p) ℝ)
    (h : ∀ x : EuclideanSpace ℝ (Fin p), ‖x‖=1 → Real.sqrt p/1000000000000 ≤ ‖G.toEuclideanLin x‖) :
    (Gᴴ*G-((p:ℝ)/(1000000000000:ℝ)^2) • (1 : Matrix (Fin p) (Fin p) ℝ)).PosSemidef := by
  have he : (Real.sqrt p/1000000000000)^2 = (p:ℝ)/(1000000000000:ℝ)^2 := by
    rw [div_pow, Real.sq_sqrt (Nat.cast_nonneg p)]
  simpa only [he] using gram_lower_of_unit_norm G (by positivity) h

end SpectralComparison
