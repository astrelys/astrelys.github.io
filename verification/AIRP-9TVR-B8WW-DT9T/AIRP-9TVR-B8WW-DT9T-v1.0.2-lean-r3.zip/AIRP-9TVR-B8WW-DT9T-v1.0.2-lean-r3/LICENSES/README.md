# Licensing notes

The proof source has no separately declared general redistribution license;
this package does not introduce one.

`mathlib-LICENSE` is the license notice for the external mathlib dependency.
Dependency source trees and binaries are not bundled. Lean and the other
dependencies retain the licenses in their pinned upstream repositories;
`dependency-lock.json` identifies those repositories and revisions.
