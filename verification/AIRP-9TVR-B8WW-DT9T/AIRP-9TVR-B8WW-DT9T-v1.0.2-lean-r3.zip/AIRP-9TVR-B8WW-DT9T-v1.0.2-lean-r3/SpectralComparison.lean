import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.NumberTheory.Harmonic.Defs
import Mathlib.Tactic

/-! Scalar foundations for the spectral comparison proof.
The complete original statements and their actual matrix constructions are in
SpectralComparison.MainTheorem and the appendix modules imported by SpectralComparison.All.
This foundation module alone is not the complete verification entry point.
-/

namespace SpectralComparison
open Finset

/-- Monotonicity of the regularization map used in equation (2.3). -/
theorem regularization_mono {a b x y : ℝ} (ha : 0 < a) (hb : 0 < b)
    (hx : 0 ≤ x) (hxy : x ≤ y) :
    x / (b + a * x) ≤ y / (b + a * y) := by
  have hy : 0 ≤ y := le_trans hx hxy
  apply (div_le_div_iff₀ (by positivity) (by positivity)).2
  nlinarith

/-- The finite-sum scalar step of (2.3), for every finite index set. -/
theorem sum_regularization_lower {ι : Type*} (s : Finset ι) (z : ι → ℝ)
    {a b L : ℝ} (ha : 0 < a) (hb : 0 < b)
    (hz : ∀ i ∈ s, 0 ≤ z i) (hL : 0 ≤ L) (hLZ : L ≤ ∑ i ∈ s, z i) :
    L / (b + a * L) ≤ ∑ i ∈ s, z i / (b + a * z i) := by
  let Z := ∑ i ∈ s, z i
  have hZ : 0 ≤ Z := Finset.sum_nonneg hz
  calc
    L / (b + a * L) ≤ Z / (b + a * Z) :=
      regularization_mono ha hb hL hLZ
    _ = ∑ i ∈ s, z i / (b + a * Z) := by rw [← Finset.sum_div]
    _ ≤ ∑ i ∈ s, z i / (b + a * z i) := by
      apply Finset.sum_le_sum
      intro i hi
      have hiz : 0 ≤ z i := hz i hi
      have hiZ : z i ≤ Z := Finset.single_le_sum hz hi
      apply div_le_div_of_nonneg_left (hz i hi) (by positivity)
      nlinarith

/-- The singular-eigenvalue comparison in equation (2.3). -/
theorem singular_regularization_bound {a b L : ℝ}
    (ha : 0 < a) (hb : 0 < b) (hL : 0 ≤ L) :
    L / (b + a * L) < 1 / a := by
  apply (div_lt_div_iff₀ (by positivity) ha).2
  nlinarith

/-- Completing the square for the scalar ridge problem in equation (7.12). -/
theorem ridge_identity {a v σ z : ℝ} (ha : 0 < a) (hv : 0 < v) :
    a * (1 - z * σ)^2 + v * z^2 =
      a * v / (v + a * σ^2) +
        (v + a * σ^2) * (z - a * σ / (v + a * σ^2))^2 := by
  have hd : v + a * σ^2 ≠ 0 := ne_of_gt (by positivity)
  field_simp
  ring

/-- Equation (7.12)'s scalar minimum, including σ = 0. -/
theorem ridge_minimum {a v σ : ℝ} (ha : 0 < a) (hv : 0 < v) :
    (∀ z : ℝ, a * v / (v + a * σ^2) ≤ a * (1 - z * σ)^2 + v * z^2) ∧
    a * (1 - (a * σ / (v + a * σ^2)) * σ)^2 +
      v * (a * σ / (v + a * σ^2))^2 = a * v / (v + a * σ^2) := by
  constructor
  · intro z
    rw [ridge_identity ha hv]
    exact le_add_of_nonneg_right (by positivity)
  · rw [ridge_identity ha hv]
    simp

/-- Parallel-sum monotonicity, used in (6.3), (7.1), and Section 9. -/
theorem parallel_sum_mono {a b z w : ℝ}
    (ha : 0 < a) (hb : a ≤ b) (hz : 0 < z) (hw : z ≤ w) :
    a * z / (a + z) ≤ b * w / (b + w) := by
  have hb0 : 0 < b := lt_of_lt_of_le ha hb
  have hw0 : 0 < w := lt_of_lt_of_le hz hw
  have h1 : a*z/(a+z) ≤ b*z/(b+z) := by
    apply (div_le_div_iff₀ (by positivity) (by positivity)).2
    nlinarith [mul_nonneg (sub_nonneg.mpr hb) (sq_nonneg z)]
  have h2 : b*z/(b+z) ≤ b*w/(b+w) := by
    apply (div_le_div_iff₀ (by positivity) (by positivity)).2
    nlinarith [mul_nonneg (sub_nonneg.mpr hw) (sq_nonneg b)]
  exact h1.trans h2

/-- The main theorem's regularized scalar lower bound, with all inputs explicit. -/
theorem regularized_threshold_lower {r F B a z x : ℝ}
    (hr : 0 < r) (hF : 0 < F) (hB : 0 < B)
    (ha : r * F ≤ a) (hz : r * F / B ≤ z)
    (hx : a * z / (a + z) ≤ x) :
    r * F / (B + 1) ≤ x := by
  have h := parallel_sum_mono (mul_pos hr hF) ha (div_pos (mul_pos hr hF) hB) hz
  have he : (r*F) * (r*F/B) / (r*F + r*F/B) = r*F/(B+1) := by
    field_simp
  rw [he] at h
  exact h.trans hx

/-- Algebra behind U_q/F ≥ sqrt(k)/(3 C_1 H_m), with r = sqrt(k).
    The finite-dimensional spectral construction supplying x is NOT assumed here. -/
theorem prefix_scale_lower {r F s C H q : ℝ}
    (hr : 0 < r) (_hF : 0 < F) (hs : F ≤ s) (hC : 0 < C) (hH : 0 < H)
    (hq : 0 ≤ q) (hqF : q * F ≤ 2 * r * s) :
    r * F / (3*C*H) ≤ r^2 * s / (C * (q+r) * H) := by
  apply (div_le_div_iff₀ (by positivity) (by positivity)).2
  have hsum : (q+r)*F ≤ 3*r*s := by nlinarith
  have hprod := mul_le_mul_of_nonneg_left hsum (show 0 ≤ r*C*H by positivity)
  nlinarith

/-- Real harmonic sum with exactly the paper's convention H_n = sum_{j=1}^n 1/j. -/
noncomputable def H (n : ℕ) : ℝ := ∑ i ∈ Finset.range n, ((i : ℝ) + 1)⁻¹

theorem H_nonneg (n : ℕ) : 0 ≤ H n := by
  apply Finset.sum_nonneg
  intro i _
  positivity

theorem H_mono {n m : ℕ} (hnm : n ≤ m) : H n ≤ H m := by
  apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono hnm)
  intro i _ _
  positivity

theorem H_one : H 1 = 1 := by norm_num [H]

theorem one_le_H {n : ℕ} (hn : 1 ≤ n) : 1 ≤ H n := by
  simpa only [H_one] using (H_mono hn)

/-- Dyadic-block harmonic bound. It avoids an analytic integral dependency. -/
theorem H_double_le {n : ℕ} (hn : 1 ≤ n) : H (2*n) ≤ H n + 1 := by
  have hnR : 0 < (n : ℝ) := by exact_mod_cast (show 0 < n by omega)
  rw [show 2*n = n+n by omega, H, Finset.sum_range_add]
  change H n + (∑ i ∈ Finset.range n, (((n+i : ℕ) : ℝ)+1)⁻¹) ≤ H n + 1
  suffices (∑ i ∈ Finset.range n, (((n+i : ℕ) : ℝ)+1)⁻¹) ≤ 1 by linarith
  calc
    (∑ i ∈ Finset.range n, (((n+i : ℕ) : ℝ)+1)⁻¹) ≤
      ∑ _i ∈ Finset.range n, (n : ℝ)⁻¹ := by
        apply Finset.sum_le_sum
        intro i _
        apply inv_anti₀ hnR
        exact_mod_cast (show n ≤ n+i+1 by omega)
    _ = 1 := by simp [ne_of_gt hnR]

/-- The exact H_{8k} ≤ 4 H_k estimate used in Theorem 9.1. -/
theorem H_eight_mul_le {k : ℕ} (hk : 1 ≤ k) : H (8*k) ≤ 4 * H k := by
  have h1 := H_double_le hk
  have h2 := H_double_le (show 1 ≤ 2*k by omega)
  have h3 := H_double_le (show 1 ≤ 4*k by omega)
  have h4 := one_le_H hk
  norm_num [← Nat.mul_assoc] at h2 h3
  linarith

/-- Final choice between the short- and long-tail inequalities.
    This is explicitly CONDITIONAL on (9.2), (9.3), and the elementary bound;
    it does not prove those spectral inputs. -/
theorem main_comparison_assembly {k m : ℕ} {R : ℝ}
    (hk : 1 ≤ k)
    (hbase : R ≤ (k:ℝ)+1)
    (hshort : R ≤ ((k:ℝ)+1) * ((96*10^27*H m+1) / Real.sqrt k))
    (hlong : R ≤ ((k:ℝ)+1) * ((192*10^27*H (8*k)+1) / Real.sqrt k)) :
    R ≤ ((k:ℝ)+1) * min 1 ((768*10^27*H (min k m)+1) / Real.sqrt k) := by
  have hkR : 0 < (k:ℝ) := by exact_mod_cast (show 0 < k by omega)
  have hsqrt : 0 < Real.sqrt k := Real.sqrt_pos.2 hkR
  have hfactor : R ≤ ((k:ℝ)+1) * ((768*10^27*H (min k m)+1) / Real.sqrt k) := by
    by_cases hmk : m ≤ k
    · rw [Nat.min_eq_right hmk]
      apply hshort.trans
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      apply div_le_div_of_nonneg_right _ hsqrt.le
      have hH := H_nonneg m
      nlinarith
    · have hkm : k ≤ m := by omega
      rw [Nat.min_eq_left hkm]
      apply hlong.trans
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      apply div_le_div_of_nonneg_right _ hsqrt.le
      have hH := H_eight_mul_le hk
      nlinarith
  by_cases h : (1:ℝ) ≤ (768*10^27*H (min k m)+1) / Real.sqrt k
  · rw [min_eq_left h, mul_one]
    exact hbase
  · rw [min_eq_right (le_of_not_ge h)]
    exact hfactor

/-- Threshold-count step of Section 9. The premise is precisely the needed
    finite sum bound; no assumption that the target conclusion itself holds. -/
theorem threshold_count_bound {ι : Type*} (s : Finset ι) (eig : ι → ℝ)
    {F r U : ℝ} (hF : 0 < F) (hr : 0 ≤ r)
    (heig : ∀ i ∈ s, 0 ≤ eig i)
    (hbound : ∑ i ∈ s, F / (eig i + F) ≤ U) :
    ((s.filter (fun i => eig i < r*F)).card : ℝ) ≤ (1+r)*U := by
  classical
  let t := s.filter (fun i => eig i < r*F)
  have hdr : 0 < 1+r := by positivity
  have hterm : ∀ i ∈ t, 1/(1+r) ≤ F/(eig i+F) := by
    intro i hi
    obtain ⟨his, hlt⟩ := Finset.mem_filter.mp hi
    have hli := heig i his
    apply (div_le_div_iff₀ hdr (by positivity)).2
    nlinarith
  have hpartial : ∑ i ∈ t, F/(eig i+F) ≤ ∑ i ∈ s, F/(eig i+F) := by
    apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _)
    intro i hi _
    have hli := heig i hi
    positivity
  have hcount : (t.card:ℝ)/(1+r) ≤ U := by
    calc
      (t.card:ℝ)/(1+r) = ∑ _i ∈ t, 1/(1+r) := by simp [div_eq_mul_inv]
      _ ≤ ∑ i ∈ t, F/(eig i+F) := Finset.sum_le_sum hterm
      _ ≤ U := hpartial.trans hbound
  have h := (div_le_iff₀ hdr).mp hcount
  simpa [t, mul_comm] using h

/-- q is within the half-rank range in the first small-tail case. -/
theorem threshold_half_range {r F s q : ℝ}
    (hr : 1 ≤ r) (hF : 0 < F) (hq : q ≤ (1+r)*(s/F))
    (hsmall : s < r*F/4) : q < r^2/2 := by
  have hquot : s/F < r/4 := (div_lt_iff₀ hF).2 (by nlinarith)
  have hmul := mul_lt_mul_of_pos_left hquot (show 0 < 1+r by linarith)
  have hr2 : r ≤ r^2 := by nlinarith [sq_nonneg (r-1)]
  nlinarith

/-- q is within the quarter-rank range in the diffuse small-tail case. -/
theorem threshold_quarter_range {r F s q : ℝ}
    (hr : 1 ≤ r) (hF : 0 < F) (hq : q ≤ (1+r)*(s/F))
    (hsmall : s < r*F/8) : q < r^2/4 := by
  have hquot : s/F < r/8 := (div_lt_iff₀ hF).2 (by nlinarith)
  have hmul := mul_lt_mul_of_pos_left hquot (show 0 < 1+r by linarith)
  have hr2 : r ≤ r^2 := by nlinarith [sq_nonneg (r-1)]
  nlinarith

/-- Diagonal case of (9.4), generalized to any positive case constant d. -/
theorem diagonal_ratio_bound {d r F s x y k : ℝ}
    (hd : 0 < d) (hr : 0 < r) (_hF : 0 < F) (hx : 0 < x)
    (hk : 0 ≤ k+1) (hy : y = (k+1)*F)
    (hsx : s ≤ x) (hlarge : r*F/d ≤ s) :
    y/x ≤ d*(k+1)/r := by
  rw [hy]
  apply (div_le_div_iff₀ hx hr).2
  have h1 : r*F ≤ s*d := (div_le_iff₀ hd).mp hlarge
  have h2 := mul_le_mul_of_nonneg_right hsx hd.le
  have h3 := mul_le_mul_of_nonneg_left (h1.trans h2) hk
  nlinarith

/-- Ratio conversion after the regularized lower bound. -/
theorem ratio_from_lower {r F B x y k : ℝ}
    (hr : 0 < r) (_hF : 0 < F) (hB : 0 < B)
    (hx : 0 < x) (hk : 0 ≤ k+1) (hy : y=(k+1)*F)
    (hlower : r*F/(B+1) ≤ x) :
    y/x ≤ (k+1)*(B+1)/r := by
  rw [hy]
  apply (div_le_div_iff₀ hx hr).2
  have h1 := (div_le_iff₀ (show 0 < B+1 by positivity)).mp hlower
  have h2 := mul_le_mul_of_nonneg_left h1 hk
  nlinarith


/-- General threshold range; specializes to the half/quarter-rank cases. -/
theorem threshold_range {r F s q d : ℝ}
    (hr : 1 ≤ r) (hF : 0 < F) (hd : 0 < d)
    (hq : q ≤ (1+r)*(s/F)) (hsmall : s < r*F/d) :
    q < 2*r^2/d := by
  have hquot : s/F < r/d := (div_lt_div_iff₀ hF hd).2 (by
    have h := (lt_div_iff₀ hd).mp hsmall
    nlinarith)
  have hmul := mul_lt_mul_of_pos_left hquot (show 0 < 1+r by linarith)
  apply lt_of_lt_of_le (hq.trans_lt hmul)
  rw [← mul_div_assoc]
  apply div_le_div_of_nonneg_right _ hd.le
  nlinarith [sq_nonneg (r-1)]

/-- Complete scalar case split in Section 9, CONDITIONAL on the spectral
    construction. C is C_1 for the short tail and 2*C_1 for the long tail.
    The missing construction and threshold eigenvalue bound are explicitly
    represented by hconstruct, not admitted or declared as an axiom. -/
theorem tail_comparison_from_inputs {r F s q C H d x y k : ℝ}
    (hr : 1 ≤ r) (hF : 0 < F) (hs : F ≤ s)
    (hq0 : 0 ≤ q) (hq : q ≤ (1+r)*(s/F))
    (hC : 0 < C) (hH : 0 < H) (hd : 0 < d)
    (hdB : d ≤ 3*C*H+1) (hx : 0 < x) (hsx : s ≤ x)
    (hk : 0 ≤ k+1) (hy : y=(k+1)*F)
    (hconstruct : q < 2*r^2/d → ∃ a : ℝ, r*F ≤ a ∧
      a * (r^2*s/(C*(q+r)*H)) / (a + r^2*s/(C*(q+r)*H)) ≤ x) :
    y/x ≤ (k+1)*(3*C*H+1)/r := by
  have hr0 : 0 < r := by linarith
  by_cases hlarge : r*F/d ≤ s
  · apply (diagonal_ratio_bound hd hr0 hF hx hk hy hsx hlarge).trans
    apply div_le_div_of_nonneg_right _ hr0.le
    nlinarith [mul_le_mul_of_nonneg_left hdB hk]
  · have hsmall : s < r*F/d := lt_of_not_ge hlarge
    obtain ⟨a, ha, hax⟩ := hconstruct (threshold_range hr hF hd hq hsmall)
    have hqF : q*F ≤ 2*r*s := by
      have h1 : q*F ≤ (1+r)*s := by
        have h2 := mul_le_mul_of_nonneg_right hq hF.le
        field_simp at h2
        nlinarith
      have hs0 : 0 ≤ s := (hF.trans_le hs).le
      nlinarith [mul_nonneg (show 0 ≤ r-1 by linarith) hs0]
    have hu := prefix_scale_lower hr0 hF hs hC hH hq0 hqF
    have hlower := regularized_threshold_lower hr0 hF
      (show 0 < 3*C*H by positivity) ha hu hax
    exact ratio_from_lower hr0 hF (by positivity) hx hk hy hlower

/-- Interior four-coefficient consequence of adjacent log-concavity in (8.2).
    Boundary/support cases of the elementary-symmetric induction are separate. -/
theorem logconcavity_cross {a b c d : ℝ}
    (hb : 0 < b) (hc : 0 < c) (hd : 0 ≤ d)
    (hleft : a*c ≤ b^2) (hright : b*d ≤ c^2) : a*d ≤ b*c := by
  have ha : a ≤ b^2/c := (le_div_iff₀ hc).2 hleft
  have hdd : d ≤ c^2/b := (le_div_iff₀ hb).2 (by nlinarith)
  calc
    a*d ≤ (b^2/c)*(c^2/b) := mul_le_mul ha hdd hd (by positivity)
    _ = b*c := by field_simp

/-- Exact coefficient expansion used in the proof of (8.2). -/
theorem coefficient_append_identity (a b c d z : ℝ) :
    (c+z*b)^2 - (b+z*a)*(d+z*c) =
      (c^2-b*d) + z*(c*b-a*d) + z^2*(b^2-a*c) := by ring

/-- Local preservation step, conditional on the required cross inequality. -/
theorem coefficient_append_nonnegative {a b c d z : ℝ}
    (hz : 0 ≤ z) (h1 : b*d ≤ c^2) (h2 : a*d ≤ c*b)
    (h3 : a*c ≤ b^2) : (b+z*a)*(d+z*c) ≤ (c+z*b)^2 := by
  have he := coefficient_append_identity a b c d z
  have hp : 0 ≤ (c^2-b*d) + z*(c*b-a*d) + z^2*(b^2-a*c) := by positivity
  linarith

/-- Inclusion-probability algebra in Lemma 8.1. Actual elementary-symmetric
    coefficients and their log-concavity still need to instantiate the inputs. -/
theorem inclusion_probability_le {A B D z : ℝ}
    (hA : 0 < A) (hB : 0 ≤ B) (hD : 0 < D) (hz : 0 < z)
    (hlc : B*D ≤ A^2) :
    z*D/(A+z*D) ≤ z/(z+(B+z*A)/(A+z*D)) := by
  have hden : 0 < A+z*D := by positivity
  have hF : 0 < (B+z*A)/(A+z*D) := by positivity
  apply (div_le_div_iff₀ hden (by positivity)).2
  have hcore : D*(z+(B+z*A)/(A+z*D)) ≤ A+z*D := by
    apply (mul_le_mul_iff_left₀ hden).mp
    field_simp
    nlinarith
  nlinarith [mul_le_mul_of_nonneg_left hcore hz.le]

end SpectralComparison
