"""Exact automatic differentiation of the released coefficient table."""
import sys
sys.dont_write_bytecode=True
from verify import *
class Dual:
 def __init__(self,value,derivative=(0,0,0,0)):
  self.v=Q(value);self.d=tuple(map(Q,derivative))
 def __add__(self,other):
  if not isinstance(other,Dual):other=Dual(other)
  return Dual(self.v+other.v,[a+b for a,b in zip(self.d,other.d)])
 __radd__=__add__
 def __neg__(self):return Dual(-self.v,[-a for a in self.d])
 def __sub__(self,other):return self+-other
 def __mul__(self,other):
  if not isinstance(other,Dual):other=Dual(other)
  return Dual(self.v*other.v,[a*other.v+self.v*b for a,b in zip(self.d,other.d)])
 __rmul__=__mul__
 def __pow__(self,n):
  return Dual(self.v**n,[n*self.v**(n-1)*a for a in self.d]) if n else Dual(1)
D=json.loads((ROOT/'deformed-family.json').read_text())
variables={name:Dual(v,[int(i==j) for j in range(4)]) for i,(name,v) in enumerate(zip(['r','s','a','x'],[2,3,2,1]))};variables['h']=Dual(5)
def expression(n):
 if isinstance(n,ast.Constant):return Dual(n.value)
 if isinstance(n,ast.Name):return variables[n.id]
 if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):return -expression(n.operand)
 if isinstance(n,ast.BinOp):
  a,b=expression(n.left),expression(n.right)
  if isinstance(n.op,ast.Add):return a+b
  if isinstance(n.op,ast.Sub):return a-b
  if isinstance(n.op,ast.Mult):return a*b
 raise ValueError(ast.dump(n))
atoms=[expression(ast.parse(s,mode='eval').body) for s in D['atoms']]
values=[]
for c,es in D['dictionary']:
 v=Dual(c)
 for i,n in es:v=v*atoms[i]**n
 values.append(v)
def matrix(t,m):return [[values[D['terms'][t][m][str(4*i+j)]] if str(4*i+j) in D['terms'][t][m] else Dual(0) for j in range(4)] for i in range(4)]
def transpose(a):return list(zip(*a))
def mm(a,b):return [[sum((a[i][k]*b[k][j] for k in range(4)),Dual(0)) for j in range(4)] for i in range(4)]
def center(t,kind):
 l,r,p=[matrix(t,m) for m in range(3)]
 return mm(mm(p,transpose(r)),transpose(l)) if kind=='N' else mm(mm(transpose(r),transpose(l)),p)
def pair(s,t,kind):
 a,b=center(s,kind),center(t,kind)
 return sum((a[i][j]*b[j][i] for i in range(4) for j in range(4)),Dual(0))
j1,j2,j3,j4=pair(0,12,'N'),pair(0,14,'N'),pair(0,7,'O'),pair(8,7,'O')
g=j2*j3-j1*(Dual(1)-j4)
M=[list(p.d) for p in [j1,j2,j4,g]]
A=[row[:] for row in M];det=Q(1)
for j in range(4):
 i=next(i for i in range(j,4) if A[i][j])
 if i!=j:A[j],A[i]=A[i],A[j];det=-det
 pivot=A[j][j];det*=pivot
 for i in range(j+1,4):
  c=A[i][j]/pivot
  A[i]=[v-c*w for v,w in zip(A[i],A[j])]
assert det==Q(1,384)
report={'variables':['r','s','a','x'],'fixed_h':'5','point':['2','3','2','1'],'invariants':['J1','J2','J4','G'],'jacobian':[[str(v) for v in row] for row in M],'determinant':str(det),'exact_dual_arithmetic':True}
(ROOT/'derivative-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
