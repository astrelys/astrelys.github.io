#!/usr/bin/env python3
"""Exact certificates for two 48-product schemes and a trace obstruction.
Python 3 standard library only. No downloads, floating point, or sample tests.
"""
from pathlib import Path
from fractions import Fraction as Q
from collections import defaultdict
from functools import lru_cache
from itertools import product
import ast, json, hashlib, time
ROOT = Path(__file__).resolve().parent

def add(a,b):
    r=dict(a)
    for e,c in b.items(): r[e]=r.get(e,Q(0))+c
    return {e:c for e,c in r.items() if c}
def scale(a,c): return {e:v*c for e,v in a.items() if v*c}
def mul(a,b):
    r=defaultdict(Q)
    for e,c in a.items():
        for f,d in b.items(): r[tuple(x+y for x,y in zip(e,f))]+=c*d
    return {e:c for e,c in r.items() if c}
def power(a,n,one):
    assert n>=0
    r=one
    while n:
        if n%2: r=mul(r,a)
        a=mul(a,a);n//=2
    return r

def parse(s,names,special=None):
    z=(0,)*len(names);one={z:Q(1)}
    def read(a):
        if isinstance(a,ast.Name):
            if special and a.id in special:return {z:Q(special[a.id])}
            return {tuple(int(i==names.index(a.id)) for i in range(len(names))):Q(1)}
        if isinstance(a,ast.Constant) and type(a.value)==int:return {z:Q(a.value)} if a.value else {}
        if isinstance(a,ast.UnaryOp) and isinstance(a.op,ast.USub):return scale(read(a.operand),-1)
        if isinstance(a,ast.BinOp):
            l,r=read(a.left),read(a.right)
            if isinstance(a.op,ast.Add):return add(l,r)
            if isinstance(a.op,ast.Sub):return add(l,scale(r,-1))
            if isinstance(a.op,ast.Mult):return mul(l,r)
        raise ValueError(ast.dump(a))
    return read(ast.parse(s,mode='eval').body)

class Scheme:
    def __init__(self,filename,special=None):
        self.data=json.loads((ROOT/filename).read_text())
        d=self.data; self.n=len(d['atoms']); self.z=(0,)*self.n
        names=d['parameters'];self.pone={(0,)*len(names):Q(1)}
        self.atoms=[parse(s,names,special) for s in d['atoms']]
        self.values=[]
        for c,es in d['dictionary']:
            e=[0]*self.n
            for i,v in es:e[i]+=v
            self.values.append({tuple(e):Q(c)})
        negative=sorted({i for p in self.values for e in p for i,v in enumerate(e) if v<0})
        assert negative==d['denominator_atoms']
        self.terms=[[{int(k):self.values[i] for k,i in m.items()} for m in t] for t in d['terms']]
        self.expand=lru_cache(None)(self._expand)
    def mono(self,c=1,es=()):
        e=[0]*self.n
        for i,v in es:e[i]+=v
        return {tuple(e):Q(c)}
    def _expand(self,e):
        p=self.pone
        for a,n in zip(self.atoms,e):
            if n:p=mul(p,power(a,n,self.pone))
        return p
    def iszero(self,p):
        if not p:return True
        minimum=tuple(min(0,min(e[i] for e in p)) for i in range(self.n))
        r={}
        for e,c in p.items():r=add(r,scale(self.expand(tuple(x-y for x,y in zip(e,minimum))),c))
        return not r
    def identities(self):
        out=defaultdict(dict)
        for t in self.terms:
            for (i,a),(j,b),(k,c) in product(*(m.items() for m in t)):
                out[i,j,k]=add(out[i,j,k],mul(mul(a,b),c))
        expanded=0
        for i,j,k in product(range(16),repeat=3):
            target=int(i//4==k//4 and i%4==j//4 and j%4==k%4)
            residual=add(out[i,j,k],self.mono(-target))
            residual={e:c for e,c in residual.items() if c}
            expanded+=bool(residual)
            assert self.iszero(residual),(i,j,k)
        return {'terms':len(self.terms),'identities':4096,'nontrivial_residuals_expanded':expanded,'mismatches':0}
    def traces(self):
        def matrix(t,m):
            return [[self.terms[t][m].get(4*i+j,{}) for j in range(4)] for i in range(4)]
        def tr(a):return list(zip(*a))
        def mm(a,b):
            return [[psum(mul(a[i][k],b[k][j]) for k in range(4)) for j in range(4)] for i in range(4)]
        def center(t,kind):
            l,r,p=[matrix(t,m) for m in range(3)]
            return mm(mm(p,tr(r)),tr(l)) if kind=='N' else mm(mm(tr(r),tr(l)),p)
        def pair(a,b,kind):
            A,B=center(a,kind),center(b,kind)
            return psum(mul(A[i][j],B[j][i]) for i in range(4) for j in range(4))
        return [pair(0,12,'N'),pair(0,14,'N'),pair(0,7,'O'),pair(8,7,'O')]
    def at(self,point):
        nums=[]
        for atom in self.data['atoms']:
            p=parse(atom,self.data['parameters']);nums.append(sum(c*product_num(Q(point[v])**e for v,e in zip(self.data['parameters'],ex)) for ex,c in p.items()))
        vals=[next(iter(p.values()))*product_num(n**e for n,e in zip(nums,next(iter(p)))) for p in self.values]
        return [[{int(k):vals[i] for k,i in m.items() if vals[i]} for m in t] for t in self.data['terms']]

def psum(items):
    s={}
    for p in items:s=add(s,p)
    return s
def product_num(items):
    x=Q(1)
    for y in items:x*=y
    return x

def main():
    start=time.monotonic();report={}
    old=Scheme('reference-family.json');new=Scheme('deformed-family.json')
    for name,scheme in [('reference_family',old),('deformed_family',new)]:
        report[name]=scheme.identities();print(name,report[name],flush=True)
    expected=[old.mono('-1/2',[(3,1),(0,-1)]),old.mono('-1/4',[(3,1)]),old.mono(1,[(9,1),(8,-1),(0,-1)]),old.mono('1/2',[(0,1),(8,-1)])]
    for actual,want in zip(old.traces(),expected):assert old.iszero(add(actual,scale(want,-1)))
    curve=Scheme('deformed-family.json',{'r':2,'s':3,'a':2,'h':5})
    expected=[curve.mono('-1/3'),curve.mono('-1/2'),curve.mono('1/6',[(0,-1)]),curve.mono('3/4')]
    actual=curve.traces()
    for a,w in zip(actual,expected):assert curve.iszero(add(a,scale(w,-1)))
    G=add(mul(actual[1],actual[2]),mul(actual[0],add(actual[3],curve.mono(-1))))
    assert curve.iszero(add(G,add(curve.mono('-1/12'),curve.mono('1/12',[(0,-1)]))))
    assert old.at({'r':2,'s':3,'a':2,'k':1,'h':5})==new.at({'r':2,'s':3,'a':2,'h':5,'x':1})
    # The added output coefficient is P_8[9] = 2*s*(x-1)/((s-2)*x).
    extra=new.terms[8][2][9]
    want=add(new.mono(2,[(1,1),(4,-1)]),new.mono(-2,[(1,1),(4,-1),(0,-1)]))
    assert new.iszero(add(extra,scale(want,-1)))
    report['trace_formulas']={'reference':['(4-3a)/(2s)','(4-3a)/4','(2r-s)/(r*s)','s/(2r)'],'curve':['-1/3','-1/2','1/(6*x)','3/4'],'curve_obstruction':'(x-1)/(12*x)','exact_checks_pass':True}
    report['common_basepoint']=True;report['new_output_coefficient']=True
    report['data_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.glob('*family.json'))}
    print(json.dumps(report,indent=2))
    (ROOT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__':main()
