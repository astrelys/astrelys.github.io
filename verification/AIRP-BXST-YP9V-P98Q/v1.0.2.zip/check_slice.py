"""Exact verification that F1(r,s,a,h,1)=F0(r,s,a,1,h)."""
import sys
sys.dont_write_bytecode=True
from verify import *
def rat_table(filename,special):
 d=json.loads((ROOT/filename).read_text());names=['r','s','a','h'];z=(0,)*4;one={z:Q(1)}
 atoms=[parse(a,names,special) for a in d['atoms']];vals=[]
 for c,es in d['dictionary']:
  num={z:Q(c)};den=one
  for i,e in es:
   if e>=0:num=mul(num,power(atoms[i],e,one))
   else:den=mul(den,power(atoms[i],-e,one))
  vals.append((num,den))
 return [[{int(k):vals[v] for k,v in m.items()} for m in t] for t in d['terms']]
a=rat_table('reference-family.json',{'k':1});b=rat_table('deformed-family.json',{'x':1});one={(0,)*4:Q(1)};zero=({},one)
for t in range(48):
 for m in range(3):
  for i in range(16):
   an,ad=a[t][m].get(i,zero);bn,bd=b[t][m].get(i,zero)
   assert not add(mul(an,bd),scale(mul(bn,ad),-1)),(t,m,i)
print('2304 exact rational factor identities: F1(r,s,a,h,1) = F0(r,s,a,1,h) PASS')

(ROOT/'slice-verification.json').write_text(json.dumps({'factor_coordinate_identities':2304,'mismatches':0,'statement':'F1(r,s,a,h,1)=F0(r,s,a,1,h)'},indent=2)+'\n')
