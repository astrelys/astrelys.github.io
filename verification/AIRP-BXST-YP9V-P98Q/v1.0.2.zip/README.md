# Verification data and checks

Astrée Iriart — AIRP-BXST-YP9V-P98Q, manuscript v1.0.2.
Verification attachment v1.0.2, matched to that manuscript version.
This distribution-only revision updates the version label and instructions;
all coefficient data and checker bytes are unchanged.

This attachment supplies the complete coefficient tables used to define the
two families in Section 2.2 of the research note, together with standalone
exact checks. It contains no manuscript source, research transcript or logs.

## Run locally

Requirements: Python 3, standard library only. No network or installation.
Extract into a new directory and run without Python's optimization flags:

```
python3 -B verify.py
python3 -B check_slice.py
python3 -B check_derivatives.py
```

All three commands must exit successfully. They write three verification
reports in the extracted directory; those generated files are not inputs.
`SHA256SUMS` identifies the distributed files, not mathematical correctness.

## Data format

`reference-family.json` and `deformed-family.json` are complete schemes with
parameter orders `(r,s,a,k,h)` and `(r,s,a,h,x)`, respectively.

- `atoms` contains polynomial strings with rational coefficients.
- A `dictionary` entry `[c, [[i,e], ...]]` represents `c` times the product
  of `atoms[i]**e`.
- `terms[t][m]` maps vector coordinates to dictionary indexes. The factor
  index `m=0,1,2` denotes the left input, right input and output factor.
- Each factor has 16 entries; coordinate `4*i+j` denotes matrix entry
  `(i,j)`. All indexes are zero based, and omitted entries are zero.
- `denominator_atoms` lists atoms required to be nonzero. The open domains
  are stated in the manuscript. There are 48 triples in each scheme.

For the four-parameter family set `h=5` in the deformed table. For the
distinguished curve further set `(r,s,a)=(2,3,2)`; its domain excludes
`x=0` and `x=2/3`.

## Coverage and limits

The checks expand all 4,096 tensor coordinates for each family, check the
trace identities and common point, establish the 2,304 factor-coordinate
identities on the common slice, and compute the invariant Jacobian
determinant `1/384` by exact dual-number arithmetic on the coefficient data.
There is no random sampling or floating-point tolerance.

These checks support the stated computational identities, not every prose
argument, novelty, minimal rank or external peer review. There is no
47-product construction in this attachment.

## Attribution

The baseline 48-product construction is due to prior work, including
AlphaEvolve (arXiv:2506.13131) and the rational data of Dumas, Pernet and
Sedoglavic (arXiv:2506.13242; the public `jgdumas/plinopt` repository,
commit `9a4b70810c674f839e4f79726e169b098b040dd6`). Li, Wang and Hu
(arXiv:2607.15069v2) already give an inequivalent rational one-parameter
family. The contribution claimed here is the explicit four-dimensional
invariant image, not the first 48-product algorithm or the first
inequivalent family. See the manuscript for the precise equivalence scope.
