# Verification checks

Astrée Iriart · AIRP-8VGW-AC4S-LZ4X · manuscript v3.1.1
Stability of coefficient minima for real stable polynomials

Requires Python 3.10 or later; standard library only. Run each script with
Python from any directory. No network access, data download or file output
is required. Each script exits unsuccessfully if an asserted identity fails.

- `radius_certificate.py`: polynomial identities and positive Bernstein
  certificates printed for the two sharp cubic radii.
- `complex_hessian_check.py`: complex Hermitian Hessian normalization.
- `cubic_matrix_check.py`: cubic Hermitian and block identities.
- `root_variance_check.py`: root variance, covariance and coefficient identities.
- `multicoefficient_check.py`: variable replication and weighted local descent.
- `quantitative_check.py`: logarithmic-scaling identities and finite checks
  of dimension-dependent constants.
- `escape_check.py`: symmetric-marginal path and escape-barrier identities.

The scripts are unchanged from this manuscript edition. Polynomial
certificates are checked symbolically with rational arithmetic. Other test
families are finite consistency checks; the general theorems and their
assumptions are proved in the manuscript. These are Python checks, not Lean
formalizations. This archive contains no manuscript source files.

Revision 3.1.1 adds the missing positive-prefactor hypothesis in Lemma 3.5
and spells out the positivity used in its application. The main results,
constants and these seven exact-checking programs are unchanged.
