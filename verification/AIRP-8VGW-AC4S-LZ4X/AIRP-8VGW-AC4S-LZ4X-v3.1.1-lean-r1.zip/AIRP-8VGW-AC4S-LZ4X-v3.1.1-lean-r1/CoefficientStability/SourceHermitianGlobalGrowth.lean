import CoefficientStability.SourceDeterminantHomogeneity
import CoefficientStability.ExactLocalStability

noncomputable section
open scoped BigOperators ComplexOrder Matrix.Norms.Elementwise
namespace CoefficientStability
variable {n : ℕ}

theorem source_realDeterminant_objective (A : Fin n → ComplexSquare n) :
    (realDeterminantPolynomial A).coeff (squarefreeExponent n)=hermitianMixedObjective A := by
  simp only [realDeterminantPolynomial,MvPolynomial.coeff_addMonoidAlgebraMap]
  rfl

theorem source_hermitian_deficit_distance (t : Fin n → ℝ) (A : Fin n → ComplexSquare n)
    (hA : A ∈ hermitianFeasibleTuples t) (hn : 0 < n) :
    referenceDeficit (realDeterminantPolynomial A) t n=complexTupleSq (A-complexReferenceTuple t)/2 := by
  have hHerm : ∀ i,(A i).IsHermitian := fun i => (hA.1 i).1
  have htr : (fun i => (Matrix.trace (A i)).re)=t := by
    funext i
    rw [(hA.1 i).2.2,Complex.ofReal_re]
  have h := paper_determinantal_deficit_frobenius A hHerm hA.2 hn
  rw [htr] at h
  have hc (i : Fin n) : centeredDeterminantMatrix A i=(A-complexReferenceTuple t) i := by
    rw [centeredDeterminantMatrix_source A hHerm i,congrFun htr i]
    exact congrArg (fun B => A i-B) (complexReferenceTuple_source t i).symm
  simpa only [hc,complexTupleSq] using h

theorem source_hermitian_global_growth_exists (hn : 2 ≤ n) :
    ∃ ε κ : ℝ,0 < ε ∧ 0 < κ ∧ ∀ t : Fin n → ℝ,(∑ i,t i)=n →
      (∀ i,0 < t i) → (∑ i,|t i-1|) < ε → ∀ A ∈ hermitianFeasibleTuples t,
        κ*complexTupleSq (A-complexReferenceTuple t) ≤ hermitianMixedObjective A-sourceVn n*(∏ i,t i) := by
  obtain ⟨ε,κ,hε,hκ,hgrowth⟩ := source_stable_global_growth_exists hn
  refine ⟨ε,κ/2,hε,div_pos hκ (by norm_num),?_⟩
  intro t ht htpos hnear A hA
  obtain ⟨hp,hs,hnorm,hcoeff,hgrad⟩ := source_realDeterminant_source_hypotheses A (fun i => (hA.1 i).2.1) hA.2
  have hgrad' : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i (realDeterminantPolynomial A))=t i := by
    intro i
    rw [hgrad i,(hA.1 i).2.2,Complex.ofReal_re]
  have h := hgrowth t (realDeterminantPolynomial A) hp hs hnorm ht hgrad' hnear
  rw [source_realDeterminant_objective,source_hermitian_deficit_distance t A hA (by omega)] at h
  nlinarith

theorem source_hermitian_global_growth_explicit (hn : 3 ≤ n) (t : Fin n → ℝ)
    (ht : (∑ i,t i)=n) (hnear : (∑ i,|t i-1|) ≤ 1/(1000000000*(n : ℝ)^8))
    (A : Fin n → ComplexSquare n) (hA : A ∈ hermitianFeasibleTuples t) :
    sourceVn n/(4000000000*(n : ℝ)^8)*complexTupleSq (A-complexReferenceTuple t) ≤
      hermitianMixedObjective A-sourceVn n*(∏ i,t i) := by
  obtain ⟨hp,hs,hnorm,hcoeff,hgrad⟩ := source_realDeterminant_source_hypotheses A (fun i => (hA.1 i).2.1) hA.2
  have hfun : (fun i => MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i (realDeterminantPolynomial A)))=t := by
    funext i
    rw [hgrad i,(hA.1 i).2.2,Complex.ofReal_re]
  have hgi (i : Fin n) : MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i (realDeterminantPolynomial A))=t i := congrFun hfun i
  have h := source_polynomial_global_coefficient_gap (realDeterminantPolynomial A) hn hp hs hnorm (by simpa only [hgi] using hnear)
  rw [hfun,source_realDeterminant_objective,source_hermitian_deficit_distance t A hA (by omega)] at h
  convert h using 1 <;> ring

theorem source_hermitian_global_equality_from_growth (t : Fin n → ℝ) (hn : 2 ≤ n)
    (κ : ℝ) (hκ : 0 < κ) (A : Fin n → ComplexSquare n)
    (hgrowth : κ*complexTupleSq (A-complexReferenceTuple t) ≤ hermitianMixedObjective A-sourceVn n*(∏ i,t i)) :
    sourceVn n*(∏ i,t i) ≤ hermitianMixedObjective A ∧
      (hermitianMixedObjective A=sourceVn n*(∏ i,t i) ↔ A=complexReferenceTuple t) := by
  have hδ := complexTupleSq_nonneg (A-complexReferenceTuple t)
  refine ⟨sub_nonneg.mp ((mul_nonneg hκ.le hδ).trans hgrowth),?_⟩
  constructor
  · intro he
    have hz : complexTupleSq (A-complexReferenceTuple t)=0 := by
      by_contra hh
      have hp := mul_pos hκ (lt_of_le_of_ne hδ (Ne.symm hh))
      rw [he,sub_self] at hgrowth
      linarith
    have hnorm := tuple_sq_norm_le_frobenius (A-complexReferenceTuple t)
    rw [hz] at hnorm
    have hzero : A-complexReferenceTuple t=0 := norm_eq_zero.mp (by nlinarith [sq_nonneg ‖A-complexReferenceTuple t‖,norm_nonneg (A-complexReferenceTuple t)])
    exact sub_eq_zero.mp hzero
  · intro he
    rw [he,referenceObjective_source_normalization t (by omega)]
    rfl

theorem source_hermitian_near_balanced_complete (hn : 2 ≤ n) :
    ∃ ε κ : ℝ,0 < ε ∧ 0 < κ ∧ ∀ t : Fin n → ℝ,(∑ i,t i)=n →
      (∀ i,0 < t i) → (∑ i,|t i-1|) < ε →
      complexReferenceTuple t ∈ hermitianFeasibleTuples t ∧
      ∀ A ∈ hermitianFeasibleTuples t,
        κ*complexTupleSq (A-complexReferenceTuple t) ≤ hermitianMixedObjective A-sourceVn n*(∏ i,t i) ∧
        sourceVn n*(∏ i,t i) ≤ hermitianMixedObjective A ∧
        (hermitianMixedObjective A=sourceVn n*(∏ i,t i) ↔ A=complexReferenceTuple t) := by
  obtain ⟨ε,κ,hε,hκ,hgrowth⟩ := source_hermitian_global_growth_exists hn
  refine ⟨ε,κ,hε,hκ,?_⟩
  intro t ht htpos hnear
  refine ⟨complexReferenceTuple_feasible t hn ht htpos,?_⟩
  intro A hA
  have hg := hgrowth t ht htpos hnear A hA
  exact ⟨hg,source_hermitian_global_equality_from_growth t hn κ hκ A hg⟩

end CoefficientStability
