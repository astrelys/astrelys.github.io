import CoefficientStability.ScaledMixedHessian

noncomputable section
open scoped BigOperators Matrix.Norms.Elementwise
namespace CoefficientStability
variable {n : ℕ}

def sourceScaledDirection (t : Fin n → ℝ) (A : Fin n → Matrix (Fin n) (Fin n) ℂ)
    (i : Fin n) : Matrix (Fin n) (Fin n) ℂ := Complex.ofReal ((n : ℝ)/t i) • A i

theorem sourceScaledDirection_normalization (t : Fin n → ℝ)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ) (hn : 0<n) (ht : ∀ i,t i≠0) :
    (fun i => Complex.ofReal (t i/(n : ℝ)) • sourceScaledDirection t A i)=A := by
  funext i
  have hn0 : (n : ℝ)≠0 := by exact_mod_cast (by omega : n≠0)
  simp only [sourceScaledDirection,smul_smul,← Complex.ofReal_mul]
  have he : t i/(n : ℝ)*((n : ℝ)/t i)=1 := by field_simp [ht i]
  rw [he,Complex.ofReal_one,one_smul]

theorem sourceScaledDirection_bracket (t : Fin n → ℝ)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    ((∑ i,complexFrobeniusSq (sourceScaledDirection t A i))-
      complexFrobeniusSq (∑ i,sourceScaledDirection t A i))=
      (n : ℝ)^2*matrixHessianBracket t A := by
  have he (i : Fin n) : sourceScaledDirection t A i=(n : ℂ) • (Complex.ofReal ((t i)⁻¹) • A i) := by
    simp [sourceScaledDirection,div_eq_mul_inv,Complex.ofReal_mul,smul_smul]
  have hnorm (B : Matrix (Fin n) (Fin n) ℂ) : complexFrobeniusSq ((n : ℂ) • B)=
      (n : ℝ)^2*complexFrobeniusSq B := by
    simpa only [Complex.ofReal_natCast] using complexFrobeniusSq_real_smul (n : ℝ) B
  simp only [he,← Finset.smul_sum,hnorm,← Finset.mul_sum,matrixHessianBracket,mul_sub]

theorem sourceHessianFactor_scaled (t : Fin n → ℝ) (hn : 2≤n) :
    ((∏ i,t i/(n : ℝ))*((n-2).factorial : ℝ))*(n : ℝ)^2=sourceHessianFactor t := by
  have hn0 : (n : ℝ)≠0 := by exact_mod_cast (by omega : n≠0)
  have hp : (n : ℝ)^n=(n : ℝ)^(n-2)*(n : ℝ)^2 := by
    rw [← pow_add]
    congr 1
    omega
  unfold sourceHessianFactor
  rw [Finset.prod_div_distrib]
  simp only [Finset.prod_const,Finset.card_univ,Fintype.card_fin]
  rw [hp]
  field_simp

theorem paper_actual_scalar_hessian (t : Fin n → ℝ) (hn : 2≤n) (htpos : ∀ i,0<t i)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ)
    (htrace : ∀ i,Matrix.trace (A i)=0) (hA : ∀ i,(A i).IsHermitian) :
    (deriv (fun s : ℂ => deriv (fun z : ℂ => complexMixedDiscriminant
      (complexReferenceTuple t+z • A)) s) 0).re=sourceHessianCandidate t A := by
  have hBtrace (i : Fin n) : Matrix.trace (sourceScaledDirection t A i)=0 := by
    simp [sourceScaledDirection,Matrix.trace_smul,htrace]
  have hB (i : Fin n) : (sourceScaledDirection t A i).IsHermitian := by
    exact (hA i).smul (by simp [IsSelfAdjoint])
  have h := actual_scaled_mixed_hessian_frobenius (fun i => t i/(n : ℝ))
    (sourceScaledDirection t A) hn hBtrace hB
  have href : (fun i => Complex.ofReal (t i/(n : ℝ)) • (1 : Matrix (Fin n) (Fin n) ℂ))=
      complexReferenceTuple t := (funext (complexReferenceTuple_source t)).symm
  rw [href,sourceScaledDirection_normalization t A (by omega) (fun i => ne_of_gt (htpos i)),
    sourceScaledDirection_bracket] at h
  calc
    _ = ((∏ i,t i/(n : ℝ))*((n-2).factorial : ℝ))*((n : ℝ)^2*matrixHessianBracket t A) := h
    _ = (((∏ i,t i/(n : ℝ))*((n-2).factorial : ℝ))*(n : ℝ)^2)*matrixHessianBracket t A := by ring
    _ = sourceHessianCandidate t A := by rw [sourceHessianFactor_scaled t hn];rfl

end CoefficientStability
