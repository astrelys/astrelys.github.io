import CoefficientStability.PositiveFactorCapacity
import Mathlib.Topology.Instances.RealVectorSpace

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem positive_factor_sublevel_box (P : Polynomial ℝ) (b : Fin n → ℝ) (hn : 2≤n)
    (hc : 0<P.eval 0) (hb : ∀ i,0<b i)
    (hf : ∀ z : ℝ,P.eval z=P.eval 0*∏ i,(1+b i*z))
    (M : ℝ) (hM : 0<M) (z : ℝ) (hz : 0<z) (hsub : P.eval z/z≤M) :
    P.eval 0/M≤z ∧ z≤M/(P.eval 0*b ⟨0,by omega⟩*b ⟨1,by omega⟩) := by
  classical
  let i : Fin n := ⟨0,by omega⟩
  let j : Fin n := ⟨1,by omega⟩
  have hij : i≠j := by simp [i,j]
  have hone (k : Fin n) : 1≤1+b k*z := by nlinarith [hb k]
  have hconst : P.eval 0≤P.eval z := by
    rw [hf z]
    exact le_mul_of_one_le_right hc.le (Finset.one_le_prod₀ (fun k hk => hone k))
  have htwo : (1+b i*z)*(1+b j*z)≤∏ k,(1+b k*z) := by
    have h := Finset.prod_le_prod_of_subset_of_one_le₀
      (Finset.subset_univ ({i,j} : Finset (Fin n)))
      (fun k hk => (hone k).trans' (by norm_num : (0 : ℝ)≤1))
      (fun k hk hnot => hone k)
    simpa [Finset.prod_pair hij] using h
  have hquad : P.eval 0*b i*b j*z^2≤P.eval z := by
    rw [hf z]
    have hmul := mul_le_mul_of_nonneg_left htwo hc.le
    nlinarith [mul_pos (hb i) hz,mul_pos (hb j) hz]
  have hupper := (div_le_iff₀ hz).mp hsub
  constructor
  · exact (div_le_iff₀ hM).mpr (hconst.trans (by simpa only [mul_comm] using hupper))
  · change z≤M/(P.eval 0*b i*b j)
    apply (le_div_iff₀ (mul_pos (mul_pos hc (hb i)) (hb j))).mpr
    nlinarith [mul_pos (hb i) (hb j)]

theorem positive_factor_capacity_ratio_attained (P : Polynomial ℝ) (b : Fin n → ℝ) (hn : 2≤n)
    (hc : 0<P.eval 0) (hb : ∀ i,0<b i)
    (hf : ∀ z : ℝ,P.eval z=P.eval 0*∏ i,(1+b i*z)) :
    ∃ zstar : ℝ,0<zstar ∧ ∀ z : ℝ,0<z → P.eval zstar/zstar≤P.eval z/z := by
  let M : ℝ := P.eval 1
  have hM : 0<M := by
    change 0<P.eval 1
    rw [hf 1]
    exact mul_pos hc (Finset.prod_pos (fun k hk => by nlinarith [hb k]))
  let a : ℝ := P.eval 0/M
  let B : ℝ := M/(P.eval 0*b ⟨0,by omega⟩*b ⟨1,by omega⟩)
  have ha : 0<a := div_pos hc hM
  have h1 : (1 : ℝ)∈Set.Icc a B :=
    positive_factor_sublevel_box P b hn hc hb hf M hM 1 (by norm_num) (by simp [M])
  have hcont : ContinuousOn (fun z : ℝ => P.eval z/z) (Set.Icc a B) := by
    apply P.continuous.continuousOn.div continuousOn_id
    intro z hz
    exact ne_of_gt (lt_of_lt_of_le ha hz.1)
  obtain ⟨zstar,hzstar,hmin⟩ := isCompact_Icc.exists_isMinOn ⟨1,h1⟩ hcont
  refine ⟨zstar,lt_of_lt_of_le ha hzstar.1,?_⟩
  intro z hz
  by_cases hsub : P.eval z/z≤M
  · have hzmem := positive_factor_sublevel_box P b hn hc hb hf M hM z hz hsub
    exact hmin hzmem
  · have hstar := hmin h1
    change P.eval zstar/zstar≤P.eval 1/1 at hstar
    simp only [div_one] at hstar
    exact hstar.trans (le_of_lt (lt_of_not_ge hsub))

theorem positive_split_capacity_attained (P : Polynomial ℝ) (hs : P.Splits)
    (hp : ∀ x : ℝ,0<x → 0<P.eval x) (hzero : 0<P.eval 0) (hdegree : 2≤P.natDegree) :
    ∃ zstar : ℝ,0<zstar ∧
      (∀ z : ℝ,0<z → P.eval zstar/zstar≤P.eval z/z) ∧
      positiveDomainCapacity P=P.eval zstar/zstar := by
  obtain ⟨k,hk,b,hb,hf⟩ := positive_split_positive_factor_form P hs hp hzero
  obtain ⟨z,hz,hmin⟩ := positive_factor_capacity_ratio_attained P b (by omega) hzero hb hf
  exact ⟨z,hz,hmin,positiveDomainCapacity_at_minimum P z hz hmin⟩

end CoefficientStability
