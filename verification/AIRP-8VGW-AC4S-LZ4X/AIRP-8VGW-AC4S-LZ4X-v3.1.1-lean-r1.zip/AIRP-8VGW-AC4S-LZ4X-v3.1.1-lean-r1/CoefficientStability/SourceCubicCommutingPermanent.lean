import CoefficientStability.SourceHermitianSimultaneousDiagonalization
import CoefficientStability.SourceHermitianFeasibleCompact
import CoefficientStability.SourcePermanentBridge

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 3500000
set_option backward.isDefEq.respectTransparency false

theorem source_cubic_commuting_permanent_recovery (t : Fin 3 → ℝ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : A ∈ hermitianFeasibleTuples t)
    (hc : ∀ i j,A i*A j=A j*A i) :
    ∃ (U : Matrix.unitaryGroup (Fin 3) ℂ) (B : Matrix (Fin 3) (Fin 3) ℝ),
      B ∈ sourceTransportationPolytope t ∧ sourceCubicUnitaryAction U A=sourcePermanentDiagonalTuple B ∧
      hermitianMixedObjective A=Matrix.permanent B := by
  obtain ⟨U,z,hdiag⟩ := source_hermitian_simultaneous_unitary_diagonalization A (fun i => (hA.1 i).1) hc
  let B : Matrix (Fin 3) (Fin 3) ℝ := fun i j => (z i j).re
  let D := sourceCubicUnitaryAction U A
  have hD : D ∈ hermitianFeasibleTuples t := source_cubic_unitary_feasible t U A hA
  have hd : ∀ i,D i=Matrix.diagonal (z i) := hdiag
  have hzreal : ∀ i j,(B i j : ℂ)=z i j := by
    intro i j
    have h : (((D i) j j).re : ℂ)=(D i) j j := (hD.1 i).1.coe_re_apply_self j
    simpa only [hd i,Matrix.diagonal_apply_eq] using h
  have hB : B ∈ sourceTransportationPolytope t := by
    refine ⟨?_,?_,?_⟩
    · intro i j
      have h := (hD.1 i).2.1.diag_nonneg (i := j)
      rw [hd i,Matrix.diagonal_apply_eq] at h
      exact (Complex.nonneg_iff.mp h).1
    · intro i
      have h := congrArg Complex.re (hD.1 i).2.2
      simpa only [hd i,Matrix.trace_diagonal,Complex.re_sum,Complex.ofReal_re] using h
    · intro j
      have h := congrArg (fun M : Matrix (Fin 3) (Fin 3) ℂ => (M j j).re) hD.2
      simpa only [Matrix.sum_apply,hd,Matrix.diagonal_apply_eq,Complex.re_sum,Matrix.one_apply_eq,Complex.one_re] using h
  have htuple : D=sourcePermanentDiagonalTuple B := by
    funext i
    rw [hd i]
    congr 1
    funext j
    exact (hzreal i j).symm
  have hval : hermitianMixedObjective A=Matrix.permanent B := by
    have h := congrArg Complex.re (source_cubic_unitary_mixed_invariant U A hA.2)
    change hermitianMixedObjective D=hermitianMixedObjective A at h
    rw [htuple,source_permanent_diagonal_objective] at h
    exact h.symm
  exact ⟨U,B,hB,htuple,hval⟩

theorem source_cubic_matrix_permanent_minimizers (t : Fin 3 → ℝ)
    (ht : (∑ i,t i)=3) (hp : ∀ i,0 < t i) :
    ∃ (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (B : Matrix (Fin 3) (Fin 3) ℝ),
      A ∈ hermitianFeasibleTuples t ∧ B ∈ sourceTransportationPolytope t ∧
      IsMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A ∧
      IsMinOn Matrix.permanent (sourceTransportationPolytope t) B ∧
      hermitianMixedObjective A=Matrix.permanent B := by
  obtain ⟨A,hA,hm,hc⟩ := source_cubic_commuting_global_minimum_exists t ht hp
  obtain ⟨U,B,hB,htu,hval⟩ := source_cubic_commuting_permanent_recovery t A hA hc
  refine ⟨A,B,hA,hB,hm,?_,hval⟩
  intro C hC
  change Matrix.permanent B ≤ Matrix.permanent C
  rw [← hval,← source_permanent_diagonal_objective C]
  exact hm (source_permanent_diagonal_feasible t C hC)

theorem source_cubic_matrix_permanent_minimum_value (t : Fin 3 → ℝ)
    (ht : (∑ i,t i)=3) (hp : ∀ i,0 < t i) :
    sInf (hermitianMixedObjective '' hermitianFeasibleTuples t)=
      sInf (Matrix.permanent '' sourceTransportationPolytope t) := by
  obtain ⟨A,B,hA,hB,hmA,hmB,hval⟩ := source_cubic_matrix_permanent_minimizers t ht hp
  have hLA : IsLeast (hermitianMixedObjective '' hermitianFeasibleTuples t) (hermitianMixedObjective A) :=
    ⟨⟨A,hA,rfl⟩,by rintro _ ⟨C,hC,rfl⟩;exact hmA hC⟩
  have hLB : IsLeast (Matrix.permanent '' sourceTransportationPolytope t) (Matrix.permanent B) :=
    ⟨⟨B,hB,rfl⟩,by rintro _ ⟨C,hC,rfl⟩;exact hmB hC⟩
  rw [hLA.csInf_eq,hLB.csInf_eq,hval]

theorem source_original_cubic_commuting_reduction (t : Fin 3 → ℝ)
    (ht : (∑ i,t i)=3) (hp : ∀ i,0 < t i) :
    (∀ A ∈ hermitianFeasibleTuples t,
      IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A → ∀ i j,A i*A j=A j*A i) ∧
    sInf (hermitianMixedObjective '' hermitianFeasibleTuples t)=
      sInf (Matrix.permanent '' sourceTransportationPolytope t) :=
  ⟨fun A hA hm => source_original_cubic_local_minimum_pairwise_commutation t ht hp A hA hm,
    source_cubic_matrix_permanent_minimum_value t ht hp⟩

end CoefficientStability
