import CoefficientStability.SourceStableCubicPlaneRecovery
import CoefficientStability.SourceStableCubicDefiniteTransfer

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceCubicPlanePencil (L K : Matrix (Fin 3) (Fin 3) ℂ) :
    Fin 3 → Matrix (Fin 3) (Fin 3) ℂ := ![-1+L,-1+K,(3 : ℂ) • 1-L-K]

theorem source_cubic_plane_pencil_hermitian (L K : Matrix (Fin 3) (Fin 3) ℂ)
    (hL : L.IsHermitian) (hK : K.IsHermitian) :
    ∀ i,(sourceCubicPlanePencil L K i).IsHermitian := by
  intro i
  fin_cases i
  · exact Matrix.isHermitian_one.neg.add hL
  · exact Matrix.isHermitian_one.neg.add hK
  · exact ((Matrix.isHermitian_one.smul (by norm_num : IsSelfAdjoint (3 : ℂ))).sub hL).sub hK

theorem source_cubic_plane_pencil_sum (L K : Matrix (Fin 3) (Fin 3) ℂ) :
    (∑ i,sourceCubicPlanePencil L K i)=1 := by
  norm_num [Fin.sum_univ_succ,sourceCubicPlanePencil]
  module

theorem source_cubic_plane_pencil_actual_evaluation (L K : Matrix (Fin 3) (Fin 3) ℂ)
    (u : Fin 2 → ℝ) :
    (∑ i,(sourceCubicPlanePoint u i : ℂ) • sourceCubicPlanePencil L K i)=
      1+(u 0 : ℂ) • L+(u 1 : ℂ) • K := by
  norm_num [Fin.sum_univ_succ,sourceCubicPlanePencil,sourceCubicPlanePoint,sourceCubicPlaneV,sourceCubicPlaneW]
  push_cast
  module

theorem source_stable_cubic_bivariate_pencil_recovers_original
    (p : MvPolynomial (Fin 3) ℝ) (hp : p.IsHomogeneous 3)
    (L K : Matrix (Fin 3) (Fin 3) ℂ) (hL : L.IsHermitian) (hK : K.IsHermitian)
    (hrep : ∀ u : Fin 2 → ℝ,
      (MvPolynomial.eval u (sourceCubicPlanePolynomial p) : ℂ)=
        Matrix.det (1+(u 0 : ℂ) • L+(u 1 : ℂ) • K)) :
    p=realDeterminantPolynomial (sourceCubicPlanePencil L K) := by
  have hH := source_cubic_plane_pencil_hermitian L K hL hK
  apply source_cubic_plane_homogeneous_injective p _ hp (source_realDeterminant_homogeneous _ hH)
  apply MvPolynomial.funext
  intro u
  apply Complex.ofReal_injective
  rw [source_cubic_plane_actual_evaluation (realDeterminantPolynomial _) u,realDeterminantPolynomial_evaluation _ hH,
    source_cubic_plane_pencil_actual_evaluation]
  exact hrep u

theorem source_stable_cubic_bivariate_pencil_feasible
    (p : MvPolynomial (Fin 3) ℝ) (hp : p.IsHomogeneous 3) (hs : UpperHalfPlaneZeroFree p)
    (t : Fin 3 → ℝ) (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (L K : Matrix (Fin 3) (Fin 3) ℂ) (hL : L.IsHermitian) (hK : K.IsHermitian)
    (hrep : ∀ u : Fin 2 → ℝ,
      (MvPolynomial.eval u (sourceCubicPlanePolynomial p) : ℂ)=
        Matrix.det (1+(u 0 : ℂ) • L+(u 1 : ℂ) • K)) :
    sourceCubicPlanePencil L K ∈ hermitianFeasibleTuples t ∧
      p=realDeterminantPolynomial (sourceCubicPlanePencil L K) := by
  have he := source_stable_cubic_bivariate_pencil_recovers_original p hp L K hL hK hrep
  refine ⟨source_stable_cubic_normalized_pencil_feasible t _
    (source_cubic_plane_pencil_hermitian L K hL hK)
    (source_cubic_plane_pencil_sum L K) ?_ ?_,he⟩
  · rw [← he]
    exact hs
  · rw [← he]
    exact hg

end CoefficientStability
