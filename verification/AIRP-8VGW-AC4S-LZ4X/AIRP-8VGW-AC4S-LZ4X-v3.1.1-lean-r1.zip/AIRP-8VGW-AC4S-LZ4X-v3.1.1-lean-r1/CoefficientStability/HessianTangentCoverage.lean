import CoefficientStability.HermitianHessianInertia
import CoefficientStability.SymmetricHessianInertia

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem hermitianTangentTuple_covers (A : Fin n → ComplexSquare n)
    (hHerm : ∀ i,(A i).IsHermitian) (htrace : ∀ i,Matrix.trace (A i)=0) (hsum : ∑ i,A i=0) :
    ∃ w : vectorTangent (tracelessHermitian n) (fun _ : Fin n => 1),hermitianTangentTuple w=A := by
  let w : Fin n → tracelessHermitian n := fun i => ⟨⟨A i,hHerm i⟩,by
    change (Matrix.trace (A i)).re=0
    rw [htrace i,Complex.zero_re]⟩
  have hw : (∑ i,w i)=0 := by
    let L := tracelessHermitianInclusion n
    have hi : Function.Injective L := fun x y h => Subtype.ext (Subtype.ext h)
    apply hi
    rw [map_sum,map_zero]
    exact hsum
  refine ⟨⟨w,?_⟩,rfl⟩
  change (∑ i,1 • w i)=0
  simpa only [one_smul] using hw

theorem hermitianTangentTuple_constraints
    (w : vectorTangent (tracelessHermitian n) (fun _ : Fin n => 1)) :
    (∀ i,(hermitianTangentTuple w i).IsHermitian) ∧
    (∀ i,Matrix.trace (hermitianTangentTuple w i)=0) ∧ (∑ i,hermitianTangentTuple w i)=0 := by
  refine ⟨fun i => (w.val i).val.property,fun i => tracelessHermitian_has_trace_zero (w.val i),?_⟩
  have hw : (∑ i,w.val i)=0 := by
    simpa [vectorTangent,vectorMarginalDot] using w.property
  have h := congrArg (tracelessHermitianInclusion n) hw
  rw [map_sum,map_zero] at h
  exact h

theorem symmetricTangentTuple_covers (A : Fin n → RealSquare n)
    (hSym : ∀ i,(A i).IsSymm) (htrace : ∀ i,Matrix.trace (A i)=0) (hsum : ∑ i,A i=0) :
    ∃ w : vectorTangent (tracelessSymmetric n) (fun _ : Fin n => 1),
      symmetricTangentTuple w=fun i => (A i).map Complex.ofReal := by
  let w : Fin n → tracelessSymmetric n := fun i => ⟨⟨A i,hSym i⟩,htrace i⟩
  have hw : (∑ i,w i)=0 := by
    let L : tracelessSymmetric n →ₗ[ℝ] RealSquare n :=
      (selfAdjoint.submodule ℝ (RealSquare n)).subtype.comp (tracelessSymmetric n).subtype
    have hi : Function.Injective L := fun x y h => Subtype.ext (Subtype.ext h)
    apply hi
    rw [map_sum,map_zero]
    exact hsum
  refine ⟨⟨w,?_⟩,rfl⟩
  change (∑ i,1 • w i)=0
  simpa only [one_smul] using hw

end CoefficientStability
