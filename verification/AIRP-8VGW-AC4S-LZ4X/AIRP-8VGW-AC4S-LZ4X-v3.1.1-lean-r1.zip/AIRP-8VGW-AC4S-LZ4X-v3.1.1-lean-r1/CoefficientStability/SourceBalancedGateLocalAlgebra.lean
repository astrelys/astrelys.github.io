import CoefficientStability.SourceEscapeBalancedGeometry

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceEscapeFrobeniusSq (H : Matrix (Fin 3) (Fin 3) ℝ) : ℝ := ∑ i,sourceEscapeRowSq H i

def sourceEscapeDiagonalSq (H : Matrix (Fin 3) (Fin 3) ℝ) : ℝ := ∑ i,(H i i)^2

theorem source_balanced_gate_actual_quadratic_increment (H : Matrix (Fin 3) (Fin 3) ℝ)
    (hH : H ∈ sourceEscapeTangent) :
    sourceEscapeQuadratic 1 1 (sourceBalancedEscapeGate-sourceEscapeCenter 1 1+H)-1/12=
      (sourceEscapeFrobeniusSq H-Matrix.trace H)/6 := by
  rw [source_zero_marginal_chart_recovery H hH]
  norm_num [sourceEscapeQuadratic,sourceEscapeWeights,sourceEscapeFrobeniusSq,sourceEscapeRowSq,
    sourceBalancedEscapeGate,sourceEscapeCenter,sourceEscapeTraces,sourcePermanentReference,
    sourceZeroMarginalChart,Matrix.add_apply,Matrix.sub_apply,Matrix.trace,Matrix.diag_apply,Fin.sum_univ_succ]
  ring

theorem source_balanced_gate_actual_permanent_expansion (H : Matrix (Fin 3) (Fin 3) ℝ)
    (hH : H ∈ sourceEscapeTangent) :
    Matrix.permanent (sourceBalancedEscapeGate+H)-1/4=
      sourceEscapeFrobeniusSq H/2-sourceEscapeDiagonalSq H+Matrix.permanent H := by
  rw [source_zero_marginal_chart_recovery H hH]
  norm_num [source_permanent_three,sourceEscapeFrobeniusSq,sourceEscapeRowSq,sourceEscapeDiagonalSq,
    sourceBalancedEscapeGate,sourceZeroMarginalChart,Matrix.add_apply,Fin.sum_univ_succ]
  ring

theorem source_escape_frobenius_nonnegative (H : Matrix (Fin 3) (Fin 3) ℝ) :
    0 ≤ sourceEscapeFrobeniusSq H :=
  Finset.sum_nonneg (fun i _ => Finset.sum_nonneg (fun j _ => sq_nonneg _))

theorem source_escape_two_rows_square_le_frobenius (H : Matrix (Fin 3) (Fin 3) ℝ) (j k : Fin 3) :
    (H 1 j)^2+(H 2 k)^2 ≤ sourceEscapeFrobeniusSq H := by
  have h1 : (H 1 j)^2 ≤ sourceEscapeRowSq H 1 := Finset.single_le_sum (fun l _ => sq_nonneg (H 1 l)) (Finset.mem_univ j)
  have h2 : (H 2 k)^2 ≤ sourceEscapeRowSq H 2 := Finset.single_le_sum (fun l _ => sq_nonneg (H 2 l)) (Finset.mem_univ k)
  have h0 : 0 ≤ sourceEscapeRowSq H 0 := Finset.sum_nonneg (fun l _ => sq_nonneg _)
  have he : sourceEscapeFrobeniusSq H=sourceEscapeRowSq H 0+sourceEscapeRowSq H 1+sourceEscapeRowSq H 2 := by
    norm_num only [sourceEscapeFrobeniusSq,Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero]
    change sourceEscapeRowSq H 0+(sourceEscapeRowSq H 1+sourceEscapeRowSq H 2)=_
    ring
  rw [he]
  linarith

theorem source_escape_diagonal_square_le_trace_square (H : Matrix (Fin 3) (Fin 3) ℝ)
    (hdiag : ∀ i,0 ≤ H i i) : sourceEscapeDiagonalSq H ≤ (Matrix.trace H)^2 := by
  norm_num [sourceEscapeDiagonalSq,Matrix.trace,Matrix.diag_apply,Fin.sum_univ_succ]
  nlinarith [mul_nonneg (hdiag 0) (hdiag 1),mul_nonneg (hdiag 0) (hdiag 2),mul_nonneg (hdiag 1) (hdiag 2)]

end CoefficientStability
