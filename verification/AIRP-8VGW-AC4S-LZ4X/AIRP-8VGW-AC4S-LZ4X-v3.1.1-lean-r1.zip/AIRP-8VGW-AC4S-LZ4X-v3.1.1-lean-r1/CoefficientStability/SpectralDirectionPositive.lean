import CoefficientStability.SpectralSegmentPositivity

noncomputable section
namespace CoefficientStability
variable {n N : ℕ}

theorem source_direction_one_coeff_positive (p : MvPolynomial (Fin n) ℝ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N) :
    ∀ k : Fin (N+1),0<(normalizedDirectionalRestriction p b (fun _ => 1)).coeff k.val := by
  let P := normalizedDirectionalRestriction p b (fun _ => 1)
  obtain ⟨hm,hsp,hd⟩ := normalizedDirectionalRestriction_properties p hN hp hs hnorm b hb (fun _ => 1)
  have hpos (t : ℝ) (ht : 0≤t) : 0<P.eval t := by
    rw [normalizedDirectionalRestriction_eval]
    exact mul_pos (inv_pos.mpr (positiveSpectralCone_eval_pos p hp hs hnorm b hb))
      (source_cone_reciprocal_ray_eval_pos p hp hnorm b hb t ht)
  obtain ⟨roots,hcard,hr,hlead,hfactor⟩ := positive_constant_split_positive_multiset_factors P hsp
    (fun t ht => hpos t ht.le) (hpos 0 le_rfl)
  have hmP : P.Monic := hm
  have hf : P=(roots.map (fun r => Polynomial.X+Polynomial.C r)).prod := by
    simpa only [hmP.leadingCoeff,Polynomial.C_1,one_mul] using hfactor
  intro k
  change 0<P.coeff k.val
  rw [hf]
  exact (positive_root_product_coefficients roots hr).2 k.val (by rw [hcard,hd];omega)

theorem source_cone_direction_coeff_positive (p : MvPolynomial (Fin n) ℝ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N)
    (y : Fin n → ℝ) (hy : y∈positiveSpectralCone p N) :
    ∀ k : Fin (N+1),0<(normalizedDirectionalRestriction p b y).coeff k.val := by
  let A := Set.Icc (0 : ℝ) 1
  letI : PreconnectedSpace A := Subtype.preconnectedSpace (isPreconnected_Icc : IsPreconnected (Set.Icc (0 : ℝ) 1))
  let ψ : A → Fin n → ℝ := fun a i => a.val*y i+(1-a.val)
  have hψ : Continuous ψ := by
    apply continuous_pi
    intro i
    convert! (continuous_subtype_val.mul_const (y i)).add
      (continuous_const.sub continuous_subtype_val) using 1
  let P : A → Polynomial ℝ := fun a => normalizedDirectionalRestriction p b (ψ a)
  have hprops (a : A) := normalizedDirectionalRestriction_properties p hN hp hs hnorm b hb (ψ a)
  have hcont (k : ℕ) : Continuous (fun a : A => (P a).coeff k) := by
    exact (normalizedDirectionalRestriction_coeff_continuous p b k).comp hψ
  have hzero (a : A) : (P a).coeff 0≠0 := by
    rw [Polynomial.coeff_zero_eq_eval_zero]
    apply ne_of_gt
    change 0<(normalizedDirectionalRestriction p b (ψ a)).eval 0
    rw [normalizedDirectionalRestriction_eval]
    simp only [zero_mul,add_zero]
    exact mul_pos (inv_pos.mpr (positiveSpectralCone_eval_pos p hp hs hnorm b hb))
      (source_cone_segment_eval_pos p hp hnorm y hy a.val a.property.1 a.property.2)
  let a0 : A := ⟨0,by constructor <;> norm_num⟩
  have hstart : ∀ k : Fin (N+1),0<(P a0).coeff k.val := by
    simpa only [P,ψ,a0,zero_mul,sub_zero,zero_add] using
      source_direction_one_coeff_positive p hN hp hs hnorm b hb
  have h := connected_real_split_positive_coefficients P
    (fun a => (hprops a).1) (fun a => (hprops a).2.1) (fun a => (hprops a).2.2)
    hcont hzero a0 hstart
  simpa only [P,ψ,one_mul,sub_self,add_zero] using h ⟨1,by constructor <;> norm_num⟩

end CoefficientStability
