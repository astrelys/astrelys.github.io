import CoefficientStability.StableSliceAttainment

noncomputable section
open scoped BigOperators Topology
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem coordinate_log_minimum_moment_one (p : MvPolynomial (Fin n) ℝ)
    (u : Fin n → ℝ) (i : Fin n) (hZ : tiltPartition p u≠0)
    (hmin : ∀ s : ℝ,logCapacityRatio p u≤logCapacityRatio p (u+s • Pi.single i 1)) :
    tiltedMoment p u i=1 := by
  have hm : IsMinOn (fun s : ℝ => logCapacityRatio p (u+s • Pi.single i 1)) Set.univ 0 := by
    intro s hs
    simpa only [Set.mem_setOf_eq,zero_smul,add_zero] using hmin s
  have hz := (hm.isLocalMin (by simp)).hasDerivAt_eq_zero
    (logCapacityRatio_path_hasDerivAt p u (Pi.single i 1) hZ)
  have he : (∑ j,(tiltedMoment p u j-1)*(Pi.single i (1 : ℝ) : Fin n → ℝ) j)=tiltedMoment p u i-1 := by
    simp [Pi.single_apply]
  rw [he] at hz
  linarith

theorem centered_slice_coordinate_log_minimum (hn : 0<n)
    (p : MvPolynomial (Fin n) ℝ) (hp : p.IsHomogeneous n) (hpne : p≠0)
    (hc : ∀ g,0≤p.coeff g) (x : Fin n → ℝ) (hx : ∀ j,0<x j) (i : Fin n)
    (hmin : ∀ z : ℝ,0<z →
      (realCoordinateRestriction x i p).eval (x i)/x i≤(realCoordinateRestriction x i p).eval z/z) :
    ∀ s : ℝ,logCapacityRatio p (centeredLogVector x)≤
      logCapacityRatio p (centeredLogVector x+s • Pi.single i 1) := by
  intro s
  let a : ℝ := Real.exp (-(∑ j,Real.log (x j))/(n : ℝ))
  have ha : 0<a := Real.exp_pos _
  let z : ℝ := x i*Real.exp s
  have hz : 0<z := mul_pos (hx i) (Real.exp_pos _)
  have hbase : (fun j => Real.exp (centeredLogVector x j))=(fun j => a*x j) :=
    funext (centeredLogVector_exp x hx)
  have hpath : (fun j => Real.exp ((centeredLogVector x+s • (Pi.single i (1 : ℝ) : Fin n → ℝ) : Fin n → ℝ) j))=
      (fun j => a*(Function.update x i z) j) := by
    classical
    funext j
    by_cases hji : j=i
    · subst j
      simp only [Pi.add_apply,Pi.smul_apply,smul_eq_mul,Pi.single_eq_same,mul_one,Real.exp_add,
        centeredLogVector_exp x hx,Function.update_self]
      dsimp [a,z]
      ring
    · simp only [Pi.add_apply,Pi.smul_apply,smul_eq_mul,Pi.single_eq_of_ne hji,mul_zero,add_zero,
        Function.update_of_ne hji,centeredLogVector_exp x hx]
      rfl
  have hprod : (∏ j,(Function.update x i z) j)=(∏ j,x j)/(x i)*z := by
    classical
    rw [Finset.prod_update_of_mem (Finset.mem_univ i)]
    have h := Finset.mul_prod_erase (Finset.univ : Finset (Fin n)) x (Finset.mem_univ i)
    rw [Finset.sdiff_singleton_eq_erase,mul_comm z]
    congr 1
    apply (eq_div_iff (ne_of_gt (hx i))).mpr
    nlinarith [h]
  have hnum := hmin z hz
  simp only [realCoordinateRestriction_eval,Function.update_eq_self] at hnum
  have hother : 0<(∏ j,x j)/(x i) := div_pos (Finset.prod_pos (fun j hj => hx j)) (hx i)
  have hratio : MvPolynomial.eval x p/(∏ j,x j)≤
      MvPolynomial.eval (Function.update x i z) p/(∏ j,(Function.update x i z) j) := by
    rw [hprod]
    have hxx : (∏ j,x j)=((∏ j,x j)/(x i))*(x i) :=
      (div_mul_cancel₀ _ (ne_of_gt (hx i))).symm
    calc
      MvPolynomial.eval x p/(∏ j,x j)=(MvPolynomial.eval x p/(x i))/((∏ j,x j)/(x i)) := by
        rw [div_div]
        congr 1
        exact hxx.trans (mul_comm _ _)
      _≤(MvPolynomial.eval (Function.update x i z) p/z)/((∏ j,x j)/(x i)) :=
        div_le_div_of_nonneg_right hnum hother.le
      _=MvPolynomial.eval (Function.update x i z) p/((∏ j,x j)/(x i)*z) := by
        rw [div_div,mul_comm z]

  rw [logCapacityRatio_eq_log_ratio p hpne hc,logCapacityRatio_eq_log_ratio p hpne hc,hbase,hpath,
    homogeneous_capacity_ratio_scale p hp a ha x,
    homogeneous_capacity_ratio_scale p hp a ha (Function.update x i z)]
  have hy : ∀ j,0<(Function.update x i z) j := by
    intro j
    by_cases hji : j=i
    · subst j;simpa using hz
    · simpa only [Function.update_of_ne hji] using hx j
  exact (Real.log_le_log_iff
    (div_pos (nonnegative_coeff_eval_pos p hpne hc x hx) (Finset.prod_pos (fun j hj => hx j)))
    (div_pos (nonnegative_coeff_eval_pos p hpne hc _ hy) (Finset.prod_pos (fun j hj => hy j)))).mpr hratio

end CoefficientStability
