import CoefficientStability.GeneralMixedCoefficient

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ} {R : Type*} [CommRing R]

def matrixColumnLinear (c : Fin n) : Matrix (Fin n) (Fin n) R →ₗ[R] (Fin n → R) where
  toFun A r := A r c
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

def columnDetMultilinear : MultilinearMap R (fun _ : Fin n => Matrix (Fin n) (Fin n) R) R :=
  (Matrix.detRowAlternating : (Fin n → R) [⋀^Fin n]→ₗ[R] R).toMultilinearMap.compLinearMap
    (fun i => matrixColumnLinear i)

def actualMixedMultilinear : MultilinearMap R (fun _ : Fin n => Matrix (Fin n) (Fin n) R) R :=
  ∑ q : Equiv.Perm (Fin n),MultilinearMap.domDomCongr q columnDetMultilinear

theorem columnDetMultilinear_apply (A : Fin n → Matrix (Fin n) (Fin n) R) :
    columnDetMultilinear A=Matrix.det (fun r c => A c r c) := by
  change Matrix.det (Matrix.transpose (fun r c => A c r c))=_
  exact Matrix.det_transpose _

theorem actualMixedMultilinear_eq (A : Fin n → Matrix (Fin n) (Fin n) R) :
    actualMixedMultilinear A=genericMixedDiscriminant A := by
  rw [genericMixedDiscriminant_eq_rowDetSum]
  simp only [actualMixedMultilinear,MultilinearMap.sum_apply,MultilinearMap.domDomCongr_apply,
    columnDetMultilinear_apply]

end CoefficientStability
