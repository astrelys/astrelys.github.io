import CoefficientStability.SourceCubicFeasibleGeometry

noncomputable section
open scoped BigOperators ComplexOrder Matrix.Norms.Elementwise Topology
namespace CoefficientStability
set_option maxHeartbeats 2200000
set_option backward.isDefEq.respectTransparency false

theorem source_cubic_local_minimum_gradient_nonnegative (t : Fin 3 → ℝ)
    (A B : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) (hB : B ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A) :
    0 ≤ ∑ i,(Matrix.trace (sourceCubicMatrixGradient (t i) (A i)*(B i-A i))).re := by
  let γ : ℝ → (Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) := fun s => A+(s : ℂ) • (B-A)
  have he (s : ℝ) : γ s=(1-s) • A+s • B := by
    funext i
    ext r c
    simp only [γ,Pi.add_apply,Pi.smul_apply,Pi.sub_apply,Matrix.add_apply,Matrix.sub_apply,Matrix.smul_apply,
      Complex.real_smul,smul_eq_mul,Complex.ofReal_sub,Complex.ofReal_one]
    ring
  have hf (s : ℝ) (hs : s ∈ Set.Icc 0 1) : γ s ∈ hermitianFeasibleTuples t := by
    rw [he]
    exact source_hermitian_feasible_convex t hA hB (by linarith [hs.2]) hs.1 (by ring)
  have hc : Continuous γ := by unfold γ;fun_prop
  have hz : γ 0=A := by simp [γ]
  have hm0 : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (γ 0) := by rw [hz];exact hm
  have hcomp : IsLocalMinOn (fun s => hermitianMixedObjective (γ s)) (Set.Icc 0 1) 0 :=
    hm0.comp_continuousOn hf hc.continuousOn (by constructor <;> norm_num)
  have hsum : (∑ i,(B-A) i)=0 := by simp only [Pi.sub_apply,Finset.sum_sub_distrib,hA.2,hB.2,sub_self]
  have htrace : ∀ i,Matrix.trace ((B-A) i)=0 := by
    intro i
    simp only [Pi.sub_apply,Matrix.trace_sub,(hA.1 i).2.2,(hB.1 i).2.2,sub_self]
  have hd := source_cubic_mixed_constrained_hasDerivAt t A (B-A) hA.2 (fun i => (hA.1 i).2.2) hsum htrace
  exact source_right_local_minimum_derivative_nonnegative _ _ hcomp hd

theorem source_cubic_local_minimum_linear_minimum (t : Fin 3 → ℝ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : A ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A) :
    IsMinOn (fun B => ∑ i,(Matrix.trace (sourceCubicMatrixGradient (t i) (A i)*B i)).re)
      (hermitianFeasibleTuples t) A := by
  intro B hB
  have hn := source_cubic_local_minimum_gradient_nonnegative t A B hA hB hm
  simp only [mul_sub,Matrix.trace_sub,Complex.sub_re,Finset.sum_sub_distrib] at hn
  exact sub_nonneg.mp hn

end CoefficientStability
