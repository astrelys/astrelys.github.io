import CoefficientStability.SpectralConeOrthant

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem lineRestriction_shift_factors (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ)
    (roots : Multiset ℝ)
    (hf : lineRestriction p x=(roots.map (fun r => Polynomial.X+Polynomial.C r)).prod) (a : ℝ) :
    lineRestriction p (fun i => x i+a)=
      ((roots.map (fun r => r+a)).map (fun r => Polynomial.X+Polynomial.C r)).prod := by
  apply Polynomial.funext
  intro t
  have heq : (lineRestriction p (fun i => x i+a)).eval t=(lineRestriction p x).eval (t+a) := by
    rw [eval_lineRestriction_real,eval_lineRestriction_real]
    apply congrArg (fun w : Fin n → ℝ => MvPolynomial.eval w p)
    funext i
    ring
  rw [heq,hf,Polynomial.eval_multiset_prod,Polynomial.eval_multiset_prod]
  simp only [Multiset.map_map,Function.comp_def,Polynomial.eval_add,Polynomial.eval_X,Polynomial.eval_C]
  congr 1
  apply Multiset.map_congr rfl
  intro r hr
  ring

theorem nonnegative_spectral_factors_mem_closure (p : MvPolynomial (Fin n) ℝ)
    (N : ℕ) (x : Fin n → ℝ) (roots : Multiset ℝ) (hcard : roots.card=N)
    (hr : ∀ r∈roots,0≤r)
    (hf : lineRestriction p x=(roots.map (fun r => Polynomial.X+Polynomial.C r)).prod) :
    x∈closure (positiveSpectralCone p N) := by
  apply Metric.mem_closure_iff.mpr
  intro ε hε
  let y : Fin n → ℝ := fun i => x i+ε/2
  have hycone : y∈positiveSpectralCone p N := by
    refine ⟨roots.map (fun r => r+ε/2),by simpa only [Multiset.card_map] using hcard,?_,?_⟩
    · intro r hmem
      obtain ⟨s,hs,rfl⟩ := Multiset.mem_map.mp hmem
      linarith [hr s hs]
    · exact lineRestriction_shift_factors p x roots hf (ε/2)
  refine ⟨y,hycone,?_⟩
  have hnorm : ‖y-x‖≤ε/2 := by
    apply (pi_norm_le_iff_of_nonneg (by linarith : (0 : ℝ)≤ε/2)).mpr
    intro i
    simp only [Pi.sub_apply,y,add_sub_cancel_left,Real.norm_eq_abs]
    exact le_of_eq (abs_of_nonneg (by linarith))
  rw [dist_comm,dist_eq_norm]
  exact hnorm.trans_lt (by linarith)

end CoefficientStability
