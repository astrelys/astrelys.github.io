import CoefficientStability.SmoothedLineFamily
import Mathlib.Algebra.Polynomial.Eval.Degree

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem nuij_step_constant_comp_scale (P : Polynomial ℝ) (c a ε : ℝ) :
    nuijUnivariateStep ε (Polynomial.C c*P.comp (Polynomial.C a*Polynomial.X))=
      Polynomial.C c*(nuijUnivariateStep (ε*a) P).comp (Polynomial.C a*Polynomial.X) := by
  simp only [nuijUnivariateStep,Polynomial.derivative_C_mul,Polynomial.derivative_comp,
    Polynomial.derivative_X,Polynomial.add_comp,Polynomial.mul_comp,Polynomial.C_comp,map_mul]
  ring

theorem nuij_iterate_constant_comp_scale (P : Polynomial ℝ) (c a ε : ℝ) (k : ℕ) :
    (nuijUnivariateStep ε)^[k] (Polynomial.C c*P.comp (Polynomial.C a*Polynomial.X))=
      Polynomial.C c*((nuijUnivariateStep (ε*a))^[k] P).comp (Polynomial.C a*Polynomial.X) := by
  induction k with
  | zero => rfl
  | succ k ih =>
    rw [Function.iterate_succ_apply',ih,nuij_step_constant_comp_scale,Function.iterate_succ_apply']

theorem homogeneous_line_affine_normalization (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (x b : Fin n → ℝ) (t : ℝ) (ht : t≠0) :
    lineRestriction p (x+t • b)=Polynomial.C (t^N)*
      (lineRestriction p (b+(1/t) • x)).comp (Polynomial.C (1/t)*Polynomial.X) := by
  apply Polynomial.funext
  intro s
  rw [eval_lineRestriction_real,Polynomial.eval_mul,Polynomial.eval_C,Polynomial.eval_comp,
    Polynomial.eval_mul,Polynomial.eval_C,Polynomial.eval_X,eval_lineRestriction_real]
  have heq : (fun i => t*((1/t)*s+(b+(1/t) • x) i))=(fun i => s+(x+t • b) i) := by
    funext i
    simp only [Pi.add_apply,Pi.smul_apply,smul_eq_mul]
    field_simp
    ring
  have h := homogeneous_eval_real_scale p N hp t (fun i => (1/t)*s+(b+(1/t) • x) i)
  rw [heq] at h
  exact h

theorem smoothed_line_affine_normalization (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (x b : Fin n → ℝ) (ε t : ℝ) (ht : t≠0) :
    smoothedLineRestriction p N ε (x+t • b)=Polynomial.C (t^N)*
      (smoothedLineRestriction p N (ε/t) (b+(1/t) • x)).comp (Polynomial.C (1/t)*Polynomial.X) := by
  unfold smoothedLineRestriction
  rw [homogeneous_line_affine_normalization p N hp x b t ht,nuij_iterate_constant_comp_scale]
  simp only [div_eq_mul_inv,one_div,one_mul]

end CoefficientStability
