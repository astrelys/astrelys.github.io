import CoefficientStability.LocalQuadraticExpansion

noncomputable section
open scoped BigOperators Matrix.Norms.Elementwise Topology
namespace CoefficientStability
variable {n : ℕ}

def sourceLocalCurvature (t : Fin n → ℝ) : ℝ := sourceHessianFactor t*scalarHessianLambda t/(n : ℝ)^2

theorem sourceLocalCurvature_pos (t : Fin n → ℝ) (hn : 2≤n) (htpos : ∀ i,0<t i)
    (hl : 0<scalarHessianLambda t) : 0<sourceLocalCurvature t := by
  exact div_pos (mul_pos (sourceHessianFactor_pos t hn htpos) hl)
    (sq_pos_of_pos (by exact_mod_cast (by omega : 0<n)))

theorem sourceHessian_uniform_coercive (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ) (hA : ∑ i,A i=0) (hl : 0<scalarHessianLambda t) :
    sourceLocalCurvature t*complexTupleSq A≤sourceHessianCandidate t A := by
  apply sourceHessianCandidate_coercive t A (n : ℝ) hn ht htpos _ hA hl
  intro i
  rw [← ht]
  exact Finset.single_le_sum (fun j hj => (htpos j).le) (Finset.mem_univ i)

theorem paper_local_quadratic_growth (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : 0<scalarHessianLambda t) :
    ∃ a r : ℝ,0<a ∧ 0<r ∧ ∀ A : Fin n → Matrix (Fin n) (Fin n) ℂ,
      (∀ i,(A i).IsHermitian) → (∀ i,Matrix.trace (A i)=0) → (∑ i,A i)=0 → ‖A‖<r →
      a*complexTupleSq A≤hermitianMixedObjective (complexReferenceTuple t+A)-
        ((n.factorial : ℝ)/(n : ℝ)^n*∏ i,t i) := by
  obtain ⟨C,e,hC,he,hbound⟩ := actual_cubic_remainder_bound (complexReferenceTuple t)
  let m := sourceLocalCurvature t
  have hm : 0<m := sourceLocalCurvature_pos t hn htpos hl
  refine ⟨m/4,min e (m/(4*C)),by positivity,lt_min he (by positivity),?_⟩
  intro A hHerm htrace hsum hsmall
  have hAe : ‖A‖<e := lt_of_lt_of_le hsmall (min_le_left _ _)
  have hAm : ‖A‖<m/(4*C) := lt_of_lt_of_le hsmall (min_le_right _ _)
  have hcA : C*‖A‖≤m/4 := by
    have h := (lt_div_iff₀ (by positivity : 0<4*C)).mp hAm
    nlinarith
  have hres := hbound A hAe
  have hrest : ‖complexMixedDiscriminant (complexReferenceTuple t+A)-
      (actualMixedSeries (complexReferenceTuple t)).partialSum 3 A‖≤(m/4)*complexTupleSq A := by
    apply le_trans hres
    calc
      C*‖A‖^3=(C*‖A‖)*‖A‖^2 := by ring
      _ ≤ (m/4)*‖A‖^2 := mul_le_mul_of_nonneg_right hcA (sq_nonneg _)
      _ ≤ (m/4)*complexTupleSq A := mul_le_mul_of_nonneg_left (tuple_sq_norm_le_frobenius A) (by positivity)
  have hre := Complex.abs_re_le_norm (complexMixedDiscriminant (complexReferenceTuple t+A)-
      (actualMixedSeries (complexReferenceTuple t)).partialSum 3 A)
  have hneg := neg_le_abs (complexMixedDiscriminant (complexReferenceTuple t+A)-
      (actualMixedSeries (complexReferenceTuple t)).partialSum 3 A).re
  have hquad := sourceHessian_uniform_coercive t hn ht htpos A hsum hl
  have hpoly := scalar_series_partialSum_three_real t hn htpos A htrace hHerm
  have hnorm := referenceObjective_source_normalization t (by omega)
  simp only [Complex.sub_re] at hre hneg
  rw [hpoly] at hre hneg
  change _≤hermitianMixedObjective (complexReferenceTuple t+A)-_ 
  rw [← hnorm]
  change m*complexTupleSq A≤sourceHessianCandidate t A at hquad
  change _≤_ at hrest
  unfold hermitianMixedObjective at *
  linarith

end CoefficientStability
