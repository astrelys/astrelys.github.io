import CoefficientStability.ScalarHessianCriterion
import Mathlib.LinearAlgebra.QuadraticForm.Signature
import Mathlib.LinearAlgebra.Dual.Lemmas

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def marginalDot (t : Fin n → ℝ) : (Fin n → ℝ) →ₗ[ℝ] ℝ where
  toFun z := ∑ i,t i*z i
  map_add' x y := by simp [mul_add,Finset.sum_add_distrib]
  map_smul' a z := by simp [Finset.mul_sum];congr 1;funext i;ring

def scalarTangent (t : Fin n → ℝ) : Submodule ℝ (Fin n → ℝ) := (marginalDot t).ker

def tangentSum (t : Fin n → ℝ) : scalarTangent t →ₗ[ℝ] ℝ :=
  (marginalDot (fun _ => 1)).comp (scalarTangent t).subtype

def scalarTangentQuadratic (t : Fin n → ℝ) : QuadraticForm ℝ (scalarTangent t) :=
  ((QuadraticMap.weightedSumSquares ℝ (fun _ : Fin n => (1 : ℝ)))-
    QuadraticMap.sq.comp (marginalDot (fun _ => 1))).restrict (scalarTangent t)

theorem scalarTangentQuadratic_apply (t : Fin n → ℝ) (z : scalarTangent t) :
    scalarTangentQuadratic t z=scalarHessianForm z.val := by
  simp [scalarTangentQuadratic,QuadraticMap.weightedSumSquares_apply,
    QuadraticMap.restrict_apply,QuadraticMap.comp_apply,QuadraticMap.sq,
    marginalDot,scalarHessianForm,pow_two]

theorem marginalDot_ne_zero (t : Fin n → ℝ) (hn : 0<n) (ht : ∑ i,t i=n) :
    marginalDot t≠0 := by
  intro h
  have he := congrArg (fun f : (Fin n → ℝ) →ₗ[ℝ] ℝ => f (fun _ => 1)) h
  have hn' : (0 : ℝ)<n := by exact_mod_cast hn
  simp [marginalDot,ht] at he
  linarith

theorem scalarTangent_finrank (t : Fin n → ℝ) (hn : 0<n) (ht : ∑ i,t i=n) :
    Module.finrank ℝ (scalarTangent t)=n-1 := by
  have h := Module.Dual.finrank_ker_add_one_of_ne_zero (marginalDot_ne_zero t hn ht)
  simp only [Module.finrank_pi,Module.finrank_self,Finset.sum_const,
    Finset.card_univ,Fintype.card_fin,smul_eq_mul,mul_one] at h
  change Module.finrank ℝ (scalarTangent t)+1=n at h
  omega

def exceptionalTangent (t : Fin n → ℝ) (hn : 0<n) (ht : ∑ i,t i=n) : scalarTangent t :=
  ⟨projectedOnes t,projectedOnes_dot_t t hn ht⟩

theorem exceptionalTangent_ne_zero (t : Fin n → ℝ) (hn : 0<n)
    (ht : ∑ i,t i=n) (hl : scalarHessianLambda t<1) : exceptionalTangent t hn ht≠0 := by
  intro hz
  have he := projectedOnes_normSq t hn ht
  have hv : projectedOnes t=0 := congrArg Subtype.val hz
  rw [hv] at he
  simp at he
  linarith

theorem tangentSum_exceptional (t : Fin n → ℝ) (hn : 0<n) (ht : ∑ i,t i=n) :
    tangentSum t (exceptionalTangent t hn ht)=1-scalarHessianLambda t := by
  simpa [tangentSum,marginalDot,exceptionalTangent] using projectedOnes_sum t ht

theorem tangentSum_ne_zero (t : Fin n → ℝ) (hn : 0<n)
    (ht : ∑ i,t i=n) (hl : scalarHessianLambda t<1) : tangentSum t≠0 := by
  intro h
  have he := tangentSum_exceptional t hn ht
  rw [h] at he
  simp at he
  linarith

theorem scalarUnitSubspace_finrank (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (hl : scalarHessianLambda t<1) :
    Module.finrank ℝ (tangentSum t).ker=n-2 := by
  have h := Module.Dual.finrank_ker_add_one_of_ne_zero
    (tangentSum_ne_zero t (by omega) ht hl)
  rw [scalarTangent_finrank t (by omega) ht] at h
  omega

theorem scalarUnitSubspace_positive (t : Fin n → ℝ) :
    ((scalarTangentQuadratic t).restrict (tangentSum t).ker).PosDef := by
  intro z hz
  rw [QuadraticMap.restrict_apply,scalarTangentQuadratic_apply]
  have hs : (∑ i,(z.val.val i))=0 := by simpa [tangentSum,marginalDot] using z.property
  unfold scalarHessianForm
  rw [hs]
  simp only [zero_pow (by decide : 2≠0),sub_zero]
  apply sumSquares_pos_of_ne_zero
  intro he
  apply hz
  apply Subtype.ext
  exact Subtype.ext he

theorem scalarTangentQuadratic_exceptional (t : Fin n → ℝ) (hn : 0<n)
    (ht : ∑ i,t i=n) :
    scalarTangentQuadratic t (exceptionalTangent t hn ht)=
      scalarHessianLambda t*(1-scalarHessianLambda t) := by
  rw [scalarTangentQuadratic_apply]
  exact scalarHessianForm_projectedOnes t hn ht

theorem scalarExceptional_nonpositive (t : Fin n → ℝ) (hn : 0<n)
    (ht : ∑ i,t i=n) (hl : scalarHessianLambda t≤0) :
    ∀ z ∈ Submodule.span ℝ {exceptionalTangent t hn ht},scalarTangentQuadratic t z≤0 := by
  intro z hz
  obtain ⟨a,rfl⟩ := Submodule.mem_span_singleton.mp hz
  rw [QuadraticMap.map_smul,scalarTangentQuadratic_exceptional]
  exact smul_nonpos_of_nonneg_of_nonpos (mul_self_nonneg a)
    (mul_nonpos_of_nonpos_of_nonneg hl (by linarith))

theorem scalarExceptional_negative (t : Fin n → ℝ) (hn : 0<n)
    (ht : ∑ i,t i=n) (hl : scalarHessianLambda t<0) :
    ((-(scalarTangentQuadratic t)).restrict
      (Submodule.span ℝ {exceptionalTangent t hn ht})).PosDef := by
  intro z hz
  obtain ⟨a,ha⟩ := Submodule.mem_span_singleton.mp z.property
  have ha0 : a≠0 := by
    intro he
    apply hz
    apply Subtype.ext
    simpa [he] using ha.symm
  change 0< -(scalarTangentQuadratic t z.val)
  rw [← ha,QuadraticMap.map_smul,scalarTangentQuadratic_exceptional]
  have hq : scalarHessianLambda t*(1-scalarHessianLambda t)<0 :=
    mul_neg_of_neg_of_pos hl (by linarith)
  exact neg_pos.mpr (smul_neg_of_pos_of_neg (mul_self_pos.mpr ha0) hq)

theorem scalarUnitSubspace_nonpositive_neg (t : Fin n → ℝ) :
    ∀ z ∈ (tangentSum t).ker,(-(scalarTangentQuadratic t)) z≤0 := by
  intro z hz
  change -(scalarTangentQuadratic t z)≤0
  rw [scalarTangentQuadratic_apply]
  have hs : (∑ i,z.val i)=0 := by simpa [tangentSum,marginalDot] using hz
  unfold scalarHessianForm
  rw [hs]
  simp only [zero_pow (by decide : 2≠0),sub_zero,neg_nonpos]
  exact Finset.sum_nonneg (fun _ _ => sq_nonneg _)

theorem scalarHessian_inertia_nonpositive (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (hl : scalarHessianLambda t≤0) :
    sigPos (scalarTangentQuadratic t)=n-2 ∧
    sigNeg (scalarTangentQuadratic t)=(if scalarHessianLambda t<0 then 1 else 0) ∧
    Module.finrank ℝ (scalarTangentQuadratic t).radical=
      (if scalarHessianLambda t=0 then 1 else 0) := by
  have hlt : scalarHessianLambda t<1 := by linarith
  have hdim := scalarTangent_finrank t (by omega) ht
  have hunit := scalarUnitSubspace_finrank t hn ht hlt
  have hvdim : Module.finrank ℝ (Submodule.span ℝ {exceptionalTangent t (by omega) ht})=1 :=
    finrank_span_singleton (exceptionalTangent_ne_zero t (by omega) ht hlt)
  have hp := le_sigPos_of_posDef (scalarTangentQuadratic t) (scalarUnitSubspace_positive t)
  rw [hunit] at hp
  have hpupper := QuadraticForm.sigPos_add_finrank_le_of_nonpos
    (scalarExceptional_nonpositive t (by omega) ht hl)
  rw [hvdim,hdim] at hpupper
  have hnegupper := QuadraticForm.sigPos_add_finrank_le_of_nonpos
    (scalarUnitSubspace_nonpositive_neg t)
  rw [hunit,hdim,sigPos_neg] at hnegupper
  have hidentity := QuadraticForm.sigPos_add_sigNeg_add_radical (Q := scalarTangentQuadratic t)
  rw [hdim] at hidentity
  have hpval : sigPos (scalarTangentQuadratic t)=n-2 := by omega
  refine ⟨hpval,?_,?_⟩
  · by_cases hneg : scalarHessianLambda t<0
    · have hm := le_sigNeg_of_negDef (scalarTangentQuadratic t) (scalarExceptional_negative t (by omega) ht hneg)
      rw [hvdim] at hm
      simp only [hneg,ite_true]
      omega
    · have he : scalarHessianLambda t=0 := by linarith
      have hnonneg : ∀ z : scalarTangent t,0≤scalarTangentQuadratic t z := by
        intro z
        rw [scalarTangentQuadratic_apply]
        have h := scalarHessianForm_lower t z.val (by omega) ht z.property
        simpa only [he,zero_mul] using h
      have hm := QuadraticForm.sigPos_add_finrank_le_of_nonpos
        (Q := -(scalarTangentQuadratic t)) (V := ⊤) (fun z _ => neg_nonpos.mpr (hnonneg z))
      rw [finrank_top,hdim,sigPos_neg] at hm
      simp only [hneg,ite_false]
      omega
  · by_cases hneg : scalarHessianLambda t<0
    · have hm := le_sigNeg_of_negDef (scalarTangentQuadratic t) (scalarExceptional_negative t (by omega) ht hneg)
      rw [hvdim] at hm
      have he : scalarHessianLambda t≠0 := ne_of_lt hneg
      simp only [he,ite_false]
      omega
    · have he : scalarHessianLambda t=0 := by linarith
      have hnonneg : ∀ z : scalarTangent t,0≤scalarTangentQuadratic t z := by
        intro z
        rw [scalarTangentQuadratic_apply]
        have h := scalarHessianForm_lower t z.val (by omega) ht z.property
        simpa only [he,zero_mul] using h
      have hm := QuadraticForm.sigPos_add_finrank_le_of_nonpos
        (Q := -(scalarTangentQuadratic t)) (V := ⊤) (fun z _ => neg_nonpos.mpr (hnonneg z))
      rw [finrank_top,hdim,sigPos_neg] at hm
      simp only [he,ite_true]
      omega

theorem scalarHessian_inertia_positive (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (hl : 0<scalarHessianLambda t) :
    sigPos (scalarTangentQuadratic t)=n-1 ∧ sigNeg (scalarTangentQuadratic t)=0 ∧
    Module.finrank ℝ (scalarTangentQuadratic t).radical=0 := by
  have hdim := scalarTangent_finrank t (by omega) ht
  have hp : ((scalarTangentQuadratic t).restrict ⊤).PosDef := by
    intro z hz
    rw [QuadraticMap.restrict_apply,scalarTangentQuadratic_apply]
    apply (scalarHessian_positive_iff t (by omega) ht).mpr hl z.val.val z.val.property
    intro he
    apply hz
    exact Subtype.ext (Subtype.ext he)
  have hpl := le_sigPos_of_posDef (scalarTangentQuadratic t) hp
  rw [finrank_top,hdim] at hpl
  have hpu := sigPos_le_finrank (scalarTangentQuadratic t)
  rw [hdim] at hpu
  have hi := QuadraticForm.sigPos_add_sigNeg_add_radical (Q := scalarTangentQuadratic t)
  rw [hdim] at hi
  omega

end CoefficientStability
