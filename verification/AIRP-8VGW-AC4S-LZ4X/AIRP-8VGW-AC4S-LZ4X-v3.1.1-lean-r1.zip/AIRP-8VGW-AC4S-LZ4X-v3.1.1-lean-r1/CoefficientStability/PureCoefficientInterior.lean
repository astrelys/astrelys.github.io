import CoefficientStability.CapacityEtaUpper
import CoefficientStability.StablePermutation

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability

theorem reduced_variable_capacity_original_dimension (n : ℕ) (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p) (hc : ∀ g,0≤p.coeff g)
    (i : Fin n) (hdegree : p.degreeOf i≤n-1) :
    sourceVn n*(capacityG (n-1)/capacityG n)*multivariatePositiveCapacity p≤p.coeff (squarefreeExponent n) := by
  cases n with
  | zero => exact Fin.elim0 i
  | succ n =>
    simpa only [Nat.add_sub_cancel,mul_div_assoc] using
      paper_reduced_variable_degree_capacity_lower p hp hs hc i hdegree

theorem homogeneous_zero_pure_degree_drop (n : ℕ) (hn : 0<n)
    (p : MvPolynomial (Fin n) ℝ) (hp : p.IsHomogeneous n) (i : Fin n)
    (hzero : p.coeff (Finsupp.single i n)=0) : p.degreeOf i≤n-1 := by
  classical
  apply MvPolynomial.degreeOf_le_iff.mpr
  intro g hg
  have hmass := homogeneous_mass p n hp g hg
  have hgi : g i≤n := by
    exact (Finset.single_le_sum (fun j hj => Nat.zero_le (g j)) (Finset.mem_univ i)).trans_eq hmass
  by_contra hbad
  have heqi : g i=n := by omega
  have herase : (∑ j∈Finset.univ.erase i,g j)=0 := by
    have h := Finset.sum_erase_add (Finset.univ : Finset (Fin n)) (fun j => g j) (Finset.mem_univ i)
    rw [hmass,heqi] at h
    omega
  have heqg : g=Finsupp.single i n := by
    ext j
    by_cases hji : j=i
    · subst j
      simpa using heqi
    · have hle := Finset.single_le_sum (fun k hk => Nat.zero_le (g k))
        (Finset.mem_erase.mpr ⟨hji,Finset.mem_univ j⟩)
      rw [herase] at hle
      simp only [Finsupp.single_eq_of_ne hji]
      exact Nat.eq_zero_of_le_zero hle
  have hne := MvPolynomial.mem_support_iff.mp hg
  rw [heqg,hzero] at hne
  exact hne rfl

theorem balanced_nearminimal_pure_coeff_pos (n : ℕ) (hn : 3≤n)
    (p : MvPolynomial (Fin n) ℝ) (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=1)
    (hL : p.coeff (squarefreeExponent n)≤sourceVn n*(1+capacityEta n/2)) :
    ∀ i,0<p.coeff (Finsupp.single i n) := by
  intro i
  have hc := normalized_homogeneous_stable_coeff_nonneg p n hp hs hnorm
  have hcap := paper_balanced_capacity_one p hc hnorm hgrad
  by_contra hbad
  have hz : p.coeff (Finsupp.single i n)=0 := le_antisymm (le_of_not_gt hbad) (hc _)
  have hd := homogeneous_zero_pure_degree_drop n (by omega) p hp i hz
  have hpen := reduced_variable_capacity_original_dimension n p hp hs hc i hd
  rw [hcap,mul_one] at hpen
  have hratio : capacityG (n-1)/capacityG n=capacityEta n+1 := by rw [capacityEta]; ring
  rw [hratio] at hpen
  have hV := sourceVn_pos (by omega : 0<n)
  have hη := capacityEta_pos n hn
  nlinarith

end CoefficientStability
