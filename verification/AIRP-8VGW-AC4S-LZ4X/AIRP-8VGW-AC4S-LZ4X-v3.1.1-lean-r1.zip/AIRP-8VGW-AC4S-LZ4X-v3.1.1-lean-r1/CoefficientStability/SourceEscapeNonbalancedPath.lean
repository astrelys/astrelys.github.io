import CoefficientStability.SourceEscapeGateRadial

noncomputable section
open scoped BigOperators Topology unitInterval
namespace CoefficientStability
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

def sourceEscapeStep (a b : ℝ) : ℝ := (sourceEscapeD a b-sourceEscapeV a b)/2

def sourceEscapeNonbalancedCurve (a b : ℝ) : SourceEscapeCurve :=
  sourceEscapePolyline (sourceEscapeCenter a b) (sourceEscapeGate a b (sourceEscapeV a b))
    (sourceEscapeGate a b (sourceEscapeV a b)+sourceEscapeStep a b • sourceEscapeFlatDirection)

theorem source_escape_nonbalanced_endpoint_data (a b : ℝ) (ha : 0 < a) (hb : 0 < b)
    (hs : a+2*b=3) (hab : b/4 ≤ a) (hne : a ≠ b) :
    sourceEscapeGate a b (sourceEscapeV a b) ∈ sourceTransportationPolytope (sourceEscapeTraces a b) ∧
    sourceEscapeGate a b (sourceEscapeV a b)+sourceEscapeStep a b • sourceEscapeFlatDirection ∈
      sourceTransportationPolytope (sourceEscapeTraces a b) ∧
    sourceEscapeQ a b < sourceEscapeQuadratic a b
      (sourceEscapeGate a b (sourceEscapeV a b)+sourceEscapeStep a b • sourceEscapeFlatDirection-sourceEscapeCenter a b) := by
  have hv := source_escape_v_properties a b hb hab
  have hvd := source_escape_v_lt_d_of_unbalanced a b ha hb hab hne
  have hz : 0 < sourceEscapeStep a b := by unfold sourceEscapeStep;linarith
  have hsum : 0 ≤ sourceEscapeV a b+sourceEscapeStep a b := add_nonneg hv.1 hz.le
  have hle : sourceEscapeV a b+sourceEscapeStep a b ≤ sourceEscapeD a b := by unfold sourceEscapeStep;linarith
  have hS := source_escape_gate_flat_feasible a b (sourceEscapeV a b) 0 hb.le hs
    (by simpa only [add_zero,abs_of_nonneg hv.1] using hvd.le)
  simp only [zero_smul,add_zero] at hS
  have hE := source_escape_gate_flat_feasible a b (sourceEscapeV a b) (sourceEscapeStep a b) hb.le hs
    (by rw [abs_of_nonneg hsum];exact hle)
  refine ⟨hS,hE,?_⟩
  have he : sourceEscapeGate a b (sourceEscapeV a b)+sourceEscapeStep a b • sourceEscapeFlatDirection-sourceEscapeCenter a b=
      sourceEscapeGate a b (sourceEscapeV a b)-sourceEscapeCenter a b+sourceEscapeStep a b • sourceEscapeFlatDirection := by abel
  rw [he,source_escape_gate_flat_quadratic_increment,source_escape_gate_quadratic a b (sourceEscapeV a b) hs hv.2]
  have h1 : 0 ≤ (4*b*sourceEscapeV a b/3)*sourceEscapeStep a b :=
    mul_nonneg (div_nonneg (mul_nonneg (mul_nonneg (by norm_num) hb.le) hv.1) (by norm_num)) hz.le
  have h2 : 0 < (2*b/3)*(sourceEscapeStep a b)^2 := mul_pos (by positivity) (sq_pos_of_pos hz)
  linarith

theorem source_escape_nonbalanced_curve_admissible (a b : ℝ) (ha : 0 < a) (hb : 0 < b)
    (hs : a+2*b=3) (hab : b/4 ≤ a) (hne : a ≠ b) :
    sourceEscapeAdmissible a b (sourceEscapeNonbalancedCurve a b) := by
  obtain ⟨hS,hE,hQ⟩ := source_escape_nonbalanced_endpoint_data a b ha hb hs hab hne
  refine ⟨by simp [sourceEscapeNonbalancedCurve],?_,?_⟩
  · apply source_escape_polyline_property
    · exact source_transportation_actual_segment_feasible _ _ _ (source_escape_center_feasible a b ha hb hs) hS
    · exact source_transportation_actual_segment_feasible _ _ _ hS hE
  · simpa only [sourceEscapeNonbalancedCurve,source_escape_polyline_one] using hQ

theorem source_escape_nonbalanced_curve_height_upper (a b : ℝ) (ha : 0 < a) (hb : 0 < b)
    (hs : a+2*b=3) (hab : b/4 ≤ a) :
    sourceEscapeCurveHeight a b (sourceEscapeNonbalancedCurve a b) ≤ sourceEscapeDelta a b := by
  apply source_escape_curve_height_le
  unfold sourceEscapeNonbalancedCurve
  refine source_escape_polyline_property _ _ _ (fun X => sourceEscapeExcess a b X ≤ sourceEscapeDelta a b) ?_ ?_
  · exact source_escape_gate_actual_segment_bound a b (sourceEscapeV a b) ha hb hs
      (source_escape_v_properties a b hb hab).2
  · intro u
    exact (source_escape_gate_actual_flat_segment_excess a b (sourceEscapeV a b) (sourceEscapeStep a b) hs u).le

theorem source_escape_nonbalanced_actual_attainment (a b : ℝ) (ha : 0 < a) (hb : 0 < b)
    (hs : a+2*b=3) (hab : b/4 ≤ a) (hne : a ≠ b) :
    sourceEscapeAdmissible a b (sourceEscapeNonbalancedCurve a b) ∧
    sourceEscapeCurveHeight a b (sourceEscapeNonbalancedCurve a b)=sourceEscapeDelta a b ∧
    sourceEscapeBarrier a b=sourceEscapeDelta a b := by
  have hγ := source_escape_nonbalanced_curve_admissible a b ha hb hs hab hne
  have hH : sourceEscapeCurveHeight a b (sourceEscapeNonbalancedCurve a b)=sourceEscapeDelta a b :=
    le_antisymm (source_escape_nonbalanced_curve_height_upper a b ha hb hs hab)
      (source_escape_every_curve_height_lower a b ha hb hs _ hγ)
  refine ⟨hγ,hH,le_antisymm ?_ ?_⟩
  · have h := source_escape_barrier_le_curve a b ha hb hs _ hγ
    rwa [hH] at h
  · exact source_escape_barrier_lower a b ha hb hs ⟨_,hγ⟩

end CoefficientStability
