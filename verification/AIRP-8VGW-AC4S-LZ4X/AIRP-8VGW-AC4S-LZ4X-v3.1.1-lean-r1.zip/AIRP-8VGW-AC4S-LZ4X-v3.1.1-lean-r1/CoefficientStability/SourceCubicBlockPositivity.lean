import CoefficientStability.SourceCubicBlockBasics

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 2600000
set_option backward.isDefEq.respectTransparency false

def sourceTwoCentered (b : ℝ) (V : Matrix (Fin 2) (Fin 2) ℂ) : Matrix (Fin 2) (Fin 2) ℂ :=
  ((b : ℂ)/2) • 1+V

theorem source_two_centered_hermitian (b : ℝ) (V : Matrix (Fin 2) (Fin 2) ℂ) (hV : V.IsHermitian) :
    (sourceTwoCentered b V).IsHermitian := by
  exact (Matrix.isHermitian_one.smul (by simp [IsSelfAdjoint])).add hV

theorem source_two_centered_trace (b : ℝ) (V : Matrix (Fin 2) (Fin 2) ℂ) (ht : Matrix.trace V=0) :
    Matrix.trace (sourceTwoCentered b V)=(b : ℂ) := by
  norm_num [sourceTwoCentered,Matrix.trace_add,Matrix.trace_smul,Matrix.trace_one,ht] <;> ring

theorem source_two_centered_psd_iff (b : ℝ) (hb : 0 ≤ b) (V : Matrix (Fin 2) (Fin 2) ℂ)
    (hV : V.IsHermitian) (ht : Matrix.trace V=0) :
    (sourceTwoCentered b V).PosSemidef ↔ sourceTwoTraceQuadratic V ≤ b^2/4 := by
  rw [source_hermitian_two_psd_trace_det _ (source_two_centered_hermitian b V hV),source_two_centered_trace b V ht]
  change (0 ≤ (b : ℂ) ∧ 0 ≤ (((b : ℂ)/2) • 1+V).det) ↔ _
  rw [source_hermitian_two_centered_determinant b V hV ht]
  simp only [Complex.zero_le_real,hb,true_and]
  exact sub_nonneg

theorem source_two_centered_psd_of_quadratic_decrease (b : ℝ)
    (V W : Matrix (Fin 2) (Fin 2) ℂ) (hV : V.IsHermitian) (hW : W.IsHermitian)
    (htV : Matrix.trace V=0) (htW : Matrix.trace W=0)
    (hPSD : (sourceTwoCentered b V).PosSemidef) (hq : sourceTwoTraceQuadratic W ≤ sourceTwoTraceQuadratic V) :
    (sourceTwoCentered b W).PosSemidef := by
  have hbt := hPSD.trace_nonneg
  rw [source_two_centered_trace b V htV] at hbt
  have hb : 0 ≤ b := Complex.zero_le_real.mp hbt
  exact (source_two_centered_psd_iff b hb W hW htW).mpr
    (hq.trans ((source_two_centered_psd_iff b hb V hV htV).mp hPSD))

theorem source_two_trace_pair_symmetric (V W : Matrix (Fin 2) (Fin 2) ℂ) :
    sourceTwoTracePair V W=sourceTwoTracePair W V := by
  unfold sourceTwoTracePair
  rw [Matrix.trace_mul_comm]

theorem source_two_trace_quadratic_affine (V W : Matrix (Fin 2) (Fin 2) ℂ) (s : ℝ) :
    sourceTwoTraceQuadratic (V+s • W)=sourceTwoTraceQuadratic V+
      2*s*sourceTwoTracePair V W+s^2*sourceTwoTraceQuadratic W := by
  norm_num [sourceTwoTraceQuadratic,sourceTwoTracePair,Matrix.trace,Matrix.mul_apply,
    Matrix.add_apply,Matrix.smul_apply,Fin.sum_univ_succ,Complex.real_smul,Complex.add_re,Complex.mul_re]
  ring

theorem source_two_trace_quadratic_zero_iff (V : Matrix (Fin 2) (Fin 2) ℂ) (hV : V.IsHermitian) :
    sourceTwoTraceQuadratic V=0 ↔ V=0 := by
  constructor
  · intro hz
    by_contra hn
    have hp := source_two_trace_quadratic_positive V hV hn
    linarith
  · intro hz
    simp [hz,sourceTwoTraceQuadratic]

end CoefficientStability
