import CoefficientStability.MultinomialCoefficientLaw
import CoefficientStability.MixedDiagonalCoefficient

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def subsetExponent (s : Finset (Fin n)) : Fin n →₀ ℕ := ∑ i∈s,Finsupp.single i 1

theorem subsetExponent_apply (s : Finset (Fin n)) (i : Fin n) :
    subsetExponent s i=if i∈s then 1 else 0 := by
  classical
  simp [subsetExponent,Finsupp.single_apply]

theorem subsetExponent_sum (s : Finset (Fin n)) :
    (∑ i,subsetExponent s i)=s.card := by
  classical
  simp [subsetExponent_apply]

theorem subsetExponent_degree (s : Finset (Fin n)) :
    (subsetExponent s).sum (fun _ m => m)=s.card := by
  rw [Finsupp.sum_fintype _ _ (fun _ => rfl)]
  exact subsetExponent_sum s

theorem subsetExponent_multinomial (s : Finset (Fin n)) :
    (subsetExponent s).multinomial=s.card.factorial := by
  classical
  rw [Finsupp.multinomial_eq_of_support_subset (Finset.subset_univ _)]
  unfold Nat.multinomial
  rw [subsetExponent_sum]
  have hp : (∏ i,(subsetExponent s i).factorial)=1 := by
    apply Finset.prod_eq_one
    intro i hi
    rw [subsetExponent_apply]
    split_ifs <;> rfl
  rw [hp,Nat.div_one]

theorem subsetExponent_power_product (s : Finset (Fin n)) (a : Fin n → ℝ) :
    (subsetExponent s).prod (fun i m => a i^m)=∏ i∈s,a i := by
  classical
  rw [Finsupp.prod_fintype _ _ (fun _ => pow_zero _)]
  simp only [subsetExponent_apply]
  calc
    _ = ∏ i : Fin n,if i∈s then a i else 1 := by
      apply Finset.prod_congr rfl
      intro i hi
      by_cases h : i∈s <;> simp [h]
    _ = _ := by rw [← Finset.prod_filter];simp

theorem scalarLinear_squarefree_coefficient (t : Fin n → ℝ) (N : ℕ) (s : Finset (Fin n)) :
    ((scalarLinear t N)^s.card).coeff (subsetExponent s)=
      (s.card.factorial : ℝ)*(∏ i∈s,t i/(N : ℝ)) := by
  have h := MvPolynomial.coeff_linearCombination_X_pow_of_fintype
    (fun i => t i/(N : ℝ)) (subsetExponent s) s.card
  simp only [subsetExponent_degree,ite_true,subsetExponent_multinomial,subsetExponent_power_product] at h
  simpa only [scalarLinear,MvPolynomial.smul_eq_C_mul] using h

theorem scalarPower_squarefree_coefficient (t : Fin n → ℝ) :
    (scalarPower t n).coeff (squarefreeExponent n)=
      (n.factorial : ℝ)/(n : ℝ)^n*(∏ i,t i) := by
  have h := scalarLinear_squarefree_coefficient t n (Finset.univ : Finset (Fin n))
  have he : (scalarPower t n).coeff (squarefreeExponent n)=
      (n.factorial : ℝ)*(∏ i,t i/(n : ℝ)) := by
    simpa only [Finset.card_univ,Fintype.card_fin,subsetExponent,squarefreeExponent,scalarPower] using h
  rw [Finset.prod_div_distrib] at he
  simpa only [Finset.prod_const,Finset.card_univ,Fintype.card_fin,div_eq_mul_inv,
    mul_assoc,mul_left_comm,mul_comm] using he

end CoefficientStability
