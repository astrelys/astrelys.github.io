import CoefficientStability.CoordinateRestrictionDegree
import CoefficientStability.BalancedCapacity

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem multivariate_capacity_bddBelow (p : MvPolynomial (Fin n) ℝ)
    (hc : ∀ g,0≤p.coeff g) :
    BddBelow (Set.range (fun x : {x : Fin n → ℝ // ∀ i,0<x i} => MvPolynomial.eval x.val p/(∏ i,x.val i))) := by
  refine ⟨0,?_⟩
  rintro y ⟨x,rfl⟩
  change 0≤MvPolynomial.eval x.val p/(∏ i,x.val i)
  exact div_nonneg (nonnegative_coeff_eval_nonneg p hc x.val (fun i => (x.prop i).le))
    (Finset.prod_nonneg (fun i hi => (x.prop i).le))

theorem multivariate_capacity_nonneg (p : MvPolynomial (Fin n) ℝ)
    (hc : ∀ g,0≤p.coeff g) : 0≤multivariatePositiveCapacity p := by
  apply le_csInf
  · exact ⟨_,⟨⟨fun _ => 1,fun _ => by norm_num⟩,rfl⟩⟩
  · rintro y ⟨x,rfl⟩
    change 0≤MvPolynomial.eval x.val p/(∏ i,x.val i)
    exact div_nonneg (nonnegative_coeff_eval_nonneg p hc x.val (fun i => (x.prop i).le))
      (Finset.prod_nonneg (fun i hi => (x.prop i).le))

theorem dropLastPolynomial_eval (p : MvPolynomial (Fin (n+1)) ℝ) (x : Fin n → ℝ) :
    MvPolynomial.eval x (dropLastPolynomial p)=MvPolynomial.eval (Fin.lastCases 0 x) p := by
  classical
  change (MvPolynomial.eval x) (MvPolynomial.eval₂ _ _ p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c
    simp
  · funext j
    refine Fin.lastCases ?_ (fun k => ?_) j <;> simp

@[simp] theorem realCoordinateRestriction_C (x : Fin n → ℝ) (i : Fin n) (c : ℝ) :
    realCoordinateRestriction x i (MvPolynomial.C c)=Polynomial.C c := by simp [realCoordinateRestriction]

@[simp] theorem realCoordinateRestriction_X (x : Fin n → ℝ) (i j : Fin n) :
    realCoordinateRestriction x i (MvPolynomial.X j)=if j=i then Polynomial.X else Polynomial.C (x j) := by
  simp [realCoordinateRestriction]

theorem realCoordinateRestriction_partial (p : MvPolynomial (Fin n) ℝ)
    (x : Fin n → ℝ) (i : Fin n) :
    realCoordinateRestriction x i (pderiv i p)=(realCoordinateRestriction x i p).derivative := by
  classical
  induction p using MvPolynomial.induction_on with
  | C c => simp
  | add p q hp hq => simp only [map_add,hp,hq,Polynomial.derivative_add]
  | mul_X p k hp =>
    by_cases hki : k=i
    · subst k
      simp [pderiv_mul,pderiv_X,Pi.single_apply,map_add,map_mul,hp,Polynomial.derivative_mul] <;> ring
    · simp [pderiv_mul,pderiv_X,Pi.single_apply,hki,eq_comm,map_add,map_mul,hp,Polynomial.derivative_mul] <;> ring

theorem last_real_restriction_eval (p : MvPolynomial (Fin (n+1)) ℝ) (x : Fin n → ℝ) (z : ℝ) :
    (realCoordinateRestriction (Fin.lastCases 1 x) (Fin.last n) p).eval z=
      MvPolynomial.eval (Fin.lastCases z x) p := by
  rw [realCoordinateRestriction_eval]
  have he : Function.update (Fin.lastCases (1 : ℝ) x : Fin (n+1) → ℝ) (Fin.last n) z=
      (Fin.lastCases z x : Fin (n+1) → ℝ) := by
    funext j
    refine Fin.lastCases ?_ (fun k => ?_) j <;> simp
  rw [he]

theorem last_elimination_restriction_derivative (p : MvPolynomial (Fin (n+1)) ℝ) (x : Fin n → ℝ) :
    MvPolynomial.eval x (lastDerivativeElimination p)=
      (realCoordinateRestriction (Fin.lastCases 1 x) (Fin.last n) p).derivative.eval 0 := by
  rw [← realCoordinateRestriction_partial,last_real_restriction_eval]
  exact dropLastPolynomial_eval _ x

theorem multivariate_capacity_slice_lower (p : MvPolynomial (Fin (n+1)) ℝ)
    (hc : ∀ g,0≤p.coeff g) (x : Fin n → ℝ) (hx : ∀ j,0<x j) :
    multivariatePositiveCapacity p*(∏ j,x j)≤
      positiveDomainCapacity (realCoordinateRestriction (Fin.lastCases 1 x) (Fin.last n) p) := by
  apply le_csInf
  · exact ⟨_,⟨⟨1,by norm_num⟩,rfl⟩⟩
  · rintro y ⟨z,rfl⟩
    change multivariatePositiveCapacity p*(∏ j,x j)≤
      (realCoordinateRestriction (Fin.lastCases 1 x) (Fin.last n) p).eval z.val/z.val
    rw [last_real_restriction_eval]
    have hlegal : ∀ j : Fin (n+1),(0 : ℝ)<Fin.lastCases z.val x j := by
      intro j
      refine Fin.lastCases ?_ (fun k => ?_) j
      · simpa only [Fin.lastCases_last] using z.prop
      · simpa only [Fin.lastCases_castSucc] using hx k
    have hcap : multivariatePositiveCapacity p≤
        MvPolynomial.eval (Fin.lastCases z.val x) p/(∏ j,Fin.lastCases z.val x j) :=
      csInf_le (multivariate_capacity_bddBelow p hc) ⟨⟨_,hlegal⟩,rfl⟩
    have hprod : (∏ j : Fin (n+1),Fin.lastCases z.val x j)=(∏ j,x j)*z.val := by
      rw [Fin.prod_univ_castSucc]
      simp
    rw [hprod] at hcap
    have hX : 0<∏ j,x j := Finset.prod_pos (fun j hj => hx j)
    apply (le_div_iff₀ z.prop).mpr
    simpa only [mul_assoc] using (le_div_iff₀ (mul_pos hX z.prop)).mp hcap

theorem multivariate_capacity_derivative_elimination (p : MvPolynomial (Fin (n+1)) ℝ)
    (hs : UpperHalfPlaneZeroFree p) (hc : ∀ g,0≤p.coeff g) (K : ℕ)
    (hK : p.degreeOf (Fin.last n)≤K) :
    capacityG K*multivariatePositiveCapacity p≤multivariatePositiveCapacity (lastDerivativeElimination p) := by
  apply le_csInf
  · exact ⟨_,⟨⟨fun _ => 1,fun _ => by norm_num⟩,rfl⟩⟩
  · rintro y ⟨x,rfl⟩
    change capacityG K*multivariatePositiveCapacity p≤
      MvPolynomial.eval x.val (lastDerivativeElimination p)/(∏ j,x.val j)
    have hx : ∀ j,(0 : ℝ)<Fin.lastCases 1 x.val j := by
      intro j
      refine Fin.lastCases ?_ (fun k => ?_) j
      · norm_num
      · simpa only [Fin.lastCases_castSucc] using x.prop k
    have hdegree := (realCoordinateRestriction_degree_le p (Fin.lastCases 1 x.val) (Fin.last n)).trans hK
    have huni := positive_stable_coordinate_capacity_cutoff p hs hc _ hx (Fin.last n) K hdegree
    have hslice := multivariate_capacity_slice_lower p hc x.val x.prop
    have hbound := (mul_le_mul_of_nonneg_left hslice (capacityG_nonneg K)).trans huni
    rw [← last_elimination_restriction_derivative] at hbound
    apply (le_div_iff₀ (Finset.prod_pos (fun j hj => x.prop j))).mpr
    simpa only [mul_assoc] using hbound

end CoefficientStability
