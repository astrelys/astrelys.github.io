import CoefficientStability.SourceStableCubicRealZero

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

theorem source_affine_substitution_total_degree {m n : ℕ}
    (p : MvPolynomial (Fin m) ℝ) (N : ℕ) (hp : p.IsHomogeneous N)
    (f : Fin m → MvPolynomial (Fin n) ℝ) (hf : ∀ i,(f i).totalDegree ≤ 1) :
    (MvPolynomial.eval₂ MvPolynomial.C f p).totalDegree ≤ N := by
  classical
  conv_lhs => rw [p.as_sum]
  simp only [MvPolynomial.eval₂_sum]
  apply MvPolynomial.totalDegree_finsetSum_le
  intro g hg
  rw [MvPolynomial.eval₂_monomial]
  have hprod : g.prod (fun i k => f i^k)=∏ i,f i^g i := g.prod_fintype _ (by simp)
  rw [hprod]
  calc
    (MvPolynomial.C (p.coeff g)*(∏ i,f i^g i)).totalDegree ≤
      (MvPolynomial.C (p.coeff g)).totalDegree+(∏ i,f i^g i).totalDegree := MvPolynomial.totalDegree_mul _ _
    _=(∏ i,f i^g i).totalDegree := by simp
    _≤ ∑ i,(f i^g i).totalDegree := MvPolynomial.totalDegree_finsetProd _ _
    _≤ ∑ i,g i := by
      apply Finset.sum_le_sum
      intro i hi
      exact (MvPolynomial.totalDegree_pow _ _).trans (by simpa using Nat.mul_le_mul_left (g i) (hf i))
    _=N := homogeneous_mass p N hp g hg

theorem source_affine_restriction_degree_le {n : ℕ} (p : MvPolynomial (Fin n) ℝ)
    (x v : Fin n → ℝ) : (affineDirectionalRestriction p x v).natDegree ≤ p.totalDegree := by
  classical
  unfold affineDirectionalRestriction
  conv_lhs => rw [p.as_sum]
  simp only [MvPolynomial.eval₂_sum]
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro g hg
  rw [MvPolynomial.eval₂_monomial]
  have hprod : g.prod (fun i k => (Polynomial.C (v i)*Polynomial.X+Polynomial.C (x i))^k)=
      ∏ i,(Polynomial.C (v i)*Polynomial.X+Polynomial.C (x i))^g i := g.prod_fintype _ (by simp)
  rw [hprod]
  apply (Polynomial.natDegree_C_mul_le _ _).trans
  apply (Polynomial.natDegree_prod_le _ _).trans
  calc
    (∑ i,((Polynomial.C (v i)*Polynomial.X+Polynomial.C (x i))^g i).natDegree) ≤ ∑ i,g i := by
      apply Finset.sum_le_sum
      intro i hi
      apply Polynomial.natDegree_pow_le.trans
      have h := Polynomial.natDegree_add_le (Polynomial.C (v i)*Polynomial.X) (Polynomial.C (x i))
      have hlinear : (Polynomial.C (v i)*Polynomial.X+Polynomial.C (x i)).natDegree ≤ 1 := by
        apply h.trans
        apply max_le
        · exact (Polynomial.natDegree_C_mul_le _ _).trans (by simp)
        · simp
      simpa using Nat.mul_le_mul_left (g i) hlinear
    _≤ p.totalDegree := by
      have h := MvPolynomial.le_totalDegree hg
      rw [Finsupp.sum_fintype _ _ (by simp)] at h
      exact h

theorem source_stable_cubic_plane_actual_degree (p : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3) (hs : UpperHalfPlaneZeroFree p)
    (hn : MvPolynomial.eval (fun _ => 1) p=1) :
    (sourceCubicPlanePolynomial p).totalDegree=3 := by
  have hf (i : Fin 3) : (1+
      MvPolynomial.C (sourceCubicPlaneV i)*MvPolynomial.X (0 : Fin 2)+
      MvPolynomial.C (sourceCubicPlaneW i)*MvPolynomial.X (1 : Fin 2)).totalDegree ≤ 1 := by
    apply (MvPolynomial.totalDegree_add _ _).trans
    apply max_le
    · apply (MvPolynomial.totalDegree_add _ _).trans
      apply max_le
      · simp
      · apply (MvPolynomial.totalDegree_mul _ _).trans
        simp
    · apply (MvPolynomial.totalDegree_mul _ _).trans
      simp
  have hupper := source_affine_substitution_total_degree p 3 hp _ hf
  have hv : ∀ i,0 < sourceCubicPlaneV i := by
    intro i
    fin_cases i <;> norm_num [sourceCubicPlaneV]
  have hpos := source_stable_cubic_positive_orthant p hp hs hn sourceCubicPlaneV hv
  have hd := (positive_direction_degree_and_top p 3 hp (fun _ => 1) sourceCubicPlaneV hv (ne_of_gt hpos)).1
  have hline := source_cubic_plane_actual_line p (![1,0] : Fin 2 → ℝ)
  have he : (fun i => (![1,0] : Fin 2 → ℝ) 0*sourceCubicPlaneV i+
      (![1,0] : Fin 2 → ℝ) 1*sourceCubicPlaneW i)=sourceCubicPlaneV := by
    funext i
    simp
  rw [he] at hline
  have hlower := source_affine_restriction_degree_le (sourceCubicPlanePolynomial p) (fun _ => 0) (![1,0] : Fin 2 → ℝ)
  rw [hline,hd] at hlower
  exact Nat.le_antisymm hupper hlower

end CoefficientStability
