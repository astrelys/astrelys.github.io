import CoefficientStability.SourceNearBalancedCapacity

noncomputable section
namespace CoefficientStability

theorem nonnegative_base_bernoulli (n : ℕ) (x : ℝ) (hx : 0≤x) :
    1+(n : ℝ)*(x-1)≤x^n := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hmul := mul_le_mul_of_nonneg_left ih hx
    simp only [Nat.cast_add,Nat.cast_one,pow_succ]
    nlinarith [mul_nonneg (Nat.cast_nonneg n : 0≤(n : ℝ)) (sq_nonneg (x-1))]

theorem rankOne_two_factor_capacity_bernoulli (n : ℕ) (r d : ℝ)
    (hr0 : 0≤r) (hr1 : r≤1) (hd0 : 0≤d) (hd1 : d≤1) :
    1-(n : ℝ)*(r+d)≤(1-r)^n*(1-d)^n := by
  have h := nonnegative_base_bernoulli n ((1-r)*(1-d))
    (mul_nonneg (sub_nonneg.mpr hr1) (sub_nonneg.mpr hd1))
  rw [mul_pow] at h
  nlinarith [mul_nonneg (mul_nonneg (Nat.cast_nonneg n : 0≤(n : ℝ)) hr0) hd0]

theorem rankOne_linear_capacity_error (n : ℕ) (hn : 1≤n) (s r d : ℝ)
    (hr : 0≤r) (hd : d≤2*s+4*(n : ℝ)*r) :
    1-2*(n : ℝ)*s-5*(n : ℝ)^2*r≤1-(n : ℝ)*(r+d) := by
  have hnr : 1≤(n : ℝ) := by exact_mod_cast hn
  have hmul := mul_le_mul_of_nonneg_left hd (Nat.cast_nonneg n : 0≤(n : ℝ))
  nlinarith [mul_nonneg (mul_nonneg (Nat.cast_nonneg n : 0≤(n : ℝ)) (sub_nonneg.mpr hnr)) hr]

end CoefficientStability
