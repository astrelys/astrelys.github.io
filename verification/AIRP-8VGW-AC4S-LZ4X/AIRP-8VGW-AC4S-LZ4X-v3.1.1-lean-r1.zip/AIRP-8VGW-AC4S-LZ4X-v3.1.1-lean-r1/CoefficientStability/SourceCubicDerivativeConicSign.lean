import CoefficientStability.SourceCubicActualDiscriminant

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000

theorem source_depressed_cubic_derivative_conic_sign (s q c : ℝ)
    (hs : 0≤s) (hq : q=3*s^2) (hd : 0≤4*q^3-27*c^2) :
    s^3-s*q+c≤0 := by
  have hc2 : c^2≤(2*s^3)^2 := by rw [hq] at hd; nlinarith only [hd]
  have hc := (le_abs_self c).trans (abs_le_of_sq_le_sq hc2 (by positivity))
  rw [hq]
  nlinarith only [hc]

def sourceConicToDepressedValue (X Y Z : ℝ) : Fin 3 → ℝ :=
  ![(X+Z)/(2*Real.sqrt 3),(X-Z)/2,Y]

theorem source_standard_conic_actual_nonpositive
    (p : MvPolynomial (Fin 3) ℝ) (C : ℝ → ℝ → ℝ)
    (hp : ∀ s x y : ℝ,MvPolynomial.eval (![s,x,y] : Fin 3 → ℝ) p=s^3-s*(x^2+y^2)+C x y)
    (hd : ∀ x y : ℝ,0≤4*(x^2+y^2)^3-27*(C x y)^2) (u v : ℝ) :
    MvPolynomial.eval (sourceConicToDepressedValue (u^2) (u*v) (v^2)) p≤0 := by
  have hr : 0<Real.sqrt 3 := Real.sqrt_pos.mpr (by norm_num)
  have hr2 : (Real.sqrt 3)^2=3 := Real.sq_sqrt (by norm_num)
  have hq : ((u^2-v^2)/2)^2+(u*v)^2=3*((u^2+v^2)/(2*Real.sqrt 3))^2 := by
    calc
      ((u^2-v^2)/2)^2+(u*v)^2=((u^2+v^2)/2)^2 := by ring
      _=(Real.sqrt 3)^2*((u^2+v^2)/(2*Real.sqrt 3))^2 := by
        field_simp [ne_of_gt hr]
      _=3*((u^2+v^2)/(2*Real.sqrt 3))^2 := by rw [hr2]
  change MvPolynomial.eval (![(u^2+v^2)/(2*Real.sqrt 3),(u^2-v^2)/2,u*v] : Fin 3 → ℝ) p≤0
  rw [hp]
  exact source_depressed_cubic_derivative_conic_sign _ _ _ (div_nonneg (by positivity) (by positivity)) hq (hd _ _)

end CoefficientStability
