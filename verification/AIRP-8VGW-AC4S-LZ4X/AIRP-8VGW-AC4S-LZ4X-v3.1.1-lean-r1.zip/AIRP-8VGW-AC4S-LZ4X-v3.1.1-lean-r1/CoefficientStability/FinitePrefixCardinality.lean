import CoefficientStability.FiniteTuplePrefixBridge

noncomputable section
namespace CoefficientStability
variable {n : ℕ}

theorem finite_prefix_coordinate_card (k : ℕ) (hk : k ≤ n) :
    (Finset.univ.filter (fun i : Fin n => i.val < k)).card=k := by
  classical
  calc
    _=(Finset.range k).card := by
      apply Finset.card_bij (fun i hi => i.val)
      · intro i hi
        exact Finset.mem_range.mpr (Finset.mem_filter.mp hi).2
      · intro i hi j hj heq
        exact Fin.ext heq
      · intro a ha
        have hak := Finset.mem_range.mp ha
        refine ⟨⟨a,lt_of_lt_of_le hak hk⟩,?_,rfl⟩
        simp [hak]
    _=k := Finset.card_range k

end CoefficientStability
