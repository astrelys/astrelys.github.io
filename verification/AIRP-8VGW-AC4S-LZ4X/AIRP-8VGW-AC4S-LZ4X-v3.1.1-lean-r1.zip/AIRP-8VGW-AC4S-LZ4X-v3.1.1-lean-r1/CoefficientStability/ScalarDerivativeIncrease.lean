import CoefficientStability.StrongRayCoercivity

noncomputable section
open scoped Topology
namespace CoefficientStability

theorem scalar_derivative_increase (d dd : ℝ → ℝ) (a b A : ℝ) (hab : a ≤ b)
    (hd : ∀ s, HasDerivAt d (dd s) s)
    (hA : ∀ s ∈ Set.Icc a b, A ≤ dd s) :
    A*(b-a) ≤ d b-d a := by
  have hg (s : ℝ) : HasDerivAt (fun z : ℝ => d z-A*z) (dd s-A) s := by
    have hl : HasDerivAt (fun z : ℝ => A*z) A s := by
      simpa only [id_eq,mul_one] using (hasDerivAt_id s).const_mul A
    exact (hd s).sub hl
  have hc : Continuous (fun z : ℝ => d z-A*z) :=
    continuous_iff_continuousAt.mpr (fun s => (hg s).continuousAt)
  have hm : MonotoneOn (fun z : ℝ => d z-A*z) (Set.Icc a b) :=
    monotoneOn_of_hasDerivWithinAt_nonneg (convex_Icc a b) hc.continuousOn
      (fun s hs => (hg s).hasDerivWithinAt)
      (fun s hs => sub_nonneg.mpr (hA s (interior_subset hs)))
  have h := hm ⟨le_rfl,hab⟩ ⟨hab,le_rfl⟩ hab
  linarith

theorem scalar_stationary_radius (d dd : ℝ → ℝ) (m r R : ℝ)
    (hm : 0 < m) (hr : 0 ≤ r) (hrm : r < m) (hR : 0 ≤ R)
    (hd : ∀ s, HasDerivAt d (dd s) s) (hend : d 1=0)
    (hstart : -r*R ≤ d 0)
    (hglobal : ∀ s ∈ Set.Icc (0 : ℝ) 1, 0 ≤ dd s)
    (hlocal : ∀ s ∈ Set.Icc (0 : ℝ) 1, s^2*R^2 ≤ 1 → m*R^2 ≤ dd s) :
    R < 1 ∧ R ≤ r/m := by
  have hRlt : R < 1 := by
    by_contra hh
    have hR1 : 1 ≤ R := le_of_not_gt hh
    have hRpos : 0 < R := by linarith
    have hb : 1/R ∈ Set.Icc (0 : ℝ) 1 :=
      ⟨by positivity,(div_le_one hRpos).mpr hR1⟩
    have hg := scalar_derivative_increase d dd 0 (1/R) (m*R^2) hb.1 hd (by
      intro s hs
      apply hlocal s ⟨hs.1,hs.2.trans hb.2⟩
      have hsR : s*R ≤ 1 := (le_div_iff₀ hRpos).mp hs.2
      nlinarith [mul_nonneg hs.1 hR])
    have hmono := scalar_derivative_increase d dd (1/R) 1 0 hb.2 hd
      (fun s hs => hglobal s ⟨hb.1.trans hs.1,hs.2⟩)
    have he : m*R^2*(1/R-0)=m*R := by field_simp;ring
    rw [he] at hg
    rw [hend] at hmono
    nlinarith [mul_pos (sub_pos.mpr hrm) hRpos]
  have hg := scalar_derivative_increase d dd 0 1 (m*R^2) (by norm_num) hd (by
    intro s hs
    apply hlocal s hs
    have hs2 : s^2 ≤ 1 := by nlinarith [hs.1,hs.2]
    have hR2 : R^2 ≤ 1 := by nlinarith
    exact (mul_le_mul_of_nonneg_right hs2 (sq_nonneg R)).trans (by simpa using hR2))
  norm_num only [sub_zero,mul_one,hend] at hg
  refine ⟨hRlt,?_⟩
  apply (le_div_iff₀ hm).mpr
  by_cases hz : R=0
  · rw [hz,zero_mul];exact hr
  · have hp : 0 < R := lt_of_le_of_ne hR (Ne.symm hz)
    by_contra hh
    have hgt : r < R*m := lt_of_not_ge hh
    nlinarith [mul_pos hp (sub_pos.mpr hgt)]

end CoefficientStability
