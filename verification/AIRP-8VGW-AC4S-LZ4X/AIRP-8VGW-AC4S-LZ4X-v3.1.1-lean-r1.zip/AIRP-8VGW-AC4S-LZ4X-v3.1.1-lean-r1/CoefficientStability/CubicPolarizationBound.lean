import CoefficientStability.DeficitSeminorm
import CoefficientStability.MultilinearPolarization

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
variable {n : ℕ}

theorem deficitSeminorm_zero (Q : Matrix (Fin n) (Fin n) ℝ) : deficitSeminorm Q 0=0 := by
  simp [deficitSeminorm,matrixQuadratic]

theorem deficitSeminorm_sum {ι : Type*} (Q : Matrix (Fin n) (Fin n) ℝ) (hQ : Q.PosSemidef)
    (s : Finset ι) (v : ι → Fin n → ℝ) : deficitSeminorm Q (∑ i∈s,v i)≤∑ i∈s,deficitSeminorm Q (v i) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [deficitSeminorm_zero]
  | @insert i s hi ih =>
    rw [Finset.sum_insert hi,Finset.sum_insert hi]
    exact (deficitSeminorm_triangle Q hQ _ _).trans (add_le_add (le_refl _) ih)

theorem cubic_polarization_unit_bound
    (T : MultilinearMap ℝ (fun _ : Fin 3 => Fin n → ℝ) ℝ)
    (Q : Matrix (Fin n) (Fin n) ℝ) (hQ : Q.PosSemidef) (C : ℝ) (hC : 0≤C)
    (hdiag : ∀ x,|T (fun _ => x)|≤C*deficitSeminorm Q x^3)
    (v : Fin 3 → Fin n → ℝ) (hv : ∀ j,deficitSeminorm Q (v j)≤1) :
    |symmetrizedMultilinear T v|≤(9/2 : ℝ)*C := by
  have hnorm (eps : Fin 3 → Bool) : deficitSeminorm Q (∑ j,realSign (eps j) • v j)≤3 := by
    have h := deficitSeminorm_sum Q hQ (Finset.univ : Finset (Fin 3)) (fun j => realSign (eps j) • v j)
    simp only [deficitSeminorm_smul Q hQ,realSign_abs,one_mul] at h
    have hs : (∑ j,deficitSeminorm Q (v j))≤3 := by
      have he := Finset.sum_le_sum (fun j (_ : j∈(Finset.univ : Finset (Fin 3))) => hv j)
      simpa using he
    exact h.trans hs
  have hb (eps : Fin 3 → Bool) : |T (fun _ => ∑ j,realSign (eps j) • v j)|≤27*C := by
    have h := hdiag (∑ j,realSign (eps j) • v j)
    have hp := pow_le_pow_left₀ (Real.sqrt_nonneg _) (hnorm eps) 3
    have hm := mul_le_mul_of_nonneg_left hp hC
    norm_num at hm
    exact h.trans (by simpa only [deficitSeminorm,mul_comm] using hm)
  have hsum : |∑ eps : Fin 3 → Bool,(∏ j,realSign (eps j))*T (fun _ => ∑ j,realSign (eps j) • v j)|≤8*(27*C) := by
    calc
      _ ≤ ∑ eps : Fin 3 → Bool,|(∏ j,realSign (eps j))*T (fun _ => ∑ j,realSign (eps j) • v j)| := Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ _eps : Fin 3 → Bool,27*C := by
        apply Finset.sum_le_sum
        intro eps heps
        simpa only [abs_mul,Finset.abs_prod,realSign_abs,Finset.prod_const_one,one_mul] using hb eps
      _ = _ := by norm_num [Fintype.card_fun]
  rw [symmetrizedMultilinear_polarization,abs_div]
  norm_num
  nlinarith

theorem cubic_polarization_scaled_bound
    (T : MultilinearMap ℝ (fun _ : Fin 3 => Fin n → ℝ) ℝ)
    (Q : Matrix (Fin n) (Fin n) ℝ) (hQ : Q.PosSemidef) (C : ℝ) (hC : 0≤C)
    (hdiag : ∀ x,|T (fun _ => x)|≤C*deficitSeminorm Q x^3)
    (v : Fin 3 → Fin n → ℝ) (a : Fin 3 → ℝ) (ha : ∀ j,0<a j)
    (hv : ∀ j,deficitSeminorm Q (v j)≤a j) :
    |symmetrizedMultilinear T v|≤((9/2 : ℝ)*C)*(∏ j,a j) := by
  let w := fun j => (a j)⁻¹ • v j
  have hw : ∀ j,deficitSeminorm Q (w j)≤1 := by
    intro j
    dsimp [w]
    rw [deficitSeminorm_smul Q hQ,abs_of_pos (inv_pos.mpr (ha j))]
    have h := mul_le_mul_of_nonneg_left (hv j) (inv_nonneg.mpr (ha j).le)
    simpa only [inv_mul_cancel₀ (ne_of_gt (ha j))] using h
  have hb := cubic_polarization_unit_bound T Q hQ C hC hdiag w hw
  have hvw : (fun j => a j • w j)=v := by
    funext j
    dsimp [w]
    rw [smul_smul,mul_inv_cancel₀ (ne_of_gt (ha j)),one_smul]
  have he := (symmetrizedMultilinear T).map_smul_univ a w
  rw [hvw] at he
  rw [he]
  simp only [smul_eq_mul]
  rw [abs_mul,abs_of_pos (Finset.prod_pos (fun j _ => ha j))]
  have hprod : 0≤∏ j,a j := Finset.prod_nonneg (fun j _ => (ha j).le)
  have hm := mul_le_mul_of_nonneg_left hb hprod
  nlinarith

theorem cubic_polarization_seminorm_bound
    (T : MultilinearMap ℝ (fun _ : Fin 3 => Fin n → ℝ) ℝ)
    (Q : Matrix (Fin n) (Fin n) ℝ) (hQ : Q.PosSemidef) (C : ℝ) (hC : 0≤C)
    (hdiag : ∀ x,|T (fun _ => x)|≤C*deficitSeminorm Q x^3)
    (v : Fin 3 → Fin n → ℝ) :
    |symmetrizedMultilinear T v|≤((9/2 : ℝ)*C)*(∏ j,deficitSeminorm Q (v j)) := by
  have hc : ContinuousAt (fun e : ℝ => ((9/2 : ℝ)*C)*(∏ j,(deficitSeminorm Q (v j)+e))) 0 := by fun_prop
  have ht : Filter.Tendsto (fun e : ℝ => ((9/2 : ℝ)*C)*(∏ j,(deficitSeminorm Q (v j)+e)))
      (𝓝[Set.Ioi 0] 0) (𝓝 (((9/2 : ℝ)*C)*(∏ j,deficitSeminorm Q (v j)))) := by
    simpa using hc.tendsto.mono_left nhdsWithin_le_nhds
  apply ge_of_tendsto ht
  filter_upwards [self_mem_nhdsWithin] with e he
  exact cubic_polarization_scaled_bound T Q hQ C hC hdiag v
    (fun j => deficitSeminorm Q (v j)+e)
    (fun j => add_pos_of_nonneg_of_pos (Real.sqrt_nonneg _) he)
    (fun j => le_add_of_nonneg_right he.le)

theorem symmetrizedMultilinear_permutation
    (T : MultilinearMap ℝ (fun _ : Fin 3 => Fin n → ℝ) ℝ)
    (v : Fin 3 → Fin n → ℝ) (s : Equiv.Perm (Fin 3)) :
    symmetrizedMultilinear T (fun j => v (s j))=symmetrizedMultilinear T v := by
  classical
  simp only [symmetrizedMultilinear,MultilinearMap.smul_apply,MultilinearMap.sum_apply,
    MultilinearMap.domDomCongr_apply,smul_eq_mul]
  congr 1
  exact Fintype.sum_equiv (Equiv.mulLeft s) _ _ (fun p => rfl)

end CoefficientStability
