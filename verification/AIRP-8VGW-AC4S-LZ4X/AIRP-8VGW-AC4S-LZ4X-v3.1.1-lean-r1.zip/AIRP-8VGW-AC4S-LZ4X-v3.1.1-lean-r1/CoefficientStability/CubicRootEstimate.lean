import CoefficientStability.RootVarianceTheorem
import CoefficientStability.BoundaryCubic

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem multiset_abs_cubes_le_square_sum (s : Multiset ℝ) (B : ℝ) (hB : 0≤B)
    (hb : ∀ r∈s,|r|≤B) : (s.map (fun r => |r^3|)).sum≤B*(s.map (fun r => r^2)).sum := by
  induction s using Multiset.induction_on with
  | empty => simp
  | @cons r s ih =>
    have hr := hb r (Multiset.mem_cons_self _ _)
    have ht := ih (fun a ha => hb a (Multiset.mem_cons_of_mem ha))
    have hc : |r^3|≤B*r^2 := by
      have hm := mul_le_mul_of_nonneg_right hr (sq_nonneg r)
      have he : |r^3|=|r| * r^2 := by rw [pow_succ,abs_mul,abs_of_nonneg (sq_nonneg r),mul_comm]
      rw [he]
      exact hm
    simp only [Multiset.map_cons,Multiset.sum_cons]
    nlinarith

theorem centered_cubic_esymm_bound (s : Multiset ℝ) (hs : s.sum=0) :
    |s.esymm 3|≤Real.sqrt ((s.map (fun r => r^2)).sum)^3/3 := by
  have hnonneg : 0≤(s.map (fun r => r^2)).sum :=
    Multiset.sum_nonneg (by intro r hr;obtain ⟨a,ha,rfl⟩ := Multiset.mem_map.mp hr;exact sq_nonneg a)
  let B := Real.sqrt ((s.map (fun r => r^2)).sum)
  have hB : 0≤B := Real.sqrt_nonneg _
  have hsq : B^2=(s.map (fun r => r^2)).sum := Real.sq_sqrt hnonneg
  have hsum := (multiset_abs_sum_bound (s.map (fun r => r^3))).trans
    (by simpa only [Multiset.map_map,Function.comp_def] using
      multiset_abs_cubes_le_square_sum s B hB (fun r hr => multiset_root_abs_bound s r hr))
  have hnew := esymm_three_identity s
  rw [hs] at hnew
  have he : (s.map (fun r => r^3)).sum=3*s.esymm 3 := by nlinarith
  rw [he,abs_mul,abs_of_pos (by norm_num : (0 : ℝ)<3)] at hsum
  rw [← hsq] at hsum
  change |s.esymm 3|≤B^3/3
  nlinarith

theorem paper_central_cubic_sharp_bound (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (N : ℕ) (hN : 3≤N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) (x : Fin n → ℝ) :
    |MvPolynomial.eval x (centralCoefficientPolynomial p t N 3)|≤
      Real.sqrt (2*matrixQuadratic (deficitMatrix p t N) x)^3/3 := by
  obtain ⟨roots,hcard,hv,he⟩ := centralLineCoefficient_eq_centered_esymm p t N x (by omega) hp hnorm hstable hgrad
  have hbound := centered_cubic_esymm_bound (centeredRoots roots)
    (centeredRoots_sum roots (by omega))
  have hs : ((centeredRoots roots).map (fun r => r^2)).sum=
      2*matrixQuadratic (deficitMatrix p t N) x := by
    unfold centeredVariance at hv
    linarith
  rw [eval_centralCoefficientPolynomial,he 3 hN]
  simpa only [hs] using hbound

end CoefficientStability
