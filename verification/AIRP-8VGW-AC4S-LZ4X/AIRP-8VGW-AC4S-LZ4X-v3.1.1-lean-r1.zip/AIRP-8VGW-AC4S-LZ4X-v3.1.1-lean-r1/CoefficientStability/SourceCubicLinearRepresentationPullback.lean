import CoefficientStability.SourceCubicConicDefiniteRepresentation
import CoefficientStability.UniformMixingRecovery

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceCubicTupleLinearPullback (L : Matrix (Fin 3) (Fin 3) ℝ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ :=
  fun i => ∑ j,(L j i : ℂ) • A j

theorem source_cubic_tuple_linear_pullback_hermitian (L : Matrix (Fin 3) (Fin 3) ℝ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : ∀ i,(A i).IsHermitian) :
    ∀ i,(sourceCubicTupleLinearPullback L A i).IsHermitian := by
  intro i
  change (∑ j,(L j i : ℂ) • A j).IsHermitian
  apply Finset.sum_induction
  · intro X Y hX hY
    exact hX.add hY
  · exact Matrix.isHermitian_zero
  · intro j hj
    exact (hA j).smul (by simp [IsSelfAdjoint])

theorem source_cubic_tuple_linear_pullback_evaluation (L : Matrix (Fin 3) (Fin 3) ℝ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (x : Fin 3 → ℝ) :
    (∑ i,(x i : ℂ) • sourceCubicTupleLinearPullback L A i)=
      ∑ j,((L.mulVec x j : ℝ) : ℂ) • A j := by
  simp only [sourceCubicTupleLinearPullback,Finset.smul_sum,smul_smul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j hj
  rw [← Finset.sum_smul]
  congr 1
  simp only [Matrix.mulVec,dotProduct]
  push_cast
  apply Finset.sum_congr rfl
  intro i hi
  ring

theorem source_cubic_tuple_linear_pullback_polynomial (L : Matrix (Fin 3) (Fin 3) ℝ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : ∀ i,(A i).IsHermitian) :
    matrixSubstitution L (realDeterminantPolynomial A)=
      realDeterminantPolynomial (sourceCubicTupleLinearPullback L A) := by
  apply MvPolynomial.funext
  intro x
  apply Complex.ofReal_injective
  rw [matrixSubstitution_eval,realDeterminantPolynomial_evaluation A hA,
    realDeterminantPolynomial_evaluation _ (source_cubic_tuple_linear_pullback_hermitian L A hA),
    source_cubic_tuple_linear_pullback_evaluation]

theorem source_cubic_actual_definite_representation_linear_recovery
    (p q : MvPolynomial (Fin 3) ℝ) (L : Matrix (Fin 3) (Fin 3) ℝ)
    (hrec : ∀ x : Fin 3 → ℝ,MvPolynomial.eval x p=MvPolynomial.eval (L.mulVec x) q)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : ∀ i,(A i).IsHermitian)
    (hpoly : q=realDeterminantPolynomial A)
    (hpos : (∑ j,((L.mulVec (fun _ => 1) j : ℝ) : ℂ) • A j).PosDef) :
    ∃ B : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ,
      (∀ i,(B i).IsHermitian) ∧ (∑ i,B i).PosDef ∧ p=realDeterminantPolynomial B := by
  refine ⟨sourceCubicTupleLinearPullback L A,source_cubic_tuple_linear_pullback_hermitian L A hA,?_,?_⟩
  · have he := source_cubic_tuple_linear_pullback_evaluation L A (fun _ => 1)
    simp only [Complex.ofReal_one,one_smul] at he
    rw [he]
    exact hpos
  · have he : p=matrixSubstitution L q := by
      apply MvPolynomial.funext
      intro x
      rw [matrixSubstitution_eval]
      exact hrec x
    rw [he,hpoly,source_cubic_tuple_linear_pullback_polynomial L A hA]

end CoefficientStability
