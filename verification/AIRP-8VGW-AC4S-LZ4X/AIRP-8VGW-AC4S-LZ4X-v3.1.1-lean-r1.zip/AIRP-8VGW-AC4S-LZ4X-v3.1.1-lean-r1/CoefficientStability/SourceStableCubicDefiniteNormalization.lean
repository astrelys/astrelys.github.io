import CoefficientStability.SourceStableCubicCongruencePolynomial

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

theorem source_stable_cubic_definite_pencil_normalization
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : ∀ i,(A i).IsHermitian)
    (hM : (∑ i,A i).PosDef) :
    ∃ B : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ,(∀ i,(B i).IsHermitian) ∧ (∑ i,B i)=1 ∧
      realDeterminantPolynomial B=(MvPolynomial.eval (fun _ => 1) (realDeterminantPolynomial A))⁻¹ • realDeterminantPolynomial A ∧
      0 < MvPolynomial.eval (fun _ => 1) (realDeterminantPolynomial A) := by
  obtain ⟨V,hV⟩ := source_stable_cubic_actual_whitening (∑ i,A i) hM
  let B := sourceCubicCongruenceTuple V A
  let a := MvPolynomial.eval (fun _ => 1) (realDeterminantPolynomial A)
  let c := Complex.normSq (Matrix.det V)
  have hBH : ∀ i,(B i).IsHermitian := source_cubic_congruence_tuple_hermitian V A hA
  have hBS : (∑ i,B i)=1 := source_cubic_actual_congruence_sum A V hV
  have hscale : realDeterminantPolynomial B=c • realDeterminantPolynomial A := source_cubic_actual_congruence_polynomial V A hA
  have hn := source_realDeterminant_normalized B hBH hBS
  have hca : c*a=1 := by
    calc
      c*a=MvPolynomial.eval (fun _ => 1) (c • realDeterminantPolynomial A) := by simp [a,MvPolynomial.smul_eq_C_mul]
      _=MvPolynomial.eval (fun _ => 1) (realDeterminantPolynomial B) := congrArg (MvPolynomial.eval (fun _ => 1)) hscale.symm
      _=1 := hn
  have hc0 : 0 ≤ c := Complex.normSq_nonneg _
  have ha : 0 < a := by
    by_contra! hnot
    have h := mul_nonpos_of_nonneg_of_nonpos hc0 hnot
    rw [hca] at h
    norm_num at h
  have hc : c=a⁻¹ := by
    apply mul_right_cancel₀ (ne_of_gt ha)
    rw [hca,inv_mul_cancel₀ (ne_of_gt ha)]
  refine ⟨B,hBH,hBS,?_,ha⟩
  rw [hscale,hc]

theorem source_stable_cubic_definite_representation_feasible (p : MvPolynomial (Fin 3) ℝ)
    (t : Fin 3 → ℝ) (hs : UpperHalfPlaneZeroFree p)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : ∀ i,(A i).IsHermitian)
    (hM : (∑ i,A i).PosDef)
    (hrep : p=(MvPolynomial.eval (fun _ => 1) (realDeterminantPolynomial A))⁻¹ • realDeterminantPolynomial A) :
    ∃ B ∈ hermitianFeasibleTuples t,p=realDeterminantPolynomial B := by
  obtain ⟨B,hBH,hBS,hpoly,ha⟩ := source_stable_cubic_definite_pencil_normalization A hA hM
  have he : p=realDeterminantPolynomial B := hrep.trans hpoly.symm
  have hstable : UpperHalfPlaneZeroFree (realDeterminantPolynomial B) := by rw [← he];exact hs
  have hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i (realDeterminantPolynomial B))=t i := by rw [← he];exact hg
  exact ⟨B,source_stable_cubic_normalized_pencil_feasible t B hBH hBS hstable hgrad,he⟩

end CoefficientStability
