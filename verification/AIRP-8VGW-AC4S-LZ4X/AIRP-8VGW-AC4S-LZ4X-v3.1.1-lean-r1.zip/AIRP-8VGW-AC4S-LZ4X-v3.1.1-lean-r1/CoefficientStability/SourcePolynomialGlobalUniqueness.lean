import CoefficientStability.SourcePolynomialGlobalGap
import CoefficientStability.StableLocalCriterion

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem coefficientL1_nonpos_zero (p : MvPolynomial (Fin n) ℝ) (hp : coefficientL1 p ≤ 0) : p=0 := by
  classical
  ext g
  change p.coeff g=0
  by_cases hg : g ∈ p.support
  · have h := Finset.single_le_sum (fun d hd => abs_nonneg (p.coeff d)) hg
    change |p.coeff g| ≤ coefficientL1 p at h
    have hz : |p.coeff g|=0 := le_antisymm (h.trans hp) (abs_nonneg _)
    exact abs_eq_zero.mp hz
  · exact MvPolynomial.notMem_support_iff.mp hg

theorem stable_zero_deficit_reference (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hn : 2 ≤ n) (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hc : ∀ g,0 ≤ p.coeff g)
    (ht : (∑ i,t i)=n) (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hδ : referenceDeficit p t n=0) : p=scalarPower t n := by
  have h := paper_coefficient_distance_upper p t hn hp hnorm hs hc ht hgrad
  rw [hδ,mul_zero] at h
  exact sub_eq_zero.mp (coefficientL1_nonpos_zero _ h)

theorem source_euclidean_global_equality_iff (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hn : 3 ≤ n) (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (ht : (∑ i,t i)=n)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hnear : (∑ i,(t i-1)^2) ≤ 1/(10000000000000000*(n : ℝ)^15)) :
    sourceVn n*(∏ i,t i) ≤ p.coeff (squarefreeExponent n) ∧
      (p.coeff (squarefreeExponent n)=sourceVn n*(∏ i,t i) ↔ p=scalarPower t n) := by
  have hc := normalized_homogeneous_stable_coeff_nonneg p n hp hs hnorm
  have hgap := source_euclidean_global_coefficient_gap p hn hp hs hnorm (by simpa only [hgrad] using hnear)
  have htfun : (fun i => MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p))=t := funext hgrad
  rw [htfun] at hgap
  have hδ := (paper_deficit_uniform_bound p t (by omega) hp hnorm hs hc ht hgrad).1
  have hk : 0 < sourceVn n/(2000000000*(n : ℝ)^8) :=
    div_pos (sourceVn_pos (by omega)) (by positivity)
  have hnonneg := mul_nonneg hk.le hδ
  refine ⟨by linarith,?_⟩
  constructor
  · intro heq
    rw [heq,sub_self] at hgap
    have hz : referenceDeficit p t n=0 := by
      have hle : referenceDeficit p t n ≤ 0 := by
        by_contra hh
        have hpos := mul_pos hk (lt_of_not_ge hh)
        linarith
      exact le_antisymm hle hδ
    exact stable_zero_deficit_reference p t (by omega) hp hs hnorm hc ht hgrad hz
  · intro heq
    rw [heq,scalarPower_squarefree_coefficient]
    rfl

theorem source_polynomial_global_equality_iff (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hn : 3 ≤ n) (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (ht : (∑ i,t i)=n)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hnear : (∑ i,|t i-1|) ≤ 1/(1000000000*(n : ℝ)^8)) :
    sourceVn n*(∏ i,t i) ≤ p.coeff (squarefreeExponent n) ∧
      (p.coeff (squarefreeExponent n)=sourceVn n*(∏ i,t i) ↔ p=scalarPower t n) := by
  exact source_euclidean_global_equality_iff p t hn hp hs hnorm ht hgrad
    (source_l1_radius_implies_euclidean hn (fun i => t i-1) hnear)

end CoefficientStability
