import CoefficientStability.NuijScaling
import CoefficientStability.SmoothedCoefficientCone
import Mathlib.Topology.Algebra.Order.Field

noncomputable section
open scoped Topology
open Filter
namespace CoefficientStability
variable {n : ℕ}

theorem normalized_smoothed_coefficients_eventually_positive
    (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (hp : p.IsHomogeneous N)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N) (x : Fin n → ℝ) (ε : ℝ)
    (l : Filter ℝ) (hinv : Tendsto (fun t : ℝ => t⁻¹) l (𝓝 0)) :
    ∀ᶠ t in l,∀ k : Fin (N+1),
      0<(smoothedLineRestriction p N (ε/t) (b+(1/t) • x)).coeff k.val := by
  have hvec : Tendsto (fun t : ℝ => b+t⁻¹ • x) l (𝓝 b) := by
    simpa only [zero_smul,add_zero] using tendsto_const_nhds.add (hinv.smul_const x)
  have hscalar : Tendsto (fun t : ℝ => ε/t) l (𝓝 0) := by
    simpa only [mul_zero,div_eq_mul_inv] using tendsto_const_nhds.mul hinv
  have hpair : Tendsto (fun t : ℝ => (b+(1/t) • x,ε/t)) l (𝓝 (b,(0 : ℝ))) := by
    simpa only [one_div] using hvec.prodMk_nhds hscalar
  exact hpair.eventually (source_smoothed_coefficients_eventually_positive p N hp hs hnorm b hb)

theorem positive_finite_coefficients_root_neg (P : Polynomial ℝ) (N : ℕ)
    (hd : P.natDegree≤N) (hc : ∀ k : Fin (N+1),0<P.coeff k.val)
    (r : ℝ) (hr : P.IsRoot r) : r<0 := by
  have hc0 : 0<P.coeff 0 := hc ⟨0,by omega⟩
  have hnonneg : ∀ k,0≤P.coeff k := by
    intro k
    by_cases hk : k≤N
    · exact (hc ⟨k,by omega⟩).le
    · rw [Polynomial.coeff_eq_zero_of_natDegree_lt (by omega)]
  by_contra hh
  have h := univariate_constant_coeff_le_eval P hnonneg r (le_of_not_gt hh)
  rw [hr] at h
  linarith

theorem smoothed_affine_root_normalized (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (x b : Fin n → ℝ) (ε t r : ℝ) (ht : t≠0)
    (hr : (smoothedLineRestriction p N ε (x+t • b)).IsRoot r) :
    (smoothedLineRestriction p N (ε/t) (b+(1/t) • x)).IsRoot ((1/t)*r) := by
  change (smoothedLineRestriction p N ε (x+t • b)).eval r=0 at hr
  rw [smoothed_line_affine_normalization p N hp x b ε t ht,Polynomial.eval_mul,Polynomial.eval_C,
    Polynomial.eval_comp,Polynomial.eval_mul,Polynomial.eval_C,Polynomial.eval_X] at hr
  exact (mul_eq_zero.mp hr).resolve_left (pow_ne_zero _ ht)

end CoefficientStability
