import CoefficientStability.TiltPathDeficit
import CoefficientStability.CubicTensorEuler

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def coefficientMean (p : MvPolynomial (Fin n) ℝ) : ((Fin n →₀ ℕ) → ℝ) →ₗ[ℝ] ℝ :=
  ∑ g∈p.support,p.coeff g • LinearMap.proj g

@[simp] theorem coefficientMean_apply (p : MvPolynomial (Fin n) ℝ) (F : (Fin n →₀ ℕ) → ℝ) :
    coefficientMean p F=∑ g∈p.support,p.coeff g*F g := by simp [coefficientMean]

theorem tiltedExpectation_coefficientMean (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ)
    (hZ : tiltPartition p u≠0) (F : (Fin n →₀ ℕ) → ℝ) :
    tiltedExpectation p u F=coefficientMean (tiltedPolynomial p u) F := by
  rw [coefficientMean_apply,tiltedPolynomial_support p u hZ]
  simp only [tiltedExpectation,tiltedPolynomial_coeff,Finset.sum_div]
  apply Finset.sum_congr rfl
  intro g hg
  ring

theorem rawCubicTensor_coefficientMean (p : MvPolynomial (Fin n) ℝ) (w : Fin 3 → Fin n → ℝ) :
    rawCubicTensor p w=coefficientMean p (fun g => factorialMonomialCubic g w) := by
  rw [rawCubicTensor_as_sum]
  simp only [MultilinearMap.sum_apply,MultilinearMap.smul_apply,smul_eq_mul,coefficientMean_apply]

theorem rawCubicTensor_one_mean (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (hp : p.IsHomogeneous N)
    (x y : Fin n → ℝ) :
    rawCubicTensor p ![(fun _ => 1),x,y]=
      ((N : ℝ)-2)*coefficientMean p (fun g => exponentLinear g x*exponentLinear g y-
        ∑ i,(g i : ℝ)*x i*y i) := by
  rw [rawCubicTensor_coefficientMean]
  simp only [coefficientMean_apply,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro g hg
  rw [factorialMonomialCubic_one g N (homogeneous_mass p N hp g hg)]
  ring

theorem rawCubicTensor_repeated_mean (p : MvPolynomial (Fin n) ℝ) (i : Fin n) (v : Fin n → ℝ) :
    rawCubicTensor p ![Pi.single i (1 : ℝ),Pi.single i (1 : ℝ),v]=
      coefficientMean p (fun g => ((g i : ℝ)^2-(g i : ℝ))*(exponentLinear g v-2*v i)) := by
  rw [rawCubicTensor_coefficientMean]
  simp only [coefficientMean_apply,factorialMonomialCubic_repeated]

end CoefficientStability
