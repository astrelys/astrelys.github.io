import CoefficientStability.HermitianObjectiveReality

noncomputable section
open scoped BigOperators ComplexOrder Topology
open Polynomial
namespace CoefficientStability
variable {n : ℕ}

theorem complexReferenceTuple_source (t : Fin n → ℝ) (i : Fin n) :
    complexReferenceTuple t i=Complex.ofReal (t i/(n : ℝ)) • (1 : Matrix (Fin n) (Fin n) ℂ) := by
  ext r l
  by_cases h : r=l <;> simp [complexReferenceTuple,scalarReferenceTuple,Matrix.map_apply,
    Matrix.smul_apply,Matrix.one_apply,h]

theorem hermitianBoundaryObjective_eval (t : Fin n → ℝ) (hn : 0<n) (s : ℝ) :
    hermitianMixedObjective (complexBoundaryTuple t s)=(boundaryMixedPolynomial t).eval s := by
  simp only [hermitianMixedObjective,complexBoundaryTuple_objective t hn s,Complex.ofReal_re]

theorem referenceObjective_source_normalization (t : Fin n → ℝ) (hn : 0<n) :
    hermitianMixedObjective (complexReferenceTuple t)=(n.factorial : ℝ)/(n : ℝ)^n*∏ i,t i := by
  rw [← complexBoundaryTuple_zero t,hermitianBoundaryObjective_eval t hn 0,
    ← Polynomial.coeff_zero_eq_eval_zero,boundaryMixedPolynomial_coeff t hn 0]
  simp [centralCoefficient,boundaryNormalizingFactor_source]

theorem polynomial_strict_descent_of_negative_quadratic (p : ℝ[X])
    (h1 : p.coeff 1=0) (h2 : p.coeff 2<0) :
    ∃ e : ℝ,0<e ∧ ∀ s : ℝ,0<s → s<e → p.eval s<p.eval 0 := by
  have hd : Polynomial.X^2 ∣ p-Polynomial.C (p.coeff 0) := by
    apply Polynomial.X_pow_dvd_iff.mpr
    intro d hd
    have hcases : d=0 ∨ d=1 := by omega
    rcases hcases with rfl | rfl <;> simp [Polynomial.coeff_sub,Polynomial.coeff_C,h1]
  obtain ⟨q,hq⟩ := hd
  have hqcoeff : p.coeff 2=q.coeff 0 := by
    have h := congrArg (fun f : ℝ[X] => f.coeff 2) hq
    have hc : (Polynomial.X^2*q).coeff 2=q.coeff 0 := Polynomial.coeff_X_pow_mul q 2 0
    simpa [Polynomial.coeff_sub,Polynomial.coeff_C,hc] using h
  have hq0 : q.eval 0<0 := by simpa only [← Polynomial.coeff_zero_eq_eval_zero,← hqcoeff] using h2
  have hnear : ∀ᶠ s in 𝓝 (0 : ℝ),q.eval s<0 :=
    q.continuousAt.eventually (eventually_lt_nhds hq0)
  obtain ⟨e,he,hbound⟩ := Metric.eventually_nhds_iff.mp hnear
  refine ⟨e,he,?_⟩
  intro s hs hse
  have hqs : q.eval s<0 := hbound (y := s) (by simpa [Real.dist_eq,abs_of_pos hs] using hse)
  have hval := congrArg (Polynomial.eval s) hq
  simp only [Polynomial.eval_sub,Polynomial.eval_C,Polynomial.eval_mul,Polynomial.eval_pow,Polynomial.eval_X] at hval
  rw [Polynomial.coeff_zero_eq_eval_zero] at hval
  have hneg := mul_neg_of_pos_of_neg (pow_pos hs 2) hqs
  linarith

theorem projectedOnes_second_coefficient_pos (t : Fin n → ℝ) (hn : 0<n)
    (ht : ∑ i,t i=n) (hl : scalarHessianLambda t<0) : 0<centralCoefficient (projectedOnes t) 2 := by
  have h := centralCoefficient_two (projectedOnes t)
  rw [projectedOnes_sum t ht,projectedOnes_normSq t hn ht] at h
  have hp := mul_neg_of_neg_of_pos hl (by linarith : 0<1-scalarHessianLambda t)
  nlinarith

theorem boundaryMixedPolynomial_negative_coeff_two (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : scalarHessianLambda t<0) :
    (boundaryMixedPolynomial t).coeff 2<0 := by
  have he := projectedOnes_second_coefficient_pos t (by omega) ht hl
  have hnorm := boundaryNormalizingFactor_pos t (by omega) htpos
  have hn0 : (n : ℝ)≠0 := by exact_mod_cast (by omega : n≠0)
  have hp : boundaryNormalizingFactor t*(1-(2 : ℝ))*(-(n : ℝ))^2<0 :=
    mul_neg_of_neg_of_pos (mul_neg_of_pos_of_neg hnorm (by norm_num)) (sq_pos_of_ne_zero (neg_ne_zero.mpr hn0))
  rw [boundaryMixedPolynomial_coeff t (by omega) 2]
  exact mul_neg_of_neg_of_pos hp he

theorem paper_negative_curvature_not_local_min (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : scalarHessianLambda t<0) :
    ¬IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (complexReferenceTuple t) := by
  obtain ⟨e,he,hdesc⟩ := polynomial_strict_descent_of_negative_quadratic (boundaryMixedPolynomial t)
    (boundaryMixedPolynomial_coeff_one t (by omega)) (boundaryMixedPolynomial_negative_coeff_two t hn ht htpos hl)
  apply not_localMin_of_complexCurve_descent t hn ht htpos
  refine ⟨e,he,?_⟩
  intro s hs hse
  have h := hdesc s hs hse
  simpa only [← complexBoundaryTuple_zero t,hermitianBoundaryObjective_eval t (by omega)] using h

theorem paper_exact_local_necessity (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i)
    (hmin : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (complexReferenceTuple t)) :
    (∑ i,(t i-1)^2)<(n : ℝ)/((n : ℝ)-1) := by
  apply (scalarHessianLambda_pos_iff_radius t hn ht).mp
  by_contra! hl
  rcases lt_or_eq_of_le hl with hneg | heq
  · exact paper_negative_curvature_not_local_min t hn ht htpos hneg hmin
  · exact paper_boundary_not_local_min t hn ht htpos heq hmin

end CoefficientStability
