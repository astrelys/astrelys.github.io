import CoefficientStability.SourceSpectralCube

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n N : ℕ}

theorem bounded_tuple_subset_mass_lower (roots : Fin N → ℝ)
    (hr : ∀ i,0≤roots i ∧ roots i≤1) (S : Finset (Fin N)) :
    0≤(∑ i∈S,roots i) ∧
      (∑ i,roots i)-((N-S.card : ℕ) : ℝ)≤∑ i∈S,roots i := by
  classical
  have hsplit := Finset.sum_add_sum_compl S roots
  have hbound : (∑ i∈Sᶜ,roots i)≤((Sᶜ).card : ℝ) := by
    calc
      _≤∑ _i∈Sᶜ,(1 : ℝ) := Finset.sum_le_sum (fun i hi => (hr i).2)
      _=_ := by simp
  have hcard : (Sᶜ).card=N-S.card := by
    rw [Finset.card_compl, Fintype.card_fin]
  rw [hcard] at hbound
  exact ⟨Finset.sum_nonneg (fun i hi => (hr i).1),by linarith⟩

theorem actual_source_indicator_trace (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (U : Finset (Fin n)) (roots : Fin N → ℝ)
    (hf : lineRestriction p (fun i => if i∈U then 1 else 0)=
      ∏ j : Fin N,(Polynomial.X+Polynomial.C (roots j))) :
    (∑ j,roots j)=∑ i∈U,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p) := by
  classical
  have h := actual_source_root_tuple_trace p N hN hp hnorm _ roots hf
  simpa only [mul_ite,mul_one,mul_zero,Finset.sum_ite_mem,Finset.inter_univ,Finset.univ_inter] using h

theorem actual_source_indicator_subset_lower (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (U : Finset (Fin n)) (roots : Fin N → ℝ)
    (hf : lineRestriction p (fun i => if i∈U then 1 else 0)=
      ∏ j : Fin N,(Polynomial.X+Polynomial.C (roots j))) (k : ℕ)
    (S : Finset (Fin N)) (hcard : S.card=k) :
    0≤(∑ j∈S,roots j) ∧
      (∑ i∈U,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p))-((N-k : ℕ) : ℝ)≤∑ j∈S,roots j := by
  classical
  have hr := actual_source_cube_spectral_bounds p N hN hp hs hnorm
    (fun i => if i∈U then 1 else 0) (by intro i;split_ifs <;> norm_num)
    (by intro i;split_ifs <;> norm_num) roots hf
  have h := bounded_tuple_subset_mass_lower roots hr S
  rwa [actual_source_indicator_trace p N hN hp hnorm U roots hf,hcard] at h

end CoefficientStability
