import CoefficientStability.SourceCubicWhitenedSourceInput

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceCubicConicPolynomial (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ) :=
  matrixSubstitution sourceConicCoordinateMatrix (sourceCubicWhitenedPolynomial p t)

def sourceCubicOriginalRecoveryMatrix (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ) :=
  sourceConicRecoveryMatrix*sourceBinaryWhiteningRecoveryMatrix
    (deficitMatrix p t 3 0 0) (deficitMatrix p t 3 0 1) (deficitMatrix p t 3 1 1)*
      sourceDepressedRecoveryMatrix t

theorem source_stable_cubic_actual_conic_source_sign
    (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ)
    (hp : p.IsHomogeneous 3) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) (ht : ∑ i,t i=3)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (ha : 0<deficitMatrix p t 3 0 0)
    (hd : 0<deficitMatrix p t 3 0 0*deficitMatrix p t 3 1 1-(deficitMatrix p t 3 0 1)^2)
    (u v : ℝ) :
    MvPolynomial.eval (![u^2,u*v,v^2] : Fin 3 → ℝ) (sourceCubicConicPolynomial p t)≤0 := by
  unfold sourceCubicConicPolynomial
  rw [matrixSubstitution_eval,source_conic_coordinate_matrix_actual]
  exact source_standard_conic_actual_nonpositive _ (sourceCubicWhitenedRemainder p t)
    (source_stable_cubic_actual_whitened_normal_form p t hp hn hs ht hg ha hd)
    (source_stable_cubic_actual_whitened_discriminant p t hp hn hs hg ha hd) u v

theorem source_cubic_conic_entire_original_recovery
    (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ) (ht : ∑ i,t i=3)
    (ha : 0<deficitMatrix p t 3 0 0)
    (hd : 0<deficitMatrix p t 3 0 0*deficitMatrix p t 3 1 1-(deficitMatrix p t 3 0 1)^2)
    (z : Fin 3 → ℝ) :
    MvPolynomial.eval z p=MvPolynomial.eval ((sourceCubicOriginalRecoveryMatrix p t).mulVec z)
      (sourceCubicConicPolynomial p t) := by
  unfold sourceCubicConicPolynomial sourceCubicWhitenedPolynomial sourceCubicDepressedPolynomial
  rw [matrixSubstitution_eval,matrixSubstitution_eval,matrixSubstitution_eval]
  simp only [sourceCubicOriginalRecoveryMatrix,← Matrix.mulVec_mulVec,
    source_conic_matrix_entire_recovery,
    source_binary_whitening_matrix_entire_recovery _ _ _ ha hd,
    source_depressed_matrix_entire_recovery t ht]

theorem source_cubic_original_recovery_normalized_direction
    (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ) (ht : ∑ i,t i=3) :
    (sourceCubicOriginalRecoveryMatrix p t).mulVec (fun _ => 1)=![Real.sqrt 3,0,Real.sqrt 3] := by
  have hD : (sourceDepressedRecoveryMatrix t).mulVec (fun _ => 1)=![1,0,0] := by
    rw [source_depressed_recovery_matrix_actual]
    simp only [mul_one,ht]
    norm_num
  have hW : (sourceBinaryWhiteningRecoveryMatrix (deficitMatrix p t 3 0 0)
      (deficitMatrix p t 3 0 1) (deficitMatrix p t 3 1 1)).mulVec (![1,0,0] : Fin 3 → ℝ)=![1,0,0] := by
    rw [source_binary_whitening_recovery_matrix_actual]
    norm_num [sourceBinaryWhiteningForward]
  unfold sourceCubicOriginalRecoveryMatrix
  rw [← Matrix.mulVec_mulVec,← Matrix.mulVec_mulVec,hD,hW,source_conic_recovery_matrix_actual]
  norm_num

theorem source_stable_cubic_positive_quadratic_actual_representation
    (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ)
    (hp : p.IsHomogeneous 3) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) (ht : ∑ i,t i=3)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (ha : 0<deficitMatrix p t 3 0 0)
    (hd : 0<deficitMatrix p t 3 0 0*deficitMatrix p t 3 1 1-(deficitMatrix p t 3 0 1)^2) :
    ∃ A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ,
      (∀ i,(A i).IsHermitian) ∧ (∑ i,A i).PosDef ∧ p=realDeterminantPolynomial A := by
  let q := sourceCubicConicPolynomial p t
  let e : Fin 3 → ℝ := ![Real.sqrt 3,0,Real.sqrt 3]
  have hq : q.IsHomogeneous 3 := matrixSubstitution_homogeneous _ _ _
    (source_cubic_whitened_polynomial_homogeneous p t hp)
  have hsign := source_stable_cubic_actual_conic_source_sign p t hp hn hs ht hg ha hd
  have hnormal : MvPolynomial.eval e q=1 := by
    have h := source_cubic_conic_entire_original_recovery p t ht ha hd (fun _ => 1)
    rw [source_cubic_original_recovery_normalized_direction p t ht,hn] at h
    exact h.symm
  obtain ⟨A,hA,hpos,hpoly⟩ := source_cubic_nonpositive_conic_actual_definite_representation q hq hsign e
    (Real.sqrt_pos.mpr (by norm_num))
    (by change 0<Real.sqrt 3*Real.sqrt 3-(0 : ℝ)^2; nlinarith [Real.sq_sqrt (show (0 : ℝ)≤3 by norm_num)])
    (by rw [hnormal];norm_num)
  apply source_cubic_actual_definite_representation_linear_recovery p q (sourceCubicOriginalRecoveryMatrix p t)
    (source_cubic_conic_entire_original_recovery p t ht ha hd) A hA hpoly
  rw [source_cubic_original_recovery_normalized_direction p t ht]
  exact hpos

end CoefficientStability
