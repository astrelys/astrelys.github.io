import CoefficientStability.ScalarHessianSpectrum
import CoefficientStability.MatrixTraceBounds

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def weightedDeficitMatrix (t : Fin n → ℝ) (Q : Matrix (Fin n) (Fin n) ℝ) :
    Matrix (Fin n) (Fin n) ℝ := fun i j => (t i)⁻¹*Q i j*(t j)⁻¹

theorem weightedDeficitMatrix_congruence (t : Fin n → ℝ) (Q : Matrix (Fin n) (Fin n) ℝ) :
    weightedDeficitMatrix t Q=Matrix.diagonal (fun i => (t i)⁻¹)*Q*
      Matrix.diagonal (fun i => (t i)⁻¹) := by
  ext i j
  simp [weightedDeficitMatrix,Matrix.diagonal_mul,Matrix.mul_diagonal]

theorem weightedDeficitMatrix_positive (t : Fin n → ℝ) (Q : Matrix (Fin n) (Fin n) ℝ)
    (hQ : Q.PosSemidef) : (weightedDeficitMatrix t Q).PosSemidef := by
  rw [weightedDeficitMatrix_congruence]
  have h := hQ.mul_mul_conjTranspose_same (Matrix.diagonal (fun i => (t i)⁻¹))
  simpa using h

theorem weightedDeficitMatrix_null (t : Fin n → ℝ) (Q : Matrix (Fin n) (Fin n) ℝ)
    (ht : ∀ i,t i≠0) (hQ : Q.mulVec (fun _ => 1)=0) : (weightedDeficitMatrix t Q).mulVec t=0 := by
  funext i
  have hi := congrArg (fun z : Fin n → ℝ => z i) hQ
  simp only [Matrix.mulVec,dotProduct,mul_one,Pi.zero_apply] at hi
  change (∑ j,((t i)⁻¹*Q i j*(t j)⁻¹)*t j)=0
  simp only [mul_assoc,inv_mul_cancel₀ (ht _),mul_one,← Finset.mul_sum,hi,mul_zero]

theorem matrixQuadratic_dot (Q : Matrix (Fin n) (Fin n) ℝ) (x : Fin n → ℝ) :
    matrixQuadratic Q x=dotProduct x (Q.mulVec x) := by
  simp only [matrixQuadratic,dotProduct,Matrix.mulVec,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro j hj
  ring

theorem matrixQuadratic_sub_kernel (Q : Matrix (Fin n) (Fin n) ℝ) (hQ : Q.IsHermitian)
    (x y : Fin n → ℝ) (a : ℝ) (hy : Q.mulVec y=0) :
    matrixQuadratic Q (x-a • y)=matrixQuadratic Q x := by
  have hc : dotProduct y (Q.mulVec x)=0 := by
    have h := hQ.star_dotProduct_mulVec_comm x y
    simpa [hy] using h.symm
  rw [matrixQuadratic_dot,matrixQuadratic_dot,Matrix.mulVec_sub,Matrix.mulVec_smul,hy,smul_zero,sub_zero]
  simp only [sub_dotProduct,smul_dotProduct,hc,smul_zero,sub_zero]

theorem psd_trace_minus_sum_lower (t : Fin n → ℝ) (Q : Matrix (Fin n) (Fin n) ℝ)
    (hn : 0<n) (ht : ∑ i,t i=n) (hQ : Q.PosSemidef) (hnull : Q.mulVec t=0) :
    scalarHessianLambda t*Matrix.trace Q≤Matrix.trace Q-matrixQuadratic Q (fun _ => 1) := by
  have h := psd_quadratic_le_trace Q hQ (projectedOnes t)
  rw [projectedOnes_normSq t hn ht] at h
  have he := matrixQuadratic_sub_kernel Q hQ.isHermitian (fun _ => 1) t
    ((n : ℝ)/marginalNormSq t) hnull
  change matrixQuadratic Q (projectedOnes t)=matrixQuadratic Q (fun _ => 1) at he
  rw [he] at h
  nlinarith

def stableLeadingBracket (t : Fin n → ℝ) (Q : Matrix (Fin n) (Fin n) ℝ) : ℝ :=
  (∑ i,Q i i/(t i)^2)-matrixQuadratic Q (fun i => (t i)⁻¹)

theorem stableLeadingBracket_weighted_trace (t : Fin n → ℝ) (Q : Matrix (Fin n) (Fin n) ℝ) :
    stableLeadingBracket t Q=Matrix.trace (weightedDeficitMatrix t Q)-
      matrixQuadratic (weightedDeficitMatrix t Q) (fun _ => 1) := by
  unfold stableLeadingBracket matrixQuadratic Matrix.trace Matrix.diag weightedDeficitMatrix
  simp only [mul_one]
  congr 1
  · apply Finset.sum_congr rfl
    intro i hi
    simp only [div_eq_mul_inv,inv_pow,pow_two]
    ring
  · apply Finset.sum_congr rfl
    intro i hi
    apply Finset.sum_congr rfl
    intro j hj
    ring

theorem weightedDeficitMatrix_trace_lower (t : Fin n → ℝ) (Q : Matrix (Fin n) (Fin n) ℝ)
    (hQ : Q.PosSemidef) (htpos : ∀ i,0<t i) (M : ℝ) (hM : ∀ i,t i≤M) :
    (M^2)⁻¹*Matrix.trace Q≤Matrix.trace (weightedDeficitMatrix t Q) := by
  change (M^2)⁻¹*(∑ i,Q i i)≤∑ i,(t i)⁻¹*Q i i*(t i)⁻¹
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i hi
  have hi2 : (t i)^2≤M^2 := by nlinarith [hM i,htpos i]
  have h := inv_anti₀ (sq_pos_of_pos (htpos i)) hi2
  have hm := mul_le_mul_of_nonneg_right h (hQ.diag_nonneg (i := i))
  calc
    _ ≤ ((t i)^2)⁻¹*Q i i := hm
    _ = _ := by simp only [inv_pow,pow_two];ring

theorem stableLeadingBracket_coercive (t : Fin n → ℝ) (Q : Matrix (Fin n) (Fin n) ℝ)
    (hn : 0<n) (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hQ : Q.PosSemidef)
    (hnull : Q.mulVec (fun _ => 1)=0) (M : ℝ) (hM : ∀ i,t i≤M)
    (hl : 0<scalarHessianLambda t) :
    (scalarHessianLambda t/M^2)*Matrix.trace Q≤stableLeadingBracket t Q := by
  have h1 := weightedDeficitMatrix_trace_lower t Q hQ htpos M hM
  have h2 := psd_trace_minus_sum_lower t (weightedDeficitMatrix t Q) hn ht
    (weightedDeficitMatrix_positive t Q hQ)
    (weightedDeficitMatrix_null t Q (fun i => ne_of_gt (htpos i)) hnull)
  rw [stableLeadingBracket_weighted_trace]
  have h3 := mul_le_mul_of_nonneg_left h1 hl.le
  exact le_trans (by simpa only [div_eq_mul_inv,mul_assoc] using h3) h2

theorem paper_stable_leading_bracket_coercive (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hn : 2≤n) (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p) (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (M : ℝ) (hM : ∀ i,t i≤M) (hl : 0<scalarHessianLambda t) :
    (scalarHessianLambda t/M^2)*referenceDeficit p t n≤
      stableLeadingBracket t (deficitMatrix p t n) := by
  rw [← trace_deficitMatrix]
  exact stableLeadingBracket_coercive t (deficitMatrix p t n) (by omega) ht htpos
    (deficitMatrix_posSemidef p t n hn hp hnorm hstable hgrad)
    (deficitMatrix_mulVec_one p t n (by omega) hp ht hgrad) M hM hl

end CoefficientStability
