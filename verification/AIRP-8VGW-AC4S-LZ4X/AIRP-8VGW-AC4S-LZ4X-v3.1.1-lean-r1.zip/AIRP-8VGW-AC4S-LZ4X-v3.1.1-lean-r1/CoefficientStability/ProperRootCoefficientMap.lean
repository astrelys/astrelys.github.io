import CoefficientStability.RootPolynomialMap
import Mathlib.Topology.Maps.Proper.CompactlyGenerated
import Mathlib.Analysis.Normed.Group.Bounded

noncomputable section
namespace CoefficientStability
variable {N : ℕ}

theorem rootCoefficientVector_isProperMap :
    IsProperMap (rootCoefficientVector : (Fin N → ℝ) → Fin N → ℝ) := by
  apply isProperMap_iff_isCompact_preimage.mpr
  refine ⟨rootCoefficientVector_continuous,?_⟩
  intro K hK
  obtain ⟨M,hMpos,hM⟩ := hK.isBounded.exists_pos_norm_le
  have hsubset : rootCoefficientVector ⁻¹' K⊆Set.Icc (fun _ : Fin N => -(M+1)) (fun _ => M+1) := by
    intro r hr
    have hbound (i : Fin N) : |r i|<M+1 := by
      apply monic_real_root_uniform_bound (realRootProduct r) (realRootProduct_monic r) M hMpos.le
      · intro k hk
        rw [realRootProduct_natDegree] at hk
        have hcoeff : |(realRootProduct r).coeff k|≤‖rootCoefficientVector r‖ := by
          simpa only [rootCoefficientVector,Real.norm_eq_abs] using
            norm_le_pi_norm (rootCoefficientVector r) ⟨k,hk⟩
        exact hcoeff.trans (hM _ hr)
      · apply Polynomial.isRoot_of_mem_roots
        rw [realRootProduct_roots]
        simp
    exact ⟨fun i => (abs_le.mp (hbound i).le).1,fun i => (abs_le.mp (hbound i).le).2⟩
  exact (isCompact_Icc : IsCompact (Set.Icc (fun _ : Fin N => -(M+1)) (fun _ => M+1))).of_isClosed_subset
    (hK.isClosed.preimage rootCoefficientVector_continuous) hsubset

theorem rootCoefficientVector_range_isClosed :
    IsClosed (Set.range (rootCoefficientVector : (Fin N → ℝ) → Fin N → ℝ)) :=
  rootCoefficientVector_isProperMap.isClosed_range

theorem monic_split_iff_rootCoefficientVector_range (P : Polynomial ℝ) (hp : P.Monic)
    (hdegree : P.natDegree=N) :
    P.Splits ↔ (fun k : Fin N => P.coeff k.val)∈Set.range (rootCoefficientVector : (Fin N → ℝ) → Fin N → ℝ) := by
  constructor
  · intro hs
    have hcard : P.roots.card=N := hs.natDegree_eq_card_roots.symm.trans hdegree
    clear hdegree
    subst N
    obtain ⟨f,henum⟩ := real_multiset_fin_enumeration P.roots
    have hfactor : P=realRootProduct f := by
      calc
        P=(P.roots.map (fun r => Polynomial.X-Polynomial.C r)).prod := hs.eq_prod_roots_of_monic hp
        _=realRootProduct f := by
          conv_lhs => rw [← henum]
          simp only [Multiset.map_coe,List.map_ofFn,Multiset.prod_coe,List.prod_ofFn,Function.comp_def,realRootProduct]
    refine ⟨f,?_⟩
    funext k
    change (realRootProduct f).coeff k.val=P.coeff k.val
    exact congrArg (fun Q : Polynomial ℝ => Q.coeff k.val) hfactor.symm
  · rintro ⟨r,hr⟩
    have heq : realRootProduct r=P := by
      apply monic_degree_eq_of_low_coefficients _ _ (realRootProduct_monic r) hp
        (realRootProduct_natDegree r) hdegree
      intro k
      exact congrArg (fun v : Fin N → ℝ => v k) hr
    exact heq ▸ realRootProduct_splits r

theorem monic_real_split_limit_at_zero (P : ℝ → Polynomial ℝ)
    (hmonic : ∀ ε,(P ε).Monic) (hdegree : ∀ ε,(P ε).natDegree=N)
    (hcont : ∀ k : Fin N,Continuous (fun ε => (P ε).coeff k.val))
    (hsplit : ∀ ε : ℝ,0<ε → (P ε).Splits) : (P 0).Splits := by
  have hF : Continuous (fun ε : ℝ => (fun k : Fin N => (P ε).coeff k.val)) := continuous_pi hcont
  have hclosed : IsClosed ((fun ε : ℝ => (fun k : Fin N => (P ε).coeff k.val)) ⁻¹'
      Set.range (rootCoefficientVector : (Fin N → ℝ) → Fin N → ℝ)) :=
    rootCoefficientVector_range_isClosed.preimage hF
  have hsub : Set.Ioi (0 : ℝ)⊆((fun ε : ℝ => (fun k : Fin N => (P ε).coeff k.val)) ⁻¹'
      Set.range (rootCoefficientVector : (Fin N → ℝ) → Fin N → ℝ)) := by
    intro ε hε
    exact (monic_split_iff_rootCoefficientVector_range (P ε) (hmonic ε) (hdegree ε)).mp (hsplit ε hε)
  have hz : (0 : ℝ)∈closure (Set.Ioi (0 : ℝ)) := by rw [closure_Ioi];simp
  exact (monic_split_iff_rootCoefficientVector_range (P 0) (hmonic 0) (hdegree 0)).mpr
    ((closure_minimal hsub hclosed) hz)

end CoefficientStability
