import CoefficientStability.GurvitsCapacityTheorem

noncomputable section
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem degree_sensitive_gurvits_last (p : MvPolynomial (Fin (n+1)) ℝ)
    (hp : p.IsHomogeneous (n+1)) (hs : UpperHalfPlaneZeroFree p) (hc : ∀ g,0≤p.coeff g)
    (K : ℕ) (hK : p.degreeOf (Fin.last n)≤K) :
    (sourceVn (n+1)*capacityG K/capacityG (n+1))*multivariatePositiveCapacity p≤
      p.coeff (squarefreeExponent (n+1)) := by
  let q := lastDerivativeElimination p
  have hqhom : q.IsHomogeneous n := lastDerivativeElimination_homogeneous p n hp
  have hqcoeff : ∀ g,0≤q.coeff g := nonnegative_stable_derivative_elimination_coeff p n hp hs hc
  have hqstable : q=0 ∨ UpperHalfPlaneZeroFree q := stable_last_derivative_elimination_zero_or_stable p hs
  have hind := gurvits_capacity_lower_zero_or_stable n q hqhom hqcoeff hqstable
  have hstep := multivariate_capacity_derivative_elimination p hs hc K hK
  have hfactor : sourceVn (n+1)*capacityG K/capacityG (n+1)=sourceVn n*capacityG K := by
    rw [sourceVn_capacityG_recurrence]
    field_simp [ne_of_gt (capacityG_strict_pos (n+1))]
  rw [hfactor]
  calc
    (sourceVn n*capacityG K)*multivariatePositiveCapacity p=
        sourceVn n*(capacityG K*multivariatePositiveCapacity p) := mul_assoc _ _ _
    _ ≤sourceVn n*multivariatePositiveCapacity q :=
      mul_le_mul_of_nonneg_left hstep (sourceVn_nonneg n)
    _ ≤q.coeff (squarefreeExponent n) := hind
    _ =p.coeff (squarefreeExponent (n+1)) := lastDerivativeElimination_squarefree_coeff p

theorem reduced_last_degree_gurvits_capacity_lower (p : MvPolynomial (Fin (n+1)) ℝ)
    (hp : p.IsHomogeneous (n+1)) (hs : UpperHalfPlaneZeroFree p) (hc : ∀ g,0≤p.coeff g)
    (hdegree : p.degreeOf (Fin.last n)≤n) :
    (sourceVn (n+1)*capacityG n/capacityG (n+1))*multivariatePositiveCapacity p≤
      p.coeff (squarefreeExponent (n+1)) :=
  degree_sensitive_gurvits_last p hp hs hc n hdegree

end CoefficientStability
