import CoefficientStability.SourceOriginalCubicKKT
import Mathlib.Analysis.Matrix.Spectrum

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 2200000
set_option backward.isDefEq.respectTransparency false

theorem source_original_cubic_common_commuting_multiplier (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (htpos : ∀ i,0 < t i) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A) :
    ∃ H : Matrix (Fin 3) (Fin 3) ℂ,H.IsHermitian ∧ ∀ i,H*A i=A i*H := by
  obtain ⟨H,hH,μ,S,hS,hcert⟩ := source_original_cubic_multiplier_certificate t ht htpos A hA hm
  refine ⟨H,hH,?_⟩
  intro i
  exact source_cubic_multiplier_commutes (t i) (μ i) (A i) H (S i)
    (hcert i).1 (hcert i).2.1 (hcert i).2.2

theorem source_hermitian_simple_multiplier_pairwise_commutation {n : ℕ}
    (H : Matrix (Fin n) (Fin n) ℂ) (hH : H.IsHermitian)
    (heig : Function.Injective hH.eigenvalues) (A : Fin 3 → Matrix (Fin n) (Fin n) ℂ)
    (hc : ∀ i,H*A i=A i*H) : ∀ i j,A i*A j=A j*A i := by
  let φ := Unitary.conjStarAlgAut ℂ (Matrix (Fin n) (Fin n) ℂ) (star hH.eigenvectorUnitary)
  let d : Fin n → ℂ := fun i => (hH.eigenvalues i : ℂ)
  have hd : Function.Injective d := Complex.ofReal_injective.comp heig
  have hφ : φ H=Matrix.diagonal d := hH.conjStarAlgAut_star_eigenvectorUnitary
  have hcφ (i : Fin 3) : Matrix.diagonal d*φ (A i)=φ (A i)*Matrix.diagonal d := by
    have h := congrArg φ (hc i)
    simpa only [map_mul,hφ] using h
  have hp := source_simple_multiplier_pairwise_commutation d hd (fun i => φ (A i)) hcφ
  intro i j
  apply (EquivLike.injective φ)
  simpa only [map_mul] using hp i j

end CoefficientStability
