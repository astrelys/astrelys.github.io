import CoefficientStability.SourceBalancedGateSymmetry

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

theorem source_three_two_zero_sum_bound (x : Fin 3 → ℝ) (hx : ∀ k,x k ≤ 1/2)
    (i j : Fin 3) (hne : i ≠ j) (hi : x i=0) (hj : x j=0) : (∑ k,x k) ≤ 1/2 := by
  have h0 := hx 0
  have h1 := hx 1
  have h2 := hx 2
  norm_num only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero]
  change x 0+(x 1+x 2) ≤ 1/2
  fin_cases i
  · change x 0=0 at hi
    fin_cases j
    · exact False.elim (hne rfl)
    · change x 1=0 at hj
      simpa only [hi,hj,zero_add] using h2
    · change x 2=0 at hj
      simpa only [hi,hj,zero_add,add_zero] using h1
  · change x 1=0 at hi
    fin_cases j
    · change x 0=0 at hj
      simpa only [hi,hj,zero_add] using h2
    · exact False.elim (hne rfl)
    · change x 2=0 at hj
      simpa only [hi,hj,zero_add,add_zero] using h0
  · change x 2=0 at hi
    fin_cases j
    · change x 0=0 at hj
      simpa only [hi,hj,zero_add,add_zero] using h1
    · change x 1=0 at hj
      simpa only [hi,hj,zero_add,add_zero] using h0
    · exact False.elim (hne rfl)

theorem source_balanced_gate_entry (i j : Fin 3) :
    sourceBalancedEscapeGate i j=if i=j then 0 else 1/2 := by
  fin_cases i <;> fin_cases j <;> norm_num [sourceBalancedEscapeGate]

theorem source_balanced_half_entries_are_gate (X : Matrix (Fin 3) (Fin 3) ℝ)
    (hX : X ∈ sourceTransportationPolytope (sourceEscapeTraces 1 1))
    (hv : ∀ i j,X i j=0 ∨ X i j=1/2) :
    ∃ c : Equiv.Perm (Fin 3),X=sourcePermutedMatrix sourceBalancedEscapeGate 1 c := by
  classical
  have hr := source_balanced_half_entry_row_recovery X hX hv
  choose f hf using hr
  have hi : Function.Injective f := by
    intro i j hij
    by_contra hne
    have hzeroi : X i (f i)=0 := by rw [hf];simp
    have hzeroj : X j (f i)=0 := by rw [hf,hij];simp
    have hbound (k : Fin 3) : X k (f i) ≤ 1/2 := by rcases hv k (f i) with h | h <;> rw [h] <;> norm_num
    have h := source_three_two_zero_sum_bound (fun k => X k (f i)) hbound i j hne hzeroi hzeroj
    change (∑ k,X k (f i)) ≤ 1/2 at h
    rw [hX.2.2 (f i)] at h
    norm_num at h
  let e : Equiv.Perm (Fin 3) := Equiv.ofBijective f ⟨hi,(Finite.injective_iff_surjective).mp hi⟩
  refine ⟨e.symm,?_⟩
  ext i j
  rw [hf]
  have hc : sourceBalancedEscapeGate i (e.symm j)=if i=e.symm j then 0 else 1/2 := by
    exact source_balanced_gate_entry i (e.symm j)
  change (if j=f i then 0 else 1/2)=sourceBalancedEscapeGate i (e.symm j)
  rw [hc]
  have he : i=e.symm j ↔ j=f i := by
    change i=e.symm j ↔ j=e i
    constructor
    · intro h
      simpa only [Equiv.apply_symm_apply] using (congrArg e h).symm
    · intro h
      rw [h]
      simp
  simp only [he]

theorem source_balanced_crossing_is_one_of_six_gates (X : Matrix (Fin 3) (Fin 3) ℝ)
    (hX : X ∈ sourceTransportationPolytope (sourceEscapeTraces 1 1))
    (hq : sourceEscapeQuadratic 1 1 (X-sourceEscapeCenter 1 1)=sourceEscapeQ 1 1)
    (hp : Matrix.permanent X ≤ 1/4) :
    ∃ c : Equiv.Perm (Fin 3),X=sourcePermutedMatrix sourceBalancedEscapeGate 1 c :=
  source_balanced_half_entries_are_gate X hX (source_balanced_crossing_actual_entry_values X hX hq hp)

end CoefficientStability
