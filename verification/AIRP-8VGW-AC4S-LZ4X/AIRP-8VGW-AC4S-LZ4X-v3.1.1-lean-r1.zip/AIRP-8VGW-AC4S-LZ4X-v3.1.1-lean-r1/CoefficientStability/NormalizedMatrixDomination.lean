import CoefficientStability.QuantitativeMatrixDomination

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem exists_dominated_doubly_stochastic_mass (hn : 0<n)
    (A : Matrix (Fin n) (Fin n) ℝ) (hA : ∀ i j,0≤A i j) (hrow : ∀ i,∑ j,A i j=1)
    (himb : matrixColumnImbalance A 1<2) :
    ∃ γ : ℝ,∃ D : Matrix (Fin n) (Fin n) ℝ,
      1-matrixColumnImbalance A 1/2≤γ ∧ 0<γ ∧ (∀ i j,0≤D i j) ∧
        (∀ i,∑ j,D i j=1) ∧ (∀ j,∑ i,D i j=1) ∧ (∀ i j,γ*D i j≤A i j) := by
  let i0 : Fin n := ⟨0,hn⟩
  obtain ⟨B,hB,hbound⟩ := exists_uniform_submatrix_mass_lower A hA hrow i0
  have hprop := uniformSubmatrix_properties A B i0 hB
  let γ := matrixRowMass B i0
  have hγ : 0<γ := by linarith
  let D : Matrix (Fin n) (Fin n) ℝ := fun i j => B i j/γ
  refine ⟨γ,D,hbound,hγ,?_,?_,?_,?_⟩
  · intro i j
    exact div_nonneg (hprop.1 i j) hγ.le
  · intro i
    change (∑ j,B i j/γ)=1
    rw [← Finset.sum_div,hprop.2.2.1]
    exact div_self (ne_of_gt hγ)
  · intro j
    change (∑ i,B i j/γ)=1
    rw [← Finset.sum_div,hprop.2.2.2]
    exact div_self (ne_of_gt hγ)
  · intro i j
    have he : γ*(B i j/γ)=B i j := by field_simp
    change γ*(B i j/γ)≤A i j
    rw [he]
    exact hprop.2.1 i j

end CoefficientStability
