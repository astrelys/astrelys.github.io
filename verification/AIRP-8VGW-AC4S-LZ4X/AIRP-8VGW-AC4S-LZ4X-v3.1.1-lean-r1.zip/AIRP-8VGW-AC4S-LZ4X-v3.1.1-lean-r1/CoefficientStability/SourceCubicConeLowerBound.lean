import CoefficientStability.SourceCubicConeGeometry
import CoefficientStability.SourceCubicConstraintOpenMap

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 2200000
set_option backward.isDefEq.respectTransparency false

theorem source_cubic_cone_linear_lower_bound (S : Module.Dual ℝ SourceCubicHermitianTuples) (C : ℝ)
    (hS : ∀ Y ∈ interior sourceCubicPSDCone,C ≤ S Y) :
    C ≤ 0 ∧ ∀ Y ∈ sourceCubicPSDCone,0 ≤ S Y := by
  have hne : (interior sourceCubicPSDCone).Nonempty :=
    ⟨sourceCubicPSDReference (fun _ => 1),source_cubic_psd_reference_interior _ (fun _ => by norm_num)⟩
  have hclosure := source_cubic_psd_cone_convex.closure_interior_eq_closure_of_nonempty_interior hne
  have hclosed : IsClosed {Y : SourceCubicHermitianTuples | C ≤ S Y} :=
    isClosed_le continuous_const S.continuous_of_finiteDimensional
  have hsubset : closure (interior sourceCubicPSDCone) ⊆ {Y | C ≤ S Y} := closure_minimal hS hclosed
  have hb (Y : SourceCubicHermitianTuples) (hY : Y ∈ sourceCubicPSDCone) : C ≤ S Y := by
    apply hsubset
    rw [hclosure]
    exact subset_closure hY
  have hzero : (0 : SourceCubicHermitianTuples) ∈ sourceCubicPSDCone := fun _ => Matrix.PosSemidef.zero
  refine ⟨by simpa using hb 0 hzero,?_⟩
  intro Y hY
  by_contra hn
  have hneg : S Y < 0 := lt_of_not_ge hn
  let a := (|C|+1)/(-S Y)
  have ha : 0 < a := div_pos (by positivity) (by linarith)
  have he : a*S Y=-(|C|+1) := by dsimp [a];field_simp [ne_of_lt hneg] <;> ring
  have h := hb (a • Y) (source_cubic_psd_cone_smul Y hY a ha.le)
  rw [map_smul,smul_eq_mul,he] at h
  linarith [neg_abs_le C]

end CoefficientStability
