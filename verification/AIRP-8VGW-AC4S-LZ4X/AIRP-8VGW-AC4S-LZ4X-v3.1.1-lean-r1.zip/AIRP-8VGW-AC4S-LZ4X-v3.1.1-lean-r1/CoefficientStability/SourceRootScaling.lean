import CoefficientStability.SourceSubsetRootSum

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n N : ℕ}

theorem actual_source_real_root_tuple (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (x : Fin n → ℝ) :
    ∃ roots : Fin N → ℝ,lineRestriction p x=∏ i : Fin N,(Polynomial.X+Polynomial.C (roots i)) := by
  obtain ⟨r,hcard,hfactor⟩ := normalized_stable_line_real_factors p x N hp hnorm hs
  obtain ⟨f,hf⟩ := real_multiset_fin_enumeration r
  subst N
  refine ⟨f,?_⟩
  rw [← hf] at hfactor
  simpa only [Multiset.map_coe,List.map_ofFn,Multiset.prod_coe,List.prod_ofFn,Function.comp_def] using hfactor

theorem actual_source_root_tuple_scaling (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (x : Fin n → ℝ) (roots : Fin N → ℝ)
    (hfactor : lineRestriction p x=∏ i : Fin N,(Polynomial.X+Polynomial.C (roots i)))
    (c : ℝ) (hc : c≠0) :
    lineRestriction p (c • x)=∏ i : Fin N,(Polynomial.X+Polynomial.C (c*roots i)) := by
  apply Polynomial.funext
  intro t
  rw [eval_lineRestriction_real]
  have heq : (fun i => c*((t/c)+x i))=(fun i => t+(c • x) i) := by
    funext i
    change c*(t/c+x i)=t+c*x i
    field_simp
    <;> ring
  have h := homogeneous_eval_real_scale p N hp c (fun i => (t/c)+x i)
  rw [heq] at h
  rw [h,← eval_lineRestriction_real,hfactor,Polynomial.eval_prod,Polynomial.eval_prod]
  simp only [Polynomial.eval_add,Polynomial.eval_X,Polynomial.eval_C]
  calc
    c^N*(∏ i : Fin N,(t/c+roots i))=(∏ _ : Fin N,c)*(∏ i : Fin N,(t/c+roots i)) := by simp
    _=∏ i : Fin N,c*(t/c+roots i) := (Finset.prod_mul_distrib).symm
    _=∏ i : Fin N,(t+c*roots i) := by
      apply Finset.prod_congr rfl
      intro i hi
      field_simp
      <;> ring

theorem sourceSubsetRootSumPolynomial_real_eval_of_factors (p : MvPolynomial (Fin n) ℝ) (N k : ℕ)
    (x : Fin n → ℝ) (roots : Fin N → ℝ)
    (hf : lineRestriction p x=∏ i : Fin N,(Polynomial.X+Polynomial.C (roots i))) :
    MvPolynomial.eval x (sourceSubsetRootSumPolynomial p N k)=
      ∏ s∈Finset.univ.powersetCard k,∑ i∈s,roots i := by
  have hfactor : MvPolynomial.eval₂ (Polynomial.C.comp (algebraMap ℝ ℝ))
      (fun i => Polynomial.X+Polynomial.C (x i)) p=∏ i : Fin N,(Polynomial.X+Polynomial.C (roots i)) := by
    simpa only [Algebra.algebraMap_self,RingHom.comp_id,lineRestriction] using hf
  convert! sourceSubsetRootSumPolynomial_eval_of_factorization p N k x roots hfactor using 1

end CoefficientStability
