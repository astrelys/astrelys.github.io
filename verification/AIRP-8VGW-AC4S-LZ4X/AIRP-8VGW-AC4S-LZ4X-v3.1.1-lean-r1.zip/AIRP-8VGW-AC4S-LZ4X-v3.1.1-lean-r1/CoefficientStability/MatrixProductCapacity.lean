import CoefficientStability.NormalizedMatrixDomination
import CoefficientStability.BalancedCapacity
import CoefficientStability.DiagonalStablePolynomial
import CoefficientStability.MultivariateCapacityElimination

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem diagonalPolynomial_eval_rows (A : Matrix (Fin n) (Fin n) ℝ) (x : Fin n → ℝ) :
    MvPolynomial.eval x (diagonalPencilPolynomial (fun i j => A i j))=∏ i,∑ j,A i j*x j := by
  rw [diagonalPencilPolynomial_eq_product]
  simp

theorem matrix_product_domination_capacity (A D : Matrix (Fin n) (Fin n) ℝ) (γ : ℝ)
    (hγ : 0≤γ) (hD : ∀ i j,0≤D i j) (hrow : ∀ i,∑ j,D i j=1)
    (hcol : ∀ j,∑ i,D i j=1) (hdom : ∀ i j,γ*D i j≤A i j) :
    γ^n≤multivariatePositiveCapacity (diagonalPencilPolynomial (fun i j => A i j)) := by
  have hcD := diagonalPolynomial_coeff_nonnegative (fun i j => D i j) hD
  have hnD := diagonalPolynomial_normalized (fun i j => D i j) hrow
  have hgD : ∀ j,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv j (diagonalPencilPolynomial (fun i j => D i j)))=1 := by
    intro j
    rw [diagonalPolynomial_gradient (fun i j => D i j) hrow j,hcol]
  have hcapD := paper_balanced_capacity_one (diagonalPencilPolynomial (fun i j => D i j)) hcD hnD hgD
  apply le_csInf
  · exact ⟨_,⟨⟨fun _ => 1,fun _ => by norm_num⟩,rfl⟩⟩
  · rintro y ⟨x,rfl⟩
    change γ^n≤MvPolynomial.eval x.val (diagonalPencilPolynomial (fun i j => A i j))/(∏ j,x.val j)
    have hX : 0<∏ j,x.val j := Finset.prod_pos (fun j hj => x.prop j)
    have hpointD : multivariatePositiveCapacity (diagonalPencilPolynomial (fun i j => D i j))≤
        MvPolynomial.eval x.val (diagonalPencilPolynomial (fun i j => D i j))/(∏ j,x.val j) :=
      csInf_le (multivariate_capacity_bddBelow _ hcD) ⟨x,rfl⟩
    rw [hcapD] at hpointD
    have hPD : (∏ j,x.val j)≤MvPolynomial.eval x.val (diagonalPencilPolynomial (fun i j => D i j)) := by
      simpa only [one_mul] using (le_div_iff₀ hX).mp hpointD
    have hprod : γ^n*MvPolynomial.eval x.val (diagonalPencilPolynomial (fun i j => D i j))≤
        MvPolynomial.eval x.val (diagonalPencilPolynomial (fun i j => A i j)) := by
      rw [diagonalPolynomial_eval_rows,diagonalPolynomial_eval_rows]
      have h := Finset.prod_le_prod₀ (s := Finset.univ)
        (f := fun i => γ*(∑ j,D i j*x.val j)) (g := fun i => ∑ j,A i j*x.val j)
        (fun i hi => mul_nonneg hγ (Finset.sum_nonneg (fun j hj => mul_nonneg (hD i j) (x.prop j).le)))
        (fun i hi => by
          rw [Finset.mul_sum]
          apply Finset.sum_le_sum
          intro j hj
          have hh := mul_le_mul_of_nonneg_right (hdom i j) (x.prop j).le
          simpa only [mul_assoc] using hh)
      simpa only [Finset.prod_mul_distrib,Finset.prod_const,Finset.card_univ,Fintype.card_fin] using h
    apply (le_div_iff₀ hX).mpr
    exact (mul_le_mul_of_nonneg_left hPD (pow_nonneg hγ n)).trans hprod

theorem row_stochastic_nearbalanced_capacity_lower (hn : 0<n) (A : Matrix (Fin n) (Fin n) ℝ)
    (hA : ∀ i j,0≤A i j) (hrow : ∀ i,∑ j,A i j=1) (himb : matrixColumnImbalance A 1<2) :
    (1-matrixColumnImbalance A 1/2)^n≤multivariatePositiveCapacity (diagonalPencilPolynomial (fun i j => A i j)) := by
  obtain ⟨γ,D,hbound,hγ,hD,hDrow,hDcol,hdom⟩ := exists_dominated_doubly_stochastic_mass hn A hA hrow himb
  have hq : 0≤1-matrixColumnImbalance A 1/2 := by linarith
  exact (pow_le_pow_left₀ hq hbound n).trans
    (matrix_product_domination_capacity A D γ hγ.le hD hDrow hDcol hdom)

theorem product_nearbalanced_capacity_source_bound (hn : 0<n) (A : Matrix (Fin n) (Fin n) ℝ)
    (hA : ∀ i j,0≤A i j) (hrow : ∀ i,∑ j,A i j=1) (himb : matrixColumnImbalance A 1<1) :
    (1-matrixColumnImbalance A 1)^n≤multivariatePositiveCapacity (diagonalPencilPolynomial (fun i j => A i j)) := by
  have hδ : 0≤matrixColumnImbalance A 1 := Finset.sum_nonneg (fun j hj => abs_nonneg _)
  have hq : 0≤1-matrixColumnImbalance A 1 := by linarith
  have hbase : 1-matrixColumnImbalance A 1≤1-matrixColumnImbalance A 1/2 := by linarith
  exact (pow_le_pow_left₀ hq hbase n).trans
    (row_stochastic_nearbalanced_capacity_lower hn A hA hrow (by linarith))

end CoefficientStability
