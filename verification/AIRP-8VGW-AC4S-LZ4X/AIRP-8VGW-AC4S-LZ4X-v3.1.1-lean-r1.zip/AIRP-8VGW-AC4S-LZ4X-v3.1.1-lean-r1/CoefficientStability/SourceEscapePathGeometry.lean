import CoefficientStability.SourceEscapeCurveSpace
import Mathlib.Analysis.Convex.PathConnected

noncomputable section
open scoped BigOperators Topology unitInterval
namespace CoefficientStability
set_option maxHeartbeats 3500000
set_option backward.isDefEq.respectTransparency false

theorem source_transportation_actual_convex (t : Fin 3 → ℝ) : Convex ℝ (sourceTransportationPolytope t) := by
  intro A hA B hB r s hr hs hrs
  refine ⟨?_,?_,?_⟩
  · intro i j
    exact add_nonneg (mul_nonneg hr (hA.1 i j)) (mul_nonneg hs (hB.1 i j))
  · intro i
    change (∑ j,(r*A i j+s*B i j))=t i
    rw [Finset.sum_add_distrib,← Finset.mul_sum,← Finset.mul_sum,hA.2.1 i,hB.2.1 i]
    rw [← add_mul,hrs,one_mul]
  · intro j
    change (∑ i,(r*A i j+s*B i j))=1
    rw [Finset.sum_add_distrib,← Finset.mul_sum,← Finset.mul_sum,hA.2.2 j,hB.2.2 j]
    simpa only [mul_one] using hrs

def sourceEscapePolyline (C S T : Matrix (Fin 3) (Fin 3) ℝ) : SourceEscapeCurve :=
  ((Path.segment C S).trans (Path.segment S T)).toContinuousMap

@[simp] theorem source_escape_polyline_zero (C S T : Matrix (Fin 3) (Fin 3) ℝ) : sourceEscapePolyline C S T 0=C := by
  exact ((Path.segment C S).trans (Path.segment S T)).source

@[simp] theorem source_escape_polyline_one (C S T : Matrix (Fin 3) (Fin 3) ℝ) : sourceEscapePolyline C S T 1=T := by
  exact ((Path.segment C S).trans (Path.segment S T)).target

theorem source_escape_polyline_property (C S T : Matrix (Fin 3) (Fin 3) ℝ)
    (P : Matrix (Fin 3) (Fin 3) ℝ → Prop)
    (h1 : ∀ u : unitInterval,P (Path.segment C S u))
    (h2 : ∀ u : unitInterval,P (Path.segment S T u)) :
    ∀ u : unitInterval,P (sourceEscapePolyline C S T u) := by
  intro u
  change P (((Path.segment C S).trans (Path.segment S T)) u)
  rw [Path.trans_apply]
  split_ifs <;> first | exact h1 _ | exact h2 _

theorem source_transportation_actual_segment_feasible (t : Fin 3 → ℝ)
    (A B : Matrix (Fin 3) (Fin 3) ℝ) (hA : A ∈ sourceTransportationPolytope t)
    (hB : B ∈ sourceTransportationPolytope t) (u : unitInterval) : Path.segment A B u ∈ sourceTransportationPolytope t := by
  change (AffineMap.lineMap A B (u : ℝ)) ∈ _
  rw [AffineMap.lineMap_apply]
  change (u : ℝ) • (B-A)+A ∈ _
  have he : (u : ℝ) • (B-A)+A=(1-(u : ℝ)) • A+(u : ℝ) • B := by module
  rw [he]
  exact source_transportation_actual_convex t hA hB (sub_nonneg.mpr u.2.2) u.2.1 (by ring)

theorem source_actual_segment_radial (A B : Matrix (Fin 3) (Fin 3) ℝ) (u : unitInterval) :
    Path.segment A B u=A+(u : ℝ) • (B-A) := by
  change (u : ℝ) • (B-A)+A=A+(u : ℝ) • (B-A)
  exact add_comm _ _

theorem source_escape_tangent_smul (A : Matrix (Fin 3) (Fin 3) ℝ) (hA : A ∈ sourceEscapeTangent) (r : ℝ) :
    r • A ∈ sourceEscapeTangent := by
  constructor
  · intro i
    simp only [Matrix.smul_apply,smul_eq_mul,← Finset.mul_sum,hA.1 i,mul_zero]
  · intro j
    simp only [Matrix.smul_apply,smul_eq_mul,← Finset.mul_sum,hA.2 j,mul_zero]

theorem source_escape_actual_permanent_homogeneous (A : Matrix (Fin 3) (Fin 3) ℝ) (r : ℝ) :
    Matrix.permanent (r • A)=r^3*Matrix.permanent A := by
  rw [source_permanent_three,source_permanent_three]
  simp only [Matrix.smul_apply,smul_eq_mul]
  ring

theorem source_escape_actual_radial_excess (a b : ℝ) (A : Matrix (Fin 3) (Fin 3) ℝ)
    (hA : A ∈ sourceEscapeTangent) (r : ℝ) :
    sourceEscapeExcess a b (sourceEscapeCenter a b+r • A)=
      r^2*sourceEscapeQuadratic a b A+r^3*Matrix.permanent A := by
  exact (source_escape_actual_cubic_expansion a b (r • A) (source_escape_tangent_smul A hA r)).trans
    (by rw [source_escape_quadratic_homogeneous,source_escape_actual_permanent_homogeneous])

theorem source_escape_cubic_shape_bounds (r : ℝ) (hr : r ∈ Set.Icc 0 1) :
    0 ≤ 3*r^2-2*r^3 ∧ 3*r^2-2*r^3 ≤ 1 := by
  have h0 := mul_nonneg (sq_nonneg r) (show 0 ≤ 3-2*r by linarith [hr.2])
  have h1 := mul_nonneg (sq_nonneg (1-r)) (show 0 ≤ 1+2*r by linarith [hr.1])
  constructor <;> nlinarith

end CoefficientStability
