import CoefficientStability.IndicatorSpectralMass
import CoefficientStability.ZeroSumSubsetBound

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem gradient_subset_mass_lower (t : Fin n → ℝ) (ht : ∑ i,t i=(n : ℝ)) (U : Finset (Fin n)) :
    (U.card : ℝ)-(∑ i,|t i-1|)/2≤∑ i∈U,t i := by
  classical
  have hv : (∑ i,(t i-1))=0 := by
    rw [Finset.sum_sub_distrib,ht]
    simp
  have h := zero_sum_subset_l1_half (fun i => t i-1) hv U
  rw [Finset.sum_sub_distrib] at h
  have hsum : (∑ _i∈U,(1 : ℝ))=(U.card : ℝ) := by simp
  rw [hsum] at h
  have hlow := (abs_le.mp h).1
  linarith

theorem source_indicator_nearbalanced_subset_lower (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (U : Finset (Fin n)) (roots : Fin n → ℝ)
    (hf : lineRestriction p (fun i => if i∈U then 1 else 0)=
      ∏ j : Fin n,(Polynomial.X+Polynomial.C (roots j))) (k : ℕ)
    (S : Finset (Fin n)) (hcard : S.card=k) :
    0≤(∑ j∈S,roots j) ∧
      (U.card : ℝ)-((n-k : ℕ) : ℝ)-
        (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)/2≤∑ j∈S,roots j := by
  have h := actual_source_indicator_subset_lower p n hn hp hs hnorm U roots hf k S hcard
  have hmass := gradient_subset_mass_lower (fun i => MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p))
    (homogeneous_gradient_total p n hp hnorm) U
  exact ⟨h.1,by linarith [h.2]⟩

end CoefficientStability
