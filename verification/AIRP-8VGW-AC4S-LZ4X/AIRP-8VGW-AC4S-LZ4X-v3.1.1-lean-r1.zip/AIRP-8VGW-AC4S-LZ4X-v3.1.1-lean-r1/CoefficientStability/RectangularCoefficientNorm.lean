import CoefficientStability.SourceWeightedGlobalGrowth
import CoefficientStability.QuadraticSourceCurveDistance

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {m N : ℕ}

theorem unit_monomial_stable (g : Fin m →₀ ℕ) :
    UpperHalfPlaneZeroFree (MvPolynomial.monomial g (1 : ℝ)) := by
  intro z hz
  have hne (i : Fin m) : z i≠0 := by
    intro he
    have h := hz i
    rw [he,Complex.zero_im] at h
    linarith
  simp only [MvPolynomial.eval₂_monomial,map_one,one_mul,Finsupp.prod]
  apply Finset.prod_ne_zero_iff.mpr
  intro i hi
  exact pow_ne_zero _ (hne i)

theorem rectangularSubstitution_unit_monomial_norm (B : Matrix (Fin m) (Fin N) ℝ)
    (hB : ∀ i j,0 ≤ B i j) (hrow : ∀ i,∑ j,B i j=1) (g : Fin m →₀ ℕ) :
    coefficientL1 (rectangularSubstitution B (MvPolynomial.monomial g (1 : ℝ)))=1 := by
  have hp : (MvPolynomial.monomial g (1 : ℝ)).IsHomogeneous g.degree := MvPolynomial.isHomogeneous_monomial 1 rfl
  have hnorm : MvPolynomial.eval (fun _ => 1) (MvPolynomial.monomial g (1 : ℝ))=1 := by simp only [eval_monomial_univ,one_pow,Finset.prod_const_one,one_mul]
  have hc := rectangularSubstitution_coeff_nonnegative B _ g.degree hp (unit_monomial_stable g) hnorm hB hrow
  have hn := rectangularSubstitution_normalized B _ hrow hnorm
  have hab (d : Fin N →₀ ℕ) : |(rectangularSubstitution B (MvPolynomial.monomial g (1 : ℝ))).coeff d|=
      (rectangularSubstitution B (MvPolynomial.monomial g (1 : ℝ))).coeff d := abs_of_nonneg (hc d)
  unfold coefficientL1
  simp_rw [hab]
  exact normalized_coefficient_mass _ hn

theorem rectangularSubstitution_coefficientL1_le (B : Matrix (Fin m) (Fin N) ℝ)
    (hB : ∀ i j,0 ≤ B i j) (hrow : ∀ i,∑ j,B i j=1) (p : MvPolynomial (Fin m) ℝ) :
    coefficientL1 (rectangularSubstitution B p) ≤ coefficientL1 p := by
  classical
  have hscalar (g : Fin m →₀ ℕ) : MvPolynomial.monomial g (p.coeff g)=
      MvPolynomial.C (p.coeff g)*MvPolynomial.monomial g 1 := by
    rw [MvPolynomial.C_mul_monomial,mul_one]
  have hex : rectangularSubstitution B p=∑ g ∈ p.support,
      MvPolynomial.C (p.coeff g)*rectangularSubstitution B (MvPolynomial.monomial g 1) := by
    conv_lhs => rw [p.as_sum]
    rw [map_sum]
    apply Finset.sum_congr rfl
    intro g hg
    rw [hscalar,map_mul,rectangularSubstitution_C]
  rw [hex]
  apply (coefficientL1_sum_le p.support _).trans_eq
  calc
    (∑ g ∈ p.support,coefficientL1 (MvPolynomial.C (p.coeff g)*rectangularSubstitution B (MvPolynomial.monomial g 1)))=
        ∑ g ∈ p.support,|p.coeff g| := by
      apply Finset.sum_congr rfl
      intro g hg
      rw [coefficientL1_C_mul,rectangularSubstitution_unit_monomial_norm B hB hrow,mul_one]
    _ = coefficientL1 p := rfl

end CoefficientStability
