import CoefficientStability.DeterminantPartialDerivative
import CoefficientStability.MixedSecondVariation

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ} {R : Type*} [CommRing R]

def determinantPencil (A : Fin n → Matrix (Fin n) (Fin n) R) :
    Matrix (Fin n) (Fin n) (MvPolynomial (Fin n) R) :=
  ∑ i,(MvPolynomial.X i : MvPolynomial (Fin n) R) • (A i).map MvPolynomial.C

def determinantPolynomial (A : Fin n → Matrix (Fin n) (Fin n) R) :
    MvPolynomial (Fin n) R := Matrix.det (determinantPencil A)

theorem determinantPencil_partial (A : Fin n → Matrix (Fin n) (Fin n) R)
    (i r c : Fin n) : pderiv i (determinantPencil A r c)=C (A i r c) := by
  classical
  simp only [determinantPencil,Matrix.sum_apply,Matrix.smul_apply,Matrix.map_apply,
    smul_eq_mul,map_sum,pderiv_mul,pderiv_C,mul_zero,add_zero,pderiv_X]
  simp [Pi.single_apply,eq_comm]

theorem determinantPencil_eval (A : Fin n → Matrix (Fin n) (Fin n) R) (x : Fin n → R) :
    (determinantPencil A).map (MvPolynomial.eval x)=∑ i,x i • A i := by
  apply Matrix.ext
  intro r c
  simp [determinantPencil,Matrix.sum_apply,Matrix.smul_apply,Matrix.map_apply,smul_eq_mul]

theorem determinantPolynomial_eval (A : Fin n → Matrix (Fin n) (Fin n) R) (x : Fin n → R) :
    MvPolynomial.eval x (determinantPolynomial A)=Matrix.det (∑ i,x i • A i) := by
  rw [determinantPolynomial,RingHom.map_det]
  change Matrix.det ((determinantPencil A).map (MvPolynomial.eval x))=_
  rw [determinantPencil_eval]

theorem determinantPolynomial_partial (A : Fin n → Matrix (Fin n) (Fin n) R) (i : Fin n) :
    pderiv i (determinantPolynomial A)=
      ∑ c,Matrix.det (Matrix.updateCol (determinantPencil A) c (fun r => C (A i r c))) := by
  rw [determinantPolynomial,partial_determinant_columns]
  simp only [determinantPencil_partial]

theorem matrix_eval_updateCol (M : Matrix (Fin n) (Fin n) (MvPolynomial (Fin n) R))
    (u : Fin n → MvPolynomial (Fin n) R) (c : Fin n) (x : Fin n → R) :
    (Matrix.updateCol M c u).map (MvPolynomial.eval x)=
      Matrix.updateCol (M.map (MvPolynomial.eval x)) c (fun r => MvPolynomial.eval x (u r)) := by
  classical
  apply Matrix.ext
  intro r k
  by_cases h : k=c <;> simp [Matrix.map_apply,Matrix.updateCol_apply,h]

theorem determinantPolynomial_gradient_one (A : Fin n → Matrix (Fin n) (Fin n) R)
    (hA : ∑ i,A i=1) (i : Fin n) :
    MvPolynomial.eval (fun _ => 1) (pderiv i (determinantPolynomial A))=Matrix.trace (A i) := by
  classical
  rw [determinantPolynomial_partial,map_sum]
  simp only [RingHom.map_det,RingHom.mapMatrix_apply,matrix_eval_updateCol,determinantPencil_eval,one_smul,hA,eval_C,
    det_identity_updateCol]
  rfl

end CoefficientStability
