import CoefficientStability.EliminationCoefficients

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability

theorem multivariatePositiveCapacity_zero (n : ℕ) :
    multivariatePositiveCapacity (0 : MvPolynomial (Fin n) ℝ)=0 := by
  letI : Nonempty {x : Fin n → ℝ // ∀ i,0<x i} := ⟨⟨fun _ => 1,fun _ => by norm_num⟩⟩
  simp [multivariatePositiveCapacity]

theorem multivariatePositiveCapacity_zero_dimension (p : MvPolynomial (Fin 0) ℝ) :
    multivariatePositiveCapacity p=p.coeff 0 := by
  letI : Nonempty {x : Fin 0 → ℝ // ∀ i,0<x i} := ⟨⟨Fin.elim0,fun i => Fin.elim0 i⟩⟩
  have hp : p=MvPolynomial.C (p.coeff 0) := by simpa using MvPolynomial.eq_C_of_isEmpty p
  have hf : (fun x : {x : Fin 0 → ℝ // ∀ i,0<x i} => MvPolynomial.eval x.val p/(∏ i,x.val i))=
      fun _ => p.coeff 0 := by
    funext x
    have he := congrArg (MvPolynomial.eval x.val) hp
    simp only [MvPolynomial.eval_C] at he
    rw [he]
    simp
  unfold multivariatePositiveCapacity
  rw [hf]
  simp

theorem squarefreeExponent_zero_dimension : squarefreeExponent 0=0 := by
  simp [squarefreeExponent]

end CoefficientStability
