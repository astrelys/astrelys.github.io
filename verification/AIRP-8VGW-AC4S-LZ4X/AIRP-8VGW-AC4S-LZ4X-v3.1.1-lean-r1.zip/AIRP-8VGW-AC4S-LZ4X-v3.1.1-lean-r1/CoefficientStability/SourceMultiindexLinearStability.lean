import CoefficientStability.SourceCloneIsometry

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {m : ℕ}

def sourceSquarefreeLinearCertificate (N : ℕ) (ε c : ℝ) : Prop :=
  ∀ (t : Fin N → ℝ) (p : MvPolynomial (Fin N) ℝ),p.IsHomogeneous N →
    UpperHalfPlaneZeroFree p → MvPolynomial.eval (fun _ => 1) p=1 →
    (∑ i,t i)=N → (∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) →
    (∑ i,|t i-1|) < ε →
    c*coefficientL1 (p-scalarPower t N) ≤ p.coeff (squarefreeExponent N)-sourceVn N*(∏ i,t i)

theorem sourceSquarefreeLinearCertificate_exists (N : ℕ) (hN : 2 ≤ N) :
    ∃ ε c : ℝ,0 < ε ∧ 0 < c ∧ sourceSquarefreeLinearCertificate N ε c :=
  source_linear_coefficient_stability_exists hN

theorem source_multiindex_linear_transfer (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (ε c : ℝ) (hsource : sourceSquarefreeLinearCertificate (sourceCloneCount α) ε c)
    (p : MvPolynomial (Fin m) ℝ) (hp : p.IsHomogeneous (sourceCloneCount α))
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (t : Fin m → ℝ) (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hnear : (∑ i,|t i-(α i : ℝ)|) < ε) :
    c/sourceCloneCoefficientWeight α*coefficientL1 (p-scalarPower t (sourceCloneCount α)) ≤
      p.coeff (sourceMultiExponent α)-sourceMultiIndexBaseline α t ∧
    (2*c/sourceCloneCoefficientWeight α)*finiteExponentTotalVariation p (scalarPower t (sourceCloneCount α)) ≤
      p.coeff (sourceMultiExponent α)-sourceMultiIndexBaseline α t := by
  obtain ⟨hph,hps,hpn,hpc,hpg⟩ := sourceClonePolynomial_source_hypotheses α hα p hp hs hnorm t hgrad
  have htotal : (∑ j,sourceClonedGradient α t j)=sourceCloneCount α := by
    have h := homogeneous_gradient_total (sourceClonePolynomial α p) (sourceCloneCount α) hph hpn
    simpa only [hpg] using h
  have hclone : (∑ j,|sourceClonedGradient α t j-1|) < ε := by
    simpa only [sourceClonedGradient,sourceCloneGradient_l1 α hα t] using hnear
  have hg := hsource (sourceClonedGradient α t) (sourceClonePolynomial α p) hph hps hpn htotal hpg hclone
  rw [← sourceClonePolynomial_scalarPower,sourceClonePolynomial_distance_isometry α hα,
    sourceClonePolynomial_squarefree_coefficient] at hg
  have href : sourceVn (sourceCloneCount α)*(∏ j,sourceClonedGradient α t j)=
      sourceCloneCoefficientWeight α*sourceMultiIndexBaseline α t := by
    rw [← sourceCloneReference_coefficient_identity,sourceScalarPower_multiindex_baseline]
    rfl
  rw [href,← mul_sub] at hg
  have hK := sourceCloneCoefficientWeight_pos α hα
  have hbound : c/sourceCloneCoefficientWeight α*coefficientL1 (p-scalarPower t (sourceCloneCount α)) ≤
      p.coeff (sourceMultiExponent α)-sourceMultiIndexBaseline α t := by
    calc
      _ = (c*coefficientL1 (p-scalarPower t (sourceCloneCount α)))/sourceCloneCoefficientWeight α := by ring
      _ ≤ _ := (div_le_iff₀ hK).mpr (by simpa only [mul_comm] using hg)
  refine ⟨hbound,?_⟩
  rw [finiteExponentTotalVariation_eq_half_coefficientL1]
  convert! hbound using 1 <;> ring

theorem source_multiindex_linear_stability_uniform (N : ℕ) (hN : 2 ≤ N) :
    ∃ ε c : ℝ,0 < ε ∧ 0 < c ∧ sourceSquarefreeLinearCertificate N ε c ∧
      ∀ (m : ℕ) (α : Fin m → ℕ), (∀ i,0 < α i) → sourceCloneCount α=N →
        ∀ (p : MvPolynomial (Fin m) ℝ),p.IsHomogeneous N → UpperHalfPlaneZeroFree p →
          MvPolynomial.eval (fun _ => 1) p=1 → ∀ t : Fin m → ℝ,
          (∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) →
          (∑ i,|t i-(α i : ℝ)|) < ε →
          c/sourceCloneCoefficientWeight α*coefficientL1 (p-scalarPower t N) ≤
            p.coeff (sourceMultiExponent α)-sourceMultiIndexBaseline α t ∧
          (2*c/sourceCloneCoefficientWeight α)*finiteExponentTotalVariation p (scalarPower t N) ≤
            p.coeff (sourceMultiExponent α)-sourceMultiIndexBaseline α t := by
  obtain ⟨ε,c,hε,hc,hsource⟩ := sourceSquarefreeLinearCertificate_exists N hN
  refine ⟨ε,c,hε,hc,hsource,?_⟩
  intro m α hα hcount p hp hs hnorm t hgrad hnear
  subst N
  exact source_multiindex_linear_transfer α hα ε c hsource p hp hs hnorm t hgrad hnear

theorem source_multiindex_probability_laws (α : Fin m → ℕ) (hN : 2 ≤ sourceCloneCount α)
    (p : MvPolynomial (Fin m) ℝ) (hp : p.IsHomogeneous (sourceCloneCount α))
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (t : Fin m → ℝ) (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) :
    (∀ g,0 ≤ p.coeff g) ∧ (∑ g ∈ p.support,p.coeff g)=1 ∧
      (∀ g,0 ≤ (scalarPower t (sourceCloneCount α)).coeff g) ∧
      (∑ g ∈ (scalarPower t (sourceCloneCount α)).support,(scalarPower t (sourceCloneCount α)).coeff g)=1 := by
  have hc := normalized_homogeneous_stable_coeff_nonneg p _ hp hs hnorm
  have ht : (∑ i,t i)=sourceCloneCount α := by
    simpa only [hgrad] using homogeneous_gradient_total p (sourceCloneCount α) hp hnorm
  have href := multinomial_coefficient_probability t (sourceCloneCount α) (by omega) ht
    (actual_gradient_nonneg p t hc hgrad)
  exact ⟨hc,normalized_coefficient_mass p hnorm,href.1,href.2.1⟩

end CoefficientStability
