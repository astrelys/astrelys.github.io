import CoefficientStability.CumulativeIndicatorInput

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def suffixSpectralLower (k : ℕ) (j : Fin n) (ε : ℝ) : ℝ :=
  if j.val=0 then (k : ℝ) else if j.val < k then ((k-j.val : ℕ) : ℝ)-ε else 0

theorem suffixSpectralLower_relative (k : ℕ) (j : Fin n) (ε : ℝ) (hε : 0≤ε) :
    (1-ε)*((k-j.val : ℕ) : ℝ)≤suffixSpectralLower k j ε := by
  classical
  by_cases hj0 : j.val=0
  · simp only [suffixSpectralLower,hj0,ite_true,Nat.sub_zero]
    nlinarith [mul_nonneg hε (show 0≤(k : ℝ) by positivity)]
  · by_cases hjk : j.val < k
    · simp only [suffixSpectralLower,if_neg hj0,if_pos hjk]
      have hcount : 1≤((k-j.val : ℕ) : ℝ) := by exact_mod_cast (show 1≤k-j.val by omega)
      nlinarith [mul_nonneg hε (sub_nonneg.mpr hcount)]
    · simp only [suffixSpectralLower,if_neg hj0,if_neg hjk,
        Nat.sub_eq_zero_of_le (Nat.le_of_not_gt hjk),Nat.cast_zero,mul_zero,le_refl]

theorem suffixSpectralLower_weighted_prefix (c : Fin n → ℝ) (hc : ∀ j,0≤c j)
    (k : ℕ) (hk : k≤n) (ε : ℝ) (hε : 0≤ε) :
    (1-ε)*finiteInputPrefix (cumulativeInput c) k≤∑ j,c j*suffixSpectralLower k j ε := by
  rw [cumulativeInput_prefix_mass c k hk,Finset.mul_sum]
  apply Finset.sum_le_sum
  intro j hj
  have h := mul_le_mul_of_nonneg_left (suffixSpectralLower_relative k j ε hε) (hc j)
  nlinarith

end CoefficientStability
