import CoefficientStability.PositiveCapacityPolynomial
import CoefficientStability.PaperRatioGradient
noncomputable section
open scoped BigOperators
namespace CoefficientStability

theorem source_univariate_capacity_loss {n : ℕ}
    (f : Polynomial ℝ) (b : Fin n → ℝ) (zstar : ℝ)
    (hn : 2 ≤ n) (hc : 0 < f.eval 0) (hb : ∀ i,0 < b i) (hz : 0 < zstar)
    (hfactor : ∀ z : ℝ,f.eval z=f.eval 0*∏ i,(1+b i*z))
    (hmin : ∀ z : ℝ,0 < z → f.eval zstar/zstar ≤ f.eval z/z) :
    0 < positiveDomainCapacity f ∧
      (∑ i,b i*zstar/(1+b i*zstar))=1 ∧
      f.derivative.eval 0/positiveDomainCapacity f ≥
        capacityG n*(1+((∑ i,(b i*zstar/(1+b i*zstar))^2)-1/(n : ℝ))/128) := by
  refine ⟨?_,positive_prefactor_univariate_loss_general f b zstar hn hc hb hz hfactor hmin⟩
  rw [positiveDomainCapacity_at_minimum f zstar hz hmin,hfactor]
  apply div_pos _ hz
  apply mul_pos hc
  apply Finset.prod_pos
  intro i hi
  nlinarith [hb i]

end CoefficientStability
