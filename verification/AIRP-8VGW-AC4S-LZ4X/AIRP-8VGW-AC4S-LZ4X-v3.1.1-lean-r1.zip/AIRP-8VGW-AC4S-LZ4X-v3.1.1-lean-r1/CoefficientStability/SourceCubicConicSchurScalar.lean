import CoefficientStability.SourceCubicConicPencil

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

theorem source_cubic_conic_schur_completion_scalar (h X Y Z f : ℝ) (U V : ℂ)
    (hX : X≠0) (hq : X*Z-Y^2≠0)
    (he : f=(X*Z-Y^2)*h-X*Complex.normSq U-Z*Complex.normSq V-
      Y*(U*star V+star U*V).re) :
    (h : ℂ)=(f/(X*Z-Y^2) : ℝ)+
      star (-((X : ℂ)*star U+(Y : ℂ)*star V)/((X*Z-Y^2 : ℝ) : ℂ))*
        ((X*Z-Y^2)/X : ℝ)*(-((X : ℂ)*star U+(Y : ℂ)*star V)/((X*Z-Y^2 : ℝ) : ℂ))+
      star (-star V/(X : ℂ))*(X : ℂ)*(-star V/(X : ℂ)) := by
  have hh : h=(f+X*Complex.normSq U+Z*Complex.normSq V+
      Y*(U*star V+star U*V).re)/(X*Z-Y^2) := by
    apply (eq_div_iff hq).mpr
    nlinarith [he]
  have hqC : ((X*Z-Y^2 : ℝ) : ℂ)≠0 := Complex.ofReal_ne_zero.mpr hq
  have hXC : (X : ℂ)≠0 := Complex.ofReal_ne_zero.mpr hX
  have hc : ((U*star V+star U*V).re : ℂ)=U*star V+star U*V := by
    apply Complex.ext
    · simp
    · simp [Complex.mul_im]
      ring
  calc
    (h : ℂ)=(((f+X*Complex.normSq U+Z*Complex.normSq V+
      Y*(U*star V+star U*V).re)/(X*Z-Y^2) : ℝ) : ℂ) := congrArg Complex.ofReal hh
    _=_ := by
      push_cast
      rw [Complex.normSq_eq_conj_mul_self,Complex.normSq_eq_conj_mul_self,hc]
      simp only [star_div₀,star_neg,star_add,star_mul,star_star,Complex.star_def, map_div, map_neg, map_add, map_mul, map_sub, map_pow, Complex.conj_ofReal, Complex.conj_conj]
      have hqC' : (X : ℂ)*(Z : ℂ)-(Y : ℂ)^2≠0 := by exact_mod_cast hq
      field_simp [hqC', hXC]
      ring

end CoefficientStability
