import CoefficientStability.SourceL1LowerRootGeometry
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.Calculus.Deriv.MeanValue

noncomputable section
open scoped Topology
open Filter
namespace CoefficientStability
set_option maxHeartbeats 1200000

theorem source_cubic_H_curve_hasDerivAt (g : ℝ → ℝ) (g' d : ℝ) (hg : HasDerivAt g g' d) :
    HasDerivAt (fun x => sourceCubicH x (g x)) (sourceCubicHd d (g d)+sourceCubicHh d (g d)*g') d := by
  have hid := hasDerivAt_id d
  have hA := ((hasDerivAt_const d (1 : ℝ)).sub (hid.const_mul 10)).sub ((hid.pow 2).const_mul 12)
  have hB := ((hasDerivAt_const d (2 : ℝ)).add (hid.const_mul 30)).sub ((hid.pow 2).const_mul 12)
  have hC := ((hasDerivAt_const d (4 : ℝ)).mul ((hasDerivAt_const d (2 : ℝ)).sub hid)).mul (hg.pow 2)
  have h := (hA.add (hB.mul hg)).sub hC
  convert h using 1
  · funext x
    dsimp [sourceCubicH]
  · dsimp [sourceCubicHd,sourceCubicHh]
    ring

theorem source_cubic_lower_root_continuousAt (d : ℝ) (hd : 0 ≤ d) (hd3 : d ≤ 1/3) :
    ContinuousAt sourceCubicLowerRoot d := by
  have hnum : Continuous (fun x : ℝ => sourceCubicHSlope x-Real.sqrt (sourceCubicHDiscriminant x)) := by
    unfold sourceCubicHDiscriminant sourceCubicHIntercept sourceCubicHSlope
    fun_prop
  have hden : Continuous (fun x : ℝ => 8*(2-x)) := by fun_prop
  exact hnum.continuousAt.div hden.continuousAt (by nlinarith)

theorem source_cubic_lower_root_continuousOn : ContinuousOn sourceCubicLowerRoot (Set.Icc (0 : ℝ) (1/3)) :=
  fun d hd => (source_cubic_lower_root_continuousAt d hd.1 hd.2).continuousWithinAt

theorem source_cubic_lower_root_differentiableAt (d : ℝ) (hd : 0 < d) (hd3 : d < 1/3) :
    DifferentiableAt ℝ sourceCubicLowerRoot d := by
  have hD := source_cubic_H_discriminant_positive d hd.le hd3.le
  have hdisc : DifferentiableAt ℝ sourceCubicHDiscriminant d := by
    unfold sourceCubicHDiscriminant sourceCubicHSlope sourceCubicHIntercept
    fun_prop
  have hB : DifferentiableAt ℝ sourceCubicHSlope d := by unfold sourceCubicHSlope;fun_prop
  have hden : DifferentiableAt ℝ (fun x : ℝ => 8*(2-x)) d := by fun_prop
  exact (hB.sub (hdisc.sqrt (ne_of_gt hD))).div hden (by nlinarith)

theorem source_cubic_lower_root_derivative_identity (d : ℝ) (hd : 0 < d) (hd3 : d < 1/3) :
    sourceCubicHd d (sourceCubicLowerRoot d)+sourceCubicHh d (sourceCubicLowerRoot d)*deriv sourceCubicLowerRoot d=0 := by
  have hchain := source_cubic_H_curve_hasDerivAt sourceCubicLowerRoot (deriv sourceCubicLowerRoot d) d
    (source_cubic_lower_root_differentiableAt d hd hd3).hasDerivAt
  have he : (fun x : ℝ => sourceCubicH x (sourceCubicLowerRoot x))=ᶠ[𝓝 d] (fun _ => 0) := by
    filter_upwards [isOpen_Ioo.mem_nhds (show d ∈ Set.Ioo (0 : ℝ) (1/3) from ⟨hd,hd3⟩)] with x hx
    exact source_cubic_lower_root_zero x hx.1.le hx.2.le
  have hzero := (hasDerivAt_const d (0 : ℝ)).congr_of_eventuallyEq he
  exact hchain.unique hzero

theorem source_cubic_lower_root_derivative_positive (d : ℝ) (hd : 0 < d) (hd3 : d < 1/3) :
    0 < deriv sourceCubicLowerRoot d := by
  have he := source_cubic_lower_root_derivative_identity d hd hd3
  have hl := source_cubic_lower_root_lower_bound d hd.le hd3.le
  have hu := source_cubic_lower_root_upper_bound d hd.le hd3.le
  have hHd := source_cubic_Hd_strip_bound d (sourceCubicLowerRoot d) hd.le hd3.le hl hu
  have hHh : 0 < sourceCubicHh d (sourceCubicLowerRoot d) := by
    rw [source_cubic_lower_root_Hh d hd.le hd3.le]
    exact Real.sqrt_pos.mpr (source_cubic_H_discriminant_positive d hd.le hd3.le)
  by_contra hh
  have hm := mul_nonpos_of_nonneg_of_nonpos hHh.le (le_of_not_gt hh)
  linarith

theorem source_cubic_lower_root_strictMonoOn : StrictMonoOn sourceCubicLowerRoot (Set.Icc (0 : ℝ) (1/3)) := by
  apply strictMonoOn_of_deriv_pos (convex_Icc 0 (1/3)) source_cubic_lower_root_continuousOn
  intro d hd
  have hi : d ∈ Set.Ioo (0 : ℝ) (1/3) := by simpa only [interior_Icc] using hd
  exact source_cubic_lower_root_derivative_positive d hi.1 hi.2

theorem source_cubic_lower_root_dstar : sourceCubicLowerRoot sourceCubicDStar=0 := by
  obtain ⟨hd,hd3⟩ := source_cubic_dstar_bounds
  have hB : 0 < sourceCubicHSlope sourceCubicDStar := by
    have hm := mul_nonneg hd.le (by linarith : 0 ≤ 1/3-sourceCubicDStar)
    unfold sourceCubicHSlope
    nlinarith [hm]
  have hA : sourceCubicHIntercept sourceCubicDStar=0 := source_cubic_dstar_equation
  have hD : sourceCubicHDiscriminant sourceCubicDStar=(sourceCubicHSlope sourceCubicDStar)^2 := by
    unfold sourceCubicHDiscriminant
    rw [hA,mul_zero,add_zero]
  unfold sourceCubicLowerRoot
  rw [hD,Real.sqrt_sq_eq_abs,abs_of_pos hB]
  simp

theorem source_cubic_lower_root_zero_iff_dstar (d : ℝ) (hd : 0 ≤ d) (hd3 : d ≤ 1/3) :
    sourceCubicLowerRoot d=0 ↔ d=sourceCubicDStar := by
  constructor
  · intro hz
    obtain ⟨hs,hs3⟩ := source_cubic_dstar_bounds
    apply source_cubic_lower_root_strictMonoOn.injOn ⟨hd,hd3⟩ ⟨hs.le,hs3.le⟩
    rw [hz,source_cubic_lower_root_dstar]
  · intro he
    rw [he,source_cubic_lower_root_dstar]

end CoefficientStability
