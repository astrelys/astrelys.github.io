import CoefficientStability.TiltNormBounds

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def categoricalVariance (π v : Fin n → ℝ) : ℝ :=
  (∑ j,π j*v j^2)-(∑ j,π j*v j)^2

theorem weighted_square_shift (π v : Fin n → ℝ) (c : ℝ) :
    (∑ j,π j*(v j-c)^2)=(∑ j,π j*v j^2)-2*c*(∑ j,π j*v j)+c^2*(∑ j,π j) := by
  simp only [Finset.mul_sum,← Finset.sum_sub_distrib,← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro j hj
  ring

theorem categoricalVariance_centered (π v : Fin n → ℝ) (hπ : ∑ j,π j=1) :
    categoricalVariance π v=∑ j,π j*(v j-(∑ k,π k*v k))^2 := by
  rw [weighted_square_shift,hπ]
  unfold categoricalVariance
  ring

theorem categoricalVariance_uniform_lower (π v : Fin n → ℝ) (ε : ℝ)
    (hε : 0≤ε) (hπ : ∑ j,π j=1) (hmin : ∀ j,ε≤π j) (hv : ∑ j,v j=0) :
    ε*(∑ j,v j^2)≤categoricalVariance π v := by
  rw [categoricalVariance_centered π v hπ]
  have hweight : ε*(∑ j,(v j-(∑ k,π k*v k))^2)≤
      ∑ j,π j*(v j-(∑ k,π k*v k))^2 := by
    rw [Finset.mul_sum]
    exact Finset.sum_le_sum (fun j hj => mul_le_mul_of_nonneg_right (hmin j) (sq_nonneg _))
  have he : (∑ j,(v j-(∑ k,π k*v k))^2)=
      (∑ j,v j^2)+(n : ℝ)*(∑ k,π k*v k)^2 := by
    have hexp := weighted_square_shift (fun _ : Fin n => (1 : ℝ)) v (∑ k,π k*v k)
    simpa only [one_mul,hv,mul_zero,sub_zero,Finset.sum_const,Finset.card_univ,
      Fintype.card_fin,nsmul_eq_mul,mul_one,mul_comm,zero_mul] using hexp
  rw [he] at hweight
  have hnonneg := mul_nonneg hε (mul_nonneg (Nat.cast_nonneg (α := ℝ) n) (sq_nonneg (∑ k,π k*v k)))
  nlinarith only [hweight,hnonneg]

end CoefficientStability
