import CoefficientStability.SourceHermitianTraceDuality
import CoefficientStability.SourceCubicComplementarity

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 2000000
set_option backward.isDefEq.respectTransparency false

theorem source_psd_trace_self_duality {n : ℕ} (S : Matrix (Fin n) (Fin n) ℂ) (hS : S.IsHermitian) :
    S.PosSemidef ↔ ∀ X : Matrix (Fin n) (Fin n) ℂ,X.PosSemidef → 0 ≤ (Matrix.trace (S*X)).re := by
  constructor
  · intro hp X hX
    exact source_psd_trace_pairing_nonnegative S X hp hX
  · intro hp
    apply Matrix.PosSemidef.of_dotProduct_mulVec_nonneg hS
    intro v
    have hn := hp (Matrix.vecMulVec v (star v)) (Matrix.posSemidef_vecMulVec_self_star v)
    rw [Matrix.mul_vecMulVec,Matrix.trace_vecMulVec,dotProduct_comm] at hn
    exact Complex.nonneg_iff.mpr ⟨hn,(hS.im_star_dotProduct_mulVec_self v).symm⟩

theorem source_hermitian_trace_product_im_zero {n : ℕ} (S X : Matrix (Fin n) (Fin n) ℂ)
    (hS : S.IsHermitian) (hX : X.IsHermitian) : (Matrix.trace (S*X)).im=0 := by
  have hh := Matrix.trace_conjTranspose (S*X)
  rw [Matrix.conjTranspose_mul,hS.eq,hX.eq,Matrix.trace_mul_comm X S] at hh
  have h := congrArg Complex.im hh
  simp only [Complex.star_def,Complex.conj_im] at h
  linarith

theorem source_psd_real_trace_pairing_zero_products {n : ℕ} (S X : Matrix (Fin n) (Fin n) ℂ)
    (hS : S.PosSemidef) (hX : X.PosSemidef) (hz : (Matrix.trace (S*X)).re=0) : S*X=0 ∧ X*S=0 := by
  have he : Matrix.trace (S*X)=0 := by
    apply Complex.ext
    · exact hz
    · exact source_hermitian_trace_product_im_zero S X hS.isHermitian hX.isHermitian
  exact source_psd_trace_pairing_zero_products S X hS hX he

theorem source_psd_tuple_complementarity {n k : ℕ}
    (S X : Fin k → Matrix (Fin n) (Fin n) ℂ)
    (hS : ∀ i,(S i).PosSemidef) (hX : ∀ i,(X i).PosSemidef)
    (hz : (∑ i,(Matrix.trace (S i*X i)).re)=0) : ∀ i,S i*X i=0 ∧ X i*S i=0 := by
  have hn : ∀ i ∈ Finset.univ,0 ≤ (Matrix.trace (S i*X i)).re :=
    fun i _ => source_psd_trace_pairing_nonnegative (S i) (X i) (hS i) (hX i)
  have he := (Finset.sum_eq_zero_iff_of_nonneg hn).mp hz
  intro i
  exact source_psd_real_trace_pairing_zero_products (S i) (X i) (hS i) (hX i) (he i (Finset.mem_univ i))

end CoefficientStability
