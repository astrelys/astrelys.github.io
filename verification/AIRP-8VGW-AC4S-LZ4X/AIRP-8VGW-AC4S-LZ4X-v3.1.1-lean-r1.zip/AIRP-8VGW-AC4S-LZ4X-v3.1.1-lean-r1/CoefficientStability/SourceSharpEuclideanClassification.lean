import CoefficientStability.SourceSharpEuclideanInequality
import CoefficientStability.SourceMatchingEqualityProfile
import CoefficientStability.SourceEuclideanSharpness

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 1200000

def sourceEuclideanEqualityDescription (t : Fin 3 → ℝ) (B : Matrix (Fin 3) (Fin 3) ℝ) : Prop :=
  B=sourcePermanentReference t ∨ ∃ (r c : Equiv.Perm (Fin 3)) (z : ℝ),0 ≤ z ∧ z ≤ 1/4 ∧
    sourcePermutedTraces t r=sourceEuclideanExceptionalTraces ∧ sourcePermutedMatrix B r c=sourceEuclideanBoundaryFamily z

theorem source_permuted_reference (t : Fin 3 → ℝ) (r c : Equiv.Perm (Fin 3)) :
    sourcePermutedMatrix (sourcePermanentReference t) r c=sourcePermanentReference (sourcePermutedTraces t r) := by
  ext i j
  rfl

theorem source_permuted_matrix_composition (B : Matrix (Fin 3) (Fin 3) ℝ) (r c a b : Equiv.Perm (Fin 3)) :
    sourcePermutedMatrix (sourcePermutedMatrix B r c) a b=sourcePermutedMatrix B (r*a) (c*b) := by
  ext i j
  rfl

theorem source_permuted_traces_composition (t : Fin 3 → ℝ) (r a : Equiv.Perm (Fin 3)) :
    sourcePermutedTraces (sourcePermutedTraces t r) a=sourcePermutedTraces t (r*a) := by
  funext i
  rfl

theorem source_euclidean_canonical_equality (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hbox : ∀ i,1/2 ≤ t i ∧ t i ≤ 3/2) (hr : (∑ i,(t i-1)^2) ≤ 3/8)
    (B : Matrix (Fin 3) (Fin 3) ℝ) (hB : B ∈ sourceTransportationPolytope t)
    (hmin : IsMinOn Matrix.permanent (sourceTransportationPolytope t) B)
    (hcase : sourceTernaryRealZeroPattern B) (hobj : Matrix.permanent B=sourceTernaryBaseline t) :
    sourceEuclideanEqualityDescription t B := by
  have hlocal := hmin.isLocalMinOn
  unfold sourceTernaryRealZeroPattern at hcase
  unfold sourceEuclideanEqualityDescription
  rcases hcase with h0 | h1 | h2 | h3 | h4 | h5
  · left
    exact (source_ternary_interior_minimum_gap t ht hbox B hB h0 hlocal).2.mp hobj
  · obtain ⟨h00,hpos⟩ := h1
    have he := source_actual_one_zero_chart t B hB h00
    have hp : ∀ q ∈ sourceOneZeroEntrySet,0 < sourceTernaryOneZero t (B 0 1) (B 1 0) (B 1 1) q.1 q.2 := by rw [← he];exact hpos
    have hl : IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) (sourceTernaryOneZero t (B 0 1) (B 1 0) (B 1 1)) := by rw [← he];exact hlocal
    have ho : Matrix.permanent (sourceTernaryOneZero t (B 0 1) (B 1 0) (B 1 1))=sourceTernaryBaseline t := by rw [← he];exact hobj
    obtain ⟨htp,ha,hb,hz,hz4,hshape⟩ := source_one_zero_equality_classification t ht (B 0 1) (B 1 0) (B 1 1) hp hl ho
    have hs : B=sourceEuclideanBoundaryFamily (B 1 1) := he.trans hshape
    right
    refine ⟨1,1,B 1 1,hz.le,hz4.le,?_,?_⟩
    · funext i
      change t i=sourceEuclideanExceptionalTraces i
      exact congrFun htp i
    · simpa [sourcePermutedMatrix,Matrix.submatrix_apply] using hs
  · obtain ⟨h00,h11,hpos⟩ := h2
    have he := source_actual_separated_zero_chart t B hB h00 h11
    have hp : ∀ q ∈ sourceSeparatedEntrySet,0 < sourceTernarySeparatedZeros t (B 0 1) (B 1 0) q.1 q.2 := by rw [← he];exact hpos
    have hl : IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) (sourceTernarySeparatedZeros t (B 0 1) (B 1 0)) := by rw [← he];exact hlocal
    have h := source_ternary_separated_minimum_strict_gap t ht (B 0 1) (B 1 0) hp hl hr
    rw [← he,hobj] at h
    exact False.elim (lt_irrefl _ h)
  · have he := source_actual_matching_chart t B hB h3
    have ho : Matrix.permanent (sourceTernaryMatchingZeros t (B 0 1))=sourceTernaryBaseline t := by rw [← he];exact hobj
    obtain ⟨r,c,htp,hshape⟩ := source_matching_equality_full_profile t ht hr (B 0 1) ho
    rw [← he] at hshape
    right
    exact ⟨r,c,0,le_rfl,by norm_num,htp,hshape⟩
  · obtain ⟨h00,h01⟩ := h4
    have he := source_actual_double_row_chart t B hB h00 h01
    have h := source_ternary_double_row_strict_bound t ht hbox (B 1 0+B 1 1) (B 1 0) (by rw [← he];exact hB.1)
    rw [← he,hobj,sub_self] at h
    norm_num at h
  · obtain ⟨h00,h10⟩ := h5
    let r : Equiv.Perm (Fin 3) := Equiv.swap 0 2
    let E := sourcePermutedMatrix B r 1
    let s := sourcePermutedTraces t r
    have hE : E ∈ sourceTransportationPolytope s := source_permuted_feasible t B hB r 1
    have hs : (∑ i,s i)=3 := (source_permuted_trace_sum t r).trans ht
    have hsb : ∀ i,1/2 ≤ s i ∧ s i ≤ 3/2 := fun i => hbox (r i)
    have he10 : E 1 0=0 := by simpa [E,r,sourcePermutedMatrix,Matrix.submatrix_apply,Equiv.swap_apply_def] using h10
    have he20 : E 2 0=0 := by simpa [E,r,sourcePermutedMatrix,Matrix.submatrix_apply,Equiv.swap_apply_def] using h00
    have he := source_actual_double_column_chart s E hE he10 he20
    have h := source_ternary_double_column_strict_bound s hs hsb (E 0 1) (E 1 1) (by rw [← he];exact hE.1)
    rw [← he] at h
    have h' : 1/32 ≤ Matrix.permanent B-sourceTernaryBaseline t := by
      simpa only [E,s,source_permuted_permanent,source_permuted_ternary_baseline] using h
    rw [hobj,sub_self] at h'
    norm_num at h'

theorem source_sharp_euclidean_equality_iff (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,(t i-1)^2) ≤ 3/8) (B : Matrix (Fin 3) (Fin 3) ℝ)
    (hB : B ∈ sourceTransportationPolytope t) :
    Matrix.permanent B=sourceTernaryBaseline t ↔ sourceEuclideanEqualityDescription t B := by
  constructor
  · intro hobj
    have hmin : IsMinOn Matrix.permanent (sourceTransportationPolytope t) B := by
      intro X hX
      change Matrix.permanent B ≤ Matrix.permanent X
      rw [hobj]
      exact source_sharp_euclidean_permanent_inequality t ht hr X hX
    obtain ⟨r,c,hcase⟩ := source_ternary_real_zero_pattern_exhaustion B hB.1
    have hD := source_permuted_feasible t B hB r c
    have hmD := source_permuted_global_minimum t B hmin r c
    have hsum : (∑ i,sourcePermutedTraces t r i)=3 := (source_permuted_trace_sum t r).trans ht
    have hR : (∑ i,(sourcePermutedTraces t r i-1)^2) ≤ 3/8 := by rwa [source_permuted_radius]
    have hbox := source_ternary_euclidean_trace_box t ht hr
    have hboxD : ∀ i,1/2 ≤ sourcePermutedTraces t r i ∧ sourcePermutedTraces t r i ≤ 3/2 := fun i => hbox (r i)
    have hobjD : Matrix.permanent (sourcePermutedMatrix B r c)=sourceTernaryBaseline (sourcePermutedTraces t r) := by
      simpa only [source_permuted_permanent,source_permuted_ternary_baseline] using hobj
    have hd := source_euclidean_canonical_equality (sourcePermutedTraces t r) hsum hboxD hR (sourcePermutedMatrix B r c) hD hmD hcase hobjD
    unfold sourceEuclideanEqualityDescription at hd ⊢
    rcases hd with hscalar | ⟨a,b,z,hz,hz4,htp,hshape⟩
    · left
      have he : sourcePermutedMatrix B r c=sourcePermutedMatrix (sourcePermanentReference t) r c :=
        hscalar.trans (source_permuted_reference t r c).symm
      have hi := congrArg (fun M => sourcePermutedMatrix M r.symm c.symm) he
      simpa only [source_permuted_matrix_inverse] using hi
    · right
      rw [source_permuted_traces_composition] at htp
      rw [source_permuted_matrix_composition] at hshape
      exact ⟨r*a,c*b,z,hz,hz4,htp,hshape⟩
  · intro hdesc
    unfold sourceEuclideanEqualityDescription at hdesc
    rcases hdesc with hscalar | ⟨r,c,z,hz,hz4,htp,hshape⟩
    · rw [hscalar,source_ternary_reference_permanent]
    · have h := (source_euclidean_boundary_family_feasible_equal z hz hz4).2
      rw [← hshape,← htp] at h
      simpa only [source_permuted_permanent,source_permuted_ternary_baseline] using h

theorem source_sharp_euclidean_open_unique (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,(t i-1)^2) < 3/8) (B : Matrix (Fin 3) (Fin 3) ℝ)
    (hB : B ∈ sourceTransportationPolytope t) :
    Matrix.permanent B=sourceTernaryBaseline t ↔ B=sourcePermanentReference t := by
  constructor
  · intro hobj
    have hd := (source_sharp_euclidean_equality_iff t ht hr.le B hB).mp hobj
    unfold sourceEuclideanEqualityDescription at hd
    rcases hd with hscalar | ⟨r,c,z,hz,hz4,htp,hshape⟩
    · exact hscalar
    · have he := congrArg (fun s : Fin 3 → ℝ => ∑ i,(s i-1)^2) htp
      change (∑ i,(sourcePermutedTraces t r i-1)^2)=∑ i,(sourceEuclideanExceptionalTraces i-1)^2 at he
      rw [source_permuted_radius] at he
      norm_num [sourceEuclideanExceptionalTraces,Fin.sum_univ_succ] at he
      norm_num [Fin.sum_univ_succ] at hr
      linarith
  · intro he
    rw [he,source_ternary_reference_permanent]

end CoefficientStability
