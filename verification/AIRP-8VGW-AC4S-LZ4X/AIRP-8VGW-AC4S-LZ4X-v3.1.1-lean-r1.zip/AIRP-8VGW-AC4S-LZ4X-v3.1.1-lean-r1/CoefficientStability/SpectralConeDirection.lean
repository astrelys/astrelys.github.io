import CoefficientStability.CrossingPolynomialSplits

noncomputable section
namespace CoefficientStability
variable {n N : ℕ}

theorem actualCrossingPolynomial_zero (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (x b : Fin n → ℝ) :
    actualCrossingPolynomial p N 0 x b=affineDirectionalRestriction p x b := by
  apply Polynomial.funext
  intro t
  rw [actualCrossingPolynomial_eval,smoothedLineRestriction_zero,eval_lineRestriction_real,
    affineDirectionalRestriction_eval]
  simp only [zero_add,Pi.add_apply,Pi.smul_apply,smul_eq_mul]

theorem source_spectral_cone_direction_splits (p : MvPolynomial (Fin n) ℝ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N) (x : Fin n → ℝ) :
    (affineDirectionalRestriction p x b).Splits ∧
      (affineDirectionalRestriction p x b).natDegree=N ∧
      (affineDirectionalRestriction p x b).leadingCoeff=MvPolynomial.eval b p := by
  have hc : MvPolynomial.eval b p≠0 := ne_of_gt (positiveSpectralCone_eval_pos p hp hs hnorm b hb)
  let Q : ℝ → Polynomial ℝ := fun ε => actualCrossingPolynomial p N ε x b
  let P : ℝ → Polynomial ℝ := fun ε => Polynomial.C (MvPolynomial.eval b p)⁻¹*Q ε
  have hdegree (ε : ℝ) : (Q ε).natDegree=N ∧ (Q ε).leadingCoeff=MvPolynomial.eval b p :=
    actualCrossingPolynomial_exact_degree p hN hp ε x b hc
  have hmonic (ε : ℝ) : (P ε).Monic := by
    apply Polynomial.monic_C_mul_of_mul_leadingCoeff_eq_one
    rw [(hdegree ε).2,inv_mul_cancel₀ hc]
  have hd (ε : ℝ) : (P ε).natDegree=N := by
    change (Polynomial.C _*Q ε).natDegree=N
    rw [Polynomial.natDegree_C_mul (inv_ne_zero hc),(hdegree ε).1]
  have hcont (k : Fin N) : Continuous (fun ε => (P ε).coeff k.val) := by
    have h := (actualCrossingPolynomial_coeff_continuous p N hN hp x b k.val).const_mul
      ((MvPolynomial.eval b p)⁻¹)
    simpa only [P,Q,Polynomial.coeff_C_mul] using h
  have hsplit (ε : ℝ) (hε : 0<ε) : (P ε).Splits :=
    Polynomial.Splits.mul (Polynomial.Splits.C _) (actualCrossingPolynomial_splits_nonzero p hN hp hs hnorm b hb x ε (ne_of_gt hε))
  have hz : (P 0).Splits := monic_real_split_limit_at_zero P hmonic hd hcont hsplit
  have hQ : (Q 0).Splits :=
    (Polynomial.splits_mul_iff_right (Polynomial.C_ne_zero.mpr (inv_ne_zero hc)) (Polynomial.Splits.C _)).mp hz
  have hzero : Q 0=affineDirectionalRestriction p x b := actualCrossingPolynomial_zero p N x b
  rw [hzero] at hQ
  have hdegzero := hdegree 0
  rw [hzero] at hdegzero
  exact ⟨hQ,hdegzero⟩

end CoefficientStability
