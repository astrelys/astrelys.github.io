import CoefficientStability.SourceStableCubicPolynomialGeometry

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

theorem source_stable_cubic_product_source_class (t : Fin 3 → ℝ)
    (B : Matrix (Fin 3) (Fin 3) ℝ) (hB : B ∈ sourceTransportationPolytope t) :
    (sourceCubicProductPolynomial B).IsHomogeneous 3 ∧ UpperHalfPlaneZeroFree (sourceCubicProductPolynomial B) ∧
    MvPolynomial.eval (fun _ => 1) (sourceCubicProductPolynomial B)=1 ∧
    (∀ d,0 ≤ (sourceCubicProductPolynomial B).coeff d) ∧
    ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i (sourceCubicProductPolynomial B))=t i := by
  have hA := source_permanent_diagonal_feasible t B hB
  have h := source_realDeterminant_source_hypotheses (sourcePermanentDiagonalTuple B) (fun i => (hA.1 i).2.1) hA.2
  rw [source_cubic_diagonal_product_polynomial] at h
  obtain ⟨hp,hs,hn,hc,hgrad⟩ := h
  refine ⟨hp,hs,hn,hc,?_⟩
  intro i
  rw [hgrad i,(hA.1 i).2.2,Complex.ofReal_re]

theorem source_stable_cubic_euclidean_equality_product (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,(t i-1)^2) ≤ 3/8) (B : Matrix (Fin 3) (Fin 3) ℝ)
    (hB : B ∈ sourceTransportationPolytope t) (hdesc : sourceEuclideanEqualityDescription t B) :
    UpperHalfPlaneZeroFree (sourceCubicProductPolynomial B) ∧
      (sourceCubicProductPolynomial B).coeff (squarefreeExponent 3)=sourceTernaryBaseline t := by
  exact ⟨(source_stable_cubic_product_source_class t B hB).2.1,
    by rw [source_cubic_product_squarefree_coefficient];exact (source_sharp_euclidean_equality_iff t ht hr B hB).mpr hdesc⟩

theorem source_stable_cubic_l1_equality_product (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,|t i-1|) ≤ sourceCubicEpsilon0) (B : Matrix (Fin 3) (Fin 3) ℝ)
    (hB : B ∈ sourceTransportationPolytope t) (hdesc : sourceL1EqualityDescription t B) :
    UpperHalfPlaneZeroFree (sourceCubicProductPolynomial B) ∧
      (sourceCubicProductPolynomial B).coeff (squarefreeExponent 3)=sourceTernaryBaseline t := by
  exact ⟨(source_stable_cubic_product_source_class t B hB).2.1,
    by rw [source_cubic_product_squarefree_coefficient];exact (source_sharp_l1_equality_iff t ht hr B hB).mpr hdesc⟩

theorem source_stable_cubic_full_euclidean_sharpness (r : ℝ) (hr : Real.sqrt (3/8) < r) :
    ∃ (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ),(∑ i,t i)=3 ∧ (∀ i,0 < t i) ∧
      p.IsHomogeneous 3 ∧ UpperHalfPlaneZeroFree p ∧ MvPolynomial.eval (fun _ => 1) p=1 ∧
      (∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) ∧
      Real.sqrt (∑ i,(t i-1)^2) < r ∧ p.coeff (squarefreeExponent 3) < sourceTernaryBaseline t := by
  obtain ⟨t,B,ht,hpos,hB,hnear,hgap⟩ := source_euclidean_sharpness_radius r hr
  obtain ⟨hp,hs,hn,hc,hgrad⟩ := source_stable_cubic_product_source_class t B hB
  exact ⟨sourceCubicProductPolynomial B,t,ht,hpos,hp,hs,hn,hgrad,hnear,
    by rwa [source_cubic_product_squarefree_coefficient]⟩

theorem source_stable_cubic_full_l1_sharpness (r : ℝ) (hr : sourceCubicEpsilon0 < r) :
    ∃ (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ),(∑ i,t i)=3 ∧ (∀ i,0 < t i) ∧
      p.IsHomogeneous 3 ∧ UpperHalfPlaneZeroFree p ∧ MvPolynomial.eval (fun _ => 1) p=1 ∧
      (∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) ∧
      (∑ i,|t i-1|) < r ∧ p.coeff (squarefreeExponent 3) < sourceTernaryBaseline t := by
  obtain ⟨t,B,ht,hpos,hB,hnear,hgap⟩ := source_l1_sharpness_radius r hr
  obtain ⟨hp,hs,hn,hc,hgrad⟩ := source_stable_cubic_product_source_class t B hB
  exact ⟨sourceCubicProductPolynomial B,t,ht,hpos,hp,hs,hn,hgrad,hnear,
    by rwa [source_cubic_product_squarefree_coefficient]⟩

end CoefficientStability
