import CoefficientStability.SourceEscapeSubtypePathBridge

noncomputable section
open scoped BigOperators Topology unitInterval
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceEscapeTarget (a b : ℝ) : Set (Matrix (Fin 3) (Fin 3) ℝ) :=
  {X | X ∈ sourceTransportationPolytope (sourceEscapeTraces a b) ∧
    sourceEscapeQ a b < sourceEscapeQuadratic a b (X-sourceEscapeCenter a b)}

theorem source_original_escape_admissible_curve_exists (a b : ℝ) (ha : 0 < a) (hb : 0 < b)
    (hs : a+2*b=3) (hab : b/4 ≤ a) :
    ∃ γ : SourceOriginalEscapeCurve a b,sourceOriginalEscapeAdmissible a b γ := by
  by_cases he : a=b
  · have hb1 : b=1 := by linarith
    have ha1 : a=1 := he.trans hb1
    subst a
    subst b
    have hγ := source_escape_balanced_curve_admissible (1/4) (by norm_num) (by norm_num)
    exact ⟨sourceEscapeRestrict 1 1 _ hγ.2.1,source_original_escape_restricted_admissible 1 1 _ hγ⟩
  · have hγ := source_escape_nonbalanced_curve_admissible a b ha hb hs hab he
    exact ⟨sourceEscapeRestrict a b _ hγ.2.1,source_original_escape_restricted_admissible a b _ hγ⟩

theorem source_original_escape_target_nonempty (a b : ℝ) (ha : 0 < a) (hb : 0 < b)
    (hs : a+2*b=3) (hab : b/4 ≤ a) : (sourceEscapeTarget a b).Nonempty := by
  obtain ⟨γ,hγ⟩ := source_original_escape_admissible_curve_exists a b ha hb hs hab
  exact ⟨(γ 1 : Matrix (Fin 3) (Fin 3) ℝ),(γ 1).property,hγ.2⟩

theorem source_original_escape_barrier_value (a b : ℝ) (ha : 0 < a) (hb : 0 < b)
    (hs : a+2*b=3) (hab : b/4 ≤ a) : sourceOriginalEscapeBarrier a b=sourceEscapeDelta a b := by
  rw [source_original_escape_barrier_eq_ambient]
  exact source_escape_full_actual_barrier a b ha hb hs hab

theorem source_original_escape_nonbalanced_attainment (a b : ℝ) (ha : 0 < a) (hb : 0 < b)
    (hs : a+2*b=3) (hab : b/4 ≤ a) (hne : a ≠ b) :
    ∃ γ : SourceOriginalEscapeCurve a b,sourceOriginalEscapeAdmissible a b γ ∧
      sourceOriginalEscapeCurveHeight a b γ=sourceOriginalEscapeBarrier a b := by
  have h := source_escape_nonbalanced_actual_attainment a b ha hb hs hab hne
  refine ⟨sourceEscapeRestrict a b (sourceEscapeNonbalancedCurve a b) h.1.2.1,
    source_original_escape_restricted_admissible a b _ h.1,?_⟩
  rw [source_original_escape_restricted_height,source_original_escape_barrier_eq_ambient,h.2.2]
  exact h.2.1

theorem source_original_escape_balanced_nonattainment (γ : SourceOriginalEscapeCurve 1 1)
    (hγ : sourceOriginalEscapeAdmissible 1 1 γ) :
    sourceOriginalEscapeBarrier 1 1 < sourceOriginalEscapeCurveHeight 1 1 γ := by
  rw [source_original_escape_barrier_eq_ambient]
  exact source_escape_balanced_actual_nonattainment (sourceEscapeForget 1 1 γ)
    ((source_original_escape_admissible_iff 1 1 γ).mp hγ)

theorem source_original_escape_barrier_continuous_on_family :
    ContinuousOn (fun p : ℝ × ℝ => sourceOriginalEscapeBarrier p.1 p.2) sourceEscapeParameterDomain := by
  apply source_escape_barrier_continuous_on_family.congr
  intro p hp
  exact source_original_escape_barrier_eq_ambient p.1 p.2

theorem source_original_symmetric_escape_and_nonattainment (a b : ℝ) (ha : 0 < a) (hb : 0 < b)
    (hs : a+2*b=3) (hab : b/4 ≤ a) :
    (sourceEscapeTarget a b).Nonempty ∧ sourceOriginalEscapeBarrier a b=sourceEscapeDelta a b ∧
    (a ≠ b → ∃ γ : SourceOriginalEscapeCurve a b,sourceOriginalEscapeAdmissible a b γ ∧
      sourceOriginalEscapeCurveHeight a b γ=sourceOriginalEscapeBarrier a b) ∧
    (∀ γ : SourceOriginalEscapeCurve 1 1,sourceOriginalEscapeAdmissible 1 1 γ →
      sourceOriginalEscapeBarrier 1 1 < sourceOriginalEscapeCurveHeight 1 1 γ) ∧
    ContinuousOn (fun p : ℝ × ℝ => sourceOriginalEscapeBarrier p.1 p.2) sourceEscapeParameterDomain :=
  ⟨source_original_escape_target_nonempty a b ha hb hs hab,source_original_escape_barrier_value a b ha hb hs hab,
    source_original_escape_nonbalanced_attainment a b ha hb hs hab,
    source_original_escape_balanced_nonattainment,source_original_escape_barrier_continuous_on_family⟩

end CoefficientStability
