import CoefficientStability.DeficitBounds
import Mathlib.Algebra.Order.Star.Real

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem scalarPower_gradient (t : Fin n → ℝ) (N : ℕ) (hN : 0<N)
    (ht : ∑ i,t i=N) (i : Fin n) :
    MvPolynomial.eval (fun _ => 1) (pderiv i (scalarPower t N))=t i := by
  have hn : (N : ℝ)≠0 := by exact_mod_cast Nat.ne_zero_of_lt hN
  simp [scalarPower,pderiv_scalarLinear,eval_one_scalarLinear t N hN ht]
  field_simp

theorem scalarPower_mixed_hessian (t : Fin n → ℝ) (N : ℕ) (hN : 2≤N)
    (ht : ∑ i,t i=N) (i j : Fin n) :
    MvPolynomial.eval (fun _ => 1) (pderiv i (pderiv j (scalarPower t N)))=
      ((N : ℝ)-1)/N*t i*t j := by
  have hn : (N : ℝ)≠0 := by exact_mod_cast (by omega : N≠0)
  simp [scalarPower,pderiv_scalarLinear,eval_one_scalarLinear t N (by omega) ht]
  rw [Nat.cast_sub (by omega : 1≤N)]
  push_cast
  field_simp

theorem scalarPower_coefficient_covariance (t : Fin n → ℝ) (N : ℕ) (hN : 2≤N)
    (ht : ∑ i,t i=N) (i j : Fin n) :
    coefficientCovariance (scalarPower t N) t i j = (if i=j then t i else 0)-t i*t j/N := by
  rw [actual_coefficient_covariance _ t (eval_one_scalarPower t N (by omega) ht)
    (scalarPower_gradient t N (by omega) ht),scalarPower_mixed_hessian t N hN ht]
  have hn : (N : ℝ)≠0 := by exact_mod_cast (by omega : N≠0)
  field_simp
  ring

theorem paper_covariance_difference (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (N : ℕ) (hN : 2≤N) (ht : ∑ i,t i=N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    coefficientCovariance (scalarPower t N) t - coefficientCovariance p t =
      (2 : ℝ) • deficitMatrix p t N := by
  ext i j
  simp only [Matrix.sub_apply,Matrix.smul_apply,smul_eq_mul]
  rw [scalarPower_coefficient_covariance t N hN ht i j,
    actual_coefficient_covariance p t hnorm hgrad i j]
  unfold deficitMatrix
  have hn : (N : ℝ)≠0 := by exact_mod_cast (by omega : N≠0)
  field_simp
  ring

theorem coefficientCovariance_as_outer_sum (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) :
    coefficientCovariance p t = ∑ g ∈ p.support,p.coeff g •
      Matrix.vecMulVec (fun i => (g i : ℝ)-t i) (fun i => (g i : ℝ)-t i) := by
  ext i j
  simp only [coefficientCovariance,Matrix.sum_apply,Matrix.smul_apply,Matrix.vecMulVec_apply,smul_eq_mul]
  apply Finset.sum_congr rfl
  intro g hg
  ring

theorem coefficientCovariance_posSemidef (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hcoeff : ∀ g,0≤p.coeff g) : (coefficientCovariance p t).PosSemidef := by
  rw [coefficientCovariance_as_outer_sum]
  apply Matrix.posSemidef_sum
  intro g hg
  have h := Matrix.posSemidef_vecMulVec_self_star (fun i : Fin n => (g i : ℝ)-t i)
  have h' : (Matrix.vecMulVec (fun i => (g i : ℝ)-t i) (fun i => (g i : ℝ)-t i)).PosSemidef := by
    simpa using h
  exact h'.smul (hcoeff g)

theorem paper_covariance_difference_posSemidef
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) (hN : 2≤N)
    (hp : p.IsHomogeneous N) (ht : ∑ i,t i=N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    (coefficientCovariance (scalarPower t N) t - coefficientCovariance p t).PosSemidef := by
  rw [paper_covariance_difference p t N hN ht hnorm hgrad]
  exact (deficitMatrix_posSemidef p t N hN hp hnorm hstable hgrad).smul (by norm_num : (0 : ℝ)≤2)

end CoefficientStability
