import CoefficientStability.RankOneReducedPenalty

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem source_nearoptimal_small_boundary_impossible (p : MvPolynomial (Fin n) ℝ) (hn : 3≤n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)≤capacityEta n/(64*(n : ℝ)))
    (hcoef : p.coeff (squarefreeExponent n)≤sourceVn n*(1+capacityEta n/2))
    (j : Fin n) (r : ℝ) (hr0 : 0≤r) (hr : r≤sourceMixingRadius n)
    (hboundary : (fun i => (if i=j then 1 else 0)-r)∈closure (positiveSpectralCone p n))
    (hzero : MvPolynomial.eval (fun i => (if i=j then 1 else 0)-r) p=0) : False := by
  let s : ℝ := ∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|
  have hs0 : 0≤s := Finset.sum_nonneg (fun i hi => abs_nonneg _)
  have hn0 : 0<n := by omega
  have hR : r≤capacityEta n/(64*(n : ℝ)^2) := by simpa only [sourceMixingRadius] using hr
  have he := source_cone_margin_scalar_estimates n hn (capacityEta n) s r
    (capacityEta_pos n hn) (capacityEta_upper n hn) hs0 hgrad hr0 hR
  have hr1 : r<1 := by linarith [he.1]
  have hcap := rankOne_source_capacity_linear_lower p hn0 hp hs hnorm j r hr0 he.1 hboundary he.2.1
  have hpenalty := rankOne_source_eta_capacity_coefficient_lower p hn0 hp hs hnorm j r hr1 hboundary hzero
  have hcompare := rankOne_source_squarefree_coefficient_comparison p hn0 hp hs hnorm j r hr0 hr1 hboundary
  have hdiv := (div_le_iff₀ (by linarith : 0<1-r)).mp hcompare
  have hpcoeff0 := normalized_homogeneous_stable_coeff_nonneg p n hp hs hnorm (squarefreeExponent n)
  have hqlep : (matrixSubstitution (rankOneUnmixingMatrix n j r) p).coeff (squarefreeExponent n)≤
      p.coeff (squarefreeExponent n) := by
    nlinarith [mul_nonneg hpcoeff0 hr0]
  have hmult : 0≤sourceVn n*(1+capacityEta n) :=
    mul_nonneg (sourceVn_nonneg n) (by linarith [capacityEta_pos n hn])
  have hlower : sourceVn n*((1+capacityEta n)*(1-2*(n : ℝ)*s-5*(n : ℝ)^2*r))≤p.coeff (squarefreeExponent n) := by
    calc
      _=(sourceVn n*(1+capacityEta n))*(1-2*(n : ℝ)*s-5*(n : ℝ)^2*r) := by ring
      _≤(sourceVn n*(1+capacityEta n))*
          multivariatePositiveCapacity (matrixSubstitution (rankOneUnmixingMatrix n j r) p) :=
        mul_le_mul_of_nonneg_left hcap hmult
      _≤(matrixSubstitution (rankOneUnmixingMatrix n j r) p).coeff (squarefreeExponent n) := hpenalty
      _≤p.coeff (squarefreeExponent n) := hqlep
  have hstrict := mul_lt_mul_of_pos_left he.2.2.2.2 (sourceVn_pos hn0)
  exact (not_lt_of_ge (hlower.trans hcoef)) hstrict

end CoefficientStability
