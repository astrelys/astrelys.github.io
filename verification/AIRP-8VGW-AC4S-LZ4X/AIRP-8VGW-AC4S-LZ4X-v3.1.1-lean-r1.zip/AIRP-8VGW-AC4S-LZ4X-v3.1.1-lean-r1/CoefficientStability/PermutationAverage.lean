import CoefficientStability.MixedDiagonalCoefficient

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ} {R : Type*} [CommRing R] [IsDomain R] [CharZero R]

theorem permutation_coordinate_sum_equal (f : Fin n → R) (r q : Fin n) :
    (∑ s : Equiv.Perm (Fin n),f (s q))=∑ s : Equiv.Perm (Fin n),f (s r) := by
  classical
  apply Fintype.sum_equiv (Equiv.mulRight (Equiv.swap r q))
  intro s
  simp [Equiv.Perm.mul_apply]

theorem permutation_coordinate_sum (f : Fin n → R) (hn : 0<n) (r : Fin n) :
    (∑ s : Equiv.Perm (Fin n),f (s r))=((n-1).factorial : R)*∑ i,f i := by
  have he : (n : R)*(∑ s : Equiv.Perm (Fin n),f (s r))=(n.factorial : R)*(∑ i,f i) := by
    calc
      _ = ∑ q : Fin n,∑ s : Equiv.Perm (Fin n),f (s q) := by
        simp only [permutation_coordinate_sum_equal f r,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
      _ = ∑ s : Equiv.Perm (Fin n),∑ q : Fin n,f (s q) := Finset.sum_comm
      _ = ∑ _s : Equiv.Perm (Fin n),∑ i,f i := by
        apply Finset.sum_congr rfl
        intro s hs
        exact Fintype.sum_bijective s s.bijective _ _ (fun _ => rfl)
      _ = _ := by simp [Fintype.card_perm]
  have hn0 : (n : R)≠0 := by exact_mod_cast Nat.ne_zero_of_lt hn
  apply mul_left_cancel₀ hn0
  rw [he]
  have hf : (n.factorial : R)=(n : R)*((n-1).factorial : R) := by
    exact_mod_cast (Nat.mul_factorial_pred (Nat.ne_zero_of_lt hn)).symm
  rw [hf]
  ring

end CoefficientStability
