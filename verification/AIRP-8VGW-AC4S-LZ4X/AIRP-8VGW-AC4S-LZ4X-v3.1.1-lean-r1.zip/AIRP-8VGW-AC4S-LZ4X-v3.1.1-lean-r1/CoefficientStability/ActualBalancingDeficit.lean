import CoefficientStability.SourceBalancingRadius

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem actual_balancing_path_deficit_bound (p : MvPolynomial (Fin n) ℝ)
    (u : Fin n → ℝ) (hn : 3 ≤ n) (hp : p.IsHomogeneous n)
    (hc : ∀ g,0 ≤ p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p)
    (hsmall : (n : ℝ)*Real.sqrt (∑ i,u i^2) ≤ 1/24)
    (s : ℝ) (hseg : s ∈ Set.Icc (0 : ℝ) 1) :
    actualTiltDeficit p (s • u) ≤ 2*actualTiltDeficit p u := by
  have he : u+(s-1) • u=s • u := by
    funext i
    simp only [Pi.add_apply,Pi.smul_apply,smul_eq_mul]
    ring
  have hb := (paper_actual_relative_tilt_endpoints p u ((s-1) • u) hn hp hc hnorm hs).2
  rw [he] at hb
  have hpiNorm : ‖(s-1) • u‖ ≤ Real.sqrt (∑ i,u i^2) := by
    rw [norm_smul,Real.norm_eq_abs,abs_of_nonpos (sub_nonpos.mpr hseg.2)]
    have hpi := real_pi_norm_le_square_sum_sqrt u
    have hs1 : 0 ≤ 1-s := sub_nonneg.mpr hseg.2
    have hh := mul_le_mul_of_nonneg_left hpi hs1
    have hh2 := mul_le_mul_of_nonneg_right (show 1-s ≤ 1 by linarith [hseg.1]) (Real.sqrt_nonneg (∑ i,u i^2))
    nlinarith
  have hexp : Real.exp (12*(n : ℝ)*‖(s-1) • u‖) ≤ 2 := by
    have harg : 12*(n : ℝ)*‖(s-1) • u‖ ≤ (1/2 : ℝ) := by
      have hh := mul_le_mul_of_nonneg_left hpiNorm (by positivity : 0 ≤ 12*(n : ℝ))
      nlinarith
    have hhalf := Real.exp_le_two_add_div_two_sub (x := (1/2 : ℝ)) (by norm_num) (by norm_num)
    exact (Real.exp_le_exp.mpr harg).trans (by norm_num at hhalf ⊢;linarith)
  have hd0 := (actual_tilt_deficit_source_bounds p u (by omega) hp hc hnorm hs).2.2.1
  exact hb.trans (mul_le_mul_of_nonneg_right hexp hd0)

end CoefficientStability
