import CoefficientStability.SourceL1LowerRootGeometry

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1200000

theorem source_l1_chart_trace_sum (u v : ℝ) (hu : 0 < u) (hv : 0 < v) (huv : u+v < 1) :
    (∑ i,sourceL1ChartTraces u v i)=3 :=
  source_ternary_stationary_chart_trace_sum ((1+v)/2) ((1-u)/2) (sourceL1ChartD u v)
    (source_l1_chart_stationary_relation u v hu hv huv)

theorem source_l1_chart_distance_height_bound (u v : ℝ) (hu : 0 < u) (hv : 0 < v) (huv : u+v < 1) :
    2*|sourceL1ChartHeight u v| < sourceCubicDistance (sourceL1ChartD u v) (sourceL1ChartHeight u v) := by
  obtain ⟨h0,h1,h2⟩ := source_l1_chart_marginal_signs u v hu hv huv
  have hs := source_l1_chart_trace_sum u v hu hv huv
  norm_num [Fin.sum_univ_succ] at hs
  have habs : |sourceL1ChartHeight u v| < sourceL1ChartTraces u v 0-sourceL1ChartTraces u v 1 := by
    apply abs_lt.mpr
    constructor <;> linarith
  rw [← source_l1_chart_actual_distance u v hu hv huv]
  norm_num only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero,Fin.reduceFinMk]
  change 2*|sourceL1ChartHeight u v| < |sourceL1ChartTraces u v 0-1|+
    (|sourceL1ChartTraces u v 1-1|+|sourceL1ChartTraces u v 2-1|)
  rw [abs_of_pos (by linarith : 0 < sourceL1ChartTraces u v 0-1),
    abs_of_neg (by linarith : sourceL1ChartTraces u v 1-1 < 0),h2]
  linarith

theorem source_cubic_S_square_decomposition (d h : ℝ) : sourceCubicS d h=(h-2*d)^2+d*(1-d) := by unfold sourceCubicS;ring

theorem source_cubic_S_positive (d h : ℝ) (hd : 0 < d) (hd1 : d < 1) : 0 < sourceCubicS d h := by
  rw [source_cubic_S_square_decomposition]
  have hp := mul_pos hd (by linarith : 0 < 1-d)
  nlinarith [sq_nonneg (h-2*d)]

theorem source_cubic_distance_small_d (d h : ℝ) (hd : 0 < d) (hd2 : d < 1/2)
    (hE : sourceCubicDistance d h < 1) : d < 1/3 := by
  let s := Real.sqrt (sourceCubicS d h)
  let x := h-2*d
  let c := d*(1-d)
  let K := 3-2*d
  let q := K*s+x
  have hc : 0 < c := mul_pos hd (by linarith)
  have hspos : 0 < s := Real.sqrt_pos.mpr (source_cubic_S_positive d h hd (by linarith))
  have hs : s^2=x^2+c := by
    dsimp [s,x,c]
    rw [Real.sq_sqrt (source_cubic_S_positive d h hd (by linarith)).le,source_cubic_S_square_decomposition]
  have hsp : 0 < s+x := by
    by_contra hh
    have hm := mul_nonneg (by linarith : 0 ≤ -x-s) (by linarith : 0 ≤ s-x)
    nlinarith [hs]
  have hq : 0 < q := by
    have hm := mul_nonneg (by dsimp [K];linarith : 0 ≤ K-1) hspos.le
    dsimp [q]
    nlinarith [hsp,hm]
  have he : q^2-(K^2-1)*c=(s+K*x)^2 := by
    dsimp [q]
    linear_combination (K^2-1)*hs
  have hqs : (K^2-1)*c ≤ q^2 := by nlinarith [sq_nonneg (s+K*x)]
  have hElower : 2*d+q ≤ sourceCubicDistance d h := by
    dsimp [sourceCubicDistance,q,K,s,x]
    linarith [le_abs_self h]
  by_contra hh
  have hd3 : 1/3 ≤ d := le_of_not_gt hh
  have hc2 : 2/9 ≤ c := by
    have hm := mul_nonneg (by linarith : 0 ≤ d-1/3) (by linarith : 0 ≤ 2/3-d)
    dsimp [c]
    nlinarith [hm]
  have hK2 : 3 ≤ K^2-1 := by
    have hK : 2 ≤ K := by dsimp [K];linarith
    nlinarith [mul_nonneg (by linarith : 0 ≤ K-2) (by linarith : 0 ≤ K+2)]
  have hp : 2/3 ≤ (K^2-1)*c := calc
    _ = 3*(2/9) := by norm_num
    _ ≤ 3*c := mul_le_mul_of_nonneg_left hc2 (by norm_num)
    _ ≤ (K^2-1)*c := mul_le_mul_of_nonneg_right hK2 hc.le
  have hq3 : q < 1/3 := by linarith
  have hbound := mul_nonneg (by linarith : 0 ≤ 1/3-q) (by linarith : 0 ≤ 1/3+q)
  nlinarith [hp,hqs,hbound]

theorem source_l1_chart_small_distance_domain (u v : ℝ) (hu : 0 < u) (hv : 0 < v) (huv : u+v < 1)
    (hE : sourceCubicDistance (sourceL1ChartD u v) (sourceL1ChartHeight u v) < 1) :
    0 < sourceL1ChartD u v ∧ sourceL1ChartD u v < 1/3 ∧ |sourceL1ChartHeight u v| < 1/2 := by
  obtain ⟨hd,hdu,hd2⟩ := source_l1_chart_d_bounds u v hu hv huv
  have hs := source_cubic_distance_small_d (sourceL1ChartD u v) (sourceL1ChartHeight u v) hd hd2 hE
  have hh := source_l1_chart_distance_height_bound u v hu hv huv
  exact ⟨hd,hs,by linarith⟩

end CoefficientStability
