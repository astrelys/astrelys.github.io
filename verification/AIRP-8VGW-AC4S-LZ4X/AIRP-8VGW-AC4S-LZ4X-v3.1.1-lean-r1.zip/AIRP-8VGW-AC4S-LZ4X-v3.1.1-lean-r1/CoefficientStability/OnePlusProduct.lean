import CoefficientStability.PermutationAverage

noncomputable section
open scoped BigOperators
open Polynomial
namespace CoefficientStability
variable {n : ℕ}

def onePlusRootProduct (s : Multiset ℝ) : ℝ[X] := (s.map (fun r => 1+C r*X)).prod

theorem onePlusRootProduct_coeff (s : Multiset ℝ) (k : ℕ) :
    (onePlusRootProduct s).coeff k=s.esymm k := by
  induction s using Multiset.induction_on generalizing k with
  | empty =>
    cases k with
    | zero => simp [onePlusRootProduct,Multiset.esymm]
    | succ k => simp [onePlusRootProduct,Multiset.esymm_of_card_lt (s := (0 : Multiset ℝ)) (n := k+1) (by simp),Polynomial.coeff_one]
  | @cons a s ih =>
    have he : onePlusRootProduct (a ::ₘ s)=onePlusRootProduct s+C a*(X*onePlusRootProduct s) := by
      unfold onePlusRootProduct
      simp only [Multiset.map_cons,Multiset.prod_cons,add_mul,one_mul,mul_assoc]
    rw [he]
    cases k with
    | zero => simp [ih]
    | succ k =>
      simp only [Polynomial.coeff_add,Polynomial.coeff_C_mul,Polynomial.coeff_X_mul,ih,esymm_cons]

def onePlusProduct (z : Fin n → ℝ) : ℝ[X] := ∏ i,(1+C (z i)*X)

theorem onePlusProduct_coeff (z : Fin n → ℝ) (k : ℕ) :
    (onePlusProduct z).coeff k=centralCoefficient z k := by
  rw [centralCoefficient_eq_esymm]
  have h := onePlusRootProduct_coeff (Finset.univ.val.map z) k
  simpa only [onePlusRootProduct,onePlusProduct,Multiset.map_map,Function.comp_apply,
    Finset.prod] using h

theorem centralCoefficient_scaled (z : Fin n → ℝ) (c : ℝ) (k : ℕ) :
    centralCoefficient (fun i => c*z i) k=c^k*centralCoefficient z k := by
  classical
  unfold centralCoefficient
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro s hs
  have hcard := (Finset.mem_powersetCard.mp hs).2
  rw [Finset.prod_mul_distrib,Finset.prod_const,hcard]

def boundaryProductPolynomial (t : Fin n → ℝ) : ℝ[X] :=
  onePlusProduct (fun i => -(n : ℝ)*projectedOnes t i)

theorem boundaryProductPolynomial_coeff (t : Fin n → ℝ) (k : ℕ) :
    (boundaryProductPolynomial t).coeff k=(-(n : ℝ))^k*centralCoefficient (projectedOnes t) k := by
  rw [boundaryProductPolynomial,onePlusProduct_coeff,centralCoefficient_scaled]

end CoefficientStability
