import CoefficientStability.SourceCubicDualDecomposition
import CoefficientStability.SourceCubicMultiplierCommutation

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 2700000
set_option backward.isDefEq.respectTransparency false

theorem source_cubic_matrix_gradient_hermitian (t : ℝ) (X : Matrix (Fin 3) (Fin 3) ℂ)
    (hX : X.IsHermitian) : (sourceCubicMatrixGradient t X).IsHermitian := by
  unfold sourceCubicMatrixGradient
  apply Matrix.IsHermitian.add
  · exact (hX.pow 2).smul (by simp [IsSelfAdjoint,Complex.star_def])
  · exact hX.smul (by simp [IsSelfAdjoint,Complex.star_def])

theorem source_original_cubic_multiplier_certificate (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (htpos : ∀ i,0 < t i) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A) :
    ∃ H : Matrix (Fin 3) (Fin 3) ℂ,H.IsHermitian ∧ ∃ (μ : Fin 3 → ℝ)
      (S : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ),(∀ i,(S i).PosSemidef) ∧
        ∀ i,sourceCubicMatrixGradient (t i) (A i)=H+(μ i : ℂ) • 1+S i ∧
          S i*A i=0 ∧ A i*S i=0 := by
  classical
  obtain ⟨ℓ,hcone,hzero⟩ := source_cubic_original_real_dual_certificate t ht htpos A hA hm
  obtain ⟨H,hrep⟩ := source_cubic_dual_slack_matrix_representation t A ℓ
  let S : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ := fun i =>
    sourceCubicMatrixGradient (t i) (A i)+H.val+(sourceCubicTraceWeights ℓ i : ℂ) • 1
  have hHerm (i : Fin 3) : (S i).IsHermitian := by
    exact ((source_cubic_matrix_gradient_hermitian (t i) (A i) (hA.1 i).1).add H.property).add
      (Matrix.isHermitian_one.smul (by simp [IsSelfAdjoint,Complex.star_def]))
  have hPSD (i : Fin 3) : (S i).PosSemidef := by
    apply (source_psd_trace_self_duality (S i) (hHerm i)).mpr
    intro X hX
    let Y : SourceCubicHermitianTuples := Function.update 0 i ⟨X,hX.isHermitian⟩
    have hY : Y ∈ sourceCubicPSDCone := by
      intro j
      by_cases hj : j=i
      · subst j
        simpa [Y] using hX
      · simpa [Y,Function.update_of_ne hj] using (Matrix.PosSemidef.zero : (0 : Matrix (Fin 3) (Fin 3) ℂ).PosSemidef)
    have hn := hcone Y hY
    rw [hrep] at hn
    change 0 ≤ ∑ j,(Matrix.trace (S j*(Y j).val)).re at hn
    have he : (∑ j,(Matrix.trace (S j*(Y j).val)).re)=(Matrix.trace (S i*X)).re := by
      rw [Finset.sum_eq_single i]
      · simp [Y]
      · intro j hj hji
        simp [Y,hji]
      · intro hnot
        exact False.elim (hnot (Finset.mem_univ i))
    rw [he] at hn
    exact hn
  have htotal : (∑ i,(Matrix.trace (S i*A i)).re)=0 := by
    have h := hrep (sourceCubicHermitianBundle A (fun i => (hA.1 i).1))
    change sourceCubicDualSlack (sourceCubicGradientDual t A) ℓ
      (sourceCubicHermitianBundle A (fun i => (hA.1 i).1))=(∑ i,(Matrix.trace (S i*A i)).re) at h
    exact h.symm.trans hzero
  have hcomp := source_psd_tuple_complementarity S A hPSD (fun i => (hA.1 i).2.1) htotal
  refine ⟨-H.val,H.property.neg,(fun i => -sourceCubicTraceWeights ℓ i),S,hPSD,?_⟩
  intro i
  refine ⟨?_,(hcomp i).1,(hcomp i).2⟩
  change sourceCubicMatrixGradient (t i) (A i)=
    -H.val+(((-sourceCubicTraceWeights ℓ i) : ℝ) : ℂ) • 1+
      (sourceCubicMatrixGradient (t i) (A i)+H.val+(sourceCubicTraceWeights ℓ i : ℂ) • 1)
  simp only [Complex.ofReal_neg,neg_smul]
  abel

end CoefficientStability
