import CoefficientStability.BalancedRigidityWithUnmixing
import CoefficientStability.BalancedGapConstants

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability

theorem actual_balanced_rigidity_from_source_unmixing (n : ℕ) (hn : 3≤n)
    (p : MvPolynomial (Fin n) ℝ) (hp : p.IsHomogeneous n)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=1)
    (hUnmixed : p.coeff (squarefreeExponent n)/sourceVn n-1≤sourceSmallExcessThreshold n →
      ∀ g,0≤(uniformUnmixedPolynomial p n (sourceMixingRadius n)).coeff g) :
    actualTiltDeficit p 0/(100000000*(n : ℝ)^8)≤p.coeff (squarefreeExponent n)/sourceVn n-1 := by
  have hc := normalized_homogeneous_stable_coeff_nonneg p n hp hs hnorm
  have hb := actual_tilt_deficit_source_bounds p 0 (by omega) hp hc hnorm hs
  apply balanced_gap_from_small_branch hn _ _
    (normalized_balanced_excess_nonneg n (by omega) p hp hs hnorm hgrad) hb.2.2.2
  intro hsmall
  exact actual_balanced_small_rigidity_from_nonnegative_unmixing n hn p hp hs hnorm hgrad
    (hUnmixed hsmall) hsmall

theorem normalized_balanced_gap_from_source_unmixing (n : ℕ) (hn : 3≤n)
    (p : MvPolynomial (Fin n) ℝ) (hp : p.IsHomogeneous n)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=1)
    (hUnmixed : p.coeff (squarefreeExponent n)/sourceVn n-1≤sourceSmallExcessThreshold n →
      ∀ g,0≤(uniformUnmixedPolynomial p n (sourceMixingRadius n)).coeff g) :
    sourceVn n*(1+referenceDeficit p (fun _ => 1) n/(100000000*(n : ℝ)^8))≤
      p.coeff (squarefreeExponent n) := by
  have h := actual_balanced_rigidity_from_source_unmixing n hn p hp hs hnorm hgrad hUnmixed
  have heq : (fun i => MvPolynomial.eval (fun _ => 1) (pderiv i p))=(fun _ => (1 : ℝ)) := funext hgrad
  rw [actualTiltDeficit_zero p hnorm,heq] at h
  have hV := sourceVn_pos (by omega : 0<n)
  have hh := (le_div_iff₀ hV).mp
    (show 1+referenceDeficit p (fun _ => 1) n/(100000000*(n : ℝ)^8)≤
      p.coeff (squarefreeExponent n)/sourceVn n by linarith)
  nlinarith

end CoefficientStability
