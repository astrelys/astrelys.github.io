import CoefficientStability.SourceCubicCertificate
import Mathlib.GroupTheory.Perm.Fin

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1200000

theorem source_permutations_three : (Finset.univ : Finset (Equiv.Perm (Fin 3)))=
    {1,Equiv.swap 0 1,Equiv.swap 0 2,Equiv.swap 1 2,
      Equiv.swap 0 1*Equiv.swap 1 2,Equiv.swap 1 2*Equiv.swap 0 1} := by decide

theorem source_permanent_three (B : Matrix (Fin 3) (Fin 3) ℝ) :
    Matrix.permanent B=B 0 0*B 1 1*B 2 2+B 0 0*B 1 2*B 2 1+
      B 0 1*B 1 0*B 2 2+B 0 1*B 1 2*B 2 0+B 0 2*B 1 0*B 2 1+B 0 2*B 1 1*B 2 0 := by
  rw [Matrix.permanent,source_permutations_three]
  rw [Finset.sum_insert (by decide),Finset.sum_insert (by decide),Finset.sum_insert (by decide),
    Finset.sum_insert (by decide),Finset.sum_insert (by decide),Finset.sum_singleton]
  norm_num [Fin.prod_univ_succ,Equiv.Perm.mul_apply,Equiv.swap_apply_def]
  ring

def sourceTernaryBaseline (t : Fin 3 → ℝ) := 2*t 0*t 1*t 2/9

theorem source_ternary_baseline_literal (t : Fin 3 → ℝ) : sourceTernaryBaseline t=sourceVn 3*(∏ i,t i) := by
  norm_num [sourceTernaryBaseline,sourceVn,Fin.prod_univ_succ]
  ring

def sourceTernaryOneZero (t : Fin 3 → ℝ) (a b c : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  ![![0,a,t 0-a],![b,c,t 1-b-c],![1-b,1-a-c,t 2-2+a+b+c]]

def sourceTernaryMatchingZeros (t : Fin 3 → ℝ) (x : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  ![![0,x,t 0-x],![2-t 2-x,0,1-t 0+x],![t 2-1+x,1-x,0]]

def sourceTernarySeparatedZeros (t : Fin 3 → ℝ) (a b : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  sourceTernaryOneZero t a b 0

theorem source_ternary_one_zero_expansion (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b c : ℝ) :
    Matrix.permanent (sourceTernaryOneZero t a b c)=
      a*t 1+t 0*b+(2*t 2-7)*a*b+2*a^2*b+2*a*b^2+c*(2*a-t 0)*(2*b-1) := by
  have ht2 : t 2=3-t 0-t 1 := by
    have h := ht
    simp only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero] at h
    change t 0+(t 1+t 2)=3 at h
    linarith
  rw [source_permanent_three]
  norm_num [sourceTernaryOneZero]
  rw [ht2]
  ring

theorem source_ternary_matching_gap (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (x : ℝ) :
    Matrix.permanent (sourceTernaryMatchingZeros t x)-sourceTernaryBaseline t=
      3*(x-(1/2+(t 0-t 2)/3))^2+(∏ i,(3-2*t i))/36 := by
  have ht2 : t 2=3-t 0-t 1 := by
    have h := ht
    simp only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero] at h
    change t 0+(t 1+t 2)=3 at h
    linarith
  rw [source_permanent_three]
  norm_num [sourceTernaryMatchingZeros,sourceTernaryBaseline,Fin.prod_univ_succ]
  rw [ht2]
  ring

theorem source_ternary_one_zero_stationary_gap (t : Fin 3 → ℝ)
    (ht : (∑ i,t i)=3) (heq : t 1=t 2) (c : ℝ) :
    Matrix.permanent (sourceTernaryOneZero t (t 0/2) (1/2) c)-sourceTernaryBaseline t=t 0^2*(3-2*t 0)/36 := by
  rw [source_ternary_one_zero_expansion t ht]
  unfold sourceTernaryBaseline
  have h := ht
  simp only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero] at h
  change t 0+(t 1+t 2)=3 at h
  rw [heq] at h
  have ht2 : t 2=(3-t 0)/2 := by linarith
  rw [heq,ht2]
  ring

def sourceTernarySharpEuclidean (x : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  ![![0,x/2,x/2],![1/2,(2-x)/4,(2-x)/4],![1/2,(2-x)/4,(2-x)/4]]

def sourceTernarySharpTraces (x : ℝ) : Fin 3 → ℝ := ![x,(3-x)/2,(3-x)/2]

theorem source_ternary_euclidean_sharp_gap (x : ℝ) :
    Matrix.permanent (sourceTernarySharpEuclidean x)-sourceTernaryBaseline (sourceTernarySharpTraces x)=x^2*(3-2*x)/36 := by
  rw [source_permanent_three]
  norm_num [sourceTernarySharpEuclidean,sourceTernarySharpTraces,sourceTernaryBaseline]
  ring

theorem source_ternary_euclidean_sharp_distance (x : ℝ) :
    (∑ i,(sourceTernarySharpTraces x i-1)^2)=(3/2)*(x-1)^2 := by
  norm_num [sourceTernarySharpTraces,Fin.sum_univ_succ]
  ring

theorem source_ternary_euclidean_sharp_feasible (x : ℝ) (hx : 3/2 < x) (hx2 : x < 2) :
    sourceTernarySharpEuclidean x ∈ sourceTransportationPolytope (sourceTernarySharpTraces x) ∧
      Matrix.permanent (sourceTernarySharpEuclidean x)<sourceTernaryBaseline (sourceTernarySharpTraces x) := by
  refine ⟨⟨?_,?_,?_⟩,?_⟩
  · intro i j
    fin_cases i <;> fin_cases j <;> norm_num [sourceTernarySharpEuclidean] <;> linarith
  · intro i
    fin_cases i <;> norm_num [sourceTernarySharpEuclidean,sourceTernarySharpTraces,Fin.sum_univ_succ] <;> ring
  · intro j
    fin_cases j <;> norm_num [sourceTernarySharpEuclidean,Fin.sum_univ_succ] <;> ring
  · have h := source_ternary_euclidean_sharp_gap x
    have hn : x^2*(3-2*x)/36 < 0 := div_neg_of_neg_of_pos (mul_neg_of_pos_of_neg (sq_pos_of_pos (by linarith)) (by linarith)) (by norm_num)
    linarith

end CoefficientStability
