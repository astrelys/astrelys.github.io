import CoefficientStability.DiagonalStablePolynomial

noncomputable section
open scoped BigOperators Topology
open MvPolynomial Filter
namespace CoefficientStability
variable {n : ℕ}

theorem diagonalPolynomial_coefficient_continuous (B : ℝ → Fin n → Fin n → ℝ)
    (hB : ∀ r i,Continuous (fun s => B s r i)) (d : Fin n →₀ ℕ) :
    Continuous (fun s => (diagonalPencilPolynomial (B s)).coeff d) := by
  classical
  simp only [diagonalPolynomial_expansion,MvPolynomial.coeff_sum,MvPolynomial.coeff_monomial]
  apply continuous_finset_sum
  intro f hf
  split_ifs
  · exact continuous_finset_prod _ (fun r _ => hB r (f r))
  · exact continuous_const

def boundaryCoefficientMatrix (t : Fin n → ℝ) (s : ℝ) (r i : Fin n) : ℝ :=
  t i/(n : ℝ)+s*(t i*projectedOnes t i)*boundaryModelDiagonal n r

def stableBoundaryCurve (t : Fin n → ℝ) (s : ℝ) : FixedDegreePolynomials n :=
  ⟨diagonalPencilPolynomial (boundaryCoefficientMatrix t s),diagonalPolynomial_homogeneous _⟩

theorem boundaryCoefficientMatrix_row (t : Fin n → ℝ) (hn : 0<n)
    (ht : ∑ i,t i=n) (s : ℝ) (r : Fin n) : ∑ i,boundaryCoefficientMatrix t s r i=1 := by
  have h := congrArg (fun M : Matrix (Fin n) (Fin n) ℝ => M r r)
    (boundaryPerturbedTuple_sum t hn ht s)
  simpa only [Matrix.sum_apply,boundaryPerturbedTuple_diagonal,Matrix.diagonal_apply_eq,
    Matrix.one_apply_eq,boundaryCoefficientMatrix] using h

theorem boundaryCoefficientMatrix_column (t : Fin n → ℝ) (hn : 0<n)
    (s : ℝ) (i : Fin n) : ∑ r,boundaryCoefficientMatrix t s r i=t i := by
  simpa only [boundaryPerturbedTuple_diagonal,Matrix.trace_diagonal,boundaryCoefficientMatrix] using
    boundaryPerturbedTuple_trace t hn s i

theorem stableBoundaryCurve_continuous (t : Fin n → ℝ) : Continuous (stableBoundaryCurve t) := by
  apply continuous_induced_rng.mpr
  apply continuous_pi
  intro d
  exact diagonalPolynomial_coefficient_continuous (boundaryCoefficientMatrix t)
    (fun r i => by unfold boundaryCoefficientMatrix;fun_prop) d

theorem stableBoundaryCurve_zero (t : Fin n → ℝ) : stableBoundaryCurve t 0=fixedDegreeReference t := by
  apply Subtype.ext
  change diagonalPencilPolynomial (boundaryCoefficientMatrix t 0)=scalarPower t n
  rw [diagonalPencilPolynomial_eq_product]
  simp only [boundaryCoefficientMatrix,zero_mul,zero_add,add_zero,Finset.prod_const,
    Finset.card_univ,Fintype.card_fin,scalarPower,scalarLinear]

theorem stableBoundaryCurve_feasible_near_zero (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) :
    ∃ e : ℝ,0<e ∧ ∀ s : ℝ,|s|<e → stableBoundaryCurve t s∈stableCoefficientClass t := by
  have hnpos : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
  obtain ⟨e,he,hnear⟩ := finite_affine_positive_near_zero
    (fun q : Fin n × Fin n => t q.2/(n : ℝ))
    (fun q => (t q.2*projectedOnes t q.2)*boundaryModelDiagonal n q.1)
    (fun q => div_pos (htpos q.2) hnpos)
  refine ⟨e,he,?_⟩
  intro s hs
  have hB : ∀ r i,0≤boundaryCoefficientMatrix t s r i := by
    intro r i
    exact le_of_lt (by simpa only [boundaryCoefficientMatrix,mul_assoc] using hnear s hs (r,i))
  have hrow := boundaryCoefficientMatrix_row t (by omega) ht s
  refine ⟨diagonalPolynomial_normalized _ hrow,diagonalPolynomial_stable _ hB hrow,
    diagonalPolynomial_coeff_nonnegative _ hB,?_⟩
  intro i
  change MvPolynomial.eval (fun _ => 1) (pderiv i (diagonalPencilPolynomial (boundaryCoefficientMatrix t s)))=t i
  rw [diagonalPolynomial_gradient _ hrow,boundaryCoefficientMatrix_column t (by omega)]

theorem stableBoundaryCurve_objective (t : Fin n → ℝ) (hn : 0<n) (s : ℝ) :
    fixedDegreeObjective (stableBoundaryCurve t s)=(boundaryMixedPolynomial t).eval s := by
  rw [boundaryMixedPolynomial_eval t hn s]
  have he : boundaryPerturbedTuple t s=(fun i => Matrix.diagonal (fun r => boundaryCoefficientMatrix t s r i)) := by
    funext i
    exact boundaryPerturbedTuple_diagonal t s i
  rw [he,mixedDiscriminant_diagonal]
  rfl

end CoefficientStability
