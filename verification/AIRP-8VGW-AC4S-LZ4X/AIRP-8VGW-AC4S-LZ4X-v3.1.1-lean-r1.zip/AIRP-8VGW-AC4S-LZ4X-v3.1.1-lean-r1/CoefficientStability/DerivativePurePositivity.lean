import CoefficientStability.HomogeneousBasisEvaluation
import CoefficientStability.PositiveFactorCapacity
import CoefficientStability.CapacityApplicationPositivity

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem positive_constant_split_derivative_zero_pos (P : Polynomial ℝ) (hs : P.Splits)
    (hp : ∀ x : ℝ,0<x → 0<P.eval x) (hzero : 0<P.eval 0) (hdegree : 0<P.natDegree) :
    0<P.derivative.eval 0 := by
  obtain ⟨k,hk,b,hb,hfactor⟩ := positive_split_positive_factor_form P hs hp hzero
  have he : P=positiveCapacityPolynomial (P.eval 0) b := by
    apply Polynomial.funext
    intro z
    rw [positiveCapacityPolynomial_eval]
    exact hfactor z
  rw [he,positiveCapacityPolynomial_derivative_zero]
  exact mul_pos hzero (positive_vector_sum_pos b (by omega) hb)

theorem stable_partial_pure_coeff_pos (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous (N+1)) (hs : UpperHalfPlaneZeroFree p) (hc : ∀ g,0≤p.coeff g)
    (i j : Fin n) (hji : j≠i)
    (hpi : 0<p.coeff (Finsupp.single i (N+1))) (hpj : 0<p.coeff (Finsupp.single j (N+1))) :
    0<(pderiv i p).coeff (Finsupp.single j N) := by
  classical
  let x : Fin n → ℝ := Pi.single j 1
  let P := realCoordinateRestriction x i p
  have hpos : ∀ r : ℝ,0≤r → 0<P.eval r := by
    intro r hr
    rw [realCoordinateRestriction_eval]
    refine polynomial_eval_pos_of_positive_pure_coefficient p _ (N+1) j hc ?_ hpj ?_
    · intro k
      by_cases hki : k=i
      · subst k
        simpa using hr
      · simp only [Function.update_of_ne hki]
        dsimp [x]
        simp only [Pi.single_apply]
        split_ifs <;> norm_num
    · simpa only [Function.update_of_ne hji,x,Pi.single_eq_same] using (show (0 : ℝ)<1 by norm_num)
  have hzero := hpos 0 (le_refl _)
  have hPne : P≠0 := by intro hz; simp [hz] at hzero
  have hPs := (stable_realCoordinateRestriction_zero_or_stable p hs x i).resolve_left hPne
  have hsplit := real_upper_zero_free_splits P hPs
  have htop : P.coeff (N+1)=p.coeff (Finsupp.single i (N+1)) :=
    homogeneous_realCoordinateRestriction_top_coeff p (N+1) hp x i
  have hdegree : P.natDegree=N+1 := Polynomial.natDegree_eq_of_le_of_coeff_ne_zero
    (homogeneous_realCoordinateRestriction_degree_le p (N+1) hp x i) (by rw [htop];exact ne_of_gt hpi)
  have hd := positive_constant_split_derivative_zero_pos P hsplit (fun r hr => hpos r hr.le) hzero (by omega)
  have hxi : x i=0 := by simp [x,Pi.single_apply,hji,Ne.symm hji]
  have hupdate : Function.update x i 0=x := by rw [← hxi,Function.update_eq_self]
  have hbridge : P.derivative.eval 0=(pderiv i p).coeff (Finsupp.single j N) := by
    rw [← realCoordinateRestriction_partial,realCoordinateRestriction_eval,hupdate]
    exact homogeneous_eval_basis (pderiv i p) N (homogeneous_partial p N hp i) j
  rw [hbridge] at hd
  exact hd

theorem lastDerivativeElimination_pure_coeff_pos (p : MvPolynomial (Fin (n+1)) ℝ)
    (hp : p.IsHomogeneous (n+1)) (hs : UpperHalfPlaneZeroFree p) (hc : ∀ g,0≤p.coeff g)
    (hpure : ∀ i,0<p.coeff (Finsupp.single i (n+1))) :
    ∀ j,0<(lastDerivativeElimination p).coeff (Finsupp.single j n) := by
  intro j
  rw [lastDerivativeElimination,dropLastPolynomial_coeff,Finsupp.mapDomain_single]
  exact stable_partial_pure_coeff_pos p n hp hs hc (Fin.last n) j.castSucc
    (Fin.castSucc_ne_last j) (hpure _) (hpure _)

end CoefficientStability
