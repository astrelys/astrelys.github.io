import CoefficientStability.LocalBoundaryObstruction

noncomputable section
open scoped BigOperators ComplexOrder
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem complexMixedDiscriminant_star (A : Fin n → Matrix (Fin n) (Fin n) ℂ)
    (hA : ∀ i,(A i).IsHermitian) : star (complexMixedDiscriminant A)=complexMixedDiscriminant A := by
  let M : Matrix (Fin n) (Fin n) (MvPolynomial (Fin n) ℂ) :=
    ∑ i,(MvPolynomial.X i : MvPolynomial (Fin n) ℂ) •
      (A i).map (MvPolynomial.C : ℂ →+* MvPolynomial (Fin n) ℂ)
  have he : (MvPolynomial.map (starRingEnd ℂ)).mapMatrix M=M.transpose := by
    apply Matrix.ext
    intro r l
    simp only [M,RingHom.mapMatrix_apply,Matrix.map_apply,Matrix.sum_apply,Matrix.smul_apply,
      smul_eq_mul,map_sum,map_mul,MvPolynomial.map_X,MvPolynomial.map_C,Matrix.transpose_apply]
    apply Finset.sum_congr rfl
    intro i hi
    have hs := (hA i).apply l r
    simpa only [starRingEnd_apply,hs] using congrArg (fun z : ℂ => MvPolynomial.X i*MvPolynomial.C z) hs
  have hp := (MvPolynomial.map (starRingEnd ℂ)).map_det M
  rw [he,Matrix.det_transpose] at hp
  have hc := congrArg (fun p : MvPolynomial (Fin n) ℂ => p.coeff (squarefreeExponent n)) hp
  simp only [MvPolynomial.coeff_map] at hc
  exact hc

theorem complexMixedDiscriminant_im_zero (A : Fin n → Matrix (Fin n) (Fin n) ℂ)
    (hA : ∀ i,(A i).IsHermitian) : (complexMixedDiscriminant A).im=0 := by
  have h := congrArg Complex.im (complexMixedDiscriminant_star A hA)
  change -(complexMixedDiscriminant A).im=(complexMixedDiscriminant A).im at h
  linarith

theorem complexMixedDiscriminant_eq_realObjective (A : Fin n → Matrix (Fin n) (Fin n) ℂ)
    (hA : ∀ i,(A i).IsHermitian) :
    complexMixedDiscriminant A=Complex.ofReal (hermitianMixedObjective A) := by
  apply Complex.ext
  · simp [hermitianMixedObjective]
  · simp [complexMixedDiscriminant_im_zero A hA]

end CoefficientStability
