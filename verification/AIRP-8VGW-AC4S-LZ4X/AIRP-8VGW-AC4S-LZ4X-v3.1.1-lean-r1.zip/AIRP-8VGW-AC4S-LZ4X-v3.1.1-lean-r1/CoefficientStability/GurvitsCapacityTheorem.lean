import CoefficientStability.CapacityBoundaryCases
import CoefficientStability.GurvitsConstants

noncomputable section
open MvPolynomial
namespace CoefficientStability

theorem gurvits_capacity_lower_zero_or_stable (n : ℕ) (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (hc : ∀ g,0≤p.coeff g) (hs : p=0 ∨ UpperHalfPlaneZeroFree p) :
    sourceVn n*multivariatePositiveCapacity p≤p.coeff (squarefreeExponent n) := by
  induction n with
  | zero =>
    rw [sourceVn_zero,one_mul,multivariatePositiveCapacity_zero_dimension,squarefreeExponent_zero_dimension]
  | succ n ih =>
    rcases hs with hz | hs
    · subst p
      rw [multivariatePositiveCapacity_zero,mul_zero]
      simp
    · let q := lastDerivativeElimination p
      have hqhom : q.IsHomogeneous n := lastDerivativeElimination_homogeneous p n hp
      have hqcoeff : ∀ g,0≤q.coeff g := nonnegative_stable_derivative_elimination_coeff p n hp hs hc
      have hqstable : q=0 ∨ UpperHalfPlaneZeroFree q := stable_last_derivative_elimination_zero_or_stable p hs
      have hind := ih q hqhom hqcoeff hqstable
      have hstep := multivariate_capacity_derivative_elimination p hs hc (n+1)
        (homogeneous_degreeOf_le p (n+1) hp (Fin.last n))
      calc
        sourceVn (n+1)*multivariatePositiveCapacity p=
            sourceVn n*(capacityG (n+1)*multivariatePositiveCapacity p) := by
          rw [sourceVn_capacityG_recurrence,mul_assoc]
        _ ≤sourceVn n*multivariatePositiveCapacity q :=
          mul_le_mul_of_nonneg_left hstep (sourceVn_nonneg n)
        _ ≤q.coeff (squarefreeExponent n) := hind
        _ =p.coeff (squarefreeExponent (n+1)) := lastDerivativeElimination_squarefree_coeff p

theorem paper_gurvits_capacity_lower (n : ℕ) (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p) (hc : ∀ g,0≤p.coeff g) :
    sourceVn n*multivariatePositiveCapacity p≤p.coeff (squarefreeExponent n) :=
  gurvits_capacity_lower_zero_or_stable n p hp hc (Or.inr hs)

theorem normalized_stable_gurvits_capacity_lower (n : ℕ) (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) :
    sourceVn n*multivariatePositiveCapacity p≤p.coeff (squarefreeExponent n) :=
  paper_gurvits_capacity_lower n p hp hs (normalized_homogeneous_stable_coeff_nonneg p n hp hs hnorm)

theorem normalized_balanced_squarefree_lower (n : ℕ) (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=1) :
    sourceVn n≤p.coeff (squarefreeExponent n) := by
  have hc := normalized_homogeneous_stable_coeff_nonneg p n hp hs hnorm
  have h := paper_gurvits_capacity_lower n p hp hs hc
  rw [paper_balanced_capacity_one p hc hnorm hgrad,mul_one] at h
  exact h

theorem normalized_balanced_excess_nonneg (n : ℕ) (hn : 0<n) (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=1) :
    0≤p.coeff (squarefreeExponent n)/sourceVn n-1 := by
  apply sub_nonneg.mpr
  apply (le_div_iff₀ (sourceVn_pos hn)).mpr
  simpa only [one_mul] using normalized_balanced_squarefree_lower n p hp hs hnorm hgrad

end CoefficientStability
