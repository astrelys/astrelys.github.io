import CoefficientStability.TiltFrechet

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def sourceVn (n : ℕ) : ℝ := (n.factorial : ℝ)/(n : ℝ)^n

theorem sourceVn_pos (hn : 0<n) : 0<sourceVn n := by
  exact div_pos (by exact_mod_cast Nat.factorial_pos n)
    (pow_pos (by exact_mod_cast hn) _)

theorem tilted_allones_coefficient_pos (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ)
    (hc : ∀ g,0≤p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hL : 0<p.coeff (squarefreeExponent n)) :
    0<(tiltedPolynomial p u).coeff (squarefreeExponent n) := by
  rw [tiltedPolynomial_coeff]
  exact div_pos (mul_pos hL (Real.exp_pos _)) (tiltPartition_pos p u hc hnorm)

theorem tiltPartition_eq_eval_exp (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ)
    (hZ : tiltPartition p u≠0) : tiltPartition p u=MvPolynomial.eval (fun i => Real.exp (u i)) p := by
  have h := tiltedPolynomial_eval p u (fun _ => 1)
  rw [tiltedPolynomial_normalized p u hZ] at h
  simp only [mul_one] at h
  exact (div_eq_one_iff_eq hZ).mp h.symm |>.symm

theorem paper_tilt_eval (p : MvPolynomial (Fin n) ℝ) (u x : Fin n → ℝ)
    (hc : ∀ g,0≤p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1) :
    MvPolynomial.eval x (tiltedPolynomial p u)=
      MvPolynomial.eval (fun i => Real.exp (u i)*x i) p/MvPolynomial.eval (fun i => Real.exp (u i)) p := by
  rw [tiltedPolynomial_eval,tiltPartition_eq_eval_exp p u (ne_of_gt (tiltPartition_pos p u hc hnorm))]

theorem paper_ratio_gradient (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ)
    (hp : p.IsHomogeneous n) (hn : 2≤n) (hc : ∀ g,0≤p.coeff g)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hL : 0<p.coeff (squarefreeExponent n))
    (ht : ∀ i,0<tiltedMoment p u i) :
    (fun j => (fderiv ℝ (tiltLogRatio p (sourceVn n)) u) (Pi.single j 1))=
      (2 : ℝ) • (deficitMatrix (tiltedPolynomial p u) (tiltedMoment p u) n).mulVec
        (fun i => 1/tiltedMoment p u i-1) := by
  funext j
  simp only [Pi.smul_apply,smul_eq_mul,Matrix.mulVec,dotProduct]
  exact paper_ratio_gradient_frechet p u hp hn (ne_of_gt (tiltPartition_pos p u hc hnorm)) _
    (ne_of_gt (sourceVn_pos (by omega)))
    (ne_of_gt (tilted_allones_coefficient_pos p u hc hnorm hL)) (fun i => ne_of_gt (ht i)) j

theorem vector_standard_expansion (v : Fin n → ℝ) : v=∑ j,v j • Pi.single j (1 : ℝ) := by
  funext k
  simp [Finset.sum_apply,Pi.single_apply]

theorem paper_ratio_gradient_all_directions (p : MvPolynomial (Fin n) ℝ) (u v : Fin n → ℝ)
    (hp : p.IsHomogeneous n) (hn : 2≤n) (hc : ∀ g,0≤p.coeff g)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hL : 0<p.coeff (squarefreeExponent n))
    (ht : ∀ i,0<tiltedMoment p u i) :
    (fderiv ℝ (tiltLogRatio p (sourceVn n)) u) v=
      ∑ j,((2 : ℝ) • (deficitMatrix (tiltedPolynomial p u) (tiltedMoment p u) n).mulVec
        (fun i => 1/tiltedMoment p u i-1)) j*v j := by
  have hg := paper_ratio_gradient p u hp hn hc hnorm hL ht
  conv_lhs => rw [vector_standard_expansion v]
  rw [map_sum]
  apply Finset.sum_congr rfl
  intro j hj
  rw [map_smul]
  have hgj := congrFun hg j
  rw [hgj]
  simp only [smul_eq_mul]
  ring

end CoefficientStability
