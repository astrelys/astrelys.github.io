import CoefficientStability.SourceProjectionContainment

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 2700000
set_option backward.isDefEq.respectTransparency false

theorem source_zero_projection_resolution_canonical
    (P : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (b : Fin 3 → ℝ)
    (hP : ∀ i,(P i).PosSemidef) (hPP : ∀ i,P i*P i=P i) (htr : ∀ i,Matrix.trace (P i)=1)
    (hzero : (∑ i,(b i : ℂ) • P i)=0) (hb0 : 0 < b 0) (hb1 : b 1≠0) : P 0=P 1 := by
  have hs := hzero
  norm_num only [Fin.sum_univ_succ,Fin.sum_univ_zero,Fin.reduceFinMk,add_zero] at hs
  change (b 0 : ℂ) • P 0+((b 1 : ℂ) • P 1+(b 2 : ℂ) • P 2)=0 at hs
  have hsl : (b 0 : ℂ) • P 0+(b 1 : ℂ) • P 1+(b 2 : ℂ) • P 2=0 := by simpa only [add_assoc] using hs
  have hd2 : ((-b 2 : ℝ) : ℂ) • P 2=(b 0 : ℂ) • P 0+(b 1 : ℂ) • P 1 := by
    simp only [Complex.ofReal_neg,neg_smul]
    calc
      -((b 2 : ℂ) • P 2)=0-(b 2 : ℂ) • P 2 := by simp
      _=((b 0 : ℂ) • P 0+(b 1 : ℂ) • P 1+(b 2 : ℂ) • P 2)-(b 2 : ℂ) • P 2 := by rw [hsl]
      _=(b 0 : ℂ) • P 0+(b 1 : ℂ) • P 1 := by abel
  by_cases hb1p : 0 < b 1
  · have h20 := source_positive_projection_resolution_equality (P 2) (P 0) (P 1)
      (hP 2) (hP 0) (hP 1) (hPP 2) (hPP 0) ((htr 2).trans (htr 0).symm)
      (-b 2) (b 0) (b 1) hb0 hb1p.le hd2
    have hd2' : ((-b 2 : ℝ) : ℂ) • P 2=(b 1 : ℂ) • P 1+(b 0 : ℂ) • P 0 := hd2.trans (add_comm _ _)
    have h21 := source_positive_projection_resolution_equality (P 2) (P 1) (P 0)
      (hP 2) (hP 1) (hP 0) (hPP 2) (hPP 1) ((htr 2).trans (htr 1).symm)
      (-b 2) (b 1) (b 0) hb1p hb0.le hd2'
    exact h20.symm.trans h21
  · have hb1n : b 1 < 0 := lt_of_le_of_ne (le_of_not_gt hb1p) hb1
    by_cases hb2 : 0 ≤ b 2
    · have hd1 : ((-b 1 : ℝ) : ℂ) • P 1=(b 0 : ℂ) • P 0+(b 2 : ℂ) • P 2 := by
        simp only [Complex.ofReal_neg,neg_smul]
        calc
          -((b 1 : ℂ) • P 1)=0-(b 1 : ℂ) • P 1 := by simp
          _=((b 0 : ℂ) • P 0+(b 1 : ℂ) • P 1+(b 2 : ℂ) • P 2)-(b 1 : ℂ) • P 1 := by rw [hsl]
          _=(b 0 : ℂ) • P 0+(b 2 : ℂ) • P 2 := by abel
      exact (source_positive_projection_resolution_equality (P 1) (P 0) (P 2)
        (hP 1) (hP 0) (hP 2) (hPP 1) (hPP 0) ((htr 1).trans (htr 0).symm)
        (-b 1) (b 0) (b 2) hb0 hb2 hd1).symm
    · have hd0 : (b 0 : ℂ) • P 0=((-b 1 : ℝ) : ℂ) • P 1+((-b 2 : ℝ) : ℂ) • P 2 := by
        simp only [Complex.ofReal_neg,neg_smul]
        calc
          (b 0 : ℂ) • P 0=((b 0 : ℂ) • P 0+(b 1 : ℂ) • P 1+(b 2 : ℂ) • P 2)-(b 1 : ℂ) • P 1-(b 2 : ℂ) • P 2 := by abel
          _=-((b 1 : ℂ) • P 1)+-((b 2 : ℂ) • P 2) := by rw [hsl];abel
      exact source_positive_projection_resolution_equality (P 0) (P 1) (P 2)
        (hP 0) (hP 1) (hP 2) (hPP 0) (hPP 1) ((htr 0).trans (htr 1).symm)
        (b 0) (-b 1) (-b 2) (by linarith) (by linarith) hd0

theorem source_zero_projection_resolution_participating_equal
    (P : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (b : Fin 3 → ℝ)
    (hP : ∀ i,(P i).PosSemidef) (hPP : ∀ i,P i*P i=P i) (htr : ∀ i,Matrix.trace (P i)=1)
    (hzero : (∑ i,(b i : ℂ) • P i)=0) : ∀ i j,b i≠0 → b j≠0 → P i=P j := by
  classical
  have hp : ∀ i j : Fin 3,i≠j → ∃ r : Equiv.Perm (Fin 3),r 0=i ∧ r 1=j := by decide
  intro i j hi hj
  by_cases hij : i=j
  · rw [hij]
  obtain ⟨r,hr0,hr1⟩ := hp i j hij
  have hs : (∑ k,(b (r k) : ℂ) • P (r k))=0 := (Equiv.sum_comp r (fun k => (b k : ℂ) • P k)).trans hzero
  by_cases hb : 0 < b i
  · have h := source_zero_projection_resolution_canonical (fun k => P (r k)) (fun k => b (r k))
      (fun k => hP (r k)) (fun k => hPP (r k)) (fun k => htr (r k)) hs (by simpa [hr0] using hb) (by simpa [hr1] using hj)
    simpa only [hr0,hr1] using h
  · have hneg : b i < 0 := lt_of_le_of_ne (le_of_not_gt hb) hi
    have hsneg : (∑ k,((-b (r k) : ℝ) : ℂ) • P (r k))=0 := by
      simp only [Complex.ofReal_neg,neg_smul,Finset.sum_neg_distrib,hs,neg_zero]
    have h := source_zero_projection_resolution_canonical (fun k => P (r k)) (fun k => -b (r k))
      (fun k => hP (r k)) (fun k => hPP (r k)) (fun k => htr (r k)) hsneg
      (by rw [hr0];linarith) (by rw [hr1];exact neg_ne_zero.mpr hj)
    simpa only [hr0,hr1] using h

end CoefficientStability
