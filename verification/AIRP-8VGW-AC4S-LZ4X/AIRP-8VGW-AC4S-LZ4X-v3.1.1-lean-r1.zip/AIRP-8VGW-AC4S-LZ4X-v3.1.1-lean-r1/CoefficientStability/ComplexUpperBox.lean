import CoefficientStability.StableLine
import Mathlib.Algebra.MvPolynomial.Funext
import CoefficientStability.HolomorphicBoundary
import Mathlib.Analysis.Analytic.Polynomial
import Mathlib.Analysis.Convex.Basic

noncomputable section
open scoped Topology
namespace CoefficientStability
variable {n : ℕ}

def upperHalfPlaneBox (n : ℕ) : Set (Fin n → ℂ) := {z | ∀ i,0<(z i).im}

theorem upperHalfPlaneBox_open (n : ℕ) : IsOpen (upperHalfPlaneBox n) := by
  have h : ∀ i : Fin n,IsOpen {z : Fin n → ℂ | 0<(z i).im} := fun i =>
    isOpen_lt continuous_const (Complex.continuous_im.comp (continuous_apply i))
  simpa only [upperHalfPlaneBox,Set.setOf_forall] using isOpen_iInter_of_finite h

theorem upperHalfPlaneBox_convex (n : ℕ) : Convex ℝ (upperHalfPlaneBox n) := by
  have h (i : Fin n) : Convex ℝ {z : Fin n → ℂ | 0<(z i).im} :=
    (convex_Ioi (0 : ℝ)).linear_preimage
      ((Complex.imCLM.comp (ContinuousLinearMap.proj i : (Fin n → ℂ) →L[ℝ] ℂ)).toLinearMap)
  simpa only [upperHalfPlaneBox,Set.setOf_forall] using convex_iInter h

theorem complex_upper_halfplane_infinite : {z : ℂ | 0<z.im}.Infinite := by
  have hi : Function.Injective (fun r : ℝ => (r : ℂ)+Complex.I) := by
    intro a b hab
    have h := congrArg Complex.re hab
    simpa using h
  have h := Set.infinite_range_of_injective hi
  apply h.mono
  rintro z ⟨r,rfl⟩
  simp

theorem realMvPolynomial_complex_eval_analyticAt (p : MvPolynomial (Fin n) ℝ) (z : Fin n → ℂ) :
    AnalyticAt ℂ (fun x : Fin n → ℂ => MvPolynomial.eval₂ Complex.ofRealHom x p) z := by
  induction p using MvPolynomial.induction_on with
  | C c =>
    simp only [MvPolynomial.eval₂_C]
    exact analyticAt_const
  | add p q hp hq =>
    simpa only [MvPolynomial.eval₂_add,Pi.add_def] using hp.add hq
  | mul_X p i hp =>
    simpa only [MvPolynomial.eval₂_mul,MvPolynomial.eval₂_X,Pi.mul_def,ContinuousLinearMap.proj_apply] using
      hp.mul ((ContinuousLinearMap.proj i : (Fin n → ℂ) →L[ℂ] ℂ).analyticAt z)

theorem realMvPolynomial_eq_zero_of_upper_evaluation (p : MvPolynomial (Fin n) ℝ)
    (hp : ∀ z : Fin n → ℂ,(∀ i,0<(z i).im) → MvPolynomial.eval₂ Complex.ofRealHom z p=0) : p=0 := by
  have hm : MvPolynomial.map Complex.ofRealHom p=0 := by
    apply MvPolynomial.funext_set (fun _ : Fin n => {z : ℂ | 0<z.im}) (fun _ => complex_upper_halfplane_infinite)
    intro z hz
    rw [map_zero]
    simpa only [MvPolynomial.eval_map] using hp z (fun i => hz i (Set.mem_univ i))
  exact (MvPolynomial.map_injective Complex.ofRealHom Complex.ofReal_injective) (by simpa only [map_zero] using hm)

end CoefficientStability
