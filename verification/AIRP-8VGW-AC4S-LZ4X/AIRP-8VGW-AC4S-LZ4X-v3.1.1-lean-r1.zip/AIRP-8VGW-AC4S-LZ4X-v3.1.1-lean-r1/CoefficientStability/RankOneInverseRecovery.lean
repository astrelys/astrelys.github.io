import CoefficientStability.RankOneDegreeReduction
import CoefficientStability.SourceNearBalancedCapacity

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def rankOneRemixingMatrix (n : ℕ) (j : Fin n) (r : ℝ) : Matrix (Fin n) (Fin n) ℝ :=
  fun i k => (if i=k then 1 else 0)+(if k=j then r/(1-r) else 0)

theorem rankOneUnmixingMatrix_mulVec_coordinate (j : Fin n) (r : ℝ) (x : Fin n → ℝ) (i : Fin n) :
    ((rankOneUnmixingMatrix n j r).mulVec x) i=x i-r*x j := by
  classical
  simp [Matrix.mulVec,dotProduct,rankOneUnmixingMatrix,sub_mul,Finset.sum_sub_distrib,ite_mul]

theorem rankOneRemixingMatrix_mulVec_coordinate (j : Fin n) (r : ℝ) (x : Fin n → ℝ) (i : Fin n) :
    ((rankOneRemixingMatrix n j r).mulVec x) i=x i+(r/(1-r))*x j := by
  classical
  simp [Matrix.mulVec,dotProduct,rankOneRemixingMatrix,add_mul,Finset.sum_add_distrib,ite_mul]

theorem rankOne_inverse_image_recovery (j : Fin n) (r : ℝ) (hr : 1-r≠0) (x : Fin n → ℝ) :
    (rankOneUnmixingMatrix n j r).mulVec ((rankOneRemixingMatrix n j r).mulVec x)=x := by
  funext i
  rw [rankOneUnmixingMatrix_mulVec_coordinate,rankOneRemixingMatrix_mulVec_coordinate,
    rankOneRemixingMatrix_mulVec_coordinate]
  field_simp
  <;> ring

theorem rankOne_inverse_polynomial_recovery (p : MvPolynomial (Fin n) ℝ)
    (j : Fin n) (r : ℝ) (hr : 1-r≠0) :
    matrixSubstitution (rankOneRemixingMatrix n j r)
      (matrixSubstitution (rankOneUnmixingMatrix n j r) p)=p := by
  apply MvPolynomial.funext
  intro x
  rw [matrixSubstitution_eval,matrixSubstitution_eval,rankOne_inverse_image_recovery j r hr]

theorem rankOneRemixingMatrix_nonnegative (j : Fin n) (r : ℝ) (hr : 0≤r) (hr1 : r<1) :
    ∀ i k,0≤rankOneRemixingMatrix n j r i k := by
  intro i k
  have hb : 0≤r/(1-r) := div_nonneg hr (by linarith)
  simp only [rankOneRemixingMatrix]
  split_ifs <;> linarith

end CoefficientStability
