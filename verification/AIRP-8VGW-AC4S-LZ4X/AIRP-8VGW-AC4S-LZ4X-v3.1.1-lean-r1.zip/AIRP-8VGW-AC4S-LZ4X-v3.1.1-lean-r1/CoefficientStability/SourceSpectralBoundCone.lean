import CoefficientStability.SourceSpectralSumSuperadditivity

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem actual_source_subset_bound_iff_closed_cone (p : MvPolynomial (Fin n) ℝ) (N k : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hk : 0<k) (hkN : k≤N)
    (x : Fin n → ℝ) (roots : Fin N → ℝ)
    (hf : lineRestriction p x=∏ i : Fin N,(Polynomial.X+Polynomial.C (roots i))) (a : ℝ) :
    (fun j => x j+ -(a/(k : ℝ)))∈closure
      (positiveSpectralCone (normalizedSourceSubsetPolynomial p N k) (N.choose k)) ↔
      ∀ s∈Finset.univ.powersetCard k,a≤∑ i∈s,roots i := by
  classical
  let Q := normalizedSourceSubsetPolynomial p N k
  let S : Finset (Finset (Fin N)) := Finset.univ.powersetCard k
  have hD : 0<N.choose k := Nat.choose_pos hkN
  have hkreal : 0<(k : ℝ) := by exact_mod_cast hk
  obtain ⟨hQhom,hQstable,hQnorm⟩ := normalizedSourceSubsetPolynomial_properties p N k hp hs hnorm hk
  have hcard : S.card=N.choose k := by simp [S]
  have hfactor := normalizedSourceSubsetPolynomial_line_factors p N k x roots hf hk
  have hshift := actual_finite_root_factor_shift Q x S (fun s => (∑ i∈s,roots i)/(k : ℝ)) hfactor (-(a/(k : ℝ)))
  constructor
  · intro hx s hs
    have hnonneg := source_closedCone_finite_factors_nonneg Q hD hQhom hQstable hQnorm _ hx S
      (fun s => (∑ i∈s,roots i)/(k : ℝ)+ -(a/(k : ℝ))) hshift
    have hratio : a/(k : ℝ)≤(∑ i∈s,roots i)/(k : ℝ) := by linarith [hnonneg s hs]
    exact (div_le_div_iff_of_pos_right hkreal).mp hratio
  · intro hbound
    apply source_nonnegative_finite_factors_mem_closure Q (N.choose k) _ S
      (fun s => (∑ i∈s,roots i)/(k : ℝ)+ -(a/(k : ℝ))) hcard
    · intro s hs
      have hratio := div_le_div_of_nonneg_right (hbound s hs) hkreal.le
      linarith
    · exact hshift

end CoefficientStability
