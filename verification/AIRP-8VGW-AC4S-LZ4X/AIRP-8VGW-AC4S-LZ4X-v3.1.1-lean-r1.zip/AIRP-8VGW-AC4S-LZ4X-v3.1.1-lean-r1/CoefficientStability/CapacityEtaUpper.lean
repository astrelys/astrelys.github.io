import CoefficientStability.CapacityEtaLower
import Mathlib.Analysis.Complex.ExponentialBounds

noncomputable section
namespace CoefficientStability

theorem capacityLogG_lower (x : ℝ) (hx : 1<x) : -1≤capacityLogG x := by
  have hxp : 0<x := by linarith
  have hbase : 0<1-1/x := sub_pos.mpr ((div_lt_one hxp).mpr hx)
  have hlog := Real.one_sub_inv_le_log_of_pos hbase
  have h := mul_le_mul_of_nonneg_left hlog (sub_pos.mpr hx).le
  have he : (x-1)*(1-(1-1/x)⁻¹)= -1 := by
    field_simp [ne_of_gt hxp,ne_of_gt (sub_pos.mpr hx)] <;> ring
  rw [he] at h
  exact h

theorem exp_neg_one_ge_quarter : (1/4 : ℝ)≤Real.exp (-1) := by
  have h4 : Real.exp (1 : ℝ)≤4 := by linarith [Real.exp_one_lt_d9]
  have h := mul_le_mul_of_nonneg_left h4 (Real.exp_pos (-1 : ℝ)).le
  rw [← Real.exp_add] at h
  norm_num at h
  linarith

theorem capacityG_lower_quarter (n : ℕ) (hn : 2≤n) : (1/4 : ℝ)≤capacityG n := by
  have hn' : (1 : ℝ)<n := by exact_mod_cast (by omega : 1<n)
  calc
    (1/4 : ℝ)≤Real.exp (-1) := exp_neg_one_ge_quarter
    _ ≤Real.exp (capacityLogG n) := Real.exp_le_exp.mpr (capacityLogG_lower _ hn')
    _ =capacityG n := exp_capacityLogG_nat n hn

theorem capacityEta_upper (n : ℕ) (hn : 3≤n) : capacityEta n≤1 := by
  have hprev := capacityG_antitone (by omega : 2≤n-1)
  have hg2 : capacityG 2=(1/2 : ℝ) := by norm_num [capacityG]
  rw [hg2] at hprev
  have hnext := capacityG_lower_quarter n (by omega)
  unfold capacityEta
  apply sub_le_iff_le_add.mpr
  apply (div_le_iff₀ (capacityG_pos (by omega : 2≤n))).mpr
  nlinarith

theorem paper_polynomial_constant_bounds (n : ℕ) (hn : 3≤n) :
    1/(2*(n : ℝ)^2)≤capacityEta n ∧ capacityEta n≤1 ∧
      1/(128*(n : ℝ)^4)≤sourceMixingRadius n ∧
      1/(1024*(n : ℝ)^3)≤sourceNoiseStrength n :=
  ⟨capacityEta_lower n hn,capacityEta_upper n hn,sourceMixingRadius_lower n hn,sourceNoiseStrength_lower n hn⟩

theorem capacityEta_pos (n : ℕ) (hn : 3≤n) : 0<capacityEta n := by
  have hnpos : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
  exact lt_of_lt_of_le (by positivity) (capacityEta_lower n hn)

theorem sourceMixingRadius_pos (n : ℕ) (hn : 3≤n) : 0<sourceMixingRadius n := by
  have hnpos : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
  exact div_pos (capacityEta_pos n hn) (by positivity)

theorem sourceMixingRadius_upper (n : ℕ) (hn : 3≤n) : sourceMixingRadius n≤1/(64*(n : ℝ)^2) := by
  exact div_le_div_of_nonneg_right (capacityEta_upper n hn) (by positivity)

theorem sourceNoiseStrength_pos (n : ℕ) (hn : 3≤n) : 0<sourceNoiseStrength n := by
  have hnpos : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
  exact div_pos (mul_pos hnpos (sourceMixingRadius_pos n hn)) (by norm_num)

end CoefficientStability
