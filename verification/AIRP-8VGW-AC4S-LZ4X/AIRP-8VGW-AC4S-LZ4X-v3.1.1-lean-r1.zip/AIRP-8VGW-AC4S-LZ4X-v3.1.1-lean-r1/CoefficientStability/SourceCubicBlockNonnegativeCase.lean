import CoefficientStability.SourceCubicBlockRadialMinimum

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 3000000
set_option backward.isDefEq.respectTransparency false

theorem source_three_zero_sum_one_zero_commute (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (hs : (∑ i,V i)=0) (hz : ∃ k,V k=0) : ∀ i j,V i*V j=V j*V i := by
  norm_num only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero] at hs
  change V 0+(V 1+V 2)=0 at hs
  obtain ⟨k,hk⟩ := hz
  fin_cases k
  · change V 0=0 at hk
    have hp : V 1+V 2=0 := by simpa only [hk,zero_add] using hs
    have he : V 2=-V 1 := by
      calc
        V 2=(V 1+V 2)-V 1 := by abel
        _=-V 1 := by rw [hp,zero_sub]
    intro i j
    fin_cases i <;> fin_cases j <;> simp [hk,he]
  · change V 1=0 at hk
    have hp : V 0+V 2=0 := by simpa only [hk,zero_add] using hs
    have he : V 2=-V 0 := by
      calc
        V 2=(V 0+V 2)-V 0 := by abel
        _=-V 0 := by rw [hp,zero_sub]
    intro i j
    fin_cases i <;> fin_cases j <;> simp [hk,he]
  · change V 2=0 at hk
    have hp : V 0+V 1=0 := by simpa only [hk,add_zero] using hs
    have he : V 1=-V 0 := by
      calc
        V 1=(V 0+V 1)-V 0 := by abel
        _=-V 0 := by rw [hp,zero_sub]
    intro i j
    fin_cases i <;> fin_cases j <;> simp [hk,he]

theorem source_two_centered_commute (b c : ℝ) (V W : Matrix (Fin 2) (Fin 2) ℂ)
    (hc : V*W=W*V) : sourceTwoCentered b V*sourceTwoCentered c W=sourceTwoCentered c W*sourceTwoCentered b V := by
  simp only [sourceTwoCentered,add_mul,mul_add,smul_mul_assoc,mul_smul_comm,one_mul,mul_one]
  rw [hc]
  module

theorem source_one_two_block_mul (a c : ℝ) (B D : Matrix (Fin 2) (Fin 2) ℂ) :
    sourceOneTwoBlock a B*sourceOneTwoBlock c D=sourceOneTwoBlock (a*c) (B*D) := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [sourceOneTwoBlock,Matrix.mul_apply,Fin.sum_univ_succ] <;> push_cast <;> ring

theorem source_one_two_block_commute (a c : ℝ) (B D : Matrix (Fin 2) (Fin 2) ℂ) (hBD : B*D=D*B) :
    sourceOneTwoBlock a B*sourceOneTwoBlock c D=sourceOneTwoBlock c D*sourceOneTwoBlock a B := by
  rw [source_one_two_block_mul,source_one_two_block_mul,hBD,mul_comm a c]

theorem source_cubic_block_tuple_scalar_sum (a b : Fin 3 → ℝ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hs : (∑ i,sourceCubicBlockTuple a b V i)=1) :
    (∑ i,a i)=1 := by
  have h := congrArg (fun M : Matrix (Fin 3) (Fin 3) ℂ => M 0 0) hs
  simp only [Matrix.sum_apply] at h
  change (∑ i,(a i : ℂ))=1 at h
  apply Complex.ofReal_injective
  push_cast
  exact h

theorem source_cubic_block_nonnegative_case_commutes (t a b : Fin 3 → ℝ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hV : ∀ i,(V i).IsHermitian)
    (ht : ∀ i,Matrix.trace (V i)=0) (hs : (∑ i,V i)=0)
    (hA : sourceCubicBlockTuple a b V ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (sourceCubicBlockTuple a b V))
    (ha : ∀ i,a i ≤ 1/2) : ∀ i j,sourceCubicBlockTuple a b V i*sourceCubicBlockTuple a b V j=
      sourceCubicBlockTuple a b V j*sourceCubicBlockTuple a b V i := by
  have has := source_cubic_block_tuple_scalar_sum a b V hA.2
  have hcs : (∑ i,(1-2*a i))=1 := by
    norm_num [Fin.sum_univ_succ] at has ⊢
    linarith
  have hp : ∃ k,0 < 1-2*a k := by
    by_contra! hn
    have hle : (∑ i,(1-2*a i)) ≤ 0 := Finset.sum_nonpos (fun i _ => hn i)
    linarith
  obtain ⟨k,hk⟩ := hp
  have hzero := source_cubic_block_positive_coefficient_vanishes t a b V hV ht hs hA hm ha k hk
  have hcomm := source_three_zero_sum_one_zero_commute V hs ⟨k,hzero⟩
  intro i j
  apply source_one_two_block_commute
  exact source_two_centered_commute (b i) (b j) (V i) (V j) (hcomm i j)

end CoefficientStability
