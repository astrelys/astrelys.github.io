import CoefficientStability.PaperRatioGradient
import Mathlib.Analysis.Calculus.LocalExtr.Basic

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem positive_capacity_minimizer_stationarity (c : ℝ) (b : Fin n → ℝ) (zstar : ℝ)
    (hc : 0<c) (hb : ∀ i,0<b i) (hz : 0<zstar)
    (hmin : ∀ z : ℝ,0<z → (c*∏ i,(1+b i*zstar))/zstar≤(c*∏ i,(1+b i*z))/z) :
    (∑ i,b i*zstar/(1+b i*zstar))=1 := by
  have hf (i : Fin n) : HasDerivAt (fun z : ℝ => 1+b i*z) (b i) zstar := by
    simpa only [mul_one,id_eq] using ((hasDerivAt_id zstar).const_mul (b i)).const_add 1
  have hp := HasDerivAt.fun_finsetProd (u := Finset.univ) (fun i hi => hf i)
  have hq := (hp.const_mul c).div (hasDerivAt_id zstar) (ne_of_gt hz)
  have hglobal : IsMinOn (fun z : ℝ => (c*∏ i,(1+b i*z))/z) (Set.Ioi 0) zstar := by
    intro z hz'
    exact hmin z hz'
  have hlocal := hglobal.isLocalMinOn.isLocalMin (isOpen_Ioi.mem_nhds hz)
  have hzero := hlocal.hasDerivAt_eq_zero hq
  simp only [id_eq,mul_one] at hzero
  have hnum : c*(∑ i,(∏ j∈Finset.univ.erase i,(1+b j*zstar))*b i)*zstar-
      c*(∏ i,(1+b i*zstar))=0 := by
    exact (div_eq_zero_iff.mp hzero).resolve_right (pow_ne_zero _ (ne_of_gt hz))
  have hstat : zstar*(∑ i,(∏ j∈Finset.univ.erase i,(1+b j*zstar))*b i)=∏ i,(1+b i*zstar) := by
    have he : c*(zstar*(∑ i,(∏ j∈Finset.univ.erase i,(1+b j*zstar))*b i)-
        ∏ i,(1+b i*zstar))=0 := by nlinarith
    exact sub_eq_zero.mp ((mul_eq_zero.mp he).resolve_left (ne_of_gt hc))
  have hP : 0<∏ i,(1+b i*zstar) := Finset.prod_pos (fun i hi => by nlinarith [hb i])
  apply mul_left_cancel₀ (ne_of_gt hP)
  rw [Finset.mul_sum,mul_one]
  have hterm (i : Fin n) :
      (∏ j,(1+b j*zstar))*(b i*zstar/(1+b i*zstar))=
        zstar*((∏ j∈Finset.univ.erase i,(1+b j*zstar))*b i) := by
    have he := Finset.mul_prod_erase (Finset.univ : Finset (Fin n)) (fun j => 1+b j*zstar) (Finset.mem_univ i)
    rw [← he]
    have hne : 1+b i*zstar≠0 := ne_of_gt (by nlinarith [hb i] : 0<1+b i*zstar)
    field_simp
  simp only [hterm,← Finset.mul_sum]
  exact hstat

end CoefficientStability
