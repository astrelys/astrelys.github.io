import CoefficientStability.SourceBalancedGateLocalAlgebra

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

theorem source_escape_abs_triple_squares (a b c δ σ : ℝ) (hδ : 0 ≤ δ)
    (ha : |a| ≤ δ) (hbc : b^2+c^2 ≤ σ) : |a*b*c| ≤ δ*σ/2 := by
  have hb : |b|^2=b^2 := sq_abs b
  have hc : |c|^2=c^2 := sq_abs c
  have hy : 2*|b| *|c| ≤ b^2+c^2 := by nlinarith [sq_nonneg (|b|-|c|)]
  have h1 := mul_le_mul_of_nonneg_right ha (mul_nonneg (abs_nonneg b) (abs_nonneg c))
  have h2 := mul_le_mul_of_nonneg_left (hy.trans hbc) hδ
  rw [abs_mul,abs_mul]
  nlinarith

theorem source_escape_abs_six_sum (a b c d e f : ℝ) :
    |a+b+c+d+e+f| ≤ |a|+|b|+|c|+|d|+|e|+|f| := by
  have h1 := abs_add_le a b
  have h2 := abs_add_le (a+b) c
  have h3 := abs_add_le (a+b+c) d
  have h4 := abs_add_le (a+b+c+d) e
  have h5 := abs_add_le (a+b+c+d+e) f
  linarith

theorem source_escape_actual_permanent_abs_cube_bound (H : Matrix (Fin 3) (Fin 3) ℝ)
    (δ : ℝ) (hδ : 0 ≤ δ) (hentry : ∀ i j,|H i j| ≤ δ) :
    |Matrix.permanent H| ≤ 3*δ*sourceEscapeFrobeniusSq H := by
  have ht (l j k : Fin 3) : |H 0 l*H 1 j*H 2 k| ≤ δ*sourceEscapeFrobeniusSq H/2 :=
    source_escape_abs_triple_squares _ _ _ δ _ hδ (hentry 0 l) (source_escape_two_rows_square_le_frobenius H j k)
  have htri := source_escape_abs_six_sum (H 0 0*H 1 1*H 2 2) (H 0 0*H 1 2*H 2 1)
    (H 0 1*H 1 0*H 2 2) (H 0 1*H 1 2*H 2 0) (H 0 2*H 1 0*H 2 1) (H 0 2*H 1 1*H 2 0)
  rw [source_permanent_three]
  nlinarith [ht 0 1 2,ht 0 2 1,ht 1 0 2,ht 1 2 0,ht 2 0 1,ht 2 1 0]

theorem source_escape_frobenius_cube_bound (H : Matrix (Fin 3) (Fin 3) ℝ)
    (δ : ℝ) (hentry : ∀ i j,|H i j| ≤ δ) : sourceEscapeFrobeniusSq H ≤ 9*δ^2 := by
  have he (i j : Fin 3) : (H i j)^2 ≤ δ^2 := sq_le_sq' (abs_le.mp (hentry i j)).1 (abs_le.mp (hentry i j)).2
  calc
    sourceEscapeFrobeniusSq H=∑ i,∑ j,(H i j)^2 := rfl
    _ ≤ ∑ _i : Fin 3,∑ _j : Fin 3,δ^2 := Finset.sum_le_sum (fun i _ => Finset.sum_le_sum (fun j _ => he i j))
    _=9*δ^2 := by norm_num;ring

theorem source_escape_trace_nonnegative_of_diagonal (H : Matrix (Fin 3) (Fin 3) ℝ)
    (hdiag : ∀ i,0 ≤ H i i) : 0 ≤ Matrix.trace H := Finset.sum_nonneg (fun i _ => hdiag i)

end CoefficientStability
