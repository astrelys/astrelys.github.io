import CoefficientStability.SourceConeTube

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n N : ℕ}

theorem source_closedCone_zero (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) :
    (0 : Fin n → ℝ)∈closure (positiveSpectralCone p N) :=
  nonnegative_input_mem_spectral_closure p N hp hs hnorm 0 (fun i => le_rfl)

theorem source_closedCone_nonneg_smul (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (x : Fin n → ℝ) (hx : x∈closure (positiveSpectralCone p N)) (c : ℝ) (hc : 0≤c) :
    c • x∈closure (positiveSpectralCone p N) := by
  by_cases hz : c=0
  · subst c
    simpa only [zero_smul] using source_closedCone_zero p hp hs hnorm
  · exact source_spectralCone_closure_positive_smul p hp hs hnorm x hx c
      (lt_of_le_of_ne hc (Ne.symm hz))

theorem source_closedCone_add (p : MvPolynomial (Fin n) ℝ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (x y : Fin n → ℝ) (hx : x∈closure (positiveSpectralCone p N))
    (hy : y∈closure (positiveSpectralCone p N)) : x+y∈closure (positiveSpectralCone p N) := by
  have hm := source_spectralCone_closure_convex p hN hp hs hnorm hx hy
    (a := (1/2 : ℝ)) (b := (1/2 : ℝ)) (by norm_num) (by norm_num) (by norm_num)
  have h := source_spectralCone_closure_positive_smul p hp hs hnorm _ hm 2 (by norm_num)
  have heq : (2 : ℝ) • ((1/2 : ℝ) • x+(1/2 : ℝ) • y)=x+y := by
    funext i
    change 2*((1/2)*x i+(1/2)*y i)=x i+y i
    ring
  rwa [heq] at h

theorem source_closedCone_finset_sum {ι : Type*} (p : MvPolynomial (Fin n) ℝ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (s : Finset ι) (v : ι → Fin n → ℝ)
    (hv : ∀ i∈s,v i∈closure (positiveSpectralCone p N)) :
    (∑ i∈s,v i)∈closure (positiveSpectralCone p N) := by
  classical
  induction s using Finset.induction_on with
  | empty => simpa using source_closedCone_zero p hp hs hnorm
  | @insert i s hi ih =>
    rw [Finset.sum_insert hi]
    exact source_closedCone_add p hN hp hs hnorm _ _ (hv i (Finset.mem_insert_self i s))
      (ih (fun j hj => hv j (Finset.mem_insert_of_mem hj)))

end CoefficientStability
