import CoefficientStability.SourceCubicCommutingPermanent
import CoefficientStability.SourceSharpEuclideanClassification
import CoefficientStability.SourceOriginalL1Theorem

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 3000000
set_option backward.isDefEq.respectTransparency false

theorem source_cubic_actual_permanent_lower_transfer (t : Fin 3 → ℝ)
    (ht : (∑ i,t i)=3) (hp : ∀ i,0 < t i) (L : ℝ)
    (hP : ∀ B ∈ sourceTransportationPolytope t,L ≤ Matrix.permanent B)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : A ∈ hermitianFeasibleTuples t) :
    L ≤ hermitianMixedObjective A := by
  obtain ⟨X,B,hX,hB,hmX,hmB,hval⟩ := source_cubic_matrix_permanent_minimizers t ht hp
  have h := hP B hB
  rw [← hval] at h
  exact h.trans (hmX hA)

theorem source_cubic_matrix_euclidean_ball_inequality (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,(t i-1)^2) ≤ 3/8) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) : sourceTernaryBaseline t ≤ hermitianMixedObjective A := by
  have hp : ∀ i,0 < t i := fun i => lt_of_lt_of_le (by norm_num) (source_ternary_euclidean_trace_box t ht hr i).1
  exact source_cubic_actual_permanent_lower_transfer t ht hp _ (source_sharp_euclidean_permanent_inequality t ht hr) A hA

theorem source_cubic_matrix_l1_ball_inequality (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,|t i-1|) ≤ sourceCubicEpsilon0) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) : sourceTernaryBaseline t ≤ hermitianMixedObjective A := by
  have hp : ∀ i,0 < t i := fun i => lt_trans (by norm_num) (source_ternary_l1_strict_trace_box t ht hr i).1
  exact source_cubic_actual_permanent_lower_transfer t ht hp _ (source_sharp_l1_permanent_inequality t ht hr) A hA

theorem source_cubic_equality_permanent_recovery (t : Fin 3 → ℝ)
    (ht : (∑ i,t i)=3) (hp : ∀ i,0 < t i) (L : ℝ)
    (hb : ∀ X ∈ hermitianFeasibleTuples t,L ≤ hermitianMixedObjective X)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : A ∈ hermitianFeasibleTuples t)
    (he : hermitianMixedObjective A=L) :
    ∃ (U : Matrix.unitaryGroup (Fin 3) ℂ) (B : Matrix (Fin 3) (Fin 3) ℝ),
      B ∈ sourceTransportationPolytope t ∧ sourceCubicUnitaryAction U A=sourcePermanentDiagonalTuple B ∧
      Matrix.permanent B=L := by
  have hm : IsMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A := by
    intro X hX
    change hermitianMixedObjective A ≤ hermitianMixedObjective X
    rw [he]
    exact hb X hX
  have hc := source_original_cubic_local_minimum_pairwise_commutation t ht hp A hA hm.isLocalMinOn
  obtain ⟨U,B,hB,htu,hval⟩ := source_cubic_commuting_permanent_recovery t A hA hc
  exact ⟨U,B,hB,htu,hval.symm.trans he⟩

theorem source_cubic_unitary_permanent_objective (t : Fin 3 → ℝ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : A ∈ hermitianFeasibleTuples t)
    (U : Matrix.unitaryGroup (Fin 3) ℂ) (B : Matrix (Fin 3) (Fin 3) ℝ)
    (he : sourceCubicUnitaryAction U A=sourcePermanentDiagonalTuple B) :
    hermitianMixedObjective A=Matrix.permanent B := by
  have h := congrArg Complex.re (source_cubic_unitary_mixed_invariant U A hA.2)
  change hermitianMixedObjective (sourceCubicUnitaryAction U A)=hermitianMixedObjective A at h
  rw [he,source_permanent_diagonal_objective] at h
  exact h.symm

@[simp] theorem source_cubic_unitary_reference (t : Fin 3 → ℝ) (U : Matrix.unitaryGroup (Fin 3) ℂ) :
    sourceCubicUnitaryAction U (complexReferenceTuple t)=complexReferenceTuple t := by
  funext i
  simp [source_cubic_unitary_action_apply,complexReferenceTuple_source,Unitary.conjStarAlgAut_apply,mul_smul_comm,smul_mul_assoc]

theorem source_cubic_unitary_scalar_recovery (t : Fin 3 → ℝ) (U : Matrix.unitaryGroup (Fin 3) ℂ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (he : sourceCubicUnitaryAction U A=complexReferenceTuple t) : A=complexReferenceTuple t := by
  have h := congrArg (sourceCubicUnitaryAction (star U)) he
  simpa only [source_cubic_unitary_action_inverse,source_cubic_unitary_reference] using h

theorem source_cubic_reference_objective (t : Fin 3 → ℝ) :
    hermitianMixedObjective (complexReferenceTuple t)=sourceTernaryBaseline t := by
  rw [← source_permanent_diagonal_reference,source_permanent_diagonal_objective,source_ternary_reference_permanent]

end CoefficientStability
