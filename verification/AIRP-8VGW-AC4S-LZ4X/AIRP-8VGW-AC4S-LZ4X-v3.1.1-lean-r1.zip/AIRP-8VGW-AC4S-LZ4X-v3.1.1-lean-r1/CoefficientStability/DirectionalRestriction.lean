import CoefficientStability.BalancedRigidityConditionalClosure

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def affineDirectionalRestriction (p : MvPolynomial (Fin n) ℝ) (x v : Fin n → ℝ) : Polynomial ℝ :=
  MvPolynomial.eval₂ Polynomial.C (fun i => Polynomial.C (v i)*Polynomial.X+Polynomial.C (x i)) p

theorem affineDirectionalRestriction_eval (p : MvPolynomial (Fin n) ℝ)
    (x v : Fin n → ℝ) (t : ℝ) :
    (affineDirectionalRestriction p x v).eval t=MvPolynomial.eval (fun i => x i+t*v i) p := by
  change (Polynomial.evalRingHom t)
    (MvPolynomial.eval₂ Polynomial.C (fun i => Polynomial.C (v i)*Polynomial.X+Polynomial.C (x i)) p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c;simp
  · funext i;simp;ring

theorem affineDirectionalRestriction_complex_eval (p : MvPolynomial (Fin n) ℝ)
    (x v : Fin n → ℝ) (t : ℂ) :
    Polynomial.eval₂ Complex.ofRealHom t (affineDirectionalRestriction p x v)=
      MvPolynomial.eval₂ Complex.ofRealHom (fun i => (x i : ℂ)+t*(v i : ℂ)) p := by
  change (Polynomial.eval₂RingHom Complex.ofRealHom t)
    (MvPolynomial.eval₂ Polynomial.C (fun i => Polynomial.C (v i)*Polynomial.X+Polynomial.C (x i)) p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c;simp
  · funext i;simp;ring

theorem stable_positive_direction_upper_zero_free (p : MvPolynomial (Fin n) ℝ)
    (hs : UpperHalfPlaneZeroFree p) (x v : Fin n → ℝ) (hv : ∀ i,0<v i) :
    realUnivariateUpperZeroFree (affineDirectionalRestriction p x v) := by
  intro t ht
  rw [affineDirectionalRestriction_complex_eval]
  apply hs
  intro i
  simpa using mul_pos ht (hv i)

theorem stable_positive_direction_splits (p : MvPolynomial (Fin n) ℝ)
    (hs : UpperHalfPlaneZeroFree p) (x v : Fin n → ℝ) (hv : ∀ i,0<v i) :
    (affineDirectionalRestriction p x v).Splits :=
  real_upper_zero_free_splits _ (stable_positive_direction_upper_zero_free p hs x v hv)

end CoefficientStability
