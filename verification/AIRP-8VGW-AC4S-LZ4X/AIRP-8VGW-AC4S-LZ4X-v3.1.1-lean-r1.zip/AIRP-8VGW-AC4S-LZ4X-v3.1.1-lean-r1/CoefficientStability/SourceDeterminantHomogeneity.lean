import CoefficientStability.SourceDeterminantStability

noncomputable section
open scoped BigOperators ComplexOrder
namespace CoefficientStability
variable {n : ℕ}

theorem source_determinantPencil_entry_homogeneous (A : Fin n → ComplexSquare n) (r c : Fin n) :
    (determinantPencil A r c).IsHomogeneous 1 := by
  classical
  simp only [determinantPencil,Matrix.sum_apply,Matrix.smul_apply,Matrix.map_apply,smul_eq_mul]
  apply MvPolynomial.IsHomogeneous.sum
  intro i hi
  rw [mul_comm]
  exact MvPolynomial.isHomogeneous_C_mul_X _ _

theorem source_determinantPolynomial_homogeneous (A : Fin n → ComplexSquare n) :
    (determinantPolynomial A).IsHomogeneous n := by
  classical
  rw [determinantPolynomial,Matrix.det_apply]
  apply MvPolynomial.IsHomogeneous.sum
  intro σ hσ
  have hp : (∏ i,determinantPencil A (σ i) i).IsHomogeneous n := by
    simpa only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,smul_eq_mul,mul_one] using
      MvPolynomial.IsHomogeneous.prod Finset.univ (fun i => determinantPencil A (σ i) i) (fun _ => 1)
        (fun i hi => source_determinantPencil_entry_homogeneous A (σ i) i)
  rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with hs | hs
  · simpa only [hs,one_smul] using hp
  · simpa [hs,Units.smul_def] using hp.neg

theorem source_realDeterminant_homogeneous (A : Fin n → ComplexSquare n)
    (hHerm : ∀ i,(A i).IsHermitian) : (realDeterminantPolynomial A).IsHomogeneous n := by
  apply MvPolynomial.IsHomogeneous.of_map (f := Complex.ofRealHom) Complex.ofReal_injective
  rw [realDeterminantPolynomial_complexification A hHerm]
  exact source_determinantPolynomial_homogeneous A

theorem source_realDeterminant_normalized (A : Fin n → ComplexSquare n)
    (hHerm : ∀ i,(A i).IsHermitian) (hA : ∑ i,A i=1) :
    MvPolynomial.eval (fun _ => 1) (realDeterminantPolynomial A)=1 := by
  apply Complex.ofReal_injective
  rw [realDeterminantPolynomial_evaluation A hHerm]
  simp only [Complex.ofReal_one,one_smul,hA,Matrix.det_one]

theorem source_realDeterminant_source_hypotheses (A : Fin n → ComplexSquare n)
    (hPSD : ∀ i,(A i).PosSemidef) (hA : ∑ i,A i=1) :
    (realDeterminantPolynomial A).IsHomogeneous n ∧ UpperHalfPlaneZeroFree (realDeterminantPolynomial A) ∧
      MvPolynomial.eval (fun _ => 1) (realDeterminantPolynomial A)=1 ∧
      (∀ g,0 ≤ (realDeterminantPolynomial A).coeff g) ∧
      ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i (realDeterminantPolynomial A))=(Matrix.trace (A i)).re := by
  have hHerm := fun i => (hPSD i).isHermitian
  have hp := source_realDeterminant_homogeneous A hHerm
  have hs := source_realDeterminant_stable A hPSD hA
  have hn := source_realDeterminant_normalized A hHerm hA
  exact ⟨hp,hs,hn,normalized_homogeneous_stable_coeff_nonneg _ n hp hs hn,realDeterminant_gradient A hHerm hA⟩

end CoefficientStability
