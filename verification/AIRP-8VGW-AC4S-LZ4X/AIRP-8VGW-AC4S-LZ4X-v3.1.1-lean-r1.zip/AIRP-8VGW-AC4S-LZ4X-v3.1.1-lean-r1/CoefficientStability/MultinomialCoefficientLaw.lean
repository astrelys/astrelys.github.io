import CoefficientStability.CovarianceBridge
import Mathlib.Algebra.MvPolynomial.Coeff

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem scalarPower_multinomial_coefficient (t : Fin n → ℝ) (N : ℕ) (d : Fin n →₀ ℕ) :
    (scalarPower t N).coeff d=
      if d.sum (fun _ m => m)=N then
        (d.multinomial : ℝ)*d.prod (fun i m => (t i/(N : ℝ))^m) else 0 := by
  simpa only [scalarPower,scalarLinear,MvPolynomial.smul_eq_C_mul] using
    MvPolynomial.coeff_linearCombination_X_pow_of_fintype (fun i => t i/(N : ℝ)) d N

theorem scalarPower_coefficient_nonnegative (t : Fin n → ℝ) (N : ℕ)
    (ht : ∀ i,0≤t i) (d : Fin n →₀ ℕ) : 0≤(scalarPower t N).coeff d := by
  rw [scalarPower_multinomial_coefficient]
  split_ifs
  · apply mul_nonneg (Nat.cast_nonneg _)
    exact Finset.prod_nonneg (fun i _ => pow_nonneg (div_nonneg (ht i) (Nat.cast_nonneg _)) _)
  · exact le_rfl

theorem multinomial_coefficient_probability (t : Fin n → ℝ) (N : ℕ) (hN : 0<N)
    (ht : ∑ i,t i=N) (htnonneg : ∀ i,0≤t i) :
    (∀ d,0≤(scalarPower t N).coeff d) ∧
    (∑ d∈(scalarPower t N).support,(scalarPower t N).coeff d)=1 ∧
    ∀ i,(∑ d∈(scalarPower t N).support,(scalarPower t N).coeff d*(d i : ℝ))=t i := by
  refine ⟨scalarPower_coefficient_nonnegative t N htnonneg,
    normalized_coefficient_mass _ (eval_one_scalarPower t N hN ht),?_⟩
  intro i
  rw [actual_coefficient_first_moment,scalarPower_gradient t N hN ht]

theorem paper_defect_hessian_identity (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (N : ℕ) (hN : 2≤N) (ht : ∑ i,t i=N) (i j : Fin n) :
    2*deficitMatrix p t N i j=
      -MvPolynomial.eval (fun _ => 1) (pderiv i (pderiv j (p-scalarPower t N))) := by
  simp only [map_sub,scalarPower_mixed_hessian t N hN ht]
  unfold deficitMatrix
  ring

end CoefficientStability
