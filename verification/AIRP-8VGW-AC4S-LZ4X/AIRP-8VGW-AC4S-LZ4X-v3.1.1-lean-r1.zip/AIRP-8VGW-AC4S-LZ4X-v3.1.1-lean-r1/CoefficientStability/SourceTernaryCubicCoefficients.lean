import CoefficientStability.SourceBinarySexticNorm

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceTernaryExponent (a b c : ℕ) : Fin 3 →₀ ℕ :=
  Finsupp.single 0 a+Finsupp.single 1 b+Finsupp.single 2 c

def sourceTernaryCubicExponent : Fin 10 → (Fin 3 →₀ ℕ) :=
  ![sourceTernaryExponent 3 0 0,sourceTernaryExponent 2 1 0,sourceTernaryExponent 2 0 1,
    sourceTernaryExponent 1 2 0,sourceTernaryExponent 1 1 1,sourceTernaryExponent 1 0 2,
    sourceTernaryExponent 0 3 0,sourceTernaryExponent 0 2 1,sourceTernaryExponent 0 1 2,
    sourceTernaryExponent 0 0 3]

theorem source_ternary_exponent_coordinates (a b c : ℕ) :
    sourceTernaryExponent a b c 0=a ∧ sourceTernaryExponent a b c 1=b ∧
      sourceTernaryExponent a b c 2=c := by
  simp [sourceTernaryExponent]

theorem source_ternary_cubic_exponent_injective : Function.Injective sourceTernaryCubicExponent := by
  intro i j hij
  have h0 := congrArg (fun g : Fin 3 →₀ ℕ => g 0) hij
  have h1 := congrArg (fun g : Fin 3 →₀ ℕ => g 1) hij
  have h2 := congrArg (fun g : Fin 3 →₀ ℕ => g 2) hij
  fin_cases i <;> fin_cases j
  all_goals solve
    | rfl
    | norm_num [sourceTernaryCubicExponent,sourceTernaryExponent,Finsupp.single_apply] at h0
    | norm_num [sourceTernaryCubicExponent,sourceTernaryExponent,Finsupp.single_apply] at h1
    | norm_num [sourceTernaryCubicExponent,sourceTernaryExponent,Finsupp.single_apply] at h2

theorem source_ternary_cubic_exponent_degree (i : Fin 10) :
    (sourceTernaryCubicExponent i).degree=3 := by
  fin_cases i <;> norm_num [sourceTernaryCubicExponent,sourceTernaryExponent]

theorem source_ternary_cubic_exponent_exhaustive (g : Fin 3 →₀ ℕ) (hg : g.degree=3) :
    ∃ i : Fin 10,g=sourceTernaryCubicExponent i := by
  have hm : g 0+g 1+g 2=3 := by
    rw [Finsupp.degree_eq_sum] at hg
    norm_num [Fin.sum_univ_succ] at hg
    omega
  have hvec : g=sourceTernaryExponent (g 0) (g 1) (g 2) := by
    apply Finsupp.ext
    intro i
    fin_cases i <;> simp [sourceTernaryExponent]
  have he : (g 0=3 ∧ g 1=0 ∧ g 2=0) ∨ (g 0=2 ∧ g 1=1 ∧ g 2=0) ∨
      (g 0=2 ∧ g 1=0 ∧ g 2=1) ∨ (g 0=1 ∧ g 1=2 ∧ g 2=0) ∨
      (g 0=1 ∧ g 1=1 ∧ g 2=1) ∨ (g 0=1 ∧ g 1=0 ∧ g 2=2) ∨
      (g 0=0 ∧ g 1=3 ∧ g 2=0) ∨ (g 0=0 ∧ g 1=2 ∧ g 2=1) ∨
      (g 0=0 ∧ g 1=1 ∧ g 2=2) ∨ (g 0=0 ∧ g 1=0 ∧ g 2=3) := by omega
  rcases he with h|h|h|h|h|h|h|h|h|h
  · exact ⟨0,by simpa [sourceTernaryCubicExponent,h.1,h.2.1,h.2.2] using hvec⟩
  · exact ⟨1,by simpa [sourceTernaryCubicExponent,h.1,h.2.1,h.2.2] using hvec⟩
  · exact ⟨2,by simpa [sourceTernaryCubicExponent,h.1,h.2.1,h.2.2] using hvec⟩
  · exact ⟨3,by simpa [sourceTernaryCubicExponent,h.1,h.2.1,h.2.2] using hvec⟩
  · exact ⟨4,by simpa [sourceTernaryCubicExponent,h.1,h.2.1,h.2.2] using hvec⟩
  · exact ⟨5,by simpa [sourceTernaryCubicExponent,h.1,h.2.1,h.2.2] using hvec⟩
  · exact ⟨6,by simpa [sourceTernaryCubicExponent,h.1,h.2.1,h.2.2] using hvec⟩
  · exact ⟨7,by simpa [sourceTernaryCubicExponent,h.1,h.2.1,h.2.2] using hvec⟩
  · exact ⟨8,by simpa [sourceTernaryCubicExponent,h.1,h.2.1,h.2.2] using hvec⟩
  · exact ⟨9,by simpa [sourceTernaryCubicExponent,h.1,h.2.1,h.2.2] using hvec⟩

theorem source_ternary_cubic_coefficient_expansion (p : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3) :
    p=∑ i : Fin 10,MvPolynomial.monomial (sourceTernaryCubicExponent i) (p.coeff (sourceTernaryCubicExponent i)) := by
  classical
  apply MvPolynomial.ext
  intro g
  simp only [MvPolynomial.coeff_sum,MvPolynomial.coeff_monomial]
  by_cases hg : g.degree=3
  · obtain ⟨i,rfl⟩ := source_ternary_cubic_exponent_exhaustive g hg
    simp [source_ternary_cubic_exponent_injective.eq_iff]
  · rw [hp.coeff_eq_zero hg]
    symm
    apply Finset.sum_eq_zero
    intro i hi
    have he : sourceTernaryCubicExponent i≠g := by
      intro h
      apply hg
      rw [← h]
      exact source_ternary_cubic_exponent_degree i
    simp [he]

end CoefficientStability
