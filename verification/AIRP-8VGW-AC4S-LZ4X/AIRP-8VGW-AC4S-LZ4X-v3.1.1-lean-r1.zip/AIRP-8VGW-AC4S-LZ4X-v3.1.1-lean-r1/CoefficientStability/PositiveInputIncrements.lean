import CoefficientStability.FiniteTuplePrefixBridge

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def naturalInputIncrement (x : ℕ → ℝ) (i : ℕ) : ℝ :=
  if i=0 then x i else x i-x (i-1)

def tupleInputIncrement (x : Fin n → ℝ) (j : Fin n) : ℝ :=
  if j.val=0 then x j else x j-x ⟨j.val-1,lt_of_le_of_lt (Nat.sub_le _ _) j.isLt⟩

theorem naturalInputIncrement_telescope (x : ℕ → ℝ) (k : ℕ) :
    (∑ i∈Finset.range (k+1),naturalInputIncrement x i)=x k := by
  induction k with
  | zero => simp [naturalInputIncrement]
  | succ k ih =>
    rw [Finset.sum_range_succ,ih]
    simp [naturalInputIncrement]

theorem tupleInputIncrement_nat_extension (x : Fin n → ℝ) (i : ℕ) (hi : i < n) :
    tupleNatExtension (tupleInputIncrement x) i=naturalInputIncrement (tupleNatExtension x) i := by
  by_cases hi0 : i=0
  · subst i
    simp [tupleNatExtension,tupleInputIncrement,naturalInputIncrement,hi]
  · have hpred : i-1 < n := lt_of_le_of_lt (Nat.sub_le _ _) hi
    simp [tupleNatExtension,tupleInputIncrement,naturalInputIncrement,hi0,hi,hpred]

theorem cumulativeInput_tupleInputIncrement (x : Fin n → ℝ) :
    cumulativeInput (tupleInputIncrement x)=x := by
  classical
  funext i
  have heq : cumulativeInput (tupleInputIncrement x) i=
      finiteInputPrefix (tupleInputIncrement x) (i.val+1) := by
    simp only [cumulativeInput,finiteInputPrefix,Fin.le_def,Nat.lt_succ_iff]
  rw [heq,finiteInputPrefix_eq_range _ _ (by omega)]
  have hterms : (∑ j∈Finset.range (i.val+1),tupleNatExtension (tupleInputIncrement x) j)=
      ∑ j∈Finset.range (i.val+1),naturalInputIncrement (tupleNatExtension x) j := by
    apply Finset.sum_congr rfl
    intro j hj
    exact tupleInputIncrement_nat_extension x j (by have h := Finset.mem_range.mp hj;omega)
  rw [hterms,naturalInputIncrement_telescope]
  simp [tupleNatExtension,i.isLt]

theorem tupleInputIncrement_nonneg (x : Fin n → ℝ) (hx : ∀ i,0<x i) (hm : Monotone x) :
    ∀ j,0≤tupleInputIncrement x j := by
  intro j
  by_cases hj0 : j.val=0
  · simpa only [tupleInputIncrement,if_pos hj0] using (hx j).le
  · simp only [tupleInputIncrement,if_neg hj0]
    exact sub_nonneg.mpr (hm (show (⟨j.val-1,lt_of_le_of_lt (Nat.sub_le _ _) j.isLt⟩ : Fin n) ≤ j from Nat.sub_le _ _))

theorem tupleInputIncrement_initial_pos (hn : 0<n) (x : Fin n → ℝ) (hx : ∀ i,0<x i) :
    0<tupleInputIncrement x ⟨0,hn⟩ := by
  simpa [tupleInputIncrement] using hx ⟨0,hn⟩

end CoefficientStability
