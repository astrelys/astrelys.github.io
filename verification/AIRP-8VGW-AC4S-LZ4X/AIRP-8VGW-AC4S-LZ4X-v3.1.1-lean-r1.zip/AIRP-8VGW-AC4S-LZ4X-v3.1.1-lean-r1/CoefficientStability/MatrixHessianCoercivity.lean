import CoefficientStability.NegativeCurvatureDescent

noncomputable section
open scoped BigOperators ComplexOrder
namespace CoefficientStability
variable {n : ℕ}

def complexFrobeniusSq (A : Matrix (Fin n) (Fin n) ℂ) : ℝ :=
  ∑ r,∑ c,((A r c).re^2+(A r c).im^2)

def complexTupleSq (A : Fin n → Matrix (Fin n) (Fin n) ℂ) : ℝ :=
  ∑ i,complexFrobeniusSq (A i)

def matrixHessianBracket (t : Fin n → ℝ) (A : Fin n → Matrix (Fin n) (Fin n) ℂ) : ℝ :=
  (∑ i,complexFrobeniusSq (Complex.ofReal ((t i)⁻¹) • A i))-
    complexFrobeniusSq (∑ i,Complex.ofReal ((t i)⁻¹) • A i)

theorem complexFrobeniusSq_nonneg (A : Matrix (Fin n) (Fin n) ℂ) :
    0≤complexFrobeniusSq A := by
  unfold complexFrobeniusSq
  apply Finset.sum_nonneg
  intro r hr
  exact Finset.sum_nonneg (fun c hc => add_nonneg (sq_nonneg _) (sq_nonneg _))

theorem complexFrobeniusSq_real_smul (a : ℝ) (A : Matrix (Fin n) (Fin n) ℂ) :
    complexFrobeniusSq ((a : ℂ) • A)=a^2*complexFrobeniusSq A := by
  unfold complexFrobeniusSq
  simp only [Matrix.smul_apply,smul_eq_mul,Complex.mul_re,Complex.ofReal_re,
    Complex.ofReal_im,zero_mul,sub_zero,Complex.mul_im,zero_add]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro r hr
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro c hc
  ring

theorem weightedFrobenius_coordinates (t : Fin n → ℝ)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    (∑ i,complexFrobeniusSq (Complex.ofReal ((t i)⁻¹) • A i)) =
      ∑ r,∑ c,∑ i,(((A i r c).re/t i)^2+((A i r c).im/t i)^2) := by
  unfold complexFrobeniusSq
  simp only [Matrix.smul_apply,smul_eq_mul,Complex.mul_re,Complex.ofReal_re,
    Complex.ofReal_im,zero_mul,sub_zero,Complex.mul_im,add_zero,div_eq_mul_inv]
  simp only [mul_comm ((t _)⁻¹)]
  rw [Finset.sum_comm (s := Finset.univ) (t := Finset.univ)]
  apply Finset.sum_congr rfl
  intro r hr
  exact Finset.sum_comm

theorem matrixHessianBracket_coordinates (t : Fin n → ℝ)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    matrixHessianBracket t A = ∑ r,∑ c,
      (scalarHessianForm (fun i => (A i r c).re/t i)+
      scalarHessianForm (fun i => (A i r c).im/t i)) := by
  unfold matrixHessianBracket
  rw [weightedFrobenius_coordinates]
  unfold complexFrobeniusSq scalarHessianForm
  simp only [Matrix.smul_apply,smul_eq_mul,Complex.mul_re,Complex.ofReal_re,
    Complex.ofReal_im,zero_mul,sub_zero,Complex.mul_im,add_zero,
    Matrix.sum_apply,Complex.re_sum,Complex.im_sum,div_eq_mul_inv]
  simp only [mul_comm ((t _)⁻¹)]
  simp_rw [Finset.sum_add_distrib,Finset.sum_sub_distrib]
  ring

theorem matrixHessianBracket_lower (t : Fin n → ℝ)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ) (hn : 0<n)
    (ht : ∑ i,t i=n) (htne : ∀ i,t i≠0) (hA : ∑ i,A i=0) :
    scalarHessianLambda t*(∑ i,complexFrobeniusSq (Complex.ofReal ((t i)⁻¹) • A i)) ≤
      matrixHessianBracket t A := by
  have hreal (r c : Fin n) : ∑ i,t i*((A i r c).re/t i)=0 := by
    simp only [mul_div_cancel₀ _ (htne _)]
    have h := congrArg (fun B : Matrix (Fin n) (Fin n) ℂ => (B r c).re) hA
    simpa only [Matrix.sum_apply,Complex.re_sum,Complex.im_sum,Matrix.zero_apply,Complex.zero_re,Complex.zero_im] using h
  have himag (r c : Fin n) : ∑ i,t i*((A i r c).im/t i)=0 := by
    simp only [mul_div_cancel₀ _ (htne _)]
    have h := congrArg (fun B : Matrix (Fin n) (Fin n) ℂ => (B r c).im) hA
    simpa only [Matrix.sum_apply,Complex.re_sum,Complex.im_sum,Matrix.zero_apply,Complex.zero_re,Complex.zero_im] using h
  rw [matrixHessianBracket_coordinates]
  rw [weightedFrobenius_coordinates,Finset.mul_sum]
  apply Finset.sum_le_sum
  intro r hr
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro c hc
  have h1 := scalarHessianForm_lower t (fun i => (A i r c).re/t i) hn ht (hreal r c)
  have h2 := scalarHessianForm_lower t (fun i => (A i r c).im/t i) hn ht (himag r c)
  rw [Finset.sum_add_distrib,mul_add]
  exact add_le_add h1 h2

theorem complexTupleSq_pos (A : Fin n → Matrix (Fin n) (Fin n) ℂ) (hA : A≠0) :
    0<complexTupleSq A := by
  have hex : ∃ i r c,A i r c≠0 := by
    by_contra! h
    apply hA
    funext i
    apply Matrix.ext
    intro r c
    exact h i r c
  obtain ⟨i,r,c,hc⟩ := hex
  have hp : 0<(A i r c).re^2+(A i r c).im^2 := by
    have hr := sq_nonneg (A i r c).re
    have hi := sq_nonneg (A i r c).im
    by_contra! h
    have hz : A i r c=0 := by
      apply Complex.ext <;> simp only [Complex.zero_re,Complex.zero_im] <;> nlinarith
    exact hc hz
  have hc' := Finset.single_le_sum
    (fun j (_ : j∈(Finset.univ : Finset (Fin n))) =>
      add_nonneg (sq_nonneg (A i r j).re) (sq_nonneg (A i r j).im)) (Finset.mem_univ c)
  have hr := Finset.single_le_sum (f := fun j => ∑ k : Fin n, ((A i j k).re^2+(A i j k).im^2))
    (fun j (_ : j∈(Finset.univ : Finset (Fin n))) =>
      Finset.sum_nonneg (fun k hk => add_nonneg (sq_nonneg (A i j k).re) (sq_nonneg (A i j k).im))) (Finset.mem_univ r)
  have hi := Finset.single_le_sum
    (fun j (_ : j∈(Finset.univ : Finset (Fin n))) => complexFrobeniusSq_nonneg (A j)) (Finset.mem_univ i)
  unfold complexTupleSq
  unfold complexFrobeniusSq at hi
  exact lt_of_lt_of_le (lt_of_lt_of_le (lt_of_lt_of_le hp hc') hr) hi

theorem weightedFrobenius_lower (t : Fin n → ℝ)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ) (M : ℝ)
    (htpos : ∀ i,0<t i) (hM : ∀ i,t i≤M) :
    (M^2)⁻¹*complexTupleSq A ≤
      ∑ i,complexFrobeniusSq (Complex.ofReal ((t i)⁻¹) • A i) := by
  unfold complexTupleSq
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i hi
  rw [complexFrobeniusSq_real_smul]
  have hi2 : (t i)^2≤M^2 := by nlinarith [hM i,htpos i]
  have h := inv_anti₀ (sq_pos_of_pos (htpos i)) hi2
  have h' := mul_le_mul_of_nonneg_right h (complexFrobeniusSq_nonneg (A i))
  simpa only [inv_pow] using h'

theorem matrixHessianBracket_coercive (t : Fin n → ℝ)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ) (M : ℝ) (hn : 0<n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hM : ∀ i,t i≤M)
    (hA : ∑ i,A i=0) (hl : 0<scalarHessianLambda t) :
    (scalarHessianLambda t/M^2)*complexTupleSq A ≤matrixHessianBracket t A := by
  have h1 := weightedFrobenius_lower t A M htpos hM
  have h2 := matrixHessianBracket_lower t A hn ht (fun i => ne_of_gt (htpos i)) hA
  have h3 := mul_le_mul_of_nonneg_left h1 hl.le
  exact le_trans (by simpa only [div_eq_mul_inv,mul_assoc] using h3) h2

def sourceHessianFactor (t : Fin n → ℝ) : ℝ :=
  ((n-2).factorial : ℝ)/(n : ℝ)^(n-2)*∏ i,t i

def sourceHessianCandidate (t : Fin n → ℝ) (A : Fin n → Matrix (Fin n) (Fin n) ℂ) : ℝ :=
  sourceHessianFactor t*matrixHessianBracket t A

theorem sourceHessianFactor_pos (t : Fin n → ℝ) (hn : 2≤n) (htpos : ∀ i,0<t i) :
    0<sourceHessianFactor t := by
  apply mul_pos
  · exact div_pos (by exact_mod_cast Nat.factorial_pos (n-2))
      (pow_pos (by exact_mod_cast (by omega : 0<n)) _)
  · exact Finset.prod_pos (fun i hi => htpos i)

theorem sourceHessianCandidate_coercive (t : Fin n → ℝ)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ) (M : ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hM : ∀ i,t i≤M)
    (hA : ∑ i,A i=0) (hl : 0<scalarHessianLambda t) :
    (sourceHessianFactor t*scalarHessianLambda t/M^2)*complexTupleSq A ≤sourceHessianCandidate t A := by
  have h := mul_le_mul_of_nonneg_left (matrixHessianBracket_coercive t A M (by omega) ht htpos hM hA hl)
    (sourceHessianFactor_pos t hn htpos).le
  simpa only [sourceHessianCandidate,div_eq_mul_inv,mul_assoc] using h

end CoefficientStability
