import CoefficientStability.CompactCapacitySublevel
import CoefficientStability.PositiveSimplexNormalization

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem positive_pure_capacity_ratio_attained (hn : 0<n) (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (hc : ∀ g,0≤p.coeff g)
    (hpure : ∀ i,0<p.coeff (Finsupp.single i n)) :
    ∃ x : Fin n → ℝ,(∀ i,0<x i) ∧ (∑ i,x i=(n : ℝ)) ∧
      ∀ y : Fin n → ℝ,(∀ i,0<y i) →
        MvPolynomial.eval x p/(∏ i,x i)≤MvPolynomial.eval y p/(∏ i,y i) := by
  obtain ⟨c,hcpos,hcpure⟩ := exists_positive_pure_lower hn p hpure
  let M : ℝ := MvPolynomial.eval (fun _ => 1) p
  have hones : (∑ _ : Fin n,(1 : ℝ))=(n : ℝ) := by simp
  have hM : 0<M := lt_of_lt_of_le hcpos
    (simplex_pure_eval_lower hn p hc c hcpos hcpure (fun _ => 1) (fun _ => by norm_num) hones)
  let a : ℝ := (c/M)/(n : ℝ)^(n-1)
  have hnr : (0 : ℝ)<n := by exact_mod_cast hn
  have ha : 0<a := div_pos (div_pos hcpos hM) (pow_pos hnr _)
  have h1 : (fun _ : Fin n => (1 : ℝ))∈compactCapacitySublevel p a M := by
    apply positive_simplex_sublevel_mem_compact hn p hc c M hcpos hM hcpure
      (fun _ => 1) (fun _ => by norm_num) hones
    simp only [Finset.prod_const_one,div_one]
    exact le_refl _
  obtain ⟨x,hx,hmin⟩ := (compactCapacitySublevel_isCompact p a M).exists_isMinOn
    ⟨_,h1⟩ (compactCapacitySublevel_ratio_continuous p a M ha)
  refine ⟨x,compactCapacitySublevel_positive p a M ha hx,hx.1.2,?_⟩
  intro y hy
  obtain ⟨z,hz,hsz,hratio⟩ := exists_positive_simplex_normalization hn p hp y hy
  by_cases hsub : MvPolynomial.eval z p/(∏ i,z i)≤M
  · have hzmem := positive_simplex_sublevel_mem_compact hn p hc c M hcpos hM hcpure z hz hsz hsub
    have hh := hmin hzmem
    change MvPolynomial.eval x p/(∏ i,x i)≤MvPolynomial.eval z p/(∏ i,z i) at hh
    rw [hratio] at hh
    exact hh
  · have hxM := compactCapacitySublevel_ratio_le p a M ha hx
    rw [hratio] at hsub
    exact hxM.trans (le_of_lt (lt_of_not_ge hsub))

theorem positive_pure_capacity_attained (hn : 0<n) (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (hc : ∀ g,0≤p.coeff g)
    (hpure : ∀ i,0<p.coeff (Finsupp.single i n)) :
    ∃ x : Fin n → ℝ,(∀ i,0<x i) ∧ (∑ i,x i=(n : ℝ)) ∧
      multivariatePositiveCapacity p=MvPolynomial.eval x p/(∏ i,x i) := by
  obtain ⟨x,hx,hs,hmin⟩ := positive_pure_capacity_ratio_attained hn p hp hc hpure
  refine ⟨x,hx,hs,le_antisymm ?_ ?_⟩
  · exact csInf_le (multivariate_capacity_bddBelow p hc) ⟨⟨x,hx⟩,rfl⟩
  · apply le_csInf
    · exact ⟨_,⟨⟨x,hx⟩,rfl⟩⟩
    · rintro r ⟨y,rfl⟩
      exact hmin y.val y.prop

end CoefficientStability
