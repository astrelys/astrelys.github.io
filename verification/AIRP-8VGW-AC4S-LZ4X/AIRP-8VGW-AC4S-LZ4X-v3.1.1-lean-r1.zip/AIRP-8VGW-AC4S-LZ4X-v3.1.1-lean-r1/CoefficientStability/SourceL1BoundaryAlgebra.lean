import CoefficientStability.SourceL1BoundaryFamily

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1600000

theorem source_l1_boundary_family_gap (d : ℝ) (hd : 0 ≤ d) :
    Matrix.permanent (sourceL1BoundaryMatrix d)-sourceTernaryBaseline (sourceL1BoundaryTraces d)=
      (1-d)*(1+2*d)*(1-10*d-12*d^2)/36 := by
  let s := sourceL1BoundaryS d
  let a := (1+s+d)/2
  let b := (1-s+d)/2
  have hsq : s^2=d+3*d^2 := Real.sq_sqrt (by positivity)
  have hrel : 4*a*b=(1-d)*(2*(a+b)-1) := by dsimp [a,b];nlinarith [hsq]
  have hab : a*b=(1-d)*(1+2*d)/4 := by dsimp [a,b];nlinarith [hsq]
  have ht : sourceL1BoundaryTraces d=sourceTernaryStationaryTraces a b d := by
    funext i
    fin_cases i <;> norm_num [sourceL1BoundaryTraces,sourceTernaryStationaryTraces,a,b] <;> nlinarith [hsq]
  have hm : sourceTernarySeparatedZeros (sourceL1BoundaryTraces d) a b=sourceL1BoundaryMatrix d := by
    ext i j
    fin_cases i <;> fin_cases j <;>
      norm_num [sourceTernarySeparatedZeros,sourceTernaryOneZero,sourceL1BoundaryTraces,sourceL1BoundaryMatrix,a,b] <;>
      dsimp [s] at * <;> ring
  have hz : d+(2-2*(a+b))/2=0 := by dsimp [a,b];ring
  have hg := source_ternary_stationary_chart_gap a b d hrel
  rw [← ht,hm,source_euclidean_H_equals_l1_H,hz,hab] at hg
  rw [hg]
  unfold sourceCubicH
  ring

theorem source_l1_boundary_trace_sum (d : ℝ) : (∑ i,sourceL1BoundaryTraces d i)=3 := by
  norm_num [sourceL1BoundaryTraces,Fin.sum_univ_succ]
  ring

theorem source_l1_boundary_distance (d : ℝ) (hd : 0 ≤ d) (hd3 : d < 3/2) :
    (∑ i,|sourceL1BoundaryTraces d i-1|)=(3-2*d)*sourceL1BoundaryS d := by
  let m := (3-2*d)*sourceL1BoundaryS d/2
  have hK : 0 ≤ 3-2*d := by linarith
  have hm : 0 ≤ m := by dsimp [m,sourceL1BoundaryS];positivity
  change (∑ i,|(![1+m,1-m,1] : Fin 3 → ℝ) i-1|)=_
  norm_num [Fin.sum_univ_succ]
  rw [abs_of_nonneg hm]
  dsimp [m]
  ring

theorem source_l1_dstar_eighth_bound : sourceCubicDStar < 1/8 := by
  have h := source_sqrt37_exact_bounds.2.2
  unfold sourceCubicDStar
  linarith

theorem source_l1_boundary_dstar_feasible_equal :
    sourceL1BoundaryMatrix sourceCubicDStar ∈ sourceTransportationPolytope sourceL1ExceptionalTraces ∧
      Matrix.permanent (sourceL1BoundaryMatrix sourceCubicDStar)=sourceTernaryBaseline sourceL1ExceptionalTraces ∧
      (∑ i,|sourceL1ExceptionalTraces i-1|)=sourceCubicEpsilon0 := by
  have hf := (source_l1_boundary_family_feasible sourceCubicDStar source_cubic_dstar_bounds.1 source_l1_dstar_eighth_bound).1
  rw [source_l1_boundary_dstar_trace_profile] at hf
  have hg := source_l1_boundary_family_gap sourceCubicDStar source_cubic_dstar_bounds.1.le
  rw [source_cubic_dstar_equation,source_l1_boundary_dstar_trace_profile] at hg
  have hd := source_l1_boundary_distance sourceCubicDStar source_cubic_dstar_bounds.1.le (by linarith [source_cubic_dstar_bounds.2])
  rw [source_l1_boundary_dstar_trace_profile] at hd
  have he := source_cubic_dstar_distance_exact
  norm_num [sourceCubicDistance,sourceCubicS] at he
  have he' : (3-2*sourceCubicDStar)*sourceL1BoundaryS sourceCubicDStar=sourceCubicEpsilon0 := by
    simpa [sourceL1BoundaryS,add_comm] using he
  exact ⟨hf,by linarith,hd.trans he'⟩

end CoefficientStability
