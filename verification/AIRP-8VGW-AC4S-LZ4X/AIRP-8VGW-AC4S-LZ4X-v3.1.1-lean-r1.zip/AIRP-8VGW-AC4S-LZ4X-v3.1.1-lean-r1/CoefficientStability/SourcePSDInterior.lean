import CoefficientStability.SourcePSDTraceSelfDuality
import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Order

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 2200000
set_option backward.isDefEq.respectTransparency false

theorem source_psd_near_positive_identity {n : ℕ} (a : ℝ) (ha : 0 < a)
    (A : Matrix (Fin n) (Fin n) ℂ) (hA : A.IsHermitian)
    (hr : ‖A-a • (1 : Matrix (Fin n) (Fin n) ℂ)‖ < a) : A.PosSemidef := by
  have hH : IsSelfAdjoint (A-a • (1 : Matrix (Fin n) (Fin n) ℂ)) :=
    hA.sub (Matrix.isHermitian_one.smul (IsSelfAdjoint.of_nonneg ha.le))
  have hn := IsSelfAdjoint.neg_algebraMap_norm_le_self (A-a • (1 : Matrix (Fin n) (Fin n) ℂ)) hH
  have hn' : (-‖A-a • (1 : Matrix (Fin n) (Fin n) ℂ)‖) • (1 : Matrix (Fin n) (Fin n) ℂ) ≤ A-a • 1 := by
    simpa only [Algebra.algebraMap_eq_smul_one,neg_smul] using hn
  have hh := add_le_add_right hn' (a • (1 : Matrix (Fin n) (Fin n) ℂ))
  have hc : a • (1 : Matrix (Fin n) (Fin n) ℂ)+(A-a • 1)=A := by abel
  rw [hc] at hh
  have he : a • (1 : Matrix (Fin n) (Fin n) ℂ)+(-‖A-a • (1 : Matrix (Fin n) (Fin n) ℂ)‖) • 1=
      (a-‖A-a • (1 : Matrix (Fin n) (Fin n) ℂ)‖) • 1 := by module
  rw [he] at hh
  have hp : 0 ≤ (a-‖A-a • (1 : Matrix (Fin n) (Fin n) ℂ)‖) • (1 : Matrix (Fin n) (Fin n) ℂ) :=
    (Matrix.PosSemidef.one.smul (sub_nonneg.mpr hr.le)).nonneg
  exact Matrix.nonneg_iff_posSemidef.mp (hp.trans hh)

theorem source_psd_positive_identity_interior (a : ℝ) (ha : 0 < a) :
    a • sourceCubicHermitianOne ∈ interior {A : SourceCubicHermitianSpace | A.val.PosSemidef} := by
  apply mem_interior_iff_mem_nhds.mpr
  apply Metric.mem_nhds_iff.mpr
  refine ⟨a,ha,?_⟩
  intro Y hY
  apply source_psd_near_positive_identity a ha Y.val Y.property
  simpa [Metric.mem_ball,dist_eq_norm,sourceCubicHermitianOne] using hY

end CoefficientStability
