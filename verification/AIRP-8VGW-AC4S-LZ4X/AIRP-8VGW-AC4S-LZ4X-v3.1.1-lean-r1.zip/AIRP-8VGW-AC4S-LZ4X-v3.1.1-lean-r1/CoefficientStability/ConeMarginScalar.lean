import CoefficientStability.RankOneSourceCapacity

noncomputable section
namespace CoefficientStability

theorem source_cone_margin_scalar_estimates (n : ℕ) (hn : 3≤n) (η s r : ℝ)
    (hη0 : 0<η) (hη1 : η≤1) (hs0 : 0≤s) (hs : s≤η/(64*(n : ℝ)))
    (hr0 : 0≤r) (hr : r≤η/(64*(n : ℝ)^2)) :
    r≤1/2 ∧ 2*s+4*(n : ℝ)*r<1 ∧
      2*(n : ℝ)*s+5*(n : ℝ)^2*r≤7*η/64 ∧
      0<1-2*(n : ℝ)*s-5*(n : ℝ)^2*r ∧
      1+η/2<(1+η)*(1-2*(n : ℝ)*s-5*(n : ℝ)^2*r) := by
  have hn1 : 1≤(n : ℝ) := by exact_mod_cast (show 1≤n by omega)
  have hn0 : 0<(n : ℝ) := by linarith
  have hS := (le_div_iff₀ (by positivity : 0<64*(n : ℝ))).mp hs
  have hR := (le_div_iff₀ (by positivity : 0<64*(n : ℝ)^2)).mp hr
  have hns : 2*(n : ℝ)*s≤η/32 := by nlinarith
  have hn2r : (n : ℝ)^2*r≤η/64 := by nlinarith
  have hn2 : 1≤(n : ℝ)^2 := by nlinarith
  have hrHalf : r≤1/2 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr hn2) hr0]
  have hsScale : 0≤((n : ℝ)-1)*s := mul_nonneg (sub_nonneg.mpr hn1) hs0
  have hrScale : 0≤(n : ℝ)*((n : ℝ)-1)*r :=
    mul_nonneg (mul_nonneg hn0.le (sub_nonneg.mpr hn1)) hr0
  have hsmall : 2*s+4*(n : ℝ)*r<1 := by nlinarith
  have herror : 2*(n : ℝ)*s+5*(n : ℝ)^2*r≤7*η/64 := by nlinarith
  have hpositive : 0<1-2*(n : ℝ)*s-5*(n : ℝ)^2*r := by linarith
  have hmid : 1+50*η/64≤(1+η)*(1-7*η/64) := by
    nlinarith [mul_nonneg hη0.le (sub_nonneg.mpr hη1)]
  have hmul : (1+η)*(1-7*η/64)≤(1+η)*(1-2*(n : ℝ)*s-5*(n : ℝ)^2*r) := by
    apply mul_le_mul_of_nonneg_left _ (by linarith : 0≤1+η)
    linarith
  refine ⟨hrHalf,hsmall,herror,hpositive,?_⟩
  exact lt_of_lt_of_le (by linarith : 1+η/2<1+50*η/64) (hmid.trans hmul)

end CoefficientStability
