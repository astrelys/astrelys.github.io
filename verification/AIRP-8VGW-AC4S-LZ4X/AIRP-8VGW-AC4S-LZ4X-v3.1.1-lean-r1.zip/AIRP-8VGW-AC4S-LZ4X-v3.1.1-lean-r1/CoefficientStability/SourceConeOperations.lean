import CoefficientStability.SourceConeConvexity
import Mathlib.Analysis.Convex.Topology
import Mathlib.Topology.Algebra.Group.Pointwise

noncomputable section
open scoped Pointwise
namespace CoefficientStability
variable {n N : ℕ}

theorem source_positiveSpectralCone_smul (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (x : Fin n → ℝ) (hx : x∈positiveSpectralCone p N) (c : ℝ) (hc : 0<c) :
    c • x∈positiveSpectralCone p N := by
  let P := lineRestriction p (c • x)
  have hpos (t : ℝ) (ht : 0≤t) : 0<P.eval t := by
    rw [eval_lineRestriction_real]
    have heq : (fun i => c*((t/c)+x i))=(fun i => t+(c • x) i) := by
      funext i
      change c*(t/c+x i)=t+c*x i
      field_simp
      <;> ring
    have h := homogeneous_eval_real_scale p N hp c (fun i => (t/c)+x i)
    rw [heq] at h
    rw [h]
    exact mul_pos (pow_pos hc _) (source_cone_forward_eval_pos p x hx (t/c) (div_nonneg ht hc.le))
  have hm : P.Monic := normalized_lineRestriction_monic p (c • x) N hp hnorm
  obtain ⟨roots,hcard,hr,hlead,hfactor⟩ := positive_constant_split_positive_multiset_factors P
    (lineRestriction_splits p hs (c • x)) (fun t ht => hpos t ht.le) (hpos 0 le_rfl)
  refine ⟨roots,hcard.trans (normalized_lineRestriction_natDegree p (c • x) N hp hnorm),hr,?_⟩
  simpa only [hm.leadingCoeff,Polynomial.C_1,one_mul] using hfactor

theorem source_positiveSpectralCone_add (p : MvPolynomial (Fin n) ℝ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (x y : Fin n → ℝ) (hx : x∈positiveSpectralCone p N) (hy : y∈positiveSpectralCone p N) :
    x+y∈positiveSpectralCone p N := by
  have hm := source_positiveSpectralCone_convex p hN hp hs hnorm hx hy
    (a := (1/2 : ℝ)) (b := (1/2 : ℝ)) (by norm_num) (by norm_num) (by norm_num)
  have h := source_positiveSpectralCone_smul p hp hs hnorm _ hm 2 (by norm_num)
  have heq : (2 : ℝ) • ((1/2 : ℝ) • x+(1/2 : ℝ) • y)=x+y := by
    funext i
    change 2*((1/2)*x i+(1/2)*y i)=x i+y i
    ring
  rwa [heq] at h

theorem source_spectralCone_closure_convex (p : MvPolynomial (Fin n) ℝ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) :
    Convex ℝ (closure (positiveSpectralCone p N)) :=
  (source_positiveSpectralCone_convex p hN hp hs hnorm).closure

theorem source_spectralCone_closure_positive_smul (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (x : Fin n → ℝ) (hx : x∈closure (positiveSpectralCone p N)) (c : ℝ) (hc : 0<c) :
    c • x∈closure (positiveSpectralCone p N) := by
  exact map_mem_closure (continuous_const_smul c) hx
    (fun y hy => source_positiveSpectralCone_smul p hp hs hnorm y hy c hc)

theorem source_spectralCone_add_closed (p : MvPolynomial (Fin n) ℝ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (x y : Fin n → ℝ) (hx : x∈positiveSpectralCone p N)
    (hy : y∈closure (positiveSpectralCone p N)) : x+y∈positiveSpectralCone p N := by
  have h : x+y∈positiveSpectralCone p N+closure (positiveSpectralCone p N) :=
    Set.add_mem_add hx hy
  rw [(positiveSpectralCone_isOpen p N hp hs hnorm).add_closure] at h
  obtain ⟨a,ha,b,hb,heq⟩ := h
  rw [← heq]
  exact source_positiveSpectralCone_add p hN hp hs hnorm a b ha hb

end CoefficientStability
