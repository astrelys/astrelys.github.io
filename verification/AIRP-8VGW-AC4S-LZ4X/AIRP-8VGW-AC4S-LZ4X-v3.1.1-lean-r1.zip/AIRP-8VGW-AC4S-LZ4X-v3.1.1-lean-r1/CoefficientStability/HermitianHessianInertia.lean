import CoefficientStability.MatrixFrobeniusQuadratic
import CoefficientStability.VectorHessianRescaling
import CoefficientStability.MixedRealVariation

set_option backward.isDefEq.respectTransparency false
noncomputable section
open scoped BigOperators Matrix.Norms.Elementwise
namespace CoefficientStability
variable {n : ℕ}

def hermitianTangentTuple (A : vectorTangent (tracelessHermitian n) (fun _ : Fin n => 1))
    (i : Fin n) : ComplexSquare n := (A.val i).val.val

def hermitianHessianQuadratic (t : Fin n → ℝ) (ht : ∀ i,t i≠0) :
    QuadraticForm ℝ (vectorTangent (tracelessHermitian n) (fun _ : Fin n => 1)) :=
  rescaledHessianQuadratic (tracelessHermitianQuadratic n) t ht (sourceHessianFactor t)

theorem hermitianHessianQuadratic_apply (t : Fin n → ℝ) (ht : ∀ i,t i≠0)
    (A : vectorTangent (tracelessHermitian n) (fun _ : Fin n => 1)) :
    hermitianHessianQuadratic (n := n) t ht A=sourceHessianCandidate t (hermitianTangentTuple A) := by
  let z := marginalRescaling (tracelessHermitian n) t ht A
  have hsum : (tracelessHermitianInclusion n) (∑ i,z.val i)=
      ∑ i,(tracelessHermitianInclusion n) (z.val i) := map_sum _ _ _
  have hz (i : Fin n) : tracelessHermitianInclusion n (z.val i)=
      Complex.ofReal ((t i)⁻¹) • hermitianTangentTuple A i := by
    change (t i)⁻¹ • (A.val i).val.val=Complex.ofReal ((t i)⁻¹) • (A.val i).val.val
    apply Matrix.ext
    intro r c
    exact Complex.real_smul
  change sourceHessianFactor t*vectorHessianQuadratic (tracelessHermitianQuadratic n) t z=_
  rw [vectorHessianQuadratic_apply]
  simp only [tracelessHermitianQuadratic,QuadraticMap.comp_apply,matrixFrobeniusQuadratic_apply]
  rw [hsum]
  simp only [hz]
  rfl

theorem paper_hermitian_hessian_quadratic (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∀ i,0<t i) (A : vectorTangent (tracelessHermitian n) (fun _ : Fin n => 1)) :
    deriv (fun s : ℝ => deriv (fun z : ℝ => hermitianMixedObjective
      (complexReferenceTuple t+(z : ℂ) • hermitianTangentTuple A)) s) 0=
      hermitianHessianQuadratic (n := n) t (fun i => ne_of_gt (ht i)) A := by
  rw [hermitianHessianQuadratic_apply]
  apply paper_real_scalar_hessian t hn ht
  · exact fun i => tracelessHermitian_has_trace_zero (A.val i)
  · exact fun i => (A.val i).val.property

theorem paper_hermitian_hessian_inertia_positive (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : 0<scalarHessianLambda t) :
    sigPos (R := ℝ) (M := vectorTangent (tracelessHermitian n) (fun _ : Fin n => (1 : ℝ))) (hermitianHessianQuadratic (n := n) t (fun i => ne_of_gt (htpos i)))=(n-1)*(n^2-1) ∧
    sigNeg (R := ℝ) (M := vectorTangent (tracelessHermitian n) (fun _ : Fin n => (1 : ℝ))) (hermitianHessianQuadratic (n := n) t (fun i => ne_of_gt (htpos i)))=0 ∧
    Module.finrank ℝ (QuadraticMap.radical (R := ℝ) (M := vectorTangent (tracelessHermitian n) (fun _ : Fin n => (1 : ℝ))) (P := ℝ) (hermitianHessianQuadratic (n := n) t (fun i => ne_of_gt (htpos i))))=0 := by
  have he := rescaledHessian_equivalent (tracelessHermitianQuadratic n) t
    (fun i => ne_of_gt (htpos i)) (sourceHessianFactor t) (sourceHessianFactor_pos t hn htpos)
  change QuadraticMap.Equivalent (hermitianHessianQuadratic (n := n) t (fun i => ne_of_gt (htpos i))) _ at he
  have hp := QuadraticMap.Equivalent.sigPos_eq (R := ℝ)
    (M := vectorTangent (tracelessHermitian n) (fun _ : Fin n => (1 : ℝ)))
    (M' := vectorTangent (tracelessHermitian n) t) he
  have hm := QuadraticMap.Equivalent.sigNeg_eq (R := ℝ)
    (M := vectorTangent (tracelessHermitian n) (fun _ : Fin n => (1 : ℝ)))
    (M' := vectorTangent (tracelessHermitian n) t) he
  have hr := QuadraticMap.Equivalent.rank_radical_eq (R := ℝ)
    (M := vectorTangent (tracelessHermitian n) (fun _ : Fin n => (1 : ℝ)))
    (M' := vectorTangent (tracelessHermitian n) t) he
  rw [hp,hm,hr]
  simpa only [tracelessHermitian_finrank (by omega : 0<n)] using
    vectorHessian_inertia_positive (tracelessHermitianQuadratic n)
      (tracelessHermitianQuadratic_positive n) t hn ht hl

theorem paper_hermitian_hessian_inertia_nonpositive (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : scalarHessianLambda t≤0) :
    sigPos (R := ℝ) (M := vectorTangent (tracelessHermitian n) (fun _ : Fin n => (1 : ℝ))) (hermitianHessianQuadratic (n := n) t (fun i => ne_of_gt (htpos i)))=(n-2)*(n^2-1) ∧
    sigNeg (R := ℝ) (M := vectorTangent (tracelessHermitian n) (fun _ : Fin n => (1 : ℝ))) (hermitianHessianQuadratic (n := n) t (fun i => ne_of_gt (htpos i)))=
      (if scalarHessianLambda t<0 then n^2-1 else 0) ∧
    Module.finrank ℝ (QuadraticMap.radical (R := ℝ) (M := vectorTangent (tracelessHermitian n) (fun _ : Fin n => (1 : ℝ))) (P := ℝ) (hermitianHessianQuadratic (n := n) t (fun i => ne_of_gt (htpos i))))=
      (if scalarHessianLambda t=0 then n^2-1 else 0) := by
  have he := rescaledHessian_equivalent (tracelessHermitianQuadratic n) t
    (fun i => ne_of_gt (htpos i)) (sourceHessianFactor t) (sourceHessianFactor_pos t hn htpos)
  change QuadraticMap.Equivalent (hermitianHessianQuadratic (n := n) t (fun i => ne_of_gt (htpos i))) _ at he
  have hp := QuadraticMap.Equivalent.sigPos_eq (R := ℝ)
    (M := vectorTangent (tracelessHermitian n) (fun _ : Fin n => (1 : ℝ)))
    (M' := vectorTangent (tracelessHermitian n) t) he
  have hm := QuadraticMap.Equivalent.sigNeg_eq (R := ℝ)
    (M := vectorTangent (tracelessHermitian n) (fun _ : Fin n => (1 : ℝ)))
    (M' := vectorTangent (tracelessHermitian n) t) he
  have hr := QuadraticMap.Equivalent.rank_radical_eq (R := ℝ)
    (M := vectorTangent (tracelessHermitian n) (fun _ : Fin n => (1 : ℝ)))
    (M' := vectorTangent (tracelessHermitian n) t) he
  rw [hp,hm,hr]
  simpa only [tracelessHermitian_finrank (by omega : 0<n)] using
    vectorHessian_inertia_nonpositive (tracelessHermitianQuadratic n)
      (tracelessHermitianQuadratic_positive n) t hn ht hl

end CoefficientStability
