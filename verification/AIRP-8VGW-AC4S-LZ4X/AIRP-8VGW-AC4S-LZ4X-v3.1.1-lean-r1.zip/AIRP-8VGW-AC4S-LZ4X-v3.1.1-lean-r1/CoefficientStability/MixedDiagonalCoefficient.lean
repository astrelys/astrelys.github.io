import CoefficientStability.BoundaryFeasibility

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def squarefreeExponent (n : ℕ) : Fin n →₀ ℕ := ∑ i : Fin n,Finsupp.single i 1

def assignmentExponent (f : Fin n → Fin n) : Fin n →₀ ℕ := ∑ r,Finsupp.single (f r) 1

theorem assignmentExponent_eq_squarefree_iff (f : Fin n → Fin n) :
    assignmentExponent f=squarefreeExponent n ↔ Function.Bijective f := by
  classical
  constructor
  · intro he
    have hs : Function.Surjective f := by
      intro i
      by_contra! h
      have hv := congrArg (fun g : Fin n →₀ ℕ => g i) he
      simp [assignmentExponent,squarefreeExponent,Finsupp.single_apply,h,eq_comm] at hv
    exact (Fintype.bijective_iff_surjective_and_card f).mpr ⟨hs,rfl⟩
  · intro hf
    exact Fintype.sum_bijective f hf _ _ (fun _ => rfl)

section Generic
variable {R : Type*} [CommRing R]

theorem generic_sum_bijective_functions (f : (Fin n → Fin n) → R) :
    (∑ u : Fin n → Fin n,if Function.Bijective u then f u else 0)=
      ∑ s : Equiv.Perm (Fin n),f s := by
  classical
  rw [← Finset.sum_filter]
  rw [Finset.sum_subtype (p := fun u : Fin n → Fin n => Function.Bijective u) _
    (by intro u; simp only [Finset.mem_filter,Finset.mem_univ,true_and])]
  exact Fintype.sum_equiv Equiv.bijectiveEquiv _ _ (fun u => rfl)

theorem product_linear_assignment_monomial (f : Fin n → Fin n) (b : Fin n → R)
    (s : Finset (Fin n)) :
    (∏ r ∈ s,C (b r)*MvPolynomial.X (f r))=
      monomial (∑ r ∈ s,Finsupp.single (f r) 1) (∏ r ∈ s,b r) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [← MvPolynomial.C_apply]
  | @insert r s hr ih =>
    rw [Finset.prod_insert hr,Finset.sum_insert hr,Finset.prod_insert hr,ih,
      C_mul_X_eq_monomial,monomial_mul_monomial]

theorem coefficient_product_linear_forms (B : Fin n → Fin n → R) :
    (∏ r,∑ i,C (B r i)*MvPolynomial.X i).coeff (squarefreeExponent n)=
      ∑ s : Equiv.Perm (Fin n),∏ r,B r (s r) := by
  classical
  have he := (MultilinearMap.mkPiAlgebra R (Fin n) (MvPolynomial (Fin n) R)).map_sum
    (fun r (i : Fin n) => C (B r i)*MvPolynomial.X i)
  simp only [MultilinearMap.mkPiAlgebra_apply] at he
  rw [he]
  simp only [MvPolynomial.coeff_sum]
  have hterm (f : Fin n → Fin n) :
      (∏ r,C (B r (f r))*MvPolynomial.X (f r)).coeff (squarefreeExponent n)=
        if Function.Bijective f then ∏ r,B r (f r) else 0 := by
    rw [product_linear_assignment_monomial]
    change (monomial (assignmentExponent f) (∏ r,B r (f r))).coeff (squarefreeExponent n)=_
    simp only [MvPolynomial.coeff_monomial,assignmentExponent_eq_squarefree_iff]
  simp only [hterm]
  exact generic_sum_bijective_functions _

def diagonalPencilPolynomial (B : Fin n → Fin n → R) : MvPolynomial (Fin n) R :=
  Matrix.det (∑ i,(MvPolynomial.X i : MvPolynomial (Fin n) R) •
    Matrix.diagonal (fun r => MvPolynomial.C (B r i)))

def diagonalMixedDeterminant (B : Fin n → Fin n → R) : R :=
  (diagonalPencilPolynomial B).coeff (squarefreeExponent n)

theorem diagonalPencilPolynomial_eq_product (B : Fin n → Fin n → R) :
    diagonalPencilPolynomial B=∏ r,∑ i,C (B r i)*MvPolynomial.X i := by
  unfold diagonalPencilPolynomial
  have he : (∑ i,(MvPolynomial.X i : MvPolynomial (Fin n) R) •
      Matrix.diagonal (fun r => C (B r i)))=Matrix.diagonal (fun r => ∑ i,C (B r i)*MvPolynomial.X i) := by
    ext r l
    by_cases h : r=l <;> simp [Matrix.sum_apply,Matrix.smul_apply,Matrix.diagonal_apply,h,mul_comm]
  rw [he,Matrix.det_diagonal]

theorem diagonalMixedDeterminant_eq_permutation_sum (B : Fin n → Fin n → R) :
    diagonalMixedDeterminant B=∑ s : Equiv.Perm (Fin n),∏ r,B r (s r) := by
  rw [diagonalMixedDeterminant,diagonalPencilPolynomial_eq_product,coefficient_product_linear_forms]

end Generic
end CoefficientStability
