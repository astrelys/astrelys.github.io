import CoefficientStability.SourceBalancedGatePermutationGeometry
import Mathlib.Topology.Connected.Clopen

noncomputable section
open scoped BigOperators Topology unitInterval
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

theorem source_escape_balanced_every_curve_strict_height (γ : SourceEscapeCurve)
    (hγ : sourceEscapeAdmissible 1 1 γ) : sourceEscapeDelta 1 1 < sourceEscapeCurveHeight 1 1 γ := by
  apply lt_of_not_ge
  intro hheight
  have hCP : Matrix.permanent (sourceEscapeCenter 1 1)=2/9 := by
    norm_num [sourceEscapeCenter,sourceEscapeTraces,sourcePermanentReference,source_permanent_three]
  have hp : ∀ u,Matrix.permanent (γ u) ≤ 1/4 := by
    intro u
    have h := source_escape_curve_excess_le_height 1 1 γ u
    unfold sourceEscapeExcess at h
    rw [hCP] at h
    norm_num [sourceEscapeDelta] at hheight
    linarith
  let g : unitInterval → ℝ := fun u => sourceEscapeQuadratic 1 1 (γ u-sourceEscapeCenter 1 1)
  have hc : Continuous g := (source_escape_quadratic_continuous 1 1).comp (γ.continuous.sub continuous_const)
  have hboundary : ∀ u,g u=sourceEscapeQ 1 1 → ∀ᶠ v in 𝓝 u,g v ≤ sourceEscapeQ 1 1 := by
    intro u hu
    obtain ⟨c,hgate⟩ := source_balanced_crossing_is_one_of_six_gates (γ u) (hγ.2.1 u) hu (hp u)
    have ht : Filter.Tendsto (fun v : unitInterval => γ v) (𝓝 u)
        (𝓝 (sourcePermutedMatrix sourceBalancedEscapeGate 1 c)) := by
      have ht0 : Filter.Tendsto (fun v : unitInterval => γ v) (𝓝 u) (𝓝 (γ u)) := γ.continuous.continuousAt
      rw [hgate] at ht0
      exact ht0
    have hnear := ht.eventually (source_balanced_every_gate_actual_local_exclusion c)
    filter_upwards [hnear] with v hv
    by_contra hnot
    have hq : sourceEscapeQ 1 1 < g v := lt_of_not_ge hnot
    have hgt := hv (hγ.2.1 v) hq
    exact not_lt_of_ge (hp v) hgt
  let A : Set unitInterval := {u | g u ≤ sourceEscapeQ 1 1}
  have hclosed : IsClosed A := isClosed_le hc continuous_const
  have hopen : IsOpen A := by
    rw [isOpen_iff_mem_nhds]
    intro u hu
    have hule : g u ≤ sourceEscapeQ 1 1 := hu
    by_cases hlt : g u < sourceEscapeQ 1 1
    · exact (hc.continuousAt.eventually (gt_mem_nhds hlt)).mono (fun v hv => hv.le)
    · exact hboundary u (le_antisymm hule (le_of_not_gt hlt))
  have hg0 : g 0=0 := by simp [g,hγ.1]
  have hzero : (0 : unitInterval) ∈ A := by
    change g 0 ≤ sourceEscapeQ 1 1
    rw [hg0]
    norm_num [sourceEscapeQ]
  have hAll : A=Set.univ := (show IsClopen A from ⟨hclosed,hopen⟩).eq_univ ⟨0,hzero⟩
  have hone : (1 : unitInterval) ∈ A := by rw [hAll];trivial
  change g 1 ≤ sourceEscapeQ 1 1 at hone
  exact not_lt_of_ge hone hγ.2.2

theorem source_escape_balanced_actual_nonattainment (γ : SourceEscapeCurve)
    (hγ : sourceEscapeAdmissible 1 1 γ) : sourceEscapeBarrier 1 1 < sourceEscapeCurveHeight 1 1 γ := by
  rw [source_escape_balanced_actual_barrier]
  exact source_escape_balanced_every_curve_strict_height γ hγ

end CoefficientStability
