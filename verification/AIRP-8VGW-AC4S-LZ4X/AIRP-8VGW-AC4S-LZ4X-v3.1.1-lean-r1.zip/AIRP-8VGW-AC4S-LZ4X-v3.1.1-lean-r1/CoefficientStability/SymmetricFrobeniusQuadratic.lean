import CoefficientStability.SymmetricDimension
import CoefficientStability.MatrixFrobeniusQuadratic

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def tracelessSymmetricInclusion (n : ℕ) : tracelessSymmetric n →ₗ[ℝ] ComplexSquare n where
  toFun A := fun r c => Complex.ofReal (A.val.val r c)
  map_add' A B := by
    apply Matrix.ext
    intro r c
    change Complex.ofReal (A.val.val r c+B.val.val r c)=Complex.ofReal (A.val.val r c)+Complex.ofReal (B.val.val r c)
    rw [Complex.ofReal_add]
  map_smul' a A := by
    apply Matrix.ext
    intro r c
    change Complex.ofReal (a*A.val.val r c)=a • Complex.ofReal (A.val.val r c)
    rw [Complex.real_smul,Complex.ofReal_mul]

def tracelessSymmetricQuadratic (n : ℕ) : QuadraticForm ℝ (tracelessSymmetric n) :=
  (matrixFrobeniusQuadratic n).comp (tracelessSymmetricInclusion n)

theorem tracelessSymmetricQuadratic_apply (A : tracelessSymmetric n) :
    tracelessSymmetricQuadratic n A=complexFrobeniusSq (tracelessSymmetricInclusion n A) := by
  exact matrixFrobeniusQuadratic_apply _

theorem tracelessSymmetricInclusion_injective (n : ℕ) :
    Function.Injective (tracelessSymmetricInclusion n) := by
  intro A B he
  apply Subtype.ext
  apply Subtype.ext
  apply Matrix.ext
  intro r c
  exact Complex.ofReal_injective (congrArg (fun M : ComplexSquare n => M r c) he)

theorem tracelessSymmetricQuadratic_positive (n : ℕ) : (tracelessSymmetricQuadratic n).PosDef := by
  intro A hA
  rw [tracelessSymmetricQuadratic_apply]
  apply complexFrobeniusSq_pos
  intro he
  apply hA
  apply tracelessSymmetricInclusion_injective n
  simpa using he

theorem tracelessSymmetric_has_trace_zero (A : tracelessSymmetric n) :
    Matrix.trace (tracelessSymmetricInclusion n A)=0 := by
  have he : Matrix.trace A.val.val=0 := A.property
  change (∑ i,Complex.ofReal (A.val.val i i))=0
  rw [← Complex.ofReal_sum]
  exact_mod_cast he

theorem tracelessSymmetric_isHermitian (A : tracelessSymmetric n) :
    (tracelessSymmetricInclusion n A).IsHermitian := by
  apply Matrix.ext
  intro r c
  change star (Complex.ofReal (A.val.val c r))=Complex.ofReal (A.val.val r c)
  rw [Complex.star_def,Complex.conj_ofReal]
  apply congrArg Complex.ofReal
  have he := congrArg (fun M : RealSquare n => M r c) A.val.property
  exact he

end CoefficientStability
