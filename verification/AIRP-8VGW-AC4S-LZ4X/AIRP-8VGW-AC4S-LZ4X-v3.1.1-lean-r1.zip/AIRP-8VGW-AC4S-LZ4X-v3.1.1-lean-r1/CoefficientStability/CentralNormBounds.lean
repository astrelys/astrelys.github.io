import CoefficientStability.PolarizationReconstruction

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem paper_central_coefficientL1_bound
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N k : ℕ)
    (hN : 2≤N) (hk : k≤N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    coefficientL1 (centralCoefficientPolynomial p t N k) ≤
      (N.choose k : ℝ)*((k : ℝ)*n)^k/(k.factorial : ℝ)*Real.sqrt (2*referenceDeficit p t N)^k := by
  have h := homogeneous_coefficientL1_bound_of_signedPolarization
    (centralCoefficientPolynomial p t N k) k (centralCoefficientPolynomial_homogeneous p t N k hk hp)
    _ (fun f => paper_central_signedPolarization_bound p t N k f hN hk hp hnorm hstable hgrad)
  apply h.trans_eq
  rw [mul_pow]
  ring

theorem central_exponent_ceiling_spec (k : ℕ) (hk : 2≤k) :
    k-2≤2*((k-1)/2) ∧ ∀ r : ℕ,k-2≤2*r → (k-1)/2≤r := by
  constructor
  · omega
  · intro r hr
    omega

theorem sqrt_variance_power_le_linear (d : ℝ) (n k : ℕ) (hn : 2≤n) (hk : 2≤k)
    (hd : 0≤d) (hmax : 2*d≤(n : ℝ)-1) :
    Real.sqrt (2*d)^k ≤ 2*d*((n : ℝ)-1)^((k-1)/2) := by
  have hd2 : 0≤2*d := by positivity
  have hn' : (2 : ℝ)≤n := by exact_mod_cast hn
  have hb : (1 : ℝ)≤(n : ℝ)-1 := by linarith
  have hb0 : 0≤(n : ℝ)-1 := by linarith
  have hs0 : 0≤Real.sqrt (2*d) := Real.sqrt_nonneg _
  have hsq := Real.sq_sqrt hd2
  have hs : Real.sqrt (2*d)≤(n : ℝ)-1 := by nlinarith
  let r := (k-2)/2
  have heven (r : ℕ) : Real.sqrt (2*d)^(2*r+2)=2*d*(2*d)^r := by
    rw [pow_add,pow_mul,hsq]
    ring
  have hm : (k-2)%2=0 ∨ (k-2)%2=1 := by omega
  rcases hm with hm | hm
  · have he : k=2*r+2 := by dsimp [r]; omega
    have hc : (k-1)/2=r := by omega
    rw [hc,he,heven]
    exact mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hd2 hmax r) hd2
  · have he : k=(2*r+2)+1 := by dsimp [r]; omega
    have hc : (k-1)/2=r+1 := by omega
    rw [hc,he,pow_succ,heven,pow_succ]
    have hp := pow_le_pow_left₀ hd2 hmax r
    calc
      (2*d*(2*d)^r)*Real.sqrt (2*d) = 2*d*((2*d)^r*Real.sqrt (2*d)) := by ring
      _ ≤ 2*d*(((n : ℝ)-1)^r*((n : ℝ)-1)) := by
        apply mul_le_mul_of_nonneg_left _ hd2
        exact mul_le_mul hp hs hs0 (pow_nonneg hb0 r)

theorem paper_central_coefficientL1_linear_bound
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (k : ℕ)
    (hn : 2≤n) (hk : 2≤k) (hkn : k≤n) (hp : p.IsHomogeneous n)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p)
    (hcoeff : ∀ g,0≤p.coeff g) (ht : ∑ i,t i=n)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    coefficientL1 (centralCoefficientPolynomial p t n k) ≤
      2*((n.choose k : ℝ)*((k : ℝ)*n)^k/(k.factorial : ℝ)*
        ((n : ℝ)-1)^((k-1)/2))*referenceDeficit p t n := by
  have hd := paper_deficit_uniform_bound p t hn hp hnorm hstable hcoeff ht hgrad
  have hmax : 2*referenceDeficit p t n≤(n : ℝ)-1 := by linarith
  have hpow := sqrt_variance_power_le_linear (referenceDeficit p t n) n k hn hk hd.1 hmax
  have h := paper_central_coefficientL1_bound p t n k hn hkn hp hnorm hstable hgrad
  calc
    _ ≤ _ := h
    _ ≤ ((n.choose k : ℝ)*((k : ℝ)*n)^k/(k.factorial : ℝ))*
        (2*referenceDeficit p t n*((n : ℝ)-1)^((k-1)/2)) := by
      apply mul_le_mul_of_nonneg_left hpow
      positivity
    _ = _ := by ring

end CoefficientStability
