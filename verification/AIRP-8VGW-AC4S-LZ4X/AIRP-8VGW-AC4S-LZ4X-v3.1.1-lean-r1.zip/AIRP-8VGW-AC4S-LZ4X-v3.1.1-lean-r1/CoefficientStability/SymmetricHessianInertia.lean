import CoefficientStability.SymmetricFrobeniusQuadratic
import CoefficientStability.VectorHessianRescaling
import CoefficientStability.MixedRealVariation

set_option backward.isDefEq.respectTransparency false
noncomputable section
open scoped BigOperators Matrix.Norms.Elementwise
namespace CoefficientStability
variable {n : ℕ}

def symmetricTangentTuple (A : vectorTangent (tracelessSymmetric n) (fun _ : Fin n => 1))
    (i : Fin n) : ComplexSquare n := tracelessSymmetricInclusion n (A.val i)

def symmetricHessianQuadratic (t : Fin n → ℝ) (ht : ∀ i,t i≠0) :
    QuadraticForm ℝ (vectorTangent (tracelessSymmetric n) (fun _ : Fin n => 1)) :=
  rescaledHessianQuadratic (tracelessSymmetricQuadratic n) t ht (sourceHessianFactor t)

theorem symmetricHessianQuadratic_apply (t : Fin n → ℝ) (ht : ∀ i,t i≠0)
    (A : vectorTangent (tracelessSymmetric n) (fun _ : Fin n => 1)) :
    symmetricHessianQuadratic (n := n) t ht A=sourceHessianCandidate t (symmetricTangentTuple A) := by
  let z := marginalRescaling (tracelessSymmetric n) t ht A
  have hsum : (tracelessSymmetricInclusion n) (∑ i,z.val i)=
      ∑ i,(tracelessSymmetricInclusion n) (z.val i) := map_sum _ _ _
  have hz (i : Fin n) : tracelessSymmetricInclusion n (z.val i)=
      Complex.ofReal ((t i)⁻¹) • symmetricTangentTuple A i := by
    change tracelessSymmetricInclusion n ((t i)⁻¹ • A.val i)=Complex.ofReal ((t i)⁻¹) • tracelessSymmetricInclusion n (A.val i)
    rw [map_smul]
    apply Matrix.ext
    intro r c
    exact Complex.real_smul
  change sourceHessianFactor t*vectorHessianQuadratic (tracelessSymmetricQuadratic n) t z=_
  rw [vectorHessianQuadratic_apply]
  simp only [tracelessSymmetricQuadratic,QuadraticMap.comp_apply,matrixFrobeniusQuadratic_apply]
  rw [hsum]
  simp only [hz]
  rfl

theorem paper_symmetric_hessian_quadratic (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∀ i,0<t i) (A : vectorTangent (tracelessSymmetric n) (fun _ : Fin n => 1)) :
    deriv (fun s : ℝ => deriv (fun z : ℝ => hermitianMixedObjective
      (complexReferenceTuple t+(z : ℂ) • symmetricTangentTuple A)) s) 0=
      symmetricHessianQuadratic (n := n) t (fun i => ne_of_gt (ht i)) A := by
  rw [symmetricHessianQuadratic_apply]
  apply paper_real_scalar_hessian t hn ht
  · exact fun i => tracelessSymmetric_has_trace_zero (A.val i)
  · exact fun i => tracelessSymmetric_isHermitian (A.val i)

theorem paper_symmetric_hessian_inertia_positive (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : 0<scalarHessianLambda t) :
    sigPos (R := ℝ) (M := vectorTangent (tracelessSymmetric n) (fun _ : Fin n => (1 : ℝ))) (symmetricHessianQuadratic (n := n) t (fun i => ne_of_gt (htpos i)))=(n-1)*(n*(n+1)/2-1) ∧
    sigNeg (R := ℝ) (M := vectorTangent (tracelessSymmetric n) (fun _ : Fin n => (1 : ℝ))) (symmetricHessianQuadratic (n := n) t (fun i => ne_of_gt (htpos i)))=0 ∧
    Module.finrank ℝ (QuadraticMap.radical (R := ℝ) (M := vectorTangent (tracelessSymmetric n) (fun _ : Fin n => (1 : ℝ))) (P := ℝ) (symmetricHessianQuadratic (n := n) t (fun i => ne_of_gt (htpos i))))=0 := by
  have he := rescaledHessian_equivalent (tracelessSymmetricQuadratic n) t
    (fun i => ne_of_gt (htpos i)) (sourceHessianFactor t) (sourceHessianFactor_pos t hn htpos)
  change QuadraticMap.Equivalent (symmetricHessianQuadratic (n := n) t (fun i => ne_of_gt (htpos i))) _ at he
  have hp := QuadraticMap.Equivalent.sigPos_eq (R := ℝ)
    (M := vectorTangent (tracelessSymmetric n) (fun _ : Fin n => (1 : ℝ)))
    (M' := vectorTangent (tracelessSymmetric n) t) he
  have hm := QuadraticMap.Equivalent.sigNeg_eq (R := ℝ)
    (M := vectorTangent (tracelessSymmetric n) (fun _ : Fin n => (1 : ℝ)))
    (M' := vectorTangent (tracelessSymmetric n) t) he
  have hr := QuadraticMap.Equivalent.rank_radical_eq (R := ℝ)
    (M := vectorTangent (tracelessSymmetric n) (fun _ : Fin n => (1 : ℝ)))
    (M' := vectorTangent (tracelessSymmetric n) t) he
  rw [hp,hm,hr]
  simpa only [tracelessSymmetric_finrank (by omega : 0<n)] using
    vectorHessian_inertia_positive (tracelessSymmetricQuadratic n)
      (tracelessSymmetricQuadratic_positive n) t hn ht hl

theorem paper_symmetric_hessian_inertia_nonpositive (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : scalarHessianLambda t≤0) :
    sigPos (R := ℝ) (M := vectorTangent (tracelessSymmetric n) (fun _ : Fin n => (1 : ℝ))) (symmetricHessianQuadratic (n := n) t (fun i => ne_of_gt (htpos i)))=(n-2)*(n*(n+1)/2-1) ∧
    sigNeg (R := ℝ) (M := vectorTangent (tracelessSymmetric n) (fun _ : Fin n => (1 : ℝ))) (symmetricHessianQuadratic (n := n) t (fun i => ne_of_gt (htpos i)))=
      (if scalarHessianLambda t<0 then n*(n+1)/2-1 else 0) ∧
    Module.finrank ℝ (QuadraticMap.radical (R := ℝ) (M := vectorTangent (tracelessSymmetric n) (fun _ : Fin n => (1 : ℝ))) (P := ℝ) (symmetricHessianQuadratic (n := n) t (fun i => ne_of_gt (htpos i))))=
      (if scalarHessianLambda t=0 then n*(n+1)/2-1 else 0) := by
  have he := rescaledHessian_equivalent (tracelessSymmetricQuadratic n) t
    (fun i => ne_of_gt (htpos i)) (sourceHessianFactor t) (sourceHessianFactor_pos t hn htpos)
  change QuadraticMap.Equivalent (symmetricHessianQuadratic (n := n) t (fun i => ne_of_gt (htpos i))) _ at he
  have hp := QuadraticMap.Equivalent.sigPos_eq (R := ℝ)
    (M := vectorTangent (tracelessSymmetric n) (fun _ : Fin n => (1 : ℝ)))
    (M' := vectorTangent (tracelessSymmetric n) t) he
  have hm := QuadraticMap.Equivalent.sigNeg_eq (R := ℝ)
    (M := vectorTangent (tracelessSymmetric n) (fun _ : Fin n => (1 : ℝ)))
    (M' := vectorTangent (tracelessSymmetric n) t) he
  have hr := QuadraticMap.Equivalent.rank_radical_eq (R := ℝ)
    (M := vectorTangent (tracelessSymmetric n) (fun _ : Fin n => (1 : ℝ)))
    (M' := vectorTangent (tracelessSymmetric n) t) he
  rw [hp,hm,hr]
  simpa only [tracelessSymmetric_finrank (by omega : 0<n)] using
    vectorHessian_inertia_nonpositive (tracelessSymmetricQuadratic n)
      (tracelessSymmetricQuadratic_positive n) t hn ht hl

end CoefficientStability
