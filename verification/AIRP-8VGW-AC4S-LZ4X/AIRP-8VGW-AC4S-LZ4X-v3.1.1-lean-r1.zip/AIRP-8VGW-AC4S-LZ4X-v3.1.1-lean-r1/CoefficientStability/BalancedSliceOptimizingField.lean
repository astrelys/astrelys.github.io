import CoefficientStability.CoordinateLogMinimum

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem realCoordinateRestriction_lastCases (p : MvPolynomial (Fin (n+1)) ℝ)
    (y : Fin n → ℝ) (z : ℝ) :
    realCoordinateRestriction (Fin.lastCases z y) (Fin.last n) p=
      realCoordinateRestriction (Fin.lastCases 1 y) (Fin.last n) p := by
  apply Polynomial.funext
  intro t
  rw [realCoordinateRestriction_eval,last_real_restriction_eval]
  apply congrArg (fun w : Fin (n+1) → ℝ => MvPolynomial.eval w p)
  funext j
  refine Fin.lastCases ?_ (fun k => ?_) j <;> simp

theorem balanced_last_slice_optimizing_field (hn : 3≤n+1)
    (p : MvPolynomial (Fin (n+1)) ℝ) (hp : p.IsHomogeneous (n+1))
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=1)
    (hL : p.coeff (squarefreeExponent (n+1))≤sourceVn (n+1)*(1+capacityEta (n+1)/2)) :
    ∃ u : Fin (n+1) → ℝ,(∑ j,u j=0) ∧
      1≤MvPolynomial.eval (fun j => Real.exp (u j)) p ∧
      MvPolynomial.eval (fun j => Real.exp (u j)) p≤p.coeff (squarefreeExponent (n+1))/sourceVn (n+1) ∧
      tiltedMoment p u (Fin.last n)=1 := by
  have hc := normalized_homogeneous_stable_coeff_nonneg p (n+1) hp hs hnorm
  obtain ⟨y,z,hy,hyprod,hz,hmin,hcap,hlower,hupper⟩ :=
    balanced_last_slice_capacity_minimizers hn p hp hs hnorm hgrad hL
  let x : Fin (n+1) → ℝ := Fin.lastCases z y
  have hx : ∀ j,0<x j := by
    intro j
    refine Fin.lastCases ?_ (fun k => ?_) j
    · simpa only [x,Fin.lastCases_last] using hz
    · simpa only [x,Fin.lastCases_castSucc] using hy k
  have hprod : (∏ j,x j)=z := by
    dsimp [x]
    rw [Fin.prod_univ_castSucc]
    simp only [Fin.lastCases_castSucc,Fin.lastCases_last,hyprod,one_mul]
  let u := centeredLogVector x
  have heval : MvPolynomial.eval (fun j => Real.exp (u j)) p=
      positiveDomainCapacity (realCoordinateRestriction (Fin.lastCases 1 y) (Fin.last n) p) := by
    rw [centeredLogVector_capacity_eval (by omega) p hp x hx,hprod]
    dsimp [x]
    rw [← last_real_restriction_eval,← hcap]
  have hm : ∀ t : ℝ,0<t → (realCoordinateRestriction x (Fin.last n) p).eval (x (Fin.last n))/x (Fin.last n)≤
      (realCoordinateRestriction x (Fin.last n) p).eval t/t := by
    intro t ht
    dsimp [x]
    rw [realCoordinateRestriction_lastCases,Fin.lastCases_last]
    exact hmin t ht
  have hlogmin := centered_slice_coordinate_log_minimum (by omega) p hp (stable_polynomial_ne_zero p hs)
    hc x hx (Fin.last n) hm
  have hZ : tiltPartition p u≠0 := by
    rw [tiltPartition_eval_exp_all,heval]
    exact ne_of_gt (lt_of_lt_of_le (by norm_num : (0 : ℝ)<1) hlower)
  exact ⟨u,centeredLogVector_sum (by omega) x,heval.symm ▸ hlower,heval.symm ▸ hupper,
    coordinate_log_minimum_moment_one p u (Fin.last n) hZ hlogmin⟩

end CoefficientStability
