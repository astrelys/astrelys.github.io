import CoefficientStability.SubsetRootSumSymmetric
import Mathlib.RingTheory.Polynomial.Vieta

noncomputable section
open scoped BigOperators
namespace CoefficientStability

theorem subsetRootSumElementaryForm_eval {R : Type*} [CommRing R] [Algebra ℝ R]
    (N k : ℕ) (r : Fin N → R) :
    MvPolynomial.aeval (fun j : Fin N =>
      ∑ s∈Finset.univ.powersetCard (j.val+1),∏ i∈s,r i)
      (subsetRootSumElementaryForm N k)=
      ∏ s∈Finset.univ.powersetCard k,∑ i∈s,r i := by
  have h := congrArg (MvPolynomial.aeval r) (subsetRootSumElementaryForm_identity N k)
  rw [MvPolynomial.comp_aeval_apply] at h
  simpa only [MvPolynomial.esymm,map_sum,map_prod,MvPolynomial.aeval_X,
    subsetRootSumPolynomial_eval] using h

end CoefficientStability
