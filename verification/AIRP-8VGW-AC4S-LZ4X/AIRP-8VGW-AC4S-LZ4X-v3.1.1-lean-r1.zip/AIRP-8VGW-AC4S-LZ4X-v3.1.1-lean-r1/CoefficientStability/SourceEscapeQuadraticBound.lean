import CoefficientStability.SourceEscapeGate

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceEscapeRowSq (A : Matrix (Fin 3) (Fin 3) ℝ) (i : Fin 3) : ℝ := ∑ j,(A i j)^2

def sourceEscapeImaginaryCubic (A : Matrix (Fin 3) (Fin 3) ℝ) : ℝ :=
  3*(A 0 0*A 1 0*(A 2 1-A 2 2)+A 0 0*A 2 0*(A 1 1-A 1 2)+A 1 0*A 2 0*(A 0 1-A 0 2))-
    (A 0 1-A 0 2)*(A 1 1-A 1 2)*(A 2 1-A 2 2)

theorem source_escape_actual_cubic_squares_identity (A : Matrix (Fin 3) (Fin 3) ℝ)
    (hA : A ∈ sourceEscapeTangent) :
    4*(2*(∏ i,sourceEscapeRowSq A i)-3*(Matrix.permanent A)^2)=(sourceEscapeImaginaryCubic A)^2 := by
  rw [source_zero_marginal_chart_recovery A hA]
  norm_num [sourceEscapeRowSq,sourceEscapeImaginaryCubic,source_permanent_three,sourceZeroMarginalChart,
    Fin.sum_univ_succ,Fin.prod_univ_succ]
  ring

theorem source_escape_actual_permanent_row_bound (A : Matrix (Fin 3) (Fin 3) ℝ)
    (hA : A ∈ sourceEscapeTangent) :
    3*(Matrix.permanent A)^2 ≤ 2*(∏ i,sourceEscapeRowSq A i) := by
  have h := source_escape_actual_cubic_squares_identity A hA
  nlinarith [sq_nonneg (sourceEscapeImaginaryCubic A)]

theorem source_escape_three_amgm (x y z : ℝ) (hx : 0 ≤ x) (hy : 0 ≤ y) (hz : 0 ≤ z) :
    27*x*y*z ≤ (x+y+z)^3 := by
  have he : 4*((x+y+z)^3-27*x*y*z)=
      (x+y-2*z)^2*(4*(x+y)+z)+27*z*(x-y)^2 := by ring
  have h1 := mul_nonneg (sq_nonneg (x+y-2*z)) (show 0 ≤ 4*(x+y)+z by linarith)
  have h2 := mul_nonneg hz (sq_nonneg (x-y))
  nlinarith

theorem source_escape_actual_weighted_cubic_bound (a b : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b)
    (A : Matrix (Fin 3) (Fin 3) ℝ) (hA : A ∈ sourceEscapeTangent) :
    3*(a*b^2)*(Matrix.permanent A)^2 ≤ 16*(sourceEscapeQuadratic a b A)^3 := by
  have hn (i : Fin 3) : 0 ≤ sourceEscapeRowSq A i := Finset.sum_nonneg (fun j _ => sq_nonneg _)
  have hR := source_escape_actual_permanent_row_bound A hA
  have hM := source_escape_three_amgm (a*sourceEscapeRowSq A 0) (b*sourceEscapeRowSq A 1) (b*sourceEscapeRowSq A 2)
    (mul_nonneg ha (hn 0)) (mul_nonneg hb (hn 1)) (mul_nonneg hb (hn 2))
  have hmul := mul_le_mul_of_nonneg_left hR (mul_nonneg ha (sq_nonneg b))
  have hq : 6*sourceEscapeQuadratic a b A=
      a*sourceEscapeRowSq A 0+b*sourceEscapeRowSq A 1+b*sourceEscapeRowSq A 2 := by
    norm_num [sourceEscapeQuadratic,sourceEscapeWeights,sourceEscapeRowSq,Fin.sum_univ_succ]
    ring
  norm_num [Fin.prod_univ_succ] at hmul
  have he : (a*sourceEscapeRowSq A 0+b*sourceEscapeRowSq A 1+b*sourceEscapeRowSq A 2)^3=
      216*(sourceEscapeQuadratic a b A)^3 := by rw [← hq];ring
  rw [he] at hM
  nlinarith

theorem source_escape_actual_crossing_permanent_bound (a b : ℝ) (ha : 0 < a) (hb : 0 < b)
    (A : Matrix (Fin 3) (Fin 3) ℝ) (hA : A ∈ sourceEscapeTangent)
    (hq : sourceEscapeQuadratic a b A=sourceEscapeQ a b) :
    -(a*b^2/18) ≤ Matrix.permanent A := by
  have h := source_escape_actual_weighted_cubic_bound a b ha.le hb.le A hA
  rw [hq] at h
  have hp : 0 < a*b^2 := mul_pos ha (sq_pos_of_pos hb)
  have he : 16*(sourceEscapeQ a b)^3=3*(a*b^2)*(a*b^2/18)^2 := by unfold sourceEscapeQ;ring
  rw [he] at h
  have hsq : (Matrix.permanent A)^2 ≤ (a*b^2/18)^2 := (mul_le_mul_iff_right₀ (by positivity : 0 < 3*(a*b^2))).mp h
  nlinarith

theorem source_escape_actual_crossing_height_bound (a b : ℝ) (ha : 0 < a) (hb : 0 < b)
    (A : Matrix (Fin 3) (Fin 3) ℝ) (hA : A ∈ sourceEscapeTangent)
    (hq : sourceEscapeQuadratic a b A=sourceEscapeQ a b) :
    sourceEscapeDelta a b ≤ Matrix.permanent (sourceEscapeCenter a b+A)-Matrix.permanent (sourceEscapeCenter a b) := by
  rw [source_escape_actual_cubic_expansion a b A hA,hq]
  have h := source_escape_actual_crossing_permanent_bound a b ha hb A hA hq
  unfold sourceEscapeDelta sourceEscapeQ
  linarith

end CoefficientStability
