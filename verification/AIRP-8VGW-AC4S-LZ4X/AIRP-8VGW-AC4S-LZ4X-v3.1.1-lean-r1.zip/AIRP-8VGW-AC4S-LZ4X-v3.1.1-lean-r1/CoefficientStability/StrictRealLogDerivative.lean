import CoefficientStability.NuijRealPolynomial
import CoefficientStability.NuijOldRootMultiplicity

noncomputable section
open scoped BigOperators Topology
open Filter
namespace CoefficientStability

theorem split_real_logderiv_hasDerivAt (P : Polynomial ℝ) (hs : P.Splits)
    (r : ℝ) (hpr : P.eval r≠0) :
    ∃ d : ℝ,HasDerivAt (fun s : ℝ => P.derivative.eval s/P.eval s) d r ∧
      (0<P.natDegree → d<0) := by
  classical
  obtain ⟨f,henum⟩ := real_multiset_fin_enumeration P.roots
  have hmem (j : Fin P.roots.card) : f j∈P.roots := by rw [← henum];simp
  have hne (j : Fin P.roots.card) : r-f j≠0 := by
    intro hh
    have heq : r=f j := sub_eq_zero.mp hh
    exact hpr (heq ▸ Polynomial.isRoot_of_mem_roots (hmem j))
  have hsum (s : ℝ) : ((P.roots.map (fun a => 1/(s-a))).sum)=∑ j,1/(s-f j) := by
    conv_lhs => rw [← henum]
    simp only [Multiset.map_coe,List.map_ofFn,Multiset.sum_coe,List.sum_ofFn,Function.comp_def]
  have hd (j : Fin P.roots.card) : HasDerivAt (fun s : ℝ => 1/(s-f j)) (-1/(r-f j)^2) r := by
    convert! ((hasDerivAt_id r).sub_const (f j)).inv (hne j) using 1 <;>
      simp only [one_div,one_mul,id_eq] <;> (funext s;rfl)
  have hD := HasDerivAt.fun_sum (u := (Finset.univ : Finset (Fin P.roots.card))) (fun j hj => hd j)
  have hnear : ∀ᶠ s in 𝓝 r,P.eval s≠0 := P.continuousAt.eventually (eventually_ne_nhds hpr)
  have heq : (fun s : ℝ => P.derivative.eval s/P.eval s)=ᶠ[𝓝 r](fun s : ℝ => ∑ j,1/(s-f j)) := by
    filter_upwards [hnear] with s hsne
    rw [hs.eval_derivative_div_eval_of_ne_zero hsne,hsum]
  refine ⟨∑ j,-1/(r-f j)^2,hD.congr_of_eventuallyEq heq,?_⟩
  intro hdegree
  have hcard : 0<P.roots.card := by rw [← hs.natDegree_eq_card_roots];exact hdegree
  apply Finset.sum_neg
  · intro j hj
    exact div_neg_of_neg_of_pos (by norm_num) (sq_pos_of_ne_zero (hne j))
  · exact ⟨⟨0,hcard⟩,Finset.mem_univ _⟩

theorem split_real_strict_laguerre (P : Polynomial ℝ) (hs : P.Splits) (hd : 0<P.natDegree)
    (r : ℝ) (hpr : P.eval r≠0) :
    0<(P.derivative.eval r)^2-P.eval r*P.derivative.derivative.eval r := by
  obtain ⟨d,hD,hdneg⟩ := split_real_logderiv_hasDerivAt P hs r hpr
  have hactual := (P.derivative.hasDerivAt r).div (P.hasDerivAt r) hpr
  have hunique := hactual.unique hD
  have hratio : (P.derivative.derivative.eval r*P.eval r-P.derivative.eval r*P.derivative.eval r)/(P.eval r)^2<0 := by
    rw [hunique]
    exact hdneg hd
  have hnum := (div_lt_iff₀ (sq_pos_of_ne_zero hpr)).mp hratio
  nlinarith

theorem nuij_new_root_derivative_ne_zero (P : Polynomial ℝ) (hs : P.Splits)
    (hd : 0<P.natDegree) (r c : ℝ) (hpr : P.eval r≠0)
    (hroot : (P+Polynomial.C c*P.derivative).eval r=0) :
    (P+Polynomial.C c*P.derivative).derivative.eval r≠0 := by
  have hLag := split_real_strict_laguerre P hs hd r hpr
  intro hzero
  have hpval : P.eval r= -c*P.derivative.eval r := by
    simp only [Polynomial.eval_add,Polynomial.eval_mul,Polynomial.eval_C] at hroot
    linarith
  have hderiv : P.derivative.eval r+c*P.derivative.derivative.eval r=0 := by
    simpa only [Polynomial.derivative_add,Polynomial.derivative_C_mul,Polynomial.eval_add,
      Polynomial.eval_mul,Polynomial.eval_C] using hzero
  have heq : (P.derivative.eval r)^2-P.eval r*P.derivative.derivative.eval r=
      P.derivative.eval r*(P.derivative.eval r+c*P.derivative.derivative.eval r) := by
    rw [hpval]
    ring
  rw [heq,hderiv,mul_zero] at hLag
  linarith

end CoefficientStability
