import CoefficientStability.FinitePrefixAbel

noncomputable section
open scoped BigOperators
namespace CoefficientStability

theorem positive_product_le_one_of_sum_le_card {ι : Type*} (S : Finset ι) (r : ι → ℝ)
    (hr : ∀ i∈S,0<r i) (hsum : (∑ i∈S,r i)≤(S.card : ℝ)) : (∏ i∈S,r i)≤1 := by
  have hlog : (∑ i∈S,Real.log (r i))≤0 := by
    calc
      _≤∑ i∈S,(r i-1) := Finset.sum_le_sum (fun i hi => Real.log_le_sub_one_of_pos (hr i hi))
      _=(∑ i∈S,r i)-(S.card : ℝ) := by simp only [Finset.sum_sub_distrib,Finset.sum_const,nsmul_eq_mul,mul_one]
      _≤0 := sub_nonpos.mpr hsum
  rw [← Real.log_prod (fun i hi => ne_of_gt (hr i hi))] at hlog
  have h := Real.exp_le_exp.mpr hlog
  rwa [Real.exp_log (Finset.prod_pos hr),Real.exp_zero] at h

theorem positive_product_comparison_of_prefix_sums (N : ℕ) (x r : ℕ → ℝ)
    (hx : ∀ i,i<N → 0<x i) (hr : ∀ i,i<N → 0<r i)
    (hmono : ∀ i j,i≤j → j<N → r i≤r j)
    (hprefix : ∀ k,k≤N → (∑ i∈Finset.range k,x i)≤∑ i∈Finset.range k,r i) :
    (∏ i∈Finset.range N,x i)≤∏ i∈Finset.range N,r i := by
  have hweighted := finite_prefix_weighted_sum_nonneg N (fun i => r i-x i) (fun i => 1/r i)
    (by intro k hk;rw [Finset.sum_sub_distrib];exact sub_nonneg.mpr (hprefix k hk))
    (fun i hi => (one_div_pos.mpr (hr i hi)).le)
    (by
      intro i j hij hj
      exact one_div_le_one_div_of_le (hr i (by omega)) (hmono i j hij hj))
  have heq : (∑ i∈Finset.range N,(1/r i)*(r i-x i))=
      (N : ℝ)-(∑ i∈Finset.range N,x i/r i) := by
    have hterm (i : ℕ) (hi : i∈Finset.range N) : (1/r i)*(r i-x i)=1-x i/r i := by
      have hne := ne_of_gt (hr i (Finset.mem_range.mp hi))
      field_simp
      <;> ring
    rw [Finset.sum_congr rfl hterm,Finset.sum_sub_distrib]
    simp
  rw [heq] at hweighted
  have hratio : (∏ i∈Finset.range N,x i/r i)≤1 :=
    positive_product_le_one_of_sum_le_card (Finset.range N) (fun i => x i/r i)
      (fun i hi => div_pos (hx i (Finset.mem_range.mp hi)) (hr i (Finset.mem_range.mp hi)))
      (by simpa only [Finset.card_range] using (sub_nonneg.mp hweighted))
  rw [Finset.prod_div_distrib] at hratio
  have hprod : 0<∏ i∈Finset.range N,r i := Finset.prod_pos (fun i hi => hr i (Finset.mem_range.mp hi))
  simpa only [one_mul] using (div_le_iff₀ hprod).mp hratio

end CoefficientStability
