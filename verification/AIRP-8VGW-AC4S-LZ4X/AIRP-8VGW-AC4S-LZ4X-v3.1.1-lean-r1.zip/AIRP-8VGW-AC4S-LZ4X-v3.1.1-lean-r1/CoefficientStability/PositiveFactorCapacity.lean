import CoefficientStability.RealRootedPositiveFactors
import CoefficientStability.LinearCapacity
import Mathlib.Algebra.Polynomial.Degree.SmallDegree

noncomputable section
open scoped BigOperators
namespace CoefficientStability

theorem positive_split_positive_factor_form (P : Polynomial ℝ) (hs : P.Splits)
    (hp : ∀ x : ℝ,0<x → 0<P.eval x) (hzero : 0<P.eval 0) :
    ∃ k : ℕ,k=P.natDegree ∧ ∃ b : Fin k → ℝ,(∀ j,0<b j) ∧
      ∀ z : ℝ,P.eval z=P.eval 0*∏ j,(1+b j*z) := by
  obtain ⟨roots,hcard,hpos,hleading,hfactor⟩ := positive_constant_split_positive_multiset_factors P hs hp hzero
  obtain ⟨r,henum⟩ := real_multiset_fin_enumeration roots
  have hr (j : Fin roots.card) : r j∈roots := by
    rw [← henum]
    simp
  have hprod : (roots.map (fun r => Polynomial.X+Polynomial.C r)).prod=
      ∏ j,(Polynomial.X+Polynomial.C (r j)) := by
    conv_lhs => rw [← henum]
    simp only [Multiset.map_coe,Multiset.prod_coe,List.map_ofFn,List.prod_ofFn,Function.comp_def]
  have heval (z : ℝ) : P.eval z=P.leadingCoeff*∏ j,(z+r j) := by
    conv_lhs => rw [hfactor,hprod]
    simp only [Polynomial.eval_mul,Polynomial.eval_C,Polynomial.eval_prod,Polynomial.eval_add,Polynomial.eval_X]
  refine ⟨roots.card,hcard,fun j => (r j)⁻¹,fun j => inv_pos.mpr (hpos _ (hr j)),?_⟩
  intro z
  rw [heval z,heval 0]
  simp only [zero_add]
  rw [mul_assoc,← Finset.prod_mul_distrib]
  congr 1
  apply Finset.prod_congr rfl
  intro j hj
  field_simp [ne_of_gt (hpos _ (hr j))]
  ring

theorem positive_constant_real_rooted_capacity_derivative_lower (P : Polynomial ℝ) (hs : P.Splits)
    (hp : ∀ x : ℝ,0<x → 0<P.eval x) (hzero : 0<P.eval 0) :
    capacityG P.natDegree*positiveDomainCapacity P≤P.derivative.eval 0 := by
  by_cases hdegree : P.natDegree≤1
  · have hlin := Polynomial.eq_X_add_C_of_natDegree_le_one hdegree
    have he : P=Polynomial.C (P.coeff 0)+Polynomial.C (P.coeff 1)*Polynomial.X := hlin.trans (add_comm _ _)
    have hcap : positiveDomainCapacity P=P.derivative.eval 0 := by
      rw [he]
      exact affine_capacity_derivative_identity _ _ (by simpa only [Polynomial.coeff_zero_eq_eval_zero] using hzero.le)
    have hg : capacityG P.natDegree=1 := by
      interval_cases h : P.natDegree <;> simp [capacityG,h]
    rw [hg,one_mul,hcap]
  · obtain ⟨k,hk,b,hb,hfactor⟩ := positive_split_positive_factor_form P hs hp hzero
    have hn : 2≤k := by omega
    have h := positive_factor_capacity_derivative_lower P b hn hzero hb hfactor
    simpa only [hk] using h

end CoefficientStability
