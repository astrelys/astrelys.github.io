import CoefficientStability.SourceL1BoundaryAlgebra

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 1600000

theorem source_l1_boundary_distance_continuous : Continuous (fun d : ℝ => (3-2*d)*sourceL1BoundaryS d) := by
  unfold sourceL1BoundaryS
  fun_prop

theorem source_l1_sharpness_radius (R : ℝ) (hR : sourceCubicEpsilon0 < R) :
    ∃ (t : Fin 3 → ℝ) (B : Matrix (Fin 3) (Fin 3) ℝ),(∑ i,t i)=3 ∧
      (∀ i,0 < t i) ∧ B ∈ sourceTransportationPolytope t ∧
      (∑ i,|t i-1|) < R ∧ Matrix.permanent B < sourceTernaryBaseline t := by
  have hFstar : (3-2*sourceCubicDStar)*sourceL1BoundaryS sourceCubicDStar=sourceCubicEpsilon0 := by
    have h := source_cubic_dstar_distance_exact
    norm_num [sourceCubicDistance,sourceCubicS] at h
    simpa [sourceL1BoundaryS,add_comm] using h
  have hn : ∀ᶠ d in 𝓝 sourceCubicDStar,(3-2*d)*sourceL1BoundaryS d < R :=
    source_l1_boundary_distance_continuous.continuousAt.eventually (gt_mem_nhds (by dsimp only;rw [hFstar];exact hR))
  obtain ⟨δ,hδ,hnear⟩ := Metric.eventually_nhds_iff.mp hn
  let e := min δ (1/8-sourceCubicDStar)/2
  have he : 0 < e := div_pos (lt_min hδ (by linarith [source_l1_dstar_eighth_bound])) (by norm_num)
  have heδ : e < δ := by have h := min_le_left δ (1/8-sourceCubicDStar);dsimp [e];linarith
  have he8 : e < 1/8-sourceCubicDStar := by have h := min_le_right δ (1/8-sourceCubicDStar);dsimp [e];linarith [source_l1_dstar_eighth_bound]
  let d := sourceCubicDStar+e
  have hdstar : sourceCubicDStar < d := by dsimp [d];linarith
  have hd : 0 < d := lt_trans source_cubic_dstar_bounds.1 hdstar
  have hd8 : d < 1/8 := by dsimp [d];linarith
  have hdist : dist d sourceCubicDStar < δ := by rw [Real.dist_eq,abs_of_pos (by dsimp [d];linarith)];dsimp [d];linarith
  have hFR := hnear hdist
  obtain ⟨hfeas,hpos⟩ := source_l1_boundary_family_feasible d hd hd8
  have htpos : ∀ i,0 < sourceL1BoundaryTraces d i := by
    intro i
    have hex : ∃ j,0 < sourceL1BoundaryMatrix d i j := by
      fin_cases i
      · exact ⟨1,hpos (0,1) (by decide)⟩
      · exact ⟨0,hpos (1,0) (by decide)⟩
      · exact ⟨2,hpos (2,2) (by decide)⟩
    obtain ⟨j,hj⟩ := hex
    have hb := Finset.single_le_sum (fun k (_ : k ∈ Finset.univ) => hfeas.1 i k) (Finset.mem_univ j)
    rw [hfeas.2.1 i] at hb
    exact lt_of_lt_of_le hj hb
  have hA : 1-10*d-12*d^2 < 0 := by
    have heq : 1-10*d-12*d^2=-(d-sourceCubicDStar)*(10+12*(d+sourceCubicDStar)) := by
      linear_combination source_cubic_dstar_equation
    rw [heq]
    exact mul_neg_of_neg_of_pos (by linarith) (by linarith [source_cubic_dstar_bounds.1])
  have hg := source_l1_boundary_family_gap d hd.le
  have hnegative : (1-d)*(1+2*d)*(1-10*d-12*d^2)/36 < 0 :=
    div_neg_of_neg_of_pos (mul_neg_of_pos_of_neg (mul_pos (by linarith) (by linarith)) hA) (by norm_num)
  refine ⟨sourceL1BoundaryTraces d,sourceL1BoundaryMatrix d,source_l1_boundary_trace_sum d,htpos,hfeas,?_,?_⟩
  · rw [source_l1_boundary_distance d hd.le (by linarith)]
    exact hFR
  · linarith

end CoefficientStability
