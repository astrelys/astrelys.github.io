import CoefficientStability.BalancedEndpointLogGap

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem finite_one_sub_sum_le_product {ι : Type*} (s : Finset ι) (a : ι → ℝ)
    (ha : ∀ i ∈ s,0 ≤ a i) (ha1 : ∀ i ∈ s,a i ≤ 1) :
    1-(∑ i ∈ s,a i) ≤ ∏ i ∈ s,(1-a i) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert i s hi ih =>
    have hia := ha i (Finset.mem_insert_self _ _)
    have hi1 := ha1 i (Finset.mem_insert_self _ _)
    have hsub := ih (fun j hj => ha j (Finset.mem_insert_of_mem hj))
      (fun j hj => ha1 j (Finset.mem_insert_of_mem hj))
    rw [Finset.sum_insert hi,Finset.prod_insert hi]
    have hh := mul_le_mul_of_nonneg_left hsub (sub_nonneg.mpr hi1)
    have hsum : 0 ≤ ∑ j ∈ s,a j := Finset.sum_nonneg (fun j hj => ha j (Finset.mem_insert_of_mem hj))
    nlinarith [mul_nonneg hia hsum]

theorem marginal_product_lower (t : Fin n → ℝ)
    (hsmall : (∑ i,|t i-1|) ≤ 1) :
    1-(∑ i,|t i-1|) ≤ ∏ i,t i := by
  have hai (i : Fin n) : |t i-1| ≤ 1 :=
    (Finset.single_le_sum (fun j hj => abs_nonneg (t j-1)) (Finset.mem_univ i)).trans hsmall
  apply (finite_one_sub_sum_le_product Finset.univ (fun i => |t i-1|)
    (fun i hi => abs_nonneg _) (fun i hi => hai i)).trans
  apply Finset.prod_le_prod₀ (fun i hi => sub_nonneg.mpr (hai i))
  intro i hi
  linarith [neg_abs_le (t i-1)]

theorem marginal_product_upper (t : Fin n → ℝ) (ht : ∀ i,0 ≤ t i)
    (hsum : (∑ i,t i)=n) : (∏ i,t i) ≤ 1 := by
  have hb (i : Fin n) : t i ≤ Real.exp (t i-1) := by
    have h := Real.add_one_le_exp (t i-1)
    linarith
  have h : (∏ i,t i) ≤ ∏ i,Real.exp (t i-1) := Finset.prod_le_prod₀ (fun i hi => ht i) (fun i hi => hb i)
  have hzero : (∑ i,(t i-1))=0 := by
    simp only [Finset.sum_sub_distrib,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,mul_one,hsum,sub_self]
  simpa only [← Real.exp_sum,hzero,Real.exp_zero] using h

end CoefficientStability
