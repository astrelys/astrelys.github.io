import CoefficientStability.ActualMomentEuclideanLipschitz
import CoefficientStability.SourceBalancingRadius

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem coordinate_abs_le_square_sum_sqrt (v : Fin n → ℝ) (i : Fin n) :
    |v i| ≤ Real.sqrt (∑ j,v j^2) := by
  have h : |v i| ≤ ‖v‖ := by simpa only [Real.norm_eq_abs] using norm_le_pi_norm v i
  exact h.trans (real_pi_norm_le_square_sum_sqrt v)

theorem reciprocal_deviation_euclidean_bound (t : Fin n → ℝ) (ht : ∀ i,(1/2 : ℝ) ≤ t i) :
    Real.sqrt (∑ i,(1/t i-1)^2) ≤ 2*Real.sqrt (∑ i,(t i-1)^2) := by
  have ha (i : Fin n) : |1/t i-1| ≤ 2*|t i-1| := by
    have htpos : 0 < t i := lt_of_lt_of_le (by norm_num) (ht i)
    have he : 1/t i-1=(1-t i)/t i := by field_simp
    rw [he,abs_div,abs_of_pos htpos,abs_sub_comm]
    apply (div_le_iff₀ htpos).mpr
    nlinarith [mul_nonneg (abs_nonneg (t i-1)) (show 0 ≤ 2*t i-1 by linarith [ht i])]
  have hs : (∑ i,(1/t i-1)^2) ≤ 4*(∑ i,(t i-1)^2) := by
    rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro i hi
    have h := (sq_le_sq₀ (abs_nonneg _) (by positivity : 0 ≤ 2*|t i-1|)).mpr (ha i)
    simpa only [mul_pow,sq_abs,show (2 : ℝ)^2=4 by norm_num] using h
  have hl : (Real.sqrt (∑ i,(1/t i-1)^2))^2=∑ i,(1/t i-1)^2 :=
    Real.sq_sqrt (Finset.sum_nonneg (fun i hi => sq_nonneg _))
  have hr : (Real.sqrt (∑ i,(t i-1)^2))^2=∑ i,(t i-1)^2 :=
    Real.sq_sqrt (Finset.sum_nonneg (fun i hi => sq_nonneg _))
  nlinarith [Real.sqrt_nonneg (∑ i,(1/t i-1)^2),Real.sqrt_nonneg (∑ i,(t i-1)^2)]

theorem actual_balancing_path_reciprocal_bound (p : MvPolynomial (Fin n) ℝ)
    (u : Fin n → ℝ) (hn : 3 ≤ n) (hp : p.IsHomogeneous n)
    (hc : ∀ g,0 ≤ p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) (hbal : ∀ i,tiltedMoment p u i=1)
    (hsmall : (n : ℝ)*Real.sqrt (∑ i,u i^2) ≤ 1/24)
    (s : ℝ) (hseg : s ∈ Set.Icc (0 : ℝ) 1) :
    (∀ i,(23/24 : ℝ) ≤ tiltedMoment p (s • u) i) ∧
    Real.sqrt (∑ i,(1/tiltedMoment p (s • u) i-1)^2) ≤
      2*(n : ℝ)*(1-s)*Real.sqrt (∑ i,u i^2) := by
  have hb := actual_balancing_path_moment_bound p u hn hp hc hnorm hs hbal s hseg
  have hu0 := Real.sqrt_nonneg (∑ i,u i^2)
  have hn0 : (0 : ℝ) ≤ n := by positivity
  have hcpt (i : Fin n) : (23/24 : ℝ) ≤ tiltedMoment p (s • u) i := by
    have ha := (coordinate_abs_le_square_sum_sqrt (fun i => tiltedMoment p (s • u) i-1) i).trans hb
    have hs0 := mul_nonneg (mul_nonneg hn0 hseg.1) hu0
    have hneg := neg_abs_le (tiltedMoment p (s • u) i-1)
    nlinarith
  refine ⟨hcpt,?_⟩
  have hrec := reciprocal_deviation_euclidean_bound (tiltedMoment p (s • u))
    (fun i => by linarith [hcpt i])
  nlinarith

end CoefficientStability
