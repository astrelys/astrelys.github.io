import CoefficientStability.SourceCloneReference

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {m : ℕ}

theorem scalarPower_stable_general_degree (t : Fin m → ℝ) (d : ℕ) (hm : 0<m) (hd : 0<d)
    (htpos : ∀ i,0 < t i) : UpperHalfPlaneZeroFree (scalarPower t d) := by
  intro z hz
  have hdpos : (0 : ℝ)<d := by exact_mod_cast hd
  have him : 0 < ((MvPolynomial.eval₂Hom Complex.ofRealHom z) (scalarLinear t d)).im := by
    have he : ((MvPolynomial.eval₂Hom Complex.ofRealHom z) (scalarLinear t d)).im=
        ∑ i,t i/(d : ℝ)*(z i).im := by
      simp [scalarLinear,Complex.mul_im]
    rw [he]
    apply Finset.sum_pos'
    · intro i hi
      exact (mul_pos (div_pos (htpos i) hdpos) (hz i)).le
    · let i : Fin m := ⟨0,hm⟩
      exact ⟨i,Finset.mem_univ i,mul_pos (div_pos (htpos i) hdpos) (hz i)⟩
  have hne : (MvPolynomial.eval₂Hom Complex.ofRealHom z) (scalarLinear t d)≠0 := by
    intro he
    rw [he,Complex.zero_im] at him
    linarith
  change (MvPolynomial.eval₂Hom Complex.ofRealHom z) (scalarPower t d)≠0
  rw [scalarPower,map_pow]
  exact pow_ne_zero _ hne

theorem scalarPower_general_source_feasible (t : Fin m → ℝ) (d : ℕ) (hd : 0<d)
    (ht : (∑ i,t i)=d) (htpos : ∀ i,0 < t i) :
    (scalarPower t d).IsHomogeneous d ∧ MvPolynomial.eval (fun _ => 1) (scalarPower t d)=1 ∧
      UpperHalfPlaneZeroFree (scalarPower t d) ∧ (∀ g,0 ≤ (scalarPower t d).coeff g) ∧
      ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i (scalarPower t d))=t i := by
  have hm : 0<m := by
    by_contra hh
    have hm0 : m=0 := by omega
    subst m
    have hzero : (d : ℝ)=0 := by simpa only [Fin.sum_univ_zero] using ht.symm
    have hz : d=0 := by exact_mod_cast hzero
    omega
  exact ⟨scalarPower_homogeneous t d,eval_one_scalarPower t d hd ht,
    scalarPower_stable_general_degree t d hm hd htpos,scalarPower_coefficient_nonnegative t d (fun i => (htpos i).le),
    scalarPower_gradient t d hd ht⟩

end CoefficientStability
