import CoefficientStability.StablePolynomialCurve

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
variable {n : ℕ}

theorem not_stableLocalMin_of_curve_descent (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i)
    (hdesc : ∃ e : ℝ,0<e ∧ ∀ s : ℝ,0<s → s<e →
      fixedDegreeObjective (stableBoundaryCurve t s)<fixedDegreeObjective (fixedDegreeReference t)) :
    ¬IsLocalMinOn fixedDegreeObjective (stableCoefficientClass t) (fixedDegreeReference t) := by
  intro hf
  obtain ⟨ef,hef,hfeas⟩ := stableBoundaryCurve_feasible_near_zero t hn ht htpos
  let J : Set ℝ := Set.Ioo (-ef) ef
  have hmem : J⊆(stableBoundaryCurve t) ⁻¹' stableCoefficientClass t := by
    intro s hs
    exact hfeas s (abs_lt.mpr hs)
  have hz : (0 : ℝ)∈J := by constructor <;> linarith
  have hstart : IsLocalMinOn fixedDegreeObjective (stableCoefficientClass t) (stableBoundaryCurve t 0) := by
    simpa only [stableBoundaryCurve_zero] using hf
  have hcomp := hstart.comp_continuousOn hmem (stableBoundaryCurve_continuous t).continuousOn hz
  have hloc := hcomp.isLocalMin (isOpen_Ioo.mem_nhds hz)
  change ∀ᶠ s in 𝓝 (0 : ℝ),fixedDegreeObjective (stableBoundaryCurve t 0)≤
    fixedDegreeObjective (stableBoundaryCurve t s) at hloc
  obtain ⟨r,hr,hnear⟩ := Metric.eventually_nhds_iff.mp hloc
  obtain ⟨ed,hed,hdes⟩ := hdesc
  let s := min r ed/2
  have hs : 0<s := by dsimp [s];exact div_pos (lt_min hr hed) (by norm_num)
  have hsr : s<r := by have h := min_le_left r ed;dsimp [s];nlinarith [lt_min hr hed]
  have hsd : s<ed := by have h := min_le_right r ed;dsimp [s];nlinarith [lt_min hr hed]
  have hle := hnear (y := s) (by simpa [Real.dist_eq,abs_of_pos hs] using hsr)
  rw [stableBoundaryCurve_zero] at hle
  have hlt := hdes s hs hsd
  linarith

theorem stable_polynomial_negative_direction (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : scalarHessianLambda t<0) :
    ¬IsLocalMinOn fixedDegreeObjective (stableCoefficientClass t) (fixedDegreeReference t) := by
  obtain ⟨e,he,hdesc⟩ := polynomial_strict_descent_of_negative_quadratic (boundaryMixedPolynomial t)
    (boundaryMixedPolynomial_coeff_one t (by omega)) (boundaryMixedPolynomial_negative_coeff_two t hn ht htpos hl)
  apply not_stableLocalMin_of_curve_descent t hn ht htpos
  refine ⟨e,he,?_⟩
  intro s hs hse
  rw [← stableBoundaryCurve_zero t,stableBoundaryCurve_objective t (by omega) s,
    stableBoundaryCurve_objective t (by omega) 0]
  exact hdesc s hs hse

theorem stable_polynomial_boundary_direction (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : scalarHessianLambda t=0) :
    ¬IsLocalMinOn fixedDegreeObjective (stableCoefficientClass t) (fixedDegreeReference t) := by
  have hn3 : 3≤n := by
    by_contra h
    have he : n=2 := by omega
    subst n
    have hp := scalarHessian_dimension_two_positive t ht htpos
    rw [hl] at hp
    linarith
  obtain ⟨e,he,hdesc⟩ := polynomial_strict_descent_of_negative_cubic (boundaryMixedPolynomial t)
    (boundaryMixedPolynomial_coeff_one t (by omega))
    (boundaryMixedPolynomial_boundary_coeff_two t (by omega) ht htpos hl)
    (boundaryMixedPolynomial_boundary_coeff_three_neg t hn3 ht htpos hl)
  apply not_stableLocalMin_of_curve_descent t hn ht htpos
  refine ⟨e,he,?_⟩
  intro s hs hse
  rw [← stableBoundaryCurve_zero t,stableBoundaryCurve_objective t (by omega) s,
    stableBoundaryCurve_objective t (by omega) 0]
  exact hdesc s hs hse

theorem paper_stable_polynomial_local_criterion (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) :
    IsLocalMinOn fixedDegreeObjective (stableCoefficientClass t) (fixedDegreeReference t) ↔
      (∑ i,(t i-1)^2)<(n : ℝ)/((n : ℝ)-1) := by
  constructor
  · intro hmin
    apply (scalarHessianLambda_pos_iff_radius t hn ht).mp
    by_contra! hl
    rcases lt_or_eq_of_le hl with hneg | heq
    · exact stable_polynomial_negative_direction t hn ht htpos hneg hmin
    · exact stable_polynomial_boundary_direction t hn ht htpos heq hmin
  · exact paper_stable_topological_local_minimum t hn ht htpos

end CoefficientStability
