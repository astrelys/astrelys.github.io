import CoefficientStability.ActualBalancingRatioTransport
import CoefficientStability.FiniteMarginalProducts

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem source_nearbalanced_squarefree_pos (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hsmall : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|) < 1) :
    0 < p.coeff (squarefreeExponent n) := by
  have hcap := source_nearbalanced_capacity_manuscript_bound p hn hp hs hnorm hsmall
  have hbase : 0 < (1-(∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|))^n := pow_pos (by linarith) _
  exact (mul_pos (sourceVn_pos hn) (hbase.trans_le hcap)).trans_le
    (normalized_stable_gurvits_capacity_lower n p hp hs hnorm)

theorem actual_short_balancing_original_log_gap (p : MvPolynomial (Fin n) ℝ)
    (u : Fin n → ℝ) (hn : 3 ≤ n) (hp : p.IsHomogeneous n)
    (hc : ∀ g,0 ≤ p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) (hL : 0 < p.coeff (squarefreeExponent n))
    (hbal : ∀ i,tiltedMoment p u i=1)
    (hsmall : (n : ℝ)*Real.sqrt (∑ i,u i^2) ≤ 1/24)
    (hsq : (∑ i,u i^2) ≤ 1/(64*(n : ℝ)*(100000000*(n : ℝ)^8))) :
    actualTiltDeficit p 0/(8*(100000000*(n : ℝ)^8)) ≤ tiltLogRatio p (sourceVn n) 0 := by
  let B : ℝ := 100000000*(n : ℝ)^8
  have hn0 : (0 : ℝ)<n := by exact_mod_cast (show 0<n by omega)
  have hB : 0 < B := by dsimp [B];positivity
  have hδ : 0 ≤ actualTiltDeficit p u :=
    (actual_tilt_deficit_source_bounds p u (by omega) hp hc hnorm hs).2.2.1
  have hratio := actual_balancing_ratio_transport p u hn hp hc hnorm hs hL hbal hsmall
  have hgap := actual_balanced_endpoint_log_gap p u hn hp hc hnorm hs hbal
  have hd := actual_balancing_path_deficit_bound p u hn hp hc hnorm hs hsmall 0 ⟨le_rfl,by norm_num⟩
  simp only [zero_smul] at hd
  have hR : 16*(n : ℝ)*(∑ i,u i^2) ≤ 1/(4*B) := by
    have hh := mul_le_mul_of_nonneg_left hsq (by positivity : 0 ≤ 16*(n : ℝ))
    apply hh.trans_eq
    dsimp [B]
    field_simp
    ring
  have herror := mul_le_mul_of_nonneg_right hR hδ
  have hle := neg_abs_le (tiltLogRatio p (sourceVn n) 0-tiltLogRatio p (sourceVn n) u)
  have hscaled := (div_le_div_iff₀ (by positivity : 0 < 8*B) (by positivity : 0 < 4*B)).mpr
    (show actualTiltDeficit p 0*(4*B) ≤ actualTiltDeficit p u*(8*B) by nlinarith [mul_le_mul_of_nonneg_right hd hB.le])
  have he : actualTiltDeficit p u/(2*B)-1/(4*B)*actualTiltDeficit p u=actualTiltDeficit p u/(4*B) := by field_simp;ring
  change actualTiltDeficit p u/(2*B) ≤ _ at hgap
  change actualTiltDeficit p 0/(8*B) ≤ _
  have hcombined : actualTiltDeficit p u/(4*B) ≤ tiltLogRatio p (sourceVn n) 0 := by
    rw [← he]
    linarith
  exact hscaled.trans hcombined

theorem actual_short_balancing_coefficient_gap (p : MvPolynomial (Fin n) ℝ)
    (u : Fin n → ℝ) (hn : 3 ≤ n) (hp : p.IsHomogeneous n)
    (hc : ∀ g,0 ≤ p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) (hL : 0 < p.coeff (squarefreeExponent n))
    (hbal : ∀ i,tiltedMoment p u i=1)
    (hsmall : (n : ℝ)*Real.sqrt (∑ i,u i^2) ≤ 1/24)
    (hsq : (∑ i,u i^2) ≤ 1/(64*(n : ℝ)*(100000000*(n : ℝ)^8)))
    (hmarg : (1/2 : ℝ) ≤ ∏ i,tiltedMoment p 0 i) :
    sourceVn n/(2000000000*(n : ℝ)^8)*actualTiltDeficit p 0 ≤
      p.coeff (squarefreeExponent n)-sourceVn n*(∏ i,tiltedMoment p 0 i) := by
  let B : ℝ := 100000000*(n : ℝ)^8
  let A : ℝ := sourceVn n*(∏ i,tiltedMoment p 0 i)
  have hV := sourceVn_pos (by omega : 0<n)
  have hB : 0 < B := by dsimp [B];positivity
  have hA : 0 < A := mul_pos hV (lt_of_lt_of_le (by norm_num) hmarg)
  have hgap := actual_short_balancing_original_log_gap p u hn hp hc hnorm hs hL hbal hsmall hsq
  have he : tiltLogRatio p (sourceVn n) 0=Real.log (p.coeff (squarefreeExponent n)/A) := by
    rw [tiltLogRatio,tiltedPolynomial_zero p hnorm]
  rw [he] at hgap
  have hlog := Real.log_le_sub_one_of_pos (div_pos hL hA)
  have hdiv : actualTiltDeficit p 0/(8*B) ≤ p.coeff (squarefreeExponent n)/A-1 := hgap.trans hlog
  have hmul := mul_le_mul_of_nonneg_right hdiv hA.le
  have heq : (p.coeff (squarefreeExponent n)/A-1)*A=p.coeff (squarefreeExponent n)-A := by field_simp
  rw [heq] at hmul
  have hδ : 0 ≤ actualTiltDeficit p 0 := (actual_tilt_deficit_source_bounds p 0 (by omega) hp hc hnorm hs).2.2.1
  have hAb : sourceVn n/2 ≤ A := by dsimp [A];nlinarith [mul_le_mul_of_nonneg_left hmarg hV.le]
  have hlower : sourceVn n/(2000000000*(n : ℝ)^8)*actualTiltDeficit p 0 ≤ actualTiltDeficit p 0/(8*B)*A := by
    have hh := mul_le_mul_of_nonneg_left hAb (div_nonneg hδ (by positivity : 0 ≤ 8*B))
    apply le_trans _ hh
    dsimp [B]
    field_simp
    nlinarith [mul_nonneg hV.le hδ]
  exact hlower.trans hmul

end CoefficientStability
