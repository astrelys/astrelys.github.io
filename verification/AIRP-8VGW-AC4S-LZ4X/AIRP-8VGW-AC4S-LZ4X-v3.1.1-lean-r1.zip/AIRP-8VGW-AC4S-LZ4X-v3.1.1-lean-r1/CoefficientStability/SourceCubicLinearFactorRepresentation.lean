import CoefficientStability.SourceCubicLinearRepresentationPullback
import CoefficientStability.SourceCubicCoordinateMatrices

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

theorem source_cubic_actual_linear_factors_definite_representation
    (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ) (ht : ∑ i,t i=3)
    (a b c α β : ℝ)
    (hfactor : ∀ s x y : ℝ,MvPolynomial.eval (sourceDepressedCubicCoordinates t s x y) p=
      (s+a*(α*x+β*y))*(s+b*(α*x+β*y))*(s+c*(α*x+β*y))) :
    ∃ A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ,
      (∀ i,(A i).IsHermitian) ∧ (∑ i,A i).PosDef ∧ p=realDeterminantPolynomial A := by
  let roots : Fin 3 → ℝ := ![a,b,c]
  let B : Matrix (Fin 3) (Fin 3) ℝ := fun i j => (![1,α*roots j,β*roots j] : Fin 3 → ℝ) i
  let A := sourcePermanentDiagonalTuple B
  let q := matrixSubstitution (sourceDepressedCoordinateMatrix t) p
  have hA : ∀ i,(A i).IsHermitian := by
    intro i
    exact Matrix.isHermitian_diagonal_iff.mpr (fun j => by simp [IsSelfAdjoint])
  have hA0 : A 0=1 := by
    apply Matrix.ext
    intro i j
    by_cases hij : i=j
    · subst j
      simp [A,sourcePermanentDiagonalTuple,B]
    · simp [A,sourcePermanentDiagonalTuple,Matrix.diagonal_apply,Matrix.one_apply,hij]
  have hpoly : q=realDeterminantPolynomial A := by
    rw [source_cubic_diagonal_product_polynomial]
    apply MvPolynomial.funext
    intro x
    change MvPolynomial.eval x (matrixSubstitution (sourceDepressedCoordinateMatrix t) p)=_
    rw [matrixSubstitution_eval,source_depressed_coordinate_matrix_actual,hfactor]
    norm_num [sourceCubicProductPolynomial,B,roots,Fin.sum_univ_succ,Fin.prod_univ_succ]
    ring
  have hD : (sourceDepressedRecoveryMatrix t).mulVec (fun _ => 1)=![1,0,0] := by
    rw [source_depressed_recovery_matrix_actual]
    simp only [mul_one,ht]
    norm_num
  apply source_cubic_actual_definite_representation_linear_recovery p q (sourceDepressedRecoveryMatrix t)
    (fun x => by rw [show q=matrixSubstitution (sourceDepressedCoordinateMatrix t) p from rfl,
      matrixSubstitution_eval,source_depressed_matrix_entire_recovery t ht]) A hA hpoly
  rw [hD,source_three_actual_pencil_sum]
  change ((1 : ℂ) • A 0+(0 : ℂ) • A 1+(0 : ℂ) • A 2).PosDef
  simp only [one_smul,zero_smul,add_zero,hA0]
  exact Matrix.PosDef.one

end CoefficientStability
