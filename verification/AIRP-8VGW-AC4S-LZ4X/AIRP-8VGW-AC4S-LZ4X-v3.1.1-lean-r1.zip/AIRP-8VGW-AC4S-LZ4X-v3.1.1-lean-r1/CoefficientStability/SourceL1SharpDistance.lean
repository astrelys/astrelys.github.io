import CoefficientStability.SourceL1FixedHeightProjection
import Mathlib.Topology.Order.IntermediateValue

noncomputable section
open scoped Topology
namespace CoefficientStability
set_option maxHeartbeats 1600000

theorem source_cubic_project_to_zero_curve (d h : ℝ) (hd : 0 < d) (hd3 : d < 1/3)
    (hl : -1/2 ≤ h) (hh : h < 1/2) (hE : sourceCubicDistance d h < 1)
    (hH : sourceCubicH d h ≤ 0) :
    ∃ D : ℝ,0 < D ∧ D ≤ d ∧ sourceCubicLowerRoot D=h ∧
      sourceCubicCurveDistance D ≤ sourceCubicDistance d h ∧
      (sourceCubicDistance d h=sourceCubicCurveDistance D ↔ d=D) := by
  have hbelow := source_cubic_nonpositive_gap_below_root d h hd hd3 hh hH
  have habove := source_cubic_small_distance_height_lower d h hd hd3 hl hE
  have hcont : ContinuousOn sourceCubicLowerRoot (Set.Icc (0 : ℝ) d) :=
    source_cubic_lower_root_continuousOn.mono (fun x hx => ⟨hx.1,hx.2.trans hd3.le⟩)
  have hbetween : h ∈ Set.Icc (sourceCubicLowerRoot 0) (sourceCubicLowerRoot d) :=
    ⟨by rw [source_cubic_lower_root_endpoints.1];exact habove.le,hbelow⟩
  obtain ⟨D,hDm,hDh⟩ := intermediate_value_Icc hd.le hcont hbetween
  have hDpos : 0 < D := by
    by_contra hn
    have hzero : D=0 := by linarith [hDm.1]
    rw [hzero,source_cubic_lower_root_endpoints.1] at hDh
    linarith
  have hD3 : D < 1/3 := lt_of_le_of_lt hDm.2 hd3
  have hheight : h ≤ 3*D/2 := by
    rw [← hDh]
    exact source_cubic_lower_root_upper_bound D hDpos.le hD3.le
  have hm := source_cubic_distance_fixed_height_strictMonoOn D d h hDpos.le hd3 hl hheight
  have hFD : sourceCubicCurveDistance D=sourceCubicDistance D h := by unfold sourceCubicCurveDistance;rw [hDh]
  refine ⟨D,hDpos,hDm.2,hDh,?_,?_⟩
  · rw [hFD]
    exact hm.monotoneOn ⟨le_rfl,hDm.2⟩ ⟨hDm.2,le_rfl⟩ hDm.2
  · constructor
    · intro he
      apply hm.injOn ⟨hDm.2,le_rfl⟩ ⟨le_rfl,hDm.2⟩
      exact he.trans hFD
    · intro he
      simpa only [he] using hFD.symm

theorem source_cubic_sharp_distance_on_strip (d h : ℝ) (hd : 0 < d) (hd3 : d < 1/3)
    (hl : -1/2 ≤ h) (hh : h < 1/2) (hE : sourceCubicDistance d h < 1)
    (hH : sourceCubicH d h ≤ 0) :
    sourceCubicEpsilon0 ≤ sourceCubicDistance d h ∧
      (sourceCubicDistance d h=sourceCubicEpsilon0 ↔ d=sourceCubicDStar ∧ h=0) := by
  obtain ⟨D,hDpos,hDd,hDh,hproj,hprojeq⟩ := source_cubic_project_to_zero_curve d h hd hd3 hl hh hE hH
  have hD3 : D ≤ 1/3 := hDd.trans hd3.le
  obtain ⟨hmin,hminEq⟩ := source_cubic_zero_curve_distance_minimum D hDpos.le hD3
  refine ⟨hmin.trans hproj,?_⟩
  constructor
  · intro he
    have hFeq : sourceCubicCurveDistance D=sourceCubicEpsilon0 := le_antisymm (hproj.trans he.le) hmin
    have hDstar := hminEq.mp hFeq
    have hdD := hprojeq.mp (he.trans hFeq.symm)
    refine ⟨hdD.trans hDstar,?_⟩
    rw [← hDh,hDstar,source_cubic_lower_root_dstar]
  · rintro ⟨hdstar,hhzero⟩
    rw [hdstar,hhzero,source_cubic_dstar_distance_exact]

theorem source_original_l1_chart_sharp_distance (u v : ℝ) (hu : 0 < u) (hv : 0 < v) (huv : u+v < 1)
    (hH : sourceCubicH (sourceL1ChartD u v) (sourceL1ChartHeight u v) ≤ 0) :
    sourceCubicEpsilon0 ≤ sourceCubicDistance (sourceL1ChartD u v) (sourceL1ChartHeight u v) ∧
      (sourceCubicDistance (sourceL1ChartD u v) (sourceL1ChartHeight u v)=sourceCubicEpsilon0 ↔
        sourceL1ChartD u v=sourceCubicDStar ∧ sourceL1ChartHeight u v=0) := by
  by_cases hE : sourceCubicDistance (sourceL1ChartD u v) (sourceL1ChartHeight u v) < 1
  · obtain ⟨hd,hd3,hhabs⟩ := source_l1_chart_small_distance_domain u v hu hv huv hE
    obtain ⟨hhlo,hhhi⟩ := abs_lt.mp hhabs
    exact source_cubic_sharp_distance_on_strip (sourceL1ChartD u v) (sourceL1ChartHeight u v) hd hd3 (by linarith) hhhi hE hH
  · have hstrict : sourceCubicEpsilon0 < sourceCubicDistance (sourceL1ChartD u v) (sourceL1ChartHeight u v) :=
      lt_of_lt_of_le source_cubic_epsilon_bounds.2 (le_of_not_gt hE)
    refine ⟨hstrict.le,?_⟩
    constructor
    · intro he
      exact False.elim ((ne_of_lt hstrict) he.symm)
    · rintro ⟨hdstar,hhzero⟩
      rw [hdstar,hhzero,source_cubic_dstar_distance_exact]

end CoefficientStability
