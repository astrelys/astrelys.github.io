import CoefficientStability.SourceCubicBlockEmbedding

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 3000000
set_option backward.isDefEq.respectTransparency false

theorem source_complex_two_centered_trace_square (z : ℂ) (V : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix.trace ((z • 1+V)^2)=2*z^2+2*z*Matrix.trace V+Matrix.trace (V^2) := by
  norm_num [Matrix.trace,Matrix.mul_apply,Matrix.add_apply,Matrix.smul_apply,Matrix.one_apply,Fin.sum_univ_succ,pow_succ,smul_eq_mul] <;> ring

theorem source_complex_two_centered_trace_cube (z : ℂ) (V : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix.trace ((z • 1+V)^3)=2*z^3+3*z^2*Matrix.trace V+3*z*Matrix.trace (V^2)+Matrix.trace (V^3) := by
  norm_num [Matrix.trace,Matrix.mul_apply,Matrix.add_apply,Matrix.smul_apply,Matrix.one_apply,Fin.sum_univ_succ,pow_succ,smul_eq_mul] <;> ring

theorem source_two_centered_trace_square (b : ℝ) (V : Matrix (Fin 2) (Fin 2) ℂ) (ht : Matrix.trace V=0) :
    Matrix.trace ((sourceTwoCentered b V)^2)=(b : ℂ)^2/2+Matrix.trace (V^2) := by
  rw [sourceTwoCentered,source_complex_two_centered_trace_square,ht]
  ring

theorem source_two_centered_trace_cube (b : ℝ) (V : Matrix (Fin 2) (Fin 2) ℂ) (ht : Matrix.trace V=0) :
    Matrix.trace ((sourceTwoCentered b V)^3)=(b : ℂ)^3/4+(3*(b : ℂ)/2)*Matrix.trace (V^2) := by
  rw [sourceTwoCentered,source_complex_two_centered_trace_cube,ht,source_complex_two_traceless_cube V ht]
  ring

theorem source_complex_cubic_block_summand_difference (a b : ℝ)
    (V : Matrix (Fin 2) (Fin 2) ℂ) (ht : Matrix.trace V=0) :
    sourceCubicMatrixSummand (a+b) (sourceOneTwoBlock a (sourceTwoCentered b V))=
      sourceCubicMatrixSummand (a+b) (sourceOneTwoBlock a (sourceTwoCentered b 0))+
        (((1-2*a)/2 : ℝ) : ℂ)*Matrix.trace (V*V) := by
  unfold sourceCubicMatrixSummand
  rw [source_one_two_block_trace_cube a (sourceTwoCentered b V),source_one_two_block_trace_square a (sourceTwoCentered b V),
    source_one_two_block_trace_cube a (sourceTwoCentered b 0),source_one_two_block_trace_square a (sourceTwoCentered b 0)]
  rw [source_two_centered_trace_cube b V ht,source_two_centered_trace_square b V ht,
    source_two_centered_trace_cube b 0 (by simp),source_two_centered_trace_square b 0 (by simp),pow_two V]
  simp only [zero_pow (by decide : 2≠0),Matrix.trace_zero,mul_zero,add_zero]
  push_cast
  ring

theorem source_real_cubic_block_summand_difference (a b : ℝ)
    (V : Matrix (Fin 2) (Fin 2) ℂ) (ht : Matrix.trace V=0) :
    (sourceCubicMatrixSummand (a+b) (sourceOneTwoBlock a (sourceTwoCentered b V))).re=
      (sourceCubicMatrixSummand (a+b) (sourceOneTwoBlock a (sourceTwoCentered b 0))).re+
        (1-2*a)*sourceTwoTraceQuadratic V := by
  have h := congrArg Complex.re (source_complex_cubic_block_summand_difference a b V ht)
  simp only [Complex.add_re,Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero] at h
  unfold sourceTwoTraceQuadratic
  nlinarith [h]

def sourceCubicBlockTuple (a b : Fin 3 → ℝ) (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) :
    Fin 3 → Matrix (Fin 3) (Fin 3) ℂ := fun i => sourceOneTwoBlock (a i) (sourceTwoCentered (b i) (V i))

theorem source_cubic_block_tuple_traces (a b : Fin 3 → ℝ) (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (ht : ∀ i,Matrix.trace (V i)=0) :
    ∀ i,Matrix.trace (sourceCubicBlockTuple a b V i)=((a i+b i : ℝ) : ℂ) := by
  intro i
  change Matrix.trace (sourceOneTwoBlock (a i) (sourceTwoCentered (b i) (V i)))=_
  rw [source_one_two_block_trace,source_two_centered_trace (b i) (V i) (ht i)]
  push_cast
  rfl

theorem source_cubic_block_tuple_objective_difference (a b : Fin 3 → ℝ)
    (V W : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (htV : ∀ i,Matrix.trace (V i)=0) (htW : ∀ i,Matrix.trace (W i)=0)
    (hsV : (∑ i,sourceCubicBlockTuple a b V i)=1) (hsW : (∑ i,sourceCubicBlockTuple a b W i)=1) :
    hermitianMixedObjective (sourceCubicBlockTuple a b W)-hermitianMixedObjective (sourceCubicBlockTuple a b V)=
      ∑ i,(1-2*a i)*(sourceTwoTraceQuadratic (W i)-sourceTwoTraceQuadratic (V i)) := by
  let t : Fin 3 → ℝ := fun i => a i+b i
  have hV := congrArg Complex.re (source_cubic_mixed_trace_summands t (sourceCubicBlockTuple a b V) hsV
    (source_cubic_block_tuple_traces a b V htV))
  have hW := congrArg Complex.re (source_cubic_mixed_trace_summands t (sourceCubicBlockTuple a b W) hsW
    (source_cubic_block_tuple_traces a b W htW))
  simp only [Complex.add_re,Complex.re_sum] at hV hW
  calc
    hermitianMixedObjective (sourceCubicBlockTuple a b W)-hermitianMixedObjective (sourceCubicBlockTuple a b V)=
      (∑ i,(sourceCubicMatrixSummand (t i) (sourceCubicBlockTuple a b W i)).re)-
        ∑ i,(sourceCubicMatrixSummand (t i) (sourceCubicBlockTuple a b V i)).re := by
      unfold hermitianMixedObjective
      linarith
    _=∑ i,((sourceCubicMatrixSummand (t i) (sourceCubicBlockTuple a b W i)).re-
      (sourceCubicMatrixSummand (t i) (sourceCubicBlockTuple a b V i)).re) := by rw [Finset.sum_sub_distrib]
    _=_ := by
      apply Finset.sum_congr rfl
      intro i hi
      change (sourceCubicMatrixSummand (a i+b i) (sourceOneTwoBlock (a i) (sourceTwoCentered (b i) (W i)))).re-
        (sourceCubicMatrixSummand (a i+b i) (sourceOneTwoBlock (a i) (sourceTwoCentered (b i) (V i)))).re=_
      rw [source_real_cubic_block_summand_difference (a i) (b i) (W i) (htW i),
        source_real_cubic_block_summand_difference (a i) (b i) (V i) (htV i)]
      ring

end CoefficientStability
