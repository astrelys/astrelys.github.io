import CoefficientStability.BalancedThresholdConstants

noncomputable section
namespace CoefficientStability
variable {n : ℕ}

theorem sourceSmallExcessThreshold_lower (hn : 3≤n) :
    1/(20480000*(n : ℝ)^7)≤sourceSmallExcessThreshold n := by
  have hn0 : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
  have h := div_le_div_of_nonneg_right (sourceMixingRadius_lower n hn)
    (by positivity : 0≤160000*(n : ℝ)^3)
  apply le_trans _ h
  field_simp <;> norm_num

theorem balanced_gap_from_small_branch (hn : 3≤n) (τ δ : ℝ) (hτ0 : 0≤τ)
    (hδ : δ≤((n : ℝ)-1)/2)
    (hsmall : τ≤sourceSmallExcessThreshold n → δ≤128*(n : ℝ)*τ) :
    δ/(100000000*(n : ℝ)^8)≤τ := by
  have hn1 : (1 : ℝ)≤n := by exact_mod_cast (by omega : 1≤n)
  have hn0 : (0 : ℝ)<n := by linarith
  apply (div_le_iff₀ (by positivity : 0<100000000*(n : ℝ)^8)).mpr
  by_cases hs : τ≤sourceSmallExcessThreshold n
  · have hp8 : (n : ℝ)≤(n : ℝ)^8 := by
      simpa only [pow_one] using pow_le_pow_right₀ hn1 (by omega : 1≤8)
    have hcoeff : 128*(n : ℝ)≤100000000*(n : ℝ)^8 := by nlinarith
    exact (hsmall hs).trans (by nlinarith [mul_le_mul_of_nonneg_right hcoeff hτ0])
  · have ht : 1/(20480000*(n : ℝ)^7)≤τ :=
      (sourceSmallExcessThreshold_lower hn).trans (le_of_lt (lt_of_not_ge hs))
    have hm := (div_le_iff₀ (by positivity : 0<20480000*(n : ℝ)^7)).mp ht
    have hmn := mul_le_mul_of_nonneg_left hm hn0.le
    nlinarith [mul_nonneg (pow_nonneg hn0.le 8) hτ0]

end CoefficientStability
