import CoefficientStability.HermitianDimension
import Mathlib.Data.Sym.Card

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}
abbrev RealSquare (n : ℕ) := Matrix (Fin n) (Fin n) ℝ

instance symmetricFinite (n : ℕ) : FiniteDimensional ℝ (selfAdjoint (RealSquare n)) :=
  FiniteDimensional.of_injective (selfAdjoint.submodule ℝ (RealSquare n)).subtype Subtype.val_injective

def symmetricCoordinates (n : ℕ) : selfAdjoint (RealSquare n) ≃ₗ[ℝ] (Sym2 (Fin n) → ℝ) where
  toFun A := Sym2.lift ⟨fun i j => A.val i j,by
    intro i j
    have h := congrArg (fun B : RealSquare n => B j i) A.property
    exact h⟩
  invFun f := ⟨fun i j => f s(i,j),by
    change star (show RealSquare n from fun i j => f s(i,j))=(fun i j => f s(i,j))
    apply Matrix.ext
    intro i j
    change f s(j,i)=f s(i,j)
    rw [Sym2.eq_swap]⟩
  left_inv A := by apply Subtype.ext;apply Matrix.ext;intro i j;rfl
  right_inv f := by funext p;induction p using Sym2.ind; rfl
  map_add' A B := by funext p;induction p using Sym2.ind;rfl
  map_smul' a A := by funext p;induction p using Sym2.ind;rfl

theorem symmetric_finrank (n : ℕ) : Module.finrank ℝ (selfAdjoint (RealSquare n))=n*(n+1)/2 := by
  rw [(symmetricCoordinates n).finrank_eq,Module.finrank_pi,Sym2.card,Fintype.card_fin,
    Nat.choose_two_right]
  simp only [Nat.add_sub_cancel]
  rw [Nat.mul_comm (n+1) n]

def symmetricTrace (n : ℕ) : selfAdjoint (RealSquare n) →ₗ[ℝ] ℝ where
  toFun A := Matrix.trace A.val
  map_add' A B := by simp [Matrix.trace_add]
  map_smul' a A := by simp [Matrix.trace_smul]

def tracelessSymmetric (n : ℕ) : Submodule ℝ (selfAdjoint (RealSquare n)) := (symmetricTrace n).ker

theorem symmetricTrace_ne_zero (hn : 0<n) : symmetricTrace n≠0 := by
  intro he
  let one : selfAdjoint (RealSquare n) := ⟨1,IsSelfAdjoint.one _⟩
  have h := congrArg (fun f : selfAdjoint (RealSquare n) →ₗ[ℝ] ℝ => f one) he
  have hn' : (0 : ℝ)<n := by exact_mod_cast hn
  simp [symmetricTrace,one,Matrix.trace_one] at h
  linarith

theorem tracelessSymmetric_finrank (hn : 0<n) :
    Module.finrank ℝ (tracelessSymmetric n)=n*(n+1)/2-1 := by
  have h := Module.Dual.finrank_ker_add_one_of_ne_zero (symmetricTrace_ne_zero hn)
  rw [symmetric_finrank] at h
  change Module.finrank ℝ (tracelessSymmetric n)+1=n*(n+1)/2 at h
  omega

end CoefficientStability
