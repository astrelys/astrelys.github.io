import CoefficientStability.SpectralConeShift

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem actual_linear_factor_root_zero (P : Polynomial ℝ) (roots : Multiset ℝ)
    (hf : P=(roots.map (fun r => Polynomial.X+Polynomial.C r)).prod)
    (r : ℝ) (hr : r∈roots) : P.eval (-r)=0 := by
  rw [hf,Polynomial.eval_multiset_prod]
  apply Multiset.prod_eq_zero_iff.mpr
  apply Multiset.mem_map.mpr
  refine ⟨Polynomial.X+Polynomial.C r,Multiset.mem_map.mpr ⟨r,hr,rfl⟩,?_⟩
  simp

theorem nonnegative_input_minimal_spectral_boundary
    (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (x : Fin n → ℝ) (hx : ∀ i,0≤x i) :
    ∃ r : ℝ,0≤r ∧ MvPolynomial.eval (fun i => x i-r) p=0 ∧
      (fun i => x i-r)∈closure (positiveSpectralCone p N) := by
  classical
  obtain ⟨roots,hcard,hr,hfactor⟩ := nonnegative_input_real_factors p N hp hs hnorm x hx
  obtain ⟨f,henum⟩ := real_multiset_fin_enumeration roots
  have hcardpos : 0<roots.card := by omega
  letI : Nonempty (Fin roots.card) := ⟨⟨0,hcardpos⟩⟩
  obtain ⟨i,hi,hmin⟩ := Finset.exists_min_image Finset.univ f Finset.univ_nonempty
  let r : ℝ := f i
  have hrmem : r∈roots := by rw [← henum];simp [r]
  have hminroot : ∀ s∈roots,r≤s := by
    intro s hsmem
    rw [← henum] at hsmem
    have hsex : ∃ j,f j=s := by simpa only [Multiset.mem_coe,List.mem_ofFn] using hsmem
    obtain ⟨j,rfl⟩ := hsex
    exact hmin j (Finset.mem_univ j)
  have hzero := actual_linear_factor_root_zero (lineRestriction p x) roots hfactor r hrmem
  rw [eval_lineRestriction_real] at hzero
  have hvec : (fun j => -r+x j)=(fun j => x j-r) := by funext j;ring
  rw [hvec] at hzero
  refine ⟨r,hr r hrmem,hzero,?_⟩
  apply nonnegative_spectral_factors_mem_closure p N (fun j => x j-r)
    (roots.map (fun s => s-r)) (by simpa only [Multiset.card_map] using hcard)
  · intro s hsmem
    obtain ⟨t,ht,rfl⟩ := Multiset.mem_map.mp hsmem
    exact sub_nonneg.mpr (hminroot t ht)
  · simpa only [sub_eq_add_neg] using lineRestriction_shift_factors p x roots hfactor (-r)

end CoefficientStability
