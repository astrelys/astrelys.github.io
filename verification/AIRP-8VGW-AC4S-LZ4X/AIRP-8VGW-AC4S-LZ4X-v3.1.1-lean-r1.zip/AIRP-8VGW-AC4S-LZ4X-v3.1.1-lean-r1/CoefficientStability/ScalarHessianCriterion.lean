import CoefficientStability.ScalarHessianGeometry

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem sumSquares_pos_of_ne_zero (z : Fin n → ℝ) (hz : z≠0) : 0<∑ i,z i^2 := by
  have hex : ∃ i,z i≠0 := by
    by_contra! h
    apply hz
    funext i
    exact h i
  obtain ⟨i,hi⟩ := hex
  have h := Finset.single_le_sum (fun j (_ : j∈(Finset.univ : Finset (Fin n))) => sq_nonneg (z j)) (Finset.mem_univ i)
  exact lt_of_lt_of_le (sq_pos_of_ne_zero hi) h

theorem projectedOnes_ne_zero_of_lambda_nonpos (t : Fin n → ℝ) (hn : 0<n)
    (ht : ∑ i,t i=n) (hl : scalarHessianLambda t≤0) : projectedOnes t≠0 := by
  intro hz
  have h := projectedOnes_normSq t hn ht
  rw [hz] at h
  simp at h
  linarith

theorem scalarHessian_positive_iff (t : Fin n → ℝ) (hn : 0<n) (ht : ∑ i,t i=n) :
    (∀ z : Fin n → ℝ,(∑ i,t i*z i)=0 → z≠0 → 0<scalarHessianForm z) ↔
      0<scalarHessianLambda t := by
  constructor
  · intro h
    by_contra! hl
    have hp := h (projectedOnes t) (projectedOnes_dot_t t hn ht)
      (projectedOnes_ne_zero_of_lambda_nonpos t hn ht hl)
    rw [scalarHessianForm_projectedOnes t hn ht] at hp
    have hq := mul_nonpos_of_nonpos_of_nonneg hl (by linarith : 0≤1-scalarHessianLambda t)
    linarith
  · intro hl z hz hzne
    have h := scalarHessianForm_lower t z hn ht hz
    have hp := mul_pos hl (sumSquares_pos_of_ne_zero z hzne)
    exact lt_of_lt_of_le hp h

theorem marginal_spread_identity (t : Fin n → ℝ) (ht : ∑ i,t i=n) :
    marginalNormSq t=(n : ℝ)+∑ i,(t i-1)^2 := by
  have he : (∑ i,(t i-1)^2)=(∑ i,t i^2)-2*(∑ i,t i)+(n : ℝ) := by
    calc
      _ = ∑ i : Fin n,(t i^2-2*t i+1) := by
        apply Finset.sum_congr rfl
        intro i hi
        ring
      _ = _ := by
        rw [Finset.sum_add_distrib,Finset.sum_sub_distrib]
        simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,mul_one,← Finset.mul_sum]
  rw [he,ht]
  unfold marginalNormSq
  ring

theorem scalarHessianLambda_pos_iff_radius (t : Fin n → ℝ) (hn : 2≤n) (ht : ∑ i,t i=n) :
    0<scalarHessianLambda t ↔ (∑ i,(t i-1)^2)<(n : ℝ)/((n : ℝ)-1) := by
  have hT := marginalNormSq_pos t (by omega) ht
  have hn' : (2 : ℝ)≤n := by exact_mod_cast hn
  have hn1 : (0 : ℝ)<(n : ℝ)-1 := by linarith
  change 0<(n : ℝ)^2/marginalNormSq t-((n : ℝ)-1) ↔ _
  rw [sub_pos,lt_div_iff₀ hT,lt_div_iff₀ hn1]
  have he := marginal_spread_identity t ht
  constructor <;> intro h <;> nlinarith

theorem paper_scalar_form_positive_iff_radius (t : Fin n → ℝ) (hn : 2≤n) (ht : ∑ i,t i=n) :
    (∀ z : Fin n → ℝ,(∑ i,t i*z i)=0 → z≠0 → 0<scalarHessianForm z) ↔
      (∑ i,(t i-1)^2)<(n : ℝ)/((n : ℝ)-1) :=
  (scalarHessian_positive_iff t (by omega) ht).trans (scalarHessianLambda_pos_iff_radius t hn ht)

theorem paper_scalar_form_negative_direction (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (hl : scalarHessianLambda t<0) :
    ∃ z : Fin n → ℝ,(∑ i,t i*z i)=0 ∧ z≠0 ∧ scalarHessianForm z<0 := by
  refine ⟨projectedOnes t,projectedOnes_dot_t t (by omega) ht,
    projectedOnes_ne_zero_of_lambda_nonpos t (by omega) ht hl.le,?_⟩
  rw [scalarHessianForm_projectedOnes t (by omega) ht]
  exact mul_neg_of_neg_of_pos hl (by linarith)

theorem paper_scalar_form_boundary_vector (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : scalarHessianLambda t=0) :
    (∑ i,t i*projectedOnes t i)=0 ∧ (∑ i,projectedOnes t i)=1 ∧
    (∑ i,(projectedOnes t i)^2)=1 ∧ scalarHessianForm (projectedOnes t)=0 ∧
    ∀ i,projectedOnes t i<1 := by
  refine ⟨projectedOnes_dot_t t (by omega) ht,?_,?_,?_,?_⟩
  · simpa only [hl,sub_zero] using projectedOnes_sum t ht
  · simpa only [hl,sub_zero] using projectedOnes_normSq t (by omega) ht
  · simp only [scalarHessianForm_projectedOnes t (by omega) ht,hl,zero_mul]
  · intro i
    have hn' : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
    have hp := mul_pos (div_pos hn' (marginalNormSq_pos t (by omega) ht)) (htpos i)
    unfold projectedOnes
    linarith

theorem scalarHessian_dimension_two_positive (t : Fin 2 → ℝ)
    (ht : ∑ i,t i=2) (htpos : ∀ i,0<t i) : 0<scalarHessianLambda t := by
  apply (scalarHessianLambda_pos_iff_radius t (by decide) ht).mpr
  have ht' : t 0+t 1=2 := by simpa [Fin.sum_univ_two] using ht
  have hp := mul_pos (htpos 0) (htpos 1)
  simp only [Fin.sum_univ_two]
  norm_num
  nlinarith

end CoefficientStability
