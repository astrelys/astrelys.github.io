import CoefficientStability.PolynomialPartialChain

noncomputable section
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def partialReverse (i : Fin n) (p : MvPolynomial (Fin n) ℝ) : MvPolynomial (Fin n) ℝ :=
  (coordinatePolynomial i p).reverse.eval₂ (RingHom.id _) (-MvPolynomial.X i)

theorem partialReverse_complex_eval (p : MvPolynomial (Fin n) ℝ) (i : Fin n) (z : Fin n → ℂ) :
    MvPolynomial.eval₂ Complex.ofRealHom z (partialReverse i p)=
      (coordinatePolynomial i p).reverse.eval₂ (MvPolynomial.eval₂Hom Complex.ofRealHom z) (-z i) := by
  unfold partialReverse
  change (MvPolynomial.eval₂Hom Complex.ofRealHom z) (Polynomial.eval₂ _ _ _)=_
  rw [Polynomial.hom_eval₂]
  simp only [RingHom.comp_id]
  congr 1
  change (MvPolynomial.eval₂Hom Complex.ofRealHom z) (-MvPolynomial.X i)=_
  rw [map_neg]
  simp

theorem negative_inverse_im_pos (z : ℂ) (hz : 0<z.im) : 0<(-z)⁻¹.im := by
  have hzne : z≠0 := by intro h; simp [h] at hz
  rw [Complex.inv_im]
  simp only [Complex.neg_im,neg_neg]
  exact div_pos hz (Complex.normSq_pos.mpr (neg_ne_zero.mpr hzne))

theorem stable_partialReverse (p : MvPolynomial (Fin n) ℝ) (hp : UpperHalfPlaneZeroFree p)
    (i : Fin n) : UpperHalfPlaneZeroFree (partialReverse i p) := by
  classical
  intro z hz
  rw [partialReverse_complex_eval]
  let x : ℂ := (-z i)⁻¹
  have hzi : z i≠0 := by
    intro h
    have hh := hz i
    simp [h] at hh
  have hx : x≠0 := inv_ne_zero (neg_ne_zero.mpr hzi)
  letI : Invertible x := invertibleOfNonzero hx
  have h := Polynomial.eval₂_reverse_eq_zero_iff (MvPolynomial.eval₂Hom Complex.ofRealHom z) x (coordinatePolynomial i p)
  have hxinv : ⅟x= -z i := by simp [invOf_eq_inv,x]
  rw [hxinv,coordinatePolynomial_complex_eval] at h
  have hlegal : ∀ j,0<((Function.update z i x) j).im := by
    intro j
    by_cases hji : j=i
    · subst j
      simp only [Function.update_self]
      exact negative_inverse_im_pos (z i) (hz i)
    · simpa only [Function.update_of_ne hji] using hz j
  exact fun hzero => hp _ hlegal (h.mp hzero)

theorem partialReverse_top_partial (p : MvPolynomial (Fin n) ℝ) (i : Fin n) :
    let d := (coordinatePolynomial i p).natDegree
    (pderiv i)^[d] (partialReverse i p)=
      (-1 : MvPolynomial (Fin n) ℝ)^d*(d.factorial : MvPolynomial (Fin n) ℝ)*
        coordinateSpecialization i 0 p := by
  dsimp only
  unfold partialReverse
  have hc : ∀ j,pderiv i ((coordinatePolynomial i p).reverse.coeff j)=0 := by
    intro j
    rw [Polynomial.coeff_reverse]
    exact coordinatePolynomial_coeff_partial_zero p i _
  rw [signed_polynomial_eval_iterate_partial i _ hc]
  rw [polynomial_iterate_derivative_at_bound _ _ (Polynomial.reverse_natDegree_le _)]
  simp only [Polynomial.eval₂_C,RingHom.id_apply]
  rw [Polynomial.coeff_reverse,Polynomial.revAt_le le_rfl,Nat.sub_self,coordinatePolynomial_coeff_zero]
  ring

end CoefficientStability
