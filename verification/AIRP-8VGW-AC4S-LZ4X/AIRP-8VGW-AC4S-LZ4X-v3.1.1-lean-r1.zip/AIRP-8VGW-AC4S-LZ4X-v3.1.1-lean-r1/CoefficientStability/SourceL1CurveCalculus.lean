import CoefficientStability.SourceL1LowerRootCalculus
import CoefficientStability.SourceL1DistanceDomain

noncomputable section
open scoped Topology
namespace CoefficientStability
set_option maxHeartbeats 1200000

def sourceCubicSd (d h : ℝ) := -4*h+6*d+1
def sourceCubicSh (d h : ℝ) := 2*h-4*d
def sourceCubicCurveBase (d : ℝ) := (3-2*d)*Real.sqrt (sourceCubicS d (sourceCubicLowerRoot d))
def sourceCubicCurveDistance (d : ℝ) := sourceCubicDistance d (sourceCubicLowerRoot d)

theorem source_cubic_S_curve_hasDerivAt (g : ℝ → ℝ) (g' d : ℝ) (hg : HasDerivAt g g' d) :
    HasDerivAt (fun x => sourceCubicS x (g x)) (sourceCubicSd d (g d)+sourceCubicSh d (g d)*g') d := by
  have hid := hasDerivAt_id d
  have h := (((hg.pow 2).sub (((hasDerivAt_const d (4 : ℝ)).mul hid).mul hg)).add ((hid.pow 2).const_mul 3)).add hid
  convert h using 1
  · funext x
    dsimp [sourceCubicS] <;> ring
  · dsimp [sourceCubicSd,sourceCubicSh] <;> ring

theorem source_cubic_curve_base_hasDerivAt (d : ℝ) (hd : 0 < d) (hd3 : d < 1/3) :
    HasDerivAt sourceCubicCurveBase
      (-2*Real.sqrt (sourceCubicS d (sourceCubicLowerRoot d))+(3-2*d)*
        ((sourceCubicSd d (sourceCubicLowerRoot d)+sourceCubicSh d (sourceCubicLowerRoot d)*deriv sourceCubicLowerRoot d)/
          (2*Real.sqrt (sourceCubicS d (sourceCubicLowerRoot d))))) d := by
  have hR := (source_cubic_lower_root_differentiableAt d hd hd3).hasDerivAt
  have hS := source_cubic_S_curve_hasDerivAt sourceCubicLowerRoot (deriv sourceCubicLowerRoot d) d hR
  have hSpos := source_cubic_S_positive d (sourceCubicLowerRoot d) hd (by linarith)
  have hK := (hasDerivAt_const d (3 : ℝ)).sub ((hasDerivAt_id d).const_mul 2)
  have h := hK.mul (hS.sqrt (ne_of_gt hSpos))
  convert h using 1 <;> first
    | (funext x;dsimp [sourceCubicCurveBase] <;> ring)
    | (dsimp <;> ring)

theorem source_cubic_curve_base_derivative_scaled (d : ℝ) (hd : 0 < d) (hd3 : d < 1/3) :
    (2*Real.sqrt (sourceCubicS d (sourceCubicLowerRoot d))*sourceCubicHh d (sourceCubicLowerRoot d))*
      deriv sourceCubicCurveBase d=sourceCubicN d (sourceCubicLowerRoot d) := by
  let h := sourceCubicLowerRoot d
  let s := Real.sqrt (sourceCubicS d h)
  let K := 3-2*d
  have hSpos := source_cubic_S_positive d h hd (by linarith)
  have hspos : 0 < s := Real.sqrt_pos.mpr hSpos
  have hs : s^2=sourceCubicS d h := Real.sq_sqrt hSpos.le
  have hrid := source_cubic_lower_root_derivative_identity d hd hd3
  have hmul : sourceCubicHh d h*deriv sourceCubicLowerRoot d= -sourceCubicHd d h := by linarith
  have hv := (source_cubic_curve_base_hasDerivAt d hd hd3).deriv
  change deriv sourceCubicCurveBase d= -2*s+K*((sourceCubicSd d h+sourceCubicSh d h*deriv sourceCubicLowerRoot d)/(2*s)) at hv
  change (2*s*sourceCubicHh d h)*deriv sourceCubicCurveBase d=sourceCubicN d h
  rw [hv]
  calc
    _ = -4*s^2*sourceCubicHh d h+K*(sourceCubicSd d h*sourceCubicHh d h+
        sourceCubicSh d h*(sourceCubicHh d h*deriv sourceCubicLowerRoot d)) := by
      field_simp [ne_of_gt hspos] <;> ring
    _ = _ := by
      rw [hs,hmul]
      dsimp [K,sourceCubicN,sourceCubicSd,sourceCubicSh]
      ring

theorem source_cubic_curve_distance_continuousOn :
    ContinuousOn sourceCubicCurveDistance (Set.Icc (0 : ℝ) (1/3)) := by
  intro d hd
  have hR := source_cubic_lower_root_continuousAt d hd.1 hd.2
  have hc : ContinuousAt sourceCubicCurveDistance d := by
    unfold sourceCubicCurveDistance sourceCubicDistance sourceCubicS
    fun_prop
  exact hc.continuousWithinAt

end CoefficientStability
