import CoefficientStability.SourceOneZeroMinimum

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1200000

def sourceTernaryZeroMarginalChart (x y z w : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  ![![x,y,-x-y],![z,w,-z-w],![-x-z,-y-w,x+y+z+w]]

theorem source_ternary_zero_marginal_chart (A : Matrix (Fin 3) (Fin 3) ℝ)
    (hrow : ∀ i,∑ j,A i j=0) (hcol : ∀ j,∑ i,A i j=0) :
    A=sourceTernaryZeroMarginalChart (A 0 0) (A 0 1) (A 1 0) (A 1 1) := by
  have hr0 := hrow 0
  have hr1 := hrow 1
  have hr2 := hrow 2
  have hc0 := hcol 0
  have hc1 := hcol 1
  norm_num [Fin.sum_univ_succ] at hr0 hr1 hr2 hc0 hc1
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [sourceTernaryZeroMarginalChart] <;> linarith

def sourceTernaryRadialQuadratic (t : Fin 3 → ℝ) (A : Matrix (Fin 3) (Fin 3) ℝ) :=
  (1/6)*(∑ i,(3-2*t i)*(∑ j,(A i j)^2))

theorem source_ternary_radial_expansion (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (A : Matrix (Fin 3) (Fin 3) ℝ) (hrow : ∀ i,∑ j,A i j=0) (hcol : ∀ j,∑ i,A i j=0) (s : ℝ) :
    Matrix.permanent (fun i j => t i/3+s*A i j)=sourceTernaryBaseline t+
      sourceTernaryRadialQuadratic t A*s^2+Matrix.permanent A*s^3 := by
  have hs := ht
  norm_num [Fin.sum_univ_succ] at hs
  have ht2 : t 2=3-t 0-t 1 := by linarith
  rw [source_permanent_three (show Matrix (Fin 3) (Fin 3) ℝ from fun i j => t i/3+s*A i j),source_permanent_three A]
  rw [source_ternary_zero_marginal_chart A hrow hcol]
  norm_num [sourceTernaryZeroMarginalChart,sourceTernaryBaseline,sourceTernaryRadialQuadratic,Fin.sum_univ_succ]
  rw [ht2]
  ring

end CoefficientStability
