import CoefficientStability.SourceTernaryRadialPositivity

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 1200000

theorem source_ternary_reference_marginals (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) :
    (∀ i,∑ j,sourcePermanentReference t i j=t i) ∧ ∀ j,∑ i,sourcePermanentReference t i j=1 := by
  constructor
  · intro i
    norm_num [sourcePermanentReference,Fin.sum_univ_succ]
    ring
  · intro j
    simp only [sourcePermanentReference,← Finset.sum_div,ht]
    norm_num

theorem source_ternary_reference_permanent (t : Fin 3 → ℝ) :
    Matrix.permanent (sourcePermanentReference t)=sourceTernaryBaseline t := by
  rw [source_permanent_three]
  unfold sourcePermanentReference sourceTernaryBaseline
  ring

theorem source_ternary_interior_minimum_gap (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hbox : ∀ i,1/2 ≤ t i ∧ t i ≤ 3/2) (B : Matrix (Fin 3) (Fin 3) ℝ)
    (hB : B ∈ sourceTransportationPolytope t) (hpos : ∀ i j,0 < B i j)
    (hmin : IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) B) :
    sourceTernaryBaseline t ≤ Matrix.permanent B ∧
      (Matrix.permanent B=sourceTernaryBaseline t ↔ B=sourcePermanentReference t) := by
  let A := B-sourcePermanentReference t
  obtain ⟨hrefrow,hrefcol⟩ := source_ternary_reference_marginals t ht
  have hrow : ∀ i,∑ j,A i j=0 := by
    intro i
    simp only [A,Matrix.sub_apply,Finset.sum_sub_distrib,hB.2.1 i,hrefrow i,sub_self]
  have hcol : ∀ j,∑ i,A i j=0 := by
    intro j
    simp only [A,Matrix.sub_apply,Finset.sum_sub_distrib,hB.2.2 j,hrefcol j,sub_self]
  let γ : ℝ → Matrix (Fin 3) (Fin 3) ℝ := fun s i j => B i j+s*A i j
  have hcont : Continuous γ := by
    apply continuous_pi
    intro i
    apply continuous_pi
    intro j
    dsimp [γ]
    fun_prop
  have hzero : γ 0=B := by ext i j;simp [γ]
  have hfeas : ∃ e : ℝ,0 < e ∧ ∀ s : ℝ,|s| < e → γ s ∈ sourceTransportationPolytope t := by
    obtain ⟨e,he,hnear⟩ := finite_affine_positive_near_zero (fun q : Fin 3 × Fin 3 => B q.1 q.2)
      (fun q => A q.1 q.2) (fun q => hpos q.1 q.2)
    refine ⟨e,he,?_⟩
    intro s hs
    refine ⟨fun i j => (hnear s hs (i,j)).le,?_,?_⟩
    · intro i
      simp only [γ,Finset.sum_add_distrib,← Finset.mul_sum,hB.2.1 i,hrow i,mul_zero,add_zero]
    · intro j
      simp only [γ,Finset.sum_add_distrib,← Finset.mul_sum,hB.2.2 j,hcol j,mul_zero,add_zero]
  let q := sourceTernaryRadialQuadratic t A
  let c := Matrix.permanent A
  have hfun : (Matrix.permanent ∘ γ)=(fun s : ℝ => sourceTernaryBaseline t+q*(1+s)^2+c*(1+s)^3) := by
    funext s
    have he : γ s=(fun i j => t i/3+(1+s)*A i j) := by
      ext i j
      dsimp [γ,A,sourcePermanentReference]
      ring
    change Matrix.permanent (γ s)=_
    rw [he]
    exact source_ternary_radial_expansion t ht A hrow hcol (1+s)
  have hder : HasDerivAt (Matrix.permanent ∘ γ) (2*q+3*c) 0 := by
    rw [hfun]
    have h1 : HasDerivAt (fun s : ℝ => 1+s) 1 0 := (hasDerivAt_id (0 : ℝ)).const_add 1
    have h := ((hasDerivAt_const (0 : ℝ) (sourceTernaryBaseline t)).add ((h1.pow 2).const_mul q)).add ((h1.pow 3).const_mul c)
    convert h using 1 <;> norm_num <;> ring
  have hstat := source_local_min_curve_derivative_zero Matrix.permanent (sourceTransportationPolytope t) B γ
    (2*q+3*c) hcont hzero hfeas hmin hder
  have hexp := source_ternary_radial_expansion t ht A hrow hcol 1
  have heB : (fun i j => t i/3+1*A i j)=B := by
    ext i j
    dsimp [A,sourcePermanentReference]
    ring
  rw [heB] at hexp
  simp only [one_pow,mul_one] at hexp
  have hq : 0 ≤ q := source_ternary_radial_quadratic_nonnegative t (fun i => (hbox i).2) A
  refine ⟨by change _=sourceTernaryBaseline t+q+c at hexp;linarith,?_⟩
  constructor
  · intro heq
    have hz : q=0 := by change _=sourceTernaryBaseline t+q+c at hexp;linarith
    have hA : A=0 := (source_ternary_radial_quadratic_zero_iff t ht hbox A hcol).mp hz
    exact sub_eq_zero.mp hA
  · intro heq
    rw [heq,source_ternary_reference_permanent]

end CoefficientStability
