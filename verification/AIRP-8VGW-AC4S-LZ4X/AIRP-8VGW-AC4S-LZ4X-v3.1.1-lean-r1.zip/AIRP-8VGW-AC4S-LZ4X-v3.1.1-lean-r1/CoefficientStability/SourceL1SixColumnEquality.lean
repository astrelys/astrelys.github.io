import CoefficientStability.SourceSharpL1Classification

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1600000

theorem source_l1_exceptional_traces_injective : Function.Injective sourceL1ExceptionalTraces := by
  intro i j hij
  by_contra hn
  have he := source_cubic_epsilon_bounds.1
  fin_cases i <;> fin_cases j <;> norm_num [sourceL1ExceptionalTraces] at hij
  all_goals first | exact hn rfl | linarith

theorem source_l1_ordered_equality_iff (B : Matrix (Fin 3) (Fin 3) ℝ)
    (hB : B ∈ sourceTransportationPolytope sourceL1ExceptionalTraces) :
    Matrix.permanent B=sourceTernaryBaseline sourceL1ExceptionalTraces ↔
      B=sourcePermanentReference sourceL1ExceptionalTraces ∨
        ∃ c : Equiv.Perm (Fin 3),B=sourcePermutedMatrix (sourceL1BoundaryMatrix sourceCubicDStar) 1 c := by
  have ht : (∑ i,sourceL1ExceptionalTraces i)=3 := by norm_num [sourceL1ExceptionalTraces,Fin.sum_univ_succ];ring
  have hr := source_l1_boundary_dstar_feasible_equal.2.2.le
  rw [source_sharp_l1_equality_iff sourceL1ExceptionalTraces ht hr B hB]
  unfold sourceL1EqualityDescription
  constructor
  · rintro (hscalar | ⟨r,c,htp,hmp⟩)
    · exact Or.inl hscalar
    · have hrid : r=1 := by
        apply Equiv.ext
        intro i
        apply source_l1_exceptional_traces_injective
        exact congrFun htp i
      subst r
      have he := congrArg (fun M => sourcePermutedMatrix M 1 c.symm) hmp
      have hi : sourcePermutedMatrix (sourcePermutedMatrix B 1 c) 1 c.symm=B := by
        ext i j
        simp [sourcePermutedMatrix,Matrix.submatrix_apply]
      rw [hi] at he
      exact Or.inr ⟨c.symm,he⟩
  · rintro (hscalar | ⟨c,hmp⟩)
    · exact Or.inl hscalar
    · right
      refine ⟨1,c.symm,rfl,?_⟩
      rw [hmp]
      exact source_permuted_matrix_inverse _ (1 : Equiv.Perm (Fin 3)) c

theorem source_l1_boundary_dstar_zero_iff (i j : Fin 3) :
    sourceL1BoundaryMatrix sourceCubicDStar i j=0 ↔ (i=0 ∧ j=0) ∨ (i=1 ∧ j=1) := by
  have hp := (source_l1_boundary_family_feasible sourceCubicDStar source_cubic_dstar_bounds.1 source_l1_dstar_eighth_bound).2
  by_cases hq : (i,j) ∈ sourceSeparatedEntrySet
  · have hn := ne_of_gt (hp _ hq)
    have hf : ¬((i=0 ∧ j=0) ∨ (i=1 ∧ j=1)) := by
      have hm := hq
      simp only [sourceSeparatedEntrySet,Finset.mem_erase,Finset.mem_univ,true_and,and_true] at hm
      rintro (⟨hi,hj⟩ | ⟨hi,hj⟩)
      · exact hm.2 (Prod.ext hi hj)
      · exact hm.1 (Prod.ext hi hj)
    exact iff_of_false hn hf
  · fin_cases i <;> fin_cases j <;> norm_num [sourceSeparatedEntrySet] at hq
    all_goals norm_num [sourceL1BoundaryMatrix]

theorem source_l1_boundary_column_permutations_injective :
    Function.Injective (fun c : Equiv.Perm (Fin 3) => sourcePermutedMatrix (sourceL1BoundaryMatrix sourceCubicDStar) 1 c) := by
  intro p q he
  have hfinite : ∀ x y : Fin 3,(x=0 ↔ y=0) → (x=1 ↔ y=1) → x=y := by decide
  apply Equiv.ext
  intro j
  apply hfinite
  · have hv := congrFun (congrFun he 0) j
    change sourceL1BoundaryMatrix sourceCubicDStar 0 (p j)=sourceL1BoundaryMatrix sourceCubicDStar 0 (q j) at hv
    have hz := congrArg (fun x : ℝ => x=0) hv
    simpa [source_l1_boundary_dstar_zero_iff] using Iff.of_eq hz
  · have hv := congrFun (congrFun he 1) j
    change sourceL1BoundaryMatrix sourceCubicDStar 1 (p j)=sourceL1BoundaryMatrix sourceCubicDStar 1 (q j) at hv
    have hz := congrArg (fun x : ℝ => x=0) hv
    simpa [source_l1_boundary_dstar_zero_iff] using Iff.of_eq hz

theorem source_l1_boundary_column_feasible_equal (c : Equiv.Perm (Fin 3)) :
    sourcePermutedMatrix (sourceL1BoundaryMatrix sourceCubicDStar) 1 c ∈ sourceTransportationPolytope sourceL1ExceptionalTraces ∧
      Matrix.permanent (sourcePermutedMatrix (sourceL1BoundaryMatrix sourceCubicDStar) 1 c)=sourceTernaryBaseline sourceL1ExceptionalTraces ∧
      sourcePermutedMatrix (sourceL1BoundaryMatrix sourceCubicDStar) 1 c≠sourcePermanentReference sourceL1ExceptionalTraces := by
  have hf := source_permuted_feasible sourceL1ExceptionalTraces (sourceL1BoundaryMatrix sourceCubicDStar)
    source_l1_boundary_dstar_feasible_equal.1 (1 : Equiv.Perm (Fin 3)) c
  refine ⟨hf,?_,?_⟩
  · rw [source_permuted_permanent]
    exact source_l1_boundary_dstar_feasible_equal.2.1
  · intro he
    have h := congrFun (congrFun he 0) (c.symm 0)
    change sourceL1BoundaryMatrix sourceCubicDStar 0 (c (c.symm 0))=sourceL1ExceptionalTraces 0/3 at h
    simp only [Equiv.apply_symm_apply] at h
    norm_num [sourceL1BoundaryMatrix,sourceL1ExceptionalTraces] at h
    linarith [source_cubic_epsilon_bounds.1]

theorem source_l1_boundary_column_permutations_card :
    (Finset.univ.image (fun c : Equiv.Perm (Fin 3) => sourcePermutedMatrix (sourceL1BoundaryMatrix sourceCubicDStar) 1 c)).card=6 := by
  classical
  rw [Finset.card_image_of_injective _ source_l1_boundary_column_permutations_injective]
  decide

end CoefficientStability
