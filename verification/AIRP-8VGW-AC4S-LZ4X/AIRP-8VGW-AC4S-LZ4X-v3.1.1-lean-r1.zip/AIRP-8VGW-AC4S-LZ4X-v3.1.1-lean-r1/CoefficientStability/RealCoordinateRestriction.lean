import CoefficientStability.FiniteRealSpecialization
import CoefficientStability.PositivePolynomialEvaluation

noncomputable section
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def realCoordinateRestriction (x : Fin n → ℝ) (i : Fin n) :
    MvPolynomial (Fin n) ℝ →+* Polynomial ℝ :=
  MvPolynomial.eval₂Hom Polynomial.C
    (fun j => if j=i then Polynomial.X else Polynomial.C (x j))

theorem realCoordinateRestriction_eval (p : MvPolynomial (Fin n) ℝ)
    (x : Fin n → ℝ) (i : Fin n) (w : ℝ) :
    (realCoordinateRestriction x i p).eval w=MvPolynomial.eval (Function.update x i w) p := by
  classical
  change (Polynomial.evalRingHom w) (MvPolynomial.eval₂ _ _ p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c
    simp
  · funext j
    by_cases hji : j=i
    · subst j
      simp
    · simp [hji]

theorem realCoordinateRestriction_complex_eval (p : MvPolynomial (Fin n) ℝ)
    (x : Fin n → ℝ) (i : Fin n) (w : ℂ) :
    Polynomial.eval₂ Complex.ofRealHom w (realCoordinateRestriction x i p)=
      MvPolynomial.eval₂ Complex.ofRealHom (Function.update (fun j => (x j : ℂ)) i w) p := by
  classical
  change (Polynomial.eval₂RingHom Complex.ofRealHom w) (MvPolynomial.eval₂ _ _ p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c
    simp
  · funext j
    by_cases hji : j=i
    · subst j
      simp
    · simp [hji]

theorem realCoordinateRestriction_finite_eval (p : MvPolynomial (Fin n) ℝ)
    (x : Fin n → ℝ) (i : Fin n) (w : ℂ) :
    MvPolynomial.eval₂ Complex.ofRealHom (Function.update (fun _ => Complex.I) i w)
      (finiteRealSpecialization (Finset.univ.erase i) x p)=
        Polynomial.eval₂ Complex.ofRealHom w (realCoordinateRestriction x i p) := by
  classical
  rw [finiteRealSpecialization_complex_eval,realCoordinateRestriction_complex_eval]
  congr 1
  funext j
  by_cases hji : j=i
  · subst j
    simp
  · simp [hji]

def realUnivariateUpperZeroFree (P : Polynomial ℝ) : Prop :=
  ∀ w : ℂ,0<w.im → Polynomial.eval₂ Complex.ofRealHom w P≠0

theorem stable_realCoordinateRestriction_zero_or_stable (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (x : Fin n → ℝ) (i : Fin n) :
    realCoordinateRestriction x i p=0 ∨ realUnivariateUpperZeroFree (realCoordinateRestriction x i p) := by
  classical
  rcases stable_finite_real_specialization_zero_or_stable p hp (Finset.univ.erase i) x with hz | hs
  · left
    apply Polynomial.funext
    intro r
    have he := realCoordinateRestriction_finite_eval p x i (r : ℂ)
    rw [hz,MvPolynomial.eval₂_zero] at he
    have hc : (((realCoordinateRestriction x i p).eval r : ℝ) : ℂ)=0 := by
      change Complex.ofRealHom ((realCoordinateRestriction x i p).eval r)=0
      rw [← Polynomial.eval₂_at_apply]
      exact he.symm
    simpa using Complex.ofReal_injective hc
  · right
    intro w hw
    have hz : ∀ j,0<((Function.update (fun _ : Fin n => Complex.I) i w) j).im := by
      intro j
      by_cases hji : j=i
      · subst j
        simpa using hw
      · simp [hji]
    have h := hs _ hz
    rw [realCoordinateRestriction_finite_eval] at h
    exact h

theorem real_upper_zero_free_root_real (P : Polynomial ℝ) (hp : realUnivariateUpperZeroFree P)
    (z : ℂ) (hz : Polynomial.eval₂ Complex.ofRealHom z P=0) : z.im=0 := by
  rcases lt_trichotomy 0 z.im with h | h | h
  · exact False.elim (hp z h hz)
  · exact h.symm
  · have hconj : Polynomial.eval₂ Complex.ofRealHom (star z) P=0 := by
      have hh := Polynomial.aeval_conj P z
      change Polynomial.eval₂ (algebraMap ℝ ℂ) z P=0 at hz
      change Polynomial.eval₂ (algebraMap ℝ ℂ) ((starRingEnd ℂ) z) P=0
      simpa only [Polynomial.aeval_def,hz,map_zero] using hh
    exact False.elim (hp (star z) (by simpa using neg_pos.mpr h) hconj)

theorem real_upper_zero_free_splits (P : Polynomial ℝ) (hp : realUnivariateUpperZeroFree P) : P.Splits := by
  apply Polynomial.Splits.of_splits_map Complex.ofRealHom (IsAlgClosed.splits _)
  intro z hz
  have hroot := Polynomial.isRoot_of_mem_roots hz
  have heval : Polynomial.eval₂ Complex.ofRealHom z P=0 := by
    simpa only [Polynomial.IsRoot,Polynomial.eval_map] using hroot
  have him := real_upper_zero_free_root_real P hp z heval
  refine ⟨z.re,?_⟩
  apply Complex.ext <;> simp [him]

theorem stable_polynomial_ne_zero (p : MvPolynomial (Fin n) ℝ) (hp : UpperHalfPlaneZeroFree p) : p≠0 := by
  intro hz
  have h := hp (fun _ => Complex.I) (by intro j; simp)
  simp [hz] at h

theorem positive_stable_realCoordinateRestriction (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (hc : ∀ g,0≤p.coeff g)
    (x : Fin n → ℝ) (hx : ∀ j,0<x j) (i : Fin n) :
    (realCoordinateRestriction x i p)≠0 ∧
      (realCoordinateRestriction x i p).Splits ∧
      (∀ r : ℝ,0<r → 0<(realCoordinateRestriction x i p).eval r) := by
  have hpos : ∀ r : ℝ,0<r → 0<(realCoordinateRestriction x i p).eval r := by
    intro r hr
    rw [realCoordinateRestriction_eval]
    apply nonnegative_coeff_eval_pos p (stable_polynomial_ne_zero p hp) hc
    intro j
    by_cases hji : j=i
    · subst j
      simpa using hr
    · simpa only [Function.update_of_ne hji] using hx j
  have hne : realCoordinateRestriction x i p≠0 := by
    intro hz
    have h := hpos 1 (by norm_num)
    simp [hz] at h
  have hs := (stable_realCoordinateRestriction_zero_or_stable p hp x i).resolve_left hne
  exact ⟨hne,real_upper_zero_free_splits _ hs,hpos⟩

end CoefficientStability
