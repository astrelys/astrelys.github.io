import CoefficientStability.SourceCubicConeGeometry
import CoefficientStability.SourceCubicConstraintOpenMap
import CoefficientStability.SourceCubicMatrixFirstOrder

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 2400000
set_option backward.isDefEq.respectTransparency false

def sourceCubicConstraintTarget (t : Fin 3 → ℝ) : SourceCubicConstraintSpace :=
  (sourceCubicHermitianOne,![t 0,t 1])
def sourceCubicHermitianBundle (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : ∀ i,(A i).IsHermitian) : SourceCubicHermitianTuples := fun i => ⟨A i,hA i⟩
def sourceCubicGradientDual (t : Fin 3 → ℝ) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) :
    Module.Dual ℝ SourceCubicHermitianTuples where
  toFun Y := ∑ i,(Matrix.trace (sourceCubicMatrixGradient (t i) (A i)*(Y i).val)).re
  map_add' Y Z := by simp [mul_add,Matrix.trace_add,Complex.add_re,Finset.sum_add_distrib]
  map_smul' a Y := by simp [mul_smul_comm,Matrix.trace_smul,Finset.mul_sum]

theorem source_cubic_cone_constraints_feasible (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (Y : SourceCubicHermitianTuples) (hY : Y ∈ sourceCubicPSDCone)
    (hc : sourceCubicConstraintMap Y=sourceCubicConstraintTarget t) :
    (fun i => (Y i).val) ∈ hermitianFeasibleTuples t := by
  obtain ⟨hs,htr⟩ := source_cubic_constraint_recovers_third_trace Y t ht hc
  exact ⟨fun i => ⟨(Y i).property,hY i,htr i⟩,hs⟩

theorem source_cubic_feasible_bundle_constraints (t : Fin 3 → ℝ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : A ∈ hermitianFeasibleTuples t) :
    sourceCubicConstraintMap (sourceCubicHermitianBundle A (fun i => (hA.1 i).1))=sourceCubicConstraintTarget t := by
  apply Prod.ext
  · apply Subtype.ext
    change (∑ i,A i)=1
    exact hA.2
  · funext j
    fin_cases j
    · change (Matrix.trace (A 0)).re=t 0
      rw [(hA.1 0).2.2,Complex.ofReal_re]
    · change (Matrix.trace (A 1)).re=t 1
      rw [(hA.1 1).2.2,Complex.ofReal_re]

theorem source_cubic_actual_conic_linear_minimum (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : A ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A)
    (Y : SourceCubicHermitianTuples) (hY : Y ∈ sourceCubicPSDCone)
    (hc : sourceCubicConstraintMap Y=sourceCubicConstraintTarget t) :
    sourceCubicGradientDual t A (sourceCubicHermitianBundle A (fun i => (hA.1 i).1)) ≤ sourceCubicGradientDual t A Y := by
  exact source_cubic_local_minimum_linear_minimum t A hA hm (source_cubic_cone_constraints_feasible t ht Y hY hc)

end CoefficientStability
