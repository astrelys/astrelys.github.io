import CoefficientStability.ActualRelativeTilt
import CoefficientStability.PaperRatioGradient
import Mathlib.Analysis.Convex.Jensen
import Mathlib.Analysis.Convex.SpecificFunctions.Basic

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def multivariatePositiveCapacity (p : MvPolynomial (Fin n) ℝ) : ℝ :=
  sInf (Set.range (fun x : {x : Fin n → ℝ // ∀ i,0<x i} => MvPolynomial.eval x.val p/(∏ i,x.val i)))

theorem balanced_coefficient_exponent_mean (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=1) :
    (∑ g∈p.support,p.coeff g*tiltExponent g u)=∑ i,u i := by
  simp only [tiltExponent,Finset.mul_sum]
  rw [Finset.sum_comm]
  calc
    _ = ∑ i,(∑ g∈p.support,p.coeff g*(g i : ℝ))*u i := by
      simp only [Finset.sum_mul,mul_assoc]
    _ = _ := by simp only [actual_coefficient_first_moment,hgrad,one_mul]

theorem balanced_polynomial_exp_lower (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ)
    (hcoeff : ∀ g,0≤p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=1) :
    Real.exp (∑ i,u i)≤MvPolynomial.eval (fun i => Real.exp (u i)) p := by
  have h := convexOn_exp.map_sum_le (t := p.support) (w := fun g => p.coeff g)
    (p := fun g => tiltExponent g u) (fun g hg => hcoeff g)
    (normalized_coefficient_mass p hnorm) (fun g hg => Set.mem_univ _)
  simp only [smul_eq_mul,balanced_coefficient_exponent_mean p u hgrad] at h
  have hZ := ne_of_gt (tiltPartition_pos p u hcoeff hnorm)
  rw [← tiltPartition_eq_eval_exp p u hZ]
  exact h

theorem paper_balanced_capacity_one (p : MvPolynomial (Fin n) ℝ)
    (hcoeff : ∀ g,0≤p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=1) :
    multivariatePositiveCapacity p=1 := by
  let S := Set.range (fun x : {x : Fin n → ℝ // ∀ i,0<x i} => MvPolynomial.eval x.val p/(∏ i,x.val i))
  have hne : S.Nonempty := ⟨_,⟨⟨fun _ => 1,fun _ => by norm_num⟩,rfl⟩⟩
  have hlower : ∀ y∈S,(1 : ℝ)≤y := by
    intro y hy
    obtain ⟨x,rfl⟩ := hy
    have he := balanced_polynomial_exp_lower p (fun i => Real.log (x.val i)) hcoeff hnorm hgrad
    simp only [Real.exp_log (x.prop _)] at he
    rw [Real.exp_sum] at he
    simp only [Real.exp_log (x.prop _)] at he
    exact (le_div_iff₀ (Finset.prod_pos (fun i hi => x.prop i))).mpr (by simpa using he)
  have hbb : BddBelow S := ⟨1,hlower⟩
  apply le_antisymm
  · apply csInf_le hbb
    refine ⟨⟨fun _ => 1,fun _ => by norm_num⟩,?_⟩
    simp [hnorm]
  · exact le_csInf hne hlower

end CoefficientStability
