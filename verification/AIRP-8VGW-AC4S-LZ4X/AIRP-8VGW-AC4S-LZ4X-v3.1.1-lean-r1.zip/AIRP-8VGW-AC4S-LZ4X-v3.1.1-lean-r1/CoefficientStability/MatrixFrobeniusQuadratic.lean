import CoefficientStability.HermitianDimension
import CoefficientStability.VectorHessianInertia

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def matrixRealEntry (r c : Fin n) : ComplexSquare n →ₗ[ℝ] ℝ where
  toFun A := (A r c).re
  map_add' A B := by simp
  map_smul' a A := by simp

def matrixImagEntry (r c : Fin n) : ComplexSquare n →ₗ[ℝ] ℝ where
  toFun A := (A r c).im
  map_add' A B := by simp
  map_smul' a A := by simp

def matrixFrobeniusQuadratic (n : ℕ) : QuadraticForm ℝ (ComplexSquare n) :=
  ∑ r : Fin n,∑ c : Fin n,
    (QuadraticMap.sq.comp (matrixRealEntry r c)+QuadraticMap.sq.comp (matrixImagEntry r c))

theorem matrixFrobeniusQuadratic_apply (A : ComplexSquare n) :
    matrixFrobeniusQuadratic n A=complexFrobeniusSq A := by
  simp [matrixFrobeniusQuadratic,matrixRealEntry,matrixImagEntry,QuadraticMap.sq,
    complexFrobeniusSq,pow_two,Finset.sum_add_distrib]
  rfl

theorem complexFrobeniusSq_pos (A : ComplexSquare n) (hA : A≠0) : 0<complexFrobeniusSq A := by
  classical
  have hex : ∃ r c,A r c≠0 := by
    by_contra! h
    apply hA
    exact Matrix.ext (fun r c => h r c)
  obtain ⟨r,c,hc⟩ := hex
  have hp : 0<(A r c).re^2+(A r c).im^2 := by
    have h := Complex.normSq_pos.mpr hc
    simpa [Complex.normSq_apply,pow_two] using h
  unfold complexFrobeniusSq
  apply Finset.sum_pos'
  · exact fun i _ => Finset.sum_nonneg (fun j _ => add_nonneg (sq_nonneg _) (sq_nonneg _))
  · refine ⟨r,Finset.mem_univ r,?_⟩
    apply Finset.sum_pos'
    · exact fun j _ => add_nonneg (sq_nonneg _) (sq_nonneg _)
    · exact ⟨c,Finset.mem_univ c,hp⟩

def tracelessHermitianInclusion (n : ℕ) : tracelessHermitian n →ₗ[ℝ] ComplexSquare n :=
  (selfAdjoint.submodule ℝ (ComplexSquare n)).subtype.comp (tracelessHermitian n).subtype

def tracelessHermitianQuadratic (n : ℕ) : QuadraticForm ℝ (tracelessHermitian n) :=
  (matrixFrobeniusQuadratic n).comp (tracelessHermitianInclusion n)

theorem tracelessHermitianQuadratic_apply (A : tracelessHermitian n) :
    tracelessHermitianQuadratic n A=complexFrobeniusSq A.val.val := by
  exact matrixFrobeniusQuadratic_apply A.val.val

theorem tracelessHermitianQuadratic_positive (n : ℕ) :
    (tracelessHermitianQuadratic n).PosDef := by
  intro A hA
  rw [tracelessHermitianQuadratic_apply]
  apply complexFrobeniusSq_pos
  exact fun he => hA (Subtype.ext (Subtype.ext he))

theorem tracelessHermitian_has_trace_zero (A : tracelessHermitian n) : Matrix.trace A.val.val=0 := by
  apply Complex.ext
  · exact A.property
  · have he := congrArg (fun B : ComplexSquare n => (Matrix.trace B).im) A.val.property
    change (Matrix.trace (star A.val.val)).im=(Matrix.trace A.val.val).im at he
    have him : (Matrix.trace (star A.val.val)).im= -(Matrix.trace A.val.val).im := by
      change (∑ i,(star A.val.val) i i).im= -(∑ i,A.val.val i i).im
      simp only [Matrix.star_apply,Complex.im_sum,Complex.star_def,Complex.conj_im,Finset.sum_neg_distrib]
    rw [him] at he
    simp only [Complex.zero_im]
    linarith

end CoefficientStability
