import CoefficientStability.RootVariance
import Mathlib.Algebra.MvPolynomial.PDeriv
import Mathlib.RingTheory.MvPolynomial.Homogeneous

noncomputable section
open scoped BigOperators
open MvPolynomial Finsupp
namespace CoefficientStability

theorem zero_mass_weighted_bound {ι : Type*} (s : Finset ι) (f w : ι → ℝ) (W : ℝ)
    (hz : ∑ i ∈ s, f i = 0) (hw : ∀ i ∈ s, 0 ≤ w i ∧ w i ≤ W) :
    |∑ i ∈ s, w i * f i| ≤ W/2 * ∑ i ∈ s, |f i| := by
  have he : (∑ i ∈ s, w i * f i) = ∑ i ∈ s, (w i - W/2) * f i := by
    simp [sub_mul, Finset.sum_sub_distrib, ← Finset.mul_sum, hz]
  rw [he]
  calc
    |∑ i ∈ s, (w i-W/2)*f i| ≤ ∑ i ∈ s, |(w i-W/2)*f i| :=
      Finset.abs_sum_le_sum_abs _ _
    _ = ∑ i ∈ s, |w i-W/2| *|f i| := by simp only [abs_mul]
    _ ≤ ∑ i ∈ s, (W/2)*|f i| := by
      apply Finset.sum_le_sum
      intro i hi
      apply mul_le_mul_of_nonneg_right _ (abs_nonneg _)
      apply abs_le.mpr
      obtain ⟨h0,hW⟩ := hw i hi
      constructor <;> linarith
    _ = W/2 * ∑ i ∈ s, |f i| := by rw [Finset.mul_sum]

variable {n : ℕ}

def diagonalWeight (g : Fin n →₀ ℕ) : ℝ := ∑ i, (g i : ℝ)*((g i : ℝ)-1)

def coefficientL1 (f : MvPolynomial (Fin n) ℝ) : ℝ := ∑ g ∈ f.support, |f.coeff g|

def coefficientDeficit (f : MvPolynomial (Fin n) ℝ) : ℝ :=
  -(∑ g ∈ f.support, diagonalWeight g * f.coeff g)/2

theorem diagonalWeight_nonneg (g : Fin n →₀ ℕ) : 0 ≤ diagonalWeight g := by
  apply Finset.sum_nonneg
  intro i hi
  rcases Nat.eq_zero_or_pos (g i) with h | h
  · simp [h]
  · have hg : (1 : ℝ) ≤ g i := by exact_mod_cast h
    exact mul_nonneg (Nat.cast_nonneg _) (sub_nonneg.mpr hg)

theorem diagonalWeight_le (g : Fin n →₀ ℕ) (N : ℕ) (h : ∑ i, g i = N) :
    diagonalWeight g ≤ (N : ℝ)*(N-1) := by
  have hs : (∑ i, (g i : ℝ)) = N := by exact_mod_cast h
  have hsq := Finset.sum_sq_le_sq_sum_of_nonneg
    (s := (Finset.univ : Finset (Fin n))) (f := fun i => (g i : ℝ)) (fun i _ => Nat.cast_nonneg (g i))
  have he : diagonalWeight g = (∑ i, (g i : ℝ)^2) - ∑ i, (g i : ℝ) := by
    simp [diagonalWeight, mul_sub, ← pow_two, Finset.sum_sub_distrib]
  rw [hs] at hsq
  rw [he, hs]
  nlinarith

theorem homogeneous_mass (f : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hf : f.IsHomogeneous N) (g : Fin n →₀ ℕ) (hg : g ∈ f.support) :
    ∑ i, g i = N := by
  have h := hf.degree_eq_sum_deg_support hg
  rw [h]
  exact (Finset.sum_subset (Finset.subset_univ _) (fun i _ hi => Finsupp.notMem_support_iff.mp hi)).symm

theorem coefficient_sum_eq_eval_one (f : MvPolynomial (Fin n) ℝ) :
    (∑ g ∈ f.support, f.coeff g) = MvPolynomial.eval (fun _ => 1) f := by
  simp [MvPolynomial.eval_eq]

theorem four_deficit_le_degree_coefficientL1 (f : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hf : f.IsHomogeneous N) (hz : MvPolynomial.eval (fun _ => 1) f = 0) :
    4 * coefficientDeficit f ≤ (N : ℝ)*(N-1)*coefficientL1 f := by
  have hsum : (∑ g ∈ f.support, f.coeff g) = 0 := by rw [coefficient_sum_eq_eval_one, hz]
  have hw (g : Fin n →₀ ℕ) (hg : g ∈ f.support) :
      0 ≤ diagonalWeight g ∧ diagonalWeight g ≤ (N : ℝ)*(N-1) :=
    ⟨diagonalWeight_nonneg g, diagonalWeight_le g N (homogeneous_mass f N hf g hg)⟩
  have h := zero_mass_weighted_bound f.support (fun g => f.coeff g) diagonalWeight
    ((N : ℝ)*(N-1)) hsum hw
  have hn := neg_le_abs (∑ g ∈ f.support, diagonalWeight g * f.coeff g)
  unfold coefficientDeficit coefficientL1
  linarith

theorem eval_one_second_monomial (g : Fin n →₀ ℕ) (c : ℝ) (i : Fin n) :
    MvPolynomial.eval (fun _ => 1) (pderiv i (pderiv i (monomial g c))) =
      (g i : ℝ)*((g i : ℝ)-1)*c := by
  simp only [pderiv_monomial, MvPolynomial.eval_monomial]
  simp only [Finsupp.tsub_apply, Finsupp.single_eq_same]
  simp only [one_pow, Finsupp.prod, Finset.prod_const_one, mul_one]
  rcases Nat.eq_zero_or_pos (g i) with h | h
  · simp [h]
  · have hi : 1 ≤ g i := h
    rw [Nat.cast_sub hi]
    norm_num
    ring

def hessianTraceAtOne (f : MvPolynomial (Fin n) ℝ) : ℝ :=
  ∑ i, MvPolynomial.eval (fun _ => 1) (pderiv i (pderiv i f))

theorem hessianTrace_monomial (g : Fin n →₀ ℕ) (c : ℝ) :
    hessianTraceAtOne (monomial g c) = diagonalWeight g * c := by
  simp_rw [hessianTraceAtOne, eval_one_second_monomial]
  rw [diagonalWeight, Finset.sum_mul]

theorem hessianTrace_eq_weighted_coefficients (f : MvPolynomial (Fin n) ℝ) :
    hessianTraceAtOne f = ∑ g ∈ f.support, diagonalWeight g * f.coeff g := by
  conv_lhs => rw [f.as_sum]
  simp only [hessianTraceAtOne, map_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro g hg
  exact hessianTrace_monomial g (f.coeff g)

theorem coefficientDeficit_eq_negative_half_trace (f : MvPolynomial (Fin n) ℝ) :
    coefficientDeficit f = -hessianTraceAtOne f / 2 := by
  rw [coefficientDeficit, hessianTrace_eq_weighted_coefficients]

theorem hessianTrace_coefficient_distance_lower (f : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hf : f.IsHomogeneous N) (hz : MvPolynomial.eval (fun _ => 1) f = 0) :
    -2*hessianTraceAtOne f ≤ (N : ℝ)*(N-1)*coefficientL1 f := by
  have h := four_deficit_le_degree_coefficientL1 f N hf hz
  rw [coefficientDeficit_eq_negative_half_trace] at h
  linarith

end CoefficientStability
