import CoefficientStability.SourceCubicMatrixBallEquality

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 3000000
set_option backward.isDefEq.respectTransparency false

theorem source_cubic_diagonal_unitary_orbit (t : Fin 3 → ℝ)
    (B : Matrix (Fin 3) (Fin 3) ℝ) (hB : B ∈ sourceTransportationPolytope t)
    (U : Matrix.unitaryGroup (Fin 3) ℂ) :
    sourceCubicUnitaryAction (star U) (sourcePermanentDiagonalTuple B) ∈ hermitianFeasibleTuples t ∧
    hermitianMixedObjective (sourceCubicUnitaryAction (star U) (sourcePermanentDiagonalTuple B))=Matrix.permanent B ∧
    sourceCubicUnitaryAction U (sourceCubicUnitaryAction (star U) (sourcePermanentDiagonalTuple B))=
      sourcePermanentDiagonalTuple B := by
  have hD := source_permanent_diagonal_feasible t B hB
  have hf := source_cubic_unitary_feasible t (star U) _ hD
  have hv := congrArg Complex.re (source_cubic_unitary_mixed_invariant (star U) (sourcePermanentDiagonalTuple B) hD.2)
  change hermitianMixedObjective (sourceCubicUnitaryAction (star U) (sourcePermanentDiagonalTuple B))=
    hermitianMixedObjective (sourcePermanentDiagonalTuple B) at hv
  rw [source_permanent_diagonal_objective] at hv
  have hi := source_cubic_unitary_action_inverse (star U) (sourcePermanentDiagonalTuple B)
  exact ⟨hf,hv,by simpa only [star_star] using hi⟩

theorem source_cubic_matrix_euclidean_sharpness (r : ℝ) (hr : Real.sqrt (3/8) < r) :
    ∃ (t : Fin 3 → ℝ) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ),(∑ i,t i)=3 ∧
      (∀ i,0 < t i) ∧ A ∈ hermitianFeasibleTuples t ∧
      Real.sqrt (∑ i,(t i-1)^2) < r ∧ hermitianMixedObjective A < sourceTernaryBaseline t := by
  obtain ⟨t,B,ht,hp,hB,hnear,hgap⟩ := source_euclidean_sharpness_radius r hr
  exact ⟨t,sourcePermanentDiagonalTuple B,ht,hp,source_permanent_diagonal_feasible t B hB,hnear,
    by rwa [source_permanent_diagonal_objective]⟩

theorem source_cubic_matrix_l1_sharpness (r : ℝ) (hr : sourceCubicEpsilon0 < r) :
    ∃ (t : Fin 3 → ℝ) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ),(∑ i,t i)=3 ∧
      (∀ i,0 < t i) ∧ A ∈ hermitianFeasibleTuples t ∧
      (∑ i,|t i-1|) < r ∧ hermitianMixedObjective A < sourceTernaryBaseline t := by
  obtain ⟨t,B,ht,hp,hB,hnear,hgap⟩ := source_l1_sharpness_radius r hr
  exact ⟨t,sourcePermanentDiagonalTuple B,ht,hp,source_permanent_diagonal_feasible t B hB,hnear,
    by rwa [source_permanent_diagonal_objective]⟩

theorem source_original_cubic_matrix_euclidean_ball (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,(t i-1)^2) ≤ 3/8) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) :
    sourceTernaryBaseline t ≤ hermitianMixedObjective A ∧
    (hermitianMixedObjective A=sourceTernaryBaseline t ↔ sourceCubicMatrixEuclideanEquality t A) ∧
    ((∑ i,(t i-1)^2) < 3/8 → (hermitianMixedObjective A=sourceTernaryBaseline t ↔ A=complexReferenceTuple t)) ∧
    sourceTernaryBaseline t/6 ≤ hermitianMixedObjective A/6 ∧
    (hermitianMixedObjective A/6=sourceTernaryBaseline t/6 ↔ sourceCubicMatrixEuclideanEquality t A) := by
  exact ⟨source_cubic_matrix_euclidean_ball_inequality t ht hr A hA,
    source_cubic_matrix_euclidean_equality_iff t ht hr A hA,
    fun hstrict => source_cubic_matrix_euclidean_open_unique t ht hstrict A hA,
    source_cubic_matrix_euclidean_normalized t ht hr A hA⟩

theorem source_original_cubic_matrix_l1_ball (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,|t i-1|) ≤ sourceCubicEpsilon0) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) :
    sourceTernaryBaseline t ≤ hermitianMixedObjective A ∧
    (hermitianMixedObjective A=sourceTernaryBaseline t ↔ sourceCubicMatrixL1Equality t A) ∧
    ((∑ i,|t i-1|) < sourceCubicEpsilon0 → (hermitianMixedObjective A=sourceTernaryBaseline t ↔ A=complexReferenceTuple t)) ∧
    sourceTernaryBaseline t/6 ≤ hermitianMixedObjective A/6 ∧
    (hermitianMixedObjective A/6=sourceTernaryBaseline t/6 ↔ sourceCubicMatrixL1Equality t A) := by
  exact ⟨source_cubic_matrix_l1_ball_inequality t ht hr A hA,
    source_cubic_matrix_l1_equality_iff t ht hr A hA,
    fun hstrict => source_cubic_matrix_l1_open_unique t ht hstrict A hA,
    source_cubic_matrix_l1_normalized t ht hr A hA⟩

end CoefficientStability
