import CoefficientStability.SourceStableCubicPencilPositivity

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

theorem source_stable_cubic_actual_whitening (M : Matrix (Fin 3) (Fin 3) ℂ) (hM : M.PosDef) :
    ∃ V : Matrix (Fin 3) (Fin 3) ℂ,V*M*V.conjTranspose=1 := by
  let U := hM.isHermitian.eigenvectorUnitary
  let d : Fin 3 → ℝ := hM.isHermitian.eigenvalues
  let r : Fin 3 → ℝ := fun i => (Real.sqrt (d i))⁻¹
  let D : Matrix (Fin 3) (Fin 3) ℂ := Matrix.diagonal (fun i => (r i : ℂ))
  have hd (i : Fin 3) : 0 < d i := hM.eigenvalues_pos i
  have hr (i : Fin 3) : r i*d i*r i=1 := by
    have hs := Real.sqrt_pos.mpr (hd i)
    have hsq := Real.sq_sqrt (hd i).le
    dsimp [r]
    field_simp [ne_of_gt hs]
    nlinarith
  have hDH : D.conjTranspose=D := Matrix.isHermitian_diagonal_iff.mpr (fun i => by simp [IsSelfAdjoint])
  have hdiag : D*Matrix.diagonal (fun i => (d i : ℂ))*D=1 := by
    rw [Matrix.diagonal_mul_diagonal,Matrix.diagonal_mul_diagonal]
    ext i j
    by_cases hij : i=j
    · subst j
      simp only [Matrix.diagonal_apply_eq,Pi.mul_apply,Matrix.one_apply_eq]
      change (r i : ℂ)*(d i : ℂ)*(r i : ℂ)=1
      have h := congrArg Complex.ofReal (hr i)
      push_cast at h
      exact h
    · simp [Matrix.diagonal_apply,Matrix.one_apply,hij]
  have hspectral : (U : Matrix (Fin 3) (Fin 3) ℂ).conjTranspose*M*(U : Matrix (Fin 3) (Fin 3) ℂ)=
      Matrix.diagonal (fun i => (d i : ℂ)) := by
    have h := hM.isHermitian.conjStarAlgAut_star_eigenvectorUnitary
    simp only [Unitary.conjStarAlgAut_star_apply,Matrix.star_eq_conjTranspose] at h
    convert h using 1 <;> congr 1
  refine ⟨D*(U : Matrix (Fin 3) (Fin 3) ℂ).conjTranspose,?_⟩
  calc
    D*(U : Matrix (Fin 3) (Fin 3) ℂ).conjTranspose*M*
        (D*(U : Matrix (Fin 3) (Fin 3) ℂ).conjTranspose).conjTranspose=
      D*((U : Matrix (Fin 3) (Fin 3) ℂ).conjTranspose*M*(U : Matrix (Fin 3) (Fin 3) ℂ))*D := by
        rw [Matrix.conjTranspose_mul,Matrix.conjTranspose_conjTranspose,hDH]
        noncomm_ring
    _=D*Matrix.diagonal (fun i => (d i : ℂ))*D := by rw [hspectral]
    _=1 := hdiag

theorem source_cubic_actual_congruence_hermitian (V X : Matrix (Fin 3) (Fin 3) ℂ) (hX : X.IsHermitian) :
    (V*X*V.conjTranspose).IsHermitian := by
  change (V*X*V.conjTranspose).conjTranspose=V*X*V.conjTranspose
  change X.conjTranspose=X at hX
  rw [Matrix.conjTranspose_mul,Matrix.conjTranspose_mul,Matrix.conjTranspose_conjTranspose,hX]
  noncomm_ring

theorem source_cubic_actual_congruence_sum (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (V : Matrix (Fin 3) (Fin 3) ℂ) (hV : V*(∑ i,A i)*V.conjTranspose=1) :
    (∑ i,V*A i*V.conjTranspose)=1 := by
  simpa only [Matrix.mul_sum,Matrix.sum_mul] using hV

end CoefficientStability
