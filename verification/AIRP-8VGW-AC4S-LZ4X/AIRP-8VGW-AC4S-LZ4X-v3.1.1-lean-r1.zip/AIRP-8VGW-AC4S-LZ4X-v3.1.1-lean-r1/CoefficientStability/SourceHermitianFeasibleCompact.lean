import CoefficientStability.SourceOriginalCubicLocalCommutativity
import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Order

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 3000000
set_option backward.isDefEq.respectTransparency false

theorem source_hermitian_feasible_closed {n : ℕ} (t : Fin n → ℝ) : IsClosed (hermitianFeasibleTuples t) := by
  have hP : IsClosed {A : Fin n → Matrix (Fin n) (Fin n) ℂ | ∀ i,(A i).PosSemidef} :=
    by
      rw [Set.ofPred_forall]
      apply isClosed_iInter
      intro i
      have hc : IsClosed {X : Matrix (Fin n) (Fin n) ℂ | X.PosSemidef} := Matrix.posSemidef_is_closed
      exact hc.preimage (show Continuous (fun A : Fin n → Matrix (Fin n) (Fin n) ℂ => A i) from continuous_apply i)
  have hT : IsClosed {A : Fin n → Matrix (Fin n) (Fin n) ℂ | ∀ i,Matrix.trace (A i)=(t i : ℂ)} :=
    by
      rw [Set.ofPred_forall]
      apply isClosed_iInter
      intro i
      exact isClosed_eq (show Continuous (fun A : Fin n → Matrix (Fin n) (Fin n) ℂ => Matrix.trace (A i)) by fun_prop) continuous_const
  have hN : IsClosed {A : Fin n → Matrix (Fin n) (Fin n) ℂ | (∑ i,A i)=1} :=
    isClosed_eq (by fun_prop) continuous_const
  have he : hermitianFeasibleTuples t=
      {A : Fin n → Matrix (Fin n) (Fin n) ℂ | ∀ i,(A i).PosSemidef} ∩
      ({A | ∀ i,Matrix.trace (A i)=(t i : ℂ)} ∩ {A | (∑ i,A i)=1}) := by
    ext A
    constructor
    · intro hA
      exact ⟨fun i => (hA.1 i).2.1,fun i => (hA.1 i).2.2,hA.2⟩
    · rintro ⟨hP,hT,hN⟩
      exact ⟨fun i => ⟨(hP i).isHermitian,hP i,hT i⟩,hN⟩
  rw [he]
  exact hP.inter (hT.inter hN)

theorem source_hermitian_feasible_component_le_one {n : ℕ} (t : Fin n → ℝ)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ) (hA : A ∈ hermitianFeasibleTuples t) (i : Fin n) : A i ≤ 1 := by
  have h := Finset.single_le_sum (fun j _ => (hA.1 j).2.1.nonneg) (Finset.mem_univ i)
  simpa only [hA.2] using h

theorem source_hermitian_feasible_component_norm_le_one {n : ℕ} (t : Fin n → ℝ)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ) (hA : A ∈ hermitianFeasibleTuples t) (i : Fin n) : ‖A i‖ ≤ 1 := by
  exact (CStarAlgebra.norm_le_one_iff_of_nonneg (A i) (hA.1 i).2.1.nonneg).mpr
    (source_hermitian_feasible_component_le_one t A hA i)

theorem source_hermitian_feasible_compact {n : ℕ} (t : Fin n → ℝ) : IsCompact (hermitianFeasibleTuples t) := by
  apply (isCompact_closedBall (0 : Fin n → Matrix (Fin n) (Fin n) ℂ) 1).of_isClosed_subset
    (source_hermitian_feasible_closed t)
  intro A hA
  rw [Metric.mem_closedBall,dist_zero_right]
  exact (pi_norm_le_iff_of_nonneg (by norm_num : (0 : ℝ) ≤ 1)).mpr
    (source_hermitian_feasible_component_norm_le_one t A hA)

theorem source_hermitian_mixed_objective_continuous {n : ℕ} :
    Continuous (hermitianMixedObjective : (Fin n → Matrix (Fin n) (Fin n) ℂ) → ℝ) :=
  Complex.continuous_re.comp genericMixedDiscriminant_continuous

theorem source_cubic_global_minimum_exists (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (hp : ∀ i,0 < t i) :
    ∃ A ∈ hermitianFeasibleTuples t,IsMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A :=
  (source_hermitian_feasible_compact t).exists_isMinOn
    ⟨complexReferenceTuple t,(source_cubic_strict_feasible_reference t ht hp).1⟩
    source_hermitian_mixed_objective_continuous.continuousOn

theorem source_cubic_commuting_global_minimum_exists (t : Fin 3 → ℝ)
    (ht : (∑ i,t i)=3) (hp : ∀ i,0 < t i) :
    ∃ A ∈ hermitianFeasibleTuples t,IsMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A ∧
      ∀ i j,A i*A j=A j*A i := by
  obtain ⟨A,hA,hm⟩ := source_cubic_global_minimum_exists t ht hp
  exact ⟨A,hA,hm,source_original_cubic_local_minimum_pairwise_commutation t ht hp A hA hm.isLocalMinOn⟩

end CoefficientStability
