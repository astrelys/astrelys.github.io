import CoefficientStability.MixedTaylorSeries
import CoefficientStability.TupleFrobeniusNorm

noncomputable section
open scoped BigOperators Matrix.Norms.Elementwise Topology
namespace CoefficientStability
variable {n : ℕ}

theorem scalar_series_one_zero (t : Fin n → ℝ) (hn : 2≤n) (htpos : ∀ i,0<t i)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ) (htrace : ∀ i,Matrix.trace (A i)=0) :
    (actualMixedSeries (complexReferenceTuple t)) 1 (fun _ => A)=0 := by
  rw [actualMixedSeries_one,actual_mixed_curve_derivative]
  simp only [zero_smul,add_zero]
  rw [← actual_mixed_first_derivative]
  exact paper_scalar_stationarity t htpos hn A htrace

theorem scalar_series_two_real (t : Fin n → ℝ) (hn : 2≤n) (htpos : ∀ i,0<t i)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ) (htrace : ∀ i,Matrix.trace (A i)=0)
    (hA : ∀ i,(A i).IsHermitian) :
    ((actualMixedSeries (complexReferenceTuple t)) 2 (fun _ => A)).re=sourceHessianCandidate t A/2 := by
  have h := congrArg Complex.re (actualMixedSeries_two (complexReferenceTuple t) A)
  rw [paper_actual_scalar_hessian t hn htpos A htrace hA] at h
  norm_num [Complex.mul_re] at h
  linarith

theorem scalar_series_partialSum_three_real (t : Fin n → ℝ) (hn : 2≤n) (htpos : ∀ i,0<t i)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ) (htrace : ∀ i,Matrix.trace (A i)=0)
    (hA : ∀ i,(A i).IsHermitian) :
    ((actualMixedSeries (complexReferenceTuple t)).partialSum 3 A).re=
      hermitianMixedObjective (complexReferenceTuple t)+sourceHessianCandidate t A/2 := by
  simp only [FormalMultilinearSeries.partialSum,Finset.sum_range_succ,Finset.sum_range_zero,
    zero_add,Complex.add_re,actualMixedSeries_zero,scalar_series_one_zero t hn htpos A htrace,
    Complex.zero_re,add_zero,scalar_series_two_real t hn htpos A htrace hA,hermitianMixedObjective]

theorem actual_cubic_remainder_bound (A : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    ∃ C e : ℝ,0<C ∧ 0<e ∧ ∀ H : Fin n → Matrix (Fin n) (Fin n) ℂ,‖H‖<e →
      ‖complexMixedDiscriminant (A+H)-(actualMixedSeries A).partialSum 3 H‖≤C*‖H‖^3 := by
  obtain ⟨C,hC⟩ := (actualMixedSeries_cubic_remainder A).bound
  have hbound : ∀ᶠ H : Fin n → Matrix (Fin n) (Fin n) ℂ in 𝓝 0,
      ‖complexMixedDiscriminant (A+H)-(actualMixedSeries A).partialSum 3 H‖≤(|C|+1)*‖H‖^3 := by
    filter_upwards [hC] with H hH
    have hmul : C*‖H‖^3≤(|C|+1)*‖H‖^3 :=
      mul_le_mul_of_nonneg_right (by linarith [le_abs_self C]) (by positivity)
    exact le_trans (by simpa only [Real.norm_eq_abs,abs_pow,abs_norm] using hH) hmul
  obtain ⟨e,he,hnear⟩ := Metric.eventually_nhds_iff.mp hbound
  refine ⟨|C|+1,e,by positivity,he,?_⟩
  intro H hH
  exact hnear (y := H) (by simpa only [dist_zero_right] using hH)

end CoefficientStability
