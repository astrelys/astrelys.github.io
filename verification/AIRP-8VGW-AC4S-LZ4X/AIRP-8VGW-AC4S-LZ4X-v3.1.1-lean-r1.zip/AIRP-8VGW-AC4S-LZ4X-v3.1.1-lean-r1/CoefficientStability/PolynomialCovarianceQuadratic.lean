import CoefficientStability.PolynomialDirectionalDerivative
import CoefficientStability.RoutingVariance

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem coefficientCovariance_quadratic_formula (p : MvPolynomial (Fin n) ℝ) (t v : Fin n → ℝ)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    matrixQuadratic (coefficientCovariance p t) v=
      hessianQuadraticAtOne p v+(∑ i,t i*v i^2)-(∑ i,t i*v i)^2 := by
  classical
  simp only [matrixQuadratic,actual_coefficient_covariance p t hnorm hgrad,
    sub_mul,add_mul,Finset.sum_sub_distrib,Finset.sum_add_distrib]
  have hdiag : (∑ i,∑ j,(if i=j then t i else 0)*v i*v j)=∑ i,t i*v i^2 := by
    apply Finset.sum_congr rfl
    intro i hi
    rw [Finset.sum_eq_single i]
    · simp only [ite_true]
      ring
    · intro j hj hji
      simp [Ne.symm hji]
    · simp
  have houter : (∑ i,∑ j,t i*t j*v i*v j)=(∑ i,t i*v i)^2 := by
    rw [pow_two,Finset.sum_mul_sum]
    apply Finset.sum_congr rfl
    intro i hi
    apply Finset.sum_congr rfl
    intro j hj
    ring
  rw [hdiag,houter]
  rfl

theorem matrixSubstitution_mulVec_one (M : Matrix (Fin n) (Fin n) ℝ)
    (hrow : ∀ i,∑ j,M i j=1) : M.mulVec (fun _ => 1)=fun _ => 1 := by
  ext i
  simpa only [Matrix.mulVec,dotProduct,mul_one] using hrow i

theorem matrixSubstitution_normalized (M : Matrix (Fin n) (Fin n) ℝ) (p : MvPolynomial (Fin n) ℝ)
    (hrow : ∀ i,∑ j,M i j=1) (hnorm : MvPolynomial.eval (fun _ => 1) p=1) :
    MvPolynomial.eval (fun _ => 1) (matrixSubstitution M p)=1 := by
  rw [matrixSubstitution_eval,matrixSubstitution_mulVec_one M hrow,hnorm]

theorem matrixSubstitution_gradient_dot (M : Matrix (Fin n) (Fin n) ℝ)
    (p : MvPolynomial (Fin n) ℝ) (hrow : ∀ i,∑ j,M i j=1) (v : Fin n → ℝ) :
    (∑ j,MvPolynomial.eval (fun _ => 1) (pderiv j (matrixSubstitution M p))*v j)=
      ∑ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)*(M.mulVec v) i := by
  have h := congrArg (MvPolynomial.eval (fun _ : Fin n => (1 : ℝ)))
    (polynomialDirectional_linear_substitution M v p)
  rw [matrixSubstitution_eval,matrixSubstitution_mulVec_one M hrow,
    polynomialDirectional_eval,polynomialDirectional_eval] at h
  simpa only [mul_comm] using h

theorem matrixSubstitution_hessian_quadratic (M : Matrix (Fin n) (Fin n) ℝ)
    (p : MvPolynomial (Fin n) ℝ) (hrow : ∀ i,∑ j,M i j=1) (v : Fin n → ℝ) :
    hessianQuadraticAtOne (matrixSubstitution M p) v=hessianQuadraticAtOne p (M.mulVec v) := by
  rw [← polynomialDirectional_second_eval,polynomialDirectional_linear_substitution,
    polynomialDirectional_linear_substitution,matrixSubstitution_eval,
    matrixSubstitution_mulVec_one M hrow,polynomialDirectional_second_eval]

theorem matrixSubstitution_covariance_quadratic (M : Matrix (Fin n) (Fin n) ℝ)
    (p : MvPolynomial (Fin n) ℝ) (hrow : ∀ i,∑ j,M i j=1)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (v : Fin n → ℝ) :
    let t := fun i => MvPolynomial.eval (fun _ => 1) (pderiv i p)
    let q := matrixSubstitution M p
    let s := fun j => MvPolynomial.eval (fun _ => 1) (pderiv j q)
    matrixQuadratic (coefficientCovariance q s) v=
      matrixQuadratic (coefficientCovariance p t) (M.mulVec v)+
        ∑ i,t i*categoricalVariance (fun j => M i j) v := by
  dsimp only
  rw [coefficientCovariance_quadratic_formula _ _ v (matrixSubstitution_normalized M p hrow hnorm) (fun i => rfl),
    coefficientCovariance_quadratic_formula _ _ (M.mulVec v) hnorm (fun i => rfl),
    matrixSubstitution_hessian_quadratic M p hrow v,matrixSubstitution_gradient_dot M p hrow v]
  have h2 := matrixSubstitution_gradient_dot M p hrow (fun j => v j^2)
  rw [h2]
  simp only [categoricalVariance,Matrix.mulVec,dotProduct,mul_sub,Finset.sum_sub_distrib]
  ring

end CoefficientStability
