import CoefficientStability.SourceCubicMatrixObjective
import Mathlib.Analysis.Complex.RealDeriv

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 3000000
set_option backward.isDefEq.respectTransparency false

def sourceCubicMatrixSummand (t : ℝ) (X : Matrix (Fin 3) (Fin 3) ℂ) : ℂ :=
  (2/3 : ℂ)*Matrix.trace (X^3)+((1/2 : ℂ)-(t : ℂ))*Matrix.trace (X^2)
def sourceCubicMatrixGradient (t : ℝ) (X : Matrix (Fin 3) (Fin 3) ℂ) : Matrix (Fin 3) (Fin 3) ℂ :=
  (2 : ℂ) • X^2+(1-2*(t : ℂ)) • X

theorem source_complex_trace_square_affine (X Y : Matrix (Fin 3) (Fin 3) ℂ) (s : ℂ) :
    Matrix.trace ((X+s • Y)^2)=Matrix.trace (X^2)+2*s*Matrix.trace (X*Y)+s^2*Matrix.trace (Y^2) := by
  norm_num [Matrix.trace,Matrix.mul_apply,Matrix.add_apply,Matrix.smul_apply,Fin.sum_univ_succ,pow_succ,smul_eq_mul]
  ring

theorem source_complex_trace_cube_affine (X Y : Matrix (Fin 3) (Fin 3) ℂ) (s : ℂ) :
    Matrix.trace ((X+s • Y)^3)=Matrix.trace (X^3)+3*s*Matrix.trace (X^2*Y)+
      3*s^2*Matrix.trace (X*Y^2)+s^3*Matrix.trace (Y^3) := by
  norm_num [Matrix.trace,Matrix.mul_apply,Matrix.add_apply,Matrix.smul_apply,Fin.sum_univ_succ,pow_succ,smul_eq_mul]
  ring

theorem source_cubic_matrix_gradient_trace (t : ℝ) (X Y : Matrix (Fin 3) (Fin 3) ℂ) :
    Matrix.trace (sourceCubicMatrixGradient t X*Y)=
      2*Matrix.trace (X^2*Y)+(1-2*(t : ℂ))*Matrix.trace (X*Y) := by
  simp only [sourceCubicMatrixGradient,add_mul,smul_mul_assoc,Matrix.trace_add,Matrix.trace_smul,smul_eq_mul]

theorem source_cubic_matrix_summand_affine (t : ℝ) (X Y : Matrix (Fin 3) (Fin 3) ℂ) (s : ℂ) :
    sourceCubicMatrixSummand t (X+s • Y)=sourceCubicMatrixSummand t X+
      s*Matrix.trace (sourceCubicMatrixGradient t X*Y)+
      s^2*(2*Matrix.trace (X*Y^2)+((1/2 : ℂ)-(t : ℂ))*Matrix.trace (Y^2))+
      s^3*((2/3 : ℂ)*Matrix.trace (Y^3)) := by
  unfold sourceCubicMatrixSummand
  rw [source_complex_trace_square_affine,source_complex_trace_cube_affine,source_cubic_matrix_gradient_trace]
  ring

theorem source_cubic_matrix_summand_hasDerivAt (t : ℝ) (X Y : Matrix (Fin 3) (Fin 3) ℂ) :
    HasDerivAt (fun s : ℂ => sourceCubicMatrixSummand t (X+s • Y))
      (Matrix.trace (sourceCubicMatrixGradient t X*Y)) 0 := by
  have he : (fun s : ℂ => sourceCubicMatrixSummand t (X+s • Y))=
      (fun s => sourceCubicMatrixSummand t X+s*Matrix.trace (sourceCubicMatrixGradient t X*Y)+
        s^2*(2*Matrix.trace (X*Y^2)+((1/2 : ℂ)-(t : ℂ))*Matrix.trace (Y^2))+
        s^3*((2/3 : ℂ)*Matrix.trace (Y^3))) := funext (source_cubic_matrix_summand_affine t X Y)
  rw [he]
  have h := (((hasDerivAt_const (0 : ℂ) (sourceCubicMatrixSummand t X)).add
    ((hasDerivAt_id (0 : ℂ)).mul_const (Matrix.trace (sourceCubicMatrixGradient t X*Y)))).add
    (((hasDerivAt_id (0 : ℂ)).pow 2).mul_const
      (2*Matrix.trace (X*Y^2)+((1/2 : ℂ)-(t : ℂ))*Matrix.trace (Y^2)))).add
    (((hasDerivAt_id (0 : ℂ)).pow 3).mul_const ((2/3 : ℂ)*Matrix.trace (Y^3)))
  convert h using 1 <;> norm_num
  funext s
  rfl

theorem source_cubic_matrix_summand_real_hasDerivAt (t : ℝ) (X Y : Matrix (Fin 3) (Fin 3) ℂ) :
    HasDerivAt (fun s : ℝ => (sourceCubicMatrixSummand t (X+(s : ℂ) • Y)).re)
      (Matrix.trace (sourceCubicMatrixGradient t X*Y)).re 0 := by
  simpa using (source_cubic_matrix_summand_hasDerivAt t X Y).real_of_complex

end CoefficientStability
