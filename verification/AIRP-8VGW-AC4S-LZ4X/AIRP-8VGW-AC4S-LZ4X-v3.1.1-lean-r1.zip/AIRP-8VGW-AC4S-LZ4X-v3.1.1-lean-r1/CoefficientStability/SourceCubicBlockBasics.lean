import CoefficientStability.SourceCubicScalarSpectralBranch

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 2600000
set_option backward.isDefEq.respectTransparency false

def sourceTwoTraceQuadratic (V : Matrix (Fin 2) (Fin 2) ℂ) : ℝ := (Matrix.trace (V*V)).re/2
def sourceTwoTracePair (V W : Matrix (Fin 2) (Fin 2) ℂ) : ℝ := (Matrix.trace (V*W)).re/2

theorem source_complex_two_det_trace (B : Matrix (Fin 2) (Fin 2) ℂ) :
    B.det=((Matrix.trace B)^2-Matrix.trace (B^2))/2 := by
  norm_num [Matrix.det_fin_two,Matrix.trace,Matrix.mul_apply,Fin.sum_univ_succ,pow_succ]
  ring

theorem source_complex_two_trace_cube (B : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix.trace (B^3)=(3/2 : ℂ)*Matrix.trace B*Matrix.trace (B^2)-(1/2 : ℂ)*(Matrix.trace B)^3 := by
  norm_num [Matrix.trace,Matrix.mul_apply,Fin.sum_univ_succ,pow_succ]
  ring

theorem source_complex_two_traceless_cube (V : Matrix (Fin 2) (Fin 2) ℂ) (ht : Matrix.trace V=0) :
    Matrix.trace (V^3)=0 := by rw [source_complex_two_trace_cube,ht];ring

theorem source_hermitian_two_psd_trace_det (B : Matrix (Fin 2) (Fin 2) ℂ) (hB : B.IsHermitian) :
    B.PosSemidef ↔ 0 ≤ Matrix.trace B ∧ 0 ≤ B.det := by
  constructor
  · intro hP
    exact ⟨hP.trace_nonneg,hP.det_nonneg⟩
  · rintro ⟨ht,hd⟩
    have htrace := hB.trace_eq_sum_eigenvalues
    norm_num only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero] at htrace
    change Matrix.trace B=(hB.eigenvalues 0 : ℂ)+(hB.eigenvalues 1 : ℂ) at htrace
    rw [htrace] at ht
    have hsum := (Complex.nonneg_iff.mp ht).1
    norm_num only [Complex.add_re,Complex.ofReal_re] at hsum
    have hdet := hB.det_eq_prod_eigenvalues
    norm_num only [Fin.prod_univ_succ,Fin.prod_univ_zero,mul_one] at hdet
    change B.det=(hB.eigenvalues 0 : ℂ)*(hB.eigenvalues 1 : ℂ) at hdet
    rw [hdet] at hd
    have hprod := (Complex.nonneg_iff.mp hd).1
    norm_num [Complex.mul_re] at hprod
    apply hB.posSemidef_iff_eigenvalues_nonneg.mpr
    intro i
    fin_cases i
    · change 0 ≤ hB.eigenvalues 0
      by_contra hn
      have hx : hB.eigenvalues 0 < 0 := lt_of_not_ge hn
      have hy : 0 < hB.eigenvalues 1 := by linarith
      have hp := mul_neg_of_neg_of_pos hx hy
      linarith
    · change 0 ≤ hB.eigenvalues 1
      by_contra hn
      have hy : hB.eigenvalues 1 < 0 := lt_of_not_ge hn
      have hx : 0 < hB.eigenvalues 0 := by linarith
      have hp := mul_neg_of_pos_of_neg hx hy
      linarith

theorem source_complex_two_centered_det (z : ℂ) (V : Matrix (Fin 2) (Fin 2) ℂ) :
    (z • 1+V).det=z^2+z*Matrix.trace V+V.det := by
  norm_num [Matrix.det_fin_two,Matrix.trace,Matrix.smul_apply,Matrix.add_apply,Matrix.one_apply,Fin.sum_univ_succ,smul_eq_mul]
  ring

theorem source_two_trace_quadratic_nonnegative (V : Matrix (Fin 2) (Fin 2) ℂ) (hV : V.IsHermitian) :
    0 ≤ sourceTwoTraceQuadratic V := by
  unfold sourceTwoTraceQuadratic
  rw [hermitian_trace_square_frobenius V hV]
  exact div_nonneg (complexFrobeniusSq_nonneg V) (by norm_num)

theorem source_two_trace_quadratic_positive (V : Matrix (Fin 2) (Fin 2) ℂ) (hV : V.IsHermitian) (hne : V≠0) :
    0 < sourceTwoTraceQuadratic V := by
  unfold sourceTwoTraceQuadratic
  rw [hermitian_trace_square_frobenius V hV]
  exact div_pos (complexFrobeniusSq_pos V hne) (by norm_num)

theorem source_hermitian_two_centered_determinant (b : ℝ) (V : Matrix (Fin 2) (Fin 2) ℂ)
    (hV : V.IsHermitian) (ht : Matrix.trace V=0) :
    (((b : ℂ)/2) • 1+V).det=((b^2/4-sourceTwoTraceQuadratic V : ℝ) : ℂ) := by
  have hr : Matrix.trace (V*V)=((Matrix.trace (V*V)).re : ℂ) := by
    apply Complex.ext
    · simp
    · simpa using source_hermitian_trace_product_im_zero V V hV hV
  rw [source_complex_two_centered_det,ht,mul_zero,add_zero,source_complex_two_det_trace,ht,pow_two V,hr]
  unfold sourceTwoTraceQuadratic
  push_cast
  ring

end CoefficientStability
