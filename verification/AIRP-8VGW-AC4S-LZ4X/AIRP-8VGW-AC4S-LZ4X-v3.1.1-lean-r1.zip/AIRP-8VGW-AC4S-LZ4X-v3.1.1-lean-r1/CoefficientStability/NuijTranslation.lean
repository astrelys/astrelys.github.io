import CoefficientStability.SmoothedRootSigns

noncomputable section
namespace CoefficientStability
variable {n : ℕ}

theorem nuij_step_comp_translation (P : Polynomial ℝ) (a ε : ℝ) :
    nuijUnivariateStep ε (P.comp (Polynomial.X+Polynomial.C a))=
      (nuijUnivariateStep ε P).comp (Polynomial.X+Polynomial.C a) := by
  simp only [nuijUnivariateStep,Polynomial.derivative_comp,Polynomial.derivative_add,
    Polynomial.derivative_X,Polynomial.derivative_C,add_zero,one_mul,
    Polynomial.add_comp,Polynomial.mul_comp,Polynomial.C_comp]

theorem nuij_iterate_comp_translation (P : Polynomial ℝ) (a ε : ℝ) (k : ℕ) :
    (nuijUnivariateStep ε)^[k] (P.comp (Polynomial.X+Polynomial.C a))=
      ((nuijUnivariateStep ε)^[k] P).comp (Polynomial.X+Polynomial.C a) := by
  induction k with
  | zero => rfl
  | succ k ih => rw [Function.iterate_succ_apply',ih,nuij_step_comp_translation,Function.iterate_succ_apply']

theorem source_line_base_translation (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ) (a : ℝ) :
    lineRestriction p (fun i => x i+a)=(lineRestriction p x).comp (Polynomial.X+Polynomial.C a) := by
  apply Polynomial.funext
  intro s
  rw [eval_lineRestriction_real,Polynomial.eval_comp,Polynomial.eval_add,Polynomial.eval_X,
    Polynomial.eval_C,eval_lineRestriction_real]
  apply congrArg (fun w : Fin n → ℝ => MvPolynomial.eval w p)
  funext i
  ring

theorem smoothed_source_line_base_translation (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (ε : ℝ) (x : Fin n → ℝ) (a : ℝ) :
    smoothedLineRestriction p N ε (fun i => x i+a)=
      (smoothedLineRestriction p N ε x).comp (Polynomial.X+Polynomial.C a) := by
  unfold smoothedLineRestriction
  rw [source_line_base_translation,nuij_iterate_comp_translation]

theorem smoothed_source_line_root_translation (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (ε : ℝ) (x : Fin n → ℝ) (a r : ℝ)
    (hr : (smoothedLineRestriction p N ε x).IsRoot r) :
    (smoothedLineRestriction p N ε (fun i => x i+a)).IsRoot (r-a) := by
  change (smoothedLineRestriction p N ε (fun i => x i+a)).eval (r-a)=0
  rw [smoothed_source_line_base_translation,Polynomial.eval_comp,Polynomial.eval_add,
    Polynomial.eval_X,Polynomial.eval_C,sub_add_cancel]
  exact hr

end CoefficientStability
