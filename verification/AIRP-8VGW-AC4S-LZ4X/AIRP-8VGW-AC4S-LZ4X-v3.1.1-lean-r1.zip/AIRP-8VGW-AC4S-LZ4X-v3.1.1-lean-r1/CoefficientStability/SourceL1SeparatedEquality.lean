import CoefficientStability.SourceL1BoundaryAlgebra

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1600000

theorem source_l1_separated_equality_profile (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b : ℝ)
    (hpos : ∀ q ∈ sourceSeparatedEntrySet,0 < sourceTernarySeparatedZeros t a b q.1 q.2)
    (hmin : IsMinOn Matrix.permanent (sourceTransportationPolytope t) (sourceTernarySeparatedZeros t a b))
    (hr : (∑ i,|t i-1|) ≤ sourceCubicEpsilon0)
    (hobj : Matrix.permanent (sourceTernarySeparatedZeros t a b)=sourceTernaryBaseline t) :
    ∃ r c : Equiv.Perm (Fin 3),sourcePermutedTraces t r=sourceL1ExceptionalTraces ∧
      sourcePermutedMatrix (sourceTernarySeparatedZeros t a b) r c=sourceL1BoundaryMatrix sourceCubicDStar := by
  obtain ⟨r,c,u,v,hu,hv,huv,htc,hmc⟩ := source_l1_every_separated_minimum_recovery t ht a b hpos hmin
  have hdist : sourceCubicDistance (sourceL1ChartD u v) (sourceL1ChartHeight u v) ≤ sourceCubicEpsilon0 := by
    rw [← source_l1_chart_actual_distance u v hu hv huv,← htc,source_permuted_l1_distance]
    exact hr
  have hgap := source_l1_chart_actual_gap u v hu hv huv
  rw [← hmc,← htc,source_permuted_permanent,source_permuted_ternary_baseline,hobj,sub_self] at hgap
  have hu1 := (source_l1_chart_denominator u v hu hv huv).2.1
  have hp : 0 < ((1+v)/2)*((1-u)/2)/9 := by positivity
  have hprod : (((1+v)/2)*((1-u)/2)/9)*sourceCubicH (sourceL1ChartD u v) (sourceL1ChartHeight u v)=0 := hgap.symm
  have hH : sourceCubicH (sourceL1ChartD u v) (sourceL1ChartHeight u v)=0 :=
    (mul_eq_zero.mp hprod).resolve_left (ne_of_gt hp)
  obtain ⟨hlower,heq⟩ := source_original_l1_chart_sharp_distance u v hu hv huv hH.le
  obtain ⟨hd,hh⟩ := heq.mp (le_antisymm hdist hlower)
  obtain ⟨htp,hmp⟩ := source_l1_zero_height_profile u v hu hv huv hh
  rw [hd,source_l1_boundary_dstar_trace_profile] at htp
  rw [hd] at hmp
  exact ⟨r,c,htc.trans htp,hmc.trans hmp⟩

end CoefficientStability
