import CoefficientStability.PureCapacityAttainment
import CoefficientStability.TiltMatrixSubstitution

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def centeredLogVector (x : Fin n → ℝ) (i : Fin n) : ℝ :=
  Real.log (x i)-(∑ j,Real.log (x j))/(n : ℝ)

theorem centeredLogVector_sum (hn : 0<n) (x : Fin n → ℝ) :
    (∑ i,centeredLogVector x i)=0 := by
  have hnr : (n : ℝ)≠0 := by exact_mod_cast (ne_of_gt hn)
  simp only [centeredLogVector,Finset.sum_sub_distrib,Finset.sum_const,Finset.card_univ,
    Fintype.card_fin,nsmul_eq_mul]
  field_simp
  ring

theorem centeredLogVector_exp (x : Fin n → ℝ) (hx : ∀ i,0<x i) (i : Fin n) :
    Real.exp (centeredLogVector x i)=
      Real.exp (-(∑ j,Real.log (x j))/(n : ℝ))*x i := by
  rw [centeredLogVector,sub_eq_add_neg,Real.exp_add,Real.exp_log (hx i)]
  rw [neg_div]
  ring

theorem zero_sum_exp_product (u : Fin n → ℝ) (hu : ∑ i,u i=0) :
    (∏ i,Real.exp (u i))=1 := by
  rw [← Real.exp_sum,hu,Real.exp_zero]

theorem centeredLogVector_capacity_eval (hn : 0<n) (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (x : Fin n → ℝ) (hx : ∀ i,0<x i) :
    MvPolynomial.eval (fun i => Real.exp (centeredLogVector x i)) p=
      MvPolynomial.eval x p/(∏ i,x i) := by
  have he : (fun i => Real.exp (centeredLogVector x i))=
      (fun i => Real.exp (-(∑ j,Real.log (x j))/(n : ℝ))*x i) :=
    funext (centeredLogVector_exp x hx)
  have h := homogeneous_capacity_ratio_scale p hp
    (Real.exp (-(∑ j,Real.log (x j))/(n : ℝ))) (Real.exp_pos _) x
  rw [← he,zero_sum_exp_product _ (centeredLogVector_sum hn x),div_one] at h
  exact h

theorem positive_pure_capacity_centered_field (hn : 0<n) (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (hc : ∀ g,0≤p.coeff g)
    (hpure : ∀ i,0<p.coeff (Finsupp.single i n)) :
    ∃ u : Fin n → ℝ,(∑ i,u i=0) ∧
      multivariatePositiveCapacity p=MvPolynomial.eval (fun i => Real.exp (u i)) p := by
  obtain ⟨x,hx,hs,hcap⟩ := positive_pure_capacity_attained hn p hp hc hpure
  exact ⟨centeredLogVector x,centeredLogVector_sum hn x,
    hcap.trans (centeredLogVector_capacity_eval hn p hp x hx).symm⟩

end CoefficientStability
