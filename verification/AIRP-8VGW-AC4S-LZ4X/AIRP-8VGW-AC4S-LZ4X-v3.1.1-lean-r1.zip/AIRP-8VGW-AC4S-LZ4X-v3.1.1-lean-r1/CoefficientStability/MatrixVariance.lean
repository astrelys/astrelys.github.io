import CoefficientStability.RootHessianBridge
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.RingTheory.MvPolynomial.EulerIdentity

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem eval_one_mixed_second_symm (p : MvPolynomial (Fin n) ℝ) (i j : Fin n) :
    MvPolynomial.eval (fun _ => 1) (pderiv i (pderiv j p)) =
      MvPolynomial.eval (fun _ => 1) (pderiv j (pderiv i p)) := by
  conv_lhs => rw [p.as_sum]
  conv_rhs => rw [p.as_sum]
  simp only [map_sum, eval_one_mixed_second_monomial]
  apply Finset.sum_congr rfl
  intro g hg
  by_cases hij : i=j
  · subst j; rfl
  · simp only [hij, Ne.symm hij, ite_false, sub_zero]
    ring

theorem deficitMatrix_isHermitian (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) :
    (deficitMatrix p t N).IsHermitian := by
  ext i j
  change deficitMatrix p t N j i = deficitMatrix p t N i j
  unfold deficitMatrix
  rw [eval_one_mixed_second_symm p j i]
  ring

theorem deficitMatrix_posSemidef
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ)
    (hN : 2 ≤ N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p) = t i) :
    (deficitMatrix p t N).PosSemidef := by
  apply Matrix.PosSemidef.of_dotProduct_mulVec_nonneg (deficitMatrix_isHermitian p t N)
  intro x
  have h := deficitMatrix_quadratic_nonneg p t N x hN hp hnorm hstable hgrad
  have he : dotProduct (star x) ((deficitMatrix p t N).mulVec x) = matrixQuadratic (deficitMatrix p t N) x := by
    simp only [dotProduct, Matrix.mulVec, Pi.star_apply, star_trivial, matrixQuadratic, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i hi
    apply Finset.sum_congr rfl
    intro j hj
    ring
  rw [he]
  exact h

theorem hessian_row_sum (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hN : 1 ≤ N) (hp : p.IsHomogeneous N) (i : Fin n) :
    (∑ j, MvPolynomial.eval (fun _ => 1) (pderiv j (pderiv i p))) =
      ((N : ℝ)-1) * MvPolynomial.eval (fun _ => 1) (pderiv i p) := by
  have he := (hp.pderiv (i := i)).sum_X_mul_pderiv
  have hv := congrArg (MvPolynomial.eval (fun _ => (1 : ℝ))) he
  simpa [Nat.cast_sub hN, nsmul_eq_mul] using hv

theorem deficitMatrix_mulVec_one
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ)
    (hN : 1 ≤ N) (hp : p.IsHomogeneous N) (ht : ∑ i, t i = N)
    (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p) = t i) :
    (deficitMatrix p t N).mulVec (fun _ => 1) = 0 := by
  ext i
  simp only [Matrix.mulVec, dotProduct, mul_one, Pi.zero_apply]
  unfold deficitMatrix
  rw [Finset.sum_sub_distrib]
  have he := hessian_row_sum p N hN hp i
  have he' : (∑ j, MvPolynomial.eval (fun _ => 1) (pderiv i (pderiv j p))) =
      ((N : ℝ)-1) * t i := by
    calc
      _ = ∑ j, MvPolynomial.eval (fun _ => 1) (pderiv j (pderiv i p)) := by
        apply Finset.sum_congr rfl
        intro j hj
        exact eval_one_mixed_second_symm p i j
      _ = _ := by rw [he, hgrad i]
  simp only [div_eq_mul_inv]
  rw [← Finset.mul_sum, ← Finset.sum_mul]
  rw [ht, he']
  have hn : (N : ℝ) ≠ 0 := by exact_mod_cast (by omega : N ≠ 0)
  field_simp
  ring

end CoefficientStability
