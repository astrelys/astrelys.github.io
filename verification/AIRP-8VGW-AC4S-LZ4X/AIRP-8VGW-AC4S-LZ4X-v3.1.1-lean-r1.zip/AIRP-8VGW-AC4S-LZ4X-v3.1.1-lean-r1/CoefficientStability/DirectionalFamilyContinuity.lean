import CoefficientStability.RealSplitPositiveComponent

noncomputable section
namespace CoefficientStability
variable {n N : ℕ}

theorem affineDirectionalRestriction_coefficient_continuous (p : MvPolynomial (Fin n) ℝ)
    (b : Fin n → ℝ) : ∀ k,Continuous (fun x : Fin n → ℝ => (affineDirectionalRestriction p x b).coeff k) := by
  induction p using MvPolynomial.induction_on with
  | C c =>
    intro k
    simpa only [affineDirectionalRestriction,MvPolynomial.eval₂_C] using
      (continuous_const : Continuous (fun _ : Fin n → ℝ => (Polynomial.C c).coeff k))
  | add p q hp hq =>
    intro k
    convert! (hp k).add (hq k) using 1
    funext x
    simp only [affineDirectionalRestriction,MvPolynomial.eval₂_add,Polynomial.coeff_add] <;> rfl
  | mul_X p i hp =>
    have hQ (k : ℕ) : Continuous (fun x : Fin n → ℝ =>
        (Polynomial.C (b i)*Polynomial.X+Polynomial.C (x i)).coeff k) := by
      simp only [Polynomial.coeff_add,Polynomial.coeff_C]
      by_cases hk : k=0
      · subst k
        simpa using (continuous_apply i : Continuous (fun x : Fin n → ℝ => x i))
      · simpa [hk] using (continuous_const : Continuous (fun _ : Fin n → ℝ =>
          b i*Polynomial.X.coeff k))
    intro k
    have h := polynomial_family_mul_coeff_continuous
      (fun x : Fin n → ℝ => affineDirectionalRestriction p x b)
      (fun x => Polynomial.C (b i)*Polynomial.X+Polynomial.C (x i)) hp hQ k
    simpa only [affineDirectionalRestriction,MvPolynomial.eval₂_mul,MvPolynomial.eval₂_X] using h

def normalizedDirectionalRestriction (p : MvPolynomial (Fin n) ℝ) (b x : Fin n → ℝ) : Polynomial ℝ :=
  Polynomial.C (MvPolynomial.eval b p)⁻¹*affineDirectionalRestriction p x b

theorem normalizedDirectionalRestriction_properties (p : MvPolynomial (Fin n) ℝ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N) (x : Fin n → ℝ) :
    (normalizedDirectionalRestriction p b x).Monic ∧
      (normalizedDirectionalRestriction p b x).Splits ∧
      (normalizedDirectionalRestriction p b x).natDegree=N := by
  have hc := ne_of_gt (positiveSpectralCone_eval_pos p hp hs hnorm b hb)
  obtain ⟨hsp,hd,hlc⟩ := source_spectral_cone_direction_splits p hN hp hs hnorm b hb x
  refine ⟨?_,Polynomial.Splits.mul (Polynomial.Splits.C _) hsp,?_⟩
  · apply Polynomial.monic_C_mul_of_mul_leadingCoeff_eq_one
    rw [hlc,inv_mul_cancel₀ hc]
  · rw [normalizedDirectionalRestriction,Polynomial.natDegree_C_mul (inv_ne_zero hc),hd]

theorem normalizedDirectionalRestriction_coeff_continuous (p : MvPolynomial (Fin n) ℝ)
    (b : Fin n → ℝ) (k : ℕ) :
    Continuous (fun x : Fin n → ℝ => (normalizedDirectionalRestriction p b x).coeff k) := by
  simpa only [normalizedDirectionalRestriction,Polynomial.coeff_C_mul] using
    (affineDirectionalRestriction_coefficient_continuous p b k).const_mul (MvPolynomial.eval b p)⁻¹

theorem normalizedDirectionalRestriction_eval (p : MvPolynomial (Fin n) ℝ)
    (b x : Fin n → ℝ) (t : ℝ) :
    (normalizedDirectionalRestriction p b x).eval t=
      (MvPolynomial.eval b p)⁻¹*MvPolynomial.eval (fun i => x i+t*b i) p := by
  rw [normalizedDirectionalRestriction,Polynomial.eval_mul,Polynomial.eval_C,affineDirectionalRestriction_eval]

end CoefficientStability
