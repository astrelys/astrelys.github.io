import CoefficientStability.SourceL1RationalMatrix
import CoefficientStability.SourceL1RationalDensity

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 5000000

theorem source_l1_boundary_family_strict_after_star (d : ℝ)
    (hd : sourceCubicDStar<d) (hd8 : d<1/8) :
    Matrix.permanent (sourceL1BoundaryMatrix d)<sourceTernaryBaseline (sourceL1BoundaryTraces d) := by
  have hd0 : 0<d := source_cubic_dstar_bounds.1.trans hd
  have hA : 1-10*d-12*d^2<0 := by
    have he : 1-10*d-12*d^2= -(d-sourceCubicDStar)*(10+12*(d+sourceCubicDStar)) := by
      linear_combination source_cubic_dstar_equation
    rw [he]
    exact mul_neg_of_neg_of_pos (by linarith) (by linarith [source_cubic_dstar_bounds.1])
  have hg := source_l1_boundary_family_gap d hd0.le
  have hn : (1-d)*(1+2*d)*(1-10*d-12*d^2)/36<0 :=
    div_neg_of_neg_of_pos (mul_neg_of_pos_of_neg (mul_pos (by linarith) (by linarith)) hA) (by norm_num)
  linarith

theorem source_l1_full_rational_sharpness (R : ℝ) (hR : sourceCubicEpsilon0<R) :
    ∃ η : ℚ,3<(η : ℝ) ∧ (η : ℝ)<sourceL1EtaStar ∧
      (fun i j => (sourceL1RationalMatrixRat η i j : ℝ))∈
        sourceTransportationPolytope (fun i => (sourceL1RationalTracesRat η i : ℝ)) ∧
      (∀ i,0<(sourceL1RationalTracesRat η i : ℝ)) ∧
      (∑ i,|(sourceL1RationalTracesRat η i : ℝ)-1|)<R ∧
      Matrix.permanent (fun i j => (sourceL1RationalMatrixRat η i j : ℝ))<
        sourceTernaryBaseline (fun i => (sourceL1RationalTracesRat η i : ℝ)) := by
  obtain ⟨η,hη,hstar,hd0,hd8,hF⟩ := source_l1_rational_parameter_arbitrarily_close R hR
  have heB := source_l1_rational_matrix_actual_original η hη
  have heT := source_l1_rational_trace_actual_original η hη hd8
  obtain ⟨hf,hpos⟩ := source_l1_boundary_family_feasible _ hd0 hd8
  refine ⟨η,hη,hstar,?_,?_,?_,?_⟩
  · rw [heB,heT]
    exact hf
  · intro i
    change 0<((fun i => (sourceL1RationalTracesRat η i : ℝ)) i)
    rw [heT]
    have hex : ∃ j,0<sourceL1BoundaryMatrix (sourceL1RationalD (η : ℝ)) i j := by
      fin_cases i
      · exact ⟨1,hpos (0,1) (by decide)⟩
      · exact ⟨0,hpos (1,0) (by decide)⟩
      · exact ⟨2,hpos (2,2) (by decide)⟩
    obtain ⟨j,hj⟩ := hex
    have hb := Finset.single_le_sum (fun k (_ : k∈Finset.univ) => hf.1 i k) (Finset.mem_univ j)
    rw [hf.2.1 i] at hb
    exact hj.trans_le hb
  · change (∑ i,|((fun i => (sourceL1RationalTracesRat η i : ℝ)) i)-1|)<R
    rw [heT,source_l1_boundary_distance _ hd0.le (by linarith),source_l1_rational_parameter_actual_sqrt _ hη]
    exact hF
  · rw [heB,heT]
    exact source_l1_boundary_family_strict_after_star _
      (source_l1_rational_parameter_d_above_star (η : ℝ) hη hstar) hd8

end CoefficientStability
