import CoefficientStability.SourceCubicUnitaryGeometry
import Mathlib.LinearAlgebra.Matrix.Swap

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 2500000
set_option backward.isDefEq.respectTransparency false

def sourceThreeSwapUnitary (k : Fin 3) : Matrix.unitaryGroup (Fin 3) ℂ :=
  ⟨Matrix.swap ℂ 0 k, by rw [Matrix.mem_unitaryGroup_iff,Matrix.star_eq_conjTranspose,Matrix.conjTranspose_swap,Matrix.swap_mul_self]⟩

theorem source_three_swap_conjugation_entry (k : Fin 3) (X : Matrix (Fin 3) (Fin 3) ℂ) (i j : Fin 3) :
    Unitary.conjStarAlgAut ℂ (Matrix (Fin 3) (Fin 3) ℂ) (sourceThreeSwapUnitary k) X i j=
      X (Equiv.swap 0 k i) (Equiv.swap 0 k j) := by
  change (Matrix.swap ℂ 0 k*X*star (Matrix.swap ℂ 0 k)) i j=_
  rw [Matrix.star_eq_conjTranspose,Matrix.conjTranspose_swap]
  simp [Matrix.swap,Equiv.Perm.permMatrix,PEquiv.toMatrix_toPEquiv_mul,PEquiv.mul_toMatrix_toPEquiv]

theorem source_three_swap_diagonal (k : Fin 3) (a b : ℝ) :
    Unitary.conjStarAlgAut ℂ (Matrix (Fin 3) (Fin 3) ℂ) (sourceThreeSwapUnitary k)
      (Matrix.diagonal (fun i => ((a+b*(if i=k then 1 else 0) : ℝ) : ℂ)))=
      Matrix.diagonal (fun i => ((a+b*(if i=0 then 1 else 0) : ℝ) : ℂ)) := by
  ext i j
  rw [source_three_swap_conjugation_entry]
  by_cases hij : i=j
  · subst j
    simp only [Matrix.diagonal_apply_eq]
    have he : Equiv.swap 0 k i=k ↔ i=0 := by
      rw [← Equiv.swap_apply_left (0 : Fin 3) k]
      exact (Equiv.swap 0 k).injective.eq_iff
    simp only [he]
  · have hs : Equiv.swap 0 k i ≠ Equiv.swap 0 k j := (Equiv.swap 0 k).injective.ne hij
    simp [Matrix.diagonal_apply,hij,hs]

end CoefficientStability
