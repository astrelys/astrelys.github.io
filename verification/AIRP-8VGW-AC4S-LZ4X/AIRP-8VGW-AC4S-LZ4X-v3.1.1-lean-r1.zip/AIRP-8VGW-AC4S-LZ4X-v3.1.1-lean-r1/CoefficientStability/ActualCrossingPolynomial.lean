import CoefficientStability.HomogeneousFamilyContinuity
import CoefficientStability.HomogeneousPureCoordinate

noncomputable section
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def planePoint (s t : ℝ) : Fin 3 → ℝ := fun j => if j=0 then s else if j=1 then t else 1

theorem planePoint_update_S (s t : ℝ) : Function.update (planePoint 0 t) 0 s=planePoint s t := by
  funext j
  fin_cases j <;> simp [planePoint,Function.update]

theorem planePoint_update_T (t : ℝ) : Function.update (planePoint 0 0) 1 t=planePoint 0 t := by
  funext j
  fin_cases j <;> simp [planePoint,Function.update]

theorem plane_S_restriction_eval (q : MvPolynomial (Fin 3) ℝ) (s t : ℝ) :
    (realCoordinateRestriction (planePoint 0 t) 0 q).eval s=MvPolynomial.eval (planePoint s t) q := by
  rw [realCoordinateRestriction_eval,planePoint_update_S]

theorem plane_T_restriction_eval (q : MvPolynomial (Fin 3) ℝ) (t : ℝ) :
    (realCoordinateRestriction (planePoint 0 0) 1 q).eval t=MvPolynomial.eval (planePoint 0 t) q := by
  rw [realCoordinateRestriction_eval,planePoint_update_T]

theorem plane_restriction_Nuij_step (q : MvPolynomial (Fin 3) ℝ) (t ε : ℝ) :
    realCoordinateRestriction (planePoint 0 t) 0 (homogeneousNuijStep ε q)=
      nuijUnivariateStep ε (realCoordinateRestriction (planePoint 0 t) 0 q) := by
  simp only [homogeneousNuijStep,map_add,map_mul,realCoordinateRestriction_C,
    realCoordinateRestriction_partial,realCoordinateRestriction_X]
  norm_num [planePoint,nuijUnivariateStep]

theorem plane_restriction_Nuij_iterate (q : MvPolynomial (Fin 3) ℝ) (t ε : ℝ) (k : ℕ) :
    realCoordinateRestriction (planePoint 0 t) 0 ((homogeneousNuijStep ε)^[k] q)=
      (nuijUnivariateStep ε)^[k] (realCoordinateRestriction (planePoint 0 t) 0 q) := by
  induction k with
  | zero => rfl
  | succ k ih => rw [Function.iterate_succ_apply',plane_restriction_Nuij_step,ih,Function.iterate_succ_apply']

theorem plane_source_S_restriction (p : MvPolynomial (Fin n) ℝ) (x b : Fin n → ℝ) (t : ℝ) :
    realCoordinateRestriction (planePoint 0 t) 0 (homogenizedPlanePolynomial p x b)=
      lineRestriction p (x+t • b) := by
  apply Polynomial.funext
  intro s
  rw [plane_S_restriction_eval,homogenizedPlanePolynomial_eval,eval_lineRestriction_real]
  apply congrArg (fun w : Fin n → ℝ => MvPolynomial.eval w p)
  funext i
  simp [planePoint,Pi.add_apply,Pi.smul_apply,smul_eq_mul]
  <;> ring

def actualCrossingPolynomial (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (ε : ℝ) (x b : Fin n → ℝ) : Polynomial ℝ :=
  realCoordinateRestriction (planePoint 0 0) 1
    ((homogeneousNuijStep ε)^[N] (homogenizedPlanePolynomial p x b))

theorem actualCrossingPolynomial_eval (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (ε : ℝ)
    (x b : Fin n → ℝ) (t : ℝ) :
    (actualCrossingPolynomial p N ε x b).eval t=
      (smoothedLineRestriction p N ε (x+t • b)).eval 0 := by
  unfold actualCrossingPolynomial
  rw [plane_T_restriction_eval,← plane_S_restriction_eval _ 0 t,
    plane_restriction_Nuij_iterate,plane_source_S_restriction]
  rfl

theorem actualCrossingPolynomial_coeff_degree (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (ε : ℝ) (x b : Fin n → ℝ) :
    (actualCrossingPolynomial p N ε x b).natDegree≤N ∧
      (actualCrossingPolynomial p N ε x b).coeff N=MvPolynomial.eval b p := by
  have h := homogeneousNuij_iterate_invariants (homogenizedPlanePolynomial p x b) N hN
    (homogenizedPlanePolynomial_homogeneous p N hp x b) ε N
  refine ⟨homogeneous_realCoordinateRestriction_degree_le _ N h.1 _ _,?_⟩
  change (realCoordinateRestriction _ _ _).coeff N=_
  rw [homogeneous_realCoordinateRestriction_top_coeff _ N h.1,h.2,homogenizedPlanePolynomial_pure_T p N hp]

theorem actualCrossingPolynomial_coeff_continuous (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (x b : Fin n → ℝ) (k : ℕ) :
    Continuous (fun ε : ℝ => (actualCrossingPolynomial p N ε x b).coeff k) := by
  exact homogeneous_family_restriction_coeff_continuous
    (fun ε : ℝ => (homogeneousNuijStep ε)^[N] (homogenizedPlanePolynomial p x b)) N
    (fun ε => (homogeneousNuij_iterate_invariants _ N hN
      (homogenizedPlanePolynomial_homogeneous p N hp x b) ε N).1)
    (homogeneousNuij_iterate_coefficient_continuous _ N)
    (realCoordinateRestriction (planePoint 0 0) 1)
    (realCoordinateRestriction_C (planePoint 0 0) 1) k

end CoefficientStability
