import CoefficientStability.MultivariateCapacityElimination
import CoefficientStability.ProductDeficitExtremal

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem last_not_in_castSucc_range (n : ℕ) :
    Fin.last n∉Set.range (Fin.castSucc : Fin n → Fin (n+1)) := by
  rintro ⟨j,hj⟩
  exact Fin.castSucc_ne_last j hj

theorem dropLastPolynomial_eq_killCompl (p : MvPolynomial (Fin (n+1)) ℝ) :
    dropLastPolynomial p=MvPolynomial.killCompl (Fin.castSucc_injective n) p := by
  classical
  induction p using MvPolynomial.induction_on with
  | C c => simp [dropLastPolynomial,MvPolynomial.killCompl_C]
  | add p q hp hq => simp only [map_add,hp,hq]
  | mul_X p j hp =>
    simp only [map_mul,hp]
    congr 1
    refine Fin.lastCases ?_ (fun k => ?_) j
    · simp [dropLastPolynomial,MvPolynomial.killCompl,last_not_in_castSucc_range]
    · have h := MvPolynomial.killCompl_rename_app (Fin.castSucc_injective n) (MvPolynomial.X k : MvPolynomial (Fin n) ℝ)
      simpa [dropLastPolynomial] using h.symm

theorem dropLastPolynomial_coeff (p : MvPolynomial (Fin (n+1)) ℝ) (g : Fin n →₀ ℕ) :
    (dropLastPolynomial p).coeff g=p.coeff (g.mapDomain Fin.castSucc) := by
  rw [dropLastPolynomial_eq_killCompl,MvPolynomial.coeff_killCompl]

theorem squarefreeExponent_extend_last (n : ℕ) :
    (squarefreeExponent n).mapDomain Fin.castSucc+Finsupp.single (Fin.last n) 1=squarefreeExponent (n+1) := by
  classical
  ext j
  refine Fin.lastCases ?_ (fun k => ?_) j
  · simp only [Finsupp.add_apply,Finsupp.mapDomain_of_notMem_range _ _ (last_not_in_castSucc_range n),
      Finsupp.single_eq_same,squarefreeExponent_value,zero_add]
  · simp only [Finsupp.add_apply,Finsupp.mapDomain_apply_of_injective (Fin.castSucc_injective n),
      squarefreeExponent_value]
    simp [Finsupp.single_apply,Fin.castSucc_ne_last]

theorem lastDerivativeElimination_squarefree_coeff (p : MvPolynomial (Fin (n+1)) ℝ) :
    (lastDerivativeElimination p).coeff (squarefreeExponent n)=p.coeff (squarefreeExponent (n+1)) := by
  rw [lastDerivativeElimination,dropLastPolynomial_coeff,MvPolynomial.coeff_pderiv,squarefreeExponent_extend_last]
  rw [Finsupp.mapDomain_of_notMem_range _ _ (last_not_in_castSucc_range n)]
  simp

theorem homogeneous_degreeOf_le (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (i : Fin n) : p.degreeOf i≤N := by
  apply MvPolynomial.degreeOf_le_iff.mpr
  intro g hg
  rw [← homogeneous_mass p N hp g hg]
  exact Finset.single_le_sum (fun j hj => Nat.zero_le _) (Finset.mem_univ i)

end CoefficientStability
