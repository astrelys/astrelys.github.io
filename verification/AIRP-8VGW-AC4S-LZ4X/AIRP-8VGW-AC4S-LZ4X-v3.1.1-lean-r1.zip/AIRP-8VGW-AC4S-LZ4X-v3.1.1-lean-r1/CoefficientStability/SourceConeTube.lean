import CoefficientStability.SourceConeOperations

noncomputable section
namespace CoefficientStability
variable {n N : ℕ}

theorem source_cone_complex_direction_nonzero (p : MvPolynomial (Fin n) ℝ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N) (x : Fin n → ℝ)
    (t : ℂ) (ht : 0<t.im) :
    MvPolynomial.eval₂ Complex.ofRealHom (fun i => (x i : ℂ)+t*(b i : ℂ)) p≠0 := by
  obtain ⟨hsp,hd,hlc⟩ := source_spectral_cone_direction_splits p hN hp hs hnorm b hb x
  have hne : affineDirectionalRestriction p x b≠0 := Polynomial.leadingCoeff_ne_zero.mp
    (hlc.trans_ne (ne_of_gt (positiveSpectralCone_eval_pos p hp hs hnorm b hb)))
  have h := splits_real_upper_zero_free _ hsp hne t ht
  rwa [affineDirectionalRestriction_complex_eval] at h

theorem source_cone_tube_nonzero (p : MvPolynomial (Fin n) ℝ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (z : Fin n → ℂ) (hz : (fun i => (z i).im)∈positiveSpectralCone p N) :
    MvPolynomial.eval₂ Complex.ofRealHom z p≠0 := by
  have h := source_cone_complex_direction_nonzero p hN hp hs hnorm
    (fun i => (z i).im) hz (fun i => (z i).re) Complex.I (by norm_num)
  have heq : (fun i => ((z i).re : ℂ)+Complex.I*((z i).im : ℂ))=z := by
    funext i
    apply Complex.ext <;> simp
  rwa [heq] at h

end CoefficientStability
