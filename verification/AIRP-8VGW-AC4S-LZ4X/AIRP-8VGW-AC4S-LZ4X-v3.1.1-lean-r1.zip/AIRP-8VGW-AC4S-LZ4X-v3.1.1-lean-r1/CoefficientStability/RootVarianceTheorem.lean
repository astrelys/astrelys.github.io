import CoefficientStability.HomogeneousCentral

noncomputable section
open scoped BigOperators
open Polynomial MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem paper_root_variance
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ)
    (hN : 2 ≤ N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) (hstable : UpperHalfPlaneZeroFree p)
    (ht : ∑ i, t i=N) (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p) = t i) :
    ∃ a : ℕ → MvPolynomial (Fin n) ℝ,
      (∀ k ≤ N, (a k).IsHomogeneous k) ∧
      (deficitMatrix p t N).PosSemidef ∧
      (deficitMatrix p t N).mulVec (fun _ => 1) = 0 ∧
      (∀ x : Fin n → ℝ, MvPolynomial.eval x p = ((∑ i,t i*x i)/N)^N -
        ((∑ i,t i*x i)/N)^(N-2)*matrixQuadratic (deficitMatrix p t N) x +
        ∑ j ∈ Finset.range (N-2), ((∑ i,t i*x i)/N)^(N-(j+3))*
          MvPolynomial.eval x (a (j+3))) ∧
      (∀ (x : Fin n → ℝ) (k : ℕ), k ≤ N →
        |MvPolynomial.eval x (a k)| ≤ (N.choose k : ℝ)*
          (2*matrixQuadratic (deficitMatrix p t N) x)^((k : ℝ)/2)) := by
  refine ⟨centralCoefficientPolynomial p t N,?_,?_,?_,?_,?_⟩
  · intro k hk
    exact centralCoefficientPolynomial_homogeneous p t N k hk hp
  · exact deficitMatrix_posSemidef p t N hN hp hnorm hstable hgrad
  · exact deficitMatrix_mulVec_one p t N (by omega) hp ht hgrad
  · intro x
    exact paper_central_expansion p t N x hN hp hnorm hstable hgrad
  · intro x k hk
    rw [eval_centralCoefficientPolynomial]
    exact paper_central_coefficient_rpow_bound p t N x k hN hk hp hnorm hstable hgrad

end CoefficientStability
