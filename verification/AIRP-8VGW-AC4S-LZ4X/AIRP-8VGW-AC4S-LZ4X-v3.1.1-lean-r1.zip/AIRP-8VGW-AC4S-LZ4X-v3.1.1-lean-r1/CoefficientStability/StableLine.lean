import CoefficientStability.RootVariance
import Mathlib.Algebra.MvPolynomial.Eval
import Mathlib.Analysis.RCLike.Lemmas
import Mathlib.Analysis.Complex.Polynomial.Basic

noncomputable section
namespace CoefficientStability
variable {n : ℕ}

def UpperHalfPlaneZeroFree (p : MvPolynomial (Fin n) ℝ) : Prop :=
  ∀ z : Fin n → ℂ, (∀ i, 0 < (z i).im) →
    MvPolynomial.eval₂ Complex.ofRealHom z p ≠ 0

def lineRestriction (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ) : Polynomial ℝ :=
  MvPolynomial.eval₂ Polynomial.C (fun i => Polynomial.X + Polynomial.C (x i)) p

theorem eval_lineRestriction (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ) (z : ℂ) :
    Polynomial.eval₂ Complex.ofRealHom z (lineRestriction p x) =
      MvPolynomial.eval₂ Complex.ofRealHom (fun i => z + (x i : ℂ)) p := by
  change (Polynomial.eval₂RingHom Complex.ofRealHom z)
      (MvPolynomial.eval₂ Polynomial.C (fun i => Polynomial.X + Polynomial.C (x i)) p) = _
  rw [MvPolynomial.hom_eval₂]
  simp

theorem lineRestriction_nonzero_upper (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (x : Fin n → ℝ) (z : ℂ) (hz : 0 < z.im) :
    Polynomial.eval₂ Complex.ofRealHom z (lineRestriction p x) ≠ 0 := by
  rw [eval_lineRestriction]
  apply hp
  intro i
  simpa using hz

theorem lineRestriction_root_is_real (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (x : Fin n → ℝ) (z : ℂ)
    (hz : Polynomial.eval₂ Complex.ofRealHom z (lineRestriction p x) = 0) :
    z.im = 0 := by
  rcases lt_trichotomy 0 z.im with h | h | h
  · exact False.elim (lineRestriction_nonzero_upper p hp x z h hz)
  · exact h.symm
  · have hconj : Polynomial.eval₂ Complex.ofRealHom (star z) (lineRestriction p x) = 0 := by
      have hh := Polynomial.aeval_conj (lineRestriction p x) z
      change Polynomial.eval₂ (algebraMap ℝ ℂ) z (lineRestriction p x) = 0 at hz
      change Polynomial.eval₂ (algebraMap ℝ ℂ) ((starRingEnd ℂ) z) (lineRestriction p x) = 0
      simpa only [Polynomial.aeval_def, hz, map_zero] using hh
    have hpos : 0 < (star z).im := by simpa using neg_pos.mpr h
    exact False.elim (lineRestriction_nonzero_upper p hp x (star z) hpos hconj)

theorem lineRestriction_splits (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (x : Fin n → ℝ) :
    (lineRestriction p x).Splits := by
  apply Polynomial.Splits.of_splits_map Complex.ofRealHom (IsAlgClosed.splits _)
  intro z hz
  have hroot := Polynomial.isRoot_of_mem_roots hz
  have heval : Polynomial.eval₂ Complex.ofRealHom z (lineRestriction p x) = 0 := by
    simpa only [Polynomial.IsRoot, Polynomial.eval_map] using hroot
  have him := lineRestriction_root_is_real p hp x z heval
  refine ⟨z.re, ?_⟩
  apply Complex.ext <;> simp [him]

theorem lineRestriction_real_factorization (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (x : Fin n → ℝ) :
    ∃ roots : Multiset ℝ,
      lineRestriction p x = Polynomial.C (lineRestriction p x).leadingCoeff *
        (roots.map (fun r => Polynomial.X + Polynomial.C r)).prod := by
  exact Polynomial.splits_iff_exists_multiset'.mp (lineRestriction_splits p hp x)

end CoefficientStability
