import CoefficientStability.StochasticCovarianceLower
import CoefficientStability.TiltMatrixSubstitution

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem actual_routed_polynomial_covariance_lower (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (hcoeff : ∀ g,0≤p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (M : Matrix (Fin n) (Fin n) ℝ) (hrow : ∀ i,∑ j,M i j=1)
    (r : ℝ) (hr : 0≤r) (hmin : ∀ i j,r≤M i j)
    (u v : Fin n → ℝ) (hu : (∑ j,u j^2)≤1) (hv : ∑ j,v j=0) :
    ((n : ℝ)*r/8)*(∑ j,v j^2)≤
      matrixQuadratic (coefficientCovariance (tiltedPolynomial (matrixSubstitution M p) u)
        (tiltedMoment (matrixSubstitution M p) u)) v := by
  have huabs (j : Fin n) : |u j|≤1 := coordinate_abs_le_one_of_square_sum u hu j
  have hden (i : Fin n) : 0<routingDenominator M u i :=
    (Real.exp_pos _).trans_le (routingDenominator_bounds M u i (fun j => hr.trans (hmin i j)) (hrow i) huabs).1
  let w := logRoutingField M u
  let R := routingMatrix M u
  have hZ : tiltPartition p w≠0 := ne_of_gt (tiltPartition_pos p w hcoeff hnorm)
  have hrowR (i : Fin n) : (∑ j,R i j)=1 := routingProbability_total M u i (ne_of_gt (hden i))
  have hminR (i j : Fin n) : r/8≤R i j :=
    routingProbability_uniform_lower M u i j r hr (hmin i) (hrow i) huabs
  have h := stochastic_composition_covariance_lower (tiltedPolynomial p w) n
    (tiltedPolynomial_homogeneous p w n hp) (tiltedPolynomial_coefficient_nonnegative p w hcoeff hnorm)
    (tiltedPolynomial_normalized p w hZ) R hrowR (r/8) (by positivity) hminR v hv
  dsimp only at h
  have he : tiltedPolynomial (matrixSubstitution M p) u=matrixSubstitution R (tiltedPolynomial p w) :=
    actual_tilt_matrixSubstitution M p u hden
  have hZcomp : tiltPartition (matrixSubstitution M p) u≠0 := by
    rw [routing_partition_identity M p u hden]
    exact hZ
  have hgrad : tiltedMoment (matrixSubstitution M p) u=
      (fun j => MvPolynomial.eval (fun _ => 1) (pderiv j (matrixSubstitution R (tiltedPolynomial p w)))) := by
    funext j
    rw [tiltedMoment_actual_gradient _ u hZcomp j,he]
  rw [he,hgrad]
  simpa only [mul_div_assoc] using h

end CoefficientStability
