import CoefficientStability.StableHigherRemainder
import CoefficientStability.SignOrthogonality

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

def sourceBooleanPoint {n : ℕ} (eps : Fin n → Bool) : Fin n → ℝ :=
  fun i => if eps i then 1 else 0

def sourceBooleanCoefficientSum {n : ℕ} (p : MvPolynomial (Fin n) ℝ) : ℝ :=
  ∑ eps : Fin n → Bool,(∏ i,realSign (eps i))*MvPolynomial.eval (sourceBooleanPoint eps) p

theorem source_boolean_one_coordinate_moment (k : ℕ) :
    (∑ b : Bool,realSign b*(if b then (1 : ℝ) else 0)^k)=if k=0 then 0 else 1 := by
  by_cases hk : k=0
  · simp [hk,realSign]
  · simp [hk,realSign,zero_pow hk]

theorem source_squarefree_exponent_value {n : ℕ} (i : Fin n) : (squarefreeExponent n) i=1 := by
  simp [squarefreeExponent,Finsupp.single_apply]

theorem source_boolean_monomial_moment {n : ℕ} (g : Fin n →₀ ℕ)
    (hmass : (∑ i,g i)=n) :
    (∑ eps : Fin n → Bool,(∏ i,realSign (eps i))*(∏ i,sourceBooleanPoint eps i^g i))=
      if g=squarefreeExponent n then (1 : ℝ) else 0 := by
  classical
  have hdist : (∑ eps : Fin n → Bool,(∏ i,realSign (eps i))*(∏ i,sourceBooleanPoint eps i^g i))=
      ∏ i,∑ b : Bool,realSign b*(if b then (1 : ℝ) else 0)^g i := by
    simp only [sourceBooleanPoint,← Finset.prod_mul_distrib]
    exact (Fintype.prod_sum (fun (i : Fin n) (b : Bool) => realSign b*(if b then (1 : ℝ) else 0)^g i)).symm
  rw [hdist]
  simp only [source_boolean_one_coordinate_moment]
  by_cases he : g=squarefreeExponent n
  · subst g
    simp [source_squarefree_exponent_value]
  · rw [if_neg he]
    have hz : ∃ i,g i=0 := by
      by_contra! h
      have hp (i : Fin n) : 1 ≤ g i := Nat.one_le_iff_ne_zero.mpr (h i)
      have hone (i : Fin n) : g i=1 := by
        apply Nat.le_antisymm _ (hp i)
        by_contra! hi
        have hs := Finset.sum_lt_sum (fun j (_ : j∈(Finset.univ : Finset (Fin n))) => hp j)
          ⟨i,Finset.mem_univ i,hi⟩
        simpa [hmass] using hs
      apply he
      ext i
      rw [source_squarefree_exponent_value,hone]
    obtain ⟨i,hi⟩ := hz
    apply Finset.prod_eq_zero (Finset.mem_univ i)
    simp [hi]

theorem source_boolean_squarefree_coefficient {n : ℕ} (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) : sourceBooleanCoefficientSum p=p.coeff (squarefreeExponent n) := by
  classical
  have heval (eps : Fin n → Bool) : MvPolynomial.eval (sourceBooleanPoint eps) p=
      ∑ g∈p.support,p.coeff g*(∏ i,sourceBooleanPoint eps i^g i) := by
    rw [MvPolynomial.eval_eq']
  unfold sourceBooleanCoefficientSum
  simp only [heval,Finset.mul_sum]
  rw [Finset.sum_comm]
  have he (g : Fin n →₀ ℕ) (hg : g∈p.support) :
      (∑ eps : Fin n → Bool,(∏ i,realSign (eps i))*(p.coeff g*∏ i,sourceBooleanPoint eps i^g i))=
        if g=squarefreeExponent n then p.coeff g else 0 := by
    have hm := source_boolean_monomial_moment g (homogeneous_mass p n hp g hg)
    calc
      _=p.coeff g*(∑ eps : Fin n → Bool,(∏ i,realSign (eps i))*(∏ i,sourceBooleanPoint eps i^g i)) := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro eps heps
        ring
      _=if g=squarefreeExponent n then p.coeff g else 0 := by rw [hm];split_ifs <;> simp
  trans ∑ g∈p.support,if g=squarefreeExponent n then p.coeff g else 0
  · apply Finset.sum_congr rfl
    intro g hg
    simpa only [mul_assoc] using he g hg
  · by_cases h : squarefreeExponent n∈p.support
    · simp [h]
    · simp [h,MvPolynomial.notMem_support_iff.mp h]

theorem source_boolean_squarefree_coefficient_bound {n : ℕ} (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (B : ℝ)
    (hbound : ∀ eps : Fin n → Bool,|MvPolynomial.eval (sourceBooleanPoint eps) p| ≤ B) :
    |p.coeff (squarefreeExponent n)| ≤ (2 : ℝ)^n*B := by
  rw [← source_boolean_squarefree_coefficient p hp]
  unfold sourceBooleanCoefficientSum
  calc
    _≤∑ eps : Fin n → Bool,|(∏ i,realSign (eps i))*MvPolynomial.eval (sourceBooleanPoint eps) p| :=
      Finset.abs_sum_le_sum_abs _ _
    _≤∑ _eps : Fin n → Bool,B := by
      apply Finset.sum_le_sum
      intro eps heps
      simpa only [abs_mul,Finset.abs_prod,realSign_abs,Finset.prod_const_one,one_mul] using hbound eps
    _=(2 : ℝ)^n*B := by simp [Fintype.card_fun]

end CoefficientStability
