import CoefficientStability.SourceBalancedGateLocalBounds

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

theorem source_balanced_gate_actual_cube_exclusion (X : Matrix (Fin 3) (Fin 3) ℝ)
    (hX : X ∈ sourceTransportationPolytope (sourceEscapeTraces 1 1))
    (hentry : ∀ i j,|X i j-sourceBalancedEscapeGate i j| ≤ 1/100)
    (hq : sourceEscapeQ 1 1 < sourceEscapeQuadratic 1 1 (X-sourceEscapeCenter 1 1)) :
    1/4 < Matrix.permanent X := by
  let H := X-sourceBalancedEscapeGate
  have ht : H ∈ sourceEscapeTangent := by
    constructor
    · intro i
      change (∑ j,(X i j-sourceBalancedEscapeGate i j))=0
      rw [Finset.sum_sub_distrib,hX.2.1 i,source_escape_balanced_gate_feasible.2.1 i,sub_self]
    · intro j
      change (∑ i,(X i j-sourceBalancedEscapeGate i j))=0
      rw [Finset.sum_sub_distrib,hX.2.2 j,source_escape_balanced_gate_feasible.2.2 j,sub_self]
  have hd : ∀ i,0 ≤ H i i := by
    intro i
    have hz : sourceBalancedEscapeGate i i=0 := by fin_cases i <;> norm_num [sourceBalancedEscapeGate]
    change 0 ≤ X i i-sourceBalancedEscapeGate i i
    rw [hz,sub_zero]
    exact hX.1 i i
  have he : ∀ i j,|H i j| ≤ 1/100 := hentry
  have hD := source_escape_trace_nonnegative_of_diagonal H hd
  have hinc := source_balanced_gate_actual_quadratic_increment H ht
  have hsum : sourceBalancedEscapeGate-sourceEscapeCenter 1 1+H=X-sourceEscapeCenter 1 1 := by dsimp [H];abel
  rw [hsum] at hinc
  have hless : Matrix.trace H < sourceEscapeFrobeniusSq H := by norm_num [sourceEscapeQ] at hq;linarith
  have hpos : 0 < sourceEscapeFrobeniusSq H := lt_of_le_of_lt hD hless
  have hbound := source_escape_frobenius_cube_bound H (1/100) he
  norm_num at hbound
  have hdiag := source_escape_diagonal_square_le_trace_square H hd
  have hsq : (Matrix.trace H)^2 ≤ (sourceEscapeFrobeniusSq H)^2 := sq_le_sq' (by linarith) hless.le
  have hsmall : (sourceEscapeFrobeniusSq H)^2 ≤ sourceEscapeFrobeniusSq H/100 := by
    have h := mul_nonneg hpos.le (show 0 ≤ 1/100-sourceEscapeFrobeniusSq H by linarith)
    nlinarith
  have hrem := source_escape_actual_permanent_abs_cube_bound H (1/100) (by norm_num) he
  have hremlo := (abs_le.mp hrem).1
  have hTaylor := source_balanced_gate_actual_permanent_expansion H ht
  have hrec : sourceBalancedEscapeGate+H=X := by dsimp [H];abel
  rw [hrec] at hTaylor
  nlinarith

theorem source_balanced_gate_actual_local_escape_exclusion :
    ∀ᶠ X in 𝓝 sourceBalancedEscapeGate,
      X ∈ sourceTransportationPolytope (sourceEscapeTraces 1 1) →
      sourceEscapeQ 1 1 < sourceEscapeQuadratic 1 1 (X-sourceEscapeCenter 1 1) → 1/4 < Matrix.permanent X := by
  have hnear (i j : Fin 3) : ∀ᶠ X in 𝓝 sourceBalancedEscapeGate,|X i j-sourceBalancedEscapeGate i j| ≤ 1/100 := by
    have hc : Continuous (fun X : Matrix (Fin 3) (Fin 3) ℝ => |X i j-sourceBalancedEscapeGate i j|) := by fun_prop
    have h := hc.continuousAt.eventually (gt_mem_nhds (by simp : |sourceBalancedEscapeGate i j-sourceBalancedEscapeGate i j| < (1/100 : ℝ)))
    exact h.mono (fun X hX => hX.le)
  have hcube : ∀ᶠ X in 𝓝 sourceBalancedEscapeGate,∀ i j,|X i j-sourceBalancedEscapeGate i j| ≤ 1/100 := by
    simpa only [Filter.eventually_all] using hnear
  filter_upwards [hcube] with X hcube hX hq
  exact source_balanced_gate_actual_cube_exclusion X hX hcube hq

end CoefficientStability
