import CoefficientStability.SourceCubicConicActualTuple
import CoefficientStability.SourceCubicConicPositiveDefinite

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

theorem source_cubic_nonpositive_conic_actual_definite_representation
    (p : MvPolynomial (Fin 3) ℝ) (hp : p.IsHomogeneous 3)
    (hconic : ∀ u v : ℝ,MvPolynomial.eval (![u^2,u*v,v^2] : Fin 3 → ℝ) p ≤ 0)
    (e : Fin 3 → ℝ) (heX : 0<e 0) (heq : 0<e 0*e 2-(e 1)^2)
    (hef : 0<MvPolynomial.eval e p) :
    ∃ A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ,
      (∀ i,(A i).IsHermitian) ∧ (∑ i,(e i : ℂ) • A i).PosDef ∧
        p=realDeterminantPolynomial A := by
  obtain ⟨a,ha⟩ := source_cubic_actual_conic_coefficient_factor_exists p hp hconic
  let c := sourceTernaryCubicCoefficients p
  let A := sourceCubicConicActualTuple c a
  have hA : ∀ i,(A i).IsHermitian := source_cubic_conic_actual_tuple_hermitian c a
  have hvec (x : Fin 3 → ℝ) : (![x 0,x 1,x 2] : Fin 3 → ℝ)=x := by
    funext i
    fin_cases i <;> rfl
  have he : MvPolynomial.eval e p=(e 0*e 2-(e 1)^2)*sourceConicLinearValue c a (e 0) (e 1) (e 2)-
      e 0*Complex.normSq (sourceConicNormU a (e 0) (e 1))-
      e 2*Complex.normSq (sourceConicNormV a (e 1) (e 2))-
      e 1*(sourceConicNormU a (e 0) (e 1)*star (sourceConicNormV a (e 1) (e 2))+
        star (sourceConicNormU a (e 0) (e 1))*sourceConicNormV a (e 1) (e 2)).re := by
    have heval := source_ternary_cubic_actual_eval p hp (e 0) (e 1) (e 2)
    rw [hvec e] at heval
    rw [heval]
    exact source_cubic_conic_entire_value_identity c a ha (e 0) (e 1) (e 2)
  refine ⟨A,hA,?_,?_⟩
  · change (∑ i,(e i : ℂ) • sourceCubicConicActualTuple c a i).PosDef
    rw [source_cubic_conic_actual_tuple_evaluation]
    exact source_cubic_conic_actual_positive_definite _ _ _ _ _ _ _ heX heq hef he
  · apply MvPolynomial.funext
    intro x
    apply Complex.ofReal_injective
    rw [realDeterminantPolynomial_evaluation A hA,source_cubic_conic_actual_tuple_evaluation c a x,
      source_cubic_conic_entire_determinant c a ha]
    rw [← source_ternary_cubic_actual_eval p hp,hvec x]

end CoefficientStability
