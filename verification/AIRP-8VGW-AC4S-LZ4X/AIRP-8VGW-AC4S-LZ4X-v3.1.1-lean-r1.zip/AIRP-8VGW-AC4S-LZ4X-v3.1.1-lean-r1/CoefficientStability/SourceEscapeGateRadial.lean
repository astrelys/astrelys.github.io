import CoefficientStability.SourceEscapePathGeometry

noncomputable section
open scoped BigOperators Topology unitInterval
namespace CoefficientStability
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

theorem source_escape_gate_displacement_tangent (a b v : ℝ) (hs : a+2*b=3) :
    sourceEscapeGate a b v-sourceEscapeCenter a b ∈ sourceEscapeTangent := by
  constructor <;> intro i <;> fin_cases i <;>
    norm_num [sourceEscapeGate,sourceEscapeCenter,sourceEscapeTraces,sourcePermanentReference,sourceEscapeD,
      Matrix.sub_apply,Fin.sum_univ_succ] <;> linarith

theorem source_escape_gate_displacement_permanent (a b v : ℝ) (hs : a+2*b=3) (hv : v^2=b*(4*a-b)/48) :
    Matrix.permanent (sourceEscapeGate a b v-sourceEscapeCenter a b)=-(2/3)*sourceEscapeQ a b := by
  have hx := source_escape_actual_cubic_expansion a b (sourceEscapeGate a b v-sourceEscapeCenter a b)
    (source_escape_gate_displacement_tangent a b v hs)
  have he : sourceEscapeCenter a b+(sourceEscapeGate a b v-sourceEscapeCenter a b)=sourceEscapeGate a b v := by abel
  rw [he,source_escape_gate_height a b v hs,source_escape_gate_quadratic a b v hs hv] at hx
  unfold sourceEscapeQ sourceEscapeDelta at *
  linarith

theorem source_escape_gate_actual_radial_excess (a b v : ℝ) (hs : a+2*b=3)
    (hv : v^2=b*(4*a-b)/48) (r : ℝ) :
    sourceEscapeExcess a b (sourceEscapeCenter a b+r • (sourceEscapeGate a b v-sourceEscapeCenter a b))=
      sourceEscapeDelta a b*(3*r^2-2*r^3) := by
  rw [source_escape_actual_radial_excess a b _ (source_escape_gate_displacement_tangent a b v hs) r,
    source_escape_gate_quadratic a b v hs hv,source_escape_gate_displacement_permanent a b v hs hv]
  unfold sourceEscapeQ sourceEscapeDelta
  ring

theorem source_escape_gate_actual_segment_bound (a b v : ℝ) (ha : 0 < a) (hb : 0 < b)
    (hs : a+2*b=3) (hv : v^2=b*(4*a-b)/48) (u : unitInterval) :
    sourceEscapeExcess a b (Path.segment (sourceEscapeCenter a b) (sourceEscapeGate a b v) u) ≤ sourceEscapeDelta a b := by
  rw [source_actual_segment_radial,source_escape_gate_actual_radial_excess a b v hs hv]
  have hd : 0 ≤ sourceEscapeDelta a b := by unfold sourceEscapeDelta;positivity
  have h := source_escape_cubic_shape_bounds (u : ℝ) u.2
  exact mul_le_of_le_one_right hd h.2

theorem source_escape_gate_actual_flat_segment_excess (a b v z : ℝ) (hs : a+2*b=3) (u : unitInterval) :
    sourceEscapeExcess a b (Path.segment (sourceEscapeGate a b v)
      (sourceEscapeGate a b v+z • sourceEscapeFlatDirection) u)=sourceEscapeDelta a b := by
  rw [source_actual_segment_radial]
  have he : sourceEscapeGate a b v+(u : ℝ) •
      ((sourceEscapeGate a b v+z • sourceEscapeFlatDirection)-sourceEscapeGate a b v)=
      sourceEscapeGate a b v+((u : ℝ)*z) • sourceEscapeFlatDirection := by module
  rw [he]
  unfold sourceEscapeExcess
  rw [source_escape_gate_flat_permanent]
  have h := source_escape_gate_height a b v hs
  have hp := source_escape_gate_flat_permanent a b v 0
  simp only [zero_smul,add_zero] at hp
  rwa [hp] at h

end CoefficientStability
