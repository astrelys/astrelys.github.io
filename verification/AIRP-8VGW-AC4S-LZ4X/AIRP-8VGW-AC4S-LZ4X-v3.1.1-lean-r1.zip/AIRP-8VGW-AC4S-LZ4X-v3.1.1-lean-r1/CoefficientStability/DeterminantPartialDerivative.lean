import CoefficientStability.GeneralMixedCoefficient
import Mathlib.Algebra.MvPolynomial.PDeriv

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ} {R σ ι : Type*} [CommRing R]

theorem partial_product_erase [DecidableEq ι] (i : σ) (s : Finset ι)
    (f : ι → MvPolynomial σ R) :
    pderiv i (∏ r∈s,f r)=∑ c∈s,(∏ r∈s.erase c,f r)*pderiv i (f c) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [pderiv_one]
  | @insert a s ha ih =>
    rw [Finset.prod_insert ha,pderiv_mul,ih,Finset.sum_insert ha]
    have hself : (insert a s).erase a=s := Finset.erase_insert ha
    rw [hself,Finset.mul_sum]
    rw [mul_comm (pderiv i (f a))]
    congr 1
    apply Finset.sum_congr rfl
    intro c hc
    have hca : c≠a := ne_of_mem_of_not_mem hc ha
    rw [Finset.erase_insert_of_ne hca.symm,Finset.prod_insert]
    · ring
    · exact fun h => ha (Finset.mem_of_mem_erase h)

theorem product_update_erase [Fintype ι] [DecidableEq ι] (f : ι → R) (c : ι) (d : R) :
    (∏ r,if r=c then d else f r)=(∏ r∈Finset.univ.erase c,f r)*d := by
  rw [← Finset.prod_erase_mul _ _ (Finset.mem_univ c)]
  simp only [ite_true]
  congr 1
  apply Finset.prod_congr rfl
  intro r hr
  simp only [Finset.mem_erase] at hr
  simp only [hr.1,ite_false]

theorem partial_determinant_columns (i : σ)
    (M : Matrix (Fin n) (Fin n) (MvPolynomial σ R)) :
    pderiv i (Matrix.det M)=
      ∑ c,Matrix.det (Matrix.updateCol M c (fun r => pderiv i (M r c))) := by
  classical
  rw [Matrix.det_apply]
  simp only [map_sum,Units.smul_def,map_zsmul,partial_product_erase,Finset.smul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro c hc
  rw [Matrix.det_apply]
  apply Finset.sum_congr rfl
  intro p hp
  congr 1
  have he : (∏ r,(Matrix.updateCol M c (fun r => pderiv i (M r c))) (p r) r)=
      ∏ r,if r=c then pderiv i (M (p c) c) else M (p r) r := by
    apply Finset.prod_congr rfl
    intro r hr
    by_cases h : r=c <;> simp [h,Matrix.updateCol_apply]
  rw [he,product_update_erase]

end CoefficientStability
