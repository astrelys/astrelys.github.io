import CoefficientStability.FiniteSpectralClosure
import CoefficientStability.SourceSubsetFactorization

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem actual_source_subset_sum_lower_add (p : MvPolynomial (Fin n) ℝ) (N k : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hk : 0<k) (hkN : k≤N)
    (x y : Fin n → ℝ) (rx ry rz : Fin N → ℝ)
    (hfx : lineRestriction p x=∏ i : Fin N,(Polynomial.X+Polynomial.C (rx i)))
    (hfy : lineRestriction p y=∏ i : Fin N,(Polynomial.X+Polynomial.C (ry i)))
    (hfz : lineRestriction p (x+y)=∏ i : Fin N,(Polynomial.X+Polynomial.C (rz i)))
    (a b : ℝ)
    (ha : ∀ s∈Finset.univ.powersetCard k,a≤∑ i∈s,rx i)
    (hb : ∀ s∈Finset.univ.powersetCard k,b≤∑ i∈s,ry i) :
    ∀ s∈Finset.univ.powersetCard k,a+b≤∑ i∈s,rz i := by
  classical
  let Q := normalizedSourceSubsetPolynomial p N k
  let S : Finset (Finset (Fin N)) := Finset.univ.powersetCard k
  have hD : 0<N.choose k := Nat.choose_pos hkN
  have hkreal : 0<(k : ℝ) := by exact_mod_cast hk
  obtain ⟨hQhom,hQstable,hQnorm⟩ := normalizedSourceSubsetPolynomial_properties p N k hp hs hnorm hk
  have hcard : S.card=N.choose k := by simp [S]
  have hfX := normalizedSourceSubsetPolynomial_line_factors p N k x rx hfx hk
  have hfY := normalizedSourceSubsetPolynomial_line_factors p N k y ry hfy hk
  have hfZ := normalizedSourceSubsetPolynomial_line_factors p N k (x+y) rz hfz hk
  have hxclosed : (fun j => x j+ -(a/(k : ℝ)))∈closure (positiveSpectralCone Q (N.choose k)) := by
    apply source_nonnegative_finite_factors_mem_closure Q (N.choose k) _ S
      (fun s => (∑ i∈s,rx i)/(k : ℝ)+ -(a/(k : ℝ))) hcard
    · intro s hs
      have h := div_le_div_of_nonneg_right (ha s hs) hkreal.le
      linarith
    · exact actual_finite_root_factor_shift Q x S (fun s => (∑ i∈s,rx i)/(k : ℝ)) hfX (-(a/(k : ℝ)))
  have hyclosed : (fun j => y j+ -(b/(k : ℝ)))∈closure (positiveSpectralCone Q (N.choose k)) := by
    apply source_nonnegative_finite_factors_mem_closure Q (N.choose k) _ S
      (fun s => (∑ i∈s,ry i)/(k : ℝ)+ -(b/(k : ℝ))) hcard
    · intro s hs
      have h := div_le_div_of_nonneg_right (hb s hs) hkreal.le
      linarith
    · exact actual_finite_root_factor_shift Q y S (fun s => (∑ i∈s,ry i)/(k : ℝ)) hfY (-(b/(k : ℝ)))
  have hzclosed := source_closedCone_add Q hD hQhom hQstable hQnorm _ _ hxclosed hyclosed
  have hvec : (fun j => x j+ -(a/(k : ℝ)))+(fun j => y j+ -(b/(k : ℝ)))=
      (fun j => (x+y) j+ -((a+b)/(k : ℝ))) := by
    funext j
    simp only [Pi.add_apply]
    ring
  rw [hvec] at hzclosed
  have hnonneg := source_closedCone_finite_factors_nonneg Q hD hQhom hQstable hQnorm
    _ hzclosed S (fun s => (∑ i∈s,rz i)/(k : ℝ)+ -((a+b)/(k : ℝ)))
    (actual_finite_root_factor_shift Q (x+y) S (fun s => (∑ i∈s,rz i)/(k : ℝ)) hfZ (-((a+b)/(k : ℝ))))
  intro s hs
  have hratio : (a+b)/(k : ℝ)≤(∑ i∈s,rz i)/(k : ℝ) := by linarith [hnonneg s hs]
  have hcross := (div_le_div_iff₀ hkreal hkreal).mp hratio
  by_contra hbad
  have hlt : (∑ i∈s,rz i)<a+b := lt_of_not_ge hbad
  nlinarith [mul_pos (sub_pos.mpr hlt) hkreal]

end CoefficientStability
