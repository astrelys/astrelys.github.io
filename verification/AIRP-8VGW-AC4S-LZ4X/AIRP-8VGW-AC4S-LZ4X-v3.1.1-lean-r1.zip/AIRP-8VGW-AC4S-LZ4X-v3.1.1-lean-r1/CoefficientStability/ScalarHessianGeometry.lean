import CoefficientStability.SourceConstant

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def marginalNormSq (t : Fin n → ℝ) : ℝ := ∑ i,t i^2

def scalarHessianLambda (t : Fin n → ℝ) : ℝ :=
  (n : ℝ)^2/marginalNormSq t-((n : ℝ)-1)

def projectedOnes (t : Fin n → ℝ) (i : Fin n) : ℝ :=
  1-((n : ℝ)/marginalNormSq t)*t i

def scalarHessianForm (z : Fin n → ℝ) : ℝ := (∑ i,z i^2)-(∑ i,z i)^2

theorem marginalNormSq_pos (t : Fin n → ℝ) (hn : 0<n) (ht : ∑ i,t i=n) :
    0<marginalNormSq t := by
  have h := marginal_sum_squares_lower t hn ht
  have hn' : (0 : ℝ)<n := by exact_mod_cast hn
  unfold marginalNormSq
  linarith

theorem projectedOnes_dot_t (t : Fin n → ℝ) (hn : 0<n) (ht : ∑ i,t i=n) :
    ∑ i,t i*projectedOnes t i=0 := by
  have hT := ne_of_gt (marginalNormSq_pos t hn ht)
  unfold projectedOnes
  have he : (∑ i,t i*(1-((n : ℝ)/marginalNormSq t)*t i)) =
      (∑ i,t i)-((n : ℝ)/marginalNormSq t)*(∑ i,t i^2) := by
    rw [Finset.mul_sum,← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro i hi
    ring
  rw [he,ht]
  change (n : ℝ)-((n : ℝ)/marginalNormSq t)*marginalNormSq t=0
  field_simp <;> ring

theorem projectedOnes_sum (t : Fin n → ℝ) (ht : ∑ i,t i=n) :
    (∑ i,projectedOnes t i)=1-scalarHessianLambda t := by
  simp only [projectedOnes,Finset.sum_sub_distrib,Finset.sum_const,Finset.card_univ,
    Fintype.card_fin,nsmul_eq_mul,mul_one,← Finset.mul_sum,ht,scalarHessianLambda]
  ring

theorem projectedOnes_normSq (t : Fin n → ℝ) (hn : 0<n) (ht : ∑ i,t i=n) :
    (∑ i,(projectedOnes t i)^2)=1-scalarHessianLambda t := by
  have hT := ne_of_gt (marginalNormSq_pos t hn ht)
  have he : (∑ i,(projectedOnes t i)^2) =
      (n : ℝ)-2*((n : ℝ)/marginalNormSq t)*(∑ i,t i)+
        ((n : ℝ)/marginalNormSq t)^2*(∑ i,t i^2) := by
    calc
      _ = ∑ i : Fin n,(1-2*((n : ℝ)/marginalNormSq t)*t i+
          ((n : ℝ)/marginalNormSq t)^2*t i^2) := by
        apply Finset.sum_congr rfl
        intro i hi
        unfold projectedOnes
        ring
      _ = _ := by
        rw [Finset.sum_add_distrib,Finset.sum_sub_distrib]
        simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,
          mul_one,← Finset.mul_sum]
  rw [he,ht]
  change (n : ℝ)-2*((n : ℝ)/marginalNormSq t)*n+
    ((n : ℝ)/marginalNormSq t)^2*marginalNormSq t=1-scalarHessianLambda t
  unfold scalarHessianLambda
  field_simp <;> ring

theorem projectedOnes_dot_eq_sum (t z : Fin n → ℝ) (hz : ∑ i,t i*z i=0) :
    (∑ i,projectedOnes t i*z i)=∑ i,z i := by
  have he : (∑ i,projectedOnes t i*z i)=(∑ i,z i)-((n : ℝ)/marginalNormSq t)*(∑ i,t i*z i) := by
    unfold projectedOnes
    rw [Finset.mul_sum,← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro i hi
    ring
  rw [he,hz,mul_zero,sub_zero]

theorem scalarHessianForm_lower (t z : Fin n → ℝ) (hn : 0<n)
    (ht : ∑ i,t i=n) (hz : ∑ i,t i*z i=0) :
    scalarHessianLambda t*(∑ i,z i^2) ≤ scalarHessianForm z := by
  have h := Finset.sum_mul_sq_le_sq_mul_sq (Finset.univ : Finset (Fin n)) (projectedOnes t) z
  rw [projectedOnes_dot_eq_sum t z hz,projectedOnes_normSq t hn ht] at h
  unfold scalarHessianForm
  nlinarith

theorem scalarHessianLambda_le_one (t : Fin n → ℝ) (hn : 0<n) (ht : ∑ i,t i=n) :
    scalarHessianLambda t≤1 := by
  have h : 0≤∑ i,(projectedOnes t i)^2 := Finset.sum_nonneg (fun _ _ => sq_nonneg _)
  rw [projectedOnes_normSq t hn ht] at h
  linarith

theorem scalarHessianForm_projectedOnes (t : Fin n → ℝ) (hn : 0<n) (ht : ∑ i,t i=n) :
    scalarHessianForm (projectedOnes t)=scalarHessianLambda t*(1-scalarHessianLambda t) := by
  unfold scalarHessianForm
  rw [projectedOnes_normSq t hn ht,projectedOnes_sum t ht]
  ring

end CoefficientStability
