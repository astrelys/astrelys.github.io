import CoefficientStability.SourceCubicConicRestriction

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceTernaryCubicCoefficients (p : MvPolynomial (Fin 3) ℝ) : Fin 10 → ℝ :=
  fun i => p.coeff (sourceTernaryCubicExponent i)

def sourceTernaryCubicValue (c : Fin 10 → ℝ) (X Y Z : ℝ) : ℝ :=
  c 0*X^3+c 1*X^2*Y+c 2*X^2*Z+c 3*X*Y^2+c 4*X*Y*Z+c 5*X*Z^2+
    c 6*Y^3+c 7*Y^2*Z+c 8*Y*Z^2+c 9*Z^3

theorem source_ternary_monomial_actual_eval (a b c : ℕ) (d X Y Z : ℝ) :
    MvPolynomial.eval (![X,Y,Z] : Fin 3 → ℝ) (MvPolynomial.monomial (sourceTernaryExponent a b c) d)=
      d*X^a*Y^b*Z^c := by
  norm_num [MvPolynomial.eval_monomial,sourceTernaryExponent,Fin.prod_univ_succ,Finsupp.single_apply] <;> ring

theorem source_ternary_cubic_actual_eval (p : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3) (X Y Z : ℝ) :
    MvPolynomial.eval (![X,Y,Z] : Fin 3 → ℝ) p=
      sourceTernaryCubicValue (sourceTernaryCubicCoefficients p) X Y Z := by
  conv_lhs => rw [source_ternary_cubic_coefficient_expansion p hp]
  norm_num [map_sum,Fin.sum_univ_succ,sourceTernaryCubicExponent,
    source_ternary_monomial_actual_eval,sourceTernaryCubicValue,sourceTernaryCubicCoefficients] <;> ring

def sourceBinaryNormCoefficients (a : Fin 4 → ℂ) : Fin 7 → ℝ :=
  ![Complex.normSq (a 0),(a 0*star (a 1)+star (a 0)*a 1).re,
    Complex.normSq (a 1)+(a 0*star (a 2)+star (a 0)*a 2).re,
    (a 0*star (a 3)+star (a 0)*a 3+a 1*star (a 2)+star (a 1)*a 2).re,
    Complex.normSq (a 2)+(a 1*star (a 3)+star (a 1)*a 3).re,
    (a 2*star (a 3)+star (a 2)*a 3).re,Complex.normSq (a 3)]

theorem source_binary_cubic_norm_expansion (a : Fin 4 → ℂ) (t : ℝ) :
    Complex.normSq (sourceBinaryCubicValue a 1 (t : ℂ))=
      sourceBinaryNormCoefficients a 0+sourceBinaryNormCoefficients a 1*t+
      sourceBinaryNormCoefficients a 2*t^2+sourceBinaryNormCoefficients a 3*t^3+
      sourceBinaryNormCoefficients a 4*t^4+sourceBinaryNormCoefficients a 5*t^5+
      sourceBinaryNormCoefficients a 6*t^6 := by
  simp [sourceBinaryCubicValue,sourceBinaryNormCoefficients,Complex.normSq_apply,Complex.add_re,Complex.add_im,
    Complex.mul_re,Complex.mul_im,pow_succ] <;> ring

end CoefficientStability
