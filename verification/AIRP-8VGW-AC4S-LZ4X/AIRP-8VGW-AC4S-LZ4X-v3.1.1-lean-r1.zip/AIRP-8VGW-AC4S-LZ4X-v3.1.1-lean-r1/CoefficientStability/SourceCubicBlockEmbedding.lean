import CoefficientStability.SourceCubicBlockPositivity

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 2800000
set_option backward.isDefEq.respectTransparency false

def sourceOneTwoBlock (a : ℝ) (B : Matrix (Fin 2) (Fin 2) ℂ) : Matrix (Fin 3) (Fin 3) ℂ :=
  ![![(a : ℂ),0,0],![0,B 0 0,B 0 1],![0,B 1 0,B 1 1]]

theorem source_one_two_block_hermitian (a : ℝ) (B : Matrix (Fin 2) (Fin 2) ℂ) (hB : B.IsHermitian) :
    (sourceOneTwoBlock a B).IsHermitian := by
  ext i j
  fin_cases i <;> fin_cases j <;> simp [sourceOneTwoBlock,Matrix.conjTranspose_apply,hB.apply]

theorem source_one_two_block_psd (a : ℝ) (ha : 0 ≤ a) (B : Matrix (Fin 2) (Fin 2) ℂ) (hB : B.PosSemidef) :
    (sourceOneTwoBlock a B).PosSemidef := by
  apply Matrix.PosSemidef.of_dotProduct_mulVec_nonneg (source_one_two_block_hermitian a B hB.isHermitian)
  intro x
  have hb := hB.dotProduct_mulVec_nonneg (fun i : Fin 2 => x i.succ)
  have haC : 0 ≤ (a : ℂ) := Complex.zero_le_real.mpr ha
  have hp := mul_nonneg haC (star_mul_self_nonneg (x 0))
  have he : star x ⬝ᵥ (sourceOneTwoBlock a B*ᵥ x)=(a : ℂ)*(star (x 0)*x 0)+
      star (fun i : Fin 2 => x i.succ) ⬝ᵥ (B*ᵥ (fun i : Fin 2 => x i.succ)) := by
    norm_num [sourceOneTwoBlock,Matrix.mulVec,dotProduct,Fin.sum_univ_succ]
    ring
  rw [he]
  exact add_nonneg hp hb

theorem source_one_two_block_psd_components (a : ℝ) (B : Matrix (Fin 2) (Fin 2) ℂ)
    (hB : (sourceOneTwoBlock a B).PosSemidef) : 0 ≤ a ∧ B.PosSemidef := by
  have haC : 0 ≤ (a : ℂ) := by simpa [sourceOneTwoBlock] using (hB.diag_nonneg (i := 0))
  refine ⟨Complex.zero_le_real.mp haC,?_⟩
  have hp := hB.submatrix (fun i : Fin 2 => i.succ)
  convert hp using 1
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [sourceOneTwoBlock,Matrix.submatrix_apply]

theorem source_one_two_block_trace (a : ℝ) (B : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix.trace (sourceOneTwoBlock a B)=(a : ℂ)+Matrix.trace B := by
  norm_num [sourceOneTwoBlock,Matrix.trace,Fin.sum_univ_succ] <;> ring

theorem source_one_two_block_trace_square (a : ℝ) (B : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix.trace ((sourceOneTwoBlock a B)^2)=(a : ℂ)^2+Matrix.trace (B^2) := by
  norm_num [sourceOneTwoBlock,Matrix.trace,Matrix.mul_apply,Fin.sum_univ_succ,pow_succ] <;> ring

theorem source_one_two_block_trace_cube (a : ℝ) (B : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix.trace ((sourceOneTwoBlock a B)^3)=(a : ℂ)^3+Matrix.trace (B^3) := by
  norm_num [sourceOneTwoBlock,Matrix.trace,Matrix.mul_apply,Fin.sum_univ_succ,pow_succ] <;> ring

theorem source_one_two_block_sum (a : Fin 3 → ℝ) (B : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) :
    (∑ i,sourceOneTwoBlock (a i) (B i))=sourceOneTwoBlock (∑ i,a i) (∑ i,B i) := by
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [sourceOneTwoBlock,Matrix.sum_apply,Fin.sum_univ_succ] <;> push_cast <;> ring

theorem source_one_two_block_sum_normalized (a : Fin 3 → ℝ) (B : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (ha : (∑ i,a i)=1) (hB : (∑ i,B i)=1) : (∑ i,sourceOneTwoBlock (a i) (B i))=1 := by
  rw [source_one_two_block_sum,ha,hB]
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [sourceOneTwoBlock,Matrix.one_apply]

end CoefficientStability
