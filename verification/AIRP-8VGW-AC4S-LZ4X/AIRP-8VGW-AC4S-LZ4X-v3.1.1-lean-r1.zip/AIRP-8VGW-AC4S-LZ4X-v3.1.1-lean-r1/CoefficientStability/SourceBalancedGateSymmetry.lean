import CoefficientStability.SourceBalancedGateAlgebra

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

theorem source_escape_permuted_tangent (A : Matrix (Fin 3) (Fin 3) ℝ)
    (hA : A ∈ sourceEscapeTangent) (r c : Equiv.Perm (Fin 3)) :
    sourcePermutedMatrix A r c ∈ sourceEscapeTangent := by
  constructor
  · intro i
    change (∑ j,A (r i) (c j))=0
    exact (Equiv.sum_comp c (fun j => A (r i) j)).trans (hA.1 (r i))
  · intro j
    change (∑ i,A (r i) (c j))=0
    exact (Equiv.sum_comp r (fun i => A i (c j))).trans (hA.2 (c j))

theorem source_escape_permuted_row_square (A : Matrix (Fin 3) (Fin 3) ℝ)
    (r c : Equiv.Perm (Fin 3)) (i : Fin 3) :
    sourceEscapeRowSq (sourcePermutedMatrix A r c) i=sourceEscapeRowSq A (r i) :=
  Equiv.sum_comp c (fun j => (A (r i) j)^2)

theorem source_balanced_gate_actual_all_entries (A : Matrix (Fin 3) (Fin 3) ℝ)
    (hA : A ∈ sourceEscapeTangent) (hR : ∀ i,sourceEscapeRowSq A i=1/6)
    (hp : Matrix.permanent A=-(1/18)) : ∀ i j,A i j=-(1/3) ∨ A i j=1/6 := by
  intro i j
  let r : Equiv.Perm (Fin 3) := Equiv.swap 0 i
  let c : Equiv.Perm (Fin 3) := Equiv.swap 0 j
  have hP := source_escape_permuted_tangent A hA r c
  have hRow : ∀ k,sourceEscapeRowSq (sourcePermutedMatrix A r c) k=1/6 := by
    intro k
    rw [source_escape_permuted_row_square]
    exact hR (r k)
  have hper : Matrix.permanent (sourcePermutedMatrix A r c)=-(1/18) := by rw [source_permuted_permanent,hp]
  have h := source_balanced_gate_actual_first_entry _ hP hRow hper
  simpa only [sourcePermutedMatrix,Matrix.submatrix_apply,r,c,Equiv.swap_apply_left] using h

theorem source_balanced_crossing_actual_entry_values (X : Matrix (Fin 3) (Fin 3) ℝ)
    (hX : X ∈ sourceTransportationPolytope (sourceEscapeTraces 1 1))
    (hq : sourceEscapeQuadratic 1 1 (X-sourceEscapeCenter 1 1)=sourceEscapeQ 1 1)
    (hp : Matrix.permanent X ≤ 1/4) : ∀ i j,X i j=0 ∨ X i j=1/2 := by
  have hT := source_escape_feasible_displacement_tangent 1 1 (by norm_num) (by norm_num) (by norm_num) X hX
  have hc : sourceEscapeCenter 1 1+(X-sourceEscapeCenter 1 1)=X := by abel
  have hF : Matrix.permanent (sourceEscapeCenter 1 1+(X-sourceEscapeCenter 1 1))-
      Matrix.permanent (sourceEscapeCenter 1 1) ≤ sourceEscapeDelta 1 1 := by
    rw [hc]
    have hCP : Matrix.permanent (sourceEscapeCenter 1 1)=2/9 := by
      norm_num [sourceEscapeCenter,sourceEscapeTraces,sourcePermanentReference,source_permanent_three]
    rw [hCP]
    norm_num only [sourceEscapeDelta,one_mul,one_pow]
    linarith
  obtain ⟨hper,hR⟩ := source_escape_balanced_crossing_equalities _ hT hq hF
  have hentries := source_balanced_gate_actual_all_entries _ hT hR hper
  intro i j
  have hC : sourceEscapeCenter 1 1 i j=1/3 := by fin_cases i <;> norm_num [sourceEscapeCenter,sourceEscapeTraces,sourcePermanentReference]
  have h := hentries i j
  change X i j-sourceEscapeCenter 1 1 i j=-(1/3) ∨ X i j-sourceEscapeCenter 1 1 i j=1/6 at h
  rw [hC] at h
  rcases h with h | h
  · left
    linarith
  · right
    linarith

theorem source_balanced_half_entry_row_recovery (X : Matrix (Fin 3) (Fin 3) ℝ)
    (hX : X ∈ sourceTransportationPolytope (sourceEscapeTraces 1 1))
    (hv : ∀ i j,X i j=0 ∨ X i j=1/2) : ∀ i,∃ k : Fin 3,∀ j,X i j=if j=k then 0 else 1/2 := by
  intro i
  have hr := hX.2.1 i
  have ht : sourceEscapeTraces 1 1 i=1 := by fin_cases i <;> norm_num [sourceEscapeTraces]
  rw [ht] at hr
  norm_num only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero] at hr
  change X i 0+(X i 1+X i 2)=1 at hr
  rcases hv i 0 with h0 | h0 <;> rcases hv i 1 with h1 | h1 <;> rcases hv i 2 with h2 | h2
  all_goals solve
    | (exfalso;linarith)
    | (refine ⟨0,?_⟩;intro j;fin_cases j <;> simp_all)
    | (refine ⟨1,?_⟩;intro j;fin_cases j <;> simp_all)
    | (refine ⟨2,?_⟩;intro j;fin_cases j <;> simp_all)

end CoefficientStability
