import CoefficientStability.PositiveCapacityStationarity
import Mathlib.Analysis.SpecialFunctions.Log.Basic

noncomputable section
open scoped BigOperators
namespace CoefficientStability

theorem capacity_log_one_add_upper (x : ℝ) (hx0 : -(1/2 : ℝ)≤x) (hx1 : x≤1) :
    Real.log (1+x)≤x-x^2/8 := by
  have hpos : 0<1+x := by linarith
  have hy := Real.log_le_sub_one_of_pos (Real.sqrt_pos.mpr hpos)
  rw [Real.log_sqrt hpos.le] at hy
  have hsq := Real.sq_sqrt hpos.le
  have hypos := Real.sqrt_nonneg (1+x)
  have hrhs : 0≤2+x-x^2/8 := by nlinarith [sq_nonneg (x+1/2)]
  have hpoly : 0≤(2+x-x^2/8)^2-4*(1+x) := by
    have hp : 0≤(x^2)*(1/2-x/4+x^2/64) :=
      mul_nonneg (sq_nonneg x) (by nlinarith [sq_nonneg x])
    nlinarith
  have hsqrt : 2*Real.sqrt (1+x)≤2+x-x^2/8 := by nlinarith
  linarith

theorem capacity_normalized_product_bound {n : ℕ} (v : Fin n → ℝ) (hn : 2≤n)
    (hv : ∀ i,0<v i) (hvs : ∑ i,v i=1) :
    (∏ i,(1+v i-1/(n : ℝ)))≤Real.exp (-(∑ i,(v i-1/(n : ℝ))^2)/8) := by
  have hn' : (2 : ℝ)≤n := by exact_mod_cast hn
  have hn0 : (n : ℝ)≠0 := by positivity
  have hrec : 0<1/(n : ℝ) ∧ 1/(n : ℝ)≤1/2 := by
    constructor
    · positivity
    · apply (div_le_iff₀ (by positivity : (0 : ℝ)<n)).mpr
      nlinarith
  have hvle (i : Fin n) : v i≤1 := by
    rw [← hvs]
    exact Finset.single_le_sum (fun j hj => (hv j).le) (Finset.mem_univ i)
  have hfactor (i : Fin n) : 0<1+v i-1/(n : ℝ) := by linarith [hv i,hrec.2]
  have hlog : (∑ i,Real.log (1+v i-1/(n : ℝ)))≤-(∑ i,(v i-1/(n : ℝ))^2)/8 := by
    have hsum := Finset.sum_le_sum (s := Finset.univ) (fun i hi => capacity_log_one_add_upper
      (v i-1/(n : ℝ)) (by linarith [hv i,hrec.2]) (by linarith [hvle i,hrec.1]))
    have hzero : (∑ i,(v i-1/(n : ℝ)))=0 := by
      simp only [Finset.sum_sub_distrib,hvs,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
      field_simp <;> ring
    simp only [Finset.sum_sub_distrib,← Finset.sum_div,hzero,zero_sub] at hsum
    simpa only [add_sub_assoc,neg_div] using hsum
  have hprod := Real.exp_le_exp.mpr hlog
  rw [Real.exp_sum] at hprod
  simpa only [Real.exp_log (hfactor _)] using hprod

end CoefficientStability
