import CoefficientStability.SourceStableCubicUniversalRepresentation

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

theorem source_original_stable_cubic_euclidean_ball
    (p : MvPolynomial (Fin 3) ℝ) (hp : p.IsHomogeneous 3)
    (hs : UpperHalfPlaneZeroFree p) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (t : Fin 3 → ℝ) (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hr : (∑ i,(t i-1)^2)≤3/8) :
    sourceTernaryBaseline t≤p.coeff (squarefreeExponent 3) ∧
      (p.coeff (squarefreeExponent 3)=sourceTernaryBaseline t ↔ sourceStableCubicEuclideanEquality t p) ∧
      ((∑ i,(t i-1)^2)<3/8 → (p.coeff (squarefreeExponent 3)=sourceTernaryBaseline t ↔ p=scalarPower t 3)) :=
  source_stable_cubic_definite_euclidean_transfer p hp hs hn t hg
    (source_stable_cubic_actual_definite_payload p t hp hn hs hg) hr

theorem source_original_stable_cubic_l1_ball
    (p : MvPolynomial (Fin 3) ℝ) (hp : p.IsHomogeneous 3)
    (hs : UpperHalfPlaneZeroFree p) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (t : Fin 3 → ℝ) (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hr : (∑ i,|t i-1|)≤sourceCubicEpsilon0) :
    sourceTernaryBaseline t≤p.coeff (squarefreeExponent 3) ∧
      (p.coeff (squarefreeExponent 3)=sourceTernaryBaseline t ↔ sourceStableCubicL1Equality t p) ∧
      ((∑ i,|t i-1|)<sourceCubicEpsilon0 →
        (p.coeff (squarefreeExponent 3)=sourceTernaryBaseline t ↔ p=scalarPower t 3)) :=
  source_stable_cubic_definite_l1_transfer p hp hs hn t hg
    (source_stable_cubic_actual_definite_payload p t hp hn hs hg) hr

theorem source_original_stable_cubic_either_ball_bound
    (p : MvPolynomial (Fin 3) ℝ) (hp : p.IsHomogeneous 3)
    (hs : UpperHalfPlaneZeroFree p) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (t : Fin 3 → ℝ) (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hr : (∑ i,(t i-1)^2)≤3/8 ∨ (∑ i,|t i-1|)≤sourceCubicEpsilon0) :
    sourceTernaryBaseline t≤p.coeff (squarefreeExponent 3) := by
  rcases hr with hr|hr
  · exact (source_original_stable_cubic_euclidean_ball p hp hs hn t hg hr).1
  · exact (source_original_stable_cubic_l1_ball p hp hs hn t hg hr).1

end CoefficientStability
