import CoefficientStability.SuffixSpectralScalar

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def suffixCoordinateSet (j : Fin n) : Finset (Fin n) := Finset.univ.filter (fun i => j ≤ i)

theorem suffixCoordinateSet_card (j : Fin n) : (suffixCoordinateSet j).card=n-j.val := by
  classical
  have h := suffix_prefix_coordinate_count j n le_rfl
  have hu : (Finset.univ.filter (fun i : Fin n => i.val < n))=Finset.univ := by
    ext i
    simp [i.isLt]
  rwa [hu] at h

theorem actual_source_suffix_spectrum (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (k : ℕ) (hk : k ≤ n) (j : Fin n) :
    ∃ roots : Fin n → ℝ,lineRestriction p (suffixIndicator j)=
      (∏ i : Fin n,(Polynomial.X+Polynomial.C (roots i))) ∧
      ∀ T∈Finset.univ.powersetCard k,
        suffixSpectralLower k j ((∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)/2)≤∑ i∈T,roots i := by
  classical
  by_cases hj0 : j.val=0
  · refine ⟨fun _ => 1,?_,?_⟩
    · have heq : suffixIndicator j=(fun _ => 1) := by
        funext i
        simp [suffixIndicator,Fin.le_def,hj0]
      rw [heq]
      exact source_line_at_one_full_factors p n hp hnorm
    · intro T hT
      have hcard : T.card=k := by simpa only [Finset.mem_powersetCard_univ] using hT
      simp [suffixSpectralLower,hj0,hcard]
  · obtain ⟨roots,hfactor⟩ := actual_source_real_root_tuple p n hp hs hnorm (suffixIndicator j)
    refine ⟨roots,hfactor,?_⟩
    intro T hT
    have hcard : T.card=k := by simpa only [Finset.mem_powersetCard_univ] using hT
    have hvec : (fun i => if i∈suffixCoordinateSet j then (1 : ℝ) else 0)=suffixIndicator j := by
      funext i
      simp [suffixCoordinateSet,suffixIndicator]
    have hfU : lineRestriction p (fun i => if i∈suffixCoordinateSet j then 1 else 0)=
        ∏ i : Fin n,(Polynomial.X+Polynomial.C (roots i)) := by rw [hvec];exact hfactor
    have h := source_indicator_nearbalanced_subset_lower p hn hp hs hnorm (suffixCoordinateSet j) roots hfU k T hcard
    by_cases hjk : j.val < k
    · simp only [suffixSpectralLower,if_neg hj0,if_pos hjk]
      rw [Nat.cast_sub (Nat.le_of_lt hjk)]
      have hlow := h.2
      rw [suffixCoordinateSet_card,Nat.cast_sub (Nat.le_of_lt j.isLt),Nat.cast_sub hk] at hlow
      linarith
    · simpa only [suffixSpectralLower,if_neg hj0,if_neg hjk] using h.1

end CoefficientStability
