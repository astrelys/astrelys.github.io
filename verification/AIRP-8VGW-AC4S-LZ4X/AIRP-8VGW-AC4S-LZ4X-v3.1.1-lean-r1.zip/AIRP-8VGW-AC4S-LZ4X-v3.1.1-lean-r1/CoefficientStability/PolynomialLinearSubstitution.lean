import CoefficientStability.DiagonalStablePolynomial
import CoefficientStability.HomogeneousMultilinear

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def matrixSubstitution (M : Matrix (Fin n) (Fin n) ℝ) :
    MvPolynomial (Fin n) ℝ →+* MvPolynomial (Fin n) ℝ :=
  MvPolynomial.eval₂Hom MvPolynomial.C (rowLinearPolynomial M)

@[simp] theorem matrixSubstitution_C (M : Matrix (Fin n) (Fin n) ℝ) (c : ℝ) :
    matrixSubstitution M (MvPolynomial.C c)=MvPolynomial.C c := by simp [matrixSubstitution]

@[simp] theorem matrixSubstitution_X (M : Matrix (Fin n) (Fin n) ℝ) (i : Fin n) :
    matrixSubstitution M (MvPolynomial.X i)=rowLinearPolynomial M i := by simp [matrixSubstitution]

theorem matrixSubstitution_eval (M : Matrix (Fin n) (Fin n) ℝ)
    (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ) :
    MvPolynomial.eval x (matrixSubstitution M p)=MvPolynomial.eval (M.mulVec x) p := by
  change (MvPolynomial.eval x) (MvPolynomial.eval₂ MvPolynomial.C _ p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c
    simp
  · funext i
    simp [rowLinearPolynomial,Matrix.mulVec,dotProduct]

theorem matrixSubstitution_partial (M : Matrix (Fin n) (Fin n) ℝ)
    (p : MvPolynomial (Fin n) ℝ) (j : Fin n) :
    pderiv j (matrixSubstitution M p)=
      ∑ i,MvPolynomial.C (M i j)*matrixSubstitution M (pderiv i p) := by
  classical
  induction p using MvPolynomial.induction_on with
  | C c => simp [pderiv_C]
  | add p q hp hq => simp only [map_add,hp,hq,mul_add,Finset.sum_add_distrib]
  | mul_X p k hp =>
    rw [map_mul,matrixSubstitution_X,pderiv_mul,hp,rowLinearPolynomial_partial (fun i k => M i k) k j]
    simp only [pderiv_mul,pderiv_X,map_add,map_mul,matrixSubstitution_X]
    have hsingle (i : Fin n) : matrixSubstitution M
        ((Pi.single i (1 : MvPolynomial (Fin n) ℝ) : Fin n → MvPolynomial (Fin n) ℝ) k)=if i=k then 1 else 0 := by
      by_cases hik : i=k <;> simp [Pi.single_apply,hik,eq_comm]
    simp only [hsingle,mul_add,Finset.sum_add_distrib]
    have hfirst : (∑ i,C (M i j)*(matrixSubstitution M (pderiv i p)*rowLinearPolynomial M k))=
        (∑ i,C (M i j)*matrixSubstitution M (pderiv i p))*rowLinearPolynomial M k := by
      rw [Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro i hi
      ring
    rw [hfirst]
    have hsecond : (∑ i,C (M i j)*(matrixSubstitution M p*(if i=k then 1 else 0)))=
        matrixSubstitution M p*C (M k j) := by
      simp only [mul_ite,mul_one,mul_zero,Finset.sum_ite_eq',Finset.mem_univ,ite_true]
      ring
    rw [hsecond]

theorem homogeneous_eval_real_scale (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (a : ℝ) (x : Fin n → ℝ) :
    MvPolynomial.eval (fun i => a*x i) p=a^N*MvPolynomial.eval x p := by
  obtain ⟨T,hT⟩ := homogeneous_exists_multilinear p N hp
  have h := T.map_smul_univ (fun _ : Fin N => a) (fun _ => x)
  simp only [Finset.prod_const,Finset.card_univ,Fintype.card_fin,smul_eq_mul] at h
  simp only [hT] at h
  have hax : (a • x)=(fun i => a*x i) := by ext i; rfl
  rw [← hax]
  exact h

end CoefficientStability
