import CoefficientStability.StableReference
import CoefficientStability.DeterminantPartialDerivative

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def rowLinearPolynomial (B : Fin n → Fin n → ℝ) (r : Fin n) : MvPolynomial (Fin n) ℝ :=
  ∑ i,C (B r i)*MvPolynomial.X i

theorem diagonalPolynomial_expansion (B : Fin n → Fin n → ℝ) :
    diagonalPencilPolynomial B=∑ f : Fin n → Fin n,
      MvPolynomial.monomial (assignmentExponent f) (∏ r,B r (f r)) := by
  rw [diagonalPencilPolynomial_eq_product]
  have he := (MultilinearMap.mkPiAlgebra ℝ (Fin n) (MvPolynomial (Fin n) ℝ)).map_sum
    (fun r (i : Fin n) => C (B r i)*MvPolynomial.X i)
  simp only [MultilinearMap.mkPiAlgebra_apply] at he
  rw [he]
  apply Finset.sum_congr rfl
  intro f hf
  exact product_linear_assignment_monomial f (fun r => B r (f r)) Finset.univ

theorem diagonalPolynomial_coeff_nonnegative (B : Fin n → Fin n → ℝ)
    (hB : ∀ r i,0≤B r i) (d : Fin n →₀ ℕ) : 0≤(diagonalPencilPolynomial B).coeff d := by
  classical
  rw [diagonalPolynomial_expansion]
  simp only [MvPolynomial.coeff_sum,MvPolynomial.coeff_monomial]
  apply Finset.sum_nonneg
  intro f hf
  split_ifs
  · exact Finset.prod_nonneg (fun r _ => hB r (f r))
  · exact le_rfl

theorem rowLinearPolynomial_homogeneous (B : Fin n → Fin n → ℝ) (r : Fin n) :
    (rowLinearPolynomial B r).IsHomogeneous 1 := by
  unfold rowLinearPolynomial
  apply MvPolynomial.IsHomogeneous.sum
  intro i hi
  exact (MvPolynomial.isHomogeneous_X ℝ i).C_mul _

theorem diagonalPolynomial_homogeneous (B : Fin n → Fin n → ℝ) :
    (diagonalPencilPolynomial B).IsHomogeneous n := by
  rw [diagonalPencilPolynomial_eq_product]
  simpa only [rowLinearPolynomial,Finset.sum_const,Finset.card_univ,Fintype.card_fin,smul_eq_mul,mul_one] using
    MvPolynomial.IsHomogeneous.prod (Finset.univ : Finset (Fin n))
      (rowLinearPolynomial B) (fun _ => 1) (fun r _ => rowLinearPolynomial_homogeneous B r)

theorem diagonalPolynomial_normalized (B : Fin n → Fin n → ℝ)
    (hrow : ∀ r,∑ i,B r i=1) : MvPolynomial.eval (fun _ => 1) (diagonalPencilPolynomial B)=1 := by
  rw [diagonalPencilPolynomial_eq_product]
  simp [hrow]

theorem rowLinearPolynomial_partial (B : Fin n → Fin n → ℝ) (r i : Fin n) :
    pderiv i (rowLinearPolynomial B r)=C (B r i) := by
  classical
  simp [rowLinearPolynomial,pderiv_mul,pderiv_C,pderiv_X,Pi.single_apply,eq_comm]

theorem diagonalPolynomial_gradient (B : Fin n → Fin n → ℝ) (hrow : ∀ r,∑ i,B r i=1) (i : Fin n) :
    MvPolynomial.eval (fun _ => 1) (pderiv i (diagonalPencilPolynomial B))=∑ r,B r i := by
  rw [diagonalPencilPolynomial_eq_product]
  change MvPolynomial.eval (fun _ => 1) (pderiv i (∏ r,rowLinearPolynomial B r))=_
  rw [partial_product_erase]
  simp only [rowLinearPolynomial_partial]
  simp [rowLinearPolynomial,hrow]

theorem diagonalPolynomial_stable (B : Fin n → Fin n → ℝ)
    (hB : ∀ r i,0≤B r i) (hrow : ∀ r,∑ i,B r i=1) : UpperHalfPlaneZeroFree (diagonalPencilPolynomial B) := by
  classical
  intro z hz
  change (MvPolynomial.eval₂Hom Complex.ofRealHom z) (diagonalPencilPolynomial B)≠0
  rw [diagonalPencilPolynomial_eq_product,map_prod]
  apply Finset.prod_ne_zero_iff.mpr
  intro r hr
  have he : ((MvPolynomial.eval₂Hom Complex.ofRealHom z) (rowLinearPolynomial B r)).im=
      ∑ i,B r i*(z i).im := by simp [rowLinearPolynomial,Complex.mul_im]
  have hex : ∃ i,0<B r i := by
    by_contra! h
    have hall : ∀ i,B r i=0 := fun i => le_antisymm (h i) (hB r i)
    have h := hrow r
    simp [hall] at h
  obtain ⟨i,hi⟩ := hex
  have him : 0<((MvPolynomial.eval₂Hom Complex.ofRealHom z) (rowLinearPolynomial B r)).im := by
    rw [he]
    apply Finset.sum_pos'
    · exact fun j _ => mul_nonneg (hB r j) (hz j).le
    · exact ⟨i,Finset.mem_univ i,mul_pos hi (hz i)⟩
  intro hzero
  change (MvPolynomial.eval₂Hom Complex.ofRealHom z) (rowLinearPolynomial B r)=0 at hzero
  rw [hzero,Complex.zero_im] at him
  exact lt_irrefl _ him

end CoefficientStability
