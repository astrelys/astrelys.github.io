import CoefficientStability.PartialReverse

noncomputable section
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem stable_zero_specialization_zero_or_stable (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (i : Fin n) :
    coordinateSpecialization i 0 p=0 ∨ UpperHalfPlaneZeroFree (coordinateSpecialization i 0 p) := by
  classical
  by_cases hq : coordinateSpecialization i 0 p=0
  · exact Or.inl hq
  right
  let d := (coordinatePolynomial i p).natDegree
  have he : (pderiv i)^[d] (partialReverse i p)=
      (-1 : MvPolynomial (Fin n) ℝ)^d*(d.factorial : MvPolynomial (Fin n) ℝ)*
        coordinateSpecialization i 0 p := partialReverse_top_partial p i
  have hscalar : (-1 : MvPolynomial (Fin n) ℝ)^d*(d.factorial : MvPolynomial (Fin n) ℝ)≠0 :=
    mul_ne_zero (pow_ne_zero _ (neg_ne_zero.mpr one_ne_zero))
      (Nat.cast_ne_zero.mpr (Nat.factorial_ne_zero d))
  have hiter : (pderiv i)^[d] (partialReverse i p)≠0 := by
    intro hz
    apply hq
    exact (mul_eq_zero.mp (he.symm.trans hz)).resolve_left hscalar
  have hs := (stable_iterate_partial_zero_or_stable (partialReverse i p)
    (stable_partialReverse p hp i) i d).resolve_left hiter
  intro z hz hzero
  apply hs z hz
  rw [he]
  rw [MvPolynomial.eval₂_mul,hzero,mul_zero]

theorem stable_derivative_elimination_zero_or_stable (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (i : Fin n) :
    coordinateSpecialization i 0 (pderiv i p)=0 ∨
      UpperHalfPlaneZeroFree (coordinateSpecialization i 0 (pderiv i p)) := by
  rcases stable_partial_zero_or_stable p hp i with hz | hs
  · left
    simp [hz]
  · exact stable_zero_specialization_zero_or_stable _ hs i

end CoefficientStability
