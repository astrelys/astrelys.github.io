import CoefficientStability.SourceCubicScalarProjectionTuple

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 2500000
set_option backward.isDefEq.respectTransparency false

theorem source_hermitian_trace_square_zero_matrix {n : ℕ} (B : Matrix (Fin n) (Fin n) ℂ)
    (hB : B.IsHermitian) (hz : (Matrix.trace (B*B)).re=0) : B=0 := by
  rw [hermitian_trace_square_frobenius B hB] at hz
  by_contra hn
  have hp := complexFrobeniusSq_pos B hn
  linarith

theorem source_projection_complement_psd {n : ℕ} (P : Matrix (Fin n) (Fin n) ℂ)
    (hP : P.PosSemidef) (hPP : P*P=P) : (1-P).PosSemidef := by
  have he : (1-P)ᴴ*(1-P)=1-P := by
    rw [Matrix.conjTranspose_sub,Matrix.conjTranspose_one,hP.isHermitian.eq]
    simp only [sub_mul,mul_sub,one_mul,mul_one,hPP] <;> abel
  rw [← he]
  exact Matrix.posSemidef_conjTranspose_mul_self _

theorem source_equal_trace_projection_containment {n : ℕ} (P Q : Matrix (Fin n) (Fin n) ℂ)
    (hP : P.PosSemidef) (hQ : Q.PosSemidef) (hPP : P*P=P) (hQQ : Q*Q=Q)
    (htr : Matrix.trace P=Matrix.trace Q) (hPQ : P*Q=Q) (hQP : Q*P=Q) : P=Q := by
  apply sub_eq_zero.mp
  apply source_hermitian_trace_square_zero_matrix (P-Q) (hP.isHermitian.sub hQ.isHermitian)
  have he : (P-Q)*(P-Q)=P-Q := by simp only [sub_mul,mul_sub,hPP,hQQ,hPQ,hQP] <;> abel
  rw [he,Matrix.trace_sub,htr,sub_self]
  simp

theorem source_positive_projection_resolution_equality {n : ℕ}
    (P Q R : Matrix (Fin n) (Fin n) ℂ) (hP : P.PosSemidef) (hQ : Q.PosSemidef) (hR : R.PosSemidef)
    (hPP : P*P=P) (hQQ : Q*Q=Q) (htr : Matrix.trace P=Matrix.trace Q)
    (a b c : ℝ) (hb : 0 < b) (hc : 0 ≤ c)
    (hres : (a : ℂ) • P=(b : ℂ) • Q+(c : ℂ) • R) : P=Q := by
  have hC := source_projection_complement_psd P hP hPP
  have hCP : (1-P)*P=0 := by rw [sub_mul,one_mul,hPP,sub_self]
  have hnQ := source_psd_trace_pairing_nonnegative (1-P) Q hC hQ
  have hnR := source_psd_trace_pairing_nonnegative (1-P) R hC hR
  have he := congrArg (fun M : Matrix (Fin n) (Fin n) ℂ => (Matrix.trace ((1-P)*M)).re) hres
  simp only [mul_add,mul_smul_comm,hCP,smul_zero,Matrix.trace_zero,Complex.zero_re,
    Matrix.trace_add,Matrix.trace_smul,Complex.add_re,smul_eq_mul,Complex.mul_re,
    Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero] at he
  have hq : (Matrix.trace ((1-P)*Q)).re=0 := by
    have hcR := mul_nonneg hc hnR
    have hp : b*(Matrix.trace ((1-P)*Q)).re=0 := by nlinarith
    exact (mul_eq_zero.mp hp).resolve_left (ne_of_gt hb)
  obtain ⟨hCQ,hQC⟩ := source_psd_real_trace_pairing_zero_products (1-P) Q hC hQ hq
  have hPQ : P*Q=Q := by
    have h : Q-P*Q=0 := by simpa only [sub_mul,one_mul] using hCQ
    exact (sub_eq_zero.mp h).symm
  have hQP : Q*P=Q := by
    have h : Q-Q*P=0 := by simpa only [mul_sub,mul_one] using hQC
    exact (sub_eq_zero.mp h).symm
  exact source_equal_trace_projection_containment P Q hP hQ hPP hQQ htr hPQ hQP

end CoefficientStability
