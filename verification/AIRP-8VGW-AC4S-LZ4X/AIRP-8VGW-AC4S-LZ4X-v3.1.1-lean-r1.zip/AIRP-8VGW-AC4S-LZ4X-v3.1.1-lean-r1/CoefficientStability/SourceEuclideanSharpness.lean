import CoefficientStability.SourceTransportationGeometry

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1200000

theorem source_euclidean_sharpness_squared (R : ℝ) (hR : 3/8 < R) :
    ∃ (t : Fin 3 → ℝ) (B : Matrix (Fin 3) (Fin 3) ℝ),(∑ i,t i)=3 ∧
      (∀ i,0 < t i) ∧ B ∈ sourceTransportationPolytope t ∧
      (∑ i,(t i-1)^2) < R ∧ Matrix.permanent B < sourceTernaryBaseline t := by
  let d := min (1/4 : ℝ) ((R-3/8)/4)
  have hd : 0 < d := lt_min (by norm_num) (by linarith)
  have hd4 : d ≤ 1/4 := min_le_left _ _
  have hdR : d ≤ (R-3/8)/4 := min_le_right _ _
  have hd2 : d^2 ≤ d/4 := by nlinarith [mul_nonneg hd.le (sub_nonneg.mpr hd4)]
  let x := 3/2+d
  have hx : 3/2 < x := by dsimp [x];linarith
  have hx2 : x < 2 := by dsimp [x];linarith
  obtain ⟨hfeas,hgap⟩ := source_ternary_euclidean_sharp_feasible x hx hx2
  refine ⟨sourceTernarySharpTraces x,sourceTernarySharpEuclidean x,?_,?_,hfeas,?_,hgap⟩
  · norm_num [sourceTernarySharpTraces,Fin.sum_univ_succ]
  · intro i
    fin_cases i <;> norm_num [sourceTernarySharpTraces] <;> linarith
  · rw [source_ternary_euclidean_sharp_distance]
    dsimp [x]
    nlinarith [hd2,hdR]

theorem source_euclidean_sharpness_radius (r : ℝ) (hr : Real.sqrt (3/8) < r) :
    ∃ (t : Fin 3 → ℝ) (B : Matrix (Fin 3) (Fin 3) ℝ),(∑ i,t i)=3 ∧
      (∀ i,0 < t i) ∧ B ∈ sourceTransportationPolytope t ∧
      Real.sqrt (∑ i,(t i-1)^2) < r ∧ Matrix.permanent B < sourceTernaryBaseline t := by
  have hrpos : 0 < r := lt_of_le_of_lt (Real.sqrt_nonneg _) hr
  have hs := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 3/8)
  have hR : 3/8 < r^2 := by nlinarith [Real.sqrt_nonneg (3/8)]
  obtain ⟨t,B,ht,htpos,hfeas,hnear,hgap⟩ := source_euclidean_sharpness_squared (r^2) hR
  refine ⟨t,B,ht,htpos,hfeas,?_,hgap⟩
  have hsR := Real.sq_sqrt (Finset.sum_nonneg (fun i (_ : i ∈ Finset.univ) => sq_nonneg (t i-1)))
  by_contra hh
  have hge : r ≤ Real.sqrt (∑ i,(t i-1)^2) := le_of_not_gt hh
  nlinarith [Real.sqrt_nonneg (∑ i,(t i-1)^2)]

end CoefficientStability
