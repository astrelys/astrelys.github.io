import CoefficientStability.CapacityGMonotonicity
import Mathlib.Analysis.Calculus.Deriv.Pow

noncomputable section
open scoped Topology
namespace CoefficientStability

def capacityLogBarrier (s : ℝ) : ℝ := Real.log (1-s)+s+s^2/2

theorem capacityLogBarrier_hasDerivAt (s : ℝ) (hs : s<1) :
    HasDerivAt capacityLogBarrier (-1/(1-s)+1+s) s := by
  have hlog := ((hasDerivAt_id s).const_sub 1).log (by linarith : 1-s≠0)
  have hpow := (hasDerivAt_pow 2 s).div_const 2
  have h := (hlog.add (hasDerivAt_id s)).add hpow
  convert! h using 1 <;> simp only [capacityLogBarrier,Pi.add_def,id_eq,Nat.cast_ofNat,Nat.reduceSub,pow_one] <;> ring

theorem log_one_sub_quadratic_upper (s : ℝ) (hs0 : 0≤s) (hs1 : s<1) :
    Real.log (1-s)≤ -s-s^2/2 := by
  have hC : ContinuousOn capacityLogBarrier (Set.Ico (0 : ℝ) 1) := fun x hx =>
    (capacityLogBarrier_hasDerivAt x hx.2).continuousAt.continuousWithinAt
  have hM : AntitoneOn capacityLogBarrier (Set.Ico (0 : ℝ) 1) := by
    apply antitoneOn_of_hasDerivWithinAt_nonpos (convex_Ico 0 1) hC
      (fun x hx => (capacityLogBarrier_hasDerivAt x (interior_subset hx).2).hasDerivWithinAt)
    intro x hx
    have hpos : 0<1-x := sub_pos.mpr (interior_subset hx).2
    have he : -1/(1-x)+1+x= -x^2/(1-x) := by field_simp <;> ring
    rw [he]
    exact div_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr (sq_nonneg _)) hpos.le
  have h := hM (by constructor <;> norm_num) ⟨hs0,hs1⟩ hs0
  simp only [capacityLogBarrier,sub_zero,Real.log_one,zero_add,zero_pow (by norm_num : (2 : ℕ)≠0),zero_div,add_zero] at h
  linarith

theorem capacityLogG_derivative_upper (x : ℝ) (hx : 1<x) :
    Real.log (1-1/x)+1/x≤ -1/(2*x^2) := by
  have hxp : 0<x := by linarith
  have hrec : 0≤1/x := (one_div_pos.mpr hxp).le
  have hrec1 : 1/x<1 := (div_lt_one hxp).mpr hx
  have h := log_one_sub_quadratic_upper (1/x) hrec hrec1
  have he : (1/x)^2/2=1/(2*x^2) := by field_simp
  rw [he] at h
  simp only [neg_div]
  linarith

end CoefficientStability
