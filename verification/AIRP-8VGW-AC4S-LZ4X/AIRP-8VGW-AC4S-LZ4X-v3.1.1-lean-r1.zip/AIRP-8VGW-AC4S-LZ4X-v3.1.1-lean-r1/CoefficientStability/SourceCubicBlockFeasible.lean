import CoefficientStability.SourceCubicBlockEnergy

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 2600000
set_option backward.isDefEq.respectTransparency false

theorem source_cubic_block_replacement_feasible (t a b : Fin 3 → ℝ)
    (V W : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (hV : ∀ i,(V i).IsHermitian) (hW : ∀ i,(W i).IsHermitian)
    (htV : ∀ i,Matrix.trace (V i)=0) (htW : ∀ i,Matrix.trace (W i)=0)
    (hs : (∑ i,W i)=∑ i,V i) (hq : ∀ i,sourceTwoTraceQuadratic (W i) ≤ sourceTwoTraceQuadratic (V i))
    (hA : sourceCubicBlockTuple a b V ∈ hermitianFeasibleTuples t) :
    sourceCubicBlockTuple a b W ∈ hermitianFeasibleTuples t := by
  have hPSD (i : Fin 3) : (sourceCubicBlockTuple a b W i).PosSemidef := by
    obtain ⟨ha,hB⟩ := source_one_two_block_psd_components (a i) (sourceTwoCentered (b i) (V i)) (hA.1 i).2.1
    have hBW := source_two_centered_psd_of_quadratic_decrease (b i) (V i) (W i) (hV i) (hW i) (htV i) (htW i) hB (hq i)
    exact source_one_two_block_psd (a i) ha _ hBW
  refine ⟨?_,?_⟩
  · intro i
    refine ⟨(hPSD i).isHermitian,hPSD i,?_⟩
    exact (source_cubic_block_tuple_traces a b W htW i).trans
      ((source_cubic_block_tuple_traces a b V htV i).symm.trans (hA.1 i).2.2)
  · have hsum : (∑ i,sourceTwoCentered (b i) (W i))=∑ i,sourceTwoCentered (b i) (V i) := by
      simp only [sourceTwoCentered,Finset.sum_add_distrib,hs]
    have hold := hA.2
    change (∑ i,sourceOneTwoBlock (a i) (sourceTwoCentered (b i) (V i)))=1 at hold
    rw [source_one_two_block_sum] at hold
    change (∑ i,sourceOneTwoBlock (a i) (sourceTwoCentered (b i) (W i)))=1
    rw [source_one_two_block_sum,hsum]
    exact hold

theorem source_one_two_block_continuous (a : ℝ) : Continuous (sourceOneTwoBlock a) := by
  apply continuous_matrix
  intro i j
  fin_cases i <;> fin_cases j
  · change Continuous (fun _ : Matrix (Fin 2) (Fin 2) ℂ => (a : ℂ))
    exact continuous_const
  · change Continuous (fun _ : Matrix (Fin 2) (Fin 2) ℂ => (0 : ℂ))
    exact continuous_const
  · change Continuous (fun _ : Matrix (Fin 2) (Fin 2) ℂ => (0 : ℂ))
    exact continuous_const
  · change Continuous (fun _ : Matrix (Fin 2) (Fin 2) ℂ => (0 : ℂ))
    exact continuous_const
  · change Continuous (fun B : Matrix (Fin 2) (Fin 2) ℂ => B 0 0)
    exact continuous_id.matrix_elem (0 : Fin 2) (0 : Fin 2)
  · change Continuous (fun B : Matrix (Fin 2) (Fin 2) ℂ => B 0 1)
    exact continuous_id.matrix_elem (0 : Fin 2) (1 : Fin 2)
  · change Continuous (fun _ : Matrix (Fin 2) (Fin 2) ℂ => (0 : ℂ))
    exact continuous_const
  · change Continuous (fun B : Matrix (Fin 2) (Fin 2) ℂ => B 1 0)
    exact continuous_id.matrix_elem (1 : Fin 2) (0 : Fin 2)
  · change Continuous (fun B : Matrix (Fin 2) (Fin 2) ℂ => B 1 1)
    exact continuous_id.matrix_elem (1 : Fin 2) (1 : Fin 2)

theorem source_cubic_block_curve_continuous (a b : Fin 3 → ℝ)
    (V : ℝ → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hV : Continuous V) :
    Continuous (fun s : ℝ => sourceCubicBlockTuple a b (V s)) := by
  apply continuous_pi
  intro i
  have hi : Continuous (fun s : ℝ => V s i) := (continuous_apply i).comp hV
  have hc : Continuous (fun s : ℝ => sourceTwoCentered (b i) (V s i)) := by
    unfold sourceTwoCentered
    exact continuous_const.add hi
  exact (source_one_two_block_continuous (a i)).comp hc

end CoefficientStability
