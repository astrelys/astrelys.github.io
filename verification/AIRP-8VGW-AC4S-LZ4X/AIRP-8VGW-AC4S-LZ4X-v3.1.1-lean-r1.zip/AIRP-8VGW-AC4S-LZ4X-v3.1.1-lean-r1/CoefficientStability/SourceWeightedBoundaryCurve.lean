import CoefficientStability.SourceBlockProjection

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {m : ℕ}

def sourceWeightedBoundaryCurve (α : Fin m → ℕ) (t : Fin m → ℝ) (s : ℝ) :
    SourceHomogeneousPolynomials m (sourceCloneCount α) :=
  ⟨rectangularSubstitution (sourceCloneRecoveryMatrix α) (stableBoundaryCurve (sourceClonedGradient α t) s).val,
    rectangularSubstitution_homogeneous _ _ _ (stableBoundaryCurve (sourceClonedGradient α t) s).property⟩

def sourceWeightedBoundaryRows (α : Fin m → ℕ) (t : Fin m → ℝ) (s : ℝ)
    (r : Fin (sourceCloneCount α)) (i : Fin m) : ℝ :=
  (α i : ℝ)*sourceBoundaryBlockWeight α t s r i

theorem sourceWeightedBoundaryCurve_clones (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (t : Fin m → ℝ) (s : ℝ) :
    sourceClonePolynomial α (sourceWeightedBoundaryCurve α t s).val=
      (stableBoundaryCurve (sourceClonedGradient α t) s).val := by
  exact sourceClone_fixed_block_diagonal α hα (boundaryCoefficientMatrix (sourceClonedGradient α t) s)
    (sourceBoundaryBlockWeight α t s) (sourceBoundaryMatrix_block_constant α t s)

theorem sourceWeightedBoundaryCurve_zero (α : Fin m → ℕ) (hα : ∀ i,0 < α i) (t : Fin m → ℝ) :
    sourceWeightedBoundaryCurve α t 0=sourceWeightedReference α t := by
  apply Subtype.ext
  have he := congrArg Subtype.val (stableBoundaryCurve_zero (sourceClonedGradient α t))
  change rectangularSubstitution (sourceCloneRecoveryMatrix α) (stableBoundaryCurve (sourceClonedGradient α t) 0).val=
    scalarPower t (sourceCloneCount α)
  rw [he]
  change rectangularSubstitution (sourceCloneRecoveryMatrix α) (scalarPower (sourceClonedGradient α t) (sourceCloneCount α))=_
  rw [← sourceClonePolynomial_scalarPower,sourceClonePolynomial_ring_recovery α hα]

theorem sourceWeightedBoundaryCurve_coefficient (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (t : Fin m → ℝ) (s : ℝ) :
    sourceCloneCoefficientWeight α*sourceMultiindexObjective α (sourceWeightedBoundaryCurve α t s)=
      fixedDegreeObjective (stableBoundaryCurve (sourceClonedGradient α t) s) := by
  have h := sourceClonePolynomial_squarefree_coefficient α (sourceWeightedBoundaryCurve α t s).val
  rw [sourceWeightedBoundaryCurve_clones α hα] at h
  exact h.symm

theorem sourceWeightedBoundaryCurve_distance (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (t : Fin m → ℝ) (s r : ℝ) :
    coefficientL1 ((sourceWeightedBoundaryCurve α t s).val-(sourceWeightedBoundaryCurve α t r).val)=
      coefficientL1 ((stableBoundaryCurve (sourceClonedGradient α t) s).val-
        (stableBoundaryCurve (sourceClonedGradient α t) r).val) := by
  have h := sourceClonePolynomial_distance_isometry α hα
    (sourceWeightedBoundaryCurve α t s).val (sourceWeightedBoundaryCurve α t r).val
  rw [sourceWeightedBoundaryCurve_clones α hα,sourceWeightedBoundaryCurve_clones α hα] at h
  exact h.symm

theorem sourceWeightedBoundaryCurve_feasible (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (hN : 2 ≤ sourceCloneCount α) (t : Fin m → ℝ)
    (ht : (∑ i,t i)=sourceCloneCount α) (htpos : ∀ i,0 < t i) :
    ∃ e : ℝ,0 < e ∧ ∀ s : ℝ,|s| < e → sourceWeightedBoundaryCurve α t s ∈ sourceMultiindexCoefficientClass α t := by
  obtain ⟨e,he,hfeas⟩ := stableBoundaryCurve_feasible_near_zero (sourceClonedGradient α t) hN
    ((sourceClonedGradient_sum α hα t).trans ht) (sourceClonedGradient_pos α hα t htpos)
  refine ⟨e,he,?_⟩
  intro s hs
  have hold := hfeas s hs
  have hrow := sourceCloneRecoveryMatrix_row α
  refine ⟨rectangularSubstitution_normalized _ _ hrow hold.1,
    rectangularSubstitution_stable _ _ hold.2.1 (sourceCloneRecoveryMatrix_nonnegative α) hrow,
    rectangularSubstitution_coeff_nonnegative _ _ _ (stableBoundaryCurve (sourceClonedGradient α t) s).property
      hold.2.1 hold.1 (sourceCloneRecoveryMatrix_nonnegative α) hrow,?_⟩
  intro i
  change MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i
    (rectangularSubstitution (sourceCloneRecoveryMatrix α) (stableBoundaryCurve (sourceClonedGradient α t) s).val))=t i
  rw [rectangularSubstitution_actual_gradient _ _ hrow]
  have hgrad : (fun j => MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv j
      (stableBoundaryCurve (sourceClonedGradient α t) s).val))=sourceClonedGradient α t := funext hold.2.2.2
  rw [hgrad,sourceCloneRecovery_original_gradient α hα]

theorem sourceWeightedBoundaryCurve_product (α : Fin m → ℕ) (t : Fin m → ℝ) (s : ℝ) :
    (sourceWeightedBoundaryCurve α t s).val=
      ∏ r : Fin (sourceCloneCount α),scalarLinear (sourceWeightedBoundaryRows α t s r) 1 := by
  change rectangularSubstitution (sourceCloneRecoveryMatrix α)
    (diagonalPencilPolynomial (boundaryCoefficientMatrix (sourceClonedGradient α t) s))=_
  rw [diagonalPencilPolynomial_eq_product,map_prod]
  apply Finset.prod_congr rfl
  intro r hr
  have he : rectangularSourceGradient (sourceCloneRecoveryMatrix α)
      (fun j => sourceBoundaryBlockWeight α t s r (sourceCloneBlock α j))=sourceWeightedBoundaryRows α t s r :=
    funext (sourceCloneRecovery_block_gradient α (sourceBoundaryBlockWeight α t s r))
  have h := rectangularSubstitution_scalarLinear (sourceCloneRecoveryMatrix α)
    (fun j => sourceBoundaryBlockWeight α t s r (sourceCloneBlock α j)) 1
  rw [he] at h
  simpa only [scalarLinear,Nat.cast_one,div_one,sourceBoundaryMatrix_block_constant] using h

theorem sourceWeightedBoundaryRows_positive_near_zero (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (hN : 2 ≤ sourceCloneCount α) (t : Fin m → ℝ) (htpos : ∀ i,0 < t i) :
    ∃ e : ℝ,0 < e ∧ ∀ s : ℝ,|s| < e → ∀ r i,0 < sourceWeightedBoundaryRows α t s r i := by
  let base : Fin (sourceCloneCount α) × Fin m → ℝ := fun q =>
    (α q.2 : ℝ)*((t q.2/(α q.2 : ℝ))/(sourceCloneCount α : ℝ))
  let slope : Fin (sourceCloneCount α) × Fin m → ℝ := fun q =>
    (α q.2 : ℝ)*((t q.2/(α q.2 : ℝ))*(1-((sourceCloneCount α : ℝ)/marginalNormSq (sourceClonedGradient α t))*(t q.2/(α q.2 : ℝ))))*
      boundaryModelDiagonal (sourceCloneCount α) q.1
  have hbase (q : Fin (sourceCloneCount α) × Fin m) : 0 < base q := by
    have ha : (0 : ℝ)<α q.2 := by exact_mod_cast hα q.2
    have hn : (0 : ℝ)<sourceCloneCount α := by exact_mod_cast (show 0<sourceCloneCount α by omega)
    exact mul_pos ha (div_pos (div_pos (htpos q.2) ha) hn)
  obtain ⟨e,he,hnear⟩ := finite_affine_positive_near_zero base slope hbase
  refine ⟨e,he,?_⟩
  intro s hs r i
  have h := hnear s hs (r,i)
  have heq : sourceWeightedBoundaryRows α t s r i=base (r,i)+s*slope (r,i) := by
    unfold sourceWeightedBoundaryRows sourceBoundaryBlockWeight base slope
    ring
  rwa [heq]

end CoefficientStability
