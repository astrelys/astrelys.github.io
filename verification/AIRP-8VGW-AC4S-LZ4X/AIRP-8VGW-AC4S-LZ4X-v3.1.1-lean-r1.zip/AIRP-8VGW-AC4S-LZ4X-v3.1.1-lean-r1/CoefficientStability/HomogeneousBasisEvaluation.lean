import CoefficientStability.HomogeneousPureCoordinate

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem nonpure_exponent_has_other (g : Fin n →₀ ℕ) (N : ℕ) (j : Fin n)
    (hmass : ∑ k,g k=N) (hne : g≠Finsupp.single j N) : ∃ k,k≠j ∧ 0<g k := by
  classical
  have hle : g j≤N :=
    (Finset.single_le_sum (fun k hk => Nat.zero_le (g k)) (Finset.mem_univ j)).trans_eq hmass
  have hlt : g j<N := lt_of_le_of_ne hle (fun hj => hne (exponent_eq_pure_of_mass g N j hmass hj))
  have hsum := Finset.sum_erase_add (Finset.univ : Finset (Fin n)) (fun k => g k) (Finset.mem_univ j)
  rw [hmass] at hsum
  have hpos : 0<∑ k∈Finset.univ.erase j,g k := by omega
  obtain ⟨k,hk,hkp⟩ : ∃ k∈Finset.univ.erase j,0<g k := by
    by_contra hh
    push_neg at hh
    have hz : (∑ k∈Finset.univ.erase j,g k)=0 :=
      Finset.sum_eq_zero (fun k hk => Nat.eq_zero_of_le_zero (hh k hk))
    omega
  exact ⟨k,(Finset.mem_erase.mp hk).1,hkp⟩

theorem homogeneous_eval_basis (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (j : Fin n) :
    MvPolynomial.eval (Pi.single j (1 : ℝ)) p=p.coeff (Finsupp.single j N) := by
  classical
  have he : MvPolynomial.eval (Pi.single j (1 : ℝ)) p=
      ∑ g∈p.support,p.coeff g*(∏ k,((Pi.single j (1 : ℝ) : Fin n → ℝ) k)^g k) := by
    conv_lhs => rw [p.as_sum]
    simp only [map_sum,eval_monomial_univ]
  rw [he]
  have hterm (g : Fin n →₀ ℕ) (hg : g∈p.support) :
      p.coeff g*(∏ k,((Pi.single j (1 : ℝ) : Fin n → ℝ) k)^g k)=
        if g=Finsupp.single j N then p.coeff g else 0 := by
    by_cases hgi : g=Finsupp.single j N
    · subst g
      simp [Finsupp.single_apply,Pi.single_apply]
    · rw [if_neg hgi]
      obtain ⟨k,hkj,hkpos⟩ := nonpure_exponent_has_other g N j (homogeneous_mass p N hp g hg) hgi
      have hprod : (∏ k,((Pi.single j (1 : ℝ) : Fin n → ℝ) k)^g k)=0 := by
        apply Finset.prod_eq_zero (Finset.mem_univ k)
        simp [Pi.single_apply,hkj,Ne.symm hkj,ne_of_gt hkpos]
      rw [hprod,mul_zero]
  rw [Finset.sum_congr rfl (fun g hg => hterm g hg)]
  by_cases hmem : Finsupp.single j N∈p.support
  · simp [Finset.sum_ite_eq',hmem]
  · simp [Finset.sum_ite_eq',hmem,MvPolynomial.notMem_support_iff.mp hmem]

end CoefficientStability
