import CoefficientStability.SourceWeightedLocalGrowth

noncomputable section
open scoped BigOperators Topology
open Filter
namespace CoefficientStability

abbrev SourceHomogeneousPolynomials (m d : ℕ) := MvPolynomial.homogeneousSubmodule (Fin m) ℝ d

instance sourceHomogeneousCoefficientTopology (m d : ℕ) : TopologicalSpace (SourceHomogeneousPolynomials m d) :=
  TopologicalSpace.induced (fun (p : SourceHomogeneousPolynomials m d) (g : Fin m →₀ ℕ) => p.val.coeff g) inferInstance

theorem sourceHomogeneous_coefficient_continuous (m d : ℕ) (g : Fin m →₀ ℕ) :
    Continuous (fun p : SourceHomogeneousPolynomials m d => p.val.coeff g) :=
  (continuous_apply g).comp continuous_induced_dom

def sourceGeneralDegreeSupport (m d : ℕ) : Finset (Fin m →₀ ℕ) := (Finsupp.finite_of_degree_eq d).toFinset

theorem sourceHomogeneous_support_subset {m d : ℕ} (p : MvPolynomial (Fin m) ℝ) (hp : p.IsHomogeneous d) :
    p.support ⊆ sourceGeneralDegreeSupport m d := by
  classical
  intro g hg
  change g ∈ (Finsupp.finite_of_degree_eq d).toFinset
  simp only [Set.Finite.mem_toFinset,Set.mem_setOf_eq]
  by_contra hdeg
  exact (MvPolynomial.mem_support_iff.mp hg) (hp.coeff_eq_zero hdeg)

theorem sourceHomogeneous_coefficientL1_continuous (m d : ℕ) (q : SourceHomogeneousPolynomials m d) :
    Continuous (fun p : SourceHomogeneousPolynomials m d => coefficientL1 (p.val-q.val)) := by
  classical
  have he : (fun p : SourceHomogeneousPolynomials m d => coefficientL1 (p.val-q.val))=
      (fun p => ∑ g ∈ sourceGeneralDegreeSupport m d,|p.val.coeff g-q.val.coeff g|) := by
    funext p
    rw [coefficientL1_eq_sum_on _ _ (sourceHomogeneous_support_subset _ (p.property.sub q.property))]
    simp
  rw [he]
  apply continuous_finset_sum
  intro g hg
  exact ((sourceHomogeneous_coefficient_continuous m d g).sub continuous_const).abs

def sourceWeightedReference {m : ℕ} (α : Fin m → ℕ) (t : Fin m → ℝ) : SourceHomogeneousPolynomials m (sourceCloneCount α) :=
  ⟨scalarPower t (sourceCloneCount α),scalarPower_homogeneous t (sourceCloneCount α)⟩

def sourceMultiindexCoefficientClass {m : ℕ} (α : Fin m → ℕ) (t : Fin m → ℝ) :
    Set (SourceHomogeneousPolynomials m (sourceCloneCount α)) :=
  {p | MvPolynomial.eval (fun _ => 1) p.val=1 ∧ UpperHalfPlaneZeroFree p.val ∧
    (∀ g,0 ≤ p.val.coeff g) ∧ ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p.val)=t i}

def sourceMultiindexObjective {m : ℕ} (α : Fin m → ℕ) (p : SourceHomogeneousPolynomials m (sourceCloneCount α)) : ℝ :=
  p.val.coeff (sourceMultiExponent α)

@[simp] theorem sourceWeightedReference_objective {m : ℕ} (α : Fin m → ℕ) (t : Fin m → ℝ) :
    sourceMultiindexObjective α (sourceWeightedReference α t)=sourceMultiIndexBaseline α t :=
  sourceScalarPower_multiindex_baseline α t

theorem sourceWeightedReference_feasible {m : ℕ} (α : Fin m → ℕ) (hN : 2 ≤ sourceCloneCount α)
    (t : Fin m → ℝ) (ht : (∑ i,t i)=sourceCloneCount α) (htpos : ∀ i,0 < t i) :
    sourceWeightedReference α t ∈ sourceMultiindexCoefficientClass α t := by
  obtain ⟨hp,hnorm,hs,hc,hgrad⟩ := scalarPower_general_source_feasible t (sourceCloneCount α) (by omega) ht htpos
  exact ⟨hnorm,hs,hc,hgrad⟩

theorem source_weighted_topological_local_minimum {m : ℕ} (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (hN : 2 ≤ sourceCloneCount α) (t : Fin m → ℝ)
    (ht : (∑ i,t i)=sourceCloneCount α) (htpos : ∀ i,0 < t i)
    (hradius : (∑ i,(t i-(α i : ℝ))^2/(α i : ℝ)) < (sourceCloneCount α : ℝ)/((sourceCloneCount α : ℝ)-1)) :
    IsLocalMinOn (sourceMultiindexObjective α) (sourceMultiindexCoefficientClass α t) (sourceWeightedReference α t) := by
  obtain ⟨a,e,ha,he,hgrowth⟩ := source_weighted_local_variance_growth α hα hN t ht htpos hradius
  have hopen : IsOpen {p : SourceHomogeneousPolynomials m (sourceCloneCount α) |
      coefficientL1 (p.val-(sourceWeightedReference α t).val) < e} :=
    isOpen_lt (sourceHomogeneous_coefficientL1_continuous m (sourceCloneCount α) _) continuous_const
  have hnear : ∀ᶠ p in 𝓝 (sourceWeightedReference α t),coefficientL1 (p.val-(sourceWeightedReference α t).val) < e :=
    hopen.mem_nhds (by simpa only [sub_self,coefficientL1_zero,Set.mem_setOf_eq] using he)
  change ∀ᶠ p in 𝓝[sourceMultiindexCoefficientClass α t] (sourceWeightedReference α t),
    sourceMultiindexObjective α (sourceWeightedReference α t) ≤ sourceMultiindexObjective α p
  filter_upwards [self_mem_nhdsWithin,hnear.filter_mono nhdsWithin_le_nhds] with p hp hclose
  have hg := (hgrowth p.val p.property hp.1 hp.2.1 hp.2.2.2 hclose).1
  have hδ := sourceWeightedDeficit_nonnegative α hα hN p.val p.property hp.2.1 hp.1 t hp.2.2.2
  have hnonneg := (mul_nonneg ha.le hδ).trans hg
  rw [sourceWeightedReference_objective]
  exact sub_nonneg.mp hnonneg

theorem source_weighted_topological_strict_local {m : ℕ} (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (hN : 2 ≤ sourceCloneCount α) (t : Fin m → ℝ)
    (ht : (∑ i,t i)=sourceCloneCount α) (htpos : ∀ i,0 < t i)
    (hradius : (∑ i,(t i-(α i : ℝ))^2/(α i : ℝ)) < (sourceCloneCount α : ℝ)/((sourceCloneCount α : ℝ)-1)) :
    ∀ᶠ p in 𝓝[sourceMultiindexCoefficientClass α t] (sourceWeightedReference α t),
      p≠sourceWeightedReference α t → sourceMultiindexObjective α (sourceWeightedReference α t) < sourceMultiindexObjective α p := by
  obtain ⟨a,e,ha,he,hgrowth⟩ := source_weighted_local_variance_growth α hα hN t ht htpos hradius
  have hopen : IsOpen {p : SourceHomogeneousPolynomials m (sourceCloneCount α) |
      coefficientL1 (p.val-(sourceWeightedReference α t).val) < e} :=
    isOpen_lt (sourceHomogeneous_coefficientL1_continuous m (sourceCloneCount α) _) continuous_const
  have hnear : ∀ᶠ p in 𝓝 (sourceWeightedReference α t),coefficientL1 (p.val-(sourceWeightedReference α t).val) < e :=
    hopen.mem_nhds (by simpa only [sub_self,coefficientL1_zero,Set.mem_setOf_eq] using he)
  filter_upwards [self_mem_nhdsWithin,hnear.filter_mono nhdsWithin_le_nhds] with p hp hclose
  intro hne
  have hpne : p.val≠scalarPower t (sourceCloneCount α) := fun h => hne (Subtype.ext h)
  have h := (hgrowth p.val p.property hp.1 hp.2.1 hp.2.2.2 hclose).2 hpne
  rw [sourceWeightedReference_objective]
  exact h

end CoefficientStability
