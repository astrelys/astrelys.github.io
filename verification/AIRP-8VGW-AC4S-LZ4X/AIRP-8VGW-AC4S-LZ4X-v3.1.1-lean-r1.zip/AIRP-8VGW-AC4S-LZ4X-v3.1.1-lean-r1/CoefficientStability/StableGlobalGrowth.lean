import CoefficientStability.SourcePolynomialGlobalUniqueness
import CoefficientStability.StableDimensionTwo

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem source_stable_global_growth_exists (hn : 2 ≤ n) :
    ∃ ε κ : ℝ,0 < ε ∧ 0 < κ ∧
      ∀ (t : Fin n → ℝ) (p : MvPolynomial (Fin n) ℝ),p.IsHomogeneous n →
        UpperHalfPlaneZeroFree p → MvPolynomial.eval (fun _ => 1) p=1 →
        (∑ i,t i)=n → (∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) →
        (∑ i,|t i-1|) < ε →
        κ*referenceDeficit p t n ≤ p.coeff (squarefreeExponent n)-sourceVn n*(∏ i,t i) := by
  by_cases htwo : n=2
  · subst n
    refine ⟨1,1,by norm_num,by norm_num,?_⟩
    intro t p hp hs hnorm ht hgrad hnear
    have h := paper_stable_dimension_two_gap p t hp hnorm hs ht hgrad
    have hdiff : (p-scalarPower t 2).coeff (squarefreeExponent 2)=
        p.coeff (squarefreeExponent 2)-(scalarPower t 2).coeff (squarefreeExponent 2) := by simp
    rw [hdiff,scalarPower_squarefree_coefficient] at h
    simpa only [one_mul,sourceVn] using h.ge
  · have hn3 : 3 ≤ n := by omega
    refine ⟨1/(1000000000*(n : ℝ)^8),sourceVn n/(2000000000*(n : ℝ)^8),by positivity,
      div_pos (sourceVn_pos (by omega)) (by positivity),?_⟩
    intro t p hp hs hnorm ht hgrad hnear
    have h := source_polynomial_global_coefficient_gap p hn3 hp hs hnorm (by simpa only [hgrad] using hnear.le)
    have he : (fun i => MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p))=t := funext hgrad
    rwa [he] at h

theorem source_polynomial_global_minimizer (t : Fin n → ℝ) (hn : 3 ≤ n)
    (ht : (∑ i,t i)=n) (htpos : ∀ i,0 < t i)
    (hnear : (∑ i,|t i-1|) ≤ 1/(1000000000*(n : ℝ)^8)) :
    fixedDegreeReference t ∈ stableCoefficientClass t ∧
      ∀ p ∈ stableCoefficientClass t,
        fixedDegreeObjective (fixedDegreeReference t) ≤ fixedDegreeObjective p ∧
        (fixedDegreeObjective p=fixedDegreeObjective (fixedDegreeReference t) ↔ p=fixedDegreeReference t) := by
  refine ⟨fixedDegreeReference_feasible t (by omega) ht htpos,?_⟩
  intro p hp
  have h := source_polynomial_global_equality_iff p.val t hn p.property hp.2.1 hp.1 ht hp.2.2.2 hnear
  have hreference : fixedDegreeObjective (fixedDegreeReference t)=sourceVn n*(∏ i,t i) :=
    scalarPower_squarefree_coefficient t
  rw [hreference]
  refine ⟨h.1,?_⟩
  change p.val.coeff (squarefreeExponent n)=sourceVn n*(∏ i,t i) ↔ p=fixedDegreeReference t
  rw [h.2]
  constructor
  · intro he
    exact Subtype.ext he
  · intro he
    exact congrArg Subtype.val he

theorem source_euclidean_global_minimizer (t : Fin n → ℝ) (hn : 3 ≤ n)
    (ht : (∑ i,t i)=n) (htpos : ∀ i,0 < t i)
    (hnear : (∑ i,(t i-1)^2) ≤ 1/(10000000000000000*(n : ℝ)^15)) :
    fixedDegreeReference t ∈ stableCoefficientClass t ∧
      ∀ p ∈ stableCoefficientClass t,
        fixedDegreeObjective (fixedDegreeReference t) ≤ fixedDegreeObjective p ∧
        (fixedDegreeObjective p=fixedDegreeObjective (fixedDegreeReference t) ↔ p=fixedDegreeReference t) := by
  refine ⟨fixedDegreeReference_feasible t (by omega) ht htpos,?_⟩
  intro p hp
  have h := source_euclidean_global_equality_iff p.val t hn p.property hp.2.1 hp.1 ht hp.2.2.2 hnear
  have hreference : fixedDegreeObjective (fixedDegreeReference t)=sourceVn n*(∏ i,t i) :=
    scalarPower_squarefree_coefficient t
  rw [hreference]
  refine ⟨h.1,?_⟩
  change p.val.coeff (squarefreeExponent n)=sourceVn n*(∏ i,t i) ↔ p=fixedDegreeReference t
  rw [h.2]
  constructor
  · intro he
    exact Subtype.ext he
  · intro he
    exact congrArg Subtype.val he

end CoefficientStability
