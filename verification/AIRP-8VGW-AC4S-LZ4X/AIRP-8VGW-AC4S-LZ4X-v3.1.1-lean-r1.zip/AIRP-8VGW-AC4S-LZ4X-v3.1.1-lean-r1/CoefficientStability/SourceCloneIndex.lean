import CoefficientStability.RectangularSourceSubstitution
import Mathlib.Data.Fintype.EquivFin

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {m : ℕ}

def sourceCloneCount (α : Fin m → ℕ) : ℕ := ∑ i,α i

def sourceCloneEquiv (α : Fin m → ℕ) : (Σ i : Fin m,Fin (α i)) ≃ Fin (sourceCloneCount α) :=
  Fintype.equivFinOfCardEq (by simp [sourceCloneCount,Fintype.card_sigma])

def sourceCloneBlock (α : Fin m → ℕ) (j : Fin (sourceCloneCount α)) : Fin m :=
  ((sourceCloneEquiv α).symm j).1

@[simp] theorem sourceCloneBlock_equiv (α : Fin m → ℕ) (q : Σ i : Fin m,Fin (α i)) :
    sourceCloneBlock α (sourceCloneEquiv α q)=q.1 := by simp [sourceCloneBlock]

def sourceCloneAveragingMatrix (α : Fin m → ℕ) : Matrix (Fin m) (Fin (sourceCloneCount α)) ℝ :=
  fun i j => if sourceCloneBlock α j=i then 1/(α i : ℝ) else 0

theorem sourceCloneAveragingMatrix_nonnegative (α : Fin m → ℕ) :
    ∀ i j,0 ≤ sourceCloneAveragingMatrix α i j := by
  intro i j
  unfold sourceCloneAveragingMatrix
  split_ifs <;> positivity

theorem sourceCloneAveragingMatrix_row (α : Fin m → ℕ) (hα : ∀ i,0 < α i) (i : Fin m) :
    (∑ j,sourceCloneAveragingMatrix α i j)=1 := by
  classical
  rw [← Equiv.sum_comp (sourceCloneEquiv α) (fun j => sourceCloneAveragingMatrix α i j)]
  simp only [Fintype.sum_sigma,sourceCloneAveragingMatrix,sourceCloneBlock_equiv]
  have hne : (α i : ℝ)≠0 := by exact_mod_cast (ne_of_gt (hα i))
  simp [hne]

theorem sourceCloneAveragingMatrix_mulVec (α : Fin m → ℕ)
    (x : Fin (sourceCloneCount α) → ℝ) (i : Fin m) :
    (sourceCloneAveragingMatrix α).mulVec x i=
      (1/(α i : ℝ))*(∑ j : Fin (α i),x (sourceCloneEquiv α ⟨i,j⟩)) := by
  classical
  unfold Matrix.mulVec dotProduct
  rw [← Equiv.sum_comp (sourceCloneEquiv α) (fun j => sourceCloneAveragingMatrix α i j*x j)]
  simp only [Fintype.sum_sigma,sourceCloneAveragingMatrix,sourceCloneBlock_equiv,ite_mul,zero_mul]
  simp [Finset.mul_sum]

theorem sourceCloneAveragingMatrix_recovery (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (x : Fin m → ℝ) : (sourceCloneAveragingMatrix α).mulVec (fun j => x (sourceCloneBlock α j))=x := by
  funext i
  rw [sourceCloneAveragingMatrix_mulVec]
  simp only [sourceCloneBlock_equiv,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
  have hne : (α i : ℝ)≠0 := by exact_mod_cast (ne_of_gt (hα i))
  field_simp

theorem sourceCloneAveragingMatrix_gradient_column (α : Fin m → ℕ) (t : Fin m → ℝ)
    (j : Fin (sourceCloneCount α)) :
    (∑ i,sourceCloneAveragingMatrix α i j*t i)=t (sourceCloneBlock α j)/(α (sourceCloneBlock α j) : ℝ) := by
  classical
  simp only [sourceCloneAveragingMatrix,ite_mul,zero_mul,Finset.sum_ite_eq,Finset.mem_univ,ite_true]
  ring

theorem sourceCloneGradient_l1 (α : Fin m → ℕ) (hα : ∀ i,0 < α i) (t : Fin m → ℝ) :
    (∑ j,|t (sourceCloneBlock α j)/(α (sourceCloneBlock α j) : ℝ)-1|)=
      ∑ i,|t i-(α i : ℝ)| := by
  classical
  rw [← Equiv.sum_comp (sourceCloneEquiv α) (fun j => |t (sourceCloneBlock α j)/(α (sourceCloneBlock α j) : ℝ)-1|)]
  simp only [Fintype.sum_sigma,sourceCloneBlock_equiv,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
  apply Finset.sum_congr rfl
  intro i hi
  have hai : (0 : ℝ)<α i := by exact_mod_cast hα i
  have he : t i/(α i : ℝ)-1=(t i-(α i : ℝ))/(α i : ℝ) := by field_simp
  rw [he,abs_div,abs_of_pos hai]
  field_simp

theorem sourceCloneGradient_square_sum (α : Fin m → ℕ) (hα : ∀ i,0 < α i) (t : Fin m → ℝ) :
    (∑ j,(t (sourceCloneBlock α j)/(α (sourceCloneBlock α j) : ℝ)-1)^2)=
      ∑ i,(t i-(α i : ℝ))^2/(α i : ℝ) := by
  classical
  rw [← Equiv.sum_comp (sourceCloneEquiv α) (fun j => (t (sourceCloneBlock α j)/(α (sourceCloneBlock α j) : ℝ)-1)^2)]
  simp only [Fintype.sum_sigma,sourceCloneBlock_equiv,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
  apply Finset.sum_congr rfl
  intro i hi
  have hne : (α i : ℝ)≠0 := by exact_mod_cast (ne_of_gt (hα i))
  field_simp

end CoefficientStability
