import CoefficientStability.ZeroSumSubsetBound
import Mathlib.Combinatorics.Hall.Finite
import Mathlib.Data.Matrix.Basic
import Mathlib.Tactic.Positivity

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def matrixColumnImbalance (A : Matrix (Fin n) (Fin n) ℝ) (c : ℝ) : ℝ :=
  ∑ j,|((∑ i,A i j)-c)|

def matrixSupportNeighborhood (A : Matrix (Fin n) (Fin n) ℝ) (s : Finset (Fin n)) : Finset (Fin n) :=
  s.biUnion (fun i => Finset.univ.filter (fun j => 0<A i j))

theorem matrix_support_cut_mass_bound (A : Matrix (Fin n) (Fin n) ℝ) (c : ℝ)
    (hA : ∀ i j,0≤A i j) (hrow : ∀ i,∑ j,A i j=c) (s : Finset (Fin n)) :
    (s.card : ℝ)*c≤∑ j∈matrixSupportNeighborhood A s,∑ i,A i j := by
  classical
  let N := matrixSupportNeighborhood A s
  have hrowN (i : Fin n) (hi : i∈s) : (∑ j∈N,A i j)=c := by
    rw [← hrow i]
    apply Finset.sum_subset (Finset.subset_univ N)
    intro j hj hnot
    have hnotpos : ¬0<A i j := by
      intro hpos
      apply hnot
      exact Finset.mem_biUnion.mpr ⟨i,hi,Finset.mem_filter.mpr ⟨Finset.mem_univ j,hpos⟩⟩
    exact le_antisymm (le_of_not_gt hnotpos) (hA i j)
  calc
    (s.card : ℝ)*c=∑ i∈s,c := by simp [nsmul_eq_mul]
    _ =∑ i∈s,∑ j∈N,A i j := by
      apply Finset.sum_congr rfl
      intro i hi
      exact (hrowN i hi).symm
    _ =∑ j∈N,∑ i∈s,A i j := Finset.sum_comm
    _ ≤∑ j∈N,∑ i,A i j := by
      apply Finset.sum_le_sum
      intro j hj
      exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ s) (fun i hi hnot => hA i j)

theorem matrix_column_deviation_zero_sum (A : Matrix (Fin n) (Fin n) ℝ) (c : ℝ)
    (hrow : ∀ i,∑ j,A i j=c) : (∑ j,((∑ i,A i j)-c))=0 := by
  rw [Finset.sum_sub_distrib,Finset.sum_comm]
  simp only [hrow,Finset.sum_const,Finset.card_univ,Fintype.card_fin,sub_self]

theorem matrix_row_mass_support_hall (A : Matrix (Fin n) (Fin n) ℝ) (c : ℝ)
    (hc : 0<c) (hA : ∀ i j,0≤A i j) (hrow : ∀ i,∑ j,A i j=c)
    (himb : matrixColumnImbalance A c<2*c) :
    ∀ s : Finset (Fin n),s.card≤(matrixSupportNeighborhood A s).card := by
  classical
  intro s
  let N := matrixSupportNeighborhood A s
  by_contra hbad
  have hcard : N.card<s.card := lt_of_not_ge hbad
  have hcardR : (N.card : ℝ)+1≤s.card := by exact_mod_cast Nat.succ_le_of_lt hcard
  let v : Fin n → ℝ := fun j => (∑ i,A i j)-c
  have hv : ∑ j,v j=0 := matrix_column_deviation_zero_sum A c hrow
  have hsub := (le_abs_self (∑ j∈N,v j)).trans (zero_sum_subset_l1_half v hv N)
  have hsum : (∑ j∈N,v j)=(∑ j∈N,∑ i,A i j)-(N.card : ℝ)*c := by
    simp only [v,Finset.sum_sub_distrib,Finset.sum_const,nsmul_eq_mul]
  rw [hsum] at hsub
  change (∑ j∈N,∑ i,A i j)-(N.card : ℝ)*c≤matrixColumnImbalance A c/2 at hsub
  have hmass := matrix_support_cut_mass_bound A c hA hrow s
  change (s.card : ℝ)*c≤∑ j∈N,∑ i,A i j at hmass
  have hgap : c≤(s.card : ℝ)*c-(N.card : ℝ)*c := by nlinarith
  linarith

theorem matrix_row_mass_support_permutation (A : Matrix (Fin n) (Fin n) ℝ) (c : ℝ)
    (hc : 0<c) (hA : ∀ i j,0≤A i j) (hrow : ∀ i,∑ j,A i j=c)
    (himb : matrixColumnImbalance A c<2*c) :
    ∃ e : Equiv.Perm (Fin n),∀ i,0<A i (e i) := by
  classical
  have hh := matrix_row_mass_support_hall A c hc hA hrow himb
  obtain ⟨f,hf,hmem⟩ := (Finset.all_card_le_biUnion_card_iff_existsInjective'
    (t := fun i : Fin n => Finset.univ.filter (fun j => 0<A i j))).mp hh
  refine ⟨Equiv.ofBijective f ⟨hf,Finite.surjective_of_injective hf⟩,?_⟩
  intro i
  exact (Finset.mem_filter.mp (hmem i)).2

end CoefficientStability
