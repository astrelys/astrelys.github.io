import CoefficientStability.SourceCubicMatrixFirstOrder
import Mathlib.Analysis.Matrix.Order

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 2200000
set_option backward.isDefEq.respectTransparency false

theorem source_psd_trace_pairing_nonnegative {n : ℕ} (S X : Matrix (Fin n) (Fin n) ℂ)
    (hS : S.PosSemidef) (hX : X.PosSemidef) : 0 ≤ (Matrix.trace (S*X)).re := by
  obtain ⟨U,hU⟩ := CStarAlgebra.nonneg_iff_eq_star_mul_self.mp hS.nonneg
  have hp := hX.mul_mul_conjTranspose_same U
  have he : Matrix.trace (U*X*Uᴴ)=Matrix.trace (S*X) := by
    rw [Matrix.trace_mul_cycle,hU]
    simp only [Matrix.star_eq_conjTranspose]
  have hh : 0 ≤ Matrix.trace (U*X*Uᴴ) := hp.trace_nonneg
  have hz := Complex.nonneg_iff.mp hh
  rw [he] at hz
  exact hz.1

theorem source_psd_trace_pairing_zero_products {n : ℕ} (S X : Matrix (Fin n) (Fin n) ℂ)
    (hS : S.PosSemidef) (hX : X.PosSemidef) (hz : Matrix.trace (S*X)=0) : S*X=0 ∧ X*S=0 := by
  obtain ⟨U,hU⟩ := CStarAlgebra.nonneg_iff_eq_star_mul_self.mp hS.nonneg
  obtain ⟨V,hV⟩ := CStarAlgebra.nonneg_iff_eq_star_mul_self.mp hX.nonneg
  let T := U*Vᴴ
  have he : Matrix.trace (Tᴴ*T)=Matrix.trace (S*X) := by
    dsimp [T]
    rw [Matrix.conjTranspose_mul,Matrix.conjTranspose_conjTranspose]
    rw [Matrix.mul_assoc,Matrix.trace_mul_comm V]
    rw [hU,hV]
    simp only [Matrix.star_eq_conjTranspose]
    congr 1
    noncomm_ring
  have ht : T=0 := Matrix.trace_conjTranspose_mul_self_eq_zero_iff.mp (he.trans hz)
  have hsx : S*X=0 := by
    rw [hU,hV]
    simp only [Matrix.star_eq_conjTranspose]
    have hm : Uᴴ*U*(Vᴴ*V)=Uᴴ*T*V := by dsimp [T];noncomm_ring
    rw [hm,ht,mul_zero,zero_mul]
  refine ⟨hsx,?_⟩
  have h := congrArg Matrix.conjTranspose hsx
  simpa only [Matrix.conjTranspose_mul,hS.isHermitian.eq,hX.isHermitian.eq,Matrix.conjTranspose_zero] using h

end CoefficientStability
