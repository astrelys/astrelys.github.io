import CoefficientStability.StableLine
import Mathlib.Algebra.MvPolynomial.PDeriv
import CoefficientStability.UnivariateLogDerivative

noncomputable section
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def coordinateRestriction (z : Fin n → ℂ) (i : Fin n) :
    MvPolynomial (Fin n) ℝ →+* Polynomial ℂ :=
  MvPolynomial.eval₂Hom (Polynomial.C.comp Complex.ofRealHom)
    (fun j => if j=i then Polynomial.X else Polynomial.C (z j))

@[simp] theorem coordinateRestriction_C (z : Fin n → ℂ) (i : Fin n) (c : ℝ) :
    coordinateRestriction z i (MvPolynomial.C c)=Polynomial.C (c : ℂ) := by simp [coordinateRestriction]

@[simp] theorem coordinateRestriction_X (z : Fin n → ℂ) (i j : Fin n) :
    coordinateRestriction z i (MvPolynomial.X j)=if j=i then Polynomial.X else Polynomial.C (z j) := by
  simp [coordinateRestriction]

theorem coordinateRestriction_eval (p : MvPolynomial (Fin n) ℝ) (z : Fin n → ℂ) (i : Fin n) (w : ℂ) :
    (coordinateRestriction z i p).eval w=MvPolynomial.eval₂ Complex.ofRealHom (Function.update z i w) p := by
  classical
  change (Polynomial.evalRingHom w) (MvPolynomial.eval₂ _ _ p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c
    simp
  · funext j
    by_cases hji : j=i
    · subst j
      simp
    · simp [hji,Function.update_of_ne hji]

theorem coordinateRestriction_partial (p : MvPolynomial (Fin n) ℝ) (z : Fin n → ℂ) (i : Fin n) :
    coordinateRestriction z i (pderiv i p)=(coordinateRestriction z i p).derivative := by
  classical
  induction p using MvPolynomial.induction_on with
  | C c => simp [pderiv_C]
  | add p q hp hq => simp only [map_add,hp,hq,Polynomial.derivative_add]
  | mul_X p k hp =>
    by_cases hki : k=i
    · subst k
      simp [pderiv_mul,pderiv_X,Pi.single_apply,map_add,map_mul,hp,Polynomial.derivative_mul] <;> ring
    · simp [pderiv_mul,pderiv_X,Pi.single_apply,hki,eq_comm,map_add,map_mul,hp,Polynomial.derivative_mul] <;> ring

theorem stable_partial_logderiv_im_nonpos (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (z : Fin n → ℂ) (hz : ∀ j,0<(z j).im) (i : Fin n) :
    (MvPolynomial.eval₂ Complex.ofRealHom z (pderiv i p)/MvPolynomial.eval₂ Complex.ofRealHom z p).im≤0 := by
  classical
  have hP : complexPolynomialUpperZeroFree (coordinateRestriction z i p) := by
    intro w hw
    rw [coordinateRestriction_eval]
    apply hp
    intro j
    by_cases hji : j=i
    · subst j
      simpa only [Function.update_self] using hw
    · simpa only [Function.update_of_ne hji] using hz j
  have h := upper_zero_free_logderiv_im_nonpos (coordinateRestriction z i p) hP (z i) (hz i)
  rw [← coordinateRestriction_partial,coordinateRestriction_eval,coordinateRestriction_eval] at h
  simpa only [Function.update_eq_self] using h

end CoefficientStability
