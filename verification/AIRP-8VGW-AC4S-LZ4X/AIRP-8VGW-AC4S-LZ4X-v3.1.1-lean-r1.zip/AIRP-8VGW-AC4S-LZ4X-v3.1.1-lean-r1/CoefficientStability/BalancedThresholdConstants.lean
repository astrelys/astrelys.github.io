import CoefficientStability.BalancedLogSmallField
import CoefficientStability.CapacityEtaUpper

noncomputable section
namespace CoefficientStability
variable {n : ℕ}

def sourceSmallExcessThreshold (n : ℕ) : ℝ := sourceMixingRadius n/(160000*(n : ℝ)^3)

theorem sourceSmallExcessThreshold_pos (hn : 3≤n) : 0<sourceSmallExcessThreshold n := by
  have hn0 : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
  exact div_pos (sourceMixingRadius_pos n hn) (by positivity)

theorem sourceSmallExcessThreshold_bounds (hn : 3≤n) :
    sourceSmallExcessThreshold n≤capacityEta n/2 ∧
      sourceSmallExcessThreshold n≤sourceMixingRadius n/(64*(n : ℝ)) := by
  have hn1 : (1 : ℝ)≤n := by exact_mod_cast (by omega : 1≤n)
  have hn0 : (0 : ℝ)<n := by linarith
  have hη := capacityEta_pos n hn
  have hr := sourceMixingRadius_pos n hn
  have hp3 : (n : ℝ)≤(n : ℝ)^3 := by simpa only [pow_one] using pow_le_pow_right₀ hn1 (by omega : 1≤3)
  have hp2 : (1 : ℝ)≤(n : ℝ)^2 := one_le_pow₀ hn1
  have hTle : sourceSmallExcessThreshold n≤sourceMixingRadius n := by
    apply (div_le_iff₀ (by positivity : 0<160000*(n : ℝ)^3)).mpr
    nlinarith
  constructor
  · apply hTle.trans
    unfold sourceMixingRadius
    exact div_le_div_of_nonneg_left hη.le (by norm_num) (by nlinarith)
  · exact div_le_div_of_nonneg_left hr.le (by positivity) (by nlinarith)

theorem source_small_excess_radius_bound (hn : 3≤n) (τ : ℝ) (hτ0 : 0≤τ)
    (hτ : τ≤sourceSmallExcessThreshold n) :
    4*Real.sqrt (τ/((n : ℝ)*sourceMixingRadius n))≤1/(100*(n : ℝ)^2) := by
  have hn0 : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
  have hr := sourceMixingRadius_pos n hn
  have hden : 0<(n : ℝ)*sourceMixingRadius n := mul_pos hn0 hr
  have hq : 0≤τ/((n : ℝ)*sourceMixingRadius n) := div_nonneg hτ0 hden.le
  have hscaled := (le_div_iff₀ (by positivity : 0<160000*(n : ℝ)^3)).mp hτ
  have hm := mul_le_mul_of_nonneg_left hscaled hn0.le
  apply (sq_le_sq₀ (by positivity : 0≤4*Real.sqrt (τ/((n : ℝ)*sourceMixingRadius n)))
    (by positivity : 0≤1/(100*(n : ℝ)^2))).mp
  rw [mul_pow,Real.sq_sqrt hq]
  field_simp
  nlinarith only [hscaled]

end CoefficientStability
