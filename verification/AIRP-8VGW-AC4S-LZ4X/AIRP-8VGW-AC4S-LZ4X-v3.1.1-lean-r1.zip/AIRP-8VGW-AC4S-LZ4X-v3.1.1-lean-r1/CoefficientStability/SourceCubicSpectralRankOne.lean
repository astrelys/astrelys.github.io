import CoefficientStability.SourceCubicScalarSpectrum

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 2700000
set_option backward.isDefEq.respectTransparency false

theorem source_three_repeated_profile_one_exception (x : Fin 3 → ℝ)
    (hr : x 0=x 1 ∨ x 0=x 2 ∨ x 1=x 2) :
    ∃ (k : Fin 3) (a b : ℝ),∀ i,x i=a+b*(if i=k then 1 else 0) := by
  rcases hr with h | h | h
  · refine ⟨2,x 0,x 2-x 0,?_⟩
    intro i
    fin_cases i <;> norm_num <;> linarith
  · refine ⟨1,x 0,x 1-x 0,?_⟩
    intro i
    fin_cases i <;> norm_num <;> linarith
  · refine ⟨0,x 1,x 0-x 1,?_⟩
    intro i
    fin_cases i <;> norm_num <;> linarith

theorem source_hermitian_three_repeated_rank_one_representation
    (X : Matrix (Fin 3) (Fin 3) ℂ) (hX : X.IsHermitian)
    (hr : hX.eigenvalues 0=hX.eigenvalues 1 ∨ hX.eigenvalues 0=hX.eigenvalues 2 ∨
      hX.eigenvalues 1=hX.eigenvalues 2) :
    ∃ (a b : ℝ) (v : Fin 3 → ℂ),star v ⬝ᵥ v=1 ∧
      X=(a : ℂ) • 1+(b : ℂ) • Matrix.vecMulVec v (star v) := by
  classical
  obtain ⟨k,a,b,heig⟩ := source_three_repeated_profile_one_exception hX.eigenvalues hr
  let U := hX.eigenvectorUnitary
  let v : Fin 3 → ℂ := fun r => (U : Matrix (Fin 3) (Fin 3) ℂ) r k
  let E : Matrix (Fin 3) (Fin 3) ℂ := Matrix.diagonal (fun i => if i=k then 1 else 0)
  have hunit : star v ⬝ᵥ v=1 := by
    have h := congrFun (congrFun (Unitary.coe_star_mul_self U) k) k
    simpa [v,Matrix.mul_apply,Matrix.star_eq_conjTranspose,Matrix.conjTranspose_apply,Matrix.one_apply,dotProduct] using h
  have hdiag : Matrix.diagonal (fun i => (hX.eigenvalues i : ℂ))=(a : ℂ) • 1+(b : ℂ) • E := by
    ext i j
    by_cases hij : i=j
    · subst j
      have h := heig i
      by_cases hik : i=k
      · simp [E,Matrix.diagonal_apply,Matrix.one_apply,Matrix.smul_apply,Matrix.add_apply,hik] at h ⊢
        exact_mod_cast h
      · simp [E,Matrix.diagonal_apply,Matrix.one_apply,Matrix.smul_apply,Matrix.add_apply,hik] at h ⊢
        exact_mod_cast h
    · simp [E,Matrix.diagonal_apply,Matrix.one_apply,Matrix.smul_apply,Matrix.add_apply,hij]
  let φ := Unitary.conjStarAlgAut ℂ (Matrix (Fin 3) (Fin 3) ℂ) U
  have hE : φ E=Matrix.vecMulVec v (star v) := by
    change (U : Matrix (Fin 3) (Fin 3) ℂ)*E*star (U : Matrix (Fin 3) (Fin 3) ℂ)=_
    ext i j
    rw [Matrix.mul_apply]
    simp [E,Matrix.mul_diagonal,Matrix.star_eq_conjTranspose,Matrix.conjTranspose_apply,
      v,Matrix.vecMulVec_apply,mul_ite,ite_mul]
  refine ⟨a,b,v,hunit,?_⟩
  calc
    X=φ (Matrix.diagonal (fun i => (hX.eigenvalues i : ℂ))) := hX.spectral_theorem
    _=(a : ℂ) • 1+(b : ℂ) • Matrix.vecMulVec v (star v) := by
      rw [hdiag,map_add,map_smul,map_smul,map_one,hE]

theorem source_cubic_scalar_certificate_rank_one (t c : ℝ)
    (X S : Matrix (Fin 3) (Fin 3) ℂ) (hX : X.PosSemidef) (ht : Matrix.trace X=(t : ℂ))
    (hc : sourceCubicMatrixGradient t X=(c : ℂ) • 1+S) (hSX : S*X=0) :
    ∃ (a b : ℝ) (v : Fin 3 → ℂ),star v ⬝ᵥ v=1 ∧
      X=(a : ℂ) • 1+(b : ℂ) • Matrix.vecMulVec v (star v) :=
  source_hermitian_three_repeated_rank_one_representation X hX.isHermitian
    (source_cubic_scalar_certificate_repeated_eigenvalue t c X S hX ht hc hSX)

end CoefficientStability
