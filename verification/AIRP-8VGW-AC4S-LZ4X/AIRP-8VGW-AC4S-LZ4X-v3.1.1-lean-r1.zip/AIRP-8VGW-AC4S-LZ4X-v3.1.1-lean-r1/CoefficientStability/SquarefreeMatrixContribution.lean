import CoefficientStability.NonnegativeHomogeneousSubstitution

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem squarefree_unit_monomial_product (n : ℕ) :
    (MvPolynomial.monomial (squarefreeExponent n) (1 : ℝ))=∏ i : Fin n,MvPolynomial.X i := by
  have h := product_linear_assignment_monomial (id : Fin n → Fin n) (fun _ => (1 : ℝ)) Finset.univ
  simpa [squarefreeExponent] using h.symm

theorem matrixSubstitution_squarefree_unit_coefficient (B : Matrix (Fin n) (Fin n) ℝ) :
    (matrixSubstitution B (MvPolynomial.monomial (squarefreeExponent n) (1 : ℝ))).coeff (squarefreeExponent n)=
      ∑ s : Equiv.Perm (Fin n),∏ i,B i (s i) := by
  rw [squarefree_unit_monomial_product,map_prod]
  simp only [matrixSubstitution_X]
  exact coefficient_product_linear_forms B

theorem matrixSubstitution_squarefree_unit_diagonal_lower (B : Matrix (Fin n) (Fin n) ℝ)
    (hB : ∀ i j,0≤B i j) :
    (∏ i,B i i)≤(matrixSubstitution B (MvPolynomial.monomial (squarefreeExponent n) (1 : ℝ))).coeff (squarefreeExponent n) := by
  classical
  rw [matrixSubstitution_squarefree_unit_coefficient]
  have h : (∏ i,B i ((1 : Equiv.Perm (Fin n)) i))≤∑ s : Equiv.Perm (Fin n),∏ i,B i (s i) :=
    Finset.single_le_sum (fun (s : Equiv.Perm (Fin n)) hs => Finset.prod_nonneg (fun i hi => hB i (s i))) (Finset.mem_univ _)
  simpa using h

theorem homogeneous_matrixSubstitution_squarefree_contribution (q : MvPolynomial (Fin n) ℝ)
    (hq : q.IsHomogeneous n) (hc : ∀ g,0≤q.coeff g) (B : Matrix (Fin n) (Fin n) ℝ)
    (hB : ∀ i j,0≤B i j) :
    q.coeff (squarefreeExponent n)*(∏ i,B i i)≤(matrixSubstitution B q).coeff (squarefreeExponent n) := by
  classical
  let α := squarefreeExponent n
  have hscalar : MvPolynomial.monomial α (q.coeff α)=MvPolynomial.C (q.coeff α)*MvPolynomial.monomial α 1 := by
    rw [MvPolynomial.C_mul_monomial,mul_one]
  have hterm : q.coeff α*(∏ i,B i i)≤(matrixSubstitution B (MvPolynomial.monomial α (q.coeff α))).coeff α := by
    rw [hscalar,map_mul,matrixSubstitution_C,MvPolynomial.coeff_C_mul]
    exact mul_le_mul_of_nonneg_left (matrixSubstitution_squarefree_unit_diagonal_lower B hB) (hc α)
  by_cases hα : α∈q.support
  · have hexpand : (matrixSubstitution B q).coeff α=
        ∑ g∈q.support,(matrixSubstitution B (MvPolynomial.monomial g (q.coeff g))).coeff α := by
      conv_lhs => rw [q.as_sum]
      rw [map_sum,MvPolynomial.coeff_sum]
    change q.coeff α*(∏ i,B i i)≤_
    rw [hexpand]
    apply hterm.trans
    exact Finset.single_le_sum
      (fun g hg => homogeneous_monomial_matrixSubstitution_nonnegative q hq hc B hB g hg α) hα
  · have hz : q.coeff α=0 := by simpa only [MvPolynomial.mem_support_iff,not_not] using hα
    change q.coeff α*(∏ i,B i i)≤_
    rw [hz,zero_mul]
    exact homogeneous_matrixSubstitution_coeff_nonnegative q hq hc B hB α

end CoefficientStability
