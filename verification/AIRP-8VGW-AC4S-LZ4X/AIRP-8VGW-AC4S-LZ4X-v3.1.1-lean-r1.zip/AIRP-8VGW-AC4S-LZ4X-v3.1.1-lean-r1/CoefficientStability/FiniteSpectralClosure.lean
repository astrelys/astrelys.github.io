import CoefficientStability.SourceClosedConeOperations
import CoefficientStability.NormalizedSourceSubset

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n N : ℕ}

theorem source_closedCone_finite_factors_nonneg {ι : Type*}
    (p : MvPolynomial (Fin n) ℝ) (hN : 0<N) (hp : p.IsHomogeneous N)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (x : Fin n → ℝ) (hx : x∈closure (positiveSpectralCone p N))
    (S : Finset ι) (roots : ι → ℝ)
    (hf : lineRestriction p x=∏ i∈S,(Polynomial.X+Polynomial.C (roots i))) :
    ∀ i∈S,0≤roots i := by
  classical
  intro i hi
  by_contra hneg
  have hri : roots i<0 := lt_of_not_ge hneg
  let a : ℝ := -(roots i)/2
  have hapos : 0<a := by dsimp [a];linarith
  have hone := positive_input_mem_spectral_cone p N hp hs hnorm (fun _ => 1) (by intro j;norm_num)
  have hascale := source_positiveSpectralCone_smul p hp hs hnorm _ hone a hapos
  have haactual : (fun _ : Fin n => a)∈positiveSpectralCone p N := by
    have heq : a • (fun _ : Fin n => (1 : ℝ))=(fun _ : Fin n => a) := by funext j;exact mul_one a
    rwa [heq] at hascale
  have hb := source_spectralCone_add_closed p hN hp hs hnorm (fun _ => a) x haactual hx
  have hpositive := source_cone_forward_eval_pos p ((fun _ => a)+x) hb a hapos.le
  have hzero : (lineRestriction p x).eval (-roots i)=0 := by
    rw [hf,Polynomial.eval_prod]
    apply Finset.prod_eq_zero hi
    simp
  rw [eval_lineRestriction_real] at hzero
  have heq : (fun j => a+((fun _ : Fin n => a)+x) j)=(fun j => -roots i+x j) := by
    funext j
    change a+(a+x j)= -roots i+x j
    dsimp [a]
    ring
  rw [heq,hzero] at hpositive
  exact (lt_irrefl 0) hpositive

theorem source_nonnegative_finite_factors_mem_closure {ι : Type*}
    (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (x : Fin n → ℝ)
    (S : Finset ι) (roots : ι → ℝ) (hcard : S.card=N) (hr : ∀ i∈S,0≤roots i)
    (hf : lineRestriction p x=∏ i∈S,(Polynomial.X+Polynomial.C (roots i))) :
    x∈closure (positiveSpectralCone p N) := by
  classical
  apply nonnegative_spectral_factors_mem_closure p N x (S.val.map roots)
  · rw [Multiset.card_map]
    change S.card=N
    exact hcard
  · intro r hrmem
    obtain ⟨i,hi,rfl⟩ := Multiset.mem_map.mp hrmem
    exact hr i hi
  · simpa only [Multiset.map_map,Function.comp_def,Finset.prod] using hf

theorem actual_finite_root_factor_shift {ι : Type*} (p : MvPolynomial (Fin n) ℝ)
    (x : Fin n → ℝ) (S : Finset ι) (roots : ι → ℝ)
    (hf : lineRestriction p x=∏ i∈S,(Polynomial.X+Polynomial.C (roots i))) (a : ℝ) :
    lineRestriction p (fun j => x j+a)=∏ i∈S,(Polynomial.X+Polynomial.C (roots i+a)) := by
  apply Polynomial.funext
  intro t
  have heq : (lineRestriction p (fun j => x j+a)).eval t=(lineRestriction p x).eval (t+a) := by
    rw [eval_lineRestriction_real,eval_lineRestriction_real]
    apply congrArg (fun z : Fin n → ℝ => MvPolynomial.eval z p)
    funext j
    ring
  rw [heq,hf,Polynomial.eval_prod,Polynomial.eval_prod]
  simp only [Polynomial.eval_add,Polynomial.eval_X,Polynomial.eval_C]
  apply Finset.prod_congr rfl
  intro i hi
  ring

end CoefficientStability
