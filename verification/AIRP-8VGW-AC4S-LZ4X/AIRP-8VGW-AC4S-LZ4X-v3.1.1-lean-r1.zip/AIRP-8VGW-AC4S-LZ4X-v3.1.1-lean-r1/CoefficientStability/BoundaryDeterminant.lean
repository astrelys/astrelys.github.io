import CoefficientStability.DistinguishedRow

noncomputable section
open scoped BigOperators
open Polynomial MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def mixedDiscriminant (A : Fin n → Matrix (Fin n) (Fin n) ℝ) : ℝ :=
  (Matrix.det (∑ i,(MvPolynomial.X i : MvPolynomial (Fin n) ℝ) •
    (A i).map (MvPolynomial.C : ℝ →+* MvPolynomial (Fin n) ℝ))).coeff (squarefreeExponent n)

theorem mixedDiscriminant_diagonal (B : Fin n → Fin n → ℝ) :
    mixedDiscriminant (fun i => Matrix.diagonal (fun r => B r i))=diagonalMixedDeterminant B := by
  unfold mixedDiscriminant diagonalMixedDeterminant diagonalPencilPolynomial
  congr 2
  congr 1
  apply Finset.sum_congr rfl
  intro i hi
  congr 1
  ext r l
  by_cases h : r=l <;> simp [Matrix.map_apply,Matrix.diagonal_apply,h]

def boundaryPencilEntry (t : Fin n → ℝ) (r i : Fin n) : ℝ[X] :=
  Polynomial.C (t i/(n : ℝ))*(1+Polynomial.C ((n : ℝ)*projectedOnes t i*boundaryModelDiagonal n r)*Polynomial.X)

def boundaryMixedPolynomial (t : Fin n → ℝ) : ℝ[X] := diagonalMixedDeterminant (boundaryPencilEntry t)

theorem boundaryPencilEntry_eval (t : Fin n → ℝ) (hn : 0<n) (s : ℝ) (r i : Fin n) :
    Polynomial.eval s (boundaryPencilEntry t r i)=t i/(n : ℝ)+s*(t i*projectedOnes t i)*boundaryModelDiagonal n r := by
  have hn' : (n : ℝ)≠0 := by exact_mod_cast Nat.ne_zero_of_lt hn
  simp only [boundaryPencilEntry,Polynomial.eval_mul,Polynomial.eval_add,Polynomial.eval_C,Polynomial.eval_X,Polynomial.eval_one]
  field_simp <;> ring

theorem boundaryMixedPolynomial_eval (t : Fin n → ℝ) (hn : 0<n) (s : ℝ) :
    Polynomial.eval s (boundaryMixedPolynomial t)=mixedDiscriminant (boundaryPerturbedTuple t s) := by
  have he : boundaryPerturbedTuple t s=(fun i => Matrix.diagonal (fun r =>
      t i/(n : ℝ)+s*(t i*projectedOnes t i)*boundaryModelDiagonal n r)) := by
    funext i
    exact boundaryPerturbedTuple_diagonal t s i
  rw [he,mixedDiscriminant_diagonal,boundaryMixedPolynomial,
    diagonalMixedDeterminant_eq_permutation_sum,diagonalMixedDeterminant_eq_permutation_sum]
  change (Polynomial.evalRingHom s) (∑ sig : Equiv.Perm (Fin n),∏ r,boundaryPencilEntry t r (sig r)) = _
  simp only [map_sum,map_prod]
  apply Finset.sum_congr rfl
  intro sig hsig
  apply Finset.prod_congr rfl
  intro r hr
  exact boundaryPencilEntry_eval t hn s r (sig r)

theorem boundaryPencilEntry_distinguished (t : Fin n → ℝ) (hn : 0<n) (r i : Fin n) :
    1+Polynomial.C ((n : ℝ)*projectedOnes t i*boundaryModelDiagonal n r)*Polynomial.X =
      distinguishedRowEntry (fun j => Polynomial.C ((n : ℝ)*projectedOnes t j)*Polynomial.X)
        (⟨0,hn⟩ : Fin n) r i := by
  classical
  by_cases hr : r=(⟨0,hn⟩ : Fin n)
  · have hv : r.val=0 := by simpa using congrArg Fin.val hr
    simp only [distinguishedRowEntry,if_pos hr,boundaryModelDiagonal,if_pos hv,
      Polynomial.C_mul,Polynomial.C_sub,map_natCast,Polynomial.C_1]
    ring
  · have hv : r.val≠0 := by intro h; apply hr; exact Fin.ext h
    simp only [distinguishedRowEntry,if_neg hr,boundaryModelDiagonal,if_neg hv,
      Polynomial.C_mul,Polynomial.C_neg,Polynomial.C_1]
    ring

def boundaryNormalizingFactor (t : Fin n → ℝ) : ℝ := (n.factorial : ℝ)*∏ i,t i/(n : ℝ)

theorem boundaryMixedPolynomial_distinguished_formula (t : Fin n → ℝ) (hn : 0<n) :
    boundaryMixedPolynomial t=Polynomial.C (boundaryNormalizingFactor t)*
      ((∏ i,(1-Polynomial.C ((n : ℝ)*projectedOnes t i)*Polynomial.X))+
        ∑ i,(Polynomial.C ((n : ℝ)*projectedOnes t i)*Polynomial.X)*
          (∏ j ∈ Finset.univ.erase i,(1-Polynomial.C ((n : ℝ)*projectedOnes t j)*Polynomial.X))) := by
  classical
  rw [boundaryMixedPolynomial,diagonalMixedDeterminant_eq_permutation_sum]
  simp only [boundaryPencilEntry,boundaryPencilEntry_distinguished t hn,Finset.prod_mul_distrib]
  have he (s : Equiv.Perm (Fin n)) : (∏ r,Polynomial.C (t (s r)/(n : ℝ)))=∏ i,Polynomial.C (t i/(n : ℝ)) :=
    Fintype.prod_bijective s s.bijective _ _ (fun _ => rfl)
  simp only [he]
  rw [← Finset.mul_sum,distinguished_row_permanent _ (⟨0,hn⟩ : Fin n) hn]
  have hc : (∏ i,Polynomial.C (t i/(n : ℝ)))*(n.factorial : ℝ[X])=
      Polynomial.C (boundaryNormalizingFactor t) := by
    rw [boundaryNormalizingFactor,map_mul,map_prod,map_natCast]
    exact mul_comm _ _
  rw [← mul_assoc,hc]

end CoefficientStability
