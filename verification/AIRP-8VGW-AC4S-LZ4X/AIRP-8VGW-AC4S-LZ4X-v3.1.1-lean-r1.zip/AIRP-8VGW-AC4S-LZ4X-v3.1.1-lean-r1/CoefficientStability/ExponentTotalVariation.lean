import CoefficientStability.LinearCoefficientStability

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def finiteExponentTotalVariation (p q : MvPolynomial (Fin n) ℝ) : ℝ :=
  (∑ d ∈ p.support ∪ q.support,|p.coeff d-q.coeff d|)/2

theorem finiteExponentTotalVariation_eq_half_coefficientL1 (p q : MvPolynomial (Fin n) ℝ) :
    finiteExponentTotalVariation p q=coefficientL1 (p-q)/2 := by
  classical
  have hs : (p-q).support ⊆ p.support ∪ q.support := by
    intro g hg
    by_contra hnot
    have hp0 : p.coeff g=0 := MvPolynomial.notMem_support_iff.mp (fun hh => hnot (Finset.mem_union_left _ hh))
    have hq0 : q.coeff g=0 := MvPolynomial.notMem_support_iff.mp (fun hh => hnot (Finset.mem_union_right _ hh))
    have he : (p-q).coeff g=0 := by simp [hp0,hq0]
    exact MvPolynomial.mem_support_iff.mp hg he
  rw [coefficientL1_eq_sum_on _ _ hs]
  unfold finiteExponentTotalVariation
  congr 1

theorem source_linear_total_variation_stability_exists (hn : 2 ≤ n) :
    ∃ ε c : ℝ,0 < ε ∧ 0 < c ∧
      ∀ (t : Fin n → ℝ) (p : MvPolynomial (Fin n) ℝ),p.IsHomogeneous n →
        UpperHalfPlaneZeroFree p → MvPolynomial.eval (fun _ => 1) p=1 →
        (∑ i,t i)=n → (∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) →
        (∑ i,|t i-1|) < ε →
        (∀ d,0 ≤ p.coeff d) ∧ (∑ d ∈ p.support,p.coeff d)=1 ∧
        (∀ d,0 ≤ (scalarPower t n).coeff d) ∧ (∑ d ∈ (scalarPower t n).support,(scalarPower t n).coeff d)=1 ∧
        2*c*finiteExponentTotalVariation p (scalarPower t n) ≤ p.coeff (squarefreeExponent n)-sourceVn n*(∏ i,t i) := by
  obtain ⟨ε,c,hε,hc,hgrowth⟩ := source_linear_coefficient_stability_exists hn
  refine ⟨ε,c,hε,hc,?_⟩
  intro t p hp hs hnorm ht hgrad hnear
  have hpc := normalized_homogeneous_stable_coeff_nonneg p n hp hs hnorm
  have ht0 := actual_gradient_nonneg p t hpc hgrad
  have href := multinomial_coefficient_probability t n (by omega) ht ht0
  refine ⟨hpc,normalized_coefficient_mass p hnorm,href.1,href.2.1,?_⟩
  rw [finiteExponentTotalVariation_eq_half_coefficientL1]
  convert! hgrowth t p hp hs hnorm ht hgrad hnear using 1 <;> ring

end CoefficientStability
