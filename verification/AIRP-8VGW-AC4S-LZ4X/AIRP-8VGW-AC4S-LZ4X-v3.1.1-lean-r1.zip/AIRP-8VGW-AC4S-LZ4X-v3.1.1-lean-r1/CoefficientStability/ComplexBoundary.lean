import CoefficientStability.BoundaryCubicCoefficient
import Mathlib.Analysis.Complex.Order

noncomputable section
open scoped BigOperators ComplexOrder
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def complexMixedDiscriminant (A : Fin n → Matrix (Fin n) (Fin n) ℂ) : ℂ :=
  (Matrix.det (∑ i,(MvPolynomial.X i : MvPolynomial (Fin n) ℂ) •
    (A i).map (MvPolynomial.C : ℂ →+* MvPolynomial (Fin n) ℂ))).coeff (squarefreeExponent n)

def hermitianMixedObjective (A : Fin n → Matrix (Fin n) (Fin n) ℂ) : ℝ := (complexMixedDiscriminant A).re

def complexBoundaryTuple (t : Fin n → ℝ) (s : ℝ) (i : Fin n) : Matrix (Fin n) (Fin n) ℂ :=
  (boundaryPerturbedTuple t s i).map Complex.ofRealHom

def complexReferenceTuple (t : Fin n → ℝ) (i : Fin n) : Matrix (Fin n) (Fin n) ℂ :=
  (scalarReferenceTuple t i).map Complex.ofRealHom

theorem complexBoundaryTuple_zero (t : Fin n → ℝ) : complexBoundaryTuple t 0=complexReferenceTuple t := by
  funext i
  simp [complexBoundaryTuple,complexReferenceTuple,boundaryPerturbedTuple]

theorem complexBoundaryTuple_diagonal (t : Fin n → ℝ) (s : ℝ) (i : Fin n) :
    complexBoundaryTuple t s i=Matrix.diagonal (fun r =>
      ((t i/(n : ℝ)+s*(t i*projectedOnes t i)*boundaryModelDiagonal n r : ℝ) : ℂ)) := by
  rw [complexBoundaryTuple,boundaryPerturbedTuple_diagonal]
  ext r l
  by_cases h : r=l <;> simp [Matrix.map_apply,Matrix.diagonal_apply,h]

theorem complexMixedDiscriminant_diagonal (B : Fin n → Fin n → ℂ) :
    complexMixedDiscriminant (fun i => Matrix.diagonal (fun r => B r i))=diagonalMixedDeterminant B := by
  have he (i : Fin n) :
      (Matrix.diagonal (fun r => B r i)).map (MvPolynomial.C : ℂ →+* MvPolynomial (Fin n) ℂ) =
        Matrix.diagonal (fun r => MvPolynomial.C (B r i)) := by
    ext r l
    by_cases h : r=l <;> simp [Matrix.map_apply,Matrix.diagonal_apply,h]
  simp only [complexMixedDiscriminant,diagonalMixedDeterminant,diagonalPencilPolynomial,he]

theorem diagonalMixedDeterminant_map {R S : Type*} [CommRing R] [CommRing S]
    (f : R →+* S) (B : Fin n → Fin n → R) :
    diagonalMixedDeterminant (fun r i => f (B r i))=f (diagonalMixedDeterminant B) := by
  rw [diagonalMixedDeterminant_eq_permutation_sum,diagonalMixedDeterminant_eq_permutation_sum]
  simp only [map_sum,map_prod]

theorem complexBoundaryTuple_objective (t : Fin n → ℝ) (hn : 0<n) (s : ℝ) :
    complexMixedDiscriminant (complexBoundaryTuple t s)=Complex.ofReal ((boundaryMixedPolynomial t).eval s) := by
  have hc : complexBoundaryTuple t s=(fun i => Matrix.diagonal (fun r =>
      ((t i/(n : ℝ)+s*(t i*projectedOnes t i)*boundaryModelDiagonal n r : ℝ) : ℂ))) := by
    funext i
    exact complexBoundaryTuple_diagonal t s i
  have hr : boundaryPerturbedTuple t s=(fun i => Matrix.diagonal (fun r =>
      t i/(n : ℝ)+s*(t i*projectedOnes t i)*boundaryModelDiagonal n r)) := by
    funext i
    exact boundaryPerturbedTuple_diagonal t s i
  rw [hc,complexMixedDiscriminant_diagonal,boundaryMixedPolynomial_eval t hn s,hr,mixedDiscriminant_diagonal]
  exact diagonalMixedDeterminant_map Complex.ofRealHom _

theorem complexBoundaryTuple_isHermitian (t : Fin n → ℝ) (s : ℝ) (i : Fin n) :
    (complexBoundaryTuple t s i).IsHermitian := by
  exact (boundaryPerturbedTuple_isHermitian t s i).map Complex.ofRealHom (by intro x;simp)

theorem complexBoundaryTuple_posDef (t : Fin n → ℝ) (s : ℝ) (i : Fin n)
    (h : (boundaryPerturbedTuple t s i).PosDef) : (complexBoundaryTuple t s i).PosDef := by
  rw [boundaryPerturbedTuple_diagonal,Matrix.posDef_diagonal_iff] at h
  rw [complexBoundaryTuple_diagonal,Matrix.posDef_diagonal_iff]
  intro r
  exact Complex.zero_lt_real.mpr (h r)

theorem complexBoundaryTuple_trace (t : Fin n → ℝ) (hn : 0<n) (s : ℝ) (i : Fin n) :
    Matrix.trace (complexBoundaryTuple t s i)=(t i : ℂ) := by
  rw [complexBoundaryTuple,← AddMonoidHom.map_trace,boundaryPerturbedTuple_trace t hn]
  rfl

theorem complexBoundaryTuple_sum (t : Fin n → ℝ) (hn : 0<n) (ht : ∑ i,t i=n) (s : ℝ) :
    (∑ i,complexBoundaryTuple t s i)=1 := by
  ext r l
  have h := congrArg (fun A : Matrix (Fin n) (Fin n) ℝ => A r l) (boundaryPerturbedTuple_sum t hn ht s)
  simp only [Matrix.sum_apply] at h
  simp only [Matrix.sum_apply,complexBoundaryTuple,Matrix.map_apply]
  change (∑ i,Complex.ofRealHom (boundaryPerturbedTuple t s i r l))=_
  rw [← map_sum,h]
  by_cases hrl : r=l <;> simp [Matrix.one_apply,hrl]

theorem paper_complex_boundary_actual_descent (t : Fin n → ℝ) (hn : 3≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : scalarHessianLambda t=0) :
    ∃ e : ℝ,0<e ∧ ∀ s : ℝ,0<s → s<e →
      (∀ i,(complexBoundaryTuple t s i).IsHermitian ∧ (complexBoundaryTuple t s i).PosDef) ∧
      (∑ i,complexBoundaryTuple t s i)=1 ∧
      (∀ i,Matrix.trace (complexBoundaryTuple t s i)=(t i : ℂ)) ∧
      hermitianMixedObjective (complexBoundaryTuple t s)<hermitianMixedObjective (complexReferenceTuple t) := by
  obtain ⟨e,he,hdesc⟩ := paper_boundary_actual_descent t hn ht htpos hl
  refine ⟨e,he,?_⟩
  intro s hs hse
  have h := hdesc s hs hse
  refine ⟨?_,complexBoundaryTuple_sum t (by omega) ht s,?_,?_⟩
  · intro i
    exact ⟨complexBoundaryTuple_isHermitian t s i,complexBoundaryTuple_posDef t s i (h.1 i)⟩
  · intro i
    exact complexBoundaryTuple_trace t (by omega) s i
  · have hd := h.2.2.2
    rw [← boundaryMixedPolynomial_eval t (by omega) s] at hd
    have hz : mixedDiscriminant (scalarReferenceTuple t)=(boundaryMixedPolynomial t).eval 0 := by
      rw [boundaryMixedPolynomial_eval t (by omega) 0]
      congr 1
      funext i
      simp [boundaryPerturbedTuple]
    rw [hz] at hd
    simpa only [hermitianMixedObjective,← complexBoundaryTuple_zero t,complexBoundaryTuple_objective t (by omega),Complex.ofReal_re] using hd

end CoefficientStability
