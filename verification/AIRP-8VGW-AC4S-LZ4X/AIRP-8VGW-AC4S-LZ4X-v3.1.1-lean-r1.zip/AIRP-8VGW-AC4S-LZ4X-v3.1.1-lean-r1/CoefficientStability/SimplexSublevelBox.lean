import CoefficientStability.PurePolynomialSublevel
import Mathlib.Topology.Algebra.MvPolynomial
import Mathlib.Topology.Instances.RealVectorSpace
import Mathlib.Tactic.FunProp

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem simplex_coordinate_upper (x : Fin n → ℝ) (hx : ∀ i,0≤x i)
    (hs : ∑ i,x i=(n : ℝ)) (i : Fin n) : x i≤(n : ℝ) := by
  calc x i≤∑ j,x j := Finset.single_le_sum (fun j hj => hx j) (Finset.mem_univ i)
       _=(n : ℝ) := hs

theorem simplex_product_coordinate_upper (x : Fin n → ℝ) (hx : ∀ i,0≤x i)
    (hs : ∑ i,x i=(n : ℝ)) (i : Fin n) :
    (∏ j,x j)≤x i*(n : ℝ)^(n-1) := by
  classical
  have hp : (∏ j∈Finset.univ.erase i,x j)≤(n : ℝ)^(n-1) := by
    calc (∏ j∈Finset.univ.erase i,x j)≤∏ j∈Finset.univ.erase i,(n : ℝ) :=
          Finset.prod_le_prod₀ (fun j hj => hx j) (fun j hj => simplex_coordinate_upper x hx hs j)
         _=(n : ℝ)^(n-1) := by simp
  calc (∏ j,x j)=x i*(∏ j∈Finset.univ.erase i,x j) :=
        (Finset.mul_prod_erase Finset.univ x (Finset.mem_univ i)).symm
       _≤x i*(n : ℝ)^(n-1) := mul_le_mul_of_nonneg_left hp (hx i)

theorem simplex_capacity_sublevel_coordinate_lower (hn : 0<n) (p : MvPolynomial (Fin n) ℝ)
    (hc : ∀ g,0≤p.coeff g) (c M : ℝ) (hcpos : 0<c) (hM : 0<M)
    (hpure : ∀ i,c≤p.coeff (Finsupp.single i n))
    (x : Fin n → ℝ) (hx : ∀ i,0<x i) (hxs : ∑ i,x i=(n : ℝ))
    (hsub : MvPolynomial.eval x p/(∏ i,x i)≤M) :
    ∀ i,(c/M)/(n : ℝ)^(n-1)≤x i := by
  intro i
  have hlo := simplex_capacity_sublevel_product_lower hn p hc c M hcpos hM hpure x hx hxs hsub
  have hhi := simplex_product_coordinate_upper x (fun j => (hx j).le) hxs i
  have hnreal : (0 : ℝ)<n := by exact_mod_cast hn
  exact (div_le_iff₀ (pow_pos hnreal _)).mpr (hlo.trans hhi)

end CoefficientStability
