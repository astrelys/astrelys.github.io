import CoefficientStability.FiniteSpectralClosure
import CoefficientStability.SourceSubsetFactorization

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n N : ℕ}

theorem actual_source_cube_spectral_bounds (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (x : Fin n → ℝ)
    (hx0 : ∀ i,0≤x i) (hx1 : ∀ i,x i≤1) (roots : Fin N → ℝ)
    (hf : lineRestriction p x=∏ i : Fin N,(Polynomial.X+Polynomial.C (roots i))) :
    ∀ i,0≤roots i ∧ roots i≤1 := by
  have hxclosed := nonnegative_input_mem_spectral_closure p N hp hs hnorm x hx0
  have hlo := source_closedCone_finite_factors_nonneg p hN hp hs hnorm x hxclosed Finset.univ roots hf
  have hyclosed := nonnegative_input_mem_spectral_closure p N hp hs hnorm (fun i => 1-x i)
    (fun i => sub_nonneg.mpr (hx1 i))
  have hneg := actual_source_root_tuple_scaling p N hp x roots hf (-1) (by norm_num)
  have hshift := actual_source_root_tuple_shift p N ((-1 : ℝ) • x) (fun i => (-1)*roots i) hneg 1
  have hvec : (fun i => ((-1 : ℝ) • x) i+1)=(fun i => 1-x i) := by
    funext i
    change (-1)*x i+1=1-x i
    ring
  rw [hvec] at hshift
  have hfactor : lineRestriction p (fun i => 1-x i)=∏ j : Fin N,(Polynomial.X+Polynomial.C (1-roots j)) := by
    rw [hshift]
    apply Finset.prod_congr rfl
    intro j hj
    congr 2
    ring
  have hhi := source_closedCone_finite_factors_nonneg p hN hp hs hnorm _ hyclosed Finset.univ
    (fun i => 1-roots i) hfactor
  intro i
  exact ⟨hlo i (Finset.mem_univ i),by linarith [hhi i (Finset.mem_univ i)]⟩

theorem actual_source_root_tuple_trace (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (x : Fin n → ℝ) (roots : Fin N → ℝ)
    (hf : lineRestriction p x=∏ i : Fin N,(Polynomial.X+Polynomial.C (roots i))) :
    (∑ j,roots j)=∑ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)*x i := by
  have hfactor : lineRestriction p x=realFactorPolynomial ((Finset.univ : Finset (Fin N)).val.map roots) := by
    simpa only [realFactorPolynomial,Multiset.map_map,Function.comp_def,Finset.prod] using hf
  have h := factorization_root_sum p x N hN hp hnorm _ hfactor
  simpa only [Finset.sum] using h

end CoefficientStability
