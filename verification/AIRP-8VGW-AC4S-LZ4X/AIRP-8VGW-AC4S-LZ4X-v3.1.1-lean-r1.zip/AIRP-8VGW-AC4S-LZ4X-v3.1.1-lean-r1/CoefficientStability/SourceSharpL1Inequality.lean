import CoefficientStability.SourceL1GlobalLowerBound

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 1200000

theorem source_l1_canonical_minimum_lower_bound (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hbox : ∀ i,1/2 ≤ t i ∧ t i ≤ 3/2) (hr : (∑ i,|t i-1|) ≤ sourceCubicEpsilon0)
    (B : Matrix (Fin 3) (Fin 3) ℝ) (hB : B ∈ sourceTransportationPolytope t)
    (hmin : IsMinOn Matrix.permanent (sourceTransportationPolytope t) B)
    (hcase : sourceTernaryRealZeroPattern B) : sourceTernaryBaseline t ≤ Matrix.permanent B := by
  have hlocal := hmin.isLocalMinOn
  unfold sourceTernaryRealZeroPattern at hcase
  rcases hcase with h0 | h1 | h2 | h3 | h4 | h5
  · exact (source_ternary_interior_minimum_gap t ht hbox B hB h0 hlocal).1
  · obtain ⟨h00,hpos⟩ := h1
    have he := source_actual_one_zero_chart t B hB h00
    have hpos' : ∀ q ∈ sourceOneZeroEntrySet,0 < sourceTernaryOneZero t (B 0 1) (B 1 0) (B 1 1) q.1 q.2 := by rw [← he];exact hpos
    have hlocal' : IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) (sourceTernaryOneZero t (B 0 1) (B 1 0) (B 1 1)) := by rw [← he];exact hlocal
    have h := (source_one_zero_minimum_gap t ht (B 0 1) (B 1 0) (B 1 1) hpos' hlocal' (hbox 0).2).1
    rw [← he] at h
    exact h
  · obtain ⟨h00,h11,hpos⟩ := h2
    have he := source_actual_separated_zero_chart t B hB h00 h11
    have hpos' : ∀ q ∈ sourceSeparatedEntrySet,0 < sourceTernarySeparatedZeros t (B 0 1) (B 1 0) q.1 q.2 := by rw [← he];exact hpos
    have hmin' : IsMinOn Matrix.permanent (sourceTransportationPolytope t) (sourceTernarySeparatedZeros t (B 0 1) (B 1 0)) := by rw [← he];exact hmin
    have h := source_l1_separated_minimum_gap t ht (B 0 1) (B 1 0) hpos' hmin' hr
    rw [← he] at h
    exact h
  · have he := source_actual_matching_chart t B hB h3
    have h := source_ternary_matching_nonnegative_gap t ht (fun i => (hbox i).2) (B 0 1)
    rw [← he] at h
    exact h
  · obtain ⟨h00,h01⟩ := h4
    have he := source_actual_double_row_chart t B hB h00 h01
    have h := source_ternary_double_row_strict_bound t ht hbox (B 1 0+B 1 1) (B 1 0) (by rw [← he];exact hB.1)
    rw [← he] at h
    linarith
  · obtain ⟨h00,h10⟩ := h5
    let r : Equiv.Perm (Fin 3) := Equiv.swap 0 2
    let E := sourcePermutedMatrix B r 1
    let s := sourcePermutedTraces t r
    have hE : E ∈ sourceTransportationPolytope s := source_permuted_feasible t B hB r 1
    have hs : (∑ i,s i)=3 := (source_permuted_trace_sum t r).trans ht
    have hsb : ∀ i,1/2 ≤ s i ∧ s i ≤ 3/2 := fun i => hbox (r i)
    have he10 : E 1 0=0 := by simpa [E,r,sourcePermutedMatrix,Matrix.submatrix_apply,Equiv.swap_apply_def] using h10
    have he20 : E 2 0=0 := by simpa [E,r,sourcePermutedMatrix,Matrix.submatrix_apply,Equiv.swap_apply_def] using h00
    have he := source_actual_double_column_chart s E hE he10 he20
    have h := source_ternary_double_column_strict_bound s hs hsb (E 0 1) (E 1 1) (by rw [← he];exact hE.1)
    rw [← he] at h
    have h' : 1/32 ≤ Matrix.permanent B-sourceTernaryBaseline t := by
      simpa only [E,s,source_permuted_permanent,source_permuted_ternary_baseline] using h
    linarith

theorem source_sharp_l1_permanent_inequality (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,|t i-1|) ≤ sourceCubicEpsilon0) (B : Matrix (Fin 3) (Fin 3) ℝ)
    (hB : B ∈ sourceTransportationPolytope t) : sourceTernaryBaseline t ≤ Matrix.permanent B := by
  have hb := source_ternary_l1_strict_trace_box t ht hr
  have hbox : ∀ i,1/2 ≤ t i ∧ t i ≤ 3/2 := fun i => ⟨(hb i).1.le,(hb i).2.le⟩
  have htpos : ∀ i,0 < t i := fun i => lt_of_lt_of_le (by norm_num) (hbox i).1
  obtain ⟨M,hM,hmin⟩ := source_ternary_global_minimum_exists t ht htpos
  obtain ⟨r,c,hcase⟩ := source_ternary_real_zero_pattern_exhaustion M hM.1
  have hD := source_permuted_feasible t M hM r c
  have hminD := source_permuted_global_minimum t M hmin r c
  have hsum : (∑ i,sourcePermutedTraces t r i)=3 := (source_permuted_trace_sum t r).trans ht
  have hR : (∑ i,|sourcePermutedTraces t r i-1|) ≤ sourceCubicEpsilon0 := by rwa [source_permuted_l1_distance]
  have hboxD : ∀ i,1/2 ≤ sourcePermutedTraces t r i ∧ sourcePermutedTraces t r i ≤ 3/2 := fun i => hbox (r i)
  have hbase := source_l1_canonical_minimum_lower_bound (sourcePermutedTraces t r) hsum hboxD hR
    (sourcePermutedMatrix M r c) hD hminD hcase
  rw [source_permuted_ternary_baseline,source_permuted_permanent] at hbase
  exact hbase.trans (hmin hB)

end CoefficientStability
