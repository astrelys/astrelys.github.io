import CoefficientStability.TiltRelativeExpressionBounds
import CoefficientStability.CoefficientComparison

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def actualTiltDiagonalDerivative (p : MvPolynomial (Fin n) ℝ) (u v : Fin n → ℝ) (i : Fin n) : ℝ :=
  relativeDiagonalExpression (deficitMatrix (tiltedPolynomial p u) (tiltedMoment p u) n)
    (tiltedMoment p u) v (actualCentralCubicTensor (tiltedPolynomial p u) (tiltedMoment p u) n) i

def actualTiltDeficit (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ) : ℝ :=
  referenceDeficit (tiltedPolynomial p u) (tiltedMoment p u) n

theorem actual_tilt_relative_ingredients (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ)
    (hn : 3≤n) (hp : p.IsHomogeneous n) (hcoeff : ∀ g,0≤p.coeff g)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p) :
    let Q := deficitMatrix (tiltedPolynomial p u) (tiltedMoment p u) n
    Q.PosSemidef ∧ Matrix.trace Q≤((n : ℝ)-1)/2 ∧
    (∀ i,0≤tiltedMoment p u i) ∧ (∑ i,tiltedMoment p u i)=n ∧
    ∀ w,|actualCentralCubicTensor (tiltedPolynomial p u) (tiltedMoment p u) n w|≤
      18*Real.sqrt 2*(∏ j,deficitSeminorm Q (w j)) := by
  dsimp only
  have hZ := ne_of_gt (tiltPartition_pos p u hcoeff hnorm)
  obtain ⟨hph,hpc,hpn,hps⟩ := tiltedPolynomial_source_hypotheses p u hp hcoeff hnorm hstable
  have hgrad := fun i => (tiltedMoment_actual_gradient p u hZ i).symm
  have hB := actual_tilt_deficit_source_bounds p u (by omega) hp hcoeff hnorm hstable
  refine ⟨hB.1,?_,actual_gradient_nonneg _ _ hpc hgrad,tiltedMoment_total p u hp hZ,?_⟩
  · simpa only [trace_deficitMatrix] using hB.2.2.2
  · intro w
    exact actualCentralCubicTensor_bound _ _ n hn hph hpn hps hgrad w

theorem actual_tilt_diagonal_hasDerivAt (p : MvPolynomial (Fin n) ℝ)
    (u v : Fin n → ℝ) (s : ℝ) (hn : 0<n) (hp : p.IsHomogeneous n)
    (hcoeff : ∀ g,0≤p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (i : Fin n) :
    HasDerivAt (fun z : ℝ => deficitMatrix (tiltedPolynomial p (u+z • v))
      (tiltedMoment p (u+z • v)) n i i) (actualTiltDiagonalDerivative p (u+s • v) v i) s := by
  exact paper_tilt_deficit_diagonal_path_derivative p u v s hn hp hcoeff hnorm i

theorem paper_actual_tilt_diagonal_derivative_bound (p : MvPolynomial (Fin n) ℝ)
    (u v : Fin n → ℝ) (hn : 3≤n) (hp : p.IsHomogeneous n) (hcoeff : ∀ g,0≤p.coeff g)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p) (i : Fin n) :
    |actualTiltDiagonalDerivative p u v i|≤12*(n : ℝ)*‖v‖*actualTiltDeficit p u := by
  obtain ⟨hQ,htrace,ht0,ht,hT⟩ := actual_tilt_relative_ingredients p u hn hp hcoeff hnorm hstable
  have hv (j : Fin n) : |v j|≤‖v‖ := by simpa only [Real.norm_eq_abs] using norm_le_pi_norm v j
  have h := relative_diagonal_expression_bound _ hQ htrace _ v hn ht0 ht _ hT ‖v‖ (norm_nonneg _) hv i
  simpa only [actualTiltDiagonalDerivative,actualTiltDeficit,trace_deficitMatrix] using h

theorem actual_tilt_deficit_hasDerivAt (p : MvPolynomial (Fin n) ℝ)
    (u v : Fin n → ℝ) (s : ℝ) (hn : 0<n) (hp : p.IsHomogeneous n)
    (hcoeff : ∀ g,0≤p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1) :
    HasDerivAt (fun z : ℝ => actualTiltDeficit p (u+z • v))
      (∑ i,actualTiltDiagonalDerivative p (u+s • v) v i) s := by
  have h := HasDerivAt.fun_sum (u := (Finset.univ : Finset (Fin n)))
    (fun i hi => actual_tilt_diagonal_hasDerivAt p u v s hn hp hcoeff hnorm i)
  have he : (fun z : ℝ => actualTiltDeficit p (u+z • v))=
      (fun z : ℝ => ∑ i,deficitMatrix (tiltedPolynomial p (u+z • v)) (tiltedMoment p (u+z • v)) n i i) := by
    funext z
    exact (trace_deficitMatrix _ _ n).symm
  rw [he]
  exact h

theorem paper_actual_tilt_deficit_derivative_bound (p : MvPolynomial (Fin n) ℝ)
    (u v : Fin n → ℝ) (hn : 3≤n) (hp : p.IsHomogeneous n) (hcoeff : ∀ g,0≤p.coeff g)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p) :
    |∑ i,actualTiltDiagonalDerivative p u v i|≤12*(n : ℝ)*‖v‖*actualTiltDeficit p u := by
  obtain ⟨hQ,htrace,ht0,ht,hT⟩ := actual_tilt_relative_ingredients p u hn hp hcoeff hnorm hstable
  have hv (j : Fin n) : |v j|≤‖v‖ := by simpa only [Real.norm_eq_abs] using norm_le_pi_norm v j
  have h := relative_trace_expression_bound _ hQ htrace _ v hn ht0 ht _ hT ‖v‖ (norm_nonneg _) hv
  simpa only [actualTiltDiagonalDerivative,actualTiltDeficit,trace_deficitMatrix] using h

end CoefficientStability
