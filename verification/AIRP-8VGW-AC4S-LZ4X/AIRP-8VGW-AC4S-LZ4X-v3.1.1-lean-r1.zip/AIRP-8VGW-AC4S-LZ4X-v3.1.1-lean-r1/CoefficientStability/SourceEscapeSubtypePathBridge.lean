import CoefficientStability.SourceEscapeBalancedNonattainment

noncomputable section
open scoped BigOperators Topology unitInterval
namespace CoefficientStability
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

abbrev SourceOriginalEscapeCurve (a b : ℝ) := C(unitInterval,sourceTransportationPolytope (sourceEscapeTraces a b))

def sourceEscapeForget (a b : ℝ) (γ : SourceOriginalEscapeCurve a b) : SourceEscapeCurve :=
  ⟨fun u => (γ u : Matrix (Fin 3) (Fin 3) ℝ),continuous_subtype_val.comp γ.continuous⟩

def sourceEscapeRestrict (a b : ℝ) (γ : SourceEscapeCurve)
    (hγ : ∀ u,γ u ∈ sourceTransportationPolytope (sourceEscapeTraces a b)) : SourceOriginalEscapeCurve a b :=
  ⟨fun u => ⟨γ u,hγ u⟩,γ.continuous.subtype_mk hγ⟩

def sourceOriginalEscapeAdmissible (a b : ℝ) (γ : SourceOriginalEscapeCurve a b) : Prop :=
  (γ 0 : Matrix (Fin 3) (Fin 3) ℝ)=sourceEscapeCenter a b ∧
    sourceEscapeQ a b < sourceEscapeQuadratic a b ((γ 1 : Matrix (Fin 3) (Fin 3) ℝ)-sourceEscapeCenter a b)

def sourceOriginalEscapeCurveHeight (a b : ℝ) (γ : SourceOriginalEscapeCurve a b) : ℝ :=
  sourceEscapeCurveHeight a b (sourceEscapeForget a b γ)

def sourceOriginalEscapeBarrier (a b : ℝ) : ℝ :=
  sInf (sourceOriginalEscapeCurveHeight a b '' {γ : SourceOriginalEscapeCurve a b | sourceOriginalEscapeAdmissible a b γ})

theorem source_escape_forget_restrict (a b : ℝ) (γ : SourceEscapeCurve)
    (hγ : ∀ u,γ u ∈ sourceTransportationPolytope (sourceEscapeTraces a b)) :
    sourceEscapeForget a b (sourceEscapeRestrict a b γ hγ)=γ := by
  apply ContinuousMap.ext
  intro u
  rfl

theorem source_original_escape_admissible_iff (a b : ℝ) (γ : SourceOriginalEscapeCurve a b) :
    sourceOriginalEscapeAdmissible a b γ ↔ sourceEscapeAdmissible a b (sourceEscapeForget a b γ) := by
  constructor
  · intro h
    exact ⟨h.1,fun u => (γ u).property,h.2⟩
  · intro h
    exact ⟨h.1,h.2.2⟩

theorem source_original_escape_restricted_admissible (a b : ℝ) (γ : SourceEscapeCurve)
    (hγ : sourceEscapeAdmissible a b γ) :
    sourceOriginalEscapeAdmissible a b (sourceEscapeRestrict a b γ hγ.2.1) := ⟨hγ.1,hγ.2.2⟩

theorem source_original_escape_restricted_height (a b : ℝ) (γ : SourceEscapeCurve)
    (hγ : ∀ u,γ u ∈ sourceTransportationPolytope (sourceEscapeTraces a b)) :
    sourceOriginalEscapeCurveHeight a b (sourceEscapeRestrict a b γ hγ)=sourceEscapeCurveHeight a b γ := by
  unfold sourceOriginalEscapeCurveHeight
  rw [source_escape_forget_restrict]

theorem source_original_escape_barrier_eq_ambient (a b : ℝ) :
    sourceOriginalEscapeBarrier a b=sourceEscapeBarrier a b := by
  unfold sourceOriginalEscapeBarrier sourceEscapeBarrier
  apply congrArg sInf
  ext h
  constructor
  · rintro ⟨γ,hγ,rfl⟩
    exact ⟨sourceEscapeForget a b γ,(source_original_escape_admissible_iff a b γ).mp hγ,rfl⟩
  · rintro ⟨γ,hγ,rfl⟩
    exact ⟨sourceEscapeRestrict a b γ hγ.2.1,source_original_escape_restricted_admissible a b γ hγ,
      source_original_escape_restricted_height a b γ hγ.2.1⟩

theorem source_original_escape_height_attained (a b : ℝ) (γ : SourceOriginalEscapeCurve a b) :
    ∃ u,Matrix.permanent (γ u : Matrix (Fin 3) (Fin 3) ℝ)-Matrix.permanent (sourceEscapeCenter a b)=
      sourceOriginalEscapeCurveHeight a b γ := source_escape_curve_height_attained a b (sourceEscapeForget a b γ)

end CoefficientStability
