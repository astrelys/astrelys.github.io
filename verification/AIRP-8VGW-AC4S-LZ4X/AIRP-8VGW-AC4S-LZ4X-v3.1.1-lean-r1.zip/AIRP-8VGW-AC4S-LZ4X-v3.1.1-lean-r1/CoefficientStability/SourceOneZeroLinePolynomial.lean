import CoefficientStability.SourceTernaryFaceBounds

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1200000

def sourceOneZeroLinePolynomial (t : Fin 3 → ℝ) (a b c u v w : ℝ) : Polynomial ℝ :=
  let A := Polynomial.C a+Polynomial.C u*Polynomial.X
  let B := Polynomial.C b+Polynomial.C v*Polynomial.X
  let C := Polynomial.C c+Polynomial.C w*Polynomial.X
  Polynomial.C (t 1)*A+Polynomial.C (t 0)*B+Polynomial.C (2*t 2-7)*A*B+
    2*A^2*B+2*A*B^2+C*(2*A-Polynomial.C (t 0))*(2*B-1)

def sourceOneZeroLineConstant (t : Fin 3 → ℝ) (a b c : ℝ) :=
  a*t 1+t 0*b+(2*t 2-7)*a*b+2*a^2*b+2*a*b^2+c*(2*a-t 0)*(2*b-1)

def sourceOneZeroLineLinear (t : Fin 3 → ℝ) (a b c u v w : ℝ) :=
  u*(sourceTernaryFacePartialA t a b+2*c*(2*b-1))+
  v*(sourceTernaryFacePartialB t a b+2*c*(2*a-t 0))+w*(2*a-t 0)*(2*b-1)

def sourceOneZeroLineQuadratic (t : Fin 3 → ℝ) (a b c u v w : ℝ) :=
  2*b*u^2+2*a*v^2+(2*t 2-7+4*a+4*b+4*c)*u*v+
    2*w*(u*(2*b-1)+v*(2*a-t 0))

def sourceOneZeroLineCubic (u v w : ℝ) := 2*u*v*(u+v+2*w)

theorem source_one_zero_line_expansion (t : Fin 3 → ℝ) (a b c u v w : ℝ) :
    sourceOneZeroLinePolynomial t a b c u v w=
      Polynomial.C (sourceOneZeroLineConstant t a b c)+
      Polynomial.C (sourceOneZeroLineLinear t a b c u v w)*Polynomial.X+
      Polynomial.C (sourceOneZeroLineQuadratic t a b c u v w)*Polynomial.X^2+
      Polynomial.C (sourceOneZeroLineCubic u v w)*Polynomial.X^3 := by
  unfold sourceOneZeroLinePolynomial sourceOneZeroLineConstant sourceOneZeroLineLinear
    sourceOneZeroLineQuadratic sourceOneZeroLineCubic sourceTernaryFacePartialA sourceTernaryFacePartialB
  simp only [map_add,map_sub,map_mul,map_pow,map_ofNat,map_one,map_zero]
  ring

theorem source_one_zero_line_eval (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b c u v w s : ℝ) :
    (sourceOneZeroLinePolynomial t a b c u v w).eval s=
      Matrix.permanent (sourceTernaryOneZero t (a+s*u) (b+s*v) (c+s*w)) := by
  rw [source_ternary_one_zero_expansion t ht]
  simp only [sourceOneZeroLinePolynomial,Polynomial.eval_add,Polynomial.eval_sub,Polynomial.eval_mul,
    Polynomial.eval_C,Polynomial.eval_pow,Polynomial.eval_X,Polynomial.eval_ofNat,Polynomial.eval_one]
  ring

theorem source_one_zero_line_coeff_one (t : Fin 3 → ℝ) (a b c u v w : ℝ) :
    (sourceOneZeroLinePolynomial t a b c u v w).coeff 1=sourceOneZeroLineLinear t a b c u v w := by
  rw [source_one_zero_line_expansion]
  simp

theorem source_one_zero_line_coeff_two (t : Fin 3 → ℝ) (a b c u v w : ℝ) :
    (sourceOneZeroLinePolynomial t a b c u v w).coeff 2=sourceOneZeroLineQuadratic t a b c u v w := by
  rw [source_one_zero_line_expansion]
  simp

theorem source_one_zero_line_derivative (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b c u v w : ℝ) :
    HasDerivAt (fun s : ℝ => Matrix.permanent (sourceTernaryOneZero t (a+s*u) (b+s*v) (c+s*w)))
      (sourceOneZeroLineLinear t a b c u v w) 0 := by
  have he : (fun s : ℝ => Matrix.permanent (sourceTernaryOneZero t (a+s*u) (b+s*v) (c+s*w)))=
      (fun s => (sourceOneZeroLinePolynomial t a b c u v w).eval s) := by
    funext s
    exact (source_one_zero_line_eval t ht a b c u v w s).symm
  rw [he]
  have h := (sourceOneZeroLinePolynomial t a b c u v w).hasDerivAt 0
  have hv : (sourceOneZeroLinePolynomial t a b c u v w).derivative.eval 0=sourceOneZeroLineLinear t a b c u v w := by
    rw [← Polynomial.coeff_zero_eq_eval_zero,Polynomial.coeff_derivative]
    norm_num [source_one_zero_line_coeff_one]
  rw [hv] at h
  exact h

end CoefficientStability
