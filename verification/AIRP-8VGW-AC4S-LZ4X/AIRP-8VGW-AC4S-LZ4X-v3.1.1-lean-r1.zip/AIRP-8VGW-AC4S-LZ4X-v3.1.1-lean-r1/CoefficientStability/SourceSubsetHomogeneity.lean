import CoefficientStability.SourceRootScaling
import CoefficientStability.HomogeneityFromScaling

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n N : ℕ}

theorem sourceSubsetRootSumPolynomial_real_scale (p : MvPolynomial (Fin n) ℝ) (N k : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (x : Fin n → ℝ) (c : ℝ) (hc : c≠0) :
    MvPolynomial.eval (c • x) (sourceSubsetRootSumPolynomial p N k)=
      c^(N.choose k)*MvPolynomial.eval x (sourceSubsetRootSumPolynomial p N k) := by
  obtain ⟨roots,hfactor⟩ := actual_source_real_root_tuple p N hp hs hnorm x
  have hscaled := actual_source_root_tuple_scaling p N hp x roots hfactor c hc
  rw [sourceSubsetRootSumPolynomial_real_eval_of_factors p N k (c • x) (fun i => c*roots i) hscaled,
    sourceSubsetRootSumPolynomial_real_eval_of_factors p N k x roots hfactor]
  simp_rw [← Finset.mul_sum]
  rw [Finset.prod_mul_distrib]
  simp

theorem sourceSubsetRootSumPolynomial_homogeneous (p : MvPolynomial (Fin n) ℝ) (N k : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) :
    (sourceSubsetRootSumPolynomial p N k).IsHomogeneous (N.choose k) := by
  apply homogeneous_of_actual_double_scaling
  intro x
  convert! sourceSubsetRootSumPolynomial_real_scale p N k hp hs hnorm x 2 (by norm_num) using 1

theorem source_line_at_one_full_factors (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hnorm : MvPolynomial.eval (fun _ => 1) p=1) :
    lineRestriction p (fun _ => 1)=∏ i : Fin N,(Polynomial.X+Polynomial.C (1 : ℝ)) := by
  apply Polynomial.funext
  intro t
  rw [eval_lineRestriction_real,Polynomial.eval_prod]
  have h := homogeneous_eval_real_scale p N hp (t+1) (fun _ => 1)
  simpa only [mul_one,hnorm,Polynomial.eval_add,Polynomial.eval_X,Polynomial.eval_C,
    Finset.prod_const,Finset.card_univ,Fintype.card_fin] using h

theorem sourceSubsetRootSumPolynomial_at_one (p : MvPolynomial (Fin n) ℝ) (N k : ℕ)
    (hp : p.IsHomogeneous N) (hnorm : MvPolynomial.eval (fun _ => 1) p=1) :
    MvPolynomial.eval (fun _ => 1) (sourceSubsetRootSumPolynomial p N k)=(k : ℝ)^(N.choose k) := by
  rw [sourceSubsetRootSumPolynomial_real_eval_of_factors p N k (fun _ => 1) (fun _ => 1)
    (source_line_at_one_full_factors p N hp hnorm)]
  have hcard (s : Finset (Fin N)) (hs : s∈Finset.univ.powersetCard k) : s.card=k := by
    simpa only [Finset.mem_powersetCard_univ] using hs
  have hterm (s : Finset (Fin N)) (hs : s∈Finset.univ.powersetCard k) : (∑ _i∈s,(1 : ℝ))=(k : ℝ) := by
    simp [hcard s hs]
  rw [Finset.prod_congr rfl hterm]
  simp

end CoefficientStability
