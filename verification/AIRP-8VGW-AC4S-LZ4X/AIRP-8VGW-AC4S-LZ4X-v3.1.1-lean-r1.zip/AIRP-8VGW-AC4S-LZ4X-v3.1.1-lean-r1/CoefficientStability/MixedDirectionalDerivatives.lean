import CoefficientStability.MixedStationarity
import Mathlib.Analysis.Calculus.Deriv.Comp
import Mathlib.Analysis.Calculus.Deriv.Add
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.Analysis.Calculus.Deriv.Prod

noncomputable section
open scoped BigOperators Matrix.Norms.Elementwise
namespace CoefficientStability
variable {n : ℕ}

theorem actual_mixed_comp_hasDerivAt (G : ℂ → Fin n → Matrix (Fin n) (Fin n) ℂ)
    (H : Fin n → Matrix (Fin n) (Fin n) ℂ) (s : ℂ) (hG : HasDerivAt G H s) :
    HasDerivAt (fun z => complexMixedDiscriminant (G z))
      (∑ i,complexMixedDiscriminant (Function.update (G s) i (H i))) s := by
  have hd : HasFDerivAt (𝕜 := ℂ) (actualMixedContinuous (n := n))
      ((actualMixedContinuous (n := n)).linearDeriv (G s)) (G s) :=
    (actualMixedContinuous (n := n)).hasFDerivAt (G s)
  have h := hd.comp_hasDerivAt s hG
  convert h using 1
  · exact funext (fun z => (actualMixedContinuous_eq (G z)).symm)
  · symm
    exact (actualMixedContinuous (n := n)).linearDeriv_apply (G s) H |>.trans
      (Finset.sum_congr rfl (fun i hi => actualMixedContinuous_eq _))

theorem affine_tuple_hasDerivAt (A H : Fin n → Matrix (Fin n) (Fin n) ℂ) (s : ℂ) :
    HasDerivAt (fun z : ℂ => A+z • H) H s := by
  convert (hasDerivAt_const s A).add ((hasDerivAt_id s).smul_const H) using 1 <;> first | rfl | simp only [one_smul,zero_add]

theorem updated_affine_tuple_hasDerivAt (A H : Fin n → Matrix (Fin n) (Fin n) ℂ)
    (s : ℂ) (i : Fin n) :
    HasDerivAt (fun z : ℂ => Function.update (A+z • H) i (H i)) (Function.update H i 0) s := by
  apply hasDerivAt_pi.mpr
  intro j
  by_cases hj : j=i
  · subst j
    simpa only [Function.update_self] using hasDerivAt_const s (H i)
  · simp only [Function.update_of_ne hj,Pi.add_apply,Pi.smul_apply]
    convert (hasDerivAt_const s (A j)).add ((hasDerivAt_id s).smul_const (H j)) using 1 <;> first | rfl | simp only [one_smul,zero_add]

theorem actual_mixed_curve_derivative (A H : Fin n → Matrix (Fin n) (Fin n) ℂ) (s : ℂ) :
    deriv (fun z : ℂ => complexMixedDiscriminant (A+z • H)) s=
      ∑ i,complexMixedDiscriminant (Function.update (A+s • H) i (H i)) :=
  (actual_mixed_comp_hasDerivAt _ H s (affine_tuple_hasDerivAt A H s)).deriv

theorem actual_mixed_curve_second_derivative (A H : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    deriv (fun s : ℂ => deriv (fun z : ℂ => complexMixedDiscriminant (A+z • H)) s) 0=
      ∑ i,∑ j,complexMixedDiscriminant
        (Function.update (Function.update A i (H i)) j ((Function.update H i 0) j)) := by
  have he : (fun s : ℂ => deriv (fun z : ℂ => complexMixedDiscriminant (A+z • H)) s)=
      (fun s : ℂ => ∑ i,complexMixedDiscriminant (Function.update (A+s • H) i (H i))) :=
    funext (actual_mixed_curve_derivative A H)
  rw [he]
  have hi (i : Fin n) := actual_mixed_comp_hasDerivAt
    (fun s : ℂ => Function.update (A+s • H) i (H i)) (Function.update H i 0) 0
    (updated_affine_tuple_hasDerivAt A H 0 i)
  have hs := HasDerivAt.fun_sum (u := Finset.univ) (fun i hi' => hi i)
  simpa only [zero_smul,add_zero] using hs.deriv

end CoefficientStability
