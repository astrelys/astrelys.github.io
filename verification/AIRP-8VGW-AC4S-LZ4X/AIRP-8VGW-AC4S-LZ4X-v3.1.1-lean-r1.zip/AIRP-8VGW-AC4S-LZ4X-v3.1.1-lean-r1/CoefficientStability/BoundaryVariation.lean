import CoefficientStability.BoundaryDeterminant

noncomputable section
open scoped BigOperators
open Polynomial
namespace CoefficientStability
variable {n : ℕ}

theorem boundaryProductPolynomial_product (t : Fin n → ℝ) :
    boundaryProductPolynomial t=∏ i,(1-Polynomial.C ((n : ℝ)*projectedOnes t i)*Polynomial.X) := by
  unfold boundaryProductPolynomial onePlusProduct
  apply Finset.prod_congr rfl
  intro i hi
  simp only [neg_mul,Polynomial.C_neg]
  ring

theorem boundaryProductPolynomial_X_derivative (t : Fin n → ℝ) :
    Polynomial.X*(boundaryProductPolynomial t).derivative =
      -(∑ i,(Polynomial.C ((n : ℝ)*projectedOnes t i)*Polynomial.X)*
        (∏ j ∈ Finset.univ.erase i,(1-Polynomial.C ((n : ℝ)*projectedOnes t j)*Polynomial.X))) := by
  classical
  rw [boundaryProductPolynomial_product,Polynomial.derivative_prod_finset,Finset.mul_sum,
    ← Finset.sum_neg_distrib]
  apply Finset.sum_congr rfl
  intro i hi
  simp only [Polynomial.derivative_sub,Polynomial.derivative_one,Polynomial.derivative_mul,
    Polynomial.derivative_C,Polynomial.derivative_X,zero_mul,mul_one,zero_add,zero_sub]
  ring

theorem boundaryMixedPolynomial_formula (t : Fin n → ℝ) (hn : 0<n) :
    boundaryMixedPolynomial t=Polynomial.C (boundaryNormalizingFactor t)*
      (boundaryProductPolynomial t-Polynomial.X*(boundaryProductPolynomial t).derivative) := by
  rw [boundaryMixedPolynomial_distinguished_formula t hn,boundaryProductPolynomial_X_derivative,
    boundaryProductPolynomial_product,sub_neg_eq_add]

theorem coeff_X_derivative_real (p : ℝ[X]) (k : ℕ) :
    (Polynomial.X*p.derivative).coeff k=(k : ℝ)*p.coeff k := by
  cases k with
  | zero => simp
  | succ k => simp [Polynomial.coeff_X_mul,Polynomial.coeff_derivative,Nat.cast_add,Nat.cast_one,mul_comm]

theorem boundaryMixedPolynomial_coeff (t : Fin n → ℝ) (hn : 0<n) (k : ℕ) :
    (boundaryMixedPolynomial t).coeff k=boundaryNormalizingFactor t*(1-(k : ℝ))*(-(n : ℝ))^k*
      centralCoefficient (projectedOnes t) k := by
  rw [boundaryMixedPolynomial_formula t hn,Polynomial.coeff_C_mul,Polynomial.coeff_sub,
    coeff_X_derivative_real,boundaryProductPolynomial_coeff]
  ring

theorem boundaryNormalizingFactor_pos (t : Fin n → ℝ) (hn : 0<n) (htpos : ∀ i,0<t i) :
    0<boundaryNormalizingFactor t := by
  have hf : (0 : ℝ)<(n.factorial : ℝ) := by exact_mod_cast Nat.factorial_pos n
  have hn' : (0 : ℝ)<n := by exact_mod_cast hn
  unfold boundaryNormalizingFactor
  exact mul_pos hf (Finset.prod_pos (fun i hi => div_pos (htpos i) hn'))

theorem boundaryMixedPolynomial_coeff_one (t : Fin n → ℝ) (hn : 0<n) :
    (boundaryMixedPolynomial t).coeff 1=0 := by
  rw [boundaryMixedPolynomial_coeff t hn 1]
  norm_num

theorem boundaryMixedPolynomial_boundary_coeff_two (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : scalarHessianLambda t=0) :
    (boundaryMixedPolynomial t).coeff 2=0 := by
  rw [boundaryMixedPolynomial_coeff t (by omega) 2,
    (paper_boundary_third_coefficient t hn ht htpos hl).1,mul_zero]

theorem boundaryMixedPolynomial_boundary_coeff_three_neg (t : Fin n → ℝ) (hn : 3≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : scalarHessianLambda t=0) :
    (boundaryMixedPolynomial t).coeff 3<0 := by
  have he := (paper_boundary_third_coefficient t (by omega) ht htpos hl).2.2
  have hnorm := boundaryNormalizingFactor_pos t (by omega) htpos
  have hn' : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
  rw [boundaryMixedPolynomial_coeff t (by omega) 3]
  have hcube : (-(n : ℝ))^3<0 := by nlinarith [pow_pos hn' 3]
  have hp : 0<boundaryNormalizingFactor t*(1-(3 : ℝ))*(-(n : ℝ))^3 :=
    mul_pos_of_neg_of_neg (mul_neg_of_pos_of_neg hnorm (by norm_num)) hcube
  exact mul_neg_of_pos_of_neg hp he

end CoefficientStability
