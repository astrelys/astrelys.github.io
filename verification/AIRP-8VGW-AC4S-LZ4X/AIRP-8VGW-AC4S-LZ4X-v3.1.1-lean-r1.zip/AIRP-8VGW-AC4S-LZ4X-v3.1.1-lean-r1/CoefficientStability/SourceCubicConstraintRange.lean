import CoefficientStability.SourceCubicFeasibleGeometry
import CoefficientStability.HermitianDimension

noncomputable section
open scoped BigOperators Matrix
namespace CoefficientStability
set_option maxHeartbeats 2000000
set_option backward.isDefEq.respectTransparency false

abbrev SourceCubicHermitianSpace := selfAdjoint (ComplexSquare 3)
abbrev SourceCubicHermitianTuples := Fin 3 → SourceCubicHermitianSpace
abbrev SourceCubicConstraintSpace := SourceCubicHermitianSpace × (Fin 2 → ℝ)

def sourceCubicHermitianOne : SourceCubicHermitianSpace := ⟨1,by exact IsSelfAdjoint.one _⟩

def sourceCubicConstraintMap : SourceCubicHermitianTuples →ₗ[ℝ] SourceCubicConstraintSpace where
  toFun Y := (∑ i,Y i,![hermitianTrace 3 (Y 0),hermitianTrace 3 (Y 1)])
  map_add' Y Z := by
    apply Prod.ext
    · simp only [Pi.add_apply,Finset.sum_add_distrib,Prod.fst_add]
    · funext j
      fin_cases j <;> simp [map_add]
  map_smul' a Y := by
    apply Prod.ext
    · simp only [Pi.smul_apply,Finset.smul_sum,Prod.smul_fst,RingHom.id_apply]
    · funext j
      fin_cases j <;> simp [map_smul]

def sourceCubicConstraintRightInverse (q : SourceCubicConstraintSpace) : SourceCubicHermitianTuples :=
  ![(q.2 0/3) • sourceCubicHermitianOne,(q.2 1/3) • sourceCubicHermitianOne,
    q.1-(q.2 0/3) • sourceCubicHermitianOne-(q.2 1/3) • sourceCubicHermitianOne]

theorem source_cubic_constraint_right_inverse (q : SourceCubicConstraintSpace) :
    sourceCubicConstraintMap (sourceCubicConstraintRightInverse q)=q := by
  apply Prod.ext
  · change (∑ i,sourceCubicConstraintRightInverse q i)=q.1
    norm_num [sourceCubicConstraintRightInverse,Fin.sum_univ_succ]
  · funext j
    fin_cases j <;> norm_num [sourceCubicConstraintMap,sourceCubicConstraintRightInverse,sourceCubicHermitianOne,hermitianTrace,Matrix.trace_smul,Matrix.trace_one]

theorem source_cubic_constraint_surjective : Function.Surjective sourceCubicConstraintMap := by
  intro q
  exact ⟨sourceCubicConstraintRightInverse q,source_cubic_constraint_right_inverse q⟩

theorem source_cubic_constraint_recovers_third_trace (Y : SourceCubicHermitianTuples) (t : Fin 3 → ℝ)
    (ht : (∑ i,t i)=3)
    (hY : sourceCubicConstraintMap Y=(sourceCubicHermitianOne,![t 0,t 1])) :
    (∑ i,(Y i).val)=1 ∧ ∀ i,Matrix.trace (Y i).val=(t i : ℂ) := by
  have hs : (∑ i,Y i)=sourceCubicHermitianOne := congrArg Prod.fst hY
  have h0 : hermitianTrace 3 (Y 0)=t 0 := congrFun (congrArg Prod.snd hY) 0
  have h1 : hermitianTrace 3 (Y 1)=t 1 := congrFun (congrArg Prod.snd hY) 1
  have hsum : (∑ i,(Y i).val)=1 := by
    have h := congrArg Subtype.val hs
    simpa [sourceCubicHermitianOne] using h
  have him (i : Fin 3) : (Matrix.trace (Y i).val).im=0 := by
    have hh : ((Y i).val).IsHermitian := (Y i).property
    have h := congrArg Complex.im (Matrix.trace_conjTranspose (Y i).val)
    rw [hh.eq] at h
    simp only [Complex.star_def,Complex.conj_im] at h
    linarith
  have htr := congrArg (fun M : Matrix (Fin 3) (Fin 3) ℂ => (Matrix.trace M).re) hsum
  norm_num [Matrix.trace_sum,Matrix.trace_one,Complex.re_sum,Fin.sum_univ_succ] at htr
  have hts := ht
  norm_num [Fin.sum_univ_succ] at hts
  refine ⟨hsum,?_⟩
  intro i
  apply Complex.ext
  · fin_cases i
    · change (Matrix.trace (Y 0).val).re=t 0
      exact h0
    · change (Matrix.trace (Y 1).val).re=t 1
      exact h1
    · change (Matrix.trace (Y 2).val).re=t 2
      dsimp [hermitianTrace] at h0 h1
      linarith
  · simp only [Complex.ofReal_im]
    exact him i

end CoefficientStability
