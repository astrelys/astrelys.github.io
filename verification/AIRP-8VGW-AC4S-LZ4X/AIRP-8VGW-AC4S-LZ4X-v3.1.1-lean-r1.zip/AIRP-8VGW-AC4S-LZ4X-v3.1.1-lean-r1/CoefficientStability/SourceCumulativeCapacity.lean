import CoefficientStability.SourceCumulativePrefix
import CoefficientStability.PositiveOrderedSourceRoots
import CoefficientStability.FinitePrefixCardinality

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem cumulativeInput_pos (hn : 0<n) (c : Fin n → ℝ) (hc : ∀ j,0≤c j)
    (hc0 : 0<c ⟨0,hn⟩) : ∀ i,0<cumulativeInput c i := by
  classical
  intro i
  have hle : c ⟨0,hn⟩≤∑ j∈Finset.univ.filter (fun j => j ≤ i),c j := by
    apply Finset.single_le_sum (fun j hj => hc j)
    simp only [Finset.mem_filter,Finset.mem_univ,true_and]
    change (0 : ℕ) ≤ i.val
    exact Nat.zero_le _
  exact lt_of_lt_of_le hc0 hle

theorem actual_source_value_root_product (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (x : Fin n → ℝ) (roots : Fin N → ℝ)
    (hf : lineRestriction p x=∏ j : Fin N,(Polynomial.X+Polynomial.C (roots j))) :
    MvPolynomial.eval x p=∏ j,roots j := by
  have h := congrArg (fun Q : Polynomial ℝ => Q.eval 0) hf
  rw [eval_lineRestriction_real,Polynomial.eval_prod] at h
  simpa only [Polynomial.eval_add,Polynomial.eval_X,Polynomial.eval_C,zero_add] using h

theorem source_cumulative_pointwise_capacity_lower (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (c : Fin n → ℝ)
    (hc : ∀ j,0≤c j) (hc0 : 0<c ⟨0,hn⟩)
    (hδ : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)<2) :
    (1-(∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)/2)^n*
      (∏ i,cumulativeInput c i)≤MvPolynomial.eval (cumulativeInput c) p := by
  classical
  let ε : ℝ := (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)/2
  have heps : 0<1-ε := by dsimp [ε];linarith
  have hx := cumulativeInput_pos hn c hc hc0
  obtain ⟨roots,hmono,hfactor⟩ := actual_source_ordered_root_tuple p n hp hs hnorm (cumulativeInput c)
  have hr := actual_source_positive_input_root_pos p n hp hs hnorm (cumulativeInput c) hx roots hfactor
  have hprefix : ∀ k,k ≤ n → finiteInputPrefix (fun i => (1-ε)*cumulativeInput c i) k≤finiteInputPrefix roots k := by
    intro k hk
    by_cases hkzero : k=0
    · subst k
      simp [finiteInputPrefix]
    · have hkpos : 0<k := Nat.pos_of_ne_zero hkzero
      let T : Finset (Fin n) := Finset.univ.filter (fun i => i.val < k)
      have hT : T∈Finset.univ.powersetCard k := by
        simpa only [T,Finset.mem_powersetCard_univ] using finite_prefix_coordinate_card k hk
      have h := actual_source_cumulative_spectral_prefix_bound p hn hp hs hnorm c hc k hkpos hk roots hfactor T hT
      rw [finiteInputPrefix_scalar]
      exact h
  have hprod := positive_finiteTuple_product_comparison (fun i => (1-ε)*cumulativeInput c i) roots
    (fun i => mul_pos heps (hx i)) hr hmono hprefix
  rw [Finset.prod_mul_distrib,Finset.prod_const,Finset.card_univ,Fintype.card_fin] at hprod
  rw [← actual_source_value_root_product p n (cumulativeInput c) roots hfactor] at hprod
  exact hprod

end CoefficientStability
