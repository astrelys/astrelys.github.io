import CoefficientStability.QuadraticExponentObstruction

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem source_direction_exponent_obstruction (t v : Fin (n+2) → ℝ)
    (ht : (∑ i,t i)=(n+2 : ℝ)) (htpos : ∀ i,0 < t i)
    (hv : (∑ i,v i)=0) (hvne : v≠0) (θ c e : ℝ)
    (hθ : θ < 1) (hc : 0 < c) (he : 0 < e) :
    ∃ p : MvPolynomial (Fin (n+2)) ℝ,p.IsHomogeneous (n+2) ∧
      MvPolynomial.eval (fun _ => 1) p=1 ∧ UpperHalfPlaneZeroFree p ∧
      (∀ g,0 ≤ p.coeff g) ∧ (∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) ∧
      0 < coefficientL1 (p-scalarPower t (n+2)) ∧ coefficientL1 (p-scalarPower t (n+2)) < e ∧
      p.coeff (squarefreeExponent (n+2))-sourceVn (n+2)*(∏ i,t i) <
        c*(coefficientL1 (p-scalarPower t (n+2)))^θ := by
  let Q := (scalarLinear t (n+2))^n*(scalarLinear v 1)^2
  let D := coefficientL1 Q
  let G := -Q.coeff (squarefreeExponent (n+2))
  have hD : 0 < D := source_quadratic_defect_norm_pos t v ht hvne
  obtain ⟨a,ha,hfeasible⟩ := twoFactorSourcePolynomial_feasible t v ht htpos hv
  have hsqrt : 0 < Real.sqrt (e/D) := Real.sqrt_pos.mpr (div_pos he hD)
  obtain ⟨s,hs,hsmall,hbad⟩ := scalar_quadratic_exponent_obstruction
    (min a (Real.sqrt (e/D))) c D G θ (lt_min ha hsqrt) hc hD hθ
  have hsa : |s| < a := by rw [abs_of_pos hs];exact hsmall.trans_le (min_le_left _ _)
  obtain ⟨hph,hpn,hps,hpc,hpg⟩ := hfeasible s hsa
  have hd := twoFactorSourcePolynomial_coefficient_distance t v s
  change coefficientL1 (twoFactorSourcePolynomial t v s-scalarPower t (n+2))=s^2*D at hd
  have hdist : s^2*D < e := by
    have hsr : s < Real.sqrt (e/D) := hsmall.trans_le (min_le_right _ _)
    have hsq : s^2 < (Real.sqrt (e/D))^2 := (sq_lt_sq₀ hs.le hsqrt.le).mpr hsr
    rw [Real.sq_sqrt (div_pos he hD).le] at hsq
    exact (lt_div_iff₀ hD).mp hsq
  have hgap := twoFactorSourcePolynomial_coefficient_gap t v s
  have heq : (scalarPower t (n+2)).coeff (squarefreeExponent (n+2))=sourceVn (n+2)*(∏ i,t i) :=
    scalarPower_squarefree_coefficient t
  rw [heq] at hgap
  have hG : -s^2*Q.coeff (squarefreeExponent (n+2))=G*s^2 := by dsimp [G];ring
  change (twoFactorSourcePolynomial t v s).coeff (squarefreeExponent (n+2))-sourceVn (n+2)*(∏ i,t i)=
    -s^2*Q.coeff (squarefreeExponent (n+2)) at hgap
  rw [hG] at hgap
  refine ⟨twoFactorSourcePolynomial t v s,hph,hpn,hps,hpc,hpg,?_,?_,?_⟩
  · rw [hd];exact mul_pos (sq_pos_of_pos hs) hD
  · rwa [hd]
  · rw [hgap,hd]
    exact hbad

theorem source_linear_stability_exponent_optimal (n : ℕ) (hn : 2 ≤ n)
    (t : Fin n → ℝ) (ht : (∑ i,t i)=n) (htpos : ∀ i,0 < t i)
    (θ c e : ℝ) (hθ : θ < 1) (hc : 0 < c) (he : 0 < e) :
    ∃ p : MvPolynomial (Fin n) ℝ,p.IsHomogeneous n ∧
      MvPolynomial.eval (fun _ => 1) p=1 ∧ UpperHalfPlaneZeroFree p ∧
      (∀ g,0 ≤ p.coeff g) ∧ (∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) ∧
      0 < coefficientL1 (p-scalarPower t n) ∧ coefficientL1 (p-scalarPower t n) < e ∧
      p.coeff (squarefreeExponent n)-sourceVn n*(∏ i,t i) < c*(coefficientL1 (p-scalarPower t n))^θ := by
  obtain ⟨m,hm⟩ := Nat.exists_eq_add_of_le hn
  have hnm : n=m+2 := by omega
  clear hm
  subst n
  letI : NeZero (m+2) := ⟨by omega⟩
  let v : Fin (m+2) → ℝ := Pi.single 0 1-Pi.single 1 1
  have hv : (∑ i,v i)=0 := by simp [v,Finset.sum_sub_distrib]
  have h10 : (1 : Fin (m+2))≠0 := by
    intro hh
    have h := congrArg Fin.val hh
    norm_num at h
  have hvne : v≠0 := by
    intro hz
    have h := congrFun hz 0
    simp [v,Pi.single_apply,h10,Ne.symm h10] at h
  exact source_direction_exponent_obstruction t v (by simpa only [Nat.cast_add,Nat.cast_ofNat] using ht)
    htpos hv hvne θ c e hθ hc he

end CoefficientStability
