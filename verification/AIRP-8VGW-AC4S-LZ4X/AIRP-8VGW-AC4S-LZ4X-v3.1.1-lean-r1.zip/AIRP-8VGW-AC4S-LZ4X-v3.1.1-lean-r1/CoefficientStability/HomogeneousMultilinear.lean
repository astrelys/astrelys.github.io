import CoefficientStability.MultilinearPolarization
import Mathlib.Data.Finsupp.Multiset
import Mathlib.Data.List.OfFn

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n k : ℕ}

theorem exponentMultiset_prod (g : Fin n →₀ ℕ) (x : Fin n → ℝ) :
    (g.toMultiset.map x).prod = g.prod (fun i m => x i^m) := by
  classical
  induction g using Finsupp.induction with
  | zero => simp
  | @single_add i m g hi hm ih =>
    rw [Finsupp.toMultiset_add,Finsupp.toMultiset_single,Multiset.map_add,Multiset.prod_add,
      Multiset.map_nsmul,Multiset.prod_nsmul,Multiset.map_singleton,Multiset.prod_singleton,ih]
    rw [Finsupp.prod_add_index' (fun _ => pow_zero _) (fun i a b => pow_add (x i) a b),
      Finsupp.prod_single_index (h := fun a m => x a^m) (pow_zero (x i))]

theorem monomial_exists_word (g : Fin n →₀ ℕ) (k : ℕ) (hg : ∑ i,g i=k) :
    ∃ f : Fin k → Fin n,∀ x : Fin n → ℝ,
      MvPolynomial.eval x (monomial g (1 : ℝ)) = ∏ j,x (f j) := by
  let L := g.toMultiset.toList
  have hlen : L.length=k := by
    simp only [L,Multiset.length_toList,Finsupp.card_toMultiset,Finsupp.sum]
    rw [← hg]
    exact Finset.sum_subset (Finset.subset_univ _) (by intro i hi hnot; simp [Finsupp.notMem_support_iff.mp hnot])
  cases hlen
  refine ⟨L.get,?_⟩
  intro x
  have hL : ((L : Multiset (Fin n)).map x).prod = g.prod (fun i m => x i^m) := by
    simpa only [L,Multiset.coe_toList] using exponentMultiset_prod g x
  rw [MvPolynomial.eval_monomial,one_mul]
  rw [← hL]
  simp only [Multiset.map_coe,Multiset.prod_coe]
  rw [← List.prod_ofFn]
  congr 1
  rw [← Function.comp_def,← List.map_ofFn,List.ofFn_get]

def coordinateProductMultilinear (f : Fin k → Fin n) :
    MultilinearMap ℝ (fun _ : Fin k => Fin n → ℝ) ℝ :=
  (MultilinearMap.mkPiAlgebra ℝ (Fin k) ℝ).compLinearMap (fun j => LinearMap.proj (f j))

@[simp] theorem coordinateProductMultilinear_apply (f : Fin k → Fin n)
    (v : Fin k → (Fin n → ℝ)) : coordinateProductMultilinear f v = ∏ j,v j (f j) := rfl

theorem homogeneous_exists_multilinear (h : MvPolynomial (Fin n) ℝ) (k : ℕ)
    (hh : h.IsHomogeneous k) :
    ∃ T : MultilinearMap ℝ (fun _ : Fin k => Fin n → ℝ) ℝ,
      ∀ x : Fin n → ℝ,T (fun _ => x)=MvPolynomial.eval x h := by
  classical
  have hw (g : {g // g∈h.support}) : ∃ f : Fin k → Fin n,∀ x : Fin n → ℝ,
      MvPolynomial.eval x (monomial g.val (1 : ℝ)) = ∏ j,x (f j) :=
    monomial_exists_word g.val k (homogeneous_mass h k hh g.val g.prop)
  choose word hword using hw
  refine ⟨∑ g : {g // g∈h.support},h.coeff g.val • coordinateProductMultilinear (word g),?_⟩
  intro x
  simp only [MultilinearMap.sum_apply,MultilinearMap.smul_apply,smul_eq_mul,
    coordinateProductMultilinear_apply,← hword]
  conv_rhs => rw [h.as_sum]
  simp only [map_sum,MvPolynomial.eval_monomial,one_mul]
  exact Finset.sum_coe_sort h.support (fun g => h.coeff g * g.prod (fun i m => x i^m))

end CoefficientStability
