import CoefficientStability.StableLeadingCoefficient
import CoefficientStability.StableHigherRemainder

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem paper_stable_effective_gap (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hn : 2≤n) (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p) (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i)
    (M : ℝ) (hM : ∀ i,t i≤M) (hl : 0<scalarHessianLambda t)
    (hd1 : referenceDeficit p t n≤1) :
    (sourceHessianFactor t*(scalarHessianLambda t/M^2))*referenceDeficit p t n-
      polarizationRemainderConstant n*(referenceDeficit p t n*Real.sqrt (referenceDeficit p t n))≤
      (p-scalarPower t n).coeff (squarefreeExponent n) := by
  have hd := referenceDeficit_nonneg p t n hn hp hnorm hstable hgrad
  have hlead := paper_stable_leading_gap_lower p t hn hp hnorm hstable ht htpos hgrad M hM hl
  have htail := stableHigherRemainder_coefficient_bound p t hn hp hnorm hstable ht
    (fun i => (htpos i).le) hgrad hd hd1
  have he : (p-scalarPower t n).coeff (squarefreeExponent n)=
      -(((scalarLinear t n)^(n-2)*quadraticPolynomial (deficitMatrix p t n)).coeff (squarefreeExponent n))+
        (stableHigherRemainder p t).coeff (squarefreeExponent n) := by
    rw [paper_difference_polynomial_expansion p t n hn hp hnorm hstable hgrad]
    simp [stableHigherRemainder]
  rw [he]
  have hneg := neg_le_of_abs_le htail
  linarith

theorem polarizationRemainderConstant_nonnegative (n : ℕ) : 0≤polarizationRemainderConstant n := by
  unfold polarizationRemainderConstant
  apply Finset.sum_nonneg
  intro j hj
  positivity

theorem cubic_remainder_absorption (a B : ℝ) (ha : 0<a) (hB : 0≤B) :
    ∃ r : ℝ,0<r ∧ r≤1 ∧ ∀ d : ℝ,0≤d → d≤r → a/2*d≤a*d-B*(d*Real.sqrt d) := by
  let s := min 1 (a/(2*(B+1)))
  have hden : 0<2*(B+1) := by positivity
  have hs : 0<s := lt_min (by norm_num) (div_pos ha hden)
  have hs1 : s≤1 := min_le_left _ _
  have hsratio : s*(2*(B+1))≤a := (le_div_iff₀ hden).mp (min_le_right _ _)
  refine ⟨s^2,sq_pos_of_pos hs,by nlinarith,?_⟩
  intro d hd hdr
  have hsq := Real.sq_sqrt hd
  have hroot : Real.sqrt d≤s := by nlinarith [Real.sqrt_nonneg d]
  have hbound : B*Real.sqrt d≤a/2 := by
    have hmul := mul_le_mul_of_nonneg_left hroot hB
    nlinarith
  have hm := mul_le_mul_of_nonneg_right hbound hd
  nlinarith

end CoefficientStability
