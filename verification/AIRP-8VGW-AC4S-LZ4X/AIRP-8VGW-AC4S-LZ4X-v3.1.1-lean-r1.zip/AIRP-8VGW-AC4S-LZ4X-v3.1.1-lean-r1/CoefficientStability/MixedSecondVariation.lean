import CoefficientStability.TwoColumnDeterminant
import CoefficientStability.PermutationPairAverage

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ} {R : Type*} [CommRing R]

theorem mixed_two_argument_columns (B C : Matrix (Fin n) (Fin n) R)
    (i j : Fin n) (hij : i≠j) (q : Equiv.Perm (Fin n)) :
    (fun r c => (Function.update (Function.update (fun _ : Fin n => (1 : Matrix (Fin n) (Fin n) R)) i B) j C) (q c) r c)=
      Matrix.updateCol (Matrix.updateCol 1 (q.symm i) (fun r => B r (q.symm i)))
        (q.symm j) (fun r => C r (q.symm j)) := by
  apply Matrix.ext
  intro r c
  by_cases hcj : c=q.symm j
  · subst c
    simp
  · have hqj : q c≠j := by
      intro h
      apply hcj
      apply q.injective
      simpa using h
    by_cases hci : c=q.symm i
    · subst c
      simp [hij,Function.update_of_ne hqj,Matrix.updateCol_ne hcj]
    · have hqi : q c≠i := by
        intro h
        apply hci
        apply q.injective
        simpa using h
      simp [Function.update_of_ne hqj,Function.update_of_ne hqi,Matrix.updateCol_ne hcj,
        Matrix.updateCol_ne hci]

theorem matrix_pair_trace_sum (B C : Matrix (Fin n) (Fin n) R) :
    (∑ r,∑ c,if c=r then (0 : R) else B r r*C c c-B c r*C r c)=
      Matrix.trace B*Matrix.trace C-Matrix.trace (B*C) := by
  classical
  have he (r c : Fin n) : (if c=r then (0 : R) else B r r*C c c-B c r*C r c)=
      B r r*C c c-B c r*C r c := by
    by_cases hc : c=r <;> simp [hc]
  simp only [he,Finset.sum_sub_distrib]
  have hfirst : (∑ r,∑ c,B r r*C c c)=Matrix.trace B*Matrix.trace C := by
    simp only [← Finset.mul_sum,← Finset.sum_mul,Matrix.trace,Matrix.diag]
  have hsecond : (∑ r,∑ c,B c r*C r c)=Matrix.trace (B*C) := by
    rw [Finset.sum_comm]
    rfl
  rw [hfirst,hsecond]

theorem genericMixedDiscriminant_two_arguments [IsDomain R] [CharZero R]
    (B C : Matrix (Fin n) (Fin n) R) (hn : 2≤n) (i j : Fin n) (hij : i≠j) :
    genericMixedDiscriminant (Function.update (Function.update (fun _ : Fin n => 1) i B) j C)=
      ((n-2).factorial : R)*(Matrix.trace B*Matrix.trace C-Matrix.trace (B*C)) := by
  rw [genericMixedDiscriminant_eq_rowDetSum]
  have hqne (q : Equiv.Perm (Fin n)) : q.symm i≠q.symm j := by
    exact fun h => hij (q.symm.injective h)
  simp only [mixed_two_argument_columns B C i j hij,det_identity_two_columns _ _ _ _ (hqne _)]
  have he : (∑ q : Equiv.Perm (Fin n),
      (B (q.symm i) (q.symm i)*C (q.symm j) (q.symm j)-B (q.symm j) (q.symm i)*C (q.symm i) (q.symm j)))=
      ∑ q : Equiv.Perm (Fin n),
      (B (q i) (q i)*C (q j) (q j)-B (q j) (q i)*C (q i) (q j)) := by
    exact Fintype.sum_equiv (Equiv.inv (Equiv.Perm (Fin n))) _ _ (fun q => rfl)
  rw [he,permutation_pair_sum (fun r c => B r r*C c c-B c r*C r c) hn i j hij,
    matrix_pair_trace_sum]

end CoefficientStability
