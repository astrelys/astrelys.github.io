import CoefficientStability.SourceCubicScalarProjectionTuple

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 2800000
set_option backward.isDefEq.respectTransparency false

def sourceVectorColumnMatrix (v : Fin 3 → Fin 3 → ℂ) : Matrix (Fin 3) (Fin 3) ℂ := fun r i => v i r

theorem source_weighted_projection_column_identity (b : Fin 3 → ℝ) (v : Fin 3 → Fin 3 → ℂ) :
    (∑ i,(b i : ℂ) • sourceUnitProjection (v i))=
      sourceVectorColumnMatrix v*Matrix.diagonal (fun i => (b i : ℂ))*star (sourceVectorColumnMatrix v) := by
  ext r c
  rw [Matrix.mul_apply]
  simp only [Matrix.sum_apply,Matrix.smul_apply,sourceUnitProjection,Matrix.vecMulVec_apply,
    Matrix.mul_diagonal,Matrix.star_eq_conjTranspose,Matrix.conjTranspose_apply,sourceVectorColumnMatrix,smul_eq_mul,Pi.star_apply]
  apply Finset.sum_congr rfl
  intro i hi
  ring

theorem source_rank_one_nonzero_scalar_resolution (b : Fin 3 → ℝ) (v : Fin 3 → Fin 3 → ℂ)
    (hv : ∀ i,star (v i) ⬝ᵥ v i=1) (c : ℝ) (hc : c≠0)
    (hres : (∑ i,(b i : ℂ) • sourceUnitProjection (v i))=(c : ℂ) • 1) :
    (∀ i,b i=c) ∧ star (sourceVectorColumnMatrix v)*sourceVectorColumnMatrix v=1 := by
  let V := sourceVectorColumnMatrix v
  let D : Matrix (Fin 3) (Fin 3) ℂ := Matrix.diagonal (fun i => (b i : ℂ))
  have hVD : V*D*star V=(c : ℂ) • 1 := (source_weighted_projection_column_identity b v).symm.trans hres
  have hcc : (c : ℂ)≠0 := by exact_mod_cast hc
  have hdet := congrArg Matrix.det hVD
  norm_num [Matrix.det_mul,Matrix.det_smul] at hdet
  have hVne : V.det≠0 := by
    intro hz
    rw [hz,zero_mul,zero_mul] at hdet
    exact (pow_ne_zero 3 hcc) hdet.symm
  have hVu : IsUnit V.det := isUnit_iff_ne_zero.mpr hVne
  have hVi : V⁻¹*V=1 := Matrix.nonsing_inv_mul V hVu
  have hg := congrArg (fun M : Matrix (Fin 3) (Fin 3) ℂ => V⁻¹*M*V) hVD
  have hleft : V⁻¹*(V*D*star V)*V=D*(star V*V) := by
    calc
      V⁻¹*(V*D*star V)*V=(V⁻¹*V)*(D*(star V*V)) := by noncomm_ring
      _=D*(star V*V) := by rw [hVi,one_mul]
  have hright : V⁻¹*((c : ℂ) • (1 : Matrix (Fin 3) (Fin 3) ℂ))*V=(c : ℂ) • 1 := by
    simp only [mul_smul_comm,smul_mul_assoc,mul_one,hVi]
  rw [hleft,hright] at hg
  have hdiag (i : Fin 3) : (star V*V) i i=1 := by
    simpa [V,sourceVectorColumnMatrix,Matrix.mul_apply,Matrix.star_eq_conjTranspose,Matrix.conjTranspose_apply,dotProduct] using hv i
  have hb (i : Fin 3) : b i=c := by
    have h := congrFun (congrFun hg i) i
    dsimp only [D] at h
    simp only [Matrix.diagonal_mul,Matrix.smul_apply,Matrix.one_apply_eq,smul_eq_mul] at h
    rw [hdiag,mul_one,mul_one] at h
    exact Complex.ofReal_injective h
  have hD : D=(c : ℂ) • (1 : Matrix (Fin 3) (Fin 3) ℂ) := by
    ext i j
    simp [D,hb,Matrix.diagonal_apply,Matrix.one_apply,Matrix.smul_apply]
  rw [hD,smul_mul_assoc,one_mul] at hg
  refine ⟨hb,?_⟩
  ext i j
  have h := congrFun (congrFun hg i) j
  change (c : ℂ)*(star V*V) i j=(c : ℂ)*(1 : Matrix (Fin 3) (Fin 3) ℂ) i j at h
  exact mul_left_cancel₀ hcc h

end CoefficientStability
