import CoefficientStability.CoefficientMoments

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem actual_covariance_trace (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    Matrix.trace (coefficientCovariance p t) =
      hessianTraceAtOne p + (∑ i,t i) - ∑ i,t i^2 := by
  simp only [Matrix.trace,Matrix.diag,actual_coefficient_covariance p t hnorm hgrad,
    ite_true,Finset.sum_sub_distrib,Finset.sum_add_distrib,hessianTraceAtOne,pow_two]

theorem paper_deficit_covariance_identity (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (N : ℕ) (hN : 0 < N) (ht : ∑ i,t i=N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    referenceDeficit p t N =
      ((N : ℝ)-(∑ i,t i^2)/N-Matrix.trace (coefficientCovariance p t))/2 := by
  rw [actual_covariance_trace p t hnorm hgrad,ht]
  unfold referenceDeficit
  have hn : (N : ℝ) ≠ 0 := by exact_mod_cast Nat.ne_zero_of_lt hN
  field_simp
  ring

theorem actual_hessian_trace_lower (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hcoeff : ∀ g, 0 ≤ p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    (∑ i,t i^2)-(∑ i,t i) ≤ hessianTraceAtOne p := by
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_le_sum
  intro i hi
  have h := actual_coefficient_second_moment_lower p i hcoeff hnorm
  simp [actual_coefficient_second_moment,hgrad i] at h
  linarith

theorem deficit_le_marginal_spread (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (N : ℕ) (hN : 0 < N) (ht : ∑ i,t i=N)
    (hcoeff : ∀ g, 0 ≤ p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    referenceDeficit p t N ≤ ((N : ℝ)-(∑ i,t i^2)/N)/2 := by
  have h := actual_hessian_trace_lower p t hcoeff hnorm hgrad
  rw [ht] at h
  unfold referenceDeficit
  have hn : (N : ℝ) ≠ 0 := by exact_mod_cast Nat.ne_zero_of_lt hN
  have he : (((N : ℝ)-1)/N)*(∑ i,t i^2) =
      (∑ i,t i^2)-(∑ i,t i^2)/N := by field_simp
  rw [he]
  linarith

theorem marginal_sum_squares_lower (t : Fin n → ℝ) (hn : 0 < n)
    (ht : ∑ i,t i=n) : (n : ℝ) ≤ ∑ i,t i^2 := by
  have h := Finset.sum_mul_sq_le_sq_mul_sq (Finset.univ : Finset (Fin n))
    (fun _ => (1 : ℝ)) t
  simp only [one_mul,one_pow,Finset.sum_const,Finset.card_univ,Fintype.card_fin,
    nsmul_eq_mul,mul_one,ht] at h
  have hn' : (0 : ℝ) < n := by exact_mod_cast hn
  nlinarith

theorem paper_deficit_uniform_bound
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (hn : 2 ≤ n)
    (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p) (hcoeff : ∀ g,0 ≤ p.coeff g)
    (ht : ∑ i,t i=n) (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    0 ≤ referenceDeficit p t n ∧ referenceDeficit p t n ≤ ((n : ℝ)-1)/2 := by
  constructor
  · exact referenceDeficit_nonneg p t n hn hp hnorm hstable hgrad
  · have h := deficit_le_marginal_spread p t n (by omega) ht hcoeff hnorm hgrad
    have hs := marginal_sum_squares_lower t (by omega) ht
    have hn' : (0 : ℝ) < n := by exact_mod_cast (by omega : 0<n)
    have hdiv : (1 : ℝ) ≤ (∑ i,t i^2)/n := (le_div_iff₀ hn').mpr (by simpa using hs)
    linarith

end CoefficientStability
