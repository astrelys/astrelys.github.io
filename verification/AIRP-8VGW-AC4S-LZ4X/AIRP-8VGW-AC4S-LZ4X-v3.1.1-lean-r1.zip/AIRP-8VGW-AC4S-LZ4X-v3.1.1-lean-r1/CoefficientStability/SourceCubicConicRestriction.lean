import CoefficientStability.SourceTernaryCubicCoefficients

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

def sourceConicVariableForms : Fin 3 → MvPolynomial (Fin 2) ℝ :=
  ![MvPolynomial.X 0^2,MvPolynomial.X 0*MvPolynomial.X 1,MvPolynomial.X 1^2]

def sourceConicRestriction (p : MvPolynomial (Fin 3) ℝ) : MvPolynomial (Fin 2) ℝ :=
  MvPolynomial.eval₂ MvPolynomial.C sourceConicVariableForms p

theorem source_conic_restriction_actual_evaluation (p : MvPolynomial (Fin 3) ℝ) (u v : ℝ) :
    MvPolynomial.eval (![u,v] : Fin 2 → ℝ) (sourceConicRestriction p)=
      MvPolynomial.eval (![u^2,u*v,v^2] : Fin 3 → ℝ) p := by
  unfold sourceConicRestriction
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c;simp
  · funext i
    fin_cases i
    · change MvPolynomial.eval (![u,v] : Fin 2 → ℝ) (MvPolynomial.X 0^2)=u^2
      simp
    · change MvPolynomial.eval (![u,v] : Fin 2 → ℝ) (MvPolynomial.X 0*MvPolynomial.X 1)=u*v
      simp
    · change MvPolynomial.eval (![u,v] : Fin 2 → ℝ) (MvPolynomial.X 1^2)=v^2
      simp

theorem source_conic_restriction_homogeneous (p : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3) : (sourceConicRestriction p).IsHomogeneous 6 := by
  have hf : ∀ c : ℝ,(MvPolynomial.C c : MvPolynomial (Fin 2) ℝ).IsHomogeneous 0 := fun c => MvPolynomial.isHomogeneous_C _ c
  have hg : ∀ i,(sourceConicVariableForms i).IsHomogeneous 2 := by
    intro i
    fin_cases i
    · exact (MvPolynomial.isHomogeneous_X ℝ (0 : Fin 2)).pow 2
    · exact (MvPolynomial.isHomogeneous_X ℝ (0 : Fin 2)).mul (MvPolynomial.isHomogeneous_X ℝ (1 : Fin 2))
    · exact (MvPolynomial.isHomogeneous_X ℝ (1 : Fin 2)).pow 2
  exact hp.eval₂ MvPolynomial.C sourceConicVariableForms hf hg

theorem source_cubic_nonpositive_conic_actual_norm_factor (p : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3)
    (hconic : ∀ u v : ℝ,MvPolynomial.eval (![u^2,u*v,v^2] : Fin 3 → ℝ) p ≤ 0) :
    ∃ a : Fin 4 → ℂ,∀ u v : ℝ,
      MvPolynomial.eval (![u^2,u*v,v^2] : Fin 3 → ℝ) p=
        -Complex.normSq (sourceBinaryCubicValue a (u : ℂ) (v : ℂ)) := by
  obtain ⟨a,ha⟩ := source_nonnegative_binary_sextic_norm_factor (-sourceConicRestriction p)
    (source_conic_restriction_homogeneous p hp).neg (by
      intro u v
      rw [map_neg,source_conic_restriction_actual_evaluation]
      exact neg_nonneg.mpr (hconic u v))
  refine ⟨a,?_⟩
  intro u v
  have h := ha u v
  rw [map_neg,source_conic_restriction_actual_evaluation] at h
  linarith

end CoefficientStability
