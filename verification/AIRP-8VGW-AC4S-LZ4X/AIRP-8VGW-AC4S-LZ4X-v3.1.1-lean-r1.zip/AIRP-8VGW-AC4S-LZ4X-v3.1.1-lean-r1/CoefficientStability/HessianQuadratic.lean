import CoefficientStability.ContentRoots
import CoefficientStability.ScalarPower

noncomputable section
open scoped BigOperators
open MvPolynomial Finsupp
namespace CoefficientStability
variable {n : ℕ}

theorem eval_one_mixed_second_monomial (g : Fin n →₀ ℕ) (c : ℝ) (i j : Fin n) :
    MvPolynomial.eval (fun _ => 1) (pderiv i (pderiv j (monomial g c))) =
      (g i : ℝ)*(g j : ℝ)*c - if i=j then (g i : ℝ)*c else 0 := by
  by_cases hij : i=j
  · subst j
    rw [eval_one_second_monomial]
    simp only [ite_true]
    ring
  · simp [pderiv_monomial, MvPolynomial.eval_monomial, Finsupp.tsub_apply,
      Finsupp.single_eq_of_ne hij, Finsupp.prod, hij]
    ring

def hessianQuadraticAtOne (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ) : ℝ :=
  ∑ i, ∑ j, MvPolynomial.eval (fun _ => 1) (pderiv i (pderiv j p)) * x i * x j

theorem hessianQuadratic_monomial (g : Fin n →₀ ℕ) (c : ℝ) (x : Fin n → ℝ) :
    hessianQuadraticAtOne (monomial g c) x =
      c*((∑ i, (g i : ℝ)*x i)^2 - ∑ i, (g i : ℝ)*x i^2) := by
  unfold hessianQuadraticAtOne
  simp_rw [eval_one_mixed_second_monomial, sub_mul, Finset.sum_sub_distrib]
  have hfirst : (∑ i, ∑ j, (g i : ℝ)*(g j : ℝ)*c*x i*x j) = c*(∑ i, (g i : ℝ)*x i)^2 := by
    rw [pow_two, Finset.sum_mul_sum, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i hi
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j hj
    ring
  have hdiag : (∑ i : Fin n, ∑ j : Fin n, (if i=j then (g i : ℝ)*c else 0)*x i*x j) =
      c*∑ i, (g i : ℝ)*x i^2 := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i hi
    rw [Finset.sum_eq_single i (fun j _ hji => by simp [Ne.symm hji]) (by simp)]
    simp only [ite_true]
    ring
  rw [hfirst, hdiag]
  ring

theorem hessianQuadratic_as_sum (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ) :
    hessianQuadraticAtOne p x =
      ∑ g ∈ p.support, hessianQuadraticAtOne (monomial g (p.coeff g)) x := by
  conv_lhs => rw [p.as_sum]
  simp only [hessianQuadraticAtOne, map_sum, Finset.sum_mul]
  let a : Fin n → Fin n → (Fin n →₀ ℕ) → ℝ := fun i j g =>
    MvPolynomial.eval (fun _ => 1) (pderiv i (pderiv j (monomial g (p.coeff g)))) * x i * x j
  change (∑ i, ∑ j, ∑ g ∈ p.support, a i j g) = ∑ g ∈ p.support, ∑ i, ∑ j, a i j g
  calc
    _ = ∑ i, ∑ g ∈ p.support, ∑ j, a i j g := by
      apply Finset.sum_congr rfl
      intro i hi
      exact Finset.sum_comm
    _ = _ := Finset.sum_comm

theorem lineRestriction_second_coefficient (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ)
    (N : ℕ) (hN : 2 ≤ N) (hp : p.IsHomogeneous N) :
    2 * (lineRestriction p x).coeff (N-2) = hessianQuadraticAtOne p x := by
  rw [lineRestriction_as_sum, Polynomial.finsetSum_coeff, hessianQuadratic_as_sum]
  simp only [Polynomial.coeff_C_mul, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro g hg
  have h := monomialLine_second_coefficient g x N hN (homogeneous_mass p N hp g hg)
  rw [hessianQuadratic_monomial]
  calc
    2 * (p.coeff g * (monomialLine g x).coeff (N-2)) =
        p.coeff g * (2 * (monomialLine g x).coeff (N-2)) := by ring
    _ = _ := by rw [h]

end CoefficientStability
