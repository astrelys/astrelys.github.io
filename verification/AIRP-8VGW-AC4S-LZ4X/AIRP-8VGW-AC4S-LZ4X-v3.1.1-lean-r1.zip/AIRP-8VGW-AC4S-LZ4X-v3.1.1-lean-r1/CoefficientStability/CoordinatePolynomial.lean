import CoefficientStability.StablePartialDerivative
import Mathlib.Algebra.Polynomial.Reverse

noncomputable section
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def coordinatePolynomial (i : Fin n) :
    MvPolynomial (Fin n) ℝ →+* Polynomial (MvPolynomial (Fin n) ℝ) :=
  MvPolynomial.eval₂Hom (Polynomial.C.comp MvPolynomial.C)
    (fun j => if j=i then Polynomial.X else Polynomial.C (MvPolynomial.X j))

@[simp] theorem coordinatePolynomial_C (i : Fin n) (c : ℝ) :
    coordinatePolynomial i (MvPolynomial.C c)=Polynomial.C (MvPolynomial.C c) := by
  simp [coordinatePolynomial]

@[simp] theorem coordinatePolynomial_X (i j : Fin n) :
    coordinatePolynomial i (MvPolynomial.X j)=
      if j=i then Polynomial.X else Polynomial.C (MvPolynomial.X j) := by
  simp [coordinatePolynomial]

theorem coordinatePolynomial_complex_eval (p : MvPolynomial (Fin n) ℝ) (i : Fin n)
    (z : Fin n → ℂ) (w : ℂ) :
    Polynomial.eval₂ (MvPolynomial.eval₂Hom Complex.ofRealHom z) w (coordinatePolynomial i p)=
      MvPolynomial.eval₂ Complex.ofRealHom (Function.update z i w) p := by
  classical
  change (Polynomial.eval₂RingHom _ w) (MvPolynomial.eval₂ _ _ p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c
    simp
  · funext j
    by_cases hji : j=i
    · subst j
      simp
    · simp [hji]

theorem coordinatePolynomial_coeff_partial_zero (p : MvPolynomial (Fin n) ℝ)
    (i : Fin n) (k : ℕ) : pderiv i ((coordinatePolynomial i p).coeff k)=0 := by
  classical
  induction p using MvPolynomial.induction_on generalizing k with
  | C c => by_cases hk : k=0 <;> simp [Polynomial.coeff_C,hk]
  | add p q hp hq => simp [Polynomial.coeff_add,hp,hq]
  | mul_X p j hp =>
    by_cases hji : j=i
    · subst j
      cases k with
      | zero => simp
      | succ k => simpa using hp k
    · simp [hji,Polynomial.coeff_mul_C,pderiv_mul,hp,pderiv_X,hji,eq_comm]

def coordinateSpecialization (i : Fin n) (a : ℝ) :
    MvPolynomial (Fin n) ℝ →+* MvPolynomial (Fin n) ℝ :=
  MvPolynomial.eval₂Hom MvPolynomial.C (Function.update MvPolynomial.X i (MvPolynomial.C a))

theorem coordinatePolynomial_coeff_zero (p : MvPolynomial (Fin n) ℝ) (i : Fin n) :
    (coordinatePolynomial i p).coeff 0=coordinateSpecialization i 0 p := by
  classical
  rw [Polynomial.coeff_zero_eq_eval_zero]
  change (Polynomial.evalRingHom 0) (MvPolynomial.eval₂ _ _ p)=_
  rw [MvPolynomial.hom_eval₂]
  unfold coordinateSpecialization
  congr 1
  · ext c
    simp
  · funext j
    by_cases hji : j=i
    · subst j
      simp
    · simp [hji]

end CoefficientStability
