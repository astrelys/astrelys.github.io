import CoefficientStability.SourceCubicDoubleSpectralBranch

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 3000000
set_option backward.isDefEq.respectTransparency false

theorem source_original_cubic_local_minimum_pairwise_commutation (t : Fin 3 → ℝ)
    (ht : (∑ i,t i)=3) (htpos : ∀ i,0 < t i)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : A ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A) :
    ∀ i j,A i*A j=A j*A i := by
  obtain ⟨H,hH,μ,S,hS,hcert⟩ := source_original_cubic_multiplier_certificate t ht htpos A hA hm
  have hc : ∀ i,H*A i=A i*H := by
    intro i
    exact source_cubic_multiplier_commutes (t i) (μ i) (A i) H (S i)
      (hcert i).1 (hcert i).2.1 (hcert i).2.2
  by_cases hi : Function.Injective hH.eigenvalues
  · exact source_hermitian_simple_multiplier_pairwise_commutation H hH hi A hc
  · by_cases hs : ∀ i,hH.eigenvalues i=hH.eigenvalues 0
    · have hscalar := source_hermitian_three_constant_spectrum_scalar H hH hs
      have hscalarcert : ∀ i,sourceCubicMatrixGradient (t i) (A i)=
          (hH.eigenvalues 0 : ℂ) • 1+(μ i : ℂ) • 1+S i := by
        intro i
        rw [← hscalar]
        exact (hcert i).1
      exact source_cubic_scalar_multiplier_pairwise_commutation t (hH.eigenvalues 0) μ A S hA hscalarcert
        (fun i => (hcert i).2.1)
    · exact source_cubic_double_spectrum_local_minimum_commutes t H hH hi hs A hA hm hc

end CoefficientStability
