import CoefficientStability.SpectralConeDirection
import Mathlib.Topology.Connected.Clopen

noncomputable section
namespace CoefficientStability
variable {N : ℕ}

theorem monic_split_nonnegative_coefficients_strict (P : Polynomial ℝ) (hm : P.Monic)
    (hs : P.Splits) (hd : P.natDegree=N) (hc : ∀ k,0≤P.coeff k) (hc0 : P.coeff 0≠0) :
    ∀ k,k≤N → 0<P.coeff k := by
  have h0 : 0<P.coeff 0 := lt_of_le_of_ne (hc 0) (Ne.symm hc0)
  have hpos : ∀ t : ℝ,0<t → 0<P.eval t := fun t ht =>
    lt_of_lt_of_le h0 (univariate_constant_coeff_le_eval P hc t ht.le)
  have hz : 0<P.eval 0 := by simpa only [Polynomial.coeff_zero_eq_eval_zero] using h0
  obtain ⟨roots,hcard,hr,hlead,hfactor⟩ := positive_constant_split_positive_multiset_factors P hs hpos hz
  have hf : P=(roots.map (fun r => Polynomial.X+Polynomial.C r)).prod := by
    simpa only [hm.leadingCoeff,Polynomial.C_1,one_mul] using hfactor
  intro k hk
  rw [hf]
  exact (positive_root_product_coefficients roots hr).2 k (by rw [hcard,hd];exact hk)

theorem real_split_positive_coefficient_locus_isClopen {α : Type*} [TopologicalSpace α]
    (P : α → Polynomial ℝ) (hm : ∀ a,(P a).Monic) (hs : ∀ a,(P a).Splits)
    (hd : ∀ a,(P a).natDegree=N) (hcont : ∀ k,Continuous (fun a => (P a).coeff k))
    (hzero : ∀ a,(P a).coeff 0≠0) :
    IsClopen {a | ∀ k : Fin (N+1),0<(P a).coeff k.val} := by
  let S : Set α := {a | ∀ k : Fin (N+1),0<(P a).coeff k.val}
  have ho : IsOpen S := by
    simpa only [S,Set.ofPred_forall] using isOpen_iInter_of_finite
      (fun k : Fin (N+1) => isOpen_lt continuous_const (hcont k.val))
  have hc : IsClosed S := by
    apply isClosed_of_closure_subset
    intro a ha
    have hnonneg (k : ℕ) : 0≤(P a).coeff k := by
      by_cases hk : k≤N
      · have hsub : S⊆{a | 0≤(P a).coeff k} := fun a ha => (ha ⟨k,by omega⟩).le
        exact (closure_minimal hsub (isClosed_le continuous_const (hcont k))) ha
      · rw [Polynomial.coeff_eq_zero_of_natDegree_lt (by rw [hd a];omega)]
    intro k
    exact monic_split_nonnegative_coefficients_strict (P a) (hm a) (hs a) (hd a) hnonneg
      (hzero a) k.val (Nat.le_of_lt_succ k.isLt)
  exact ⟨hc,ho⟩

theorem connected_real_split_positive_coefficients {α : Type*} [TopologicalSpace α]
    [PreconnectedSpace α] (P : α → Polynomial ℝ) (hm : ∀ a,(P a).Monic)
    (hs : ∀ a,(P a).Splits) (hd : ∀ a,(P a).natDegree=N)
    (hcont : ∀ k,Continuous (fun a => (P a).coeff k)) (hzero : ∀ a,(P a).coeff 0≠0)
    (a0 : α) (hstart : ∀ k : Fin (N+1),0<(P a0).coeff k.val) :
    ∀ a,∀ k : Fin (N+1),0<(P a).coeff k.val := by
  have h := isPreconnected_univ.subset_isClopen
    (real_split_positive_coefficient_locus_isClopen P hm hs hd hcont hzero)
    ⟨a0,Set.mem_univ _,hstart⟩
  intro a k
  exact h (Set.mem_univ a) k

end CoefficientStability
