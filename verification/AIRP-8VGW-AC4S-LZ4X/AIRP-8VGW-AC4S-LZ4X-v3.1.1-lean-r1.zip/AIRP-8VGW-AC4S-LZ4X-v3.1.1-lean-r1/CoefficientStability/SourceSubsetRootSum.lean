import CoefficientStability.UniversalSourceLine

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def sourceSubsetRootSumPolynomial (p : MvPolynomial (Fin n) ℝ) (N k : ℕ) : MvPolynomial (Fin n) ℝ :=
  MvPolynomial.aeval (fun j : Fin N => sourceLineCoefficientPolynomial p (N-(j.val+1)))
    (subsetRootSumElementaryForm N k)

theorem sourceLineCoefficientPolynomial_aeval {R : Type*} [CommRing R] [Algebra ℝ R]
    (p : MvPolynomial (Fin n) ℝ) (r : Fin n → R) (m : ℕ) :
    MvPolynomial.aeval r (sourceLineCoefficientPolynomial p m)=
      (MvPolynomial.eval₂ (Polynomial.C.comp (algebraMap ℝ R))
        (fun i => Polynomial.X+Polynomial.C (r i)) p).coeff m := by
  have h := congrArg (fun Q : Polynomial R => Q.coeff m) (universalSourceLine_map p r)
  simp only [Polynomial.coeff_map] at h
  convert! h using 1

theorem sourceSubsetRootSumPolynomial_eval_of_factorization {R : Type*} [CommRing R] [Algebra ℝ R]
    (p : MvPolynomial (Fin n) ℝ) (N k : ℕ) (r : Fin n → R) (roots : Fin N → R)
    (hfactor : MvPolynomial.eval₂ (Polynomial.C.comp (algebraMap ℝ R))
      (fun i => Polynomial.X+Polynomial.C (r i)) p=∏ i : Fin N,(Polynomial.X+Polynomial.C (roots i))) :
    MvPolynomial.aeval r (sourceSubsetRootSumPolynomial p N k)=
      ∏ s∈Finset.univ.powersetCard k,∑ i∈s,roots i := by
  rw [sourceSubsetRootSumPolynomial,MvPolynomial.comp_aeval_apply]
  have hcoords (j : Fin N) : MvPolynomial.aeval r (sourceLineCoefficientPolynomial p (N-(j.val+1)))=
      ∑ s∈Finset.univ.powersetCard (j.val+1),∏ i∈s,roots i := by
    rw [sourceLineCoefficientPolynomial_aeval,hfactor]
    have h := Finset.prod_X_add_C_coeff (Finset.univ : Finset (Fin N)) roots
      (k := N-(j.val+1)) (by simp)
    have hj : N-(N-(j.val+1))=j.val+1 := by omega
    simpa only [Finset.card_univ,Fintype.card_fin,hj] using h
  simp_rw [hcoords]
  exact subsetRootSumElementaryForm_eval N k roots

end CoefficientStability
