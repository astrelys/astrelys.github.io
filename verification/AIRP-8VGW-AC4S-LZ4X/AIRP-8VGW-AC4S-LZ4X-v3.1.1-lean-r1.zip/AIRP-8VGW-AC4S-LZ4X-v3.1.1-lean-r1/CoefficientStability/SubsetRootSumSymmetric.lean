import CoefficientStability.RootPolynomialMap
import Mathlib.RingTheory.MvPolynomial.Symmetric.FundamentalTheorem

noncomputable section
open scoped BigOperators
namespace CoefficientStability

def subsetRootSumPolynomial (N k : ℕ) : MvPolynomial (Fin N) ℝ :=
  ∏ s∈Finset.univ.powersetCard k,∑ i∈s,MvPolynomial.X i

theorem subsetRootSumPolynomial_eval {R : Type*} [CommRing R] [Algebra ℝ R]
    (N k : ℕ) (r : Fin N → R) :
    MvPolynomial.aeval r (subsetRootSumPolynomial N k)=
      ∏ s∈Finset.univ.powersetCard k,∑ i∈s,r i := by
  simp [subsetRootSumPolynomial]

theorem subsetRootSumPolynomial_symmetric (N k : ℕ) :
    (subsetRootSumPolynomial N k).IsSymmetric := by
  classical
  intro e
  simp only [subsetRootSumPolynomial,map_prod,map_sum,MvPolynomial.rename_X]
  apply Finset.prod_bij (fun s hs => s.map e.toEmbedding)
  · intro s hs
    simpa only [Finset.mem_powersetCard_univ,Finset.card_map] using hs
  · intro s hs t ht heq
    exact Finset.map_injective e.toEmbedding heq
  · intro t ht
    refine ⟨t.map e.symm.toEmbedding,?_,?_⟩
    · simpa only [Finset.mem_powersetCard_univ,Finset.card_map] using ht
    · ext i
      simp
  · intro s hs
    rw [Finset.sum_map]
    rfl

def subsetRootSumElementaryForm (N k : ℕ) : MvPolynomial (Fin N) ℝ :=
  (MvPolynomial.esymmAlgEquiv (Fin N) ℝ (by simp : Fintype.card (Fin N)=N)).symm
    ⟨subsetRootSumPolynomial N k,subsetRootSumPolynomial_symmetric N k⟩

theorem subsetRootSumElementaryForm_identity (N k : ℕ) :
    MvPolynomial.aeval (fun i : Fin N => MvPolynomial.esymm (Fin N) ℝ (i.val+1))
      (subsetRootSumElementaryForm N k)=subsetRootSumPolynomial N k := by
  have h := congrArg Subtype.val ((MvPolynomial.esymmAlgEquiv (Fin N) ℝ (by simp : Fintype.card (Fin N)=N)).apply_symm_apply
    ⟨subsetRootSumPolynomial N k,subsetRootSumPolynomial_symmetric N k⟩)
  simpa only [subsetRootSumElementaryForm,MvPolynomial.esymmAlgEquiv_apply,
    MvPolynomial.esymmAlgHom_apply] using h

end CoefficientStability
