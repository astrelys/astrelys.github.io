import CoefficientStability.ComplexSourceRoots

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem sourceSubsetRootSumPolynomial_stable (p : MvPolynomial (Fin n) ℝ) (N k : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hk : 0<k) :
    UpperHalfPlaneZeroFree (sourceSubsetRootSumPolynomial p N k) := by
  classical
  intro z hz
  obtain ⟨roots,hfactor,him⟩ := actual_source_complex_root_im_pos p N hp hs hnorm z hz
  change MvPolynomial.aeval z (sourceSubsetRootSumPolynomial p N k)≠0
  rw [sourceSubsetRootSumPolynomial_eval_of_factorization p N k z roots hfactor]
  apply Finset.prod_ne_zero_iff.mpr
  intro s hs
  have hcard : s.card=k := by simpa only [Finset.mem_powersetCard_univ] using hs
  have hnonempty : s.Nonempty := Finset.card_pos.mp (by omega)
  have hpos : 0<(∑ i∈s,roots i).im := by
    simpa using
      (show 0<∑ i∈s,(roots i).im from Finset.sum_pos (fun i hi => him i) hnonempty)
  intro heq
  rw [heq,Complex.zero_im] at hpos
  exact (lt_irrefl 0) hpos

end CoefficientStability
