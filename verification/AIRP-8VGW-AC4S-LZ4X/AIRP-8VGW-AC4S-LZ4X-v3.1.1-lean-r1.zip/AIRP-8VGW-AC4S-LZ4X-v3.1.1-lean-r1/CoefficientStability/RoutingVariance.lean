import CoefficientStability.RoutingNoise
import CoefficientStability.CoefficientMean

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem coordinate_abs_le_one_of_square_sum (u : Fin n → ℝ) (hu : (∑ j,u j^2)≤1) (i : Fin n) :
    |u i|≤1 := by
  have h := (Finset.single_le_sum (fun j hj => sq_nonneg (u j)) (Finset.mem_univ i)).trans hu
  apply (sq_le_sq₀ (abs_nonneg (u i)) (by norm_num : (0 : ℝ)≤1)).mp
  simpa only [sq_abs,one_pow] using h

theorem routing_categorical_variance_lower (M : Matrix (Fin n) (Fin n) ℝ) (u v : Fin n → ℝ)
    (i : Fin n) (r : ℝ) (hr : 0≤r) (hmin : ∀ j,r≤M i j)
    (hrow : ∑ j,M i j=1) (hu : ∀ j,|u j|≤1) (hv : ∑ j,v j=0) :
    (r/8)*(∑ j,v j^2)≤categoricalVariance (routingProbability M u i) v := by
  have hM (j : Fin n) : 0≤M i j := hr.trans (hmin j)
  have hpos : 0<routingDenominator M u i :=
    (Real.exp_pos _).trans_le (routingDenominator_bounds M u i hM hrow hu).1
  exact categoricalVariance_uniform_lower _ v (r/8) (by positivity)
    (routingProbability_total M u i (ne_of_gt hpos))
    (fun j => routingProbability_uniform_lower M u i j r hr hmin hrow hu) hv

theorem conditional_routing_variance_lower (M : Matrix (Fin n) (Fin n) ℝ) (u v : Fin n → ℝ)
    (r : ℝ) (hr : 0≤r) (hmin : ∀ i j,r≤M i j) (hrow : ∀ i,∑ j,M i j=1)
    (hu : ∀ j,|u j|≤1) (hv : ∑ j,v j=0) (g : Fin n →₀ ℕ) (N : ℕ) (hg : ∑ i,g i=N) :
    ((N : ℝ)*r/8)*(∑ j,v j^2)≤
      ∑ i,(g i : ℝ)*categoricalVariance (routingProbability M u i) v := by
  have h := Finset.sum_le_sum (s := (Finset.univ : Finset (Fin n)))
    (fun i hi => mul_le_mul_of_nonneg_left
      (routing_categorical_variance_lower M u v i r hr (hmin i) (hrow i) hu hv) (Nat.cast_nonneg (g i)))
  have he : (∑ i,(g i : ℝ)*((r/8)*(∑ j,v j^2)))=((N : ℝ)*r/8)*(∑ j,v j^2) := by
    rw [← Finset.sum_mul]
    have hsum : (∑ i,(g i : ℝ))=(N : ℝ) := by exact_mod_cast hg
    rw [hsum]
    ring
  rwa [he] at h

theorem homogeneous_mixture_routing_variance_lower (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hcoeff : ∀ g,0≤p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (M : Matrix (Fin n) (Fin n) ℝ) (u v : Fin n → ℝ) (r : ℝ) (hr : 0≤r)
    (hmin : ∀ i j,r≤M i j) (hrow : ∀ i,∑ j,M i j=1)
    (hu : ∀ j,|u j|≤1) (hv : ∑ j,v j=0) :
    ((N : ℝ)*r/8)*(∑ j,v j^2)≤coefficientMean p
      (fun g => ∑ i,(g i : ℝ)*categoricalVariance (routingProbability M u i) v) := by
  have h := Finset.sum_le_sum (s := p.support) (fun g hg =>
    mul_le_mul_of_nonneg_left (conditional_routing_variance_lower M u v r hr hmin hrow hu hv
      g N (homogeneous_mass p N hp g hg)) (hcoeff g))
  have he : (∑ g∈p.support,p.coeff g*(((N : ℝ)*r/8)*(∑ j,v j^2)))=
      ((N : ℝ)*r/8)*(∑ j,v j^2) := by
    rw [← Finset.sum_mul,normalized_coefficient_mass p hnorm,one_mul]
  simpa only [he,coefficientMean_apply] using h

end CoefficientStability
