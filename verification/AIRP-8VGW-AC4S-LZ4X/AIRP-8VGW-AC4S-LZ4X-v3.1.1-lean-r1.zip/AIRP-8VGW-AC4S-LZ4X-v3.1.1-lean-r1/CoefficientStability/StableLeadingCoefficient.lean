import CoefficientStability.StableLeadingMatrix
import CoefficientStability.SquarefreePowerCoefficient
import CoefficientStability.ProductDeficitExtremal
import CoefficientStability.MatrixHessianCoercivity

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem squarefree_complement_pair (i j : Fin n) (hij : i≠j) :
    squarefreeExponent n=subsetExponent ((Finset.univ.erase i).erase j)+Finsupp.single i 1+Finsupp.single j 1 := by
  classical
  ext k
  by_cases hki : k=i
  · subst k
    simp [squarefreeExponent_value,subsetExponent_apply,Finsupp.single_apply,hij,Ne.symm hij]
  · by_cases hkj : k=j
    · subst k
      simp [squarefreeExponent_value,subsetExponent_apply,Finsupp.single_apply,hij,Ne.symm hij]
    · simp [squarefreeExponent_value,subsetExponent_apply,Finsupp.single_apply,hki,hkj]

theorem scalarLinear_power_two_variables_coefficient (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∀ i,t i≠0) (i j : Fin n) :
    (((scalarLinear t n)^(n-2)*MvPolynomial.X i)*MvPolynomial.X j).coeff (squarefreeExponent n)=
      if i=j then 0 else sourceHessianFactor t/(t i*t j) := by
  classical
  by_cases hij : i=j
  · subst j
    simp only [ite_true,MvPolynomial.coeff_mul_X']
    simp [squarefreeExponent_value,Finsupp.tsub_apply]
  · rw [if_neg hij,squarefree_complement_pair i j hij,MvPolynomial.coeff_mul_X,MvPolynomial.coeff_mul_X]
    let s := (Finset.univ.erase i).erase j
    have hji : j∈(Finset.univ : Finset (Fin n)).erase i := by simp [Ne.symm hij]
    have hs : s.card=n-2 := by
      simp only [s,Finset.card_erase_of_mem hji,Finset.card_erase_of_mem (Finset.mem_univ i),
        Finset.card_univ,Fintype.card_fin]
      omega
    have hc := scalarLinear_squarefree_coefficient t n s
    rw [hs] at hc
    change ((scalarLinear t n)^(n-2)).coeff (subsetExponent s)=_
    rw [hc,Finset.prod_div_distrib]
    simp only [Finset.prod_const,hs]
    have hpj := Finset.prod_erase_mul ((Finset.univ : Finset (Fin n)).erase i) t hji
    have hpi := Finset.prod_erase_mul (Finset.univ : Finset (Fin n)) t (Finset.mem_univ i)
    change (∏ k∈s,t k)*t j=∏ k∈Finset.univ.erase i,t k at hpj
    have hp : (∏ k∈s,t k)*t i*t j=∏ k,t k := by rw [mul_right_comm _ (t i),hpj,hpi]
    unfold sourceHessianFactor
    rw [← hp]
    have hn0 : (n : ℝ)≠0 := by exact_mod_cast (by omega : n≠0)
    field_simp [ht i,ht j]
    <;> ring

theorem paper_stable_leading_coefficient (t : Fin n → ℝ) (Q : Matrix (Fin n) (Fin n) ℝ)
    (hn : 2≤n) (ht : ∀ i,t i≠0) :
    -(((scalarLinear t n)^(n-2)*quadraticPolynomial Q).coeff (squarefreeExponent n))=
      sourceHessianFactor t*stableLeadingBracket t Q := by
  classical
  have hterm (i j : Fin n) :
      (((scalarLinear t n)^(n-2)*(C (Q i j)*MvPolynomial.X i*MvPolynomial.X j)).coeff (squarefreeExponent n))=
      sourceHessianFactor t*(Q i j*(t i)⁻¹*(t j)⁻¹-(if i=j then Q i i/(t i)^2 else 0)) := by
    have he : (scalarLinear t n)^(n-2)*(C (Q i j)*MvPolynomial.X i*MvPolynomial.X j)=
        C (Q i j)*(((scalarLinear t n)^(n-2)*MvPolynomial.X i)*MvPolynomial.X j) := by ring
    rw [he,MvPolynomial.coeff_C_mul,scalarLinear_power_two_variables_coefficient t hn ht]
    by_cases hij : i=j
    · subst j
      simp only [ite_true,mul_zero]
      field_simp
      <;> ring
    · simp only [hij,ite_false,sub_zero,div_eq_mul_inv,mul_inv_rev]
      ring
  have he : ((scalarLinear t n)^(n-2)*quadraticPolynomial Q).coeff (squarefreeExponent n)=
      sourceHessianFactor t*(matrixQuadratic Q (fun i => (t i)⁻¹)-∑ i,Q i i/(t i)^2) := by
    unfold quadraticPolynomial
    simp only [Finset.mul_sum,MvPolynomial.coeff_sum]
    simp only [hterm]
    simp only [← Finset.mul_sum,Finset.sum_sub_distrib]
    simp only [Finset.sum_ite_eq,Finset.mem_univ,ite_true]
    rfl
  rw [he]
  unfold stableLeadingBracket
  ring

theorem paper_stable_leading_gap_lower (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hn : 2≤n) (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p) (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i)
    (M : ℝ) (hM : ∀ i,t i≤M) (hl : 0<scalarHessianLambda t) :
    (sourceHessianFactor t*(scalarHessianLambda t/M^2))*referenceDeficit p t n≤
      -(((scalarLinear t n)^(n-2)*quadraticPolynomial (deficitMatrix p t n)).coeff (squarefreeExponent n)) := by
  rw [paper_stable_leading_coefficient t _ hn (fun i => ne_of_gt (htpos i))]
  have h := paper_stable_leading_bracket_coercive p t hn hp hnorm hstable ht htpos hgrad M hM hl
  have hm := mul_le_mul_of_nonneg_left h (sourceHessianFactor_pos t hn htpos).le
  simpa only [mul_assoc] using hm

end CoefficientStability
