import CoefficientStability.PolynomialLinearSubstitution

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def polynomialDirectional (v : Fin n → ℝ) :
    MvPolynomial (Fin n) ℝ →ₗ[ℝ] MvPolynomial (Fin n) ℝ :=
  ∑ j,v j • (pderiv j).toLinearMap

@[simp] theorem polynomialDirectional_apply (v : Fin n → ℝ) (p : MvPolynomial (Fin n) ℝ) :
    polynomialDirectional v p=∑ j,C (v j)*pderiv j p := by
  simp only [polynomialDirectional,LinearMap.sum_apply,LinearMap.smul_apply,smul_eq_C_mul]
  rfl

theorem polynomialDirectional_eval (v : Fin n → ℝ) (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ) :
    MvPolynomial.eval x (polynomialDirectional v p)=
      ∑ j,v j*MvPolynomial.eval x (pderiv j p) := by
  simp only [polynomialDirectional_apply,map_sum,map_mul,eval_C]

theorem polynomialDirectional_linear_substitution (M : Matrix (Fin n) (Fin n) ℝ)
    (v : Fin n → ℝ) (p : MvPolynomial (Fin n) ℝ) :
    polynomialDirectional v (matrixSubstitution M p)=
      matrixSubstitution M (polynomialDirectional (M.mulVec v) p) := by
  simp only [polynomialDirectional_apply,matrixSubstitution_partial,map_sum,map_mul,matrixSubstitution_C,Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i hi
  change (∑ j,C (v j)*(C (M i j)*matrixSubstitution M (pderiv i p)))=
      C (∑ j,M i j*v j)*matrixSubstitution M (pderiv i p)
  rw [map_sum,Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro j hj
  rw [map_mul]
  ring

theorem polynomialDirectional_second_eval (p : MvPolynomial (Fin n) ℝ) (v : Fin n → ℝ) :
    MvPolynomial.eval (fun _ => 1) (polynomialDirectional v (polynomialDirectional v p))=
      hessianQuadraticAtOne p v := by
  simp only [polynomialDirectional_apply,map_sum,pderiv_C_mul,map_mul,eval_C]
  unfold hessianQuadraticAtOne
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i hi
  try simp only [Finset.mul_sum,Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro j hj
  ring

end CoefficientStability
