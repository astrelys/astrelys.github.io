import CoefficientStability.SourceOriginalCubicKKT

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1800000

theorem source_cubic_distinct_positive_roots_sum (t c x y : ℝ)
    (hx : 2*x^2+(1-2*t)*x=c) (hy : 2*y^2+(1-2*t)*y=c) (hne : x≠y) :
    x+y=t-1/2 := by
  have he : (x-y)*(2*(x+y)+1-2*t)=0 := by linear_combination hx-hy
  have hz := (mul_eq_zero.mp he).resolve_left (sub_ne_zero.mpr hne)
  linarith

theorem source_cubic_scalar_quadratic_repeated_eigenvalue (t c : ℝ) (x : Fin 3 → ℝ)
    (hn : ∀ i,0 ≤ x i) (hs : (∑ i,x i)=t)
    (hq : ∀ i,0 < x i → 2*(x i)^2+(1-2*t)*x i=c) :
    x 0=x 1 ∨ x 0=x 2 ∨ x 1=x 2 := by
  by_cases h01 : x 0=x 1
  · exact Or.inl h01
  by_cases h02 : x 0=x 2
  · exact Or.inr (Or.inl h02)
  by_cases h12 : x 1=x 2
  · exact Or.inr (Or.inr h12)
  exfalso
  have hsum := hs
  norm_num [Fin.sum_univ_succ] at hsum
  have hp0 : 0 < x 0 := by
    by_contra hh
    have h0 : x 0=0 := by linarith [hn 0]
    have h1 : 0 < x 1 := by have h := hn 1;by_contra hle;apply h01;linarith
    have h2 : 0 < x 2 := by have h := hn 2;by_contra hle;apply h02;linarith
    have h := source_cubic_distinct_positive_roots_sum t c (x 1) (x 2) (hq 1 h1) (hq 2 h2) h12
    linarith
  have hp1 : 0 < x 1 := by
    by_contra hh
    have h1 : x 1=0 := by linarith [hn 1]
    have h2 : 0 < x 2 := by have h := hn 2;by_contra hle;apply h12;linarith
    have h := source_cubic_distinct_positive_roots_sum t c (x 0) (x 2) (hq 0 hp0) (hq 2 h2) h02
    linarith
  have hp2 : 0 < x 2 := by
    by_contra hh
    have h2 : x 2=0 := by linarith [hn 2]
    have h := source_cubic_distinct_positive_roots_sum t c (x 0) (x 1) (hq 0 hp0) (hq 1 hp1) h01
    linarith
  have ha := source_cubic_distinct_positive_roots_sum t c (x 0) (x 1) (hq 0 hp0) (hq 1 hp1) h01
  have hb := source_cubic_distinct_positive_roots_sum t c (x 0) (x 2) (hq 0 hp0) (hq 2 hp2) h02
  apply h12
  linarith

end CoefficientStability
