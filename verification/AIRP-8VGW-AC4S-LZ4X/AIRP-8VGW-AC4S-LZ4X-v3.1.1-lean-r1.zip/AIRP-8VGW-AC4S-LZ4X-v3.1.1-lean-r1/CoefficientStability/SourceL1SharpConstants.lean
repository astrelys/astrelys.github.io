import CoefficientStability.SourceL1ChartBasics

noncomputable section
namespace CoefficientStability
set_option maxHeartbeats 1200000

def sourceCubicDStar : ℝ := (Real.sqrt 37-5)/12
def sourceCubicEpsilon0 : ℝ := Real.sqrt ((236-37*Real.sqrt 37)/12)

theorem source_sqrt37_exact_bounds : (Real.sqrt 37)^2=37 ∧ (152/25 : ℝ)<Real.sqrt 37 ∧ Real.sqrt 37 < (61/10 : ℝ) := by
  have hs := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 37)
  have hn := Real.sqrt_nonneg (37 : ℝ)
  refine ⟨hs,?_,?_⟩
  · by_contra hh
    have hp := mul_nonneg (by linarith : 0 ≤ 152/25-Real.sqrt 37) (by linarith : 0 ≤ 152/25+Real.sqrt 37)
    nlinarith [hp]
  · by_contra hh
    have hp := mul_nonneg (by linarith : 0 ≤ Real.sqrt 37-61/10) (by linarith : 0 ≤ Real.sqrt 37+61/10)
    nlinarith [hp]

theorem source_cubic_dstar_bounds : 0 < sourceCubicDStar ∧ sourceCubicDStar < 1/3 := by
  obtain ⟨hs,hl,hu⟩ := source_sqrt37_exact_bounds
  unfold sourceCubicDStar
  constructor <;> linarith

theorem source_cubic_epsilon_bounds : 0 < sourceCubicEpsilon0 ∧ sourceCubicEpsilon0 < 1 := by
  obtain ⟨hs,hl,hu⟩ := source_sqrt37_exact_bounds
  have ha : 0 < (236-37*Real.sqrt 37)/12 := by linarith
  have ha1 : (236-37*Real.sqrt 37)/12 < 1 := by linarith
  have hpos : 0 < sourceCubicEpsilon0 := Real.sqrt_pos.mpr ha
  have hsq : sourceCubicEpsilon0^2=(236-37*Real.sqrt 37)/12 := Real.sq_sqrt ha.le
  exact ⟨hpos,by nlinarith [hsq]⟩

theorem source_cubic_dstar_equation : 1-10*sourceCubicDStar-12*sourceCubicDStar^2=0 := by
  have hs := source_sqrt37_exact_bounds.1
  unfold sourceCubicDStar
  nlinarith [hs]

theorem source_cubic_dstar_zero_gap : sourceCubicH sourceCubicDStar 0=0 := by
  simpa [sourceCubicH] using source_cubic_dstar_equation

theorem source_cubic_dstar_radius_square_identity :
    (3-2*sourceCubicDStar)^2*(sourceCubicDStar+3*sourceCubicDStar^2)=(236-37*Real.sqrt 37)/12 := by
  have hs := source_sqrt37_exact_bounds.1
  unfold sourceCubicDStar
  linear_combination ((1/1728) * (Real.sqrt 37)^2 + (-13/432) * (Real.sqrt 37)^1 + (847/1728)) * hs

theorem source_cubic_dstar_distance_exact : sourceCubicDistance sourceCubicDStar 0=sourceCubicEpsilon0 := by
  obtain ⟨hd,hd3⟩ := source_cubic_dstar_bounds
  have hK : 0 < 3-2*sourceCubicDStar := by linarith
  have hS : 0 < sourceCubicDStar+3*sourceCubicDStar^2 := by positivity
  have heS : sourceCubicS sourceCubicDStar 0=sourceCubicDStar+3*sourceCubicDStar^2 := by unfold sourceCubicS;ring
  have hdistpos : 0 < sourceCubicDistance sourceCubicDStar 0 := by
    unfold sourceCubicDistance
    rw [heS]
    simpa only [abs_zero,add_zero] using mul_pos hK (Real.sqrt_pos.mpr hS)
  have hdist2 : (sourceCubicDistance sourceCubicDStar 0)^2=(236-37*Real.sqrt 37)/12 := by
    unfold sourceCubicDistance
    rw [heS]
    simp only [abs_zero,add_zero,mul_pow,Real.sq_sqrt hS.le]
    exact source_cubic_dstar_radius_square_identity
  have hepspos := source_cubic_epsilon_bounds.1
  have harg : 0 ≤ (236-37*Real.sqrt 37)/12 := by
    obtain ⟨hs,hl,hu⟩ := source_sqrt37_exact_bounds
    linarith
  have heps2 : sourceCubicEpsilon0^2=(236-37*Real.sqrt 37)/12 := Real.sq_sqrt harg
  nlinarith [hdist2,heps2]

end CoefficientStability
