import CoefficientStability.RankOneDegreeReduction

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n N : ℕ}

def normalizedRankOnePolynomial (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (j : Fin n) (r : ℝ) :
    MvPolynomial (Fin n) ℝ :=
  MvPolynomial.C ((1-r)^N)⁻¹*matrixSubstitution (rankOneUnmixingMatrix n j r) p

theorem rankOne_matrix_gradient_sum (t : Fin n → ℝ) (ht : ∑ i,t i=(N : ℝ))
    (j k : Fin n) (r : ℝ) :
    (∑ i,rankOneUnmixingMatrix n j r i k*t i)=t k-(if k=j then (N : ℝ)*r else 0) := by
  classical
  by_cases hk : k=j
  · simp only [rankOneUnmixingMatrix,if_pos hk,sub_mul,Finset.sum_sub_distrib]
    simp only [ite_mul,one_mul,zero_mul,Finset.sum_ite_eq',Finset.mem_univ,ite_true]
    rw [← Finset.mul_sum,ht]
    ring
  · simp [rankOneUnmixingMatrix,hk,ite_mul,Finset.sum_ite_eq']

theorem normalizedRankOnePolynomial_gradient (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous (N+1)) (t : Fin n → ℝ)
    (ht : ∑ i,t i=(N+1 : ℕ)) (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i)
    (j k : Fin n) (r : ℝ) (hr : 1-r≠0) :
    MvPolynomial.eval (fun _ => 1) (pderiv k (normalizedRankOnePolynomial p (N+1) j r))=
      (t k-(if k=j then (N+1 : ℕ)*r else 0))/(1-r) := by
  classical
  have heval (i : Fin n) : MvPolynomial.eval (fun _ => 1-r) (pderiv i p)=(1-r)^N*t i := by
    have h := homogeneous_eval_real_scale (pderiv i p) N (homogeneous_partial p N hp i)
      (1-r) (fun _ => 1)
    simpa only [mul_one,hgrad i] using h
  simp only [normalizedRankOnePolynomial,pderiv_mul,pderiv_C,zero_mul,zero_add,map_mul,eval_C,
    matrixSubstitution_partial,map_sum,matrixSubstitution_eval,rankOneUnmixingMatrix_one,heval]
  have hsum : (∑ i,rankOneUnmixingMatrix n j r i k*((1-r)^N*t i))=
      (1-r)^N*(t k-(if k=j then (N+1 : ℕ)*r else 0)) := by
    have h := rankOne_matrix_gradient_sum t ht j k r
    rw [← h]
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i hi
    ring
  rw [hsum]
  field_simp [pow_succ,hr]
  <;> ring

end CoefficientStability
