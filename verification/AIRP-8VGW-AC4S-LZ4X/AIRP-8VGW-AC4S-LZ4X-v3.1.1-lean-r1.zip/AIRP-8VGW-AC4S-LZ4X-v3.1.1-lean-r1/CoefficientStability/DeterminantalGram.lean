import CoefficientStability.RealDeterminantHessian
import CoefficientStability.CovarianceBridge

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def centeredDeterminantMatrix (A : Fin n → ComplexSquare n) (i : Fin n) : ComplexSquare n :=
  A i-(Matrix.trace (A i)/(n : ℂ)) • (1 : ComplexSquare n)

theorem trace_centered_product (B C : ComplexSquare n) (hn : 0<n) :
    Matrix.trace ((B-(Matrix.trace B/(n : ℂ)) • 1)*(C-(Matrix.trace C/(n : ℂ)) • 1))=
      Matrix.trace (B*C)-Matrix.trace B*Matrix.trace C/(n : ℂ) := by
  have hn0 : (n : ℂ)≠0 := by exact_mod_cast (by omega : n≠0)
  simp only [sub_mul,mul_sub,Matrix.mul_smul,Matrix.smul_mul,Matrix.mul_one,Matrix.one_mul,
    Matrix.trace_sub,Matrix.trace_smul,Matrix.trace_one,Fintype.card_fin,smul_eq_mul]
  field_simp
  <;> ring

theorem hermitian_trace_im_zero (B : ComplexSquare n) (hB : B.IsHermitian) : (Matrix.trace B).im=0 := by
  have h := congrArg Complex.im (Matrix.trace_conjTranspose B)
  rw [hB] at h
  change (Matrix.trace B).im= -(Matrix.trace B).im at h
  linarith

theorem centeredDeterminantMatrix_isHermitian (A : Fin n → ComplexSquare n)
    (hA : ∀ i,(A i).IsHermitian) (i : Fin n) : (centeredDeterminantMatrix A i).IsHermitian := by
  have he : Matrix.trace (A i)=Complex.ofReal (Matrix.trace (A i)).re := by
    apply Complex.ext
    · rfl
    · exact hermitian_trace_im_zero (A i) (hA i)
  unfold centeredDeterminantMatrix
  rw [he]
  apply (hA i).sub
  apply Matrix.IsHermitian.smul (Matrix.isHermitian_one)
  change star (Complex.ofReal (Matrix.trace (A i)).re/(n : ℂ))=_
  simp

theorem paper_determinantal_deficit_gram (A : Fin n → ComplexSquare n)
    (hHerm : ∀ i,(A i).IsHermitian) (hA : ∑ i,A i=1) (hn : 0<n) (i j : Fin n) :
    deficitMatrix (realDeterminantPolynomial A) (fun k => (Matrix.trace (A k)).re) n i j=
      (Matrix.trace (centeredDeterminantMatrix A i*centeredDeterminantMatrix A j)).re/2 := by
  have htrace (k : Fin n) := hermitian_trace_im_zero (A k) (hHerm k)
  have he := congrArg Complex.re (trace_centered_product (A i) (A j) hn)
  have hn0 : (n : ℝ)≠0 := by exact_mod_cast (by omega : n≠0)
  change (Matrix.trace (centeredDeterminantMatrix A i*centeredDeterminantMatrix A j)).re=_ at he
  simp only [Complex.sub_re,Complex.div_natCast_re,Complex.mul_re,htrace,mul_zero,sub_zero] at he
  unfold deficitMatrix
  rw [realDeterminant_hessian A hHerm hA j i,he]
  rw [Matrix.trace_mul_comm (A j) (A i)]
  field_simp
  <;> ring

theorem paper_determinantal_deficit_frobenius (A : Fin n → ComplexSquare n)
    (hHerm : ∀ i,(A i).IsHermitian) (hA : ∑ i,A i=1) (hn : 0<n) :
    referenceDeficit (realDeterminantPolynomial A) (fun k => (Matrix.trace (A k)).re) n=
      (∑ i,complexFrobeniusSq (centeredDeterminantMatrix A i))/2 := by
  rw [← trace_deficitMatrix]
  change (∑ i,deficitMatrix (realDeterminantPolynomial A) (fun k => (Matrix.trace (A k)).re) n i i)=_
  simp only [paper_determinantal_deficit_gram A hHerm hA hn,
    hermitian_trace_square_frobenius _ (centeredDeterminantMatrix_isHermitian A hHerm _)]
  exact (Finset.sum_div ..).symm

theorem hermitian_trace_product_im_zero (B C : ComplexSquare n)
    (hB : B.IsHermitian) (hC : C.IsHermitian) : (Matrix.trace (B*C)).im=0 := by
  have he : star (Matrix.trace (B*C))=Matrix.trace (B*C) := by
    rw [← Matrix.trace_conjTranspose,Matrix.conjTranspose_mul,hC,hB,Matrix.trace_mul_comm]
  have hi := congrArg Complex.im he
  change -(Matrix.trace (B*C)).im=(Matrix.trace (B*C)).im at hi
  linarith

theorem centeredDeterminantMatrix_source (A : Fin n → ComplexSquare n)
    (hA : ∀ i,(A i).IsHermitian) (i : Fin n) :
    centeredDeterminantMatrix A i=
      A i-Complex.ofReal ((Matrix.trace (A i)).re/(n : ℝ)) • 1 := by
  have he : Matrix.trace (A i)=Complex.ofReal (Matrix.trace (A i)).re := by
    apply Complex.ext
    · rfl
    · exact hermitian_trace_im_zero (A i) (hA i)
  unfold centeredDeterminantMatrix
  rw [he,Complex.ofReal_div,Complex.ofReal_natCast]
  simp only [Complex.ofReal_re]

theorem paper_determinantal_deficit_gram_complex (A : Fin n → ComplexSquare n)
    (hHerm : ∀ i,(A i).IsHermitian) (hA : ∑ i,A i=1) (hn : 0<n) (i j : Fin n) :
    Complex.ofReal (deficitMatrix (realDeterminantPolynomial A) (fun k => (Matrix.trace (A k)).re) n i j)=
      Matrix.trace (centeredDeterminantMatrix A i*centeredDeterminantMatrix A j)/2 := by
  change Complex.ofReal (deficitMatrix (realDeterminantPolynomial A) (fun k => (Matrix.trace (A k)).re) n i j)=
    Matrix.trace (centeredDeterminantMatrix A i*centeredDeterminantMatrix A j)/(2 : ℕ)
  apply Complex.ext
  · simp only [Complex.ofReal_re,Complex.div_natCast_re]
    convert paper_determinantal_deficit_gram A hHerm hA hn i j using 1 <;> norm_num
  · simp only [Complex.ofReal_im,Complex.div_natCast_im,
      hermitian_trace_product_im_zero _ _ (centeredDeterminantMatrix_isHermitian A hHerm i)
        (centeredDeterminantMatrix_isHermitian A hHerm j),zero_div]

end CoefficientStability
