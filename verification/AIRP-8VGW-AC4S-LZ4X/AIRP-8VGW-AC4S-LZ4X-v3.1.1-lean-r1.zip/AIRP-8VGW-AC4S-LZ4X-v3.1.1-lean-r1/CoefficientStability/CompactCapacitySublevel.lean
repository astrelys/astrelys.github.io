import CoefficientStability.SimplexSublevelBox

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def compactCapacitySublevel (p : MvPolynomial (Fin n) ℝ) (a M : ℝ) : Set (Fin n → ℝ) :=
  (Set.Icc (fun _ => a) (fun _ => (n : ℝ)) ∩ {x | ∑ i,x i=(n : ℝ)}) ∩
    {x | MvPolynomial.eval x p≤M*(∏ i,x i)}

theorem compactCapacitySublevel_isCompact (p : MvPolynomial (Fin n) ℝ) (a M : ℝ) :
    IsCompact (compactCapacitySublevel p a M) := by
  have hsum : IsClosed {x : Fin n → ℝ | ∑ i,x i=(n : ℝ)} :=
    isClosed_eq (by fun_prop) continuous_const
  have hpoly : IsClosed {x : Fin n → ℝ | MvPolynomial.eval x p≤M*(∏ i,x i)} :=
    isClosed_le p.continuous_eval (by fun_prop)
  exact (isCompact_Icc.inter_right hsum).inter_right hpoly

theorem compactCapacitySublevel_positive (p : MvPolynomial (Fin n) ℝ)
    (a M : ℝ) (ha : 0<a) {x : Fin n → ℝ} (hx : x∈compactCapacitySublevel p a M) :
    ∀ i,0<x i := by
  intro i
  exact lt_of_lt_of_le ha (hx.1.1.1 i)

theorem compactCapacitySublevel_ratio_le (p : MvPolynomial (Fin n) ℝ)
    (a M : ℝ) (ha : 0<a) {x : Fin n → ℝ} (hx : x∈compactCapacitySublevel p a M) :
    MvPolynomial.eval x p/(∏ i,x i)≤M := by
  apply (div_le_iff₀ (Finset.prod_pos (fun i hi => compactCapacitySublevel_positive p a M ha hx i))).mpr
  simpa only [Set.mem_setOf_eq,mul_comm] using hx.2

theorem compactCapacitySublevel_ratio_continuous (p : MvPolynomial (Fin n) ℝ)
    (a M : ℝ) (ha : 0<a) :
    ContinuousOn (fun x : Fin n → ℝ => MvPolynomial.eval x p/(∏ i,x i))
      (compactCapacitySublevel p a M) := by
  apply p.continuous_eval.continuousOn.div (by fun_prop)
  intro x hx
  exact ne_of_gt (Finset.prod_pos (fun i hi => compactCapacitySublevel_positive p a M ha hx i))

theorem positive_simplex_sublevel_mem_compact (hn : 0<n) (p : MvPolynomial (Fin n) ℝ)
    (hc : ∀ g,0≤p.coeff g) (c M : ℝ) (hcpos : 0<c) (hM : 0<M)
    (hpure : ∀ i,c≤p.coeff (Finsupp.single i n))
    (x : Fin n → ℝ) (hx : ∀ i,0<x i) (hs : ∑ i,x i=(n : ℝ))
    (hsub : MvPolynomial.eval x p/(∏ i,x i)≤M) :
    x∈compactCapacitySublevel p ((c/M)/(n : ℝ)^(n-1)) M := by
  refine ⟨⟨⟨simplex_capacity_sublevel_coordinate_lower hn p hc c M hcpos hM hpure x hx hs hsub,
    fun i => simplex_coordinate_upper x (fun j => (hx j).le) hs i⟩,hs⟩,?_⟩
  have h := (div_le_iff₀ (Finset.prod_pos (fun i hi => hx i))).mp hsub
  simpa only [Set.mem_setOf_eq,mul_comm] using h

end CoefficientStability
