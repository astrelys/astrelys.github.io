import CoefficientStability.ComplexUpperBox
import CoefficientStability.CoordinateRestriction
import Mathlib.Analysis.Convex.PathConnected

noncomputable section
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem stable_partial_zero_or_stable (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (i : Fin n) :
    pderiv i p=0 ∨ UpperHalfPlaneZeroFree (pderiv i p) := by
  classical
  by_cases hq : pderiv i p=0
  · exact Or.inl hq
  right
  intro z hz
  intro hzero
  let f : (Fin n → ℂ) → ℂ := fun x =>
    MvPolynomial.eval₂ Complex.ofRealHom x (pderiv i p)/MvPolynomial.eval₂ Complex.ofRealHom x p
  have hana : AnalyticOnNhd ℂ f (upperHalfPlaneBox n) := by
    intro x hx
    exact (realMvPolynomial_complex_eval_analyticAt (pderiv i p) x).div
      (realMvPolynomial_complex_eval_analyticAt p x) (hp x hx)
  have hbound : ∀ x∈upperHalfPlaneBox n,(f x).im≤0 := by
    intro x hx
    exact stable_partial_logderiv_im_nonpos p hp x hx i
  have hfzero : f z=0 := by simp only [f,hzero,zero_div]
  have hall := analytic_lower_halfplane_zero_boundary f (upperHalfPlaneBox n)
    (upperHalfPlaneBox_open n) (upperHalfPlaneBox_convex n).isPreconnected
    hana hbound z hz hfzero
  apply hq
  apply realMvPolynomial_eq_zero_of_upper_evaluation
  intro x hx
  exact (div_eq_zero_iff.mp (hall x hx)).resolve_right (hp x hx)

end CoefficientStability
