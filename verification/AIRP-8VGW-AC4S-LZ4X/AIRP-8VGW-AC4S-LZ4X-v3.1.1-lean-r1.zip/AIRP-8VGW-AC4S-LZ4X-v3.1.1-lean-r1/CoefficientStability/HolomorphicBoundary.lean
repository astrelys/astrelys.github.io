import Mathlib.Analysis.Complex.OpenMapping

noncomputable section
open scoped Topology
namespace CoefficientStability

theorem analytic_lower_halfplane_zero_boundary
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E]
    (f : E → ℂ) (U : Set E) (hU : IsOpen U) (hpre : IsPreconnected U)
    (hf : AnalyticOnNhd ℂ f U) (hbound : ∀ z∈U,(f z).im≤0)
    (z0 : E) (hz0 : z0∈U) (hf0 : f z0=0) : ∀ z∈U,f z=0 := by
  obtain ⟨c,hc⟩ | ho := hf.is_constant_or_isOpen hpre
  · have hc0 : c=0 := (hc z0 hz0).symm.trans hf0
    intro z hz
    exact (hc z hz).trans hc0
  · have hopen : IsOpen (f '' U) := ho U Set.Subset.rfl hU
    have hzero : (0 : ℂ)∈f '' U := ⟨z0,hz0,hf0⟩
    obtain ⟨ε,hε,hball⟩ := Metric.isOpen_iff.mp hopen 0 hzero
    let w : ℂ := ((ε/2 : ℝ) : ℂ)*Complex.I
    have hw : w∈Metric.ball (0 : ℂ) ε := by
      rw [Metric.mem_ball,dist_zero_right]
      simp only [w,norm_mul,Complex.norm_I,mul_one,Complex.norm_real,Real.norm_eq_abs]
      rw [abs_of_pos (by linarith : 0<ε/2)]
      linarith
    obtain ⟨z,hz,hfz⟩ := hball hw
    have hb := hbound z hz
    rw [hfz] at hb
    have him : w.im=ε/2 := by simp [w]
    rw [him] at hb
    linarith

end CoefficientStability
