import CoefficientStability.MixedDirectionalDerivatives
import CoefficientStability.HermitianQuadraticTrace

noncomputable section
open scoped BigOperators Matrix.Norms.Elementwise
namespace CoefficientStability
variable {n : ℕ}

theorem actual_mixed_double_scalar_update (c : Fin n → ℂ)
    (B : Fin n → Matrix (Fin n) (Fin n) ℂ) (i j : Fin n) (hij : i≠j) :
    complexMixedDiscriminant
      (Function.update (Function.update (fun k => c k • (1 : Matrix (Fin n) (Fin n) ℂ)) i (c i • B i)) j (c j • B j))=
      (∏ k,c k)*complexMixedDiscriminant
        (Function.update (Function.update (fun _ : Fin n => 1) i (B i)) j (B j)) := by
  have he : Function.update (Function.update (fun k => c k • (1 : Matrix (Fin n) (Fin n) ℂ)) i (c i • B i)) j (c j • B j)=
      (fun k => c k • (Function.update (Function.update (fun _ : Fin n => (1 : Matrix (Fin n) (Fin n) ℂ)) i (B i)) j (B j) k)) := by
    funext k
    by_cases hkj : k=j
    · subst k
      simp
    · by_cases hki : k=i
      · subst k
        simp [hij]
      · simp [Function.update_of_ne hkj,Function.update_of_ne hki]
  rw [he,← actualMixedContinuous_eq,ContinuousMultilinearMap.map_smul_univ,actualMixedContinuous_eq]
  rfl

theorem actual_mixed_second_derivative_offdiagonal
    (A H : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    deriv (fun s : ℂ => deriv (fun z : ℂ => complexMixedDiscriminant (A+z • H)) s) 0=
      ∑ i,∑ j,if j=i then 0 else complexMixedDiscriminant
        (Function.update (Function.update A i (H i)) j (H j)) := by
  rw [actual_mixed_curve_second_derivative]
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro j hj
  by_cases hji : j=i
  · subst j
    simp only [Function.update_self,ite_true]
    rw [complexMixedDiscriminant_generic,← actualMixedMultilinear_eq,MultilinearMap.map_update_zero]
  · simp only [Function.update_of_ne hji,hji,ite_false]

theorem actual_scaled_mixed_second_derivative (c : Fin n → ℂ)
    (B : Fin n → Matrix (Fin n) (Fin n) ℂ) (hn : 2≤n)
    (htrace : ∀ i,Matrix.trace (B i)=0) :
    deriv (fun s : ℂ => deriv (fun z : ℂ => complexMixedDiscriminant
      ((fun i => c i • (1 : Matrix (Fin n) (Fin n) ℂ))+z • (fun i => c i • B i))) s) 0=
      -((∏ i,c i)*((n-2).factorial : ℂ)) *
        (∑ i,∑ j,if j=i then (0 : ℂ) else Matrix.trace (B i*B j)) := by
  rw [actual_mixed_second_derivative_offdiagonal]
  have he (i j : Fin n) :
      (if j=i then (0 : ℂ) else complexMixedDiscriminant
        (Function.update (Function.update (fun k => c k • (1 : Matrix (Fin n) (Fin n) ℂ)) i (c i • B i)) j (c j • B j)))=
      -((∏ k,c k)*((n-2).factorial : ℂ))*(if j=i then 0 else Matrix.trace (B i*B j)) := by
    by_cases hji : j=i
    · simp [hji]
    · simp only [hji,ite_false]
      rw [actual_mixed_double_scalar_update c B i j (Ne.symm hji),complexMixedDiscriminant_generic,
        genericMixedDiscriminant_two_arguments _ _ hn i j (Ne.symm hji),htrace i,htrace j]
      ring
  simp only [he,← Finset.mul_sum]

theorem actual_scaled_mixed_hessian_frobenius (c : Fin n → ℝ)
    (B : Fin n → Matrix (Fin n) (Fin n) ℂ) (hn : 2≤n)
    (htrace : ∀ i,Matrix.trace (B i)=0) (hB : ∀ i,(B i).IsHermitian) :
    (deriv (fun s : ℂ => deriv (fun z : ℂ => complexMixedDiscriminant
      ((fun i => (c i : ℂ) • (1 : Matrix (Fin n) (Fin n) ℂ))+z • (fun i => (c i : ℂ) • B i))) s) 0).re=
      ((∏ i,c i)*((n-2).factorial : ℝ)) *
        ((∑ i,complexFrobeniusSq (B i))-complexFrobeniusSq (∑ i,B i)) := by
  rw [actual_scaled_mixed_second_derivative (fun i => (c i : ℂ)) B hn htrace]
  have hp : (∏ i,(c i : ℂ))*((n-2).factorial : ℂ)=
      Complex.ofReal ((∏ i,c i)*((n-2).factorial : ℝ)) := by simp
  rw [hp]
  simp only [Complex.neg_re,Complex.neg_im,Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,neg_zero,zero_mul,sub_zero]
  rw [hermitian_offdiagonal_frobenius B hB]
  ring

end CoefficientStability
