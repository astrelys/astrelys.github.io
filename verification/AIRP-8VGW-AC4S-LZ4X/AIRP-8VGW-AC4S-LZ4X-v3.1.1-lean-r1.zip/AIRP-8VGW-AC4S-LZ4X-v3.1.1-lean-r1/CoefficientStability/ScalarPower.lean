import CoefficientStability.CoefficientDeficit
import Mathlib.LinearAlgebra.Matrix.Trace

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def scalarLinear (t : Fin n → ℝ) (N : ℕ) : MvPolynomial (Fin n) ℝ :=
  ∑ i, C (t i / N) * X i

def scalarPower (t : Fin n → ℝ) (N : ℕ) : MvPolynomial (Fin n) ℝ :=
  scalarLinear t N ^ N

@[simp] theorem pderiv_scalarLinear (t : Fin n → ℝ) (N : ℕ) (i : Fin n) :
    pderiv i (scalarLinear t N) = C (t i / N) := by
  classical
  simp [scalarLinear, MvPolynomial.pderiv_X, Pi.single_apply]

@[simp] theorem eval_one_scalarLinear (t : Fin n → ℝ) (N : ℕ) (hN : 0 < N)
    (ht : ∑ i, t i = N) : MvPolynomial.eval (fun _ => 1) (scalarLinear t N) = 1 := by
  have hn : (N : ℝ) ≠ 0 := by exact_mod_cast Nat.ne_zero_of_lt hN
  simp [scalarLinear, div_eq_mul_inv, ← Finset.sum_mul, ht, hn]

@[simp] theorem eval_one_scalarPower (t : Fin n → ℝ) (N : ℕ) (hN : 0 < N)
    (ht : ∑ i, t i = N) : MvPolynomial.eval (fun _ => 1) (scalarPower t N) = 1 := by
  simp [scalarPower, eval_one_scalarLinear t N hN ht]

theorem scalarLinear_homogeneous (t : Fin n → ℝ) (N : ℕ) :
    (scalarLinear t N).IsHomogeneous 1 := by
  unfold scalarLinear
  apply MvPolynomial.IsHomogeneous.sum
  intro i hi
  simpa using (MvPolynomial.isHomogeneous_C (Fin n) (t i / (N : ℝ))).mul (MvPolynomial.isHomogeneous_X (R := ℝ) i)

theorem scalarPower_homogeneous (t : Fin n → ℝ) (N : ℕ) :
    (scalarPower t N).IsHomogeneous N := by
  simpa [scalarPower] using (scalarLinear_homogeneous t N).pow N

theorem scalarPower_diagonal_hessian (t : Fin n → ℝ) (N : ℕ) (hN : 2 ≤ N)
    (ht : ∑ i, t i = N) (i : Fin n) :
    MvPolynomial.eval (fun _ => 1) (pderiv i (pderiv i (scalarPower t N))) =
      ((N : ℝ)-1) / N * t i ^ 2 := by
  have hn : (N : ℝ) ≠ 0 := by exact_mod_cast (by omega : N ≠ 0)
  simp [scalarPower, pderiv_scalarLinear,
    eval_one_scalarLinear t N (by omega) ht]
  rw [Nat.cast_sub (by omega : 1 ≤ N)]
  push_cast
  field_simp

theorem hessianTrace_scalarPower (t : Fin n → ℝ) (N : ℕ) (hN : 2 ≤ N)
    (ht : ∑ i, t i = N) :
    hessianTraceAtOne (scalarPower t N) = ((N : ℝ)-1)/N * ∑ i, t i ^ 2 := by
  simp only [hessianTraceAtOne, scalarPower_diagonal_hessian t N hN ht]
  rw [Finset.mul_sum]

def referenceDeficit (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) : ℝ :=
  (((N : ℝ)-1)/N * ∑ i, t i^2 - hessianTraceAtOne p)/2

theorem hessianTrace_sub (f g : MvPolynomial (Fin n) ℝ) :
    hessianTraceAtOne (f-g) = hessianTraceAtOne f - hessianTraceAtOne g := by
  simp [hessianTraceAtOne, map_sub, Finset.sum_sub_distrib]

theorem referenceDeficit_eq_centered_coefficientDeficit
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ)
    (hN : 2 ≤ N) (ht : ∑ i, t i = N) :
    referenceDeficit p t N = coefficientDeficit (p-scalarPower t N) := by
  rw [coefficientDeficit_eq_negative_half_trace, hessianTrace_sub,
    hessianTrace_scalarPower t N hN ht]
  unfold referenceDeficit
  ring

theorem paper_coefficient_distance_lower
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ)
    (hN : 2 ≤ N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) (ht : ∑ i, t i = N) :
    4 * referenceDeficit p t N / ((N : ℝ)*(N-1)) ≤
      coefficientL1 (p-scalarPower t N) := by
  have hf := hp.sub (scalarPower_homogeneous t N)
  have hz : MvPolynomial.eval (fun _ => 1) (p-scalarPower t N) = 0 := by
    rw [map_sub, hnorm, eval_one_scalarPower t N (by omega) ht]
    ring
  have h := four_deficit_le_degree_coefficientL1 (p-scalarPower t N) N hf hz
  rw [← referenceDeficit_eq_centered_coefficientDeficit p t N hN ht] at h
  have hNr : (2 : ℝ) ≤ N := by exact_mod_cast hN
  have hW : (0 : ℝ) < (N : ℝ)*(N-1) := mul_pos (by linarith) (by linarith)
  apply (div_le_iff₀ hW).mpr
  nlinarith [h]

def deficitMatrix (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) :
    Matrix (Fin n) (Fin n) ℝ := fun i j =>
  ((N : ℝ)-1)/(2*N) * t i * t j -
    MvPolynomial.eval (fun _ => 1) (pderiv i (pderiv j p))/2

theorem trace_deficitMatrix (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) :
    Matrix.trace (deficitMatrix p t N) = referenceDeficit p t N := by
  change (∑ i, (((N : ℝ)-1)/(2*(N : ℝ)) * t i * t i -
    MvPolynomial.eval (fun _ => 1) (pderiv i (pderiv i p))/2)) = referenceDeficit p t N
  unfold referenceDeficit hessianTraceAtOne
  simp only [Finset.sum_sub_distrib, div_eq_mul_inv]
  simp_rw [show ∀ i : Fin n, ((N : ℝ)-1) * (2*(N : ℝ))⁻¹ * t i * t i =
      (((N : ℝ)-1) * (2*(N : ℝ))⁻¹) * t i^2 by intro i; ring]
  rw [← Finset.mul_sum, ← Finset.sum_mul]
  simp only [mul_inv_rev]
  ring

theorem paper_coefficient_distance_lower_trace
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ)
    (hN : 2 ≤ N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) (ht : ∑ i, t i = N) :
    4 * Matrix.trace (deficitMatrix p t N) / ((N : ℝ)*(N-1)) ≤
      coefficientL1 (p-scalarPower t N) := by
  rw [trace_deficitMatrix]
  exact paper_coefficient_distance_lower p t N hN hp hnorm ht

end CoefficientStability
