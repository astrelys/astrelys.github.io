import CoefficientStability.ConeMatrixSubstitution

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n N : ℕ}

def rankOneUnmixingMatrix (n : ℕ) (j : Fin n) (r : ℝ) : Matrix (Fin n) (Fin n) ℝ :=
  fun i k => (if i=k then 1 else 0)-(if k=j then r else 0)

theorem rankOneUnmixingMatrix_row_sum (j : Fin n) (r : ℝ) (i : Fin n) :
    (∑ k,rankOneUnmixingMatrix n j r i k)=1-r := by
  classical
  simp [rankOneUnmixingMatrix,Finset.sum_sub_distrib]

theorem rankOneUnmixingMatrix_one (j : Fin n) (r : ℝ) :
    (rankOneUnmixingMatrix n j r).mulVec (fun _ => 1)=fun _ => 1-r := by
  funext i
  simpa [Matrix.mulVec,dotProduct] using rankOneUnmixingMatrix_row_sum j r i

theorem rankOne_source_substitution_stable (p : MvPolynomial (Fin n) ℝ) (hN : 0<N) (hn : 0<n)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (j : Fin n) (r : ℝ) (hr : r<1)
    (hboundary : (fun i => (if i=j then 1 else 0)-r)∈closure (positiveSpectralCone p N)) :
    UpperHalfPlaneZeroFree (matrixSubstitution (rankOneUnmixingMatrix n j r) p) := by
  classical
  apply cone_columns_matrixSubstitution_stable p hN hn hp hs hnorm
  · intro k
    by_cases hk : k=j
    · subst k
      simpa [rankOneUnmixingMatrix] using hboundary
    · have h := nonnegative_input_mem_spectral_closure p N hp hs hnorm
        (fun i => if i=k then 1 else 0) (by intro i;split_ifs <;> norm_num)
      simpa [rankOneUnmixingMatrix,hk] using h
  · simp only [rankOneUnmixingMatrix_row_sum]
    have hone := positive_input_mem_spectral_cone p N hp hs hnorm (fun _ => 1) (by intro i;norm_num)
    have h := source_positiveSpectralCone_smul p hp hs hnorm (fun _ => 1) hone (1-r) (by linarith)
    have heq : (1-r) • (fun _ : Fin n => (1 : ℝ))=(fun _ : Fin n => 1-r) := by
      funext i
      exact mul_one (1-r)
    rwa [heq] at h

theorem rankOne_source_substitution_at_one (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous N) (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (j : Fin n) (r : ℝ) :
    MvPolynomial.eval (fun _ => 1) (matrixSubstitution (rankOneUnmixingMatrix n j r) p)=(1-r)^N := by
  rw [matrixSubstitution_eval,rankOneUnmixingMatrix_one]
  simpa only [mul_one,hnorm,mul_one] using homogeneous_eval_real_scale p N hp (1-r) (fun _ => 1)

theorem rankOne_source_substitution_coeff_nonneg (p : MvPolynomial (Fin n) ℝ) (hN : 0<N) (hn : 0<n)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (j : Fin n) (r : ℝ) (hr : r<1)
    (hboundary : (fun i => (if i=j then 1 else 0)-r)∈closure (positiveSpectralCone p N)) :
    ∀ g,0≤(matrixSubstitution (rankOneUnmixingMatrix n j r) p).coeff g := by
  intro g
  apply homogeneous_stable_coeff_nonneg N _ (matrixSubstitution_homogeneous _ p N hp)
    (rankOne_source_substitution_stable p hN hn hp hs hnorm j r hr hboundary)
  rw [rankOne_source_substitution_at_one p hp hnorm]
  exact pow_pos (by linarith) _

end CoefficientStability
