import CoefficientStability.SourceSpectralBoundCone

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem actual_source_subset_bound_finite_combination {ι : Type*}
    (p : MvPolynomial (Fin n) ℝ) (N k : ℕ) (hp : p.IsHomogeneous N)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hk : 0<k) (hkN : k≤N) (S : Finset ι) (v : ι → Fin n → ℝ)
    (c a : ι → ℝ) (hc : ∀ i∈S,0≤c i) (roots : ι → Fin N → ℝ)
    (hfactor : ∀ i∈S,lineRestriction p (v i)=∏ j : Fin N,(Polynomial.X+Polynomial.C (roots i j)))
    (hbound : ∀ i∈S,∀ T∈Finset.univ.powersetCard k,a i≤∑ j∈T,roots i j)
    (finalRoots : Fin N → ℝ)
    (hfinal : lineRestriction p (∑ i∈S,c i • v i)=
      ∏ j : Fin N,(Polynomial.X+Polynomial.C (finalRoots j))) :
    ∀ T∈Finset.univ.powersetCard k,(∑ i∈S,c i*a i)≤∑ j∈T,finalRoots j := by
  classical
  let Q := normalizedSourceSubsetPolynomial p N k
  have hD : 0<N.choose k := Nat.choose_pos hkN
  obtain ⟨hQhom,hQstable,hQnorm⟩ := normalizedSourceSubsetPolynomial_properties p N k hp hs hnorm hk
  have hclosed : ∀ i∈S,(fun j => v i j+ -(a i/(k : ℝ)))∈closure (positiveSpectralCone Q (N.choose k)) := by
    intro i hi
    exact (actual_source_subset_bound_iff_closed_cone p N k hp hs hnorm hk hkN (v i) (roots i)
      (hfactor i hi) (a i)).mpr (hbound i hi)
  have hsumclosed : (∑ i∈S,c i • (fun j => v i j+ -(a i/(k : ℝ))))∈
      closure (positiveSpectralCone Q (N.choose k)) := by
    apply source_closedCone_finset_sum Q hD hQhom hQstable hQnorm
    intro i hi
    exact source_closedCone_nonneg_smul Q hQhom hQstable hQnorm _ (hclosed i hi) (c i) (hc i hi)
  have hvec : (∑ i∈S,c i • (fun j => v i j+ -(a i/(k : ℝ))))=
      (fun j => (∑ i∈S,c i • v i) j+ -((∑ i∈S,c i*a i)/(k : ℝ))) := by
    funext j
    simp only [Finset.sum_apply,Pi.smul_apply,smul_eq_mul,mul_add,mul_neg,← mul_div_assoc,
      Finset.sum_add_distrib,Finset.sum_neg_distrib,← Finset.sum_div]
  rw [hvec] at hsumclosed
  exact (actual_source_subset_bound_iff_closed_cone p N k hp hs hnorm hk hkN _ finalRoots hfinal _).mp hsumclosed

end CoefficientStability
