import CoefficientStability.TiltDiagonalTransport

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem exp_le_two_of_nonnegative_le_half (x : ℝ) (hx0 : 0≤x) (hx : x≤1/2) :
    Real.exp x≤2 := by
  have h := Real.exp_bound_div_one_sub_of_interval hx0 (by linarith : x<1)
  have h2 : (1 : ℝ)/(1-x)≤2 := (div_le_iff₀ (by linarith)).mpr (by linarith)
  exact h.trans h2

theorem paper_actual_small_tilt_diagonal_transport (p : MvPolynomial (Fin n) ℝ)
    (u v : Fin n → ℝ) (hn : 3≤n) (hp : p.IsHomogeneous n) (hcoeff : ∀ g,0≤p.coeff g)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p)
    (hsmall : 12*(n : ℝ)*‖v‖≤1/2) (i : Fin n) :
    |deficitMatrix (tiltedPolynomial p (u+v)) (tiltedMoment p (u+v)) n i i-
      deficitMatrix (tiltedPolynomial p u) (tiltedMoment p u) n i i|≤
      24*(n : ℝ)*‖v‖*actualTiltDeficit p u := by
  have h := paper_actual_tilt_diagonal_transport p u v hn hp hcoeff hnorm hstable i
  have hk0 : 0≤12*(n : ℝ)*‖v‖ := by positivity
  have hδ : 0≤actualTiltDeficit p u :=
    (actual_tilt_deficit_source_bounds p u (by omega) hp hcoeff hnorm hstable).2.2.1
  have he := exp_le_two_of_nonnegative_le_half _ hk0 hsmall
  have hm := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left he hk0) hδ
  exact h.trans (hm.trans_eq (by ring))

theorem small_optimizing_field_constants (hn : 3≤n) :
    12*(n : ℝ)*(1/(100*(n : ℝ)^2))≤1/2 ∧
    24*(n : ℝ)*(1/(100*(n : ℝ)^2))=6/(25*(n : ℝ)) := by
  have hn3 : (3 : ℝ)≤n := by exact_mod_cast hn
  have hn0 : (0 : ℝ)<n := by linarith
  constructor
  · apply (le_div_iff₀ (by norm_num : (0 : ℝ)<2)).mpr
    field_simp
    nlinarith [mul_nonneg (sub_nonneg.mpr hn3) (le_of_lt hn0)]
  · field_simp
    ring

end CoefficientStability
