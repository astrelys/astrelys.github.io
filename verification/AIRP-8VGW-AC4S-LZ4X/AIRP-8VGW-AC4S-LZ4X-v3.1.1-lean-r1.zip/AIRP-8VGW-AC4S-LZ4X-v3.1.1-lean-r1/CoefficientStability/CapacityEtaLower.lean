import CoefficientStability.CapacityLogQuadratic

noncomputable section
open scoped Topology
namespace CoefficientStability

def capacityEta (n : ℕ) : ℝ := capacityG (n-1)/capacityG n-1

def sourceMixingRadius (n : ℕ) : ℝ := capacityEta n/(64*(n : ℝ)^2)

def sourceNoiseStrength (n : ℕ) : ℝ := (n : ℝ)*sourceMixingRadius n/8

theorem capacityLogG_step_gap (N : ℝ) (hN : 3≤N) :
    1/(2*N^2)≤capacityLogG (N-1)-capacityLogG N := by
  let C := 1/(2*N^2)
  let f : ℝ → ℝ := fun y => capacityLogG y+C*y
  have hD (x : ℝ) (hx : x∈Set.Icc (N-1) N) :
      HasDerivAt f (Real.log (1-1/x)+1/x+C) x := by
    have hx1 : 1<x := by linarith [hx.1]
    have hlinear : HasDerivAt (fun y : ℝ => C*y) C x := by
      simpa only [id_eq,mul_one] using (hasDerivAt_id x).const_mul C
    convert! (capacityLogG_hasDerivAt x hx1).add hlinear using 1
  have hC : ContinuousOn f (Set.Icc (N-1) N) := fun x hx => (hD x hx).continuousAt.continuousWithinAt
  have hM : AntitoneOn f (Set.Icc (N-1) N) := by
    apply antitoneOn_of_hasDerivWithinAt_nonpos (convex_Icc _ _) hC
      (fun x hx => (hD x (interior_subset hx)).hasDerivWithinAt)
    intro x hx
    have hxx := interior_subset hx
    have hx1 : 1<x := by linarith [hxx.1]
    have hupper := capacityLogG_derivative_upper x hx1
    have hxp : 0<x := by linarith
    have hrec : 1/(2*N^2)≤1/(2*x^2) :=
      one_div_le_one_div_of_le (by positivity) (by nlinarith [hxx.2])
    simp only [neg_div] at hupper
    change Real.log (1-1/x)+1/x+1/(2*N^2)≤0
    linarith
  have h := hM (by constructor <;> linarith : N-1∈Set.Icc (N-1) N)
    (by constructor <;> linarith : N∈Set.Icc (N-1) N) (by linarith : N-1≤N)
  change capacityLogG N+C*N≤capacityLogG (N-1)+C*(N-1) at h
  change C≤capacityLogG (N-1)-capacityLogG N
  linarith

theorem capacityEta_exp_identity (n : ℕ) (hn : 3≤n) :
    capacityEta n=Real.exp (capacityLogG (n-1 : ℕ)-capacityLogG n)-1 := by
  rw [capacityEta,← exp_capacityLogG_nat (n-1) (by omega),← exp_capacityLogG_nat n (by omega),Real.exp_sub]

theorem capacityEta_lower (n : ℕ) (hn : 3≤n) : 1/(2*(n : ℝ)^2)≤capacityEta n := by
  have hn' : (3 : ℝ)≤n := by exact_mod_cast hn
  have hgap := capacityLogG_step_gap (n : ℝ) hn'
  have hcast : ((n-1 : ℕ) : ℝ)=(n : ℝ)-1 := by rw [Nat.cast_sub (by omega : 1≤n),Nat.cast_one]
  rw [← hcast] at hgap
  have he := Real.add_one_le_exp (capacityLogG (n-1 : ℕ)-capacityLogG n)
  rw [capacityEta_exp_identity n hn]
  linarith

theorem sourceMixingRadius_lower (n : ℕ) (hn : 3≤n) :
    1/(128*(n : ℝ)^4)≤sourceMixingRadius n := by
  have hnpos : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
  have h := div_le_div_of_nonneg_right (capacityEta_lower n hn) (by positivity : 0≤64*(n : ℝ)^2)
  have he : (1/(2*(n : ℝ)^2))/(64*(n : ℝ)^2)=1/(128*(n : ℝ)^4) := by field_simp <;> ring
  rw [he] at h
  exact h

theorem sourceNoiseStrength_lower (n : ℕ) (hn : 3≤n) :
    1/(1024*(n : ℝ)^3)≤sourceNoiseStrength n := by
  have hnpos : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
  have h := div_le_div_of_nonneg_right
    (mul_le_mul_of_nonneg_left (sourceMixingRadius_lower n hn) hnpos.le) (by norm_num : (0 : ℝ)≤8)
  have he : (n : ℝ)*(1/(128*(n : ℝ)^4))/8=1/(1024*(n : ℝ)^3) := by field_simp <;> ring
  rw [he] at h
  exact h

end CoefficientStability
