import CoefficientStability.PolarizationAverage
import Mathlib.LinearAlgebra.Multilinear.Basic

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {k : ℕ}

@[simp] theorem realSign_not (b : Bool) : realSign (!b) = -realSign b := by cases b <;> norm_num [realSign]

def flipSignCoordinate (j : Fin k) (eps : Fin k → Bool) : Fin k → Bool :=
  Function.update eps j (!(eps j))

theorem flipSignCoordinate_involutive (j : Fin k) : Function.Involutive (flipSignCoordinate j) := by
  intro eps
  funext i
  by_cases h : i=j <;> simp [flipSignCoordinate,h]

theorem sign_product_flip (j : Fin k) (eps : Fin k → Bool) :
    (∏ i,realSign (flipSignCoordinate j eps i)) = -(∏ i,realSign (eps i)) := by
  have he : (fun i => realSign (flipSignCoordinate j eps i)) =
      Function.update (fun i => realSign (eps i)) j (-realSign (eps j)) := by
    funext i
    by_cases h : i=j <;> simp [flipSignCoordinate,h]
  rw [he,Finset.prod_update_of_mem (Finset.mem_univ j)]
  have hold := Finset.prod_update_of_mem (Finset.mem_univ j) (fun i => realSign (eps i)) (realSign (eps j))
  simp only [Function.update_eq_self] at hold
  rw [hold]
  ring

def signMoment (u : Fin k → Fin k) : ℝ :=
  ∑ eps : Fin k → Bool,(∏ j,realSign (eps j))*(∏ r,realSign (eps (u r)))

theorem signMoment_zero_of_not_surjective (u : Fin k → Fin k) (hu : ¬Function.Surjective u) :
    signMoment u=0 := by
  obtain ⟨j,hj⟩ := not_forall.mp hu
  have hne (r : Fin k) : u r≠j := by
    intro h
    exact hj ⟨r,h⟩
  let F : (Fin k → Bool) → ℝ := fun eps => (∏ i,realSign (eps i))*(∏ r,realSign (eps (u r)))
  have hflip (eps : Fin k → Bool) : F (flipSignCoordinate j eps) = -F eps := by
    have he : (fun r => realSign (flipSignCoordinate j eps (u r))) =
        (fun r => realSign (eps (u r))) := by
      funext r
      simp [flipSignCoordinate,hne r]
    dsimp only [F]
    rw [sign_product_flip,he]
    ring
  have hs := Fintype.sum_bijective (flipSignCoordinate j) (flipSignCoordinate_involutive j).bijective
    F (fun eps => -F eps) (fun eps => by rw [hflip]; ring)
  simp only [Finset.sum_neg_distrib] at hs
  change (∑ eps,F eps)=0
  linarith

theorem signMoment_of_bijective (u : Fin k → Fin k) (hu : Function.Bijective u) :
    signMoment u=(2 : ℝ)^k := by
  unfold signMoment
  have hp (eps : Fin k → Bool) : (∏ r,realSign (eps (u r))) = ∏ j,realSign (eps j) :=
    Fintype.prod_bijective u hu _ _ (fun _ => rfl)
  have hs (eps : Fin k → Bool) : (∏ j,realSign (eps j))*(∏ j,realSign (eps j))=1 := by
    rw [← pow_two,← Finset.prod_pow]
    simp
  simp only [hp,hs,Finset.sum_const,Finset.card_univ,nsmul_eq_mul,mul_one]
  simp

theorem signMoment_eq (u : Fin k → Fin k) :
    signMoment u=if Function.Bijective u then (2 : ℝ)^k else 0 := by
  classical
  split_ifs with h
  · exact signMoment_of_bijective u h
  · apply signMoment_zero_of_not_surjective u
    intro hs
    exact h ((Fintype.bijective_iff_surjective_and_card u).mpr ⟨hs,rfl⟩)

end CoefficientStability
