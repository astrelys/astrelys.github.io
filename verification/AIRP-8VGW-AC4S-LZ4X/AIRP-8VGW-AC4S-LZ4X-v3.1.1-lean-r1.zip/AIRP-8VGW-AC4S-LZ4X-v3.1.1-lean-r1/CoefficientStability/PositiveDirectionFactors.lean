import CoefficientStability.DirectionalRestriction

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem positive_direction_tilt_line (p : MvPolynomial (Fin n) ℝ)
    (x v : Fin n → ℝ) (hv : ∀ i,0<v i) (hpv : MvPolynomial.eval v p≠0) :
    affineDirectionalRestriction p x v=
      Polynomial.C (MvPolynomial.eval v p)*
        lineRestriction (tiltedPolynomial p (fun i => Real.log (v i))) (fun i => x i/v i) := by
  have hExp : (fun i => Real.exp (Real.log (v i)))=v := funext (fun i => Real.exp_log (hv i))
  have hZ : tiltPartition p (fun i => Real.log (v i))=MvPolynomial.eval v p := by
    rw [tiltPartition_eval_exp_all,hExp]
  apply Polynomial.funext
  intro t
  rw [affineDirectionalRestriction_eval,Polynomial.eval_mul,Polynomial.eval_C,eval_lineRestriction_real,
    tiltedPolynomial_eval,hZ]
  have heq : (fun i => Real.exp (Real.log (v i))*(t+x i/v i))=(fun i => x i+t*v i) := by
    funext i
    rw [Real.exp_log (hv i)]
    field_simp [ne_of_gt (hv i)]
    ring
  rw [heq,mul_div_cancel₀ _ hpv]

theorem positive_direction_degree_and_top (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (x v : Fin n → ℝ) (hv : ∀ i,0<v i)
    (hpv : MvPolynomial.eval v p≠0) :
    (affineDirectionalRestriction p x v).natDegree=N ∧
      (affineDirectionalRestriction p x v).coeff N=MvPolynomial.eval v p := by
  have hZ : tiltPartition p (fun i => Real.log (v i))≠0 := by
    rw [tiltPartition_eval_exp_all]
    simpa only [Real.exp_log (hv _)] using hpv
  have hqhom := tiltedPolynomial_homogeneous p (fun i => Real.log (v i)) N hp
  have hqnorm := tiltedPolynomial_normalized p (fun i => Real.log (v i)) hZ
  rw [positive_direction_tilt_line p x v hv hpv]
  constructor
  · rw [Polynomial.natDegree_C_mul hpv]
    exact normalized_lineRestriction_natDegree _ _ N hqhom hqnorm
  · rw [Polynomial.coeff_C_mul,lineRestriction_top_coefficient _ _ N hqhom,hqnorm,mul_one]

theorem stable_positive_direction_real_factors (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p) (hc : ∀ g,0≤p.coeff g)
    (x v : Fin n → ℝ) (hv : ∀ i,0<v i) :
    ∃ roots : Multiset ℝ,roots.card=N ∧
      affineDirectionalRestriction p x v=Polynomial.C (MvPolynomial.eval v p)*
        (roots.map (fun r => Polynomial.X+Polynomial.C r)).prod := by
  have hpv : MvPolynomial.eval v p≠0 := ne_of_gt
    (nonnegative_coeff_eval_pos p (stable_polynomial_ne_zero p hs) hc v hv)
  have hExp : (fun i => Real.exp (Real.log (v i)))=v := funext (fun i => Real.exp_log (hv i))
  have hZ : tiltPartition p (fun i => Real.log (v i))≠0 := by rw [tiltPartition_eval_exp_all,hExp];exact hpv
  have hqhom := tiltedPolynomial_homogeneous p (fun i => Real.log (v i)) N hp
  have hqnorm := tiltedPolynomial_normalized p (fun i => Real.log (v i)) hZ
  have hqs := tiltedPolynomial_stable p (fun i => Real.log (v i)) hs hZ
  obtain ⟨roots,hcard,hfactor⟩ := normalized_stable_line_real_factors _ (fun i => x i/v i) N hqhom hqnorm hqs
  exact ⟨roots,hcard,(positive_direction_tilt_line p x v hv hpv).trans (congrArg (fun P => Polynomial.C (MvPolynomial.eval v p)*P) hfactor)⟩

end CoefficientStability
