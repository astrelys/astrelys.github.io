import CoefficientStability.RankOneConeSubstitution

noncomputable section
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem rankOneUnmixingMatrix_basis (j : Fin n) (r : ℝ) :
    (rankOneUnmixingMatrix n j r).mulVec (Pi.single j 1)=fun i => (if i=j then 1 else 0)-r := by
  classical
  funext i
  simp [Matrix.mulVec,dotProduct,Pi.single_apply,rankOneUnmixingMatrix]

theorem rankOne_source_degree_drop (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (j : Fin n) (r : ℝ)
    (hboundaryzero : MvPolynomial.eval (fun i => (if i=j then 1 else 0)-r) p=0) :
    (matrixSubstitution (rankOneUnmixingMatrix n j r) p).degreeOf j≤n-1 := by
  let q := matrixSubstitution (rankOneUnmixingMatrix n j r) p
  have hq : q.IsHomogeneous n := matrixSubstitution_homogeneous _ p n hp
  have hqzero : MvPolynomial.eval (Pi.single j 1) q=0 := by
    rw [matrixSubstitution_eval,rankOneUnmixingMatrix_basis]
    exact hboundaryzero
  apply homogeneous_zero_pure_degree_drop n hn q hq j
  rw [← homogeneous_eval_basis q n hq j]
  exact hqzero

theorem rankOne_source_boundary_properties (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (j : Fin n) (r : ℝ) (hr : r<1)
    (hboundary : (fun i => (if i=j then 1 else 0)-r)∈closure (positiveSpectralCone p n))
    (hboundaryzero : MvPolynomial.eval (fun i => (if i=j then 1 else 0)-r) p=0) :
    let q := matrixSubstitution (rankOneUnmixingMatrix n j r) p
    q.IsHomogeneous n ∧ UpperHalfPlaneZeroFree q ∧
      MvPolynomial.eval (fun _ => 1) q=(1-r)^n ∧
      (∀ g,0≤q.coeff g) ∧ q.degreeOf j≤n-1 := by
  exact ⟨matrixSubstitution_homogeneous _ p n hp,
    rankOne_source_substitution_stable p hn hn hp hs hnorm j r hr hboundary,
    rankOne_source_substitution_at_one p hp hnorm j r,
    rankOne_source_substitution_coeff_nonneg p hn hn hp hs hnorm j r hr hboundary,
    rankOne_source_degree_drop p hn hp j r hboundaryzero⟩

end CoefficientStability
