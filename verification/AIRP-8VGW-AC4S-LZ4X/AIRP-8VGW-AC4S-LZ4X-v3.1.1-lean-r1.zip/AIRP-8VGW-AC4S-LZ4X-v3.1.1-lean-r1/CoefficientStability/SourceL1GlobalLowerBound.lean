import CoefficientStability.SourceL1GlobalRecovery
import CoefficientStability.SourceL1SharpDistance

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1600000

theorem source_ternary_l1_coordinate_bound (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (i : Fin 3) :
    2*|t i-1| ≤ ∑ j,|t j-1| := by
  have hb (x y z : ℝ) (hs : x+y+z=0) : 2*|x| ≤ |x|+|y|+|z| := by
    have he : x=-(y+z) := by linarith
    have ha : |x| ≤ |y|+|z| := by rw [he,abs_neg];exact abs_add_le y z
    linarith
  have hs := ht
  norm_num [Fin.sum_univ_succ] at hs ⊢
  fin_cases i <;> dsimp only
  · change 2*|t 0-1| ≤ |t 0-1|+(|t 1-1|+|t 2-1|)
    have h := hb (t 0-1) (t 1-1) (t 2-1) (by linarith)
    linarith
  · change 2*|t 1-1| ≤ |t 0-1|+(|t 1-1|+|t 2-1|)
    have h := hb (t 1-1) (t 0-1) (t 2-1) (by linarith)
    linarith
  · change 2*|t 2-1| ≤ |t 0-1|+(|t 1-1|+|t 2-1|)
    have h := hb (t 2-1) (t 0-1) (t 1-1) (by linarith)
    linarith

theorem source_ternary_l1_strict_trace_box (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,|t i-1|) ≤ sourceCubicEpsilon0) : ∀ i,1/2 < t i ∧ t i < 3/2 := by
  intro i
  have hb := source_ternary_l1_coordinate_bound t ht i
  have he := source_cubic_epsilon_bounds.2
  have ha : |t i-1| < 1/2 := by linarith
  obtain ⟨hl,hu⟩ := abs_lt.mp ha
  constructor <;> linarith

theorem source_l1_chart_closed_gap (u v : ℝ) (hu : 0 < u) (hv : 0 < v) (huv : u+v < 1)
    (hr : sourceCubicDistance (sourceL1ChartD u v) (sourceL1ChartHeight u v) ≤ sourceCubicEpsilon0) :
    0 ≤ sourceCubicH (sourceL1ChartD u v) (sourceL1ChartHeight u v) := by
  by_contra hn
  have hneg := lt_of_not_ge hn
  obtain ⟨hbound,heq⟩ := source_original_l1_chart_sharp_distance u v hu hv huv hneg.le
  have he : sourceCubicDistance (sourceL1ChartD u v) (sourceL1ChartHeight u v)=sourceCubicEpsilon0 := le_antisymm hr hbound
  obtain ⟨hd,hh⟩ := heq.mp he
  rw [hd,hh,source_cubic_dstar_zero_gap] at hneg
  linarith

theorem source_l1_separated_minimum_gap (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b : ℝ)
    (hpos : ∀ q ∈ sourceSeparatedEntrySet,0 < sourceTernarySeparatedZeros t a b q.1 q.2)
    (hmin : IsMinOn Matrix.permanent (sourceTransportationPolytope t) (sourceTernarySeparatedZeros t a b))
    (hr : (∑ i,|t i-1|) ≤ sourceCubicEpsilon0) :
    sourceTernaryBaseline t ≤ Matrix.permanent (sourceTernarySeparatedZeros t a b) := by
  obtain ⟨r,c,u,v,hu,hv,huv,htc,hmc⟩ := source_l1_every_separated_minimum_recovery t ht a b hpos hmin
  have hdist : sourceCubicDistance (sourceL1ChartD u v) (sourceL1ChartHeight u v) ≤ sourceCubicEpsilon0 := by
    rw [← source_l1_chart_actual_distance u v hu hv huv,← htc,source_permuted_l1_distance]
    exact hr
  have hH := source_l1_chart_closed_gap u v hu hv huv hdist
  have hp : 0 ≤ ((1+v)/2)*((1-u)/2)/9 := by
    have hu1 := (source_l1_chart_denominator u v hu hv huv).2.1
    positivity
  have hg := source_l1_chart_actual_gap u v hu hv huv
  have hn := mul_nonneg hp hH
  rw [← hmc,← htc,source_permuted_permanent,source_permuted_ternary_baseline] at hg
  linarith

end CoefficientStability
