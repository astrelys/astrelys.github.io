import CoefficientStability.RankOneGradient

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem rankOne_gradient_perturbation_mass (hn : 1≤n) (j : Fin n) (r : ℝ) (hr : 0≤r) :
    (∑ k : Fin n,|r-(if k=j then (n : ℝ)*r else 0)|)=2*((n : ℝ)-1)*r := by
  classical
  have hnr : 1≤(n : ℝ) := by exact_mod_cast hn
  have heq (k : Fin n) : |r-(if k=j then (n : ℝ)*r else 0)|=
      r+(if k=j then ((n : ℝ)-2)*r else 0) := by
    by_cases hk : k=j
    · simp only [if_pos hk]
      rw [abs_of_nonpos (by nlinarith [mul_nonneg (sub_nonneg.mpr hnr) hr])]
      ring
    · simp [hk,abs_of_nonneg hr]
  simp_rw [heq]
  simp only [Finset.sum_add_distrib,Finset.sum_const,Finset.card_univ,Fintype.card_fin,
    nsmul_eq_mul,Finset.sum_ite_eq',Finset.mem_univ,ite_true]
  ring

theorem rankOne_normalized_gradient_distance (hn : 1≤n) (t : Fin n → ℝ) (j : Fin n)
    (r : ℝ) (hr : 0≤r) (hr1 : r<1) :
    (∑ k,|(t k-(if k=j then (n : ℝ)*r else 0))/(1-r)-1|)≤
      ((∑ k,|t k-1|)+2*((n : ℝ)-1)*r)/(1-r) := by
  have hd : 0<1-r := by linarith
  calc
    _=∑ k,|(t k-1)+(r-(if k=j then (n : ℝ)*r else 0))|/(1-r) := by
      apply Finset.sum_congr rfl
      intro k hk
      have heq : (t k-(if k=j then (n : ℝ)*r else 0))/(1-r)-1=
          ((t k-1)+(r-(if k=j then (n : ℝ)*r else 0)))/(1-r) := by
        field_simp
        <;> ring
      rw [heq,abs_div,abs_of_pos hd]
    _≤∑ k,(|t k-1|+|r-(if k=j then (n : ℝ)*r else 0)|)/(1-r) := by
      apply Finset.sum_le_sum
      intro k hk
      exact div_le_div_of_nonneg_right (abs_add_le _ _) hd.le
    _=_ := by
      rw [← Finset.sum_div,Finset.sum_add_distrib,rankOne_gradient_perturbation_mass hn j r hr]

theorem rankOne_normalized_gradient_distance_coarse (hn : 1≤n) (t : Fin n → ℝ) (j : Fin n)
    (r : ℝ) (hr : 0≤r) (hrhalf : r≤1/2) :
    (∑ k,|(t k-(if k=j then (n : ℝ)*r else 0))/(1-r)-1|)≤
      2*(∑ k,|t k-1|)+4*(n : ℝ)*r := by
  have hnr : 1≤(n : ℝ) := by exact_mod_cast hn
  have hs : 0≤∑ k,|t k-1| := Finset.sum_nonneg (fun k hk => abs_nonneg _)
  have hnum : 0≤(∑ k,|t k-1|)+2*((n : ℝ)-1)*r := by positivity
  apply (rankOne_normalized_gradient_distance hn t j r hr (by linarith)).trans
  have hratio : ((∑ k,|t k-1|)+2*((n : ℝ)-1)*r)/(1-r)≤
      2*((∑ k,|t k-1|)+2*((n : ℝ)-1)*r) := by
    apply (div_le_iff₀ (by linarith : 0<1-r)).mpr
    nlinarith [mul_nonneg hnum (show 0≤1-2*r by linarith)]
  linarith

end CoefficientStability
