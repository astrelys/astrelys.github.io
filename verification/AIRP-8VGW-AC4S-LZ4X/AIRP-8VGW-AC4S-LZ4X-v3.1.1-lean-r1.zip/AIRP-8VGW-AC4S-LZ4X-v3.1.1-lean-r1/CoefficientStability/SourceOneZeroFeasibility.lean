import CoefficientStability.SourceOneZeroLinePolynomial
import CoefficientStability.SourceTernaryColumnFace

noncomputable section
open scoped BigOperators Topology
open Filter
namespace CoefficientStability
set_option maxHeartbeats 1200000

def sourceOneZeroEntrySet : Finset (Fin 3 × Fin 3) := Finset.univ.erase (0,0)

theorem source_one_zero_marginals (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b c : ℝ) :
    (∀ i,∑ j,sourceTernaryOneZero t a b c i j=t i) ∧ ∀ j,∑ i,sourceTernaryOneZero t a b c i j=1 := by
  have hs := ht
  simp only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero] at hs
  change t 0+(t 1+t 2)=3 at hs
  constructor
  · intro i
    fin_cases i <;> norm_num [sourceTernaryOneZero,Fin.sum_univ_succ] <;> ring
  · intro j
    fin_cases j <;> norm_num [sourceTernaryOneZero,Fin.sum_univ_succ] <;> linarith

theorem source_one_zero_affine (t : Fin 3 → ℝ) (a b c u v w s : ℝ) (i j : Fin 3) :
    sourceTernaryOneZero t (a+s*u) (b+s*v) (c+s*w) i j=sourceTernaryOneZero t a b c i j+
      s*(sourceTernaryOneZero t (a+u) (b+v) (c+w) i j-sourceTernaryOneZero t a b c i j) := by
  fin_cases i <;> fin_cases j <;> norm_num [sourceTernaryOneZero] <;> ring

theorem source_one_zero_feasible_near (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b c u v w : ℝ)
    (hpos : ∀ q ∈ sourceOneZeroEntrySet,0 < sourceTernaryOneZero t a b c q.1 q.2) :
    ∃ e : ℝ,0 < e ∧ ∀ s : ℝ,|s| < e → sourceTernaryOneZero t (a+s*u) (b+s*v) (c+s*w) ∈ sourceTransportationPolytope t := by
  let base : {q // q ∈ sourceOneZeroEntrySet} → ℝ := fun q => sourceTernaryOneZero t a b c q.val.1 q.val.2
  let slope : {q // q ∈ sourceOneZeroEntrySet} → ℝ := fun q =>
    sourceTernaryOneZero t (a+u) (b+v) (c+w) q.val.1 q.val.2-sourceTernaryOneZero t a b c q.val.1 q.val.2
  obtain ⟨e,he,hnear⟩ := finite_affine_positive_near_zero base slope (fun q => hpos q.val q.property)
  refine ⟨e,he,?_⟩
  intro s hs
  obtain ⟨hrow,hcol⟩ := source_one_zero_marginals t ht (a+s*u) (b+s*v) (c+s*w)
  refine ⟨?_,hrow,hcol⟩
  intro i j
  by_cases h0 : (i,j)=(0,0)
  · have hi : i=0 := congrArg Prod.fst h0
    have hj : j=0 := congrArg Prod.snd h0
    simp [hi,hj,sourceTernaryOneZero]
  · have hq : (i,j) ∈ sourceOneZeroEntrySet := by simp [sourceOneZeroEntrySet,h0]
    have h := hnear s hs ⟨(i,j),hq⟩
    rw [source_one_zero_affine]
    exact h.le

theorem source_one_zero_curve_continuous (t : Fin 3 → ℝ) (a b c u v w : ℝ) :
    Continuous (fun s : ℝ => sourceTernaryOneZero t (a+s*u) (b+s*v) (c+s*w)) := by
  apply continuous_pi
  intro i
  apply continuous_pi
  intro j
  fin_cases i <;> fin_cases j <;> simp only [sourceTernaryOneZero,Matrix.cons_val_zero,Matrix.cons_val_succ]
  all_goals fun_prop

theorem source_local_min_curve_pullback {E : Type*} [TopologicalSpace E]
    (f : E → ℝ) (C : Set E) (p : E) (γ : ℝ → E)
    (hγ : Continuous γ) (hzero : γ 0=p)
    (hfeas : ∃ e : ℝ,0 < e ∧ ∀ s : ℝ,|s| < e → γ s ∈ C)
    (hmin : IsLocalMinOn f C p) : IsLocalMin (f ∘ γ) 0 := by
  obtain ⟨e,he,hnear⟩ := hfeas
  let J : Set ℝ := Set.Ioo (-e) e
  have hmem : J ⊆ γ ⁻¹' C := fun s hs => hnear s (abs_lt.mpr hs)
  have hz : (0 : ℝ) ∈ J := by constructor <;> linarith
  have hstart : IsLocalMinOn f C (γ 0) := by rw [hzero];exact hmin
  exact (hstart.comp_continuousOn hmem hγ.continuousOn hz).isLocalMin (isOpen_Ioo.mem_nhds hz)

theorem source_polynomial_local_min_quadratic_nonnegative (P : Polynomial ℝ)
    (hmin : IsLocalMin (fun s : ℝ => P.eval s) 0) (h1 : P.coeff 1=0) : 0 ≤ P.coeff 2 := by
  by_contra hh
  obtain ⟨e,he,hdesc⟩ := polynomial_strict_descent_of_negative_quadratic P h1 (lt_of_not_ge hh)
  change ∀ᶠ s in 𝓝 (0 : ℝ),P.eval 0 ≤ P.eval s at hmin
  obtain ⟨r,hr,hnear⟩ := Metric.eventually_nhds_iff.mp hmin
  let s := min r e/2
  have hs : 0 < s := by dsimp [s];exact div_pos (lt_min hr he) (by norm_num)
  have hsr : s < r := by have h := min_le_left r e;dsimp [s];nlinarith [lt_min hr he]
  have hse : s < e := by have h := min_le_right r e;dsimp [s];nlinarith [lt_min hr he]
  have hle := hnear (y := s) (by simpa [Real.dist_eq,abs_of_pos hs] using hsr)
  have hlt := hdesc s hs hse
  linarith

theorem source_one_zero_minimum_line_conditions (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b c : ℝ)
    (hpos : ∀ q ∈ sourceOneZeroEntrySet,0 < sourceTernaryOneZero t a b c q.1 q.2)
    (hmin : IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) (sourceTernaryOneZero t a b c)) :
    ∀ u v w : ℝ,sourceOneZeroLineLinear t a b c u v w=0 ∧ 0 ≤ sourceOneZeroLineQuadratic t a b c u v w := by
  intro u v w
  have hcont := source_one_zero_curve_continuous t a b c u v w
  have hzero : sourceTernaryOneZero t (a+0*u) (b+0*v) (c+0*w)=sourceTernaryOneZero t a b c := by simp
  have hfeas := source_one_zero_feasible_near t ht a b c u v w hpos
  have hlin := source_local_min_curve_derivative_zero Matrix.permanent (sourceTransportationPolytope t)
    (sourceTernaryOneZero t a b c) (fun s => sourceTernaryOneZero t (a+s*u) (b+s*v) (c+s*w))
    (sourceOneZeroLineLinear t a b c u v w) hcont hzero hfeas hmin
    (by simpa only [Function.comp_def] using source_one_zero_line_derivative t ht a b c u v w)
  have hloc := source_local_min_curve_pullback Matrix.permanent (sourceTransportationPolytope t)
    (sourceTernaryOneZero t a b c) (fun s => sourceTernaryOneZero t (a+s*u) (b+s*v) (c+s*w)) hcont hzero hfeas hmin
  have he : (Matrix.permanent ∘ (fun s : ℝ => sourceTernaryOneZero t (a+s*u) (b+s*v) (c+s*w)))=
      (fun s => (sourceOneZeroLinePolynomial t a b c u v w).eval s) := by
    funext s
    exact (source_one_zero_line_eval t ht a b c u v w s).symm
  rw [he] at hloc
  have hquad := source_polynomial_local_min_quadratic_nonnegative _ hloc (by rw [source_one_zero_line_coeff_one,hlin])
  rw [source_one_zero_line_coeff_two] at hquad
  exact ⟨hlin,hquad⟩

end CoefficientStability
