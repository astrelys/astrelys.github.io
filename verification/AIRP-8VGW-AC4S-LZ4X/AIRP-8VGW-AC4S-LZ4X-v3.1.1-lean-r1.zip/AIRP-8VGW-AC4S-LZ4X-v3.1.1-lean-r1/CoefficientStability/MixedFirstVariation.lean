import CoefficientStability.GeneralMixedCoefficient
import Mathlib.LinearAlgebra.Matrix.Adjugate

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ} {R : Type*} [CommRing R]

theorem det_identity_updateCol (u : Fin n → R) (j : Fin n) :
    Matrix.det (Matrix.updateCol (1 : Matrix (Fin n) (Fin n) R) j u)=u j := by
  change Matrix.cramer (1 : Matrix (Fin n) (Fin n) R) u j=u j
  rw [Matrix.cramer_one]
  rfl

theorem mixed_one_argument_column (B : Matrix (Fin n) (Fin n) R) (i : Fin n)
    (q : Equiv.Perm (Fin n)) :
    (fun r c => (Function.update (fun _ : Fin n => (1 : Matrix (Fin n) (Fin n) R)) i B) (q c) r c)=
      Matrix.updateCol 1 (q.symm i) (fun r => B r (q.symm i)) := by
  apply Matrix.ext
  intro r c
  by_cases hc : c=q.symm i
  · subst c
    simp
  · have hqi : q c≠i := by
      intro h
      apply hc
      apply q.injective
      simpa using h
    simp [Function.update_of_ne hqi,Matrix.updateCol_ne hc]

theorem genericMixedDiscriminant_one_argument [IsDomain R] [CharZero R]
    (B : Matrix (Fin n) (Fin n) R) (hn : 0<n) (i : Fin n) :
    genericMixedDiscriminant (Function.update (fun _ : Fin n => 1) i B)=
      ((n-1).factorial : R)*Matrix.trace B := by
  rw [genericMixedDiscriminant_eq_rowDetSum]
  simp only [mixed_one_argument_column,det_identity_updateCol]
  have he : (∑ q : Equiv.Perm (Fin n),B (q.symm i) (q.symm i))=
      ∑ q : Equiv.Perm (Fin n),B (q i) (q i) := by
    exact Fintype.sum_equiv (Equiv.inv (Equiv.Perm (Fin n))) _ _ (fun q => rfl)
  rw [he,permutation_coordinate_sum (fun j => B j j) hn i]
  rfl

end CoefficientStability
