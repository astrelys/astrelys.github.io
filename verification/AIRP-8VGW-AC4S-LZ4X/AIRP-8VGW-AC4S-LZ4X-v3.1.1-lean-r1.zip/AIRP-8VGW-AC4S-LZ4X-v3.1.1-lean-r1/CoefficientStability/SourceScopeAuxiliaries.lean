import CoefficientStability.CapacityEtaUpper
import CoefficientStability.GeneralMixedCoefficient

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000

theorem source_full_mixed_identity_normalization {R : Type*} [CommRing R] (n : ℕ) :
    genericMixedDiscriminant (fun _ : Fin n => (1 : Matrix (Fin n) (Fin n) R))=(n.factorial : R) := by
  rw [genericMixedDiscriminant_eq_rowDetSum]
  change (∑ _q : Equiv.Perm (Fin n),Matrix.det (1 : Matrix (Fin n) (Fin n) R))=(n.factorial : R)
  simp [Fintype.card_perm]

theorem source_capacity_degree_factor_lower_exp (n : ℕ) (hn : 2≤n) :
    Real.exp (-1)≤capacityG n := by
  calc
    Real.exp (-1)≤Real.exp (capacityLogG n) :=
      Real.exp_le_exp.mpr (capacityLogG_lower _ (by exact_mod_cast (by omega : 1<n)))
    _=capacityG n := exp_capacityLogG_nat n hn

theorem source_capacity_degree_factor_literal_bounds (n : ℕ) (hn : 2≤n) :
    Real.exp (-1)≤capacityG n ∧ capacityG n≤1/2 := by
  refine ⟨source_capacity_degree_factor_lower_exp n hn,?_⟩
  have h := capacityG_antitone hn
  have he : capacityG 2=(1/2 : ℝ) := by norm_num [capacityG]
  rwa [he] at h

end CoefficientStability
