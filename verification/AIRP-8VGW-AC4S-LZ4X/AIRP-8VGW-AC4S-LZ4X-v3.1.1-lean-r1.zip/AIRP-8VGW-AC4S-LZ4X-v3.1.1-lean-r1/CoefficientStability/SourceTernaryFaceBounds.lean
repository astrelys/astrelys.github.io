import CoefficientStability.SourceSeparatedFaceMinimum

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1200000

theorem source_ternary_trace_coordinate_radius (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (i : Fin 3) :
    (3/2)*(t i-1)^2 ≤ ∑ j,(t j-1)^2 := by
  have hs := ht
  simp only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero] at hs
  change t 0+(t 1+t 2)=3 at hs
  have ht2 : t 2=3-t 0-t 1 := by linarith
  fin_cases i <;> norm_num [Fin.sum_univ_succ,ht2] <;>
    nlinarith [sq_nonneg (t 0-t 1),sq_nonneg (2*t 0+t 1-3),sq_nonneg (t 0+2*t 1-3)]

theorem source_ternary_euclidean_trace_box (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,(t i-1)^2) ≤ 3/8) : ∀ i,1/2 ≤ t i ∧ t i ≤ 3/2 := by
  intro i
  have h := (source_ternary_trace_coordinate_radius t ht i).trans hr
  constructor <;> nlinarith [sq_nonneg (t i-1)]

theorem source_ternary_row_endpoint_gap (u v w : ℝ) (hs : u+v+w=3)
    (hu : 1/2 ≤ u) (hv : 1/2 ≤ v) (hv3 : v ≤ 3/2) :
    1/144 ≤ u/2*v*(2-v)-2*u*v*w/9 := by
  have hf : 1/2 ≤ 18-9*v-4*w := by linarith
  have hp : 1/4 ≤ u*v := by nlinarith [mul_nonneg (sub_nonneg.mpr hu) (sub_nonneg.mpr hv)]
  calc
    1/144=(1/4)/18*(1/2) := by norm_num
    _ ≤ (u*v)/18*(1/2) := mul_le_mul_of_nonneg_right (div_le_div_of_nonneg_right hp (by norm_num)) (by norm_num)
    _ ≤ (u*v)/18*(18-9*v-4*w) := mul_le_mul_of_nonneg_left hf (by positivity)
    _ = _ := by ring

def sourceTernaryDoubleRowZero (t : Fin 3 → ℝ) (r x : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  ![![0,0,t 0],![x,r-x,t 1-r],![1-x,1-r+x,t 2-2+r]]

theorem source_ternary_double_row_formula (t : Fin 3 → ℝ) (r x : ℝ) :
    Matrix.permanent (sourceTernaryDoubleRowZero t r x)=t 0*(2*(x-r/2)^2+r*(2-r)/2) := by
  rw [source_permanent_three]
  norm_num [sourceTernaryDoubleRowZero]
  ring

theorem source_ternary_double_row_strict_bound (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hbox : ∀ i,1/2 ≤ t i ∧ t i ≤ 3/2) (r x : ℝ)
    (hB : ∀ i j,0 ≤ sourceTernaryDoubleRowZero t r x i j) :
    1/144 ≤ Matrix.permanent (sourceTernaryDoubleRowZero t r x)-sourceTernaryBaseline t := by
  have hs := ht
  simp only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero] at hs
  change t 0+(t 1+t 2)=3 at hs
  have hrL : 2-t 2 ≤ r := by have h := hB 2 2;norm_num [sourceTernaryDoubleRowZero] at h;linarith
  have hrU : r ≤ t 1 := by have h := hB 1 2;norm_num [sourceTernaryDoubleRowZero] at h;linarith
  have hu : 0 ≤ t 0 := by linarith [(hbox 0).1]
  have hsq := mul_nonneg hu (sq_nonneg (x-r/2))
  rw [source_ternary_double_row_formula]
  unfold sourceTernaryBaseline
  by_cases hr : r ≤ 1
  · have hfac := mul_nonneg (by linarith : 0 ≤ r-(2-t 2)) (by linarith : 0 ≤ t 2-r)
    have hf : t 2*(2-t 2) ≤ r*(2-r) := by nlinarith [hfac]
    have hm := mul_le_mul_of_nonneg_left hf hu
    have hg := source_ternary_row_endpoint_gap (t 0) (t 2) (t 1) (by linarith) (hbox 0).1 (hbox 2).1 (hbox 2).2
    nlinarith [hsq]
  · have hfac := mul_nonneg (by linarith : 0 ≤ t 1-r) (by linarith : 0 ≤ t 1+r-2)
    have hf : t 1*(2-t 1) ≤ r*(2-r) := by nlinarith [hfac]
    have hm := mul_le_mul_of_nonneg_left hf hu
    have hg := source_ternary_row_endpoint_gap (t 0) (t 1) (t 2) (by linarith) (hbox 0).1 (hbox 1).1 (hbox 1).2
    nlinarith [hsq]

theorem source_ternary_matching_nonnegative_gap (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hbox : ∀ i,t i ≤ 3/2) (x : ℝ) :
    sourceTernaryBaseline t ≤ Matrix.permanent (sourceTernaryMatchingZeros t x) := by
  have hprod : 0 ≤ ∏ i,(3-2*t i) := Finset.prod_nonneg (fun i _ => by linarith [hbox i])
  have hgap := source_ternary_matching_gap t ht x
  nlinarith [sq_nonneg (x-(1/2+(t 0-t 2)/3))]

end CoefficientStability
