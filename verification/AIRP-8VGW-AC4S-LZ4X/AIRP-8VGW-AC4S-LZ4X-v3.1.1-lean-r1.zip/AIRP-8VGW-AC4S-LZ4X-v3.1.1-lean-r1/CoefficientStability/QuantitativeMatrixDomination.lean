import CoefficientStability.UniformMassAugmentation
import Mathlib.Data.Finset.Max

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem exists_uniform_submatrix_mass_lower (A : Matrix (Fin n) (Fin n) ℝ)
    (hA : ∀ i j,0≤A i j) (hrow : ∀ i,∑ j,A i j=1) (i0 : Fin n) :
    ∃ B∈uniformSubmatrixSet A i0,1-matrixColumnImbalance A 1/2≤matrixRowMass B i0 := by
  classical
  letI : Nonempty (Fin n) := ⟨i0⟩
  obtain ⟨B,hB,hmax⟩ := exists_maximal_uniform_submatrix A hA i0
  refine ⟨B,hB,?_⟩
  by_contra hbad
  let γ := matrixRowMass B i0
  have hbad' : γ<1-matrixColumnImbalance A 1/2 := lt_of_not_ge hbad
  have hprop := uniformSubmatrix_properties A B i0 hB
  have hδ : 0≤matrixColumnImbalance A 1 := Finset.sum_nonneg (fun j hj => abs_nonneg _)
  have hc : 0<1-γ := by linarith
  let R := A-B
  have hR : ∀ i j,0≤R i j := fun i j => sub_nonneg.mpr (hprop.2.1 i j)
  have hRrow : ∀ i,∑ j,R i j=1-γ := by
    intro i
    simp only [R,Matrix.sub_apply,Finset.sum_sub_distrib,hrow,hprop.2.2.1,γ]
  have hRimb : matrixColumnImbalance R (1-γ)<2*(1-γ) := by
    rw [residual_matrix_imbalance A B γ hprop.2.2.2]
    linarith
  obtain ⟨e,he⟩ := matrix_row_mass_support_permutation R (1-γ) hc hR hRrow hRimb
  obtain ⟨imin,himin,hmin⟩ := Finset.exists_min_image Finset.univ (fun i => R i (e i)) Finset.univ_nonempty
  let ε := R imin (e imin)
  have hε : 0<ε := he imin
  have hεle (i : Fin n) : ε≤R i (e i) := hmin i (Finset.mem_univ i)
  let C := B+permutationMassMatrix e ε
  have hC : ∀ i j,0≤C i j := by
    intro i j
    exact add_nonneg (hprop.1 i j) (permutationMassMatrix_nonneg e ε hε.le i j)
  have hCA : ∀ i j,C i j≤A i j := by
    intro i j
    change B i j+(if j=e i then ε else 0)≤A i j
    by_cases hji : j=e i
    · subst j
      simp only [ite_true]
      have h := hεle i
      change ε≤A i (e i)-B i (e i) at h
      linarith
    · simp only [hji,ite_false,add_zero]
      exact hprop.2.1 i j
  have hCmass := uniform_permutation_mass_rows_cols B γ ε hprop.2.2.1 hprop.2.2.2 e
  have hCmem : C∈uniformSubmatrixSet A i0 :=
    uniformSubmatrix_mem_of_common_mass A C i0 (γ+ε) hC hCA hCmass.1 hCmass.2
  have h := hmax C hCmem
  change (∑ j,C i0 j)≤γ at h
  rw [hCmass.1 i0] at h
  linarith

end CoefficientStability
