import CoefficientStability.SourceCubicBlockPositivity

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 2400000
set_option backward.isDefEq.respectTransparency false

@[simp] theorem source_two_trace_quadratic_zero : sourceTwoTraceQuadratic (0 : Matrix (Fin 2) (Fin 2) ℂ)=0 := by simp [sourceTwoTraceQuadratic]
@[simp] theorem source_two_trace_pair_zero_left (V : Matrix (Fin 2) (Fin 2) ℂ) : sourceTwoTracePair 0 V=0 := by simp [sourceTwoTracePair]
@[simp] theorem source_two_trace_pair_zero_right (V : Matrix (Fin 2) (Fin 2) ℂ) : sourceTwoTracePair V 0=0 := by simp [sourceTwoTracePair]

theorem source_two_trace_pair_add_left (V W K : Matrix (Fin 2) (Fin 2) ℂ) :
    sourceTwoTracePair (V+W) K=sourceTwoTracePair V K+sourceTwoTracePair W K := by
  simp only [sourceTwoTracePair,add_mul,Matrix.trace_add,Complex.add_re]
  ring

theorem source_two_trace_pair_sub_left (V W K : Matrix (Fin 2) (Fin 2) ℂ) :
    sourceTwoTracePair (V-W) K=sourceTwoTracePair V K-sourceTwoTracePair W K := by
  simp only [sourceTwoTracePair,sub_mul,Matrix.trace_sub,Complex.sub_re]
  ring

theorem source_two_trace_pair_smul_left (r : ℝ) (V K : Matrix (Fin 2) (Fin 2) ℂ) :
    sourceTwoTracePair (r • V) K=r*sourceTwoTracePair V K := by
  simp [sourceTwoTracePair,smul_mul_assoc,Matrix.trace_smul] <;> ring

theorem source_two_trace_pair_sum_left (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (K : Matrix (Fin 2) (Fin 2) ℂ) :
    sourceTwoTracePair (∑ i,V i) K=∑ i,sourceTwoTracePair (V i) K := by
  simp only [sourceTwoTracePair,Matrix.sum_mul,Matrix.trace_sum,Complex.re_sum,Finset.sum_div]

theorem source_two_trace_pair_self (V : Matrix (Fin 2) (Fin 2) ℂ) :
    sourceTwoTracePair V V=sourceTwoTraceQuadratic V := rfl

theorem source_two_trace_quadratic_smul (r : ℝ) (V : Matrix (Fin 2) (Fin 2) ℂ) :
    sourceTwoTraceQuadratic (r • V)=r^2*sourceTwoTraceQuadratic V := by
  have h := source_two_trace_quadratic_affine (0 : Matrix (Fin 2) (Fin 2) ℂ) V r
  simpa only [zero_add,source_two_trace_quadratic_zero,source_two_trace_pair_zero_left,mul_zero,add_zero] using h

theorem source_two_trace_quadratic_add (V W : Matrix (Fin 2) (Fin 2) ℂ) :
    sourceTwoTraceQuadratic (V+W)=sourceTwoTraceQuadratic V+2*sourceTwoTracePair V W+sourceTwoTraceQuadratic W := by
  simpa using source_two_trace_quadratic_affine V W 1

theorem source_two_trace_quadratic_orthogonal_affine (V W : Matrix (Fin 2) (Fin 2) ℂ)
    (hp : sourceTwoTracePair V W=0) (s : ℝ) :
    sourceTwoTraceQuadratic (V+s • W)=sourceTwoTraceQuadratic V+s^2*sourceTwoTraceQuadratic W := by
  rw [source_two_trace_quadratic_affine,hp,mul_zero,add_zero]

end CoefficientStability
