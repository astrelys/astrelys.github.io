import CoefficientStability.RealCoordinateRestriction
import CoefficientStability.HomogeneousLine

noncomputable section
open scoped BigOperators
namespace CoefficientStability

theorem real_multiset_fin_enumeration (s : Multiset ℝ) :
    ∃ f : Fin s.card → ℝ,(List.ofFn f : Multiset ℝ)=s := by
  let L := s.toList
  have hlen : L.length=s.card := Multiset.length_toList s
  refine ⟨fun i => L.get (Fin.cast hlen.symm i),?_⟩
  rw [← List.ofFn_congr hlen L.get,List.ofFn_get]
  simp only [L,Multiset.coe_toList]

theorem positive_split_nonnegative_multiset_factors (P : Polynomial ℝ) (hs : P.Splits)
    (hp : ∀ x : ℝ,0<x → 0<P.eval x) :
    ∃ roots : Multiset ℝ,roots.card=P.natDegree ∧ (∀ r∈roots,0≤r) ∧
      0<P.leadingCoeff ∧
      P=Polynomial.C P.leadingCoeff*(roots.map (fun r => Polynomial.X+Polynomial.C r)).prod := by
  obtain ⟨roots,hfactor⟩ := Polynomial.splits_iff_exists_multiset'.mp hs
  have hne : P≠0 := by intro h; have hh := hp 1 (by norm_num); simp [h] at hh
  have hnonneg : ∀ r∈roots,0≤r := by
    intro r hr
    by_contra hn
    have hrneg : r<0 := lt_of_not_ge hn
    have hzero : P.eval (-r)=0 := by
      rw [hfactor,Polynomial.eval_mul,Polynomial.eval_C]
      apply mul_eq_zero_of_right
      rw [Polynomial.eval_multiset_prod]
      apply Multiset.prod_eq_zero_iff.mpr
      apply Multiset.mem_map.mpr
      refine ⟨Polynomial.X+Polynomial.C r,?_,?_⟩
      · exact Multiset.mem_map.mpr ⟨r,hr,rfl⟩
      · simp
    have hh := hp (-r) (neg_pos.mpr hrneg)
    linarith
  have hcard : roots.card=P.natDegree := by
    rw [hfactor,Polynomial.natDegree_C_mul (Polynomial.leadingCoeff_ne_zero.mpr hne),real_linear_product_natDegree]
  have hprod : 0<((roots.map (fun r => Polynomial.X+Polynomial.C r)).prod).eval 1 := by
    rw [Polynomial.eval_multiset_prod]
    apply Multiset.prod_pos
    intro q hq
    obtain ⟨f,hf,rfl⟩ := Multiset.mem_map.mp hq
    obtain ⟨r,hr,rfl⟩ := Multiset.mem_map.mp hf
    simp only [Polynomial.eval_add,Polynomial.eval_X,Polynomial.eval_C]
    linarith [hnonneg r hr]
  have hleading : 0<P.leadingCoeff := by
    have hh := hp 1 (by norm_num)
    rw [hfactor,Polynomial.eval_mul,Polynomial.eval_C] at hh
    exact pos_of_mul_pos_left hh hprod.le
  exact ⟨roots,hcard,hnonneg,hleading,hfactor⟩

theorem positive_constant_split_positive_multiset_factors (P : Polynomial ℝ) (hs : P.Splits)
    (hp : ∀ x : ℝ,0<x → 0<P.eval x) (hzero : 0<P.eval 0) :
    ∃ roots : Multiset ℝ,roots.card=P.natDegree ∧ (∀ r∈roots,0<r) ∧
      0<P.leadingCoeff ∧
      P=Polynomial.C P.leadingCoeff*(roots.map (fun r => Polynomial.X+Polynomial.C r)).prod := by
  obtain ⟨roots,hcard,hnonneg,hleading,hfactor⟩ := positive_split_nonnegative_multiset_factors P hs hp
  refine ⟨roots,hcard,?_,hleading,hfactor⟩
  intro r hr
  have hne : r≠0 := by
    intro hz
    have hprod : ((roots.map (fun r => Polynomial.X+Polynomial.C r)).prod).eval 0=0 := by
      rw [Polynomial.eval_multiset_prod]
      apply Multiset.prod_eq_zero_iff.mpr
      apply Multiset.mem_map.mpr
      refine ⟨Polynomial.X+Polynomial.C r,?_,?_⟩
      · exact Multiset.mem_map.mpr ⟨r,hr,rfl⟩
      · simp [hz]
    rw [hfactor,Polynomial.eval_mul,Polynomial.eval_C,hprod,mul_zero] at hzero
    exact (lt_irrefl 0) hzero
  exact lt_of_le_of_ne (hnonneg r hr) (Ne.symm hne)

end CoefficientStability
