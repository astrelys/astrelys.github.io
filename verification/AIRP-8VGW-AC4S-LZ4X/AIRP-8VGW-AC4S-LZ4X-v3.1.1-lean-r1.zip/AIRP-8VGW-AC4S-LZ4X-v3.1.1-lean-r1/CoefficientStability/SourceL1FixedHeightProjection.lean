import CoefficientStability.SourceL1CurveMinimum

noncomputable section
open scoped Topology
namespace CoefficientStability
set_option maxHeartbeats 1600000

def sourceCubicT (d h : ℝ) := 3+12*d-24*d^2-12*h+24*d*h-4*h^2

theorem source_cubic_H_root_factor (d h : ℝ) (hd : 0 ≤ d) (hd3 : d ≤ 1/3) :
    sourceCubicH d h=(h-sourceCubicLowerRoot d)*
      (sourceCubicHSlope d-4*(2-d)*(h+sourceCubicLowerRoot d)) := by
  have hr := source_cubic_lower_root_zero d hd hd3
  unfold sourceCubicH sourceCubicHSlope at *
  linear_combination hr

theorem source_cubic_nonpositive_gap_below_root (d h : ℝ) (hd : 0 < d) (hd3 : d < 1/3)
    (hh : h < 1/2) (hH : sourceCubicH d h ≤ 0) : h ≤ sourceCubicLowerRoot d := by
  have hu := source_cubic_lower_root_upper_bound d hd.le hd3.le
  have hrhalf : sourceCubicLowerRoot d < 1/2 := by linarith
  have hhalf : 0 < sourceCubicH d (1/2) := by
    rw [source_cubic_H_half_identity]
    have hm : 0 < 1-3*d := by linarith
    positivity
  have hehalf := source_cubic_H_root_factor d (1/2) hd.le hd3.le
  have hFhalf : 0 < sourceCubicHSlope d-4*(2-d)*((1/2)+sourceCubicLowerRoot d) := by
    by_contra hn
    have hm := mul_nonpos_of_nonneg_of_nonpos (by linarith : 0 ≤ 1/2-sourceCubicLowerRoot d) (le_of_not_gt hn)
    rw [← hehalf] at hm
    linarith
  have hF : 0 < sourceCubicHSlope d-4*(2-d)*(h+sourceCubicLowerRoot d) := by
    have hm := mul_nonneg (by linarith : 0 ≤ 4*(2-d)) (by linarith : 0 ≤ 1/2-h)
    nlinarith
  have he := source_cubic_H_root_factor d h hd.le hd3.le
  by_contra hn
  have hp := mul_pos (by linarith : 0 < h-sourceCubicLowerRoot d) hF
  rw [← he] at hp
  linarith

theorem source_cubic_distance_fixed_height_hasDerivAt (d h : ℝ) (hd : 0 < d) (hd1 : d < 1) :
    HasDerivAt (fun x => sourceCubicDistance x h)
      (-2*Real.sqrt (sourceCubicS d h)+(3-2*d)*sourceCubicSd d h/(2*Real.sqrt (sourceCubicS d h))) d := by
  have hS : HasDerivAt (fun x => sourceCubicS x h) (sourceCubicSd d h) d := by
    simpa only [mul_zero,add_zero] using source_cubic_S_curve_hasDerivAt (fun _ => h) 0 d (hasDerivAt_const d h)
  have hpos := source_cubic_S_positive d h hd hd1
  have hK := (hasDerivAt_const d (3 : ℝ)).sub ((hasDerivAt_id d).const_mul 2)
  have he := (hK.mul (hS.sqrt (ne_of_gt hpos))).add (hasDerivAt_const d |h|)
  convert he using 1 <;> first
    | (funext x;dsimp [sourceCubicDistance] <;> ring)
    | (dsimp <;> ring)

theorem source_cubic_distance_fixed_height_derivative_scaled (d h : ℝ) (hd : 0 < d) (hd1 : d < 1) :
    2*Real.sqrt (sourceCubicS d h)*deriv (fun x => sourceCubicDistance x h) d=sourceCubicT d h := by
  let s := Real.sqrt (sourceCubicS d h)
  have hspos : 0 < s := Real.sqrt_pos.mpr (source_cubic_S_positive d h hd hd1)
  have hs : s^2=sourceCubicS d h := Real.sq_sqrt (source_cubic_S_positive d h hd hd1).le
  have hv := (source_cubic_distance_fixed_height_hasDerivAt d h hd hd1).deriv
  change deriv (fun x => sourceCubicDistance x h) d= -2*s+(3-2*d)*sourceCubicSd d h/(2*s) at hv
  change 2*s*deriv (fun x => sourceCubicDistance x h) d=sourceCubicT d h
  rw [hv]
  calc
    _ = -4*s^2+(3-2*d)*sourceCubicSd d h := by field_simp [ne_of_gt hspos] <;> ring
    _ = _ := by rw [hs];unfold sourceCubicT sourceCubicSd sourceCubicS;ring

theorem source_cubic_T_strip_positive (d h : ℝ) (hd : 0 < d) (hd3 : d < 1/3)
    (hl : -1/2 ≤ h) (hu : h ≤ 3*d/2) : 0 < sourceCubicT d h := by
  have hfac := mul_nonneg (by linarith : 0 ≤ 3*d/2-h) (by linarith : 0 ≤ 12-18*d+4*h)
  have hp : 0 < 3*(1-d)^2 := mul_pos (by norm_num) (sq_pos_of_pos (by linarith))
  unfold sourceCubicT
  nlinarith

theorem source_cubic_distance_fixed_height_derivative_positive (d h : ℝ) (hd : 0 < d) (hd3 : d < 1/3)
    (hl : -1/2 ≤ h) (hu : h ≤ 3*d/2) : 0 < deriv (fun x => sourceCubicDistance x h) d := by
  have he := source_cubic_distance_fixed_height_derivative_scaled d h hd (by linarith)
  have hT := source_cubic_T_strip_positive d h hd hd3 hl hu
  have hspos := Real.sqrt_pos.mpr (source_cubic_S_positive d h hd (by linarith))
  by_contra hh
  have hm := mul_nonpos_of_nonneg_of_nonpos (by positivity : 0 ≤ 2*Real.sqrt (sourceCubicS d h)) (le_of_not_gt hh)
  linarith

theorem source_cubic_distance_fixed_height_strictMonoOn (a b h : ℝ) (ha : 0 ≤ a) (hb : b < 1/3)
    (hl : -1/2 ≤ h) (hh : h ≤ 3*a/2) : StrictMonoOn (fun x => sourceCubicDistance x h) (Set.Icc a b) := by
  have hc : Continuous (fun x : ℝ => sourceCubicDistance x h) := by unfold sourceCubicDistance sourceCubicS;fun_prop
  apply strictMonoOn_of_deriv_pos (convex_Icc a b) hc.continuousOn
  intro x hx
  have hi : x ∈ Set.Ioo a b := by simpa only [interior_Icc] using hx
  obtain ⟨hax,hxb⟩ := hi
  exact source_cubic_distance_fixed_height_derivative_positive x h (by linarith) (by linarith) hl (by linarith)

theorem source_cubic_distance_zero_parameter (h : ℝ) : sourceCubicDistance 0 h=4*|h| := by
  norm_num [sourceCubicDistance,sourceCubicS,Real.sqrt_sq_eq_abs] <;> ring

theorem source_cubic_small_distance_height_lower (d h : ℝ) (hd : 0 < d) (hd3 : d < 1/3)
    (hl : -1/2 ≤ h) (hE : sourceCubicDistance d h < 1) : -1/4 < h := by
  by_contra hh
  have hm := source_cubic_distance_fixed_height_strictMonoOn 0 d h (le_rfl) hd3 hl (by linarith)
    ⟨le_rfl,hd.le⟩ ⟨hd.le,le_rfl⟩ hd
  change sourceCubicDistance 0 h < sourceCubicDistance d h at hm
  rw [source_cubic_distance_zero_parameter,abs_of_nonpos (by linarith : h ≤ 0)] at hm
  linarith

end CoefficientStability
