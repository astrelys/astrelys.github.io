import CoefficientStability.SourcePermanentBridge

noncomputable section
open scoped BigOperators Topology
open Filter
namespace CoefficientStability
variable {n : ℕ}

def sourcePermanentBoundaryCurve (t : Fin n → ℝ) (s : ℝ) : Matrix (Fin n) (Fin n) ℝ :=
  fun i j => boundaryCoefficientMatrix t s j i

theorem source_permanent_boundary_zero (t : Fin n → ℝ) :
    sourcePermanentBoundaryCurve t 0=sourcePermanentReference t := by
  ext i j
  simp [sourcePermanentBoundaryCurve,sourcePermanentReference,boundaryCoefficientMatrix]

theorem source_permanent_boundary_continuous (t : Fin n → ℝ) : Continuous (sourcePermanentBoundaryCurve t) := by
  apply continuous_pi
  intro i
  apply continuous_pi
  intro j
  unfold sourcePermanentBoundaryCurve boundaryCoefficientMatrix
  fun_prop

theorem source_permanent_boundary_objective (t : Fin n → ℝ) (s : ℝ) :
    Matrix.permanent (sourcePermanentBoundaryCurve t s)=fixedDegreeObjective (stableBoundaryCurve t s) := by
  rw [← source_permanent_coefficient_identity]
  rfl

theorem source_permanent_boundary_feasible (t : Fin n → ℝ) (hn : 2 ≤ n)
    (ht : (∑ i,t i)=n) (htpos : ∀ i,0 < t i) :
    ∃ e : ℝ,0 < e ∧ ∀ s : ℝ,|s| < e → sourcePermanentBoundaryCurve t s ∈ sourceTransportationPolytope t := by
  have hnpos : (0 : ℝ) < n := by exact_mod_cast (show 0<n by omega)
  obtain ⟨e,he,hnear⟩ := finite_affine_positive_near_zero
    (fun q : Fin n × Fin n => t q.2/(n : ℝ))
    (fun q => (t q.2*projectedOnes t q.2)*boundaryModelDiagonal n q.1)
    (fun q => div_pos (htpos q.2) hnpos)
  refine ⟨e,he,?_⟩
  intro s hs
  refine ⟨?_,?_,?_⟩
  · intro i j
    exact le_of_lt (by simpa only [sourcePermanentBoundaryCurve,boundaryCoefficientMatrix,mul_assoc] using hnear s hs (j,i))
  · intro i
    exact boundaryCoefficientMatrix_column t (by omega) s i
  · intro j
    exact boundaryCoefficientMatrix_row t (by omega) ht s j

theorem source_permanent_not_local_of_nonpositive_lambda (t : Fin n → ℝ) (hn : 2 ≤ n)
    (ht : (∑ i,t i)=n) (htpos : ∀ i,0 < t i) (hl : scalarHessianLambda t ≤ 0) :
    ¬IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) (sourcePermanentReference t) := by
  intro hf
  obtain ⟨ef,hef,hfeas⟩ := source_permanent_boundary_feasible t hn ht htpos
  obtain ⟨ed,hed,hdesc⟩ := source_actual_squarefree_curve_descent t hn ht htpos hl
  let J : Set ℝ := Set.Ioo (-ef) ef
  have hmem : J ⊆ (sourcePermanentBoundaryCurve t) ⁻¹' sourceTransportationPolytope t := by
    intro s hs
    exact hfeas s (abs_lt.mpr hs)
  have hz : (0 : ℝ) ∈ J := by constructor <;> linarith
  have hstart : IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) (sourcePermanentBoundaryCurve t 0) := by
    simpa only [source_permanent_boundary_zero] using hf
  have hcomp := hstart.comp_continuousOn hmem (source_permanent_boundary_continuous t).continuousOn hz
  have hloc := hcomp.isLocalMin (isOpen_Ioo.mem_nhds hz)
  change ∀ᶠ s in 𝓝 (0 : ℝ),Matrix.permanent (sourcePermanentBoundaryCurve t 0) ≤ Matrix.permanent (sourcePermanentBoundaryCurve t s) at hloc
  obtain ⟨r,hr,hnear⟩ := Metric.eventually_nhds_iff.mp hloc
  let s := min r ed/2
  have hs : 0 < s := by dsimp [s];exact div_pos (lt_min hr hed) (by norm_num)
  have hsr : s < r := by have h := min_le_left r ed;dsimp [s];nlinarith [lt_min hr hed]
  have hsd : s < ed := by have h := min_le_right r ed;dsimp [s];nlinarith [lt_min hr hed]
  have hle := hnear (y := s) (by simpa [Real.dist_eq,abs_of_pos hs] using hsr)
  rw [source_permanent_boundary_objective,source_permanent_boundary_objective,stableBoundaryCurve_zero] at hle
  have hlt := hdesc s hs hsd
  linarith

theorem source_permanent_local_iff (t : Fin n → ℝ) (hn : 2 ≤ n)
    (ht : (∑ i,t i)=n) (htpos : ∀ i,0 < t i) :
    IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) (sourcePermanentReference t) ↔
      (∑ i,(t i-1)^2) < (n : ℝ)/((n : ℝ)-1) := by
  constructor
  · intro hmin
    apply (scalarHessianLambda_pos_iff_radius t hn ht).mp
    by_contra hh
    exact source_permanent_not_local_of_nonpositive_lambda t hn ht htpos (le_of_not_gt hh) hmin
  · exact source_permanent_local_sufficiency t hn ht htpos

theorem source_permanent_global_growth_exists (hn : 2 ≤ n) :
    ∃ ε κ : ℝ,0 < ε ∧ 0 < κ ∧ ∀ t : Fin n → ℝ,(∑ i,t i)=n →
      (∀ i,0 < t i) → (∑ i,|t i-1|) < ε → ∀ B ∈ sourceTransportationPolytope t,
        κ*(∑ i,∑ j,(B i j-t i/n)^2) ≤ Matrix.permanent B-sourceVn n*(∏ i,t i) := by
  obtain ⟨ε,κ,hε,hκ,hgrowth⟩ := source_hermitian_global_growth_exists hn
  refine ⟨ε,κ,hε,hκ,?_⟩
  intro t ht htpos hnear B hB
  have h := hgrowth t ht htpos hnear (sourcePermanentDiagonalTuple B) (source_permanent_diagonal_feasible t B hB)
  simpa only [source_permanent_diagonal_distance,source_permanent_diagonal_objective] using h

theorem source_permanent_global_growth_explicit (hn : 3 ≤ n) (t : Fin n → ℝ)
    (ht : (∑ i,t i)=n) (hnear : (∑ i,|t i-1|) ≤ 1/(1000000000*(n : ℝ)^8))
    (B : Matrix (Fin n) (Fin n) ℝ) (hB : B ∈ sourceTransportationPolytope t) :
    sourceVn n/(4000000000*(n : ℝ)^8)*(∑ i,∑ j,(B i j-t i/n)^2) ≤
      Matrix.permanent B-sourceVn n*(∏ i,t i) := by
  have h := source_hermitian_global_growth_explicit hn t ht hnear (sourcePermanentDiagonalTuple B)
    (source_permanent_diagonal_feasible t B hB)
  simpa only [source_permanent_diagonal_distance,source_permanent_diagonal_objective] using h

end CoefficientStability
