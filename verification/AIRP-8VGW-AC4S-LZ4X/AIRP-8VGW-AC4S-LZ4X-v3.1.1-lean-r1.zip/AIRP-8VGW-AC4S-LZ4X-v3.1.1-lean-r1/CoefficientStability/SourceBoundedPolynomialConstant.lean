import CoefficientStability.SourceCubicActualDiscriminant
import Mathlib.Topology.Algebra.Polynomial

noncomputable section
open scoped BigOperators Topology
open Filter
namespace CoefficientStability
set_option maxHeartbeats 5000000

theorem source_real_polynomial_bounded_constant (p : Polynomial ℝ) (M : ℝ)
    (hb : ∀ x : ℝ,|p.eval x|≤M) : p=Polynomial.C (p.coeff 0) := by
  by_cases hd : p.degree≤0
  · exact Polynomial.eq_C_of_degree_le_zero hd
  · have hp : 0<p.degree := lt_of_not_ge hd
    have ht : Tendsto (fun x : ℝ => ‖p.eval x‖) atTop atTop :=
      p.tendsto_norm_atTop hp tendsto_norm_atTop_atTop
    obtain ⟨x,hx⟩ := ((tendsto_atTop.mp ht) (M+1)).exists
    have h := hb x
    rw [Real.norm_eq_abs] at hx
    linarith

theorem source_real_polynomial_square_bounded_constant (p : Polynomial ℝ) (M : ℝ)
    (hb : ∀ x : ℝ,(p.eval x)^2≤M) : p=Polynomial.C (p.coeff 0) := by
  apply source_real_polynomial_bounded_constant p (Real.sqrt (max M 0))
  intro x
  apply abs_le_of_sq_le_sq _ (Real.sqrt_nonneg _)
  rw [Real.sq_sqrt (le_max_right M 0)]
  exact (hb x).trans (le_max_left M 0)

def sourcePolynomialCurve {n : ℕ} (p : MvPolynomial (Fin n) ℝ)
    (z : Fin n → Polynomial ℝ) : Polynomial ℝ := MvPolynomial.eval₂ Polynomial.C z p

theorem source_polynomial_curve_actual_evaluation {n : ℕ}
    (p : MvPolynomial (Fin n) ℝ) (z : Fin n → Polynomial ℝ) (x : ℝ) :
    (sourcePolynomialCurve p z).eval x=MvPolynomial.eval (fun i => (z i).eval x) p := by
  change (Polynomial.evalRingHom x) (MvPolynomial.eval₂ Polynomial.C z p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c
    simp

theorem source_polynomial_curve_square_bounded_constant {n : ℕ}
    (p : MvPolynomial (Fin n) ℝ) (z : Fin n → Polynomial ℝ) (M : ℝ)
    (hb : ∀ x : ℝ,(MvPolynomial.eval (fun i => (z i).eval x) p)^2≤M) (x : ℝ) :
    MvPolynomial.eval (fun i => (z i).eval x) p=
      MvPolynomial.eval (fun i => (z i).eval 0) p := by
  have hc := source_real_polynomial_square_bounded_constant (sourcePolynomialCurve p z) M
    (by intro y;rw [source_polynomial_curve_actual_evaluation];exact hb y)
  rw [← source_polynomial_curve_actual_evaluation,← source_polynomial_curve_actual_evaluation,hc]
  simp

end CoefficientStability
