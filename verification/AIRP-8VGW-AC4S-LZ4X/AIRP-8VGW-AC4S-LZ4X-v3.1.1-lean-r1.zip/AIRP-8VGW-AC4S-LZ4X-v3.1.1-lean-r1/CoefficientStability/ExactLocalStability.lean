import CoefficientStability.LocalQuadraticGrowth

noncomputable section
open scoped BigOperators Matrix.Norms.Elementwise Topology
namespace CoefficientStability
variable {n : ℕ}

theorem complexReferenceTuple_feasible (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) :
    complexReferenceTuple t∈hermitianFeasibleTuples t := by
  obtain ⟨e,he,hfeas⟩ := complexBoundaryTuple_feasible_near_zero t hn ht htpos
  have h := hfeas 0 (by simpa using he)
  simpa only [complexBoundaryTuple_zero] using h

theorem feasible_difference_tangent (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i)
    (X : Fin n → Matrix (Fin n) (Fin n) ℂ) (hX : X∈hermitianFeasibleTuples t) :
    (∀ i,((X-complexReferenceTuple t) i).IsHermitian) ∧
      (∀ i,Matrix.trace ((X-complexReferenceTuple t) i)=0) ∧
      (∑ i,(X-complexReferenceTuple t) i)=0 := by
  have h0 := complexReferenceTuple_feasible t hn ht htpos
  refine ⟨?_,?_,?_⟩
  · intro i
    exact (hX.1 i).1.sub (h0.1 i).1
  · intro i
    simp only [Pi.sub_apply,Matrix.trace_sub,(hX.1 i).2.2,(h0.1 i).2.2,sub_self]
  · simp only [Pi.sub_apply,Finset.sum_sub_distrib,hX.2,h0.2,sub_self]

theorem paper_exact_local_sufficiency (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : 0<scalarHessianLambda t) :
    IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (complexReferenceTuple t) := by
  obtain ⟨a,r,ha,hr,hgrowth⟩ := paper_local_quadratic_growth t hn ht htpos hl
  change ∀ᶠ X in 𝓝[hermitianFeasibleTuples t] (complexReferenceTuple t),
    hermitianMixedObjective (complexReferenceTuple t)≤hermitianMixedObjective X
  have hnear : ∀ᶠ X in 𝓝 (complexReferenceTuple t),‖X-complexReferenceTuple t‖<r := by
    exact Filter.mem_of_superset (Metric.ball_mem_nhds (complexReferenceTuple t) hr)
      (fun X hX => by simpa only [Metric.mem_ball,dist_eq_norm,Set.mem_setOf_eq] using hX)
  filter_upwards [self_mem_nhdsWithin,hnear.filter_mono nhdsWithin_le_nhds] with X hX hnorm
  obtain ⟨hHerm,htrace,hsum⟩ := feasible_difference_tangent t hn ht htpos X hX
  have h := hgrowth (X-complexReferenceTuple t) hHerm htrace hsum hnorm
  have he : complexReferenceTuple t+(X-complexReferenceTuple t)=X := by abel
  rw [he,← referenceObjective_source_normalization t (by omega)] at h
  have hpos : 0≤a*complexTupleSq (X-complexReferenceTuple t) := mul_nonneg ha.le (complexTupleSq_nonneg _)
  linarith

theorem paper_exact_local (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) :
    IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (complexReferenceTuple t) ↔
      (∑ i,(t i-1)^2)<(n : ℝ)/((n : ℝ)-1) := by
  constructor
  · exact paper_exact_local_necessity t hn ht htpos
  · intro hr
    exact paper_exact_local_sufficiency t hn ht htpos ((scalarHessianLambda_pos_iff_radius t hn ht).mpr hr)

theorem paper_exact_local_frobenius_growth (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i)
    (hradius : (∑ i,(t i-1)^2)<(n : ℝ)/((n : ℝ)-1)) :
    ∃ a r : ℝ,0<a ∧ 0<r ∧ ∀ A : Fin n → Matrix (Fin n) (Fin n) ℂ,
      (∀ i,(A i).IsHermitian) → (∀ i,Matrix.trace (A i)=0) → (∑ i,A i)=0 →
      Real.sqrt (complexTupleSq A)<r → a*complexTupleSq A≤
        hermitianMixedObjective (complexReferenceTuple t+A)-((n.factorial : ℝ)/(n : ℝ)^n*∏ i,t i) := by
  obtain ⟨a,r,ha,hr,hgrowth⟩ := paper_local_quadratic_growth t hn ht htpos
    ((scalarHessianLambda_pos_iff_radius t hn ht).mpr hradius)
  refine ⟨a,r,ha,hr,?_⟩
  intro A hHerm htrace hsum hnorm
  have hle : ‖A‖≤Real.sqrt (complexTupleSq A) :=
    (Real.le_sqrt (norm_nonneg _) (complexTupleSq_nonneg _)).mpr (tuple_sq_norm_le_frobenius A)
  exact hgrowth A hHerm htrace hsum (lt_of_le_of_lt hle hnorm)

end CoefficientStability
