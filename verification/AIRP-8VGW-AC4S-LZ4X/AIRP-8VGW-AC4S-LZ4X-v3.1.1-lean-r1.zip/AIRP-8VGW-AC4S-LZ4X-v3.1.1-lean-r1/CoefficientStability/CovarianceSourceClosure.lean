import CoefficientStability.DeterminantalGram
import CoefficientStability.ProductDeficitExtremal
import CoefficientStability.MultinomialCoefficientLaw
import Mathlib.Algebra.MvPolynomial.Funext

noncomputable section
open scoped BigOperators ComplexOrder
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem actual_coefficient_gradient_nonnegative (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hcoeff : ∀ d,0≤p.coeff d) (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i)
    (i : Fin n) : 0≤t i := by
  rw [← hgrad i,← actual_coefficient_first_moment]
  exact Finset.sum_nonneg (fun d _ => mul_nonneg (hcoeff d) (Nat.cast_nonneg _))

theorem paper_covariance_source_identities (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hn : 2≤n) (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p) (hcoeff : ∀ d,0≤p.coeff d) (ht : ∑ i,t i=n)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    (∀ i j,2*deficitMatrix p t n i j=
      -MvPolynomial.eval (fun _ => 1) (pderiv i (pderiv j (p-scalarPower t n)))) ∧
    (∀ i,(∑ d∈p.support,p.coeff d*(d i : ℝ))=t i) ∧
    (∀ i,(∑ d∈(scalarPower t n).support,(scalarPower t n).coeff d*(d i : ℝ))=t i) ∧
    coefficientCovariance (scalarPower t n) t-coefficientCovariance p t=(2 : ℝ) • deficitMatrix p t n ∧
    (coefficientCovariance (scalarPower t n) t-coefficientCovariance p t).PosSemidef ∧
    referenceDeficit p t n=((n : ℝ)-(∑ i,t i^2)/n-Matrix.trace (coefficientCovariance p t))/2 ∧
    0≤referenceDeficit p t n ∧ referenceDeficit p t n≤((n : ℝ)-1)/2 := by
  have hb := paper_deficit_uniform_bound p t hn hp hnorm hstable hcoeff ht hgrad
  refine ⟨paper_defect_hessian_identity p t n hn ht,?_,?_,
    paper_covariance_difference p t n hn ht hnorm hgrad,
    paper_covariance_difference_posSemidef p t n hn hp ht hnorm hstable hgrad,
    paper_deficit_covariance_identity p t n (by omega) ht hnorm hgrad,hb.1,hb.2⟩
  · intro i
    rw [actual_coefficient_first_moment,hgrad i]
  · exact (multinomial_coefficient_probability t n (by omega) ht
      (actual_coefficient_gradient_nonnegative p t hcoeff hgrad)).2.2

theorem real_determinant_polynomial_unique (p : MvPolynomial (Fin n) ℝ)
    (A : Fin n → ComplexSquare n) (hHerm : ∀ i,(A i).IsHermitian)
    (hdet : ∀ x : Fin n → ℝ,Complex.ofReal (MvPolynomial.eval x p)=
      Matrix.det (∑ i,Complex.ofReal (x i) • A i)) : p=realDeterminantPolynomial A := by
  apply MvPolynomial.funext
  intro x
  apply Complex.ofReal_injective
  exact (hdet x).trans (realDeterminantPolynomial_evaluation A hHerm x).symm

theorem paper_covariance_determinant_specialization (p : MvPolynomial (Fin n) ℝ)
    (A : Fin n → ComplexSquare n) (hn : 2≤n) (hPSD : ∀ i,(A i).PosSemidef) (hA : ∑ i,A i=1)
    (hdet : ∀ x : Fin n → ℝ,Complex.ofReal (MvPolynomial.eval x p)=
      Matrix.det (∑ i,Complex.ofReal (x i) • A i)) :
    (∀ i j,Complex.ofReal (deficitMatrix p (fun k => (Matrix.trace (A k)).re) n i j)=
      Matrix.trace (centeredDeterminantMatrix A i*centeredDeterminantMatrix A j)/2) ∧
    referenceDeficit p (fun k => (Matrix.trace (A k)).re) n=
      (∑ i,complexFrobeniusSq (centeredDeterminantMatrix A i))/2 := by
  have hHerm : ∀ i,(A i).IsHermitian := fun i => (hPSD i).isHermitian
  rw [real_determinant_polynomial_unique p A hHerm hdet]
  exact ⟨paper_determinantal_deficit_gram_complex A hHerm hA (by omega),
    paper_determinantal_deficit_frobenius A hHerm hA (by omega)⟩

end CoefficientStability
