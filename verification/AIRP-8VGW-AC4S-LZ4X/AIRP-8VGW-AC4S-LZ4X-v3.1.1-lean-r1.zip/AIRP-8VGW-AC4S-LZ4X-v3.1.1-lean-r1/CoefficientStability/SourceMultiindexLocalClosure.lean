import CoefficientStability.SourceWeightedBoundaryDescent

noncomputable section
open scoped BigOperators Topology
open Filter
namespace CoefficientStability
variable {m : ℕ}

theorem source_weighted_lambda_positive_iff (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (hN : 2 ≤ sourceCloneCount α) (t : Fin m → ℝ) (ht : (∑ i,t i)=sourceCloneCount α) :
    0 < scalarHessianLambda (sourceClonedGradient α t) ↔
      (∑ i,(t i-(α i : ℝ))^2/(α i : ℝ)) < (sourceCloneCount α : ℝ)/((sourceCloneCount α : ℝ)-1) := by
  have h := scalarHessianLambda_pos_iff_radius (sourceClonedGradient α t) hN
    ((sourceClonedGradient_sum α hα t).trans ht)
  simpa only [sourceClonedGradient,sourceCloneGradient_square_sum α hα t] using h

theorem source_weighted_topological_local_iff (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (hN : 2 ≤ sourceCloneCount α) (t : Fin m → ℝ)
    (ht : (∑ i,t i)=sourceCloneCount α) (htpos : ∀ i,0 < t i) :
    IsLocalMinOn (sourceMultiindexObjective α) (sourceMultiindexCoefficientClass α t) (sourceWeightedReference α t) ↔
      (∑ i,(t i-(α i : ℝ))^2/(α i : ℝ)) < (sourceCloneCount α : ℝ)/((sourceCloneCount α : ℝ)-1) := by
  constructor
  · intro hmin
    apply (source_weighted_lambda_positive_iff α hα hN t ht).mp
    by_contra hh
    have hdesc := source_actual_weighted_curve_descent α hα hN t ht htpos (le_of_not_gt hh)
    exact source_not_localMin_of_actual_weighted_curve α hα hN t ht htpos hdesc hmin
  · exact source_weighted_topological_local_minimum α hα hN t ht htpos

theorem source_weighted_boundary_positive_product_descent (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (hN : 2 ≤ sourceCloneCount α) (t : Fin m → ℝ)
    (ht : (∑ i,t i)=sourceCloneCount α) (htpos : ∀ i,0 < t i)
    (hout : (sourceCloneCount α : ℝ)/((sourceCloneCount α : ℝ)-1) ≤ (∑ i,(t i-(α i : ℝ))^2/(α i : ℝ))) :
    ∃ e : ℝ,0 < e ∧ Tendsto (sourceWeightedBoundaryCurve α t) (𝓝 0) (𝓝 (sourceWeightedReference α t)) ∧
      ∀ s : ℝ,0 < s → s < e →
        sourceWeightedBoundaryCurve α t s ∈ sourceMultiindexCoefficientClass α t ∧
        sourceMultiindexObjective α (sourceWeightedBoundaryCurve α t s) < sourceMultiindexObjective α (sourceWeightedReference α t) ∧
        (∀ r i,0 < sourceWeightedBoundaryRows α t s r i) ∧
        (sourceWeightedBoundaryCurve α t s).val=∏ r : Fin (sourceCloneCount α),scalarLinear (sourceWeightedBoundaryRows α t s r) 1 := by
  have hl : scalarHessianLambda (sourceClonedGradient α t) ≤ 0 := by
    by_contra hh
    have hlt := (source_weighted_lambda_positive_iff α hα hN t ht).mp (lt_of_not_ge hh)
    linarith
  obtain ⟨ef,hef,hfeas⟩ := sourceWeightedBoundaryCurve_feasible α hα hN t ht htpos
  obtain ⟨ed,hed,hdesc⟩ := source_actual_weighted_curve_descent α hα hN t ht htpos hl
  obtain ⟨ep,hep,hpos⟩ := sourceWeightedBoundaryRows_positive_near_zero α hα hN t htpos
  refine ⟨min ef (min ed ep),lt_min hef (lt_min hed hep),sourceWeightedBoundaryCurve_tendsto_reference α hα t,?_⟩
  intro s hs hse
  have hf : s < ef := lt_of_lt_of_le hse (min_le_left _ _)
  have hd : s < ed := lt_of_lt_of_le hse ((min_le_right _ _).trans (min_le_left _ _))
  have hp : s < ep := lt_of_lt_of_le hse ((min_le_right _ _).trans (min_le_right _ _))
  exact ⟨hfeas s (by simpa only [abs_of_pos hs] using hf),hdesc s hs hd,
    hpos s (by simpa only [abs_of_pos hs] using hp),sourceWeightedBoundaryCurve_product α t s⟩

theorem source_multiindex_global_unique_all_degrees (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (hN : 2 ≤ sourceCloneCount α) (ε κ : ℝ) (hκ : 0 < κ)
    (hsource : sourceSquarefreeVarianceCertificate (sourceCloneCount α) ε κ)
    (p : MvPolynomial (Fin m) ℝ) (hp : p.IsHomogeneous (sourceCloneCount α))
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (t : Fin m → ℝ) (ht : (∑ i,t i)=sourceCloneCount α)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hnear : (∑ i,|t i-(α i : ℝ)|) < ε) :
    sourceMultiIndexBaseline α t ≤ p.coeff (sourceMultiExponent α) ∧
      (p.coeff (sourceMultiExponent α)=sourceMultiIndexBaseline α t ↔ p=scalarPower t (sourceCloneCount α)) := by
  have hg := source_multiindex_variance_transfer α hα ε κ hsource p hp hs hnorm t ht hgrad hnear
  have hδ := sourceWeightedDeficit_nonnegative α hα hN p hp hs hnorm t hgrad
  have hc : 0 < κ/sourceCloneCoefficientWeight α := div_pos hκ (sourceCloneCoefficientWeight_pos α hα)
  refine ⟨sub_nonneg.mp ((mul_nonneg hc.le hδ).trans hg),?_⟩
  constructor
  · intro he
    have hz : sourceWeightedDeficit α p t=0 := by
      by_contra hh
      have hpδ : 0 < sourceWeightedDeficit α p t := lt_of_le_of_ne hδ (Ne.symm hh)
      have hpos := mul_pos hc hpδ
      rw [he,sub_self] at hg
      linarith
    exact (sourceWeightedDeficit_zero_iff α hα hN p hp hs hnorm t ht hgrad).mp hz
  · intro he
    rw [he,sourceScalarPower_multiindex_baseline]
    rfl

end CoefficientStability
