import CoefficientStability.SourceCloneWordEnumeration

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {m : ℕ}

def sourceCloneCoefficientWeight (α : Fin m → ℕ) : ℝ :=
  ∏ i,((α i).factorial : ℝ)/(α i : ℝ)^(α i)

theorem sourceCloneCoefficientWeight_pos (α : Fin m → ℕ) (hα : ∀ i,0 < α i) :
    0 < sourceCloneCoefficientWeight α := by
  apply Finset.prod_pos
  intro i hi
  apply div_pos (by exact_mod_cast Nat.factorial_pos (α i))
  exact pow_pos (by exact_mod_cast hα i) _

theorem sourceCloneWord_factor_combination (α : Fin m → ℕ) :
    (∏ i,(1/(α i : ℝ))^(α i))*(∏ i,((α i).factorial : ℝ))=sourceCloneCoefficientWeight α := by
  rw [← Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro i hi
  rw [div_pow,one_pow]
  ring

theorem sourceClonePolynomial_squarefree_coefficient (α : Fin m → ℕ) (p : MvPolynomial (Fin m) ℝ) :
    (sourceClonePolynomial α p).coeff (squarefreeExponent (sourceCloneCount α))=
      sourceCloneCoefficientWeight α*p.coeff (sourceMultiExponent α) := by
  let l := List.ofFn (fun j : Fin (sourceCloneCount α) => j)
  have hleft := sourceWordPartial_zero_coeff l (sourceClonePolynomial α p)
  have hex : sourceWordExponent l=squarefreeExponent (sourceCloneCount α) := sourceWordExponent_all_fin _
  rw [hex] at hleft
  have hfac : (∏ j,((squarefreeExponent (sourceCloneCount α) j).factorial : ℝ))=1 := by
    apply Finset.prod_eq_one
    intro j hj
    have hj1 : squarefreeExponent (sourceCloneCount α) j=1 := by simp [squarefreeExponent,Finsupp.single_apply]
    rw [hj1]
    norm_num
  rw [hfac,mul_one] at hleft
  have ho : (sourceWordPartial (l.map (sourceCloneBlock α)) p).coeff 0=
      p.coeff (sourceMultiExponent α)*(∏ i,((α i).factorial : ℝ)) := by
    have h := sourceWordPartial_zero_coeff (l.map (sourceCloneBlock α)) p
    have he : sourceWordExponent (l.map (sourceCloneBlock α))=sourceMultiExponent α := by
      simpa only [l,List.map_ofFn,Function.comp_def] using sourceWordExponent_clone_blocks α
    rw [he] at h
    simpa only [sourceMultiExponent_apply] using h
  have hpull := congrArg (fun q : MvPolynomial (Fin (sourceCloneCount α)) ℝ => q.coeff 0)
    (sourceWordPartial_clone α l p)
  rw [hleft,MvPolynomial.coeff_C_mul,sourceClonePolynomial_zero_coeff,ho] at hpull
  have hpref : ((l.map (fun j => 1/(α (sourceCloneBlock α j) : ℝ))).prod)=
      ∏ i,(1/(α i : ℝ))^(α i) := sourceCloneWord_inverse_block_product α
  rw [hpref] at hpull
  calc
    _ = (∏ i,(1/(α i : ℝ))^(α i))*(p.coeff (sourceMultiExponent α)*(∏ i,((α i).factorial : ℝ))) := hpull
    _ = ((∏ i,(1/(α i : ℝ))^(α i))*(∏ i,((α i).factorial : ℝ)))*p.coeff (sourceMultiExponent α) := by ring
    _ = _ := by rw [sourceCloneWord_factor_combination]

end CoefficientStability
