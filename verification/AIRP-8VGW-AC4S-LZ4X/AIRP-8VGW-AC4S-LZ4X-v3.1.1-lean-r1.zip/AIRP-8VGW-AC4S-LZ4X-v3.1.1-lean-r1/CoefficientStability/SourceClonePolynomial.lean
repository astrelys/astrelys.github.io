import CoefficientStability.SourceCloneIndex
import CoefficientStability.RectangularSourceDerivatives

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {m : ℕ}

def sourceClonePolynomial (α : Fin m → ℕ) (p : MvPolynomial (Fin m) ℝ) :
    MvPolynomial (Fin (sourceCloneCount α)) ℝ := rectangularSubstitution (sourceCloneAveragingMatrix α) p

def sourceClonedGradient (α : Fin m → ℕ) (t : Fin m → ℝ) (j : Fin (sourceCloneCount α)) : ℝ :=
  t (sourceCloneBlock α j)/(α (sourceCloneBlock α j) : ℝ)

def sourceWeightedDeficit (α : Fin m → ℕ) (p : MvPolynomial (Fin m) ℝ) (t : Fin m → ℝ) : ℝ :=
  ∑ i,deficitMatrix p t (sourceCloneCount α) i i/(α i : ℝ)

theorem sourceClonePolynomial_source_hypotheses (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (p : MvPolynomial (Fin m) ℝ) (hp : p.IsHomogeneous (sourceCloneCount α))
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (t : Fin m → ℝ) (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) :
    (sourceClonePolynomial α p).IsHomogeneous (sourceCloneCount α) ∧
      UpperHalfPlaneZeroFree (sourceClonePolynomial α p) ∧
      MvPolynomial.eval (fun _ => 1) (sourceClonePolynomial α p)=1 ∧
      (∀ g,0 ≤ (sourceClonePolynomial α p).coeff g) ∧
      ∀ j,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv j (sourceClonePolynomial α p))=sourceClonedGradient α t j := by
  have hrow := sourceCloneAveragingMatrix_row α hα
  refine ⟨rectangularSubstitution_homogeneous _ p _ hp,
    rectangularSubstitution_stable _ p hs (sourceCloneAveragingMatrix_nonnegative α) hrow,
    rectangularSubstitution_normalized _ p hrow hnorm,
    rectangularSubstitution_coeff_nonnegative _ p _ hp hs hnorm (sourceCloneAveragingMatrix_nonnegative α) hrow,?_⟩
  intro j
  rw [sourceClonePolynomial,rectangularSubstitution_actual_gradient _ p hrow]
  have he : (fun i => MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p))=t := funext hgrad
  rw [he]
  exact sourceCloneAveragingMatrix_gradient_column α t j

theorem sourceClonePolynomial_eval_recovery (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (p : MvPolynomial (Fin m) ℝ) (x : Fin m → ℝ) :
    MvPolynomial.eval (fun j => x (sourceCloneBlock α j)) (sourceClonePolynomial α p)=MvPolynomial.eval x p := by
  rw [sourceClonePolynomial,rectangularSubstitution_eval,sourceCloneAveragingMatrix_recovery α hα]

theorem sourceClonePolynomial_injective (α : Fin m → ℕ) (hα : ∀ i,0 < α i) :
    Function.Injective (sourceClonePolynomial α) := by
  intro p q he
  apply MvPolynomial.funext
  intro x
  rw [← sourceClonePolynomial_eval_recovery α hα p x,← sourceClonePolynomial_eval_recovery α hα q x,he]

theorem sourceClonePolynomial_actual_deficit (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (p : MvPolynomial (Fin m) ℝ) (t : Fin m → ℝ)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (j l : Fin (sourceCloneCount α)) :
    deficitMatrix (sourceClonePolynomial α p) (sourceClonedGradient α t) (sourceCloneCount α) j l=
      deficitMatrix p t (sourceCloneCount α) (sourceCloneBlock α j) (sourceCloneBlock α l)/
        ((α (sourceCloneBlock α j) : ℝ)*(α (sourceCloneBlock α l) : ℝ)) := by
  classical
  have he : rectangularSourceGradient (sourceCloneAveragingMatrix α) t=sourceClonedGradient α t :=
    funext (sourceCloneAveragingMatrix_gradient_column α t)
  rw [sourceClonePolynomial,← he,rectangularSubstitution_actual_deficit _ p t _
    (sourceCloneAveragingMatrix_row α hα) hgrad]
  simp only [sourceCloneAveragingMatrix,ite_mul,mul_ite,zero_mul,mul_zero,Finset.sum_ite_eq,
    Finset.mem_univ,ite_true]
  ring

theorem sourceClonePolynomial_weighted_variance (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (p : MvPolynomial (Fin m) ℝ) (t : Fin m → ℝ)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) :
    referenceDeficit (sourceClonePolynomial α p) (sourceClonedGradient α t) (sourceCloneCount α)=
      sourceWeightedDeficit α p t := by
  classical
  rw [← trace_deficitMatrix]
  simp only [Matrix.trace,Matrix.diag,sourceClonePolynomial_actual_deficit α hα p t hgrad]
  rw [← Equiv.sum_comp (sourceCloneEquiv α) (fun j =>
    deficitMatrix p t (sourceCloneCount α) (sourceCloneBlock α j) (sourceCloneBlock α j)/
      ((α (sourceCloneBlock α j) : ℝ)*(α (sourceCloneBlock α j) : ℝ)))]
  simp only [Fintype.sum_sigma,sourceCloneBlock_equiv,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,sourceWeightedDeficit]
  apply Finset.sum_congr rfl
  intro i hi
  have hne : (α i : ℝ)≠0 := by exact_mod_cast (ne_of_gt (hα i))
  field_simp

end CoefficientStability
