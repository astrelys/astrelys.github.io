import CoefficientStability.SourceCubicBlockFeasible
import CoefficientStability.SourceTwoTraceGeometry

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 3000000
set_option backward.isDefEq.respectTransparency false

theorem source_cubic_block_sum_replacement (a b : Fin 3 → ℝ)
    (V W : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hs : (∑ i,W i)=∑ i,V i) :
    (∑ i,sourceCubicBlockTuple a b W i)=∑ i,sourceCubicBlockTuple a b V i := by
  have hsum : (∑ i,sourceTwoCentered (b i) (W i))=∑ i,sourceTwoCentered (b i) (V i) := by
    simp only [sourceTwoCentered,Finset.sum_add_distrib,hs]
  unfold sourceCubicBlockTuple
  rw [source_one_two_block_sum,source_one_two_block_sum,hsum]

def sourceBlockRadial (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (r : ℝ) : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ :=
  fun i => (1-r) • V i

theorem source_block_radial_hermitian (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (hV : ∀ i,(V i).IsHermitian) (r : ℝ) : ∀ i,(sourceBlockRadial V r i).IsHermitian := by
  intro i
  exact (hV i).smul (by simp [IsSelfAdjoint])

theorem source_block_radial_traceless (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (ht : ∀ i,Matrix.trace (V i)=0) (r : ℝ) : ∀ i,Matrix.trace (sourceBlockRadial V r i)=0 := by
  intro i
  simp [sourceBlockRadial,Matrix.trace_smul,ht i]

theorem source_block_radial_sum (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (hs : (∑ i,V i)=0) (r : ℝ) : (∑ i,sourceBlockRadial V r i)=∑ i,V i := by
  simp only [sourceBlockRadial,← Finset.smul_sum,hs,smul_zero]

theorem source_block_radial_quadratic_decrease (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (hV : ∀ i,(V i).IsHermitian) (r : ℝ) (hr : r ∈ Set.Icc 0 1) :
    ∀ i,sourceTwoTraceQuadratic (sourceBlockRadial V r i) ≤ sourceTwoTraceQuadratic (V i) := by
  intro i
  rw [sourceBlockRadial,source_two_trace_quadratic_smul]
  have hn := source_two_trace_quadratic_nonnegative (V i) (hV i)
  have hsq : (1-r)^2 ≤ 1 := by nlinarith [hr.1,hr.2]
  have hm := mul_nonneg (sub_nonneg.mpr hsq) hn
  nlinarith

theorem source_block_radial_continuous (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) : Continuous (sourceBlockRadial V) := by
  apply continuous_pi
  intro i
  change Continuous (fun r : ℝ => (1-r) • V i)
  fun_prop

@[simp] theorem source_block_radial_zero (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) : sourceBlockRadial V 0=V := by
  funext i
  simp [sourceBlockRadial]

theorem source_cubic_block_radial_feasible (t a b : Fin 3 → ℝ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hV : ∀ i,(V i).IsHermitian)
    (ht : ∀ i,Matrix.trace (V i)=0) (hs : (∑ i,V i)=0)
    (hA : sourceCubicBlockTuple a b V ∈ hermitianFeasibleTuples t) (r : ℝ) (hr : r ∈ Set.Icc 0 1) :
    sourceCubicBlockTuple a b (sourceBlockRadial V r) ∈ hermitianFeasibleTuples t :=
  source_cubic_block_replacement_feasible t a b V (sourceBlockRadial V r) hV
    (source_block_radial_hermitian V hV r) ht (source_block_radial_traceless V ht r)
    (source_block_radial_sum V hs r) (source_block_radial_quadratic_decrease V hV r hr) hA

theorem source_cubic_block_radial_objective (a b : Fin 3 → ℝ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (ht : ∀ i,Matrix.trace (V i)=0)
    (hs : (∑ i,V i)=0) (hN : (∑ i,sourceCubicBlockTuple a b V i)=1) (r : ℝ) :
    hermitianMixedObjective (sourceCubicBlockTuple a b (sourceBlockRadial V r))=
      hermitianMixedObjective (sourceCubicBlockTuple a b V)+((1-r)^2-1)*
        ∑ i,(1-2*a i)*sourceTwoTraceQuadratic (V i) := by
  have hNr : (∑ i,sourceCubicBlockTuple a b (sourceBlockRadial V r) i)=1 :=
    (source_cubic_block_sum_replacement a b V _ (source_block_radial_sum V hs r)).trans hN
  have h := source_cubic_block_tuple_objective_difference a b V (sourceBlockRadial V r)
    ht (source_block_radial_traceless V ht r) hN hNr
  have he : (∑ i,(1-2*a i)*(sourceTwoTraceQuadratic (sourceBlockRadial V r i)-sourceTwoTraceQuadratic (V i)))=
      ((1-r)^2-1)*(∑ i,(1-2*a i)*sourceTwoTraceQuadratic (V i)) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i hi
    rw [sourceBlockRadial,source_two_trace_quadratic_smul]
    ring
  rw [he] at h
  linarith

theorem source_cubic_block_radial_hasDerivAt (a b : Fin 3 → ℝ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (ht : ∀ i,Matrix.trace (V i)=0)
    (hs : (∑ i,V i)=0) (hN : (∑ i,sourceCubicBlockTuple a b V i)=1) :
    HasDerivAt (fun r : ℝ => hermitianMixedObjective (sourceCubicBlockTuple a b (sourceBlockRadial V r)))
      (-2*∑ i,(1-2*a i)*sourceTwoTraceQuadratic (V i)) 0 := by
  have he := funext (source_cubic_block_radial_objective a b V ht hs hN)
  rw [he]
  have h := (((((hasDerivAt_id (0 : ℝ)).const_sub 1).pow 2).sub_const 1).mul_const
    (∑ i,(1-2*a i)*sourceTwoTraceQuadratic (V i))).const_add (hermitianMixedObjective (sourceCubicBlockTuple a b V))
  simpa using h

end CoefficientStability
