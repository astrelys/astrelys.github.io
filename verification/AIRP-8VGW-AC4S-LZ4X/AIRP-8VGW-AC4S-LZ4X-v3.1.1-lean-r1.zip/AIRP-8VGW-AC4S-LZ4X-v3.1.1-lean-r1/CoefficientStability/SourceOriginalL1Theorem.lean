import CoefficientStability.SourceL1SixColumnEquality
import CoefficientStability.SourceL1Sharpness

noncomputable section
open scoped BigOperators
namespace CoefficientStability

theorem source_original_l1_permanent_ball (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,|t i-1|) ≤ sourceCubicEpsilon0) (B : Matrix (Fin 3) (Fin 3) ℝ)
    (hB : B ∈ sourceTransportationPolytope t) :
    sourceTernaryBaseline t ≤ Matrix.permanent B ∧
      (Matrix.permanent B=sourceTernaryBaseline t ↔ sourceL1EqualityDescription t B) ∧
      ((∑ i,|t i-1|) < sourceCubicEpsilon0 →
        (Matrix.permanent B=sourceTernaryBaseline t ↔ B=sourcePermanentReference t)) := by
  exact ⟨source_sharp_l1_permanent_inequality t ht hr B hB,
    source_sharp_l1_equality_iff t ht hr B hB,
    fun hstrict => source_sharp_l1_open_unique t ht hstrict B hB⟩

end CoefficientStability
