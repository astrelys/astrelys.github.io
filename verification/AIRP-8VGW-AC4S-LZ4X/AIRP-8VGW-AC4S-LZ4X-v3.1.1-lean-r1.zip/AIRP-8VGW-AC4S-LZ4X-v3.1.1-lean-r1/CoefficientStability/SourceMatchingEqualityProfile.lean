import CoefficientStability.SourceTransportationGeometry

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1200000

theorem source_ternary_exceptional_trace_profile (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,(t i-1)^2) ≤ 3/8) (i : Fin 3) (hi : t i=3/2) :
    sourcePermutedTraces t (Equiv.swap 0 i)=sourceEuclideanExceptionalTraces := by
  let u := sourcePermutedTraces t (Equiv.swap 0 i)
  have h0 : u 0=3/2 := by simpa [u,sourcePermutedTraces] using hi
  have hs : (∑ j,u j)=3 := (source_permuted_trace_sum t (Equiv.swap 0 i)).trans ht
  have hR : (∑ j,(u j-1)^2) ≤ 3/8 := by
    change (∑ j,(sourcePermutedTraces t (Equiv.swap 0 i) j-1)^2) ≤ 3/8
    rwa [source_permuted_radius]
  norm_num [Fin.sum_univ_succ] at hs hR
  have h2 : u 2=3/2-u 1 := by linarith
  rw [h0,h2] at hR
  have h1 : u 1=3/4 := by nlinarith [sq_nonneg (u 1-3/4)]
  have h2' : u 2=3/4 := by linarith
  change u=sourceEuclideanExceptionalTraces
  funext j
  fin_cases j
  · exact h0
  · exact h1
  · exact h2'

theorem source_matching_equality_full_profile (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,(t i-1)^2) ≤ 3/8) (x : ℝ)
    (hobj : Matrix.permanent (sourceTernaryMatchingZeros t x)=sourceTernaryBaseline t) :
    ∃ r c : Equiv.Perm (Fin 3),sourcePermutedTraces t r=sourceEuclideanExceptionalTraces ∧
      sourcePermutedMatrix (sourceTernaryMatchingZeros t x) r c=sourceEuclideanBoundaryFamily 0 := by
  have hbox := source_ternary_euclidean_trace_box t ht hr
  obtain ⟨hx,i,hi⟩ := source_matching_zero_equality_conditions t ht (fun i => (hbox i).2) x hobj
  have hprofile := source_ternary_exceptional_trace_profile t ht hr i hi
  refine ⟨Equiv.swap 0 i,Equiv.swap 0 i,hprofile,?_⟩
  have h0 := congrFun hprofile 0
  have h1 := congrFun hprofile 1
  have h2 := congrFun hprofile 2
  rw [hx]
  ext j k
  change sourceTernaryMatchingZeros t (1/2+(t 0-t 2)/3) ((Equiv.swap 0 i) j) ((Equiv.swap 0 i) k)=
    sourceEuclideanBoundaryFamily 0 j k
  fin_cases i
  all_goals
    norm_num [sourcePermutedTraces,sourceEuclideanExceptionalTraces,Equiv.swap_apply_def] at h0 h1 h2
    fin_cases j <;> fin_cases k <;>
      norm_num [sourceTernaryMatchingZeros,sourceEuclideanBoundaryFamily,Equiv.swap_apply_def,h0,h1,h2] <;> ring

end CoefficientStability
