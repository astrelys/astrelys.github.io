import CoefficientStability.SourceCubicScalarCommutativity

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 2300000
set_option backward.isDefEq.respectTransparency false

theorem source_hermitian_scalar_coefficient_real (z : ℂ)
    (hH : (z • (1 : Matrix (Fin 3) (Fin 3) ℂ)).IsHermitian) : z=(z.re : ℂ) := by
  have h : star z=z := by
    simpa [Matrix.smul_apply,Matrix.one_apply,smul_eq_mul] using hH.apply (0 : Fin 3) 0
  have hi := congrArg Complex.im h
  simp only [Complex.star_def,Complex.conj_im] at hi
  apply Complex.ext
  · simp
  · simp
    linarith

theorem source_cubic_complex_scalar_multiplier_commutation (t : Fin 3 → ℝ) (z : ℂ)
    (hH : (z • (1 : Matrix (Fin 3) (Fin 3) ℂ)).IsHermitian)
    (μ : Fin 3 → ℝ) (A S : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t)
    (hc : ∀ i,sourceCubicMatrixGradient (t i) (A i)=z • 1+(μ i : ℂ) • 1+S i)
    (hSX : ∀ i,S i*A i=0) : ∀ i j,A i*A j=A j*A i := by
  have hz := source_hermitian_scalar_coefficient_real z hH
  have hcert : ∀ i,sourceCubicMatrixGradient (t i) (A i)=(z.re : ℂ) • 1+(μ i : ℂ) • 1+S i := by
    intro i
    rw [← hz]
    exact hc i
  exact source_cubic_scalar_multiplier_pairwise_commutation t z.re μ A S hA hcert hSX

theorem source_hermitian_three_constant_spectrum_scalar (H : Matrix (Fin 3) (Fin 3) ℂ)
    (hH : H.IsHermitian) (hc : ∀ i,hH.eigenvalues i=hH.eigenvalues 0) :
    H=(hH.eigenvalues 0 : ℂ) • 1 := by
  let φ := Unitary.conjStarAlgAut ℂ (Matrix (Fin 3) (Fin 3) ℂ) hH.eigenvectorUnitary
  have hd : Matrix.diagonal (fun i => (hH.eigenvalues i : ℂ))=(hH.eigenvalues 0 : ℂ) • (1 : Matrix (Fin 3) (Fin 3) ℂ) := by
    ext i j
    by_cases hij : i=j
    · subst j
      simp [Matrix.diagonal_apply,Matrix.smul_apply,Matrix.one_apply,hc]
    · simp [Matrix.diagonal_apply,Matrix.smul_apply,Matrix.one_apply,hij]
  calc
    H=φ (Matrix.diagonal (fun i => (hH.eigenvalues i : ℂ))) := hH.spectral_theorem
    _=(hH.eigenvalues 0 : ℂ) • 1 := by rw [hd,map_smul,map_one]

end CoefficientStability
