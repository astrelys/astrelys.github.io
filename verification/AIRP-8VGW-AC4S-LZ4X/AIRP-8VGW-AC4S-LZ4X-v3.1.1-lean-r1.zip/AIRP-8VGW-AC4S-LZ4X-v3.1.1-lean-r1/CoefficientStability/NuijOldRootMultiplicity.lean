import CoefficientStability.NuijStablePerturbation
import Mathlib.Algebra.Polynomial.FieldDivision

noncomputable section
namespace CoefficientStability

theorem nuij_existing_root_multiplicity (P : Polynomial ℝ) (hp : P≠0)
    (r c : ℝ) (hr : P.IsRoot r) (hc : c≠0) :
    (P+Polynomial.C c*P.derivative).rootMultiplicity r=P.rootMultiplicity r-1 := by
  classical
  let k := P.rootMultiplicity r
  have hk : 0<k := (Polynomial.rootMultiplicity_pos hp).mpr hr
  have hk1 : k-1+1=k := by omega
  obtain ⟨g,hP,hg⟩ := P.exists_eq_pow_rootMultiplicity_mul_and_not_dvd hp r
  change P=(Polynomial.X-Polynomial.C r)^k*g at hP
  have hgeval : g.eval r≠0 := by
    intro hh
    exact hg (Polynomial.dvd_iff_isRoot.mpr hh)
  let G : Polynomial ℝ := (Polynomial.X-Polynomial.C r)*g+
    Polynomial.C c*(Polynomial.C (k : ℝ)*g+(Polynomial.X-Polynomial.C r)*g.derivative)
  have hD : P.derivative=Polynomial.C (k : ℝ)*(Polynomial.X-Polynomial.C r)^(k-1)*g+
      (Polynomial.X-Polynomial.C r)^k*g.derivative := by
    conv_lhs => rw [hP]
    rw [Polynomial.derivative_mul,Polynomial.derivative_X_sub_C_pow]
  have hpow : (Polynomial.X-Polynomial.C r)^k=(Polynomial.X-Polynomial.C r)^(k-1)*(Polynomial.X-Polynomial.C r) := by
    rw [← pow_succ,hk1]
  have hQ : P+Polynomial.C c*P.derivative=(Polynomial.X-Polynomial.C r)^(k-1)*G := by
    rw [hD,hP,hpow]
    dsimp [G]
    ring
  have hGval : G.eval r≠0 := by
    simp only [G,Polynomial.eval_add,Polynomial.eval_mul,Polynomial.eval_sub,Polynomial.eval_X,
      Polynomial.eval_C,sub_self,zero_mul,mul_zero,zero_add,add_zero]
    exact mul_ne_zero hc (mul_ne_zero (by exact_mod_cast (ne_of_gt hk)) hgeval)
  have hGne : G≠0 := by
    intro hh
    apply hGval
    simp [hh]
  have hprod : (Polynomial.X-Polynomial.C r)^(k-1)*G≠0 :=
    mul_ne_zero (pow_ne_zero _ (Polynomial.X_sub_C_ne_zero r)) hGne
  change (P+Polynomial.C c*P.derivative).rootMultiplicity r=k-1
  rw [hQ,Polynomial.rootMultiplicity_mul hprod,Polynomial.rootMultiplicity_X_sub_C_pow,
    Polynomial.rootMultiplicity_eq_zero hGval,add_zero]

end CoefficientStability
