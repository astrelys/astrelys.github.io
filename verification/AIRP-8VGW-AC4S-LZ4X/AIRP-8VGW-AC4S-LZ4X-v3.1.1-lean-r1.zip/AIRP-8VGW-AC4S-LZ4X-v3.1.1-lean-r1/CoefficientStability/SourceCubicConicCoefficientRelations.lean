import CoefficientStability.SourceCubicValueCoefficients

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceConicCubicCoefficients (c : Fin 10 → ℝ) : Fin 7 → ℝ :=
  ![c 0,c 1,c 2+c 3,c 4+c 6,c 5+c 7,c 8,c 9]

def sourceSevenPolynomial (b : Fin 7 → ℝ) : Polynomial ℝ :=
  Polynomial.C (b 0)+Polynomial.C (b 1)*Polynomial.X+
    Polynomial.C (b 2)*Polynomial.X^2+Polynomial.C (b 3)*Polynomial.X^3+
    Polynomial.C (b 4)*Polynomial.X^4+Polynomial.C (b 5)*Polynomial.X^5+
    Polynomial.C (b 6)*Polynomial.X^6

theorem source_seven_polynomial_coeff (b : Fin 7 → ℝ) (i : Fin 7) :
    (sourceSevenPolynomial b).coeff i.val=b i := by
  fin_cases i <;> norm_num [sourceSevenPolynomial]

theorem source_conic_cubic_values_univariate (c : Fin 10 → ℝ) (t : ℝ) :
    sourceTernaryCubicValue c 1 t (t^2)=(sourceSevenPolynomial (sourceConicCubicCoefficients c)).eval t := by
  norm_num [sourceTernaryCubicValue,sourceSevenPolynomial,sourceConicCubicCoefficients]
  ring

theorem source_binary_norm_seven_polynomial (a : Fin 4 → ℂ) (t : ℝ) :
    (sourceSevenPolynomial (sourceBinaryNormCoefficients a)).eval t=
      Complex.normSq (sourceBinaryCubicValue a 1 (t : ℂ)) := by
  rw [source_binary_cubic_norm_expansion]
  simp [sourceSevenPolynomial]

theorem source_conic_norm_seven_coefficient_relations (c : Fin 10 → ℝ) (a : Fin 4 → ℂ)
    (hfactor : ∀ u v : ℝ,sourceTernaryCubicValue c (u^2) (u*v) (v^2)=
      -Complex.normSq (sourceBinaryCubicValue a (u : ℂ) (v : ℂ))) :
    ∀ i : Fin 7,sourceConicCubicCoefficients c i= -sourceBinaryNormCoefficients a i := by
  have he : sourceSevenPolynomial (sourceConicCubicCoefficients c)=
      -sourceSevenPolynomial (sourceBinaryNormCoefficients a) := by
    apply Polynomial.funext
    intro t
    rw [Polynomial.eval_neg,← source_conic_cubic_values_univariate,source_binary_norm_seven_polynomial]
    simpa only [one_pow,one_mul,Complex.ofReal_one] using hfactor 1 t
  intro i
  have h := congrArg (fun p : Polynomial ℝ => p.coeff i.val) he
  simpa only [Polynomial.coeff_neg,source_seven_polynomial_coeff] using h

theorem source_cubic_actual_conic_coefficient_factor_exists (p : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3)
    (hconic : ∀ u v : ℝ,MvPolynomial.eval (![u^2,u*v,v^2] : Fin 3 → ℝ) p ≤ 0) :
    ∃ a : Fin 4 → ℂ,∀ i : Fin 7,
      sourceConicCubicCoefficients (sourceTernaryCubicCoefficients p) i= -sourceBinaryNormCoefficients a i := by
  obtain ⟨a,ha⟩ := source_cubic_nonpositive_conic_actual_norm_factor p hp hconic
  refine ⟨a,source_conic_norm_seven_coefficient_relations _ a ?_⟩
  intro u v
  rw [← source_ternary_cubic_actual_eval p hp]
  exact ha u v

end CoefficientStability
