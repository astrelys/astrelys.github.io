import CoefficientStability.RectangularSourceSubstitution

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {m N : ℕ}

theorem rectangularLinearPolynomial_partial (B : Matrix (Fin m) (Fin N) ℝ) (i : Fin m) (j : Fin N) :
    pderiv j (rectangularLinearPolynomial B i)=MvPolynomial.C (B i j) := by
  classical
  simp [rectangularLinearPolynomial,pderiv_mul,pderiv_C,pderiv_X,Pi.single_apply,eq_comm]

theorem rectangularSubstitution_partial (B : Matrix (Fin m) (Fin N) ℝ)
    (p : MvPolynomial (Fin m) ℝ) (j : Fin N) :
    pderiv j (rectangularSubstitution B p)=
      ∑ i,MvPolynomial.C (B i j)*rectangularSubstitution B (pderiv i p) := by
  classical
  induction p using MvPolynomial.induction_on with
  | C c => simp [pderiv_C]
  | add p q hp hq => simp only [map_add,hp,hq,mul_add,Finset.sum_add_distrib]
  | mul_X p k hp =>
    rw [map_mul,rectangularSubstitution_X,pderiv_mul,hp,rectangularLinearPolynomial_partial]
    simp only [pderiv_mul,pderiv_X,map_add,map_mul,rectangularSubstitution_X]
    have hsingle (i : Fin m) : rectangularSubstitution B
        ((Pi.single i (1 : MvPolynomial (Fin m) ℝ) : Fin m → MvPolynomial (Fin m) ℝ) k)=if i=k then 1 else 0 := by
      by_cases hik : i=k <;> simp [Pi.single_apply,hik,eq_comm]
    simp only [hsingle,mul_add,Finset.sum_add_distrib]
    have hfirst : (∑ i,C (B i j)*(rectangularSubstitution B (pderiv i p)*rectangularLinearPolynomial B k))=
        (∑ i,C (B i j)*rectangularSubstitution B (pderiv i p))*rectangularLinearPolynomial B k := by
      rw [Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro i hi
      ring
    rw [hfirst]
    have hsecond : (∑ i,C (B i j)*(rectangularSubstitution B p*(if i=k then 1 else 0)))=
        rectangularSubstitution B p*C (B k j) := by
      simp only [mul_ite,mul_one,mul_zero,Finset.sum_ite_eq',Finset.mem_univ,ite_true]
      ring
    rw [hsecond]

def rectangularSourceGradient (B : Matrix (Fin m) (Fin N) ℝ) (t : Fin m → ℝ) (j : Fin N) : ℝ :=
  ∑ i,B i j*t i

theorem rectangularSubstitution_actual_gradient (B : Matrix (Fin m) (Fin N) ℝ)
    (p : MvPolynomial (Fin m) ℝ) (hrow : ∀ i,∑ j,B i j=1) (j : Fin N) :
    MvPolynomial.eval (fun _ => 1) (pderiv j (rectangularSubstitution B p))=
      rectangularSourceGradient B (fun i => MvPolynomial.eval (fun _ => 1) (pderiv i p)) j := by
  rw [rectangularSubstitution_partial,map_sum]
  have he : B.mulVec (fun _ => 1)=(fun _ => 1) := by
    funext i
    simpa only [Matrix.mulVec,dotProduct,mul_one] using hrow i
  simp only [map_mul,eval_C,rectangularSubstitution_eval,he,rectangularSourceGradient]

theorem rectangularSubstitution_actual_hessian (B : Matrix (Fin m) (Fin N) ℝ)
    (p : MvPolynomial (Fin m) ℝ) (hrow : ∀ i,∑ j,B i j=1) (j l : Fin N) :
    MvPolynomial.eval (fun _ => 1) (pderiv j (pderiv l (rectangularSubstitution B p)))=
      ∑ i,∑ k,B i j*B k l*MvPolynomial.eval (fun _ => 1) (pderiv i (pderiv k p)) := by
  rw [rectangularSubstitution_partial]
  simp only [map_sum,pderiv_mul,pderiv_C,zero_mul,zero_add,rectangularSubstitution_partial,Finset.mul_sum]
  have he : B.mulVec (fun _ => 1)=(fun _ => 1) := by
    funext i
    simpa only [Matrix.mulVec,dotProduct,mul_one] using hrow i
  simp only [map_sum,map_mul,eval_C,rectangularSubstitution_eval,he,Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro k hk
  ring

theorem rectangularSubstitution_actual_deficit (B : Matrix (Fin m) (Fin N) ℝ)
    (p : MvPolynomial (Fin m) ℝ) (t : Fin m → ℝ) (d : ℕ)
    (hrow : ∀ i,∑ j,B i j=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) (j l : Fin N) :
    deficitMatrix (rectangularSubstitution B p) (rectangularSourceGradient B t) d j l=
      ∑ i,∑ k,B i j*deficitMatrix p t d i k*B k l := by
  unfold deficitMatrix
  rw [rectangularSubstitution_actual_hessian B p hrow]
  simp only [rectangularSourceGradient,Finset.sum_mul,Finset.mul_sum,Finset.sum_sub_distrib,
    mul_sub,sub_mul,mul_div_assoc,div_mul_eq_mul_div,Finset.sum_div]
  congr 1
  · rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro i hi
    apply Finset.sum_congr rfl
    intro k hk
    ring
  · apply Finset.sum_congr rfl
    intro i hi
    apply Finset.sum_congr rfl
    intro k hk
    ring

end CoefficientStability
