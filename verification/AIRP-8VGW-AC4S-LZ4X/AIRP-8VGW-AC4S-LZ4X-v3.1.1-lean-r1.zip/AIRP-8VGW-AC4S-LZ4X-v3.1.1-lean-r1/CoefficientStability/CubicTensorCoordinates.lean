import CoefficientStability.ActualCubicTensor

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem symmetrizedMultilinear_eq_of_permutation
    (T : MultilinearMap ℝ (fun _ : Fin 3 => Fin n → ℝ) ℝ)
    (hT : ∀ v (s : Equiv.Perm (Fin 3)),T (fun j => v (s j))=T v) :
    symmetrizedMultilinear T=T := by
  ext v
  simp only [symmetrizedMultilinear,MultilinearMap.smul_apply,MultilinearMap.sum_apply,
    MultilinearMap.domDomCongr_apply,smul_eq_mul,hT]
  norm_num [Fintype.card_perm]
  ring

theorem symmetric_cubic_diagonal_unique
    (S T : MultilinearMap ℝ (fun _ : Fin 3 => Fin n → ℝ) ℝ)
    (hS : ∀ v (s : Equiv.Perm (Fin 3)),S (fun j => v (s j))=S v)
    (hT : ∀ v (s : Equiv.Perm (Fin 3)),T (fun j => v (s j))=T v)
    (hd : ∀ x,S (fun _ => x)=T (fun _ => x)) : S=T := by
  rw [← symmetrizedMultilinear_eq_of_permutation S hS,
    ← symmetrizedMultilinear_eq_of_permutation T hT]
  ext v
  simp only [symmetrizedMultilinear_polarization,hd]

theorem actualCentralCubicTensor_bound (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (N : ℕ) (hN : 3≤N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (v : Fin 3 → Fin n → ℝ) :
    |actualCentralCubicTensor p t N v|≤18*Real.sqrt 2*
      (∏ j,deficitSeminorm (deficitMatrix p t N) (v j)) := by
  obtain ⟨S,hdiag,hperm,hbound⟩ := paper_central_cubic_tensor p t N hN hp hnorm hstable hgrad
  have he : actualCentralCubicTensor p t N=S := symmetric_cubic_diagonal_unique _ _
    (actualCentralCubicTensor_permutation p t N) hperm
    (fun x => (actualCentralCubicTensor_diagonal p t N hN hp x).trans (hdiag x).symm)
  rw [he]
  exact hbound v

def factorialMonomialCubic (g : Fin n →₀ ℕ) :
    MultilinearMap ℝ (fun _ : Fin 3 => Fin n → ℝ) ℝ :=
  cubicLinearProduct (exponentLinear g) (exponentLinear g) (exponentLinear g)-
    (∑ i,(g i : ℝ) •
      (cubicLinearProduct (LinearMap.proj i) (LinearMap.proj i) (exponentLinear g)+
        cubicLinearProduct (LinearMap.proj i) (exponentLinear g) (LinearMap.proj i)+
        cubicLinearProduct (exponentLinear g) (LinearMap.proj i) (LinearMap.proj i)))+
    (2 : ℝ) • ∑ i,(g i : ℝ) • cubicLinearProduct (LinearMap.proj i) (LinearMap.proj i) (LinearMap.proj i)

theorem factorialMonomialCubic_apply (g : Fin n →₀ ℕ) (v : Fin 3 → Fin n → ℝ) :
    factorialMonomialCubic g v=
      exponentLinear g (v 0)*exponentLinear g (v 1)*exponentLinear g (v 2)-
        (∑ i,(g i : ℝ)*(v 0 i*v 1 i*exponentLinear g (v 2)+
          v 0 i*exponentLinear g (v 1)*v 2 i+exponentLinear g (v 0)*v 1 i*v 2 i))+
        2*(∑ i,(g i : ℝ)*(v 0 i*v 1 i*v 2 i)) := by
  simp only [factorialMonomialCubic,MultilinearMap.add_apply,MultilinearMap.sub_apply,
    MultilinearMap.sum_apply,MultilinearMap.smul_apply,cubicLinearProduct_apply,
    LinearMap.proj_apply,smul_eq_mul]

theorem cubic_scalar_permutation (L W : Fin 3 → ℝ) (s : Equiv.Perm (Fin 3)) :
    L (s 0)*L (s 1)*L (s 2)=L 0*L 1*L 2 ∧
    W (s 0)*W (s 1)*L (s 2)+W (s 0)*L (s 1)*W (s 2)+L (s 0)*W (s 1)*W (s 2)=
      W 0*W 1*L 2+W 0*L 1*W 2+L 0*W 1*W 2 ∧
    W (s 0)*W (s 1)*W (s 2)=W 0*W 1*W 2 := by
  have h01 : s 0≠s 1 := s.injective.ne (by decide)
  have h02 : s 0≠s 2 := s.injective.ne (by decide)
  have h12 : s 1≠s 2 := s.injective.ne (by decide)
  generalize h0 : s 0=a
  generalize h1 : s 1=b
  generalize h2 : s 2=c
  have hab : a≠b := by simpa only [h0,h1] using h01
  have hac : a≠c := by simpa only [h0,h2] using h02
  have hbc : b≠c := by simpa only [h1,h2] using h12
  fin_cases a <;> fin_cases b <;> fin_cases c
  all_goals first
    | exact (hab rfl).elim
    | exact (hac rfl).elim
    | exact (hbc rfl).elim
    | (refine ⟨?_,?_,?_⟩ <;> simp only [Fin.reduceFinMk,Fin.mk_one,Fin.zero_eta] <;> ring)

theorem factorialMonomialCubic_permutation (g : Fin n →₀ ℕ)
    (v : Fin 3 → Fin n → ℝ) (s : Equiv.Perm (Fin 3)) :
    factorialMonomialCubic g (fun j => v (s j))=factorialMonomialCubic g v := by
  simp only [factorialMonomialCubic_apply]
  have h := cubic_scalar_permutation (fun j => exponentLinear g (v j)) (fun _ => 0) s
  rw [h.1]
  have he (i : Fin n) := cubic_scalar_permutation (fun j => exponentLinear g (v j)) (fun j => v j i) s
  simp_rw [(he _).2.1,(he _).2.2]

end CoefficientStability
