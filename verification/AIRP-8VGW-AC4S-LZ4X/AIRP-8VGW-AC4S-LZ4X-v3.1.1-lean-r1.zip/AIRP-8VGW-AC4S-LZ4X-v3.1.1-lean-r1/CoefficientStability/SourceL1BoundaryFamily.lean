import CoefficientStability.SourceSharpL1Inequality

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1600000

def sourceL1BoundaryS (d : ℝ) := Real.sqrt (d+3*d^2)
def sourceL1BoundaryTraces (d : ℝ) : Fin 3 → ℝ :=
  ![1+(3-2*d)*sourceL1BoundaryS d/2,1-(3-2*d)*sourceL1BoundaryS d/2,1]
def sourceL1BoundaryMatrix (d : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  ![![0,(1+sourceL1BoundaryS d+d)/2,(1-d)*(1+2*sourceL1BoundaryS d)/2],
    ![(1-sourceL1BoundaryS d+d)/2,0,(1-d)*(1-2*sourceL1BoundaryS d)/2],
    ![(1+sourceL1BoundaryS d-d)/2,(1-sourceL1BoundaryS d-d)/2,d]]
def sourceL1ExceptionalTraces : Fin 3 → ℝ := ![1+sourceCubicEpsilon0/2,1-sourceCubicEpsilon0/2,1]

theorem source_l1_zero_height_profile (u v : ℝ) (hu : 0 < u) (hv : 0 < v) (huv : u+v < 1)
    (hh : sourceL1ChartHeight u v=0) :
    sourceL1ChartTraces u v=sourceL1BoundaryTraces (sourceL1ChartD u v) ∧
      sourceL1ChartMatrix u v=sourceL1BoundaryMatrix (sourceL1ChartD u v) := by
  let d := sourceL1ChartD u v
  let s := sourceL1BoundaryS d
  have hheight : v-u=2*d := by dsimp [sourceL1ChartHeight] at hh;dsimp [d];linarith
  have hw : (u+v)/2=s := by
    have h := source_l1_chart_sqrt_identity u v hu hv huv
    rw [hh] at h
    norm_num [sourceCubicS] at h
    simpa [s,d,sourceL1BoundaryS,add_comm] using h.symm
  have ha : (1+v)/2=(1+s+d)/2 := by linarith
  have hb : (1-u)/2=(1-s+d)/2 := by linarith
  have hsum := source_l1_chart_trace_sum u v hu hv huv
  norm_num [Fin.sum_univ_succ] at hsum
  have ht2 : sourceL1ChartTraces u v 2=1 := by
    have h := (source_l1_chart_marginal_signs u v hu hv huv).2.2
    rw [hh] at h
    linarith
  have hdiff : sourceL1ChartTraces u v 0-sourceL1ChartTraces u v 1=(3-2*d)*s := by
    norm_num [sourceL1ChartTraces,sourceTernaryStationaryTraces]
    dsimp [d]
    rw [← hw]
    ring
  have ht : sourceL1ChartTraces u v=sourceL1BoundaryTraces d := by
    funext i
    fin_cases i
    · change sourceL1ChartTraces u v 0=1+(3-2*d)*s/2
      linarith
    · change sourceL1ChartTraces u v 1=1-(3-2*d)*s/2
      linarith
    · exact ht2
  refine ⟨ht,?_⟩
  change sourceTernarySeparatedZeros (sourceL1ChartTraces u v) ((1+v)/2) ((1-u)/2)=sourceL1BoundaryMatrix d
  rw [ht,ha,hb]
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [sourceTernarySeparatedZeros,sourceTernaryOneZero,sourceL1BoundaryTraces,sourceL1BoundaryMatrix] <;>
    dsimp [s] at * <;> ring

theorem source_l1_boundary_dstar_trace_profile :
    sourceL1BoundaryTraces sourceCubicDStar=sourceL1ExceptionalTraces := by
  have h := source_cubic_dstar_distance_exact
  norm_num [sourceCubicDistance,sourceCubicS] at h
  have he : (3-2*sourceCubicDStar)*sourceL1BoundaryS sourceCubicDStar=sourceCubicEpsilon0 := by
    simpa [sourceL1BoundaryS,add_comm] using h
  funext i
  fin_cases i <;> norm_num [sourceL1BoundaryTraces,sourceL1ExceptionalTraces] <;> linarith

theorem source_l1_boundary_family_feasible (d : ℝ) (hd : 0 < d) (hd8 : d < 1/8) :
    sourceL1BoundaryMatrix d ∈ sourceTransportationPolytope (sourceL1BoundaryTraces d) ∧
      (∀ q ∈ sourceSeparatedEntrySet,0 < sourceL1BoundaryMatrix d q.1 q.2) := by
  have hsq : (sourceL1BoundaryS d)^2=d+3*d^2 := Real.sq_sqrt (by positivity)
  have hs : 0 ≤ sourceL1BoundaryS d := Real.sqrt_nonneg _
  have hs2 : sourceL1BoundaryS d < 1/2 := by
    have hd2 : d^2 < 1/64 := by nlinarith
    nlinarith
  have hp : ∀ q ∈ sourceSeparatedEntrySet,0 < sourceL1BoundaryMatrix d q.1 q.2 := by
    rintro ⟨i,j⟩ hq
    fin_cases i <;> fin_cases j <;> norm_num [sourceSeparatedEntrySet] at hq
    all_goals norm_num [sourceL1BoundaryMatrix]
    all_goals first | positivity | linarith | exact mul_pos (by linarith) (by linarith)
  refine ⟨⟨?_,?_,?_⟩,hp⟩
  · intro i j
    by_cases hq : (i,j) ∈ sourceSeparatedEntrySet
    · exact (hp _ hq).le
    · fin_cases i <;> fin_cases j <;> norm_num [sourceSeparatedEntrySet] at hq
      all_goals norm_num [sourceL1BoundaryMatrix]
  · intro i
    fin_cases i <;> norm_num [sourceL1BoundaryMatrix,sourceL1BoundaryTraces,Fin.sum_univ_succ] <;> ring
  · intro j
    fin_cases j <;> norm_num [sourceL1BoundaryMatrix,Fin.sum_univ_succ] <;> ring

end CoefficientStability
