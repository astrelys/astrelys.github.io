import CoefficientStability.PositiveDirectionFactors

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem lineRestriction_coefficient_continuous (p : MvPolynomial (Fin n) ℝ) :
    ∀ k,Continuous (fun x : Fin n → ℝ => (lineRestriction p x).coeff k) := by
  induction p using MvPolynomial.induction_on with
  | C c =>
    intro k
    simpa only [lineRestriction,MvPolynomial.eval₂_C] using
      (continuous_const : Continuous (fun x : Fin n → ℝ => (Polynomial.C c).coeff k))
  | add p q hp hq =>
    intro k
    convert! (hp k).add (hq k) using 1
    funext x
    simp only [lineRestriction,MvPolynomial.eval₂_add,Polynomial.coeff_add] <;> rfl
  | mul_X p i hp =>
    intro k
    have he (x : Fin n → ℝ) : lineRestriction (p*MvPolynomial.X i) x=
        lineRestriction p x*Polynomial.X+lineRestriction p x*Polynomial.C (x i) := by
      simp only [lineRestriction,MvPolynomial.eval₂_mul,MvPolynomial.eval₂_X,mul_add]
    simp only [he,Polynomial.coeff_add,Polynomial.coeff_mul_C]
    cases k with
    | zero =>
      simp only [Polynomial.coeff_mul_X_zero,zero_add]
      exact (hp 0).mul (continuous_apply i)
    | succ k =>
      simp only [Polynomial.coeff_mul_X]
      exact (hp k).add ((hp (k+1)).mul (continuous_apply i))

def coefficientPositiveCone (p : MvPolynomial (Fin n) ℝ) (N : ℕ) : Set (Fin n → ℝ) :=
  {x | ∀ k : Fin (N+1),0<(lineRestriction p x).coeff k.val}

theorem coefficientPositiveCone_isOpen (p : MvPolynomial (Fin n) ℝ) (N : ℕ) :
    IsOpen (coefficientPositiveCone p N) := by
  have h (k : Fin (N+1)) : IsOpen {x : Fin n → ℝ | 0<(lineRestriction p x).coeff k.val} :=
    isOpen_lt continuous_const (lineRestriction_coefficient_continuous p k.val)
  simpa only [coefficientPositiveCone,Set.ofPred_forall] using isOpen_iInter_of_finite h

end CoefficientStability
