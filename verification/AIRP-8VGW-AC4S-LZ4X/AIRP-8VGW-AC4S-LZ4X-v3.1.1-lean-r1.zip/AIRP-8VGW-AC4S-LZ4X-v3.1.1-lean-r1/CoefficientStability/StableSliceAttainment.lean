import CoefficientStability.PositiveFactorAttainment
import CoefficientStability.DerivativeCapacityMinimizer

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem stable_positive_pure_slice_capacity_attained
    (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (hN : 2≤N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p) (hc : ∀ g,0≤p.coeff g)
    (x : Fin n → ℝ) (hx : ∀ k,0<x k) (i j : Fin n) (hji : j≠i)
    (hpi : 0<p.coeff (Finsupp.single i N)) (hpj : 0<p.coeff (Finsupp.single j N)) :
    ∃ zstar : ℝ,0<zstar ∧
      (∀ z : ℝ,0<z → (realCoordinateRestriction x i p).eval zstar/zstar≤
        (realCoordinateRestriction x i p).eval z/z) ∧
      positiveDomainCapacity (realCoordinateRestriction x i p)=
        (realCoordinateRestriction x i p).eval zstar/zstar := by
  have htop := homogeneous_realCoordinateRestriction_top_coeff p N hp x i
  have hdegree : (realCoordinateRestriction x i p).natDegree=N :=
    Polynomial.natDegree_eq_of_le_of_coeff_ne_zero
      (homogeneous_realCoordinateRestriction_degree_le p N hp x i)
      (by rw [htop];exact ne_of_gt hpi)
  have hpos := positive_stable_realCoordinateRestriction p hs hc x hx i
  have hzero : 0<(realCoordinateRestriction x i p).eval 0 := by
    rw [realCoordinateRestriction_eval]
    exact paper_capacity_section_constant_pos p x N i j hji hc hx hpj
  exact positive_split_capacity_attained _ hpos.2.1 hpos.2.2 hzero (by omega)

theorem balanced_last_slice_capacity_minimizers (hn : 3≤n+1)
    (p : MvPolynomial (Fin (n+1)) ℝ) (hp : p.IsHomogeneous (n+1))
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=1)
    (hL : p.coeff (squarefreeExponent (n+1))≤sourceVn (n+1)*(1+capacityEta (n+1)/2)) :
    ∃ y : Fin n → ℝ,∃ zstar : ℝ,(∀ j,0<y j) ∧ (∏ j,y j)=1 ∧ 0<zstar ∧
      (∀ z : ℝ,0<z → (realCoordinateRestriction (Fin.lastCases 1 y) (Fin.last n) p).eval zstar/zstar≤
        (realCoordinateRestriction (Fin.lastCases 1 y) (Fin.last n) p).eval z/z) ∧
      positiveDomainCapacity (realCoordinateRestriction (Fin.lastCases 1 y) (Fin.last n) p)=
        (realCoordinateRestriction (Fin.lastCases 1 y) (Fin.last n) p).eval zstar/zstar ∧
      1≤positiveDomainCapacity (realCoordinateRestriction (Fin.lastCases 1 y) (Fin.last n) p) ∧
      positiveDomainCapacity (realCoordinateRestriction (Fin.lastCases 1 y) (Fin.last n) p)≤
        p.coeff (squarefreeExponent (n+1))/sourceVn (n+1) := by
  have hc := normalized_homogeneous_stable_coeff_nonneg p (n+1) hp hs hnorm
  have hpp := balanced_nearminimal_pure_coeff_pos (n+1) hn p hp hs hnorm hgrad hL
  obtain ⟨y,hy,hyprod,hycap,hybound⟩ := balanced_last_elimination_capacity_minimizer hn p hp hs hnorm hgrad hL
  have hxy : ∀ k : Fin (n+1),(0 : ℝ)<Fin.lastCases 1 y k := by
    intro k
    refine Fin.lastCases ?_ (fun j => ?_) k
    · simp
    · simpa only [Fin.lastCases_castSucc] using hy j
  let j : Fin n := ⟨0,by omega⟩
  obtain ⟨z,hz,hmin,hcap⟩ := stable_positive_pure_slice_capacity_attained p (n+1) (by omega)
    hp hs hc (Fin.lastCases 1 y) hxy (Fin.last n) j.castSucc (Fin.castSucc_ne_last j) (hpp _) (hpp _)
  have hlower := multivariate_capacity_slice_lower p hc y hy
  rw [paper_balanced_capacity_one p hc hnorm hgrad,hyprod,mul_one] at hlower
  have hupper := positive_stable_coordinate_capacity_cutoff p hs hc (Fin.lastCases 1 y) hxy
    (Fin.last n) (n+1) (homogeneous_realCoordinateRestriction_degree_le p (n+1) hp _ _)
  dsimp only at hupper
  rw [← last_elimination_restriction_derivative] at hupper
  have hV := sourceVn_pos (by omega : 0<n)
  have hg := capacityG_pos (by omega : 2≤n+1)
  have hup : positiveDomainCapacity (realCoordinateRestriction (Fin.lastCases 1 y) (Fin.last n) p)≤
      p.coeff (squarefreeExponent (n+1))/sourceVn (n+1) := by
    apply (le_div_iff₀ (sourceVn_pos (by omega : 0<n+1))).mpr
    rw [sourceVn_capacityG_recurrence]
    have hh := mul_le_mul_of_nonneg_left hupper hV.le
    have hb := (le_div_iff₀ hV).mp hybound
    nlinarith
  exact ⟨y,z,hy,hyprod,hz,hmin,hcap,hlower,hup⟩

end CoefficientStability
