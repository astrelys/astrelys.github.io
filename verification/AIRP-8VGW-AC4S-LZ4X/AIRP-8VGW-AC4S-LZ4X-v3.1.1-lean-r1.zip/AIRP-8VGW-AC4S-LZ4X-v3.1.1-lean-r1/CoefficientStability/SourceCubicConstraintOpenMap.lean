import CoefficientStability.SourceCubicConstraintRange
import Mathlib.Topology.Algebra.Module.FiniteDimension

noncomputable section
open scoped BigOperators Matrix Matrix.Norms.Elementwise
namespace CoefficientStability
set_option maxHeartbeats 1800000
set_option backward.isDefEq.respectTransparency false

theorem source_cubic_constraint_open : IsOpenMap sourceCubicConstraintMap :=
  LinearMap.isOpenMap_of_finiteDimensional _ source_cubic_constraint_surjective

def sourceCubicAugmentedConstraintMap (g : Module.Dual ℝ SourceCubicHermitianTuples) :
    (SourceCubicHermitianTuples × ℝ) →ₗ[ℝ] (SourceCubicConstraintSpace × ℝ) where
  toFun q := (sourceCubicConstraintMap q.1,g q.1+q.2)
  map_add' q r := by
    apply Prod.ext
    · simp
    · simp
      ring
  map_smul' a q := by
    apply Prod.ext
    · simp
    · simp
      ring

theorem source_cubic_augmented_constraint_surjective (g : Module.Dual ℝ SourceCubicHermitianTuples) :
    Function.Surjective (sourceCubicAugmentedConstraintMap g) := by
  intro q
  refine ⟨(sourceCubicConstraintRightInverse q.1,q.2-g (sourceCubicConstraintRightInverse q.1)),?_⟩
  apply Prod.ext
  · exact source_cubic_constraint_right_inverse q.1
  · change g (sourceCubicConstraintRightInverse q.1)+(q.2-g (sourceCubicConstraintRightInverse q.1))=q.2
    ring

theorem source_cubic_augmented_constraint_open (g : Module.Dual ℝ SourceCubicHermitianTuples) :
    IsOpenMap (sourceCubicAugmentedConstraintMap g) :=
  LinearMap.isOpenMap_of_finiteDimensional _ (source_cubic_augmented_constraint_surjective g)

end CoefficientStability
