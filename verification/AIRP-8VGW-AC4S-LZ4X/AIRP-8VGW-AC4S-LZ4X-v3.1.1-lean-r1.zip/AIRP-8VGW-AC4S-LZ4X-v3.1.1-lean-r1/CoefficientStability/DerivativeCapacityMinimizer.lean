import CoefficientStability.LogCapacityStationarity
import CoefficientStability.DerivativePurePositivity
import CoefficientStability.GurvitsCapacityTheorem

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem last_elimination_product_one_capacity_minimizer (hn : 0<n)
    (p : MvPolynomial (Fin (n+1)) ℝ) (hp : p.IsHomogeneous (n+1))
    (hs : UpperHalfPlaneZeroFree p) (hc : ∀ g,0≤p.coeff g)
    (hpure : ∀ i,0<p.coeff (Finsupp.single i (n+1))) :
    ∃ y : Fin n → ℝ,(∀ j,0<y j) ∧ (∏ j,y j)=1 ∧
      MvPolynomial.eval y (lastDerivativeElimination p)=multivariatePositiveCapacity (lastDerivativeElimination p) ∧
      MvPolynomial.eval y (lastDerivativeElimination p)≤p.coeff (squarefreeExponent (n+1))/sourceVn n := by
  let q := lastDerivativeElimination p
  have hqhom : q.IsHomogeneous n := lastDerivativeElimination_homogeneous p n hp
  have hqc : ∀ g,0≤q.coeff g := nonnegative_stable_derivative_elimination_coeff p n hp hs hc
  have hqp : ∀ j,0<q.coeff (Finsupp.single j n) := lastDerivativeElimination_pure_coeff_pos p hp hs hc hpure
  obtain ⟨u,hu,hcap⟩ := positive_pure_capacity_centered_field hn q hqhom hqc hqp
  have hG := gurvits_capacity_lower_zero_or_stable n q hqhom hqc
    (stable_last_derivative_elimination_zero_or_stable p hs)
  rw [lastDerivativeElimination_squarefree_coeff] at hG
  refine ⟨fun j => Real.exp (u j),fun j => Real.exp_pos _,zero_sum_exp_product u hu,hcap.symm,?_⟩
  rw [← hcap]
  apply (le_div_iff₀ (sourceVn_pos hn)).mpr
  simpa only [mul_comm] using hG

theorem balanced_last_elimination_capacity_minimizer (hn : 3≤n+1)
    (p : MvPolynomial (Fin (n+1)) ℝ) (hp : p.IsHomogeneous (n+1))
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=1)
    (hL : p.coeff (squarefreeExponent (n+1))≤sourceVn (n+1)*(1+capacityEta (n+1)/2)) :
    ∃ y : Fin n → ℝ,(∀ j,0<y j) ∧ (∏ j,y j)=1 ∧
      MvPolynomial.eval y (lastDerivativeElimination p)=multivariatePositiveCapacity (lastDerivativeElimination p) ∧
      MvPolynomial.eval y (lastDerivativeElimination p)≤p.coeff (squarefreeExponent (n+1))/sourceVn n := by
  exact last_elimination_product_one_capacity_minimizer (by omega) p hp hs
    (normalized_homogeneous_stable_coeff_nonneg p (n+1) hp hs hnorm)
    (balanced_nearminimal_pure_coeff_pos (n+1) hn p hp hs hnorm hgrad hL)

end CoefficientStability
