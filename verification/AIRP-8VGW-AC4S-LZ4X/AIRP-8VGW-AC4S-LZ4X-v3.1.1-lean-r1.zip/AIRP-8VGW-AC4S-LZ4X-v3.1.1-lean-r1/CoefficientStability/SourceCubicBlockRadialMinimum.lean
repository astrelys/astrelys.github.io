import CoefficientStability.SourceCubicBlockRadialCurve

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 2800000
set_option backward.isDefEq.respectTransparency false

theorem source_actual_feasible_right_curve_derivative {E : Type*} [TopologicalSpace E]
    (f : E → ℝ) (S : Set E) (x : E) (γ : ℝ → E) (d : ℝ)
    (hcont : Continuous γ) (hzero : γ 0=x) (hmap : ∀ r ∈ Set.Icc 0 1,γ r ∈ S)
    (hm : IsLocalMinOn f S x) (hd : HasDerivAt (fun r => f (γ r)) d 0) : 0 ≤ d := by
  have hm0 : IsLocalMinOn f S (γ 0) := by rw [hzero];exact hm
  have hc := hm0.comp_continuousOn hmap hcont.continuousOn (show (0 : ℝ) ∈ Set.Icc 0 1 by norm_num)
  exact source_right_local_minimum_derivative_nonnegative _ _ hc hd

theorem source_cubic_block_local_minimum_radial_energy_nonpositive (t a b : Fin 3 → ℝ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hV : ∀ i,(V i).IsHermitian)
    (ht : ∀ i,Matrix.trace (V i)=0) (hs : (∑ i,V i)=0)
    (hA : sourceCubicBlockTuple a b V ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (sourceCubicBlockTuple a b V)) :
    (∑ i,(1-2*a i)*sourceTwoTraceQuadratic (V i)) ≤ 0 := by
  let γ : ℝ → (Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) := fun r => sourceCubicBlockTuple a b (sourceBlockRadial V r)
  have hc : Continuous γ := source_cubic_block_curve_continuous a b (sourceBlockRadial V) (source_block_radial_continuous V)
  have hz : γ 0=sourceCubicBlockTuple a b V := by simp [γ]
  have hf (r : ℝ) (hr : r ∈ Set.Icc 0 1) : γ r ∈ hermitianFeasibleTuples t :=
    source_cubic_block_radial_feasible t a b V hV ht hs hA r hr
  have hd := source_cubic_block_radial_hasDerivAt a b V ht hs hA.2
  have hn := source_actual_feasible_right_curve_derivative hermitianMixedObjective (hermitianFeasibleTuples t)
    (sourceCubicBlockTuple a b V) γ _ hc hz hf hm hd
  linarith

theorem source_cubic_block_nonnegative_radial_energy_zero (t a b : Fin 3 → ℝ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hV : ∀ i,(V i).IsHermitian)
    (ht : ∀ i,Matrix.trace (V i)=0) (hs : (∑ i,V i)=0)
    (hA : sourceCubicBlockTuple a b V ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (sourceCubicBlockTuple a b V))
    (ha : ∀ i,a i ≤ 1/2) : (∑ i,(1-2*a i)*sourceTwoTraceQuadratic (V i))=0 := by
  have hle := source_cubic_block_local_minimum_radial_energy_nonpositive t a b V hV ht hs hA hm
  have hge : 0 ≤ ∑ i,(1-2*a i)*sourceTwoTraceQuadratic (V i) :=
    Finset.sum_nonneg (fun i _ => mul_nonneg (by linarith [ha i]) (source_two_trace_quadratic_nonnegative (V i) (hV i)))
  exact le_antisymm hle hge

theorem source_cubic_block_positive_coefficient_vanishes (t a b : Fin 3 → ℝ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hV : ∀ i,(V i).IsHermitian)
    (ht : ∀ i,Matrix.trace (V i)=0) (hs : (∑ i,V i)=0)
    (hA : sourceCubicBlockTuple a b V ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (sourceCubicBlockTuple a b V))
    (ha : ∀ i,a i ≤ 1/2) : ∀ i,0 < 1-2*a i → V i=0 := by
  have hz := source_cubic_block_nonnegative_radial_energy_zero t a b V hV ht hs hA hm ha
  have hn : ∀ i ∈ Finset.univ,0 ≤ (1-2*a i)*sourceTwoTraceQuadratic (V i) :=
    fun i _ => mul_nonneg (by linarith [ha i]) (source_two_trace_quadratic_nonnegative (V i) (hV i))
  have he := (Finset.sum_eq_zero_iff_of_nonneg hn).mp hz
  intro i hi
  have hq := (mul_eq_zero.mp (he i (Finset.mem_univ i))).resolve_left (ne_of_gt hi)
  exact (source_two_trace_quadratic_zero_iff (V i) (hV i)).mp hq

end CoefficientStability
