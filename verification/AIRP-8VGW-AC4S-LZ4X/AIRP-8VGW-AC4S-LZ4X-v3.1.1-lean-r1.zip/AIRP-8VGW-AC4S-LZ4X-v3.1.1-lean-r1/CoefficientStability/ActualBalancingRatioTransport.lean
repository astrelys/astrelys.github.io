import CoefficientStability.ReciprocalEuclideanBounds
import CoefficientStability.ActualBalancingDeficit

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem actual_ratio_path_hasDerivAt (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ)
    (s : ℝ) (hn : 3 ≤ n) (hp : p.IsHomogeneous n) (hc : ∀ g,0 ≤ p.coeff g)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hL : 0 < p.coeff (squarefreeExponent n))
    (ht : ∀ i,0 < tiltedMoment p (s • u) i) :
    HasDerivAt (fun z : ℝ => tiltLogRatio p (sourceVn n) (z • u))
      (2*(deficitMatrix (tiltedPolynomial p (s • u)) (tiltedMoment p (s • u)) n).toBilin'
        u (fun i => 1/tiltedMoment p (s • u) i-1)) s := by
  have hZ := ne_of_gt (tiltPartition_pos p (s • u) hc hnorm)
  have hd := (tiltLogRatio_differentiableAt p (s • u) hZ (sourceVn n)
    (ne_of_gt (sourceVn_pos (by omega))) (ne_of_gt (tilted_allones_coefficient_pos p (s • u) hc hnorm hL))
    (fun i => ne_of_gt (ht i))).hasFDerivAt
  have hcurve : HasDerivAt (fun z : ℝ => z • u) u s := by
    simpa only [one_smul,id_eq] using (hasDerivAt_id s).smul_const u
  have hh := hd.comp_hasDerivAt s hcurve
  rw [paper_ratio_gradient_all_directions p (s • u) u hp (by omega) hc hnorm hL ht] at hh
  convert! hh using 1
  simp only [Matrix.toBilin'_apply',dotProduct,Pi.smul_apply,smul_eq_mul,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i hi
  ring

theorem actual_balancing_ratio_transport (p : MvPolynomial (Fin n) ℝ)
    (u : Fin n → ℝ) (hn : 3 ≤ n) (hp : p.IsHomogeneous n)
    (hc : ∀ g,0 ≤ p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) (hL : 0 < p.coeff (squarefreeExponent n))
    (hbal : ∀ i,tiltedMoment p u i=1)
    (hsmall : (n : ℝ)*Real.sqrt (∑ i,u i^2) ≤ 1/24) :
    |tiltLogRatio p (sourceVn n) 0-tiltLogRatio p (sourceVn n) u| ≤
      16*(n : ℝ)*(∑ i,u i^2)*actualTiltDeficit p u := by
  let R := Real.sqrt (∑ i,u i^2)
  let d := fun s : ℝ => 2*(deficitMatrix (tiltedPolynomial p (s • u)) (tiltedMoment p (s • u)) n).toBilin'
    u (fun i => 1/tiltedMoment p (s • u) i-1)
  have hδ := (actual_tilt_deficit_source_bounds p u (by omega) hp hc hnorm hs).2.2.1
  change 0 ≤ actualTiltDeficit p u at hδ
  have hR : 0 ≤ R := Real.sqrt_nonneg _
  have hR2 : R^2=∑ i,u i^2 := Real.sq_sqrt (Finset.sum_nonneg (fun i hi => sq_nonneg _))
  have hD (s : ℝ) (hseg : s ∈ Set.Icc (0 : ℝ) 1) :
      HasDerivAt (fun z : ℝ => tiltLogRatio p (sourceVn n) (z • u)) (d s) s := by
    have hpos := (actual_balancing_path_reciprocal_bound p u hn hp hc hnorm hs hbal hsmall s hseg).1
    exact actual_ratio_path_hasDerivAt p u s hn hp hc hnorm hL (fun i => lt_of_lt_of_le (by norm_num) (hpos i))
  have hbound (s : ℝ) (hseg : s ∈ Set.Icc (0 : ℝ) 1) :
      |d s| ≤ 16*(n : ℝ)*(∑ i,u i^2)*actualTiltDeficit p u := by
    have hQ := (actual_tilt_relative_ingredients p (s • u) hn hp hc hnorm hs).1
    have hb := psd_bilinear_trace_euclidean_bound _ hQ u (fun i => 1/tiltedMoment p (s • u) i-1)
    rw [trace_deficitMatrix] at hb
    change |(deficitMatrix (tiltedPolynomial p (s • u)) (tiltedMoment p (s • u)) n).toBilin' u (fun i => 1/tiltedMoment p (s • u) i-1)| ≤ actualTiltDeficit p (s • u)*R*Real.sqrt (∑ i,(1/tiltedMoment p (s • u) i-1)^2) at hb
    have hrec := (actual_balancing_path_reciprocal_bound p u hn hp hc hnorm hs hbal hsmall s hseg).2
    have hrec' : Real.sqrt (∑ i,(1/tiltedMoment p (s • u) i-1)^2) ≤ 2*(n : ℝ)*R := by
      have hnonneg : 0 ≤ 2*(n : ℝ)*R := by positivity
      nlinarith [mul_nonneg hseg.1 hnonneg]
    have hdef := actual_balancing_path_deficit_bound p u hn hp hc hnorm hs hsmall s hseg
    have hδs := (actual_tilt_deficit_source_bounds p (s • u) (by omega) hp hc hnorm hs).2.2.1
    calc
      |d s| = 2*|(deficitMatrix (tiltedPolynomial p (s • u)) (tiltedMoment p (s • u)) n).toBilin'
          u (fun i => 1/tiltedMoment p (s • u) i-1)| := by dsimp [d];rw [abs_mul];norm_num
      _ ≤ 2*(actualTiltDeficit p (s • u)*R*Real.sqrt (∑ i,(1/tiltedMoment p (s • u) i-1)^2)) := mul_le_mul_of_nonneg_left hb (by norm_num)
      _ ≤ 2*((2*actualTiltDeficit p u)*R*(2*(n : ℝ)*R)) := by gcongr
      _ ≤ 16*(n : ℝ)*(∑ i,u i^2)*actualTiltDeficit p u := by rw [← hR2];nlinarith [mul_nonneg (mul_nonneg (by positivity : 0 ≤ (n : ℝ)) (sq_nonneg R)) hδ]
  have hh := norm_image_sub_le_of_norm_deriv_le_segment_01'
    (fun s hs => (hD s hs).hasDerivWithinAt)
    (fun s hs => by simpa only [Real.norm_eq_abs] using hbound s ⟨hs.1,hs.2.le⟩)
  simpa only [one_smul,zero_smul,Real.norm_eq_abs,abs_sub_comm] using hh

end CoefficientStability
