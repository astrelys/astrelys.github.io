import CoefficientStability.SourceCubicDepressedNormalForm

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000

theorem source_nonnegative_binary_quadratic_exact_conditions (a b c : ℝ)
    (h : ∀ x y : ℝ,0≤a*x^2+2*b*x*y+c*y^2) :
    0≤a ∧ 0≤c ∧ 0≤a*c-b^2 ∧ (a=0 → b=0) := by
  have ha : 0≤a := by simpa using h 1 0
  have hc : 0≤c := by simpa using h 0 1
  have hb0 (ha0 : a=0) : b=0 := by
    by_contra hb
    have hh := h (-(c+1)/(2*b)) 1
    have he : a*(-(c+1)/(2*b))^2+2*b*(-(c+1)/(2*b))*1+c*1^2= -1 := by
      rw [ha0]
      field_simp [hb] <;> ring
    rw [he] at hh
    linarith
  refine ⟨ha,hc,?_,hb0⟩
  by_cases ha0 : a=0
  · rw [ha0,hb0 ha0]
    norm_num
  · have hap : 0<a := lt_of_le_of_ne ha (Ne.symm ha0)
    have hh := h (-b/a) 1
    have he : a*(-b/a)^2+2*b*(-b/a)*1+c*1^2=(a*c-b^2)/a := by
      field_simp [ha0] <;> ring
    rw [he] at hh
    simpa only [div_mul_cancel₀ _ ha0] using (mul_nonneg hh ha)

theorem source_binary_rank_one_exact_quadratic (a b c : ℝ)
    (ha : a≠0) (hd : a*c-b^2=0) (x y : ℝ) :
    a*x^2+2*b*x*y+c*y^2=a*(x+(b/a)*y)^2 := by
  have hc : c=b^2/a := by
    apply (eq_div_iff ha).mpr
    nlinarith only [hd]
  rw [hc]
  field_simp [ha] <;> ring

theorem source_stable_cubic_actual_binary_quadratic_conditions
    (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ)
    (hp : p.IsHomogeneous 3) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) :
    0≤deficitMatrix p t 3 0 0 ∧ 0≤deficitMatrix p t 3 1 1 ∧
      0≤deficitMatrix p t 3 0 0*deficitMatrix p t 3 1 1-(deficitMatrix p t 3 0 1)^2 ∧
      (deficitMatrix p t 3 0 0=0 → deficitMatrix p t 3 0 1=0) := by
  apply source_nonnegative_binary_quadratic_exact_conditions
  intro x y
  have h := deficitMatrix_quadratic_nonneg p t 3 (![x,y,0] : Fin 3 → ℝ) (by omega) hp hn hs hg
  rwa [source_binary_restricted_quadratic_exact _ (deficitMatrix_isHermitian p t 3)] at h

end CoefficientStability
