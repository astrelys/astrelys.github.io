import CoefficientStability.ActualCrossingPolynomial
import CoefficientStability.SmoothedRootCrossings

noncomputable section
namespace CoefficientStability
variable {n N : ℕ}

theorem positiveSpectralCone_eval_pos (p : MvPolynomial (Fin n) ℝ) (hp : p.IsHomogeneous N)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N) : 0<MvPolynomial.eval b p := by
  rw [positiveSpectralCone_eq_coefficientPositiveCone p N hp hs hnorm] at hb
  have h := hb ⟨0,by omega⟩
  simpa [Polynomial.coeff_zero_eq_eval_zero,eval_lineRestriction_real] using h

theorem polynomial_splits_of_degree_many_distinct_real_zeroes (P : Polynomial ℝ) (hP : P≠0)
    (hd : P.natDegree=N) (times : Fin N → ℝ) (hinj : Function.Injective times)
    (hz : ∀ i,(P.eval (times i))=0) : P.Splits := by
  classical
  let f : Fin N → {r : ℝ // r∈P.roots.toFinset} := fun i =>
    ⟨times i,by simpa using (Polynomial.mem_roots hP).mpr (hz i)⟩
  have hf : Function.Injective f := fun i j hij => hinj (congrArg Subtype.val hij)
  have hcard : N≤P.roots.toFinset.card := by
    simpa using Fintype.card_le_of_injective f hf
  apply Polynomial.splits_iff_card_roots.mpr
  apply le_antisymm (Polynomial.card_roots' P)
  rw [hd]
  exact hcard.trans (Multiset.toFinset_card_le _)

theorem actualCrossingPolynomial_exact_degree (p : MvPolynomial (Fin n) ℝ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (ε : ℝ) (x b : Fin n → ℝ) (hb : MvPolynomial.eval b p≠0) :
    (actualCrossingPolynomial p N ε x b).natDegree=N ∧
      (actualCrossingPolynomial p N ε x b).leadingCoeff=MvPolynomial.eval b p := by
  have h := actualCrossingPolynomial_coeff_degree p N hN hp ε x b
  have hd := Polynomial.natDegree_eq_of_le_of_coeff_ne_zero h.1 (h.2.trans_ne hb)
  exact ⟨hd,by rw [Polynomial.leadingCoeff,hd,h.2]⟩

theorem actualCrossingPolynomial_splits_nonzero (p : MvPolynomial (Fin n) ℝ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N) (x : Fin n → ℝ)
    (ε : ℝ) (hε : ε≠0) : (actualCrossingPolynomial p N ε x b).Splits := by
  have hbpos := positiveSpectralCone_eval_pos p hp hs hnorm b hb
  have hdegree := actualCrossingPolynomial_exact_degree p hN hp ε x b (ne_of_gt hbpos)
  have hne : actualCrossingPolynomial p N ε x b≠0 := by
    intro hz
    have h := (actualCrossingPolynomial_coeff_degree p N hN hp ε x b).2
    rw [hz,Polynomial.coeff_zero] at h
    exact (ne_of_gt hbpos) h.symm
  obtain ⟨times,hinj,hzero⟩ := source_smoothed_distinct_real_crossings p hp hs hnorm b hb x ε hε 0
  apply polynomial_splits_of_degree_many_distinct_real_zeroes _ hne hdegree.1 times hinj
  intro i
  rw [actualCrossingPolynomial_eval]
  exact hzero i

end CoefficientStability
