import CoefficientStability.RankOneInverseRecovery

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem homogeneous_monomial_matrixSubstitution_nonnegative (q : MvPolynomial (Fin n) ℝ)
    (hq : q.IsHomogeneous n) (hc : ∀ g,0≤q.coeff g) (B : Matrix (Fin n) (Fin n) ℝ)
    (hB : ∀ i j,0≤B i j) (g : Fin n →₀ ℕ) (hg : g∈q.support) (d : Fin n →₀ ℕ) :
    0≤(matrixSubstitution B (MvPolynomial.monomial g (q.coeff g))).coeff d := by
  classical
  obtain ⟨w,hw⟩ := monomial_exists_word g n (homogeneous_mass q n hq g hg)
  have hword : MvPolynomial.monomial g (1 : ℝ)=∏ j : Fin n,MvPolynomial.X (w j) := by
    apply MvPolynomial.funext
    intro x
    simpa only [map_prod,MvPolynomial.eval_X] using hw x
  have hscalar : MvPolynomial.monomial g (q.coeff g)=MvPolynomial.C (q.coeff g)*MvPolynomial.monomial g 1 := by
    rw [MvPolynomial.C_mul_monomial,mul_one]
  have hmatrix : matrixSubstitution B (MvPolynomial.monomial g (q.coeff g))=
      MvPolynomial.C (q.coeff g)*diagonalPencilPolynomial (fun r i => B (w r) i) := by
    rw [hscalar,map_mul,matrixSubstitution_C,hword,map_prod]
    simp only [matrixSubstitution_X]
    rw [diagonalPencilPolynomial_eq_product]
    rfl
  rw [hmatrix,MvPolynomial.coeff_C_mul]
  exact mul_nonneg (hc g) (diagonalPolynomial_coeff_nonnegative _ (fun r i => hB (w r) i) d)

theorem homogeneous_matrixSubstitution_coeff_nonnegative (q : MvPolynomial (Fin n) ℝ)
    (hq : q.IsHomogeneous n) (hc : ∀ g,0≤q.coeff g) (B : Matrix (Fin n) (Fin n) ℝ)
    (hB : ∀ i j,0≤B i j) (d : Fin n →₀ ℕ) : 0≤(matrixSubstitution B q).coeff d := by
  classical
  have hexpand : matrixSubstitution B q=∑ g∈q.support,matrixSubstitution B (MvPolynomial.monomial g (q.coeff g)) := by
    conv_lhs => rw [q.as_sum]
    rw [map_sum]
  rw [hexpand,MvPolynomial.coeff_sum]
  apply Finset.sum_nonneg
  intro g hg
  exact homogeneous_monomial_matrixSubstitution_nonnegative q hq hc B hB g hg d

end CoefficientStability
