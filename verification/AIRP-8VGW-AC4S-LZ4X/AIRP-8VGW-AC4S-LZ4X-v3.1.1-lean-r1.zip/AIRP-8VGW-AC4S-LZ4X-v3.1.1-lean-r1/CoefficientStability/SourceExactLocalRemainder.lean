import CoefficientStability.SourceBooleanCoefficient
import CoefficientStability.StableEffectiveGap

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceExactRemainderConstant (n : ℕ) : ℝ :=
  (2 : ℝ)^n*∑ j∈Finset.range (n-2),(n.choose (j+3) : ℝ)*Real.sqrt (2*(n : ℝ))^(j+3)

theorem source_exact_remainder_constant_formula (n : ℕ) :
    sourceExactRemainderConstant n=(2 : ℝ)^n*
      ∑ j∈Finset.range (n-2),(n.choose (j+3) : ℝ)*(2*(n : ℝ))^(((j+3 : ℕ) : ℝ)/2) := by
  unfold sourceExactRemainderConstant
  congr 1
  apply Finset.sum_congr rfl
  intro j hj
  rw [Real.rpow_div_two_eq_sqrt _ (by positivity),Real.rpow_natCast]

theorem source_boolean_point_square_sum_le {n : ℕ} (eps : Fin n → Bool) :
    (∑ i,sourceBooleanPoint eps i^2) ≤ (n : ℝ) := by
  calc
    _≤∑ _i : Fin n,(1 : ℝ) := by
      apply Finset.sum_le_sum
      intro i hi
      cases h : eps i <;> norm_num [sourceBooleanPoint,h]
    _=(n : ℝ) := by simp

theorem source_boolean_scalar_linear_range {n : ℕ} (t : Fin n → ℝ)
    (hn : 0 < n) (ht : (∑ i,t i)=n) (ht0 : ∀ i,0 ≤ t i) (eps : Fin n → Bool) :
    0 ≤ MvPolynomial.eval (sourceBooleanPoint eps) (scalarLinear t n) ∧
      MvPolynomial.eval (sourceBooleanPoint eps) (scalarLinear t n) ≤ 1 := by
  have he : MvPolynomial.eval (sourceBooleanPoint eps) (scalarLinear t n)=
      (∑ i,t i*sourceBooleanPoint eps i)/(n : ℝ) := by
    simp [scalarLinear,Finset.sum_div,mul_div_assoc,div_mul_eq_mul_div]
  have h0 : 0 ≤ ∑ i,t i*sourceBooleanPoint eps i := by
    apply Finset.sum_nonneg
    intro i hi
    apply mul_nonneg (ht0 i)
    cases h : eps i <;> norm_num [sourceBooleanPoint,h]
  have h1 : (∑ i,t i*sourceBooleanPoint eps i) ≤ n := by
    rw [← ht]
    apply Finset.sum_le_sum
    intro i hi
    cases h : eps i <;> simpa [sourceBooleanPoint,h] using ht0 i
  have hn0 : (0 : ℝ) < n := by exact_mod_cast hn
  rw [he]
  exact ⟨div_nonneg h0 hn0.le,(div_le_one hn0).mpr h1⟩

theorem source_stable_higher_remainder_homogeneous {n : ℕ}
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (hp : p.IsHomogeneous n) :
    (stableHigherRemainder p t).IsHomogeneous n := by
  unfold stableHigherRemainder
  apply MvPolynomial.IsHomogeneous.sum
  intro j hj
  have hjn : j+3 ≤ n := by have h := Finset.mem_range.mp hj;omega
  have h := ((scalarLinear_homogeneous t n).pow (n-(j+3))).mul
    (centralCoefficientPolynomial_homogeneous p t n (j+3) hjn hp)
  convert h using 1 <;> omega

theorem source_sqrt_power_exact_cubic_bound (d c : ℝ) (k : ℕ)
    (hd : 0 ≤ d) (hd1 : d ≤ 1) (hc : 0 ≤ c) (hk : 3 ≤ k) :
    Real.sqrt (c*d)^k ≤ Real.sqrt c^k*(d*Real.sqrt d) := by
  have hs := Real.sq_sqrt hd
  have hs1 : Real.sqrt d ≤ 1 := Real.sqrt_le_one.mpr hd1
  have he : k=(k-3)+3 := by omega
  have hsmall : Real.sqrt d^(k-3) ≤ 1 := pow_le_one₀ (Real.sqrt_nonneg d) hs1
  have h3 : Real.sqrt d^3=d*Real.sqrt d := by nlinarith [Real.sqrt_nonneg d]
  rw [Real.sqrt_mul hc,mul_pow]
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  rw [he,pow_add,h3]
  exact mul_le_of_le_one_left (by positivity) hsmall

theorem source_stable_higher_remainder_exact_bound {n : ℕ}
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hn : 2 ≤ n) (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p) (ht : (∑ i,t i)=n) (ht0 : ∀ i,0 ≤ t i)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hd1 : referenceDeficit p t n ≤ 1) :
    |(stableHigherRemainder p t).coeff (squarefreeExponent n)| ≤
      sourceExactRemainderConstant n*(referenceDeficit p t n*Real.sqrt (referenceDeficit p t n)) := by
  let d := referenceDeficit p t n
  have hd : 0 ≤ d := referenceDeficit_nonneg p t n hn hp hnorm hstable hgrad
  unfold sourceExactRemainderConstant
  rw [mul_assoc,Finset.sum_mul]
  apply source_boolean_squarefree_coefficient_bound _ (source_stable_higher_remainder_homogeneous p t hp)
  intro eps
  have hl := source_boolean_scalar_linear_range t (by omega) ht ht0 eps
  have hq := (paper_root_variance_trace_bound p t n (sourceBooleanPoint eps) hn hp hnorm hstable hgrad).trans
    (mul_le_mul_of_nonneg_left (source_boolean_point_square_sum_le eps) hd)
  simp only [stableHigherRemainder,map_sum,map_mul,map_pow]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  apply Finset.sum_le_sum
  intro j hj
  have hjn : j+3 ≤ n := by have h := Finset.mem_range.mp hj;omega
  have hc := paper_central_coefficient_bound p t n (sourceBooleanPoint eps) (j+3) hn hjn hp hnorm hstable hgrad
  rw [← eval_centralCoefficientPolynomial] at hc
  have hroot : Real.sqrt (2*matrixQuadratic (deficitMatrix p t n) (sourceBooleanPoint eps)) ≤
      Real.sqrt ((2*(n : ℝ))*d) := Real.sqrt_le_sqrt (by nlinarith)
  have hpow := pow_le_pow_left₀ (Real.sqrt_nonneg _) hroot (j+3)
  have hs := source_sqrt_power_exact_cubic_bound d (2*(n : ℝ)) (j+3) hd hd1 (by positivity) (by omega)
  have hcent : |MvPolynomial.eval (sourceBooleanPoint eps) (centralCoefficientPolynomial p t n (j+3))| ≤
      (n.choose (j+3) : ℝ)*(Real.sqrt (2*(n : ℝ))^(j+3)*(d*Real.sqrt d)) :=
    hc.trans (mul_le_mul_of_nonneg_left (hpow.trans hs) (by positivity))
  rw [abs_mul,abs_pow,abs_of_nonneg hl.1]
  have hlpow : (MvPolynomial.eval (sourceBooleanPoint eps) (scalarLinear t n))^(n-(j+3)) ≤ 1 := pow_le_one₀ hl.1 hl.2
  calc
    _≤|MvPolynomial.eval (sourceBooleanPoint eps) (centralCoefficientPolynomial p t n (j+3))| :=
      mul_le_of_le_one_left (abs_nonneg _) hlpow
    _≤_ := hcent
    _=_ := by ring

theorem source_stable_effective_gap_exact_remainder {n : ℕ}
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hn : 2 ≤ n) (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p) (ht : (∑ i,t i)=n) (htpos : ∀ i,0 < t i)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (M : ℝ) (hM : ∀ i,t i ≤ M) (hl : 0 < scalarHessianLambda t)
    (hd1 : referenceDeficit p t n ≤ 1) :
    (sourceHessianFactor t*(scalarHessianLambda t/M^2))*referenceDeficit p t n-
      sourceExactRemainderConstant n*(referenceDeficit p t n*Real.sqrt (referenceDeficit p t n)) ≤
      (p-scalarPower t n).coeff (squarefreeExponent n) := by
  have hlead := paper_stable_leading_gap_lower p t hn hp hnorm hstable ht htpos hgrad M hM hl
  have htail := source_stable_higher_remainder_exact_bound p t hn hp hnorm hstable ht
    (fun i => (htpos i).le) hgrad hd1
  have he : (p-scalarPower t n).coeff (squarefreeExponent n)=
      -(((scalarLinear t n)^(n-2)*quadraticPolynomial (deficitMatrix p t n)).coeff (squarefreeExponent n))+
        (stableHigherRemainder p t).coeff (squarefreeExponent n) := by
    rw [paper_difference_polynomial_expansion p t n hn hp hnorm hstable hgrad]
    simp [stableHigherRemainder]
  rw [he]
  have hneg := neg_le_of_abs_le htail
  linarith

end CoefficientStability
