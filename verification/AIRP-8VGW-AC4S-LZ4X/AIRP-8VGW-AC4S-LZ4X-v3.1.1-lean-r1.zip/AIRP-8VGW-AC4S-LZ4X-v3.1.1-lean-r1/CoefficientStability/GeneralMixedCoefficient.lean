import CoefficientStability.MatrixHessianCoercivity

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}
section Generic
variable {R : Type*} [CommRing R]

def genericMixedDiscriminant (A : Fin n → Matrix (Fin n) (Fin n) R) : R :=
  (Matrix.det (∑ i,(MvPolynomial.X i : MvPolynomial (Fin n) R) •
    (A i).map (MvPolynomial.C : R →+* MvPolynomial (Fin n) R))).coeff (squarefreeExponent n)

theorem genericMixedDiscriminant_expansion (A : Fin n → Matrix (Fin n) (Fin n) R) :
    genericMixedDiscriminant A = ∑ s : Equiv.Perm (Fin n),
      s.sign • (∑ q : Equiv.Perm (Fin n),∏ r,A (q r) (s r) r) := by
  classical
  unfold genericMixedDiscriminant
  rw [Matrix.det_apply,MvPolynomial.coeff_sum]
  apply Finset.sum_congr rfl
  intro s hs
  rw [MvPolynomial.coeff_smul]
  congr 1
  have he (r : Fin n) :
      (∑ i,(MvPolynomial.X i : MvPolynomial (Fin n) R) •
        (A i).map (MvPolynomial.C : R →+* MvPolynomial (Fin n) R)) (s r) r =
        ∑ i,C (A i (s r) r)*MvPolynomial.X i := by
    simp [Matrix.sum_apply,Matrix.smul_apply,Matrix.map_apply,smul_eq_mul,mul_comm]
  simp only [he]
  exact coefficient_product_linear_forms _

theorem genericMixedDiscriminant_eq_rowDetSum (A : Fin n → Matrix (Fin n) (Fin n) R) :
    genericMixedDiscriminant A = ∑ q : Equiv.Perm (Fin n),
      Matrix.det (fun r c => A (q c) r c) := by
  rw [genericMixedDiscriminant_expansion]
  simp only [Finset.smul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro q hq
  exact (Matrix.det_apply (show Matrix (Fin n) (Fin n) R from fun r c => A (q c) r c)).symm

end Generic

theorem complexMixedDiscriminant_generic (A : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    complexMixedDiscriminant A=genericMixedDiscriminant A := rfl

end CoefficientStability
