import CoefficientStability.SourceStableCubicPositiveQuadraticRepresentation
import CoefficientStability.SourceCubicRankOneSourceFactors
import CoefficientStability.SourceCubicLinearFactorRepresentation

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

theorem source_stable_cubic_actual_definite_representation_exists
    (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ)
    (hp : p.IsHomogeneous 3) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) :
    ∃ A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ,
      (∀ i,(A i).IsHermitian) ∧ (∑ i,A i).PosDef ∧ p=realDeterminantPolynomial A := by
  have ht := source_stable_cubic_prescribed_gradient_total p hp hn t hg
  obtain ⟨ha,hc,hd,hzero⟩ := source_stable_cubic_actual_binary_quadratic_conditions p t hp hn hs hg
  by_cases ha0 : deficitMatrix p t 3 0 0=0
  · obtain ⟨a,b,c,hfactor⟩ := source_stable_cubic_actual_second_axis_factors p t hp hn hs ht hg ha0 (hzero ha0)
    apply source_cubic_actual_linear_factors_definite_representation p t ht a b c 0 1
    simpa only [zero_mul,one_mul,zero_add] using hfactor
  · have hap : 0<deficitMatrix p t 3 0 0 := lt_of_le_of_ne ha (Ne.symm ha0)
    by_cases hd0 : deficitMatrix p t 3 0 0*deficitMatrix p t 3 1 1-(deficitMatrix p t 3 0 1)^2=0
    · obtain ⟨a,b,c,hfactor⟩ := source_stable_cubic_actual_first_rank_one_factors p t hp hn hs ht hg ha0 hd0
      apply source_cubic_actual_linear_factors_definite_representation p t ht a b c 1
        (deficitMatrix p t 3 0 1/deficitMatrix p t 3 0 0)
      simpa only [one_mul] using hfactor
    · exact source_stable_cubic_positive_quadratic_actual_representation p t hp hn hs ht hg hap
        (lt_of_le_of_ne hd (Ne.symm hd0))

theorem source_stable_cubic_actual_definite_payload
    (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ)
    (hp : p.IsHomogeneous 3) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) :
    sourceStableCubicDefiniteRepresentation p := by
  obtain ⟨A,hA,hpos,he⟩ := source_stable_cubic_actual_definite_representation_exists p t hp hn hs hg
  have hN : MvPolynomial.eval (fun _ => 1) (realDeterminantPolynomial A)=1 := by rw [← he];exact hn
  refine ⟨A,hA,hpos,?_⟩
  rw [hN,inv_one,one_smul]
  exact he

theorem source_stable_cubic_universal_feasible_representation
    (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ)
    (hp : p.IsHomogeneous 3) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) :
    ∃ A∈hermitianFeasibleTuples t,p=realDeterminantPolynomial A :=
  source_stable_cubic_definite_payload_feasible p t hs hg
    (source_stable_cubic_actual_definite_payload p t hp hn hs hg)

end CoefficientStability
