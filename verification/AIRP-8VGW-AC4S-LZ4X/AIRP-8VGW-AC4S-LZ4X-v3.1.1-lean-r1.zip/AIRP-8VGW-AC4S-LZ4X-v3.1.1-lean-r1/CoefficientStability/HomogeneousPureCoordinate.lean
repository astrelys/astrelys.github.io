import CoefficientStability.PureCoefficientInterior

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem exponent_eq_pure_of_mass (g : Fin n →₀ ℕ) (N : ℕ) (i : Fin n)
    (hmass : ∑ j,g j=N) (hi : g i=N) : g=Finsupp.single i N := by
  classical
  have herase : (∑ j∈Finset.univ.erase i,g j)=0 := by
    have h := Finset.sum_erase_add (Finset.univ : Finset (Fin n)) (fun j => g j) (Finset.mem_univ i)
    rw [hmass,hi] at h
    omega
  ext j
  by_cases hji : j=i
  · subst j
    simpa using hi
  · have hle := Finset.single_le_sum (fun k hk => Nat.zero_le (g k))
      (Finset.mem_erase.mpr ⟨hji,Finset.mem_univ j⟩)
    rw [herase] at hle
    simp only [Finsupp.single_eq_of_ne hji]
    exact Nat.eq_zero_of_le_zero hle

theorem realCoordinateRestriction_pure (x : Fin n → ℝ) (i : Fin n) (N : ℕ) (c : ℝ) :
    realCoordinateRestriction x i (MvPolynomial.monomial (Finsupp.single i N) c)=
      Polynomial.C c*Polynomial.X^N := by
  simp [realCoordinateRestriction,MvPolynomial.eval₂Hom_monomial]

theorem homogeneous_realCoordinateRestriction_top_coeff (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (x : Fin n → ℝ) (i : Fin n) :
    (realCoordinateRestriction x i p).coeff N=p.coeff (Finsupp.single i N) := by
  classical
  have he : realCoordinateRestriction x i p=∑ g∈p.support,
      realCoordinateRestriction x i (MvPolynomial.monomial g (p.coeff g)) := by
    conv_lhs => rw [p.as_sum]
    rw [map_sum]
  rw [he,Polynomial.finsetSum_coeff]
  have hterm (g : Fin n →₀ ℕ) (hg : g∈p.support) :
      (realCoordinateRestriction x i (MvPolynomial.monomial g (p.coeff g))).coeff N=
        if g=Finsupp.single i N then p.coeff g else 0 := by
    by_cases hgi : g=Finsupp.single i N
    · subst g
      rw [realCoordinateRestriction_pure]
      simp
    · rw [if_neg hgi]
      have hmass := homogeneous_mass p N hp g hg
      have hle : g i≤N :=
        (Finset.single_le_sum (fun j hj => Nat.zero_le (g j)) (Finset.mem_univ i)).trans_eq hmass
      have hlt : g i<N := lt_of_le_of_ne hle (fun hi => hgi (exponent_eq_pure_of_mass g N i hmass hi))
      exact Polynomial.coeff_eq_zero_of_natDegree_lt
        ((realCoordinateRestriction_monomial_degree_le g (p.coeff g) x i).trans_lt hlt)
  rw [Finset.sum_congr rfl (fun g hg => hterm g hg)]
  by_cases hmem : Finsupp.single i N∈p.support
  · simp [Finset.sum_ite_eq',hmem]
  · simp [Finset.sum_ite_eq',hmem,MvPolynomial.notMem_support_iff.mp hmem]

end CoefficientStability
