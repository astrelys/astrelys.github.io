import CoefficientStability.SourceHermitianJointBasis

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 3500000
set_option backward.isDefEq.respectTransparency false

def sourceOrthonormalUnitary {n : ℕ} (e : OrthonormalBasis (Fin n) ℂ (EuclideanSpace ℂ (Fin n))) :
    Matrix.unitaryGroup (Fin n) ℂ :=
  ⟨(EuclideanSpace.basisFun (Fin n) ℂ).toBasis.toMatrix e.toBasis,
    (EuclideanSpace.basisFun (Fin n) ℂ).toMatrix_orthonormalBasis_mem_unitary e⟩

@[simp] theorem source_orthonormal_unitary_entry {n : ℕ}
    (e : OrthonormalBasis (Fin n) ℂ (EuclideanSpace ℂ (Fin n))) (i j : Fin n) :
    (sourceOrthonormalUnitary e : Matrix (Fin n) (Fin n) ℂ) i j=e j i := rfl

theorem source_actual_eigenbasis_unitary_diagonal {n : ℕ}
    (X : Matrix (Fin n) (Fin n) ℂ) (e : OrthonormalBasis (Fin n) ℂ (EuclideanSpace ℂ (Fin n)))
    (z : Fin n → ℂ) (he : ∀ j,X.toEuclideanLin (e j)=z j • e j) :
    Unitary.conjStarAlgAut ℂ (Matrix (Fin n) (Fin n) ℂ) (star (sourceOrthonormalUnitary e)) X=
      Matrix.diagonal z := by
  let U := sourceOrthonormalUnitary e
  have hXU : X*(U : Matrix (Fin n) (Fin n) ℂ)=(U : Matrix (Fin n) (Fin n) ℂ)*Matrix.diagonal z := by
    ext i j
    have h := congrArg (fun v : EuclideanSpace ℂ (Fin n) => v i) (he j)
    change (∑ k,X i k*e j k)=z j*e j i at h
    rw [Matrix.mul_diagonal]
    change (∑ k,X i k*e j k)=e j i*z j
    rw [h,mul_comm]
  change Unitary.conjStarAlgAut ℂ (Matrix (Fin n) (Fin n) ℂ) (star U) X=_
  rw [Unitary.conjStarAlgAut_star_apply,Matrix.mul_assoc,hXU,← Matrix.mul_assoc,Unitary.coe_star_mul_self,one_mul]

theorem source_hermitian_simultaneous_unitary_diagonalization {n m : ℕ}
    (A : Fin m → Matrix (Fin n) (Fin n) ℂ) (hA : ∀ i,(A i).IsHermitian)
    (hc : ∀ i j,A i*A j=A j*A i) :
    ∃ (U : Matrix.unitaryGroup (Fin n) ℂ) (z : Fin m → Fin n → ℂ),
      ∀ i,Unitary.conjStarAlgAut ℂ (Matrix (Fin n) (Fin n) ℂ) U (A i)=Matrix.diagonal (z i) := by
  obtain ⟨e,z,he⟩ := source_hermitian_commuting_joint_basis A hA hc
  exact ⟨star (sourceOrthonormalUnitary e),z,fun i => source_actual_eigenbasis_unitary_diagonal (A i) e (z i) (he i)⟩

end CoefficientStability
