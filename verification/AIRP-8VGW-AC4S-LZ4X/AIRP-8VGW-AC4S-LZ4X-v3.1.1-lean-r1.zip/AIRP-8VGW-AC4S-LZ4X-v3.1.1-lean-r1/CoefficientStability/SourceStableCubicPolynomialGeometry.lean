import CoefficientStability.SourceOriginalCubicMatrixBalls

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceCubicProductPolynomial (B : Matrix (Fin 3) (Fin 3) ℝ) : MvPolynomial (Fin 3) ℝ :=
  ∏ j,∑ i,MvPolynomial.C (B i j)*MvPolynomial.X i

theorem source_cubic_actual_unitary_determinant_invariant (U : Matrix.unitaryGroup (Fin 3) ℂ)
    (X : Matrix (Fin 3) (Fin 3) ℂ) :
    Matrix.det (Unitary.conjStarAlgAut ℂ (Matrix (Fin 3) (Fin 3) ℂ) U X)=Matrix.det X := by
  rw [Unitary.conjStarAlgAut_apply,Matrix.det_mul,Matrix.det_mul]
  have h : Matrix.det (U : Matrix (Fin 3) (Fin 3) ℂ)*Matrix.det (star (U : Matrix (Fin 3) (Fin 3) ℂ))=1 := by
    rw [← Matrix.det_mul]
    have hu : (U : Matrix (Fin 3) (Fin 3) ℂ)*star (U : Matrix (Fin 3) (Fin 3) ℂ)=1 := Matrix.mem_unitaryGroup_iff.mp U.property
    rw [hu,Matrix.det_one]
  calc
    Matrix.det (U : Matrix (Fin 3) (Fin 3) ℂ)*Matrix.det X*Matrix.det (star (U : Matrix (Fin 3) (Fin 3) ℂ))=
      Matrix.det X*(Matrix.det (U : Matrix (Fin 3) (Fin 3) ℂ)*Matrix.det (star (U : Matrix (Fin 3) (Fin 3) ℂ))) := by ring
    _=Matrix.det X := by rw [h,mul_one]

theorem source_cubic_actual_unitary_polynomial_invariant (t : Fin 3 → ℝ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : A ∈ hermitianFeasibleTuples t)
    (U : Matrix.unitaryGroup (Fin 3) ℂ) :
    realDeterminantPolynomial (sourceCubicUnitaryAction U A)=realDeterminantPolynomial A := by
  have hD := source_cubic_unitary_feasible t U A hA
  apply MvPolynomial.funext
  intro x
  apply Complex.ofReal_injective
  rw [realDeterminantPolynomial_evaluation _ (fun i => (hD.1 i).1),
    realDeterminantPolynomial_evaluation A (fun i => (hA.1 i).1)]
  have he : (∑ i,(x i : ℂ) • sourceCubicUnitaryAction U A i)=
      Unitary.conjStarAlgAut ℂ (Matrix (Fin 3) (Fin 3) ℂ) U (∑ i,(x i : ℂ) • A i) := by
    simp only [source_cubic_unitary_action_apply,Unitary.conjStarAlgAut_apply,Matrix.mul_sum,Matrix.sum_mul,
      mul_smul_comm,smul_mul_assoc]
  rw [he,source_cubic_actual_unitary_determinant_invariant]

theorem source_cubic_diagonal_product_polynomial (B : Matrix (Fin 3) (Fin 3) ℝ) :
    realDeterminantPolynomial (sourcePermanentDiagonalTuple B)=sourceCubicProductPolynomial B := by
  have hHerm : ∀ i,(sourcePermanentDiagonalTuple B i).IsHermitian := by
    intro i
    exact Matrix.isHermitian_diagonal_iff.mpr (fun j => by simp [IsSelfAdjoint])
  apply MvPolynomial.funext
  intro x
  apply Complex.ofReal_injective
  rw [realDeterminantPolynomial_evaluation _ hHerm]
  have hM : (∑ i,(x i : ℂ) • sourcePermanentDiagonalTuple B i)=
      Matrix.diagonal (fun j => ∑ i,(x i : ℂ)*(B i j : ℂ)) := by
    ext r c
    by_cases hrc : r=c
    · subst c
      simp [sourcePermanentDiagonalTuple,Matrix.sum_apply,Matrix.smul_apply,smul_eq_mul]
    · simp [sourcePermanentDiagonalTuple,Matrix.sum_apply,Matrix.smul_apply,Matrix.diagonal_apply,hrc]
  rw [hM,Matrix.det_diagonal]
  simp [sourceCubicProductPolynomial,MvPolynomial.eval_prod,MvPolynomial.eval_sum,mul_comm]

theorem source_cubic_reference_product_polynomial (t : Fin 3 → ℝ) :
    sourceCubicProductPolynomial (sourcePermanentReference t)=scalarPower t 3 := by
  simp [sourceCubicProductPolynomial,sourcePermanentReference,scalarPower,scalarLinear]

theorem source_cubic_reference_determinant_polynomial (t : Fin 3 → ℝ) :
    realDeterminantPolynomial (complexReferenceTuple t)=scalarPower t 3 := by
  rw [← source_permanent_diagonal_reference,source_cubic_diagonal_product_polynomial,source_cubic_reference_product_polynomial]

theorem source_cubic_product_squarefree_coefficient (B : Matrix (Fin 3) (Fin 3) ℝ) :
    (sourceCubicProductPolynomial B).coeff (squarefreeExponent 3)=Matrix.permanent B := by
  rw [← source_cubic_diagonal_product_polynomial,source_realDeterminant_objective,source_permanent_diagonal_objective]

end CoefficientStability
