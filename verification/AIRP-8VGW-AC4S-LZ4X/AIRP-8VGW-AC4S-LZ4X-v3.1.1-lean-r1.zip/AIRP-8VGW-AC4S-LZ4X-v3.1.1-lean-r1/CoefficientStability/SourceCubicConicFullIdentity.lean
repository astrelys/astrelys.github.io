import CoefficientStability.SourceCubicConicCoefficientRelations

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceConicLinearValue (c : Fin 10 → ℝ) (a : Fin 4 → ℂ) (X Y Z : ℝ) : ℝ :=
  c 2*X+(c 4+(a 0*star (a 3)+star (a 0)*a 3).re)*Y+c 5*Z

def sourceConicNormU (a : Fin 4 → ℂ) (X Y : ℝ) : ℂ := a 0*(X : ℂ)+a 1*(Y : ℂ)
def sourceConicNormV (a : Fin 4 → ℂ) (Y Z : ℝ) : ℂ := a 2*(Y : ℂ)+a 3*(Z : ℂ)

theorem source_cubic_conic_entire_value_identity (c : Fin 10 → ℝ) (a : Fin 4 → ℂ)
    (hrel : ∀ i : Fin 7,sourceConicCubicCoefficients c i= -sourceBinaryNormCoefficients a i)
    (X Y Z : ℝ) :
    sourceTernaryCubicValue c X Y Z=(X*Z-Y^2)*sourceConicLinearValue c a X Y Z-
      X*Complex.normSq (sourceConicNormU a X Y)-Z*Complex.normSq (sourceConicNormV a Y Z)-
      Y*(sourceConicNormU a X Y*star (sourceConicNormV a Y Z)+
        star (sourceConicNormU a X Y)*sourceConicNormV a Y Z).re := by
  have h0 : c 0= -sourceBinaryNormCoefficients a 0 := hrel 0
  have h1 : c 1= -sourceBinaryNormCoefficients a 1 := hrel 1
  have h3 : c 3= -sourceBinaryNormCoefficients a 2-c 2 := by
    have h := hrel 2
    change c 2+c 3= -sourceBinaryNormCoefficients a 2 at h
    linarith
  have h6 : c 6= -sourceBinaryNormCoefficients a 3-c 4 := by
    have h := hrel 3
    change c 4+c 6= -sourceBinaryNormCoefficients a 3 at h
    linarith
  have h7 : c 7= -sourceBinaryNormCoefficients a 4-c 5 := by
    have h := hrel 4
    change c 5+c 7= -sourceBinaryNormCoefficients a 4 at h
    linarith
  have h8 : c 8= -sourceBinaryNormCoefficients a 5 := hrel 5
  have h9 : c 9= -sourceBinaryNormCoefficients a 6 := hrel 6
  unfold sourceTernaryCubicValue sourceConicLinearValue
  rw [h0,h1,h3,h6,h7,h8,h9]
  simp [sourceBinaryNormCoefficients,sourceConicNormU,sourceConicNormV,Complex.normSq_apply,
    Complex.mul_re,Complex.mul_im,Complex.add_re,Complex.add_im]
  ring

theorem source_cubic_conic_entire_determinant (c : Fin 10 → ℝ) (a : Fin 4 → ℂ)
    (hrel : ∀ i : Fin 7,sourceConicCubicCoefficients c i= -sourceBinaryNormCoefficients a i)
    (X Y Z : ℝ) :
    Matrix.det (sourceCubicConicPencilValue (sourceConicLinearValue c a X Y Z) X Y Z
      (sourceConicNormU a X Y) (sourceConicNormV a Y Z))=(sourceTernaryCubicValue c X Y Z : ℂ) := by
  rw [source_cubic_conic_pencil_value_determinant,source_cubic_conic_entire_value_identity c a hrel]
  push_cast
  rfl

theorem source_cubic_conic_actual_entire_determinant_exists (p : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3)
    (hconic : ∀ u v : ℝ,MvPolynomial.eval (![u^2,u*v,v^2] : Fin 3 → ℝ) p ≤ 0) :
    ∃ a : Fin 4 → ℂ,∀ X Y Z : ℝ,
      Matrix.det (sourceCubicConicPencilValue
        (sourceConicLinearValue (sourceTernaryCubicCoefficients p) a X Y Z) X Y Z
        (sourceConicNormU a X Y) (sourceConicNormV a Y Z))=
      (MvPolynomial.eval (![X,Y,Z] : Fin 3 → ℝ) p : ℂ) := by
  obtain ⟨a,ha⟩ := source_cubic_actual_conic_coefficient_factor_exists p hp hconic
  refine ⟨a,?_⟩
  intro X Y Z
  rw [source_cubic_conic_entire_determinant _ a ha,source_ternary_cubic_actual_eval p hp]

end CoefficientStability
