import CoefficientStability.SourceWeightedBoundaryCurve

noncomputable section
open scoped BigOperators Topology
open Filter
namespace CoefficientStability
variable {m n : ℕ}

theorem actual_abs_coeff_le_coefficientL1 (p : MvPolynomial (Fin n) ℝ) (g : Fin n →₀ ℕ) :
    |p.coeff g| ≤ coefficientL1 p := by
  classical
  by_cases hg : g ∈ p.support
  · exact Finset.single_le_sum (fun d hd => abs_nonneg (p.coeff d)) hg
  · rw [MvPolynomial.notMem_support_iff.mp hg,abs_zero]
    exact coefficientL1_nonneg p

theorem sourceWeightedBoundaryCurve_continuous (α : Fin m → ℕ) (hα : ∀ i,0 < α i) (t : Fin m → ℝ) :
    Continuous (sourceWeightedBoundaryCurve α t) := by
  apply continuous_induced_rng.mpr
  apply continuous_pi
  intro g
  apply continuous_iff_continuousAt.mpr
  intro s0
  apply Metric.tendsto_nhds.mpr
  intro ε hε
  have hcn := (fixedDegree_coefficientL1_continuous (sourceCloneCount α)
      (stableBoundaryCurve (sourceClonedGradient α t) s0)).comp
    (stableBoundaryCurve_continuous (sourceClonedGradient α t))
  have hnear : ∀ᶠ s in 𝓝 s0,
      coefficientL1 ((stableBoundaryCurve (sourceClonedGradient α t) s).val-
        (stableBoundaryCurve (sourceClonedGradient α t) s0).val) < ε :=
    hcn.continuousAt.eventually (gt_mem_nhds (by simpa only [Function.comp_apply,sub_self,coefficientL1_zero] using hε))
  filter_upwards [hnear] with s hs
  rw [Real.dist_eq]
  have hbound := actual_abs_coeff_le_coefficientL1
    ((sourceWeightedBoundaryCurve α t s).val-(sourceWeightedBoundaryCurve α t s0).val) g
  have he : ((sourceWeightedBoundaryCurve α t s).val-(sourceWeightedBoundaryCurve α t s0).val).coeff g=
      (sourceWeightedBoundaryCurve α t s).val.coeff g-(sourceWeightedBoundaryCurve α t s0).val.coeff g := by simp
  rw [he,sourceWeightedBoundaryCurve_distance α hα] at hbound
  exact hbound.trans_lt hs

theorem sourceWeightedBoundaryCurve_tendsto_reference (α : Fin m → ℕ) (hα : ∀ i,0 < α i) (t : Fin m → ℝ) :
    Tendsto (sourceWeightedBoundaryCurve α t) (𝓝 (0 : ℝ)) (𝓝 (sourceWeightedReference α t)) := by
  have h := (sourceWeightedBoundaryCurve_continuous α hα t).tendsto (0 : ℝ)
  rwa [sourceWeightedBoundaryCurve_zero α hα] at h

end CoefficientStability
