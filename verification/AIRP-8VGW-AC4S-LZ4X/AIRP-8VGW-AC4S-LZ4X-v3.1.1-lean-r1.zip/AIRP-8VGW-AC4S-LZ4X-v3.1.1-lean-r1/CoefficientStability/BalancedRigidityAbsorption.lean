import CoefficientStability.SmallTiltTransport

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem paper_balanced_rigidity_field_absorption (p : MvPolynomial (Fin n) ℝ)
    (hn : 3≤n) (hp : p.IsHomogeneous n) (hcoeff : ∀ g,0≤p.coeff g)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p)
    (τ : ℝ) (hτ : 0≤τ) (fields : Fin n → Fin n → ℝ)
    (hfield : ∀ i,‖fields i‖≤1/(100*(n : ℝ)^2))
    (hdiag : ∀ i,deficitMatrix (tiltedPolynomial p (fields i)) (tiltedMoment p (fields i)) n i i≤64*τ) :
    actualTiltDeficit p 0≤128*(n : ℝ)*τ := by
  have hn0 : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
  have hδ : 0≤actualTiltDeficit p 0 :=
    (actual_tilt_deficit_source_bounds p 0 (by omega) hp hcoeff hnorm hstable).2.2.1
  have hc := small_optimizing_field_constants hn
  have hpoint (i : Fin n) :
      deficitMatrix (tiltedPolynomial p 0) (tiltedMoment p 0) n i i≤
        64*τ+(6/(25*(n : ℝ)))*actualTiltDeficit p 0 := by
    have hsmall : 12*(n : ℝ)*‖fields i‖≤1/2 :=
      (mul_le_mul_of_nonneg_left (hfield i) (by positivity)).trans hc.1
    have ht := paper_actual_small_tilt_diagonal_transport p 0 (fields i) hn hp hcoeff hnorm hstable hsmall i
    simp only [zero_add] at ht
    have hm := mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_left (hfield i) (by positivity : 0≤24*(n : ℝ))) hδ
    rw [hc.2] at hm
    have hreverse := (le_abs_self
      (deficitMatrix (tiltedPolynomial p 0) (tiltedMoment p 0) n i i-
        deficitMatrix (tiltedPolynomial p (fields i)) (tiltedMoment p (fields i)) n i i))
    rw [abs_sub_comm] at ht
    linarith [hdiag i]
  have hs := Finset.sum_le_sum (s := (Finset.univ : Finset (Fin n))) (fun i hi => hpoint i)
  have htrace : (∑ i,deficitMatrix (tiltedPolynomial p 0) (tiltedMoment p 0) n i i)=actualTiltDeficit p 0 :=
    trace_deficitMatrix _ _ n
  rw [htrace] at hs
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] at hs
  have he : (n : ℝ)*(64*τ+(6/(25*(n : ℝ)))*actualTiltDeficit p 0)=
      64*(n : ℝ)*τ+(6/25)*actualTiltDeficit p 0 := by
    field_simp <;> ring
  rw [he] at hs
  nlinarith [mul_nonneg hn0.le hτ]

end CoefficientStability
