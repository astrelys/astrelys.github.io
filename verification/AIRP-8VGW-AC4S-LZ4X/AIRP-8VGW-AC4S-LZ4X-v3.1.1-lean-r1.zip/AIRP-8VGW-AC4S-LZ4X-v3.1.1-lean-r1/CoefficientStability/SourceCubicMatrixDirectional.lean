import CoefficientStability.SourceCubicMatrixGradient

noncomputable section
open scoped BigOperators Matrix.Norms.Elementwise
namespace CoefficientStability
set_option maxHeartbeats 1800000
set_option backward.isDefEq.respectTransparency false

def sourceCubicTraceConstant (t : Fin 3 → ℝ) : ℂ :=
  1-(1/2 : ℂ)*(∑ i,(t i : ℂ)^2)+(1/3 : ℂ)*(∑ i,(t i : ℂ)^3)

theorem source_cubic_mixed_trace_summands (t : Fin 3 → ℝ) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hs : (∑ i,A i)=1) (ht : ∀ i,Matrix.trace (A i)=(t i : ℂ)) :
    complexMixedDiscriminant A=sourceCubicTraceConstant t+∑ i,sourceCubicMatrixSummand (t i) (A i) := by
  rw [source_cubic_mixed_separable_objective A hs]
  simp only [sourceCubicTraceConstant,sourceCubicMatrixSummand,ht]

theorem source_cubic_mixed_constrained_hasDerivAt (t : Fin 3 → ℝ)
    (A H : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hs : (∑ i,A i)=1) (ht : ∀ i,Matrix.trace (A i)=(t i : ℂ))
    (hHs : (∑ i,H i)=0) (hHt : ∀ i,Matrix.trace (H i)=0) :
    HasDerivAt (fun s : ℝ => hermitianMixedObjective (A+(s : ℂ) • H))
      (∑ i,(Matrix.trace (sourceCubicMatrixGradient (t i) (A i)*H i)).re) 0 := by
  have he (s : ℝ) : hermitianMixedObjective (A+(s : ℂ) • H)=
      (sourceCubicTraceConstant t).re+∑ i,(sourceCubicMatrixSummand (t i) (A i+(s : ℂ) • H i)).re := by
    have hsum : (∑ i,(A+(s : ℂ) • H) i)=1 := by
      simp only [Pi.add_apply,Pi.smul_apply,Finset.sum_add_distrib,← Finset.smul_sum,hs,hHs,smul_zero,add_zero]
    have htrace : ∀ i,Matrix.trace ((A+(s : ℂ) • H) i)=(t i : ℂ) := by
      intro i
      simp only [Pi.add_apply,Pi.smul_apply,Matrix.trace_add,Matrix.trace_smul,ht,hHt,smul_zero,add_zero]
    have h := congrArg Complex.re (source_cubic_mixed_trace_summands t (A+(s : ℂ) • H) hsum htrace)
    simpa only [hermitianMixedObjective,Complex.add_re,Complex.re_sum,Pi.add_apply,Pi.smul_apply] using h
  have hd := (hasDerivAt_const (0 : ℝ) (sourceCubicTraceConstant t).re).add
    (HasDerivAt.fun_sum (u := Finset.univ) (fun i _ => source_cubic_matrix_summand_real_hasDerivAt (t i) (A i) (H i)))
  convert hd using 1
  · funext s
    exact he s
  · simp

end CoefficientStability
