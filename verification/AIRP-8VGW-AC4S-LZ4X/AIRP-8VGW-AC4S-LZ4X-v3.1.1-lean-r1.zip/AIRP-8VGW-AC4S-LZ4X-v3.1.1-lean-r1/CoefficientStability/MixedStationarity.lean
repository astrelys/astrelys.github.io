import CoefficientStability.MixedMultilinearity
import CoefficientStability.MixedSecondVariation
import Mathlib.Analysis.Calculus.FDeriv.Analytic
import Mathlib.Topology.Instances.Matrix
import Mathlib.Analysis.Matrix.Normed

noncomputable section
open scoped BigOperators Matrix.Norms.Elementwise
namespace CoefficientStability
variable {n : ℕ}

theorem genericMixedDiscriminant_continuous :
    Continuous (genericMixedDiscriminant : (Fin n → Matrix (Fin n) (Fin n) ℂ) → ℂ) := by
  simp only [show (genericMixedDiscriminant : (Fin n → Matrix (Fin n) (Fin n) ℂ) → ℂ)=
    (fun A => ∑ s : Equiv.Perm (Fin n),s.sign •
      (∑ q : Equiv.Perm (Fin n),∏ r,A (q r) (s r) r)) from funext genericMixedDiscriminant_expansion]
  fun_prop

def actualMixedContinuous : ContinuousMultilinearMap ℂ
    (fun _ : Fin n => Matrix (Fin n) (Fin n) ℂ) ℂ :=
  { actualMixedMultilinear with
    cont := by
      change Continuous (actualMixedMultilinear : (Fin n → Matrix (Fin n) (Fin n) ℂ) → ℂ)
      have he : (actualMixedMultilinear : (Fin n → Matrix (Fin n) (Fin n) ℂ) → ℂ)=genericMixedDiscriminant :=
        funext actualMixedMultilinear_eq
      rw [he]
      exact genericMixedDiscriminant_continuous }

theorem actualMixedContinuous_eq (A : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    actualMixedContinuous A=complexMixedDiscriminant A := actualMixedMultilinear_eq A

theorem actual_mixed_first_derivative (A H : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    (fderiv ℂ complexMixedDiscriminant A) H=
      ∑ i,complexMixedDiscriminant (Function.update A i (H i)) := by
  have he : (actualMixedContinuous : (Fin n → Matrix (Fin n) (Fin n) ℂ) → ℂ)=complexMixedDiscriminant :=
    funext actualMixedContinuous_eq
  have hd : HasFDerivAt (𝕜 := ℂ) (actualMixedContinuous (n := n))
      ((actualMixedContinuous (n := n)).linearDeriv A) A :=
    (actualMixedContinuous (n := n)).hasFDerivAt A
  have h := congrArg (fun L : (Fin n → Matrix (Fin n) (Fin n) ℂ) →L[ℂ] ℂ => L H) hd.fderiv
  simpa only [he,ContinuousMultilinearMap.linearDeriv_apply,actualMixedContinuous_eq] using h

theorem mixed_scalar_update_trace_zero (c : Fin n → ℂ) (hc : ∀ i,c i≠0)
    (H : Matrix (Fin n) (Fin n) ℂ) (hH : Matrix.trace H=0) (hn : 0<n) (k : Fin n) :
    complexMixedDiscriminant (Function.update (fun i => c i • (1 : Matrix (Fin n) (Fin n) ℂ)) k H)=0 := by
  have he : Function.update (fun i => c i • (1 : Matrix (Fin n) (Fin n) ℂ)) k H=
      (fun i => c i • (Function.update (fun _ : Fin n => (1 : Matrix (Fin n) (Fin n) ℂ)) k ((c k)⁻¹ • H) i)) := by
    funext i
    by_cases hi : i=k
    · subst i
      simp [smul_smul,hc]
    · simp [Function.update_of_ne hi]
  rw [he,← actualMixedContinuous_eq,ContinuousMultilinearMap.map_smul_univ]
  rw [actualMixedContinuous_eq,complexMixedDiscriminant_generic,genericMixedDiscriminant_one_argument _ hn k]
  simp [Matrix.trace_smul,hH]

theorem paper_scalar_stationarity (t : Fin n → ℝ) (htpos : ∀ i,0<t i) (hn : 2≤n)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ) (hA : ∀ i,Matrix.trace (A i)=0) :
    (fderiv ℂ complexMixedDiscriminant (complexReferenceTuple t)) A=0 := by
  rw [actual_mixed_first_derivative]
  apply Finset.sum_eq_zero
  intro i hi
  have he : complexReferenceTuple t=(fun i => Complex.ofReal (t i/(n : ℝ)) •
      (1 : Matrix (Fin n) (Fin n) ℂ)) := funext (complexReferenceTuple_source t)
  rw [he]
  apply mixed_scalar_update_trace_zero _ _ _ (hA i) (by omega)
  intro j
  exact_mod_cast ne_of_gt (div_pos (htpos j) (by exact_mod_cast (by omega : 0<n)))

end CoefficientStability
