import CoefficientStability.ActualRelativeTilt

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem psd_bilinear_euclidean_bound (A : Matrix (Fin n) (Fin n) ℝ) (hA : A.PosSemidef)
    (c : ℝ) (hc : 0 ≤ c) (hq : ∀ v, matrixQuadratic A v ≤ c*(∑ i,v i^2))
    (x y : Fin n → ℝ) :
    |A.toBilin' x y| ≤ c*Real.sqrt (∑ i,x i^2)*Real.sqrt (∑ i,y i^2) := by
  have hx : (Real.sqrt (∑ i,x i^2))^2=∑ i,x i^2 := Real.sq_sqrt (Finset.sum_nonneg (fun i hi => sq_nonneg (x i)))
  have hy : (Real.sqrt (∑ i,y i^2))^2=∑ i,y i^2 := Real.sq_sqrt (Finset.sum_nonneg (fun i hi => sq_nonneg (y i)))
  have hh := (psd_bilinear_square_bound A hA x y).trans
    (mul_le_mul (hq x) (hq y) (psd_matrixQuadratic_nonneg A hA y) (by positivity))
  have he : (c*Real.sqrt (∑ i,x i^2)*Real.sqrt (∑ i,y i^2))^2=
      (c*(∑ i,x i^2))*(c*(∑ i,y i^2)) := by rw [mul_pow,mul_pow,hx,hy];ring
  apply (sq_le_sq₀ (abs_nonneg _) (by positivity)).mp
  rw [sq_abs,he]
  exact hh

theorem psd_bilinear_trace_euclidean_bound (A : Matrix (Fin n) (Fin n) ℝ) (hA : A.PosSemidef)
    (x y : Fin n → ℝ) :
    |A.toBilin' x y| ≤ Matrix.trace A*Real.sqrt (∑ i,x i^2)*Real.sqrt (∑ i,y i^2) := by
  apply psd_bilinear_euclidean_bound A hA (Matrix.trace A)
  · exact Finset.sum_nonneg (fun i hi => by simpa using (hA.diag_nonneg (i := i)))
  · intro v
    exact psd_quadratic_le_trace A hA v

theorem actual_tilt_covariance_euclidean_upper (p : MvPolynomial (Fin n) ℝ)
    (u v : Fin n → ℝ) (hn : 3 ≤ n) (hp : p.IsHomogeneous n)
    (hc : ∀ g,0 ≤ p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) :
    matrixQuadratic (coefficientCovariance (tiltedPolynomial p u) (tiltedMoment p u)) v ≤ (n : ℝ)*(∑ i,v i^2) := by
  classical
  obtain ⟨hQ,htrace,ht0,ht,hT⟩ := actual_tilt_relative_ingredients p u hn hp hc hnorm hs
  have hZ := ne_of_gt (tiltPartition_pos p u hc hnorm)
  have hn0 : (0 : ℝ) < n := by exact_mod_cast (show 0<n by omega)
  have hti (i : Fin n) : tiltedMoment p u i ≤ n := by
    rw [← ht]
    exact Finset.single_le_sum (fun j hj => ht0 j) (Finset.mem_univ i)
  have he : matrixQuadratic (coefficientCovariance (tiltedPolynomial p u) (tiltedMoment p u)) v=
      (∑ i,tiltedMoment p u i*v i^2)-(∑ i,tiltedMoment p u i*v i)^2/(n : ℝ)-
        2*matrixQuadratic (deficitMatrix (tiltedPolynomial p u) (tiltedMoment p u) n) v := by
    simp only [matrixQuadratic,actual_tilt_covariance_deficit p u (by omega) hZ,sub_mul,
      Finset.sum_sub_distrib]
    have hdiag : (∑ i,∑ j,(if i=j then tiltedMoment p u i else 0)*v i*v j)=∑ i,tiltedMoment p u i*v i^2 := by
      apply Finset.sum_congr rfl
      intro i hi
      simp only [ite_mul,zero_mul,Finset.sum_ite_eq,Finset.mem_univ,ite_true]
      ring
    have hout : (∑ i,∑ j,tiltedMoment p u i*tiltedMoment p u j/(n : ℝ)*v i*v j)=
        (∑ i,tiltedMoment p u i*v i)^2/(n : ℝ) := by
      rw [pow_two,Finset.sum_mul_sum,Finset.sum_div]
      apply Finset.sum_congr rfl
      intro i hi
      rw [Finset.sum_div]
      apply Finset.sum_congr rfl
      intro j hj
      ring
    rw [hdiag,hout]
    simp only [Finset.mul_sum]
    ring
  rw [he]
  have hsum : (∑ i,tiltedMoment p u i*v i^2) ≤ (n : ℝ)*(∑ i,v i^2) := by
    rw [Finset.mul_sum]
    exact Finset.sum_le_sum (fun i hi => mul_le_mul_of_nonneg_right (hti i) (sq_nonneg _))
  have hquad := psd_matrixQuadratic_nonneg _ hQ v
  have hout := div_nonneg (sq_nonneg (∑ i,tiltedMoment p u i*v i)) hn0.le
  linarith

end CoefficientStability
