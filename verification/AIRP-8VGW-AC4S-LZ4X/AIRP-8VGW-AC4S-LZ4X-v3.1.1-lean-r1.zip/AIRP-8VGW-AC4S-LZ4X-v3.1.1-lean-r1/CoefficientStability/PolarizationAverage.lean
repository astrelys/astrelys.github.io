import CoefficientStability.QuadraticNorm

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n k : ℕ}

def realSign (b : Bool) : ℝ := if b then 1 else -1

@[simp] theorem realSign_abs (b : Bool) : |realSign b|=1 := by cases b <;> norm_num [realSign]
@[simp] theorem realSign_square (b : Bool) : (realSign b)^2=1 := by cases b <;> norm_num [realSign]

def polarizationPoint (f : Fin k → Fin n) (eps : Fin k → Bool) (i : Fin n) : ℝ :=
  ∑ j,if f j=i then realSign (eps j) else 0

def signedPolarizationCoefficient (h : MvPolynomial (Fin n) ℝ) (f : Fin k → Fin n) : ℝ :=
  (∑ eps : Fin k → Bool,(∏ j,realSign (eps j))*MvPolynomial.eval (polarizationPoint f eps) h)/
    ((2 : ℝ)^k*(k.factorial : ℝ))

theorem polarizationPoint_l1_le (f : Fin k → Fin n) (eps : Fin k → Bool) :
    (∑ i,|polarizationPoint f eps i|) ≤ (k : ℝ) := by
  calc
    _ ≤ ∑ i : Fin n,∑ j : Fin k,|if f j=i then realSign (eps j) else (0 : ℝ)| := by
      apply Finset.sum_le_sum
      intro i hi
      exact Finset.abs_sum_le_sum_abs _ _
    _ = _ := by
      rw [Finset.sum_comm]
      have he (j : Fin k) (i : Fin n) : |if f j=i then realSign (eps j) else (0 : ℝ)| =
          if f j=i then (1 : ℝ) else 0 := by
        split_ifs <;> simp
      simp only [he]
      simp

theorem polarizationPoint_sum_squares_le (f : Fin k → Fin n) (eps : Fin k → Bool) :
    (∑ i,polarizationPoint f eps i^2) ≤ (k : ℝ)^2 := by
  have h := Finset.sum_sq_le_sq_sum_of_nonneg (s := (Finset.univ : Finset (Fin n)))
    (f := fun i => |polarizationPoint f eps i|) (fun i hi => abs_nonneg _)
  simp only [sq_abs] at h
  have hl := polarizationPoint_l1_le f eps
  have hs : 0 ≤ ∑ i,|polarizationPoint f eps i| := Finset.sum_nonneg (fun _ _ => abs_nonneg _)
  nlinarith

theorem signedPolarizationCoefficient_bound (h : MvPolynomial (Fin n) ℝ)
    (f : Fin k → Fin n) (P : ℝ) (hP : 0≤P)
    (hbound : ∀ eps : Fin k → Bool,|MvPolynomial.eval (polarizationPoint f eps) h|≤P) :
    |signedPolarizationCoefficient h f|≤P/(k.factorial : ℝ) := by
  have hsum : |∑ eps : Fin k → Bool,(∏ j,realSign (eps j))*MvPolynomial.eval (polarizationPoint f eps) h| ≤
      (2 : ℝ)^k*P := by
    calc
      _ ≤ ∑ eps : Fin k → Bool,|(∏ j,realSign (eps j))*MvPolynomial.eval (polarizationPoint f eps) h| :=
        Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ _eps : Fin k → Bool,P := by
        apply Finset.sum_le_sum
        intro eps heps
        simpa only [abs_mul,Finset.abs_prod,realSign_abs,Finset.prod_const_one,one_mul] using hbound eps
      _ = _ := by simp [Fintype.card_fun]
  have h2 : (0 : ℝ)<2^k := pow_pos (by norm_num) _
  have hf : (0 : ℝ)<(k.factorial : ℝ) := by exact_mod_cast Nat.factorial_pos k
  unfold signedPolarizationCoefficient
  rw [abs_div,abs_of_pos (mul_pos h2 hf)]
  apply (div_le_iff₀ (mul_pos h2 hf)).mpr
  calc
    _ ≤ (2 : ℝ)^k*P := hsum
    _ = (P/(k.factorial : ℝ))*((2 : ℝ)^k*(k.factorial : ℝ)) := by field_simp

theorem paper_central_polynomial_on_polarization_points
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N k : ℕ) (f : Fin k → Fin n)
    (hN : 2≤N) (hk : k≤N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) (eps : Fin k → Bool) :
    |MvPolynomial.eval (polarizationPoint f eps) (centralCoefficientPolynomial p t N k)| ≤
      (N.choose k : ℝ)*Real.sqrt (2*referenceDeficit p t N)^k*(k : ℝ)^k := by
  have hd := referenceDeficit_nonneg p t N hN hp hnorm hstable hgrad
  have hq := paper_root_variance_trace_bound p t N (polarizationPoint f eps) hN hp hnorm hstable hgrad
  have hs := polarizationPoint_sum_squares_le f eps
  have hqk : matrixQuadratic (deficitMatrix p t N) (polarizationPoint f eps) ≤
      referenceDeficit p t N*(k : ℝ)^2 := hq.trans (mul_le_mul_of_nonneg_left hs hd)
  have hr : Real.sqrt (2*matrixQuadratic (deficitMatrix p t N) (polarizationPoint f eps)) ≤
      Real.sqrt (2*referenceDeficit p t N)*(k : ℝ) := by
    calc
      _ ≤ Real.sqrt ((2*referenceDeficit p t N)*(k : ℝ)^2) :=
        Real.sqrt_le_sqrt (by nlinarith)
      _ = _ := by rw [Real.sqrt_mul (by positivity),Real.sqrt_sq_eq_abs,abs_of_nonneg (Nat.cast_nonneg k)]
  rw [eval_centralCoefficientPolynomial]
  have h := paper_central_coefficient_bound p t N (polarizationPoint f eps) k hN hk hp hnorm hstable hgrad
  calc
    _ ≤ _ := h
    _ ≤ (N.choose k : ℝ)*(Real.sqrt (2*referenceDeficit p t N)*(k : ℝ))^k := by
      gcongr
    _ = _ := by rw [mul_pow]; ring

theorem paper_central_signedPolarization_bound
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N k : ℕ) (f : Fin k → Fin n)
    (hN : 2≤N) (hk : k≤N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    |signedPolarizationCoefficient (centralCoefficientPolynomial p t N k) f| ≤
      ((N.choose k : ℝ)*Real.sqrt (2*referenceDeficit p t N)^k*(k : ℝ)^k)/(k.factorial : ℝ) := by
  apply signedPolarizationCoefficient_bound
  · positivity
  · intro eps
    exact paper_central_polynomial_on_polarization_points p t N k f hN hk hp hnorm hstable hgrad eps

end CoefficientStability
