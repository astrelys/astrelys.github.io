import CoefficientStability.SourceBalancedSixGates
import CoefficientStability.SourceBalancedGateLocalExclusion

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

theorem source_escape_column_quadratic_invariant (a b : ℝ) (X : Matrix (Fin 3) (Fin 3) ℝ)
    (c : Equiv.Perm (Fin 3)) :
    sourceEscapeQuadratic a b (sourcePermutedMatrix X 1 c-sourceEscapeCenter a b)=
      sourceEscapeQuadratic a b (X-sourceEscapeCenter a b) := by
  unfold sourceEscapeQuadratic
  apply congrArg (fun r : ℝ => r/6)
  apply Finset.sum_congr rfl
  intro i hi
  apply congrArg (fun r : ℝ => sourceEscapeWeights a b i*r)
  change (∑ j,(X i (c j)-sourceEscapeTraces a b i/3)^2)=∑ j,(X i j-sourceEscapeTraces a b i/3)^2
  exact Equiv.sum_comp c (fun j => (X i j-sourceEscapeTraces a b i/3)^2)

theorem source_actual_column_permutation_continuous (c : Equiv.Perm (Fin 3)) :
    Continuous (fun X : Matrix (Fin 3) (Fin 3) ℝ => sourcePermutedMatrix X 1 c) := by
  apply continuous_pi
  intro i
  apply continuous_pi
  intro j
  change Continuous (fun X : Matrix (Fin 3) (Fin 3) ℝ => X i (c j))
  fun_prop

theorem source_balanced_gate_column_permutation_injective :
    Function.Injective (fun c : Equiv.Perm (Fin 3) => sourcePermutedMatrix sourceBalancedEscapeGate 1 c) := by
  intro c d h
  apply Equiv.ext
  intro j
  by_contra hne
  have he := congrArg (fun X : Matrix (Fin 3) (Fin 3) ℝ => X (c j) j) h
  change sourceBalancedEscapeGate (c j) (c j)=sourceBalancedEscapeGate (c j) (d j) at he
  rw [source_balanced_gate_entry,source_balanced_gate_entry] at he
  simp only [if_pos rfl,if_neg hne] at he
  norm_num at he

theorem source_balanced_actual_gate_count :
    (Finset.univ.image (fun c : Equiv.Perm (Fin 3) => sourcePermutedMatrix sourceBalancedEscapeGate 1 c)).card=6 := by
  classical
  rw [Finset.card_image_of_injective _ source_balanced_gate_column_permutation_injective]
  decide

theorem source_balanced_permuted_gate_feasible (c : Equiv.Perm (Fin 3)) :
    sourcePermutedMatrix sourceBalancedEscapeGate 1 c ∈ sourceTransportationPolytope (sourceEscapeTraces 1 1) :=
  source_permuted_feasible _ _ source_escape_balanced_gate_feasible 1 c

theorem source_balanced_every_gate_actual_local_exclusion (c : Equiv.Perm (Fin 3)) :
    ∀ᶠ X in 𝓝 (sourcePermutedMatrix sourceBalancedEscapeGate 1 c),
      X ∈ sourceTransportationPolytope (sourceEscapeTraces 1 1) →
      sourceEscapeQ 1 1 < sourceEscapeQuadratic 1 1 (X-sourceEscapeCenter 1 1) → 1/4 < Matrix.permanent X := by
  let ψ : Matrix (Fin 3) (Fin 3) ℝ → Matrix (Fin 3) (Fin 3) ℝ := fun X => sourcePermutedMatrix X 1 c.symm
  have hc : Continuous ψ := source_actual_column_permutation_continuous c.symm
  have hi : ψ (sourcePermutedMatrix sourceBalancedEscapeGate 1 c)=sourceBalancedEscapeGate :=
    source_permuted_matrix_inverse _ 1 c
  have ht : Filter.Tendsto ψ (𝓝 (sourcePermutedMatrix sourceBalancedEscapeGate 1 c)) (𝓝 sourceBalancedEscapeGate) := by
    have ht0 : Filter.Tendsto ψ (𝓝 (sourcePermutedMatrix sourceBalancedEscapeGate 1 c))
        (𝓝 (ψ (sourcePermutedMatrix sourceBalancedEscapeGate 1 c))) := hc.continuousAt
    simpa only [hi] using ht0
  have hnear := ht.eventually source_balanced_gate_actual_local_escape_exclusion
  filter_upwards [hnear] with X hnear hX hq
  have hY : ψ X ∈ sourceTransportationPolytope (sourceEscapeTraces 1 1) := source_permuted_feasible _ X hX 1 c.symm
  have hqY : sourceEscapeQ 1 1 < sourceEscapeQuadratic 1 1 (ψ X-sourceEscapeCenter 1 1) := by
    rw [source_escape_column_quadratic_invariant]
    exact hq
  have h := hnear hY hqY
  simpa only [ψ,source_permuted_permanent] using h

theorem source_balanced_every_gate_actual_crossing (c : Equiv.Perm (Fin 3)) :
    sourceEscapeQuadratic 1 1 (sourcePermutedMatrix sourceBalancedEscapeGate 1 c-sourceEscapeCenter 1 1)=sourceEscapeQ 1 1 ∧
    Matrix.permanent (sourcePermutedMatrix sourceBalancedEscapeGate 1 c)=1/4 := by
  constructor
  · rw [source_escape_column_quadratic_invariant]
    exact source_escape_balanced_gate_q_and_cubic.1
  · rw [source_permuted_permanent]
    have h := source_escape_balanced_flat_permanent 0
    simpa only [zero_smul,add_zero,zero_pow (by decide : 2 ≠ 0),mul_zero] using h

theorem source_balanced_minimal_crossing_iff (X : Matrix (Fin 3) (Fin 3) ℝ)
    (hX : X ∈ sourceTransportationPolytope (sourceEscapeTraces 1 1)) :
    (sourceEscapeQuadratic 1 1 (X-sourceEscapeCenter 1 1)=sourceEscapeQ 1 1 ∧ Matrix.permanent X ≤ 1/4) ↔
      ∃ c : Equiv.Perm (Fin 3),X=sourcePermutedMatrix sourceBalancedEscapeGate 1 c := by
  constructor
  · rintro ⟨hq,hp⟩
    exact source_balanced_crossing_is_one_of_six_gates X hX hq hp
  · rintro ⟨c,rfl⟩
    exact ⟨(source_balanced_every_gate_actual_crossing c).1,(source_balanced_every_gate_actual_crossing c).2.le⟩

end CoefficientStability
