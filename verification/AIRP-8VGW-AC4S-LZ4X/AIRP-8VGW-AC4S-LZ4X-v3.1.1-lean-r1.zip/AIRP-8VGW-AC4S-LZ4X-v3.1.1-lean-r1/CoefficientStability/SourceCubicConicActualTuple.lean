import CoefficientStability.SourceCubicConicFullIdentity

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceCubicConicActualTuple (c : Fin 10 → ℝ) (a : Fin 4 → ℂ) :
    Fin 3 → Matrix (Fin 3) (Fin 3) ℂ :=
  ![sourceCubicConicPencilValue (c 2) 1 0 0 (a 0) 0,
    sourceCubicConicPencilValue (c 4+(a 0*star (a 3)+star (a 0)*a 3).re) 0 1 0 (a 1) (a 2),
    sourceCubicConicPencilValue (c 5) 0 0 1 0 (a 3)]

theorem source_cubic_conic_actual_tuple_hermitian (c : Fin 10 → ℝ) (a : Fin 4 → ℂ) :
    ∀ i,(sourceCubicConicActualTuple c a i).IsHermitian := by
  intro i
  fin_cases i <;> apply source_cubic_conic_pencil_value_hermitian

theorem source_three_actual_pencil_sum (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (x : Fin 3 → ℝ) :
    (∑ i,(x i : ℂ) • A i)=(x 0 : ℂ) • A 0+(x 1 : ℂ) • A 1+(x 2 : ℂ) • A 2 := by
  norm_num [Fin.sum_univ_succ] <;> abel

theorem source_cubic_conic_actual_tuple_evaluation (c : Fin 10 → ℝ) (a : Fin 4 → ℂ)
    (x : Fin 3 → ℝ) :
    (∑ i,(x i : ℂ) • sourceCubicConicActualTuple c a i)=
      sourceCubicConicPencilValue (sourceConicLinearValue c a (x 0) (x 1) (x 2))
        (x 0) (x 1) (x 2) (sourceConicNormU a (x 0) (x 1)) (sourceConicNormV a (x 1) (x 2)) := by
  rw [source_three_actual_pencil_sum]
  apply Matrix.ext
  intro i j
  fin_cases i <;> fin_cases j
  · change (x 0 : ℂ)*(c 2 : ℂ)+(x 1 : ℂ)*
      ((c 4+(a 0*star (a 3)+star (a 0)*a 3).re : ℝ) : ℂ)+(x 2 : ℂ)*(c 5 : ℂ)=
      (sourceConicLinearValue c a (x 0) (x 1) (x 2) : ℂ)
    simp only [sourceConicLinearValue,Complex.ofReal_add,Complex.ofReal_mul]
    ring
  · change (x 0 : ℂ)*(-a 0)+(x 1 : ℂ)*(-a 1)+(x 2 : ℂ)*(-0)= -sourceConicNormU a (x 0) (x 1)
    unfold sourceConicNormU
    ring
  · change (x 0 : ℂ)*(-0)+(x 1 : ℂ)*(-a 2)+(x 2 : ℂ)*(-a 3)= -sourceConicNormV a (x 1) (x 2)
    unfold sourceConicNormV
    ring
  · change (x 0 : ℂ)*(-star (a 0))+(x 1 : ℂ)*(-star (a 1))+(x 2 : ℂ)*(-star 0)= -star (sourceConicNormU a (x 0) (x 1))
    simp [sourceConicNormU,star_add,star_mul]
    ring
  · change (x 0 : ℂ)*0+(x 1 : ℂ)*0+(x 2 : ℂ)*1=(x 2 : ℂ)
    ring
  · change (x 0 : ℂ)*(-0)+(x 1 : ℂ)*(-1)+(x 2 : ℂ)*(-0)=(-x 1 : ℂ)
    ring
  · change (x 0 : ℂ)*(-star 0)+(x 1 : ℂ)*(-star (a 2))+(x 2 : ℂ)*(-star (a 3))= -star (sourceConicNormV a (x 1) (x 2))
    simp [sourceConicNormV,star_add,star_mul]
    ring
  · change (x 0 : ℂ)*(-0)+(x 1 : ℂ)*(-1)+(x 2 : ℂ)*(-0)=(-x 1 : ℂ)
    ring
  · change (x 0 : ℂ)*1+(x 1 : ℂ)*0+(x 2 : ℂ)*0=(x 0 : ℂ)
    ring

theorem source_cubic_nonpositive_conic_actual_representation (p : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3)
    (hconic : ∀ u v : ℝ,MvPolynomial.eval (![u^2,u*v,v^2] : Fin 3 → ℝ) p ≤ 0) :
    ∃ A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ,(∀ i,(A i).IsHermitian) ∧ p=realDeterminantPolynomial A := by
  obtain ⟨a,ha⟩ := source_cubic_actual_conic_coefficient_factor_exists p hp hconic
  let c := sourceTernaryCubicCoefficients p
  let A := sourceCubicConicActualTuple c a
  have hA : ∀ i,(A i).IsHermitian := source_cubic_conic_actual_tuple_hermitian c a
  refine ⟨A,hA,?_⟩
  apply MvPolynomial.funext
  intro x
  apply Complex.ofReal_injective
  rw [realDeterminantPolynomial_evaluation A hA,source_cubic_conic_actual_tuple_evaluation c a x,
    source_cubic_conic_entire_determinant c a ha]
  have hx : (![x 0,x 1,x 2] : Fin 3 → ℝ)=x := by
    funext i
    fin_cases i <;> rfl
  rw [← source_ternary_cubic_actual_eval p hp,hx]

end CoefficientStability
