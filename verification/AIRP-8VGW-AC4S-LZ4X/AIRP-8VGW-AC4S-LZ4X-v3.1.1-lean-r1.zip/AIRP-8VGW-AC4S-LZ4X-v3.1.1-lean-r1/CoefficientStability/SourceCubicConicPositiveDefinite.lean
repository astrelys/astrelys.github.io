import CoefficientStability.SourceCubicConicSchurScalar

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceConicTriangular (X Y Z : ℝ) (U V : ℂ) : Matrix (Fin 3) (Fin 3) ℂ :=
  !![1,0,0;
    -((X : ℂ)*star U+(Y : ℂ)*star V)/((X*Z-Y^2 : ℝ) : ℂ),1,0;
    -star V/(X : ℂ),-(Y : ℂ)/(X : ℂ),1]

theorem source_three_diagonal_congruence_entry (T : Matrix (Fin 3) (Fin 3) ℂ)
    (d : Fin 3 → ℂ) (i j : Fin 3) :
    (T.conjTranspose * Matrix.diagonal d * T) i j =
      star (T 0 i)*d 0*T 0 j + star (T 1 i)*d 1*T 1 j + star (T 2 i)*d 2*T 2 j := by
  rw [Matrix.mul_assoc, Matrix.mul_apply]
  norm_num [Matrix.diagonal_mul,Matrix.conjTranspose_apply,Fin.sum_univ_succ] <;> ring

theorem source_conic_triangular_determinant (X Y Z : ℝ) (U V : ℂ) :
    (sourceConicTriangular X Y Z U V).det=1 := by
  rw [Matrix.det_fin_three]
  change (1 : ℂ)*1*1 - 1*0*(-(Y : ℂ)/(X : ℂ)) -
    0*(-((X : ℂ)*star U+(Y : ℂ)*star V)/((X*Z-Y^2 : ℝ) : ℂ))*1 +
    0*0*(-star V/(X : ℂ)) +
    0*(-((X : ℂ)*star U+(Y : ℂ)*star V)/((X*Z-Y^2 : ℝ) : ℂ))*(-(Y : ℂ)/(X : ℂ)) -
    0*1*(-star V/(X : ℂ)) = 1
  ring

theorem source_cubic_conic_actual_congruence (h X Y Z f : ℝ) (U V : ℂ)
    (hX : X≠0) (hq : X*Z-Y^2≠0)
    (he : f=(X*Z-Y^2)*h-X*Complex.normSq U-Z*Complex.normSq V-
      Y*(U*star V+star U*V).re) :
    (sourceConicTriangular X Y Z U V).conjTranspose *
      Matrix.diagonal (fun k => ((![f/(X*Z-Y^2),(X*Z-Y^2)/X,X] k : ℝ) : ℂ)) *
        sourceConicTriangular X Y Z U V = sourceCubicConicPencilValue h X Y Z U V := by
  have hXC : (X : ℂ)≠0 := Complex.ofReal_ne_zero.mpr hX
  have hqC : (X : ℂ)*(Z : ℂ)-(Y : ℂ)^2≠0 := by exact_mod_cast hq
  apply Matrix.ext
  intro i j
  rw [source_three_diagonal_congruence_entry]
  fin_cases i <;> fin_cases j
  · change star (1 : ℂ)*((f/(X*Z-Y^2) : ℝ) : ℂ)*(1 : ℂ) + star (-((X : ℂ)*star U+(Y : ℂ)*star V)/((X*Z-Y^2 : ℝ) : ℂ))*(((X*Z-Y^2)/X : ℝ) : ℂ)*(-((X : ℂ)*star U+(Y : ℂ)*star V)/((X*Z-Y^2 : ℝ) : ℂ)) + star (-star V/(X : ℂ))*(X : ℂ)*(-star V/(X : ℂ)) = (h : ℂ)
    simpa only [star_one,one_mul,mul_one] using (source_cubic_conic_schur_completion_scalar h X Y Z f U V hX hq he).symm
  · change star (1 : ℂ)*((f/(X*Z-Y^2) : ℝ) : ℂ)*(0 : ℂ) + star (-((X : ℂ)*star U+(Y : ℂ)*star V)/((X*Z-Y^2 : ℝ) : ℂ))*(((X*Z-Y^2)/X : ℝ) : ℂ)*(1 : ℂ) + star (-star V/(X : ℂ))*(X : ℂ)*(-(Y : ℂ)/(X : ℂ)) = -U
    push_cast
    simp only [star_div₀,star_neg,star_add,star_mul,star_zero,star_one,star_star,Complex.star_def,map_div,map_neg,map_add,map_mul,map_sub,map_pow,Complex.conj_ofReal,Complex.conj_conj]
    field_simp [hXC,hqC] <;> ring
  · change star (1 : ℂ)*((f/(X*Z-Y^2) : ℝ) : ℂ)*(0 : ℂ) + star (-((X : ℂ)*star U+(Y : ℂ)*star V)/((X*Z-Y^2 : ℝ) : ℂ))*(((X*Z-Y^2)/X : ℝ) : ℂ)*(0 : ℂ) + star (-star V/(X : ℂ))*(X : ℂ)*(1 : ℂ) = -V
    push_cast
    simp only [star_div₀,star_neg,star_add,star_mul,star_zero,star_one,star_star,Complex.star_def,map_div,map_neg,map_add,map_mul,map_sub,map_pow,Complex.conj_ofReal,Complex.conj_conj]
    field_simp [hXC,hqC] <;> ring
  · change star (0 : ℂ)*((f/(X*Z-Y^2) : ℝ) : ℂ)*(1 : ℂ) + star (1 : ℂ)*(((X*Z-Y^2)/X : ℝ) : ℂ)*(-((X : ℂ)*star U+(Y : ℂ)*star V)/((X*Z-Y^2 : ℝ) : ℂ)) + star (-(Y : ℂ)/(X : ℂ))*(X : ℂ)*(-star V/(X : ℂ)) = -star U
    push_cast
    simp only [star_div₀,star_neg,star_add,star_mul,star_zero,star_one,star_star,Complex.star_def,map_div,map_neg,map_add,map_mul,map_sub,map_pow,Complex.conj_ofReal,Complex.conj_conj]
    field_simp [hXC,hqC] <;> ring
  · change star (0 : ℂ)*((f/(X*Z-Y^2) : ℝ) : ℂ)*(0 : ℂ) + star (1 : ℂ)*(((X*Z-Y^2)/X : ℝ) : ℂ)*(1 : ℂ) + star (-(Y : ℂ)/(X : ℂ))*(X : ℂ)*(-(Y : ℂ)/(X : ℂ)) = (Z : ℂ)
    push_cast
    simp only [star_div₀,star_neg,star_add,star_mul,star_zero,star_one,star_star,Complex.star_def,map_div,map_neg,map_add,map_mul,map_sub,map_pow,Complex.conj_ofReal,Complex.conj_conj]
    field_simp [hXC,hqC] <;> ring
  · change star (0 : ℂ)*((f/(X*Z-Y^2) : ℝ) : ℂ)*(0 : ℂ) + star (1 : ℂ)*(((X*Z-Y^2)/X : ℝ) : ℂ)*(0 : ℂ) + star (-(Y : ℂ)/(X : ℂ))*(X : ℂ)*(1 : ℂ) = -(Y : ℂ)
    push_cast
    simp only [star_div₀,star_neg,star_add,star_mul,star_zero,star_one,star_star,Complex.star_def,map_div,map_neg,map_add,map_mul,map_sub,map_pow,Complex.conj_ofReal,Complex.conj_conj]
    field_simp [hXC,hqC] <;> ring
  · change star (0 : ℂ)*((f/(X*Z-Y^2) : ℝ) : ℂ)*(1 : ℂ) + star (0 : ℂ)*(((X*Z-Y^2)/X : ℝ) : ℂ)*(-((X : ℂ)*star U+(Y : ℂ)*star V)/((X*Z-Y^2 : ℝ) : ℂ)) + star (1 : ℂ)*(X : ℂ)*(-star V/(X : ℂ)) = -star V
    push_cast
    simp only [star_div₀,star_neg,star_add,star_mul,star_zero,star_one,star_star,Complex.star_def,map_div,map_neg,map_add,map_mul,map_sub,map_pow,Complex.conj_ofReal,Complex.conj_conj]
    field_simp [hXC,hqC] <;> ring
  · change star (0 : ℂ)*((f/(X*Z-Y^2) : ℝ) : ℂ)*(0 : ℂ) + star (0 : ℂ)*(((X*Z-Y^2)/X : ℝ) : ℂ)*(1 : ℂ) + star (1 : ℂ)*(X : ℂ)*(-(Y : ℂ)/(X : ℂ)) = -(Y : ℂ)
    push_cast
    simp only [star_div₀,star_neg,star_add,star_mul,star_zero,star_one,star_star,Complex.star_def,map_div,map_neg,map_add,map_mul,map_sub,map_pow,Complex.conj_ofReal,Complex.conj_conj]
    field_simp [hXC,hqC] <;> ring
  · change star (0 : ℂ)*((f/(X*Z-Y^2) : ℝ) : ℂ)*(0 : ℂ) + star (0 : ℂ)*(((X*Z-Y^2)/X : ℝ) : ℂ)*(0 : ℂ) + star (1 : ℂ)*(X : ℂ)*(1 : ℂ) = (X : ℂ)
    push_cast
    simp only [star_div₀,star_neg,star_add,star_mul,star_zero,star_one,star_star,Complex.star_def,map_div,map_neg,map_add,map_mul,map_sub,map_pow,Complex.conj_ofReal,Complex.conj_conj]
    field_simp [hXC,hqC] <;> ring

theorem source_cubic_conic_actual_positive_definite (h X Y Z f : ℝ) (U V : ℂ)
    (hX : 0<X) (hq : 0<X*Z-Y^2) (hf : 0<f)
    (he : f=(X*Z-Y^2)*h-X*Complex.normSq U-Z*Complex.normSq V-
      Y*(U*star V+star U*V).re) :
    (sourceCubicConicPencilValue h X Y Z U V).PosDef := by
  let d : Fin 3 → ℂ := fun k => ((![f/(X*Z-Y^2),(X*Z-Y^2)/X,X] k : ℝ) : ℂ)
  have hd : (Matrix.diagonal d).PosDef := by
    apply Matrix.PosDef.diagonal
    intro i
    fin_cases i
    · change (0 : ℂ) < ((f/(X*Z-Y^2) : ℝ) : ℂ)
      exact_mod_cast (div_pos hf hq)
    · change (0 : ℂ) < (((X*Z-Y^2)/X : ℝ) : ℂ)
      exact_mod_cast (div_pos hq hX)
    · change (0 : ℂ) < (X : ℂ)
      exact_mod_cast hX
  have hT : IsUnit (sourceConicTriangular X Y Z U V) := by
    simpa only [Matrix.isUnit_iff_isUnit_det,source_conic_triangular_determinant] using (isUnit_one : IsUnit (1 : ℂ))
  have hp := hd.conjTranspose_mul_mul_same (Matrix.mulVec_injective_of_isUnit hT)
  rw [source_cubic_conic_actual_congruence h X Y Z f U V (ne_of_gt hX) (ne_of_gt hq) he] at hp
  exact hp

end CoefficientStability
