import CoefficientStability.CubicTensorEuler
import Mathlib.LinearAlgebra.Multilinear.Curry

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem multilinear_curry_sub {k : ℕ}
    (A B : MultilinearMap ℝ (fun _ : Fin (k+1) => Fin n → ℝ) ℝ) :
    (A-B).curryLeft=A.curryLeft-B.curryLeft := by ext x v; rfl

theorem multilinear_curry_smul {k : ℕ}
    (A : MultilinearMap ℝ (fun _ : Fin (k+1) => Fin n → ℝ) ℝ) (a : ℝ) :
    (a • A).curryLeft=a • A.curryLeft := by ext x v; rfl

theorem multilinear_single_sub_smul
    (A : MultilinearMap ℝ (fun _ : Fin 1 => Fin n → ℝ) ℝ)
    (v z : Fin n → ℝ) (b : ℝ) : A ![v-b • z]=A ![v]-b*A ![z] := by
  have he (w : Fin n → ℝ) : Function.update (0 : Fin 1 → Fin n → ℝ) 0 w=![w] := by
    ext j i
    fin_cases j
    rfl
  have h := (A.toLinearMap 0 0).map_sub v (b • z)
  rw [map_smul] at h
  change A (Function.update 0 0 (v-b • z))=A (Function.update 0 0 v)-b*A (Function.update 0 0 z) at h
  simpa only [he] using h

theorem cubicTensor_shift_repeated
    (T : MultilinearMap ℝ (fun _ : Fin 3 => Fin n → ℝ) ℝ)
    (x z v : Fin n → ℝ) (a b : ℝ) :
    T ![x-a • z,x-a • z,v-b • z]=
      T ![x,x,v]-b*T ![x,x,z]-a*T ![x,z,v]+a*b*T ![x,z,z]-
        a*T ![z,x,v]+a*b*T ![z,x,z]+a^2*T ![z,z,v]-a^2*b*T ![z,z,z] := by
  have he (x y w : Fin n → ℝ) : T ![x,y,w]=((T.curryLeft x).curryLeft y) ![w] := rfl
  simp only [he,map_sub,map_smul,MultilinearMap.sub_apply,MultilinearMap.smul_apply,
    multilinear_curry_sub,multilinear_curry_smul,LinearMap.sub_apply,LinearMap.smul_apply,
    multilinear_single_sub_smul,smul_eq_mul]
  ring

theorem symmetric_cubic_swap_first
    (T : MultilinearMap ℝ (fun _ : Fin 3 => Fin n → ℝ) ℝ)
    (hT : ∀ w (s : Equiv.Perm (Fin 3)),T (fun j => w (s j))=T w)
    (x y z : Fin n → ℝ) : T ![x,y,z]=T ![y,x,z] := by
  have h := hT ![y,x,z] (Equiv.swap 0 1)
  have he : (fun j : Fin 3 => ![y,x,z] (Equiv.swap 0 1 j))=![x,y,z] := by
    funext j
    fin_cases j <;> simp [Equiv.swap_apply_def]
  rwa [he] at h

theorem symmetric_cubic_rotate
    (T : MultilinearMap ℝ (fun _ : Fin 3 => Fin n → ℝ) ℝ)
    (hT : ∀ w (s : Equiv.Perm (Fin 3)),T (fun j => w (s j))=T w)
    (x y z : Fin n → ℝ) : T ![x,y,z]=T ![z,x,y] := by
  let r : Equiv.Perm (Fin 3) := (Equiv.swap 0 1)*(Equiv.swap 1 2)
  have h := hT ![z,x,y] r
  have he : (fun j : Fin 3 => ![z,x,y] (r j))=![x,y,z] := by
    funext j
    fin_cases j <;> simp [r,Equiv.swap_apply_def,Equiv.Perm.mul_apply]
  rwa [he] at h

theorem symmetric_cubic_shift_repeated
    (T : MultilinearMap ℝ (fun _ : Fin 3 => Fin n → ℝ) ℝ)
    (hT : ∀ w (s : Equiv.Perm (Fin 3)),T (fun j => w (s j))=T w)
    (x z v : Fin n → ℝ) (a b : ℝ) :
    T ![x-a • z,x-a • z,v-b • z]=
      T ![x,x,v]-2*a*T ![z,x,v]-b*T ![z,x,x]+
        a^2*T ![z,z,v]+2*a*b*T ![z,z,x]-a^2*b*T ![z,z,z] := by
  rw [cubicTensor_shift_repeated,
    symmetric_cubic_rotate T hT x x z,symmetric_cubic_swap_first T hT x z v,
    symmetric_cubic_rotate T hT x z z,symmetric_cubic_rotate T hT z x z]
  ring

end CoefficientStability
