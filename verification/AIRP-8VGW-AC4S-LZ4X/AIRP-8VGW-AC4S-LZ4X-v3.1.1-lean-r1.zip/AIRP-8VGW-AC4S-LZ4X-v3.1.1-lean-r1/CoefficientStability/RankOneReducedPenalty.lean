import CoefficientStability.ConeMarginScalar
import CoefficientStability.CapacityEtaUpper

noncomputable section
namespace CoefficientStability
variable {n : ℕ}

theorem rankOne_source_reduced_capacity_coefficient_lower (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (j : Fin n) (r : ℝ) (hr : r<1)
    (hboundary : (fun i => (if i=j then 1 else 0)-r)∈closure (positiveSpectralCone p n))
    (hzero : MvPolynomial.eval (fun i => (if i=j then 1 else 0)-r) p=0) :
    (sourceVn n*capacityG (n-1)/capacityG n)*
      multivariatePositiveCapacity (matrixSubstitution (rankOneUnmixingMatrix n j r) p)≤
      (matrixSubstitution (rankOneUnmixingMatrix n j r) p).coeff (squarefreeExponent n) := by
  cases n with
  | zero => omega
  | succ N =>
    have hdegree := rankOne_source_degree_drop p hn hp j r hzero
    have h := paper_reduced_variable_degree_capacity_lower _ (matrixSubstitution_homogeneous _ p (N+1) hp)
      (rankOne_source_substitution_stable p hn hn hp hs hnorm j r hr hboundary)
      (rankOne_source_substitution_coeff_nonneg p hn hn hp hs hnorm j r hr hboundary) j
      (by simpa only [Nat.add_sub_cancel] using hdegree)
    simpa only [Nat.add_sub_cancel] using h

theorem rankOne_source_eta_capacity_coefficient_lower (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (j : Fin n) (r : ℝ) (hr : r<1)
    (hboundary : (fun i => (if i=j then 1 else 0)-r)∈closure (positiveSpectralCone p n))
    (hzero : MvPolynomial.eval (fun i => (if i=j then 1 else 0)-r) p=0) :
    (sourceVn n*(1+capacityEta n))*
      multivariatePositiveCapacity (matrixSubstitution (rankOneUnmixingMatrix n j r) p)≤
      (matrixSubstitution (rankOneUnmixingMatrix n j r) p).coeff (squarefreeExponent n) := by
  have heq : sourceVn n*(1+capacityEta n)=sourceVn n*capacityG (n-1)/capacityG n := by
    unfold capacityEta
    ring
  rw [heq]
  exact rankOne_source_reduced_capacity_coefficient_lower p hn hp hs hnorm j r hr hboundary hzero

end CoefficientStability
