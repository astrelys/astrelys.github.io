import CoefficientStability.SourceStableCubicRepresentationCompact
noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder
namespace CoefficientStability
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

def sourceCubicConicPencilValue (h X Y Z : ℝ) (U V : ℂ) : Matrix (Fin 3) (Fin 3) ℂ :=
  !![(h : ℂ),-U,-V; -star U,(Z : ℂ),(-Y : ℂ); -star V,(-Y : ℂ),(X : ℂ)]

theorem source_cubic_conic_pencil_value_hermitian (h X Y Z : ℝ) (U V : ℂ) :
    (sourceCubicConicPencilValue h X Y Z U V).IsHermitian := by
  change (sourceCubicConicPencilValue h X Y Z U V).conjTranspose=sourceCubicConicPencilValue h X Y Z U V
  apply Matrix.ext
  intro i j
  fin_cases i <;> fin_cases j
  · change star (h : ℂ)=(h : ℂ)
    simp
  · change star (-star U)= -U
    simp
  · change star (-star V)= -V
    simp
  · change star (-U)= -star U
    simp
  · change star (Z : ℂ)=(Z : ℂ)
    simp
  · change star (-Y : ℂ)=(-Y : ℂ)
    simp
  · change star (-V)= -star V
    simp
  · change star (-Y : ℂ)=(-Y : ℂ)
    simp
  · change star (X : ℂ)=(X : ℂ)
    simp

theorem source_cubic_conic_pencil_value_determinant (h X Y Z : ℝ) (U V : ℂ) :
    Matrix.det (sourceCubicConicPencilValue h X Y Z U V)=
      ((X*Z-Y^2)*h-X*Complex.normSq U-Z*Complex.normSq V-
        Y*(U*star V+star U*V).re : ℂ) := by
  rw [Matrix.det_fin_three]
  change (h : ℂ)*Z*X-(h : ℂ)*(-Y)*(-Y)-(-U)*(-star U)*X+
    (-U)*(-Y)*(-star V)+(-V)*(-star U)*(-Y)-(-V)*Z*(-star V)=_
  have hu : U*star U=(Complex.normSq U : ℂ) := by
    apply Complex.ext <;> simp [Complex.normSq_apply,Complex.mul_re,Complex.mul_im] <;> ring
  have hv : V*star V=(Complex.normSq V : ℂ) := by
    apply Complex.ext <;> simp [Complex.normSq_apply,Complex.mul_re,Complex.mul_im] <;> ring
  have hc : U*star V+star U*V=((U*star V+star U*V).re : ℂ) := by
    apply Complex.ext
    · simp
    · simp [Complex.mul_im]
      ring
  push_cast
  calc
    _=((X : ℂ)*Z-Y^2)*h-X*(U*star U)-Z*(V*star V)-Y*(U*star V+star U*V) := by ring
    _=_ := by rw [hu,hv,hc];simp only [Complex.ofReal_re]

theorem source_cubic_conic_schur_positive_scalar (h X Y Z f : ℝ) (U V : ℂ)
    (hX : 0 < X) (hq : 0 < X*Z-Y^2) (hf : 0 < f)
    (he : f=(X*Z-Y^2)*h-X*Complex.normSq U-Z*Complex.normSq V-
      Y*(U*star V+star U*V).re) :
    0 < h-(X*Complex.normSq U+Z*Complex.normSq V+
      Y*(U*star V+star U*V).re)/(X*Z-Y^2) := by
  have heq : h-(X*Complex.normSq U+Z*Complex.normSq V+
      Y*(U*star V+star U*V).re)/(X*Z-Y^2)=f/(X*Z-Y^2) := by
    field_simp
    nlinarith [he]
  rw [heq]
  exact div_pos hf hq

end CoefficientStability
