import CoefficientStability.SourceOriginalCubicLocalCommutativity
import Mathlib.Analysis.InnerProductSpace.JointEigenspace

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 3500000
set_option backward.isDefEq.respectTransparency false

theorem source_hermitian_commuting_joint_basis {n m : ℕ}
    (A : Fin m → Matrix (Fin n) (Fin n) ℂ) (hA : ∀ i,(A i).IsHermitian)
    (hc : ∀ i j,A i*A j=A j*A i) :
    ∃ (e : OrthonormalBasis (Fin n) ℂ (EuclideanSpace ℂ (Fin n))) (z : Fin m → Fin n → ℂ),
      ∀ i j,(A i).toEuclideanLin (e j)=z i j • e j := by
  classical
  let T : Fin m → Module.End ℂ (EuclideanSpace ℂ (Fin n)) := fun i => (A i).toEuclideanLin
  have hT : ∀ i,(T i).IsSymmetric := fun i => Matrix.isSymmetric_toEuclideanLin_iff.mpr (hA i)
  have hC : Pairwise (fun i j => Commute (T i) (T j)) := by
    intro i j hij
    change Matrix.toLpLin 2 2 (A i) ∘ₗ Matrix.toLpLin 2 2 (A j)=
      Matrix.toLpLin 2 2 (A j) ∘ₗ Matrix.toLpLin 2 2 (A i)
    rw [← Matrix.toLpLin_mul_same,← Matrix.toLpLin_mul_same,hc i j]
  have hD := LinearMap.IsSymmetric.directSum_isInternal_of_pairwise_commute hT hC
  have hO := LinearMap.IsSymmetric.orthogonalFamily_iInf_eigenspaces hT
  have hn : Module.finrank ℂ (EuclideanSpace ℂ (Fin n))=n := by simp
  let V := fun x : Fin m → ℂ => ⨅ i,Module.End.eigenspace (T i) (x i)
  let v := fun x : Fin m → ℂ => stdOrthonormalBasis ℂ (V x)
  let b := hD.collectedBasis (fun x => (v x).toBasis)
  let J := (Σ x : Fin m → ℂ,Fin (Module.finrank ℂ (V x)))
  letI : Fintype J := FiniteDimensional.fintypeBasisIndex b
  have hb : Orthonormal ℂ b := hD.collectedBasis_orthonormal hO (fun x => (v x).orthonormal)
  let eb := b.toOrthonormalBasis hb
  have hcard : Fintype.card J=n := (Module.finrank_eq_card_basis b).symm.trans hn
  let q : J ≃ Fin n := Fintype.equivFinOfCardEq hcard
  let e := eb.reindex q
  refine ⟨e,(fun i j => (q.symm j).1 i),?_⟩
  intro i j
  have hmem : e j ∈ V (q.symm j).1 := by
    simpa only [e,eb,OrthonormalBasis.reindex_apply,Module.Basis.coe_toOrthonormalBasis,b] using
      hD.collectedBasis_mem (fun x => (v x).toBasis) (q.symm j)
  have hi := (Submodule.mem_iInf (fun a => Module.End.eigenspace (T a) ((q.symm j).1 a))).mp hmem i
  exact Module.End.mem_eigenspace_iff.mp hi

end CoefficientStability
