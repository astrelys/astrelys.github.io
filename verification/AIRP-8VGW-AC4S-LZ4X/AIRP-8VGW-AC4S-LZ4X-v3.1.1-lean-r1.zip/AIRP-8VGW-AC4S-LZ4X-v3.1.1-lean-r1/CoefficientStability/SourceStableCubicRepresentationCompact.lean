import CoefficientStability.SourceStableCubicPlanePencil

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceNormalizedCubicPsdTuples : Set (Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) :=
  {A | (∀ i,(A i).PosSemidef) ∧ (∑ i,A i)=1}

theorem source_normalized_cubic_psd_closed : IsClosed sourceNormalizedCubicPsdTuples := by
  have hP : IsClosed {A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ | ∀ i,(A i).PosSemidef} := by
    rw [Set.ofPred_forall]
    apply isClosed_iInter
    intro i
    exact Matrix.posSemidef_is_closed.preimage
      (show Continuous (fun A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ => A i) from continuous_apply i)
  exact hP.inter (isClosed_eq (by fun_prop) continuous_const)

theorem source_normalized_cubic_psd_component_norm (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A∈sourceNormalizedCubicPsdTuples) (i : Fin 3) : ‖A i‖ ≤ 1 := by
  have hle : A i ≤ 1 := by
    have h := Finset.single_le_sum (fun j _ => (hA.1 j).nonneg) (Finset.mem_univ i)
    simpa only [hA.2] using h
  exact (CStarAlgebra.norm_le_one_iff_of_nonneg (A i) (hA.1 i).nonneg).mpr hle

theorem source_normalized_cubic_psd_compact : IsCompact sourceNormalizedCubicPsdTuples := by
  apply (isCompact_closedBall (0 : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) 1).of_isClosed_subset
    source_normalized_cubic_psd_closed
  intro A hA
  rw [Metric.mem_closedBall,dist_zero_right]
  exact (pi_norm_le_iff_of_nonneg (by norm_num : (0 : ℝ) ≤ 1)).mpr
    (source_normalized_cubic_psd_component_norm A hA)

def sourceCubicPencilValueMap (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) : (Fin 3 → ℝ) → ℂ :=
  fun x => Matrix.det (∑ i,(x i : ℂ) • A i)

theorem source_cubic_pencil_value_map_continuous : Continuous sourceCubicPencilValueMap := by
  apply continuous_pi
  intro x
  unfold sourceCubicPencilValueMap
  fun_prop

theorem source_cubic_represented_values_closed :
    IsClosed (sourceCubicPencilValueMap '' sourceNormalizedCubicPsdTuples) :=
  (source_normalized_cubic_psd_compact.image source_cubic_pencil_value_map_continuous).isClosed

theorem source_stable_cubic_represented_limit
    (p : MvPolynomial (Fin 3) ℝ) (P : ℕ → MvPolynomial (Fin 3) ℝ)
    (hrep : ∀ k,∃ A∈sourceNormalizedCubicPsdTuples,P k=realDeterminantPolynomial A)
    (hlim : ∀ x : Fin 3 → ℝ,Filter.Tendsto (fun k => MvPolynomial.eval x (P k)) Filter.atTop
      (𝓝 (MvPolynomial.eval x p))) :
    ∃ A∈sourceNormalizedCubicPsdTuples,p=realDeterminantPolynomial A := by
  let V : ℕ → (Fin 3 → ℝ) → ℂ := fun k x => (MvPolynomial.eval x (P k) : ℂ)
  let v : (Fin 3 → ℝ) → ℂ := fun x => (MvPolynomial.eval x p : ℂ)
  have hV : Filter.Tendsto V Filter.atTop (𝓝 v) := by
    apply tendsto_pi_nhds.mpr
    intro x
    exact Complex.continuous_ofReal.continuousAt.tendsto.comp (hlim x)
  have hmem : v∈sourceCubicPencilValueMap '' sourceNormalizedCubicPsdTuples := by
    apply source_cubic_represented_values_closed.mem_of_tendsto hV
    apply Filter.Eventually.of_forall
    intro k
    obtain ⟨A,hA,he⟩ := hrep k
    refine ⟨A,hA,?_⟩
    funext x
    change Matrix.det (∑ i,(x i : ℂ) • A i)=(MvPolynomial.eval x (P k) : ℂ)
    rw [he,realDeterminantPolynomial_evaluation A (fun i => (hA.1 i).isHermitian)]
  obtain ⟨A,hA,he⟩ := hmem
  refine ⟨A,hA,?_⟩
  apply MvPolynomial.funext
  intro x
  apply Complex.ofReal_injective
  rw [realDeterminantPolynomial_evaluation A (fun i => (hA.1 i).isHermitian)]
  exact (congrFun he x).symm

end CoefficientStability
