import CoefficientStability.StrictRealLogDerivative

noncomputable section
namespace CoefficientStability

def nuijUnivariateStep (c : ℝ) (P : Polynomial ℝ) : Polynomial ℝ := P+Polynomial.C c*P.derivative

theorem nuij_one_step_multiplicity_bound (P : Polynomial ℝ) (hp : P.Monic)
    (hs : P.Splits) (c : ℝ) (hc : c≠0) (r : ℝ) :
    (nuijUnivariateStep c P).rootMultiplicity r≤max 1 (P.rootMultiplicity r-1) := by
  classical
  let Q := nuijUnivariateStep c P
  have hQne : Q≠0 := (monic_add_real_derivative_degree P hp c).1.ne_zero
  by_cases hr : P.IsRoot r
  · rw [nuijUnivariateStep,nuij_existing_root_multiplicity P hp.ne_zero r c hr hc]
    exact Nat.le_max_right _ _
  by_cases hqr : Q.IsRoot r
  · have hpr : P.eval r≠0 := hr
    have hd : 0<P.natDegree := by
      by_contra hh
      have hD : P.derivative=0 := Polynomial.derivative_of_natDegree_zero (by omega)
      have hval : P.eval r=0 := by simpa only [Q,nuijUnivariateStep,hD,mul_zero,add_zero,Polynomial.IsRoot] using hqr
      exact hr hval
    have hnew : Q.derivative.eval r≠0 := nuij_new_root_derivative_ne_zero P hs hd r c hpr hqr
    have hle : Q.rootMultiplicity r≤1 := by
      by_contra hh
      exact hnew ((Polynomial.one_lt_rootMultiplicity_iff_isRoot hQne).mp (by omega)).2
    exact hle.trans (Nat.le_max_left _ _)
  · rw [Polynomial.rootMultiplicity_eq_zero hqr]
    exact Nat.zero_le _

theorem nuij_univariate_iterate_properties (P : Polynomial ℝ) (hp : P.Monic)
    (hs : P.Splits) (c : ℝ) (k : ℕ) :
    ((nuijUnivariateStep c)^[k] P).Monic ∧ ((nuijUnivariateStep c)^[k] P).Splits ∧
      ((nuijUnivariateStep c)^[k] P).natDegree=P.natDegree := by
  induction k with
  | zero => exact ⟨hp,hs,rfl⟩
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    have hm := monic_add_real_derivative_degree _ ih.1 c
    exact ⟨hm.1,splits_add_real_derivative _ ih.2.1 ih.1.ne_zero c,hm.2.trans ih.2.2⟩

theorem nuij_univariate_iterate_multiplicity_bound (P : Polynomial ℝ) (hp : P.Monic)
    (hs : P.Splits) (c : ℝ) (hc : c≠0) (k : ℕ) :
    ∀ r : ℝ,((nuijUnivariateStep c)^[k] P).rootMultiplicity r≤max 1 (P.natDegree-k) := by
  classical
  induction k with
  | zero =>
    intro r
    have hle : P.rootMultiplicity r≤P.natDegree := by
      rw [← Polynomial.count_roots P]
      exact (Multiset.count_le_card r P.roots).trans (Polynomial.card_roots' P)
    exact hle.trans (Nat.le_max_right _ _)
  | succ k ih =>
    intro r
    rw [Function.iterate_succ_apply']
    have hprop := nuij_univariate_iterate_properties P hp hs c k
    have hstep := nuij_one_step_multiplicity_bound _ hprop.1 hprop.2.1 c hc r
    exact hstep.trans (by have h := ih r;omega)

theorem finite_nuij_smoothing_simple_roots (P : Polynomial ℝ) (hp : P.Monic)
    (hs : P.Splits) (c : ℝ) (hc : c≠0) :
    ((nuijUnivariateStep c)^[P.natDegree] P).Monic ∧
      ((nuijUnivariateStep c)^[P.natDegree] P).Splits ∧
      ((nuijUnivariateStep c)^[P.natDegree] P).natDegree=P.natDegree ∧
      ((nuijUnivariateStep c)^[P.natDegree] P).roots.Nodup := by
  classical
  have hprop := nuij_univariate_iterate_properties P hp hs c P.natDegree
  refine ⟨hprop.1,hprop.2.1,hprop.2.2,?_⟩
  apply Multiset.nodup_iff_count_le_one.mpr
  intro r
  rw [Polynomial.count_roots]
  simpa only [Nat.sub_self,max_eq_left (by omega : 0≤1)] using nuij_univariate_iterate_multiplicity_bound P hp hs c hc P.natDegree r

end CoefficientStability
