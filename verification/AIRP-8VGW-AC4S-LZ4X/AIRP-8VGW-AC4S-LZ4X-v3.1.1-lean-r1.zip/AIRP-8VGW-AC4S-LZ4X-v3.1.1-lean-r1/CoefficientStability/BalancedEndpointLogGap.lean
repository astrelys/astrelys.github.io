import CoefficientStability.SourceBalancedRigidity

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem half_le_log_one_add (x : ℝ) (hx0 : 0 ≤ x) (hx1 : x ≤ 1) :
    x/2 ≤ Real.log (1+x) := by
  apply le_trans _ (Real.le_log_one_add_of_nonneg hx0)
  apply (le_div_iff₀ (by positivity : 0 < x+2)).mpr
  nlinarith [mul_nonneg hx0 (sub_nonneg.mpr hx1)]

theorem source_scaled_deficit_unit_bound (hn : 3 ≤ n) (δ : ℝ)
    (hδ0 : 0 ≤ δ) (hδ : δ ≤ ((n : ℝ)-1)/2) :
    0 ≤ δ/(100000000*(n : ℝ)^8) ∧ δ/(100000000*(n : ℝ)^8) ≤ 1 := by
  have hn1 : (1 : ℝ) ≤ n := by exact_mod_cast (show 1 ≤ n by omega)
  have hn0 : (0 : ℝ) < n := by linarith
  have hp : (n : ℝ) ≤ (n : ℝ)^8 := by
    simpa only [pow_one] using pow_le_pow_right₀ hn1 (by norm_num : 1 ≤ 8)
  refine ⟨div_nonneg hδ0 (by positivity),?_⟩
  apply (div_le_one (by positivity : 0 < 100000000*(n : ℝ)^8)).mpr
  nlinarith

theorem actual_balanced_endpoint_log_gap (p : MvPolynomial (Fin n) ℝ)
    (u : Fin n → ℝ) (hn : 3 ≤ n) (hp : p.IsHomogeneous n)
    (hc : ∀ g,0 ≤ p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) (hbal : ∀ i,tiltedMoment p u i=1) :
    actualTiltDeficit p u/(2*(100000000*(n : ℝ)^8)) ≤ tiltLogRatio p (sourceVn n) u := by
  have hZ := ne_of_gt (tiltPartition_pos p u hc hnorm)
  obtain ⟨hph,hpc,hpn,hps⟩ := tiltedPolynomial_source_hypotheses p u hp hc hnorm hs
  have hgrad (i : Fin n) : MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i (tiltedPolynomial p u))=1 := by
    rw [← tiltedMoment_actual_gradient p u hZ,hbal]
  have heδ : referenceDeficit (tiltedPolynomial p u) (fun _ => 1) n=actualTiltDeficit p u := by
    unfold actualTiltDeficit
    rw [show tiltedMoment p u=(fun _ => 1) from funext hbal]
  have hgap := source_normalized_balanced_gap (tiltedPolynomial p u) hn hph hps hpn hgrad
  rw [heδ] at hgap
  have hratio : 1+actualTiltDeficit p u/(100000000*(n : ℝ)^8) ≤
      (tiltedPolynomial p u).coeff (squarefreeExponent n)/sourceVn n := by
    apply (le_div_iff₀ (sourceVn_pos (by omega))).mpr
    simpa only [mul_comm] using hgap
  have hδ := actual_tilt_deficit_source_bounds p u (by omega) hp hc hnorm hs
  have hx := source_scaled_deficit_unit_bound hn (actualTiltDeficit p u) hδ.2.2.1 hδ.2.2.2
  have hlog := (half_le_log_one_add _ hx.1 hx.2).trans
    (Real.log_le_log (by linarith : 0 < 1+actualTiltDeficit p u/(100000000*(n : ℝ)^8)) hratio)
  have he : tiltLogRatio p (sourceVn n) u=Real.log ((tiltedPolynomial p u).coeff (squarefreeExponent n)/sourceVn n) := by
    simp only [tiltLogRatio,hbal,Finset.prod_const_one,mul_one]
  rw [he]
  convert! hlog using 1 <;> ring

end CoefficientStability
