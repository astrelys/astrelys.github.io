import CoefficientStability.IteratedSourceCoefficients

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {m n : ℕ}

theorem sourceWordPartial_C_mul (l : List (Fin n)) (c : ℝ) (p : MvPolynomial (Fin n) ℝ) :
    sourceWordPartial l (MvPolynomial.C c*p)=MvPolynomial.C c*sourceWordPartial l p := by
  induction l with
  | nil => rfl
  | cons i l ih =>
    simp only [sourceWordPartial,ih,MvPolynomial.pderiv_mul,MvPolynomial.pderiv_C,zero_mul,zero_add]

theorem sourceClonePolynomial_partial (α : Fin m → ℕ) (p : MvPolynomial (Fin m) ℝ)
    (j : Fin (sourceCloneCount α)) :
    MvPolynomial.pderiv j (sourceClonePolynomial α p)=
      MvPolynomial.C (1/(α (sourceCloneBlock α j) : ℝ))*
        sourceClonePolynomial α (MvPolynomial.pderiv (sourceCloneBlock α j) p) := by
  classical
  rw [sourceClonePolynomial,rectangularSubstitution_partial]
  simp only [sourceCloneAveragingMatrix,apply_ite,MvPolynomial.C_0,ite_mul,zero_mul,
    Finset.sum_ite_eq,Finset.mem_univ,ite_true,sourceClonePolynomial]

theorem sourceClonePolynomial_zero_coeff (α : Fin m → ℕ) (p : MvPolynomial (Fin m) ℝ) :
    (sourceClonePolynomial α p).coeff 0=p.coeff 0 := by
  have h := rectangularSubstitution_eval (sourceCloneAveragingMatrix α) p (fun _ => 0)
  have he : (sourceCloneAveragingMatrix α).mulVec (fun _ => (0 : ℝ))=(fun _ => 0) := by
    funext i
    simp [Matrix.mulVec,dotProduct]
  rw [he] at h
  simpa only [sourceClonePolynomial,MvPolynomial.eval_zero',MvPolynomial.constantCoeff_eq] using h

theorem sourceWordPartial_clone (α : Fin m → ℕ) (l : List (Fin (sourceCloneCount α)))
    (p : MvPolynomial (Fin m) ℝ) :
    sourceWordPartial l (sourceClonePolynomial α p)=
      MvPolynomial.C ((l.map (fun j => 1/(α (sourceCloneBlock α j) : ℝ))).prod)*
        sourceClonePolynomial α (sourceWordPartial (l.map (sourceCloneBlock α)) p) := by
  induction l with
  | nil => simp only [sourceWordPartial,List.map_nil,List.prod_nil,MvPolynomial.C_1,one_mul]
  | cons j l ih =>
    rw [sourceWordPartial,ih,MvPolynomial.pderiv_mul,MvPolynomial.pderiv_C,zero_mul,zero_add,
      sourceClonePolynomial_partial]
    simp only [List.map_cons,List.prod_cons,sourceWordPartial,map_mul]
    ring

end CoefficientStability
