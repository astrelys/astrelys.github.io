import CoefficientStability.SourceSubsetStability

noncomputable section
namespace CoefficientStability
variable {n : ℕ}

def normalizedSourceSubsetPolynomial (p : MvPolynomial (Fin n) ℝ) (N k : ℕ) : MvPolynomial (Fin n) ℝ :=
  MvPolynomial.C (((k : ℝ)^(N.choose k))⁻¹)*sourceSubsetRootSumPolynomial p N k

theorem normalizedSourceSubsetPolynomial_properties (p : MvPolynomial (Fin n) ℝ) (N k : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hk : 0<k) :
    (normalizedSourceSubsetPolynomial p N k).IsHomogeneous (N.choose k) ∧
      UpperHalfPlaneZeroFree (normalizedSourceSubsetPolynomial p N k) ∧
      MvPolynomial.eval (fun _ => 1) (normalizedSourceSubsetPolynomial p N k)=1 := by
  have hkreal : (k : ℝ)≠0 := by exact_mod_cast Nat.ne_zero_of_lt hk
  refine ⟨(sourceSubsetRootSumPolynomial_homogeneous p N k hp hs hnorm).C_mul _,
    stable_scalar_mul _ (sourceSubsetRootSumPolynomial_stable p N k hp hs hnorm hk)
      _ (inv_ne_zero (pow_ne_zero _ hkreal)),?_⟩
  rw [normalizedSourceSubsetPolynomial,map_mul,MvPolynomial.eval_C,sourceSubsetRootSumPolynomial_at_one p N k hp hnorm]
  exact inv_mul_cancel₀ (pow_ne_zero _ hkreal)

end CoefficientStability
