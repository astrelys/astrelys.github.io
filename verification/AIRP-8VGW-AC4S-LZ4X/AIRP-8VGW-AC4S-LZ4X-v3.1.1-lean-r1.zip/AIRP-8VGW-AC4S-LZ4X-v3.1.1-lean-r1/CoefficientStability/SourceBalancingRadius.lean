import CoefficientStability.SourceBalancingField
import CoefficientStability.ScalarDerivativeIncrease

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem source_centered_balancing_radius (p : MvPolynomial (Fin n) ℝ) (hn : 3 ≤ n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|) ≤ capacityEta n/(64*(n : ℝ)))
    (hcoef : p.coeff (squarefreeExponent n) ≤ sourceVn n*(1+capacityEta n/2))
    (hsmall : Real.sqrt (∑ i,(MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1)^2) < sourceNoiseStrength n)
    (u : Fin n → ℝ) (hu : ∑ i,u i=0) (hbal : ∀ i,tiltedMoment p u i=1) :
    Real.sqrt (∑ i,u i^2) < 1 ∧ Real.sqrt (∑ i,u i^2) ≤
      Real.sqrt (∑ i,(MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1)^2)/sourceNoiseStrength n := by
  let R := Real.sqrt (∑ i,u i^2)
  let r := Real.sqrt (∑ i,(MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1)^2)
  let d := deriv (logGeneratingRay p u)
  let dd := fun s : ℝ => matrixQuadratic
    (coefficientCovariance (tiltedPolynomial p (s • u)) (tiltedMoment p (s • u))) u
  have hc := normalized_homogeneous_stable_coeff_nonneg p n hp hs hnorm
  have hZ (s : ℝ) := ne_of_gt (tiltPartition_pos p (s • u) hc hnorm)
  have hd (s : ℝ) : HasDerivAt d (dd s) s := logGeneratingRay_second_hasDerivAt p u s (hZ s)
  have hend : d 1=0 := by
    dsimp [d]
    rw [(logGeneratingRay_hasDerivAt p u 1 (hZ 1)).deriv]
    simp only [one_smul,hbal,one_mul,hu]
  have hstart : -r*R ≤ d 0 := by
    have hcs := Real.sum_mul_le_sqrt_mul_sqrt Finset.univ
      (fun i => -(MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1)) u
    simp only [neg_sq] at hcs
    have he : d 0=∑ i,(MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1)*u i := by
      dsimp [d]
      rw [(logGeneratingRay_hasDerivAt p u 0 (hZ 0)).deriv]
      simp only [zero_smul,tiltedMoment_zero p hnorm,sub_mul,one_mul,Finset.sum_sub_distrib,hu,sub_zero]
    rw [he]
    dsimp [r,R]
    simp only [neg_mul,Finset.sum_neg_distrib] at hcs
    linarith
  have hglobal (s : ℝ) (hs : s ∈ Set.Icc (0 : ℝ) 1) : 0 ≤ dd s :=
    psd_matrixQuadratic_nonneg _ (coefficientCovariance_posSemidef _ _
      (tiltedPolynomial_coefficient_nonnegative p (s • u) hc hnorm)) u
  have hlocal (s : ℝ) (hseg : s ∈ Set.Icc (0 : ℝ) 1) (hsR : s^2*R^2 ≤ 1) : sourceNoiseStrength n*R^2 ≤ dd s := by
    have hR2 : R^2=∑ i,u i^2 := Real.sq_sqrt (Finset.sum_nonneg (fun i hi => sq_nonneg (u i)))
    have hnrm : (∑ i,(s • u) i^2) ≤ 1 := by
      simpa only [Pi.smul_apply,smul_eq_mul,mul_pow,← Finset.mul_sum,hR2] using hsR
    have hh := paper_noise_hessian_from_nonnegative_unmixing p hp hnorm (sourceMixingRadius n)
      (sourceMixingRadius_pos n hn).le (source_mixing_radius_subcritical hn)
      (source_uniform_unmixed_coeff_nonnegative p hn hp hs hnorm hgrad hcoef) (s • u) u hnrm hu
    rw [actualLogHessian_eq_covariance p (s • u) (hZ s)] at hh
    simpa only [sourceNoiseStrength,hR2] using hh
  exact scalar_stationary_radius d dd (sourceNoiseStrength n) r R
    (by dsimp [sourceNoiseStrength];exact div_pos (mul_pos (by exact_mod_cast (show 0<n by omega)) (sourceMixingRadius_pos n hn)) (by norm_num))
    (Real.sqrt_nonneg _) hsmall (Real.sqrt_nonneg _) hd hend hstart hglobal hlocal

end CoefficientStability
