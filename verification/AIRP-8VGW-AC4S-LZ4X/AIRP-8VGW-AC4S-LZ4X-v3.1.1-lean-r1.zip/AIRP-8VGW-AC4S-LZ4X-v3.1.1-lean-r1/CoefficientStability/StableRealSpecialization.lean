import CoefficientStability.StableBoundarySpecialization

noncomputable section
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def coordinateTranslation (i : Fin n) (a : ℝ) :
    MvPolynomial (Fin n) ℝ →+* MvPolynomial (Fin n) ℝ :=
  MvPolynomial.eval₂Hom MvPolynomial.C
    (Function.update MvPolynomial.X i (MvPolynomial.X i+MvPolynomial.C a))

theorem coordinateTranslation_complex_eval (p : MvPolynomial (Fin n) ℝ) (i : Fin n)
    (a : ℝ) (z : Fin n → ℂ) :
    MvPolynomial.eval₂ Complex.ofRealHom z (coordinateTranslation i a p)=
      MvPolynomial.eval₂ Complex.ofRealHom (Function.update z i (z i+(a : ℂ))) p := by
  classical
  change (MvPolynomial.eval₂Hom Complex.ofRealHom z) (MvPolynomial.eval₂ _ _ p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c
    simp
  · funext j
    by_cases hji : j=i
    · subst j
      simp
    · simp [hji]

theorem stable_coordinateTranslation (p : MvPolynomial (Fin n) ℝ) (hp : UpperHalfPlaneZeroFree p)
    (i : Fin n) (a : ℝ) : UpperHalfPlaneZeroFree (coordinateTranslation i a p) := by
  intro z hz
  rw [coordinateTranslation_complex_eval]
  apply hp
  intro j
  by_cases hji : j=i
  · subst j
    simpa using hz i
  · simpa only [Function.update_of_ne hji] using hz j

theorem zero_specialization_coordinateTranslation (p : MvPolynomial (Fin n) ℝ)
    (i : Fin n) (a : ℝ) :
    coordinateSpecialization i 0 (coordinateTranslation i a p)=coordinateSpecialization i a p := by
  classical
  induction p using MvPolynomial.induction_on with
  | C c => simp [coordinateTranslation,coordinateSpecialization]
  | add p q hp hq => simp only [map_add,hp,hq]
  | mul_X p j hp =>
    simp only [map_mul,hp]
    congr 1
    by_cases hji : j=i
    · subst j
      simp [coordinateTranslation,coordinateSpecialization]
    · simp [coordinateTranslation,coordinateSpecialization,hji]

theorem stable_real_specialization_zero_or_stable (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (i : Fin n) (a : ℝ) :
    coordinateSpecialization i a p=0 ∨ UpperHalfPlaneZeroFree (coordinateSpecialization i a p) := by
  have h := stable_zero_specialization_zero_or_stable (coordinateTranslation i a p)
    (stable_coordinateTranslation p hp i a) i
  simpa only [zero_specialization_coordinateTranslation] using h

end CoefficientStability
