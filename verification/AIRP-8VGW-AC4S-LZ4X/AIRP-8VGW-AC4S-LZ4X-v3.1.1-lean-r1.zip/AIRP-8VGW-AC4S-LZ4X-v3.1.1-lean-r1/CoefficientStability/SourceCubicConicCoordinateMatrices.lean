import CoefficientStability.SourceCubicCoordinateMatrices

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000

def sourceConicCoordinateMatrix : Matrix (Fin 3) (Fin 3) ℝ :=
  !![1/(2*Real.sqrt 3),0,1/(2*Real.sqrt 3);1/2,0,-1/2;0,1,0]
def sourceConicRecoveryMatrix : Matrix (Fin 3) (Fin 3) ℝ :=
  !![Real.sqrt 3,1,0;0,0,1;Real.sqrt 3,-1,0]

theorem source_conic_coordinate_matrix_actual (z : Fin 3 → ℝ) :
    sourceConicCoordinateMatrix.mulVec z=sourceConicToDepressedValue (z 0) (z 1) (z 2) := by
  funext i
  rw [source_real_three_mulvec_entry]
  fin_cases i
  · change (1/(2*Real.sqrt 3))*z 0+0*z 1+(1/(2*Real.sqrt 3))*z 2=(z 0+z 2)/(2*Real.sqrt 3)
    ring
  · change (1/2)*z 0+0*z 1+(-1/2)*z 2=(z 0-z 2)/2
    ring
  · change 0*z 0+1*z 1+0*z 2=z 1
    ring

theorem source_conic_recovery_matrix_actual (z : Fin 3 → ℝ) :
    sourceConicRecoveryMatrix.mulVec z=![Real.sqrt 3*z 0+z 1,z 2,Real.sqrt 3*z 0-z 1] := by
  funext i
  rw [source_real_three_mulvec_entry]
  fin_cases i
  · change Real.sqrt 3*z 0+1*z 1+0*z 2=Real.sqrt 3*z 0+z 1
    ring
  · change 0*z 0+0*z 1+1*z 2=z 2
    ring
  · change Real.sqrt 3*z 0+(-1)*z 1+0*z 2=Real.sqrt 3*z 0-z 1
    ring

theorem source_conic_matrix_entire_recovery (z : Fin 3 → ℝ) :
    sourceConicCoordinateMatrix.mulVec (sourceConicRecoveryMatrix.mulVec z)=z := by
  rw [source_conic_coordinate_matrix_actual,source_conic_recovery_matrix_actual]
  have hr : Real.sqrt 3≠0 := ne_of_gt (Real.sqrt_pos.mpr (by norm_num))
  funext i
  fin_cases i
  · change (Real.sqrt 3*z 0+z 1+(Real.sqrt 3*z 0-z 1))/(2*Real.sqrt 3)=z 0
    field_simp [hr] <;> ring
  · change (Real.sqrt 3*z 0+z 1-(Real.sqrt 3*z 0-z 1))/2=z 1
    ring
  · change z 2=z 2
    rfl

end CoefficientStability
