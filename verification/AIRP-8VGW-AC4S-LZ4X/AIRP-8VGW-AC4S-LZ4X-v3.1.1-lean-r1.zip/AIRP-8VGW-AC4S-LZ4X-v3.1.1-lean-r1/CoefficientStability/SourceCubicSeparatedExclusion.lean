import CoefficientStability.SourceTernaryPermanentAlgebra

noncomputable section
namespace CoefficientStability
set_option maxHeartbeats 1200000

def sourceCubicR (d z : ℝ) := ((3-3*d+d^2)*z^2+(-6*d+12*d^2-4*d^3)*z+9*d-9*d^2+4*d^3)/2
def sourceCubicEuclideanH (d z : ℝ) := 1-8*d+10*d^2-8*d^3+(1+7*d-2*d^2)*z-(2-d)*z^2
def sourceCubicDiscriminantQ (d : ℝ) := 18-36*d+45*d^2-24*d^3+4*d^4
def sourceCubicAlpha (d : ℝ) := 1+d-2*d^2+d^3
def sourceCubicBeta (d : ℝ) := 1+d+4*d^2+8*d^3-4*d^4
def sourceCubicGamma (d : ℝ) := (1+d+40*d^2-52*d^3+16*d^4)/4
def sourceCubicPsi (d : ℝ) := -30+37*d+139*d^2-104*d^3+116*d^4-80*d^5+16*d^6

theorem source_positive_quadratic (a b c x : ℝ) (ha : 0 < a) (hd : b^2-4*a*c < 0) :
    0 < a*x^2+b*x+c := by
  by_contra hh
  have hm := mul_nonpos_of_nonneg_of_nonpos (by linarith : 0 ≤ 4*a) (le_of_not_gt hh)
  nlinarith [sq_nonneg (2*a*x+b)]

theorem source_cubic_discriminant_Q_positive (d : ℝ) (hd : 0 < d) (hd1 : d < 1) :
    0 < sourceCubicDiscriminantQ d := by
  let u := 1-d
  have hu : 0 ≤ u := by dsimp [u];linarith
  have hu1 : u ≤ 1 := by dsimp [u];linarith
  have hu2 : u^2 ≤ 1 := by nlinarith
  have he : sourceCubicDiscriminantQ d=7+2*u-3*u^2+8*u^3+4*u^4 := by
    dsimp [sourceCubicDiscriminantQ,u]
    ring
  rw [he]
  nlinarith [pow_nonneg hu 3,pow_nonneg hu 4]

theorem source_cubic_R_lower (d z : ℝ) (hd : 0 < d) (hd1 : d < 1) :
    3*d/2 < sourceCubicR d z := by
  let a := 3-3*d+d^2
  let b := -6*d+12*d^2-4*d^3
  let c := 6*d-9*d^2+4*d^3
  have ha : 0 < a := by dsimp [a];nlinarith [sq_nonneg (d-3/2)]
  have hQ := source_cubic_discriminant_Q_positive d hd hd1
  have he : b^2-4*a*c=4*d*(d-1)*sourceCubicDiscriminantQ d := by
    dsimp [a,b,c,sourceCubicDiscriminantQ]
    ring
  have hdisc : b^2-4*a*c < 0 := by
    rw [he]
    exact mul_neg_of_neg_of_pos (mul_neg_of_pos_of_neg (by positivity) (by linarith)) hQ
  have hp := source_positive_quadratic a b c z ha hdisc
  have hid : a*z^2+b*z+c=2*sourceCubicR d z-3*d := by
    dsimp [a,b,c,sourceCubicR]
    ring
  rw [hid] at hp
  linarith

theorem source_cubic_small_d (d z : ℝ) (hd : 0 < d) (hd1 : d < 1) (hR : sourceCubicR d z ≤ 3/8) : d < 1/4 := by
  have h := source_cubic_R_lower d z hd hd1
  linarith

theorem source_cubic_alpha_positive (d : ℝ) (hd : 0 ≤ d) (hd4 : d ≤ 1/4) : 0 < sourceCubicAlpha d := by
  have hm := mul_nonneg hd (by linarith : 0 ≤ 1-2*d)
  unfold sourceCubicAlpha
  nlinarith [pow_nonneg hd 3]

theorem source_cubic_psi_bound (d : ℝ) (hd : 0 ≤ d) (hd4 : d ≤ 1/4) : sourceCubicPsi d ≤ -2971/256 := by
  have h2 := pow_le_pow_left₀ hd hd4 2
  have h4 := pow_le_pow_left₀ hd hd4 4
  have h6 := pow_le_pow_left₀ hd hd4 6
  norm_num at h2 h4 h6
  unfold sourceCubicPsi
  nlinarith [pow_nonneg hd 3,pow_nonneg hd 5]

theorem source_cubic_alpha_beta_gamma_discriminant (d : ℝ) :
    (sourceCubicBeta d)^2-4*sourceCubicAlpha d*sourceCubicGamma d=d^2*sourceCubicPsi d := by
  unfold sourceCubicAlpha sourceCubicBeta sourceCubicGamma sourceCubicPsi
  ring

theorem source_cubic_separated_H_decomposition (d z : ℝ) :
    sourceCubicEuclideanH d z=(2+2*d)*(3/8-sourceCubicR d z)+
      sourceCubicAlpha d*z^2+sourceCubicBeta d*z+sourceCubicGamma d := by
  unfold sourceCubicEuclideanH sourceCubicR sourceCubicAlpha sourceCubicBeta sourceCubicGamma
  ring

theorem source_cubic_separated_H_positive (d z : ℝ) (hd : 0 < d) (hd1 : d < 1)
    (hR : sourceCubicR d z ≤ 3/8) : 0 < sourceCubicEuclideanH d z := by
  have hd4 := source_cubic_small_d d z hd hd1 hR
  have ha := source_cubic_alpha_positive d hd.le hd4.le
  have hpsi := source_cubic_psi_bound d hd.le hd4.le
  have hdisc : (sourceCubicBeta d)^2-4*sourceCubicAlpha d*sourceCubicGamma d < 0 := by
    rw [source_cubic_alpha_beta_gamma_discriminant]
    exact mul_neg_of_pos_of_neg (sq_pos_of_pos hd) (by linarith)
  have hq := source_positive_quadratic (sourceCubicAlpha d) (sourceCubicBeta d) (sourceCubicGamma d) z ha hdisc
  rw [source_cubic_separated_H_decomposition]
  have hg := mul_nonneg (by linarith : 0 ≤ 2+2*d) (sub_nonneg.mpr hR)
  linarith

end CoefficientStability
