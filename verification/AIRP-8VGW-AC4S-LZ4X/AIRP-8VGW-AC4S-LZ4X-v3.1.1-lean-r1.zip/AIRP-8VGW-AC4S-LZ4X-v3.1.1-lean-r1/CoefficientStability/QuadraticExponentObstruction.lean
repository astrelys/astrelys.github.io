import CoefficientStability.QuadraticSourceCurveDistance
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity

noncomputable section
open scoped Topology
namespace CoefficientStability

theorem scalar_quadratic_exponent_obstruction (e c D G θ : ℝ)
    (he : 0 < e) (hc : 0 < c) (hD : 0 < D) (hθ : θ < 1) :
    ∃ s : ℝ,0 < s ∧ s < e ∧ G*s^2 < c*(s^2*D)^θ := by
  let A : ℝ := c*D^θ/(|G|+1)
  have hB : 0 < |G|+1 := by positivity
  have hA : 0 < A := div_pos (mul_pos hc (Real.rpow_pos_of_pos hD _)) hB
  have hpowpos : 0 < 1-θ := sub_pos.mpr hθ
  have hcont : ContinuousAt (fun s : ℝ => (s^2)^(1-θ)) 0 :=
    (Real.continuous_rpow_const hpowpos.le).continuousAt.comp ((continuous_id.pow 2).continuousAt)
  have hnear : ∀ᶠ s : ℝ in 𝓝 0,(s^2)^(1-θ) < A :=
    hcont.eventually (gt_mem_nhds (by simpa only [zero_pow (by norm_num : (2 : ℕ)≠0),Real.zero_rpow (ne_of_gt hpowpos)] using hA))
  obtain ⟨d,hd,hall⟩ := Metric.eventually_nhds_iff.mp hnear
  let s : ℝ := min (e/2) (d/2)
  have hs : 0 < s := lt_min (by positivity) (by positivity)
  have hse : s < e := (min_le_left _ _).trans_lt (by linarith)
  have hsd : dist s 0 < d := by
    rw [Real.dist_eq,sub_zero,abs_of_pos hs]
    exact (min_le_right _ _).trans_lt (by linarith)
  have hs2 : 0 < s^2 := sq_pos_of_pos hs
  have hsmall := hall hsd
  have hm : (s^2)^(1-θ)*(|G|+1) < c*D^θ := (lt_div_iff₀ hB).mp hsmall
  have hm2 := mul_lt_mul_of_pos_right hm (Real.rpow_pos_of_pos hs2 θ)
  have hid : (s^2)^(1-θ)*(s^2)^θ=s^2 := by
    rw [← Real.rpow_add hs2]
    norm_num
  have hleft : ((s^2)^(1-θ)*(|G|+1))*(s^2)^θ=(|G|+1)*s^2 := by
    calc
      _ = (|G|+1)*((s^2)^(1-θ)*(s^2)^θ) := by ring
      _ = _ := by rw [hid]
  have hright : c*D^θ*(s^2)^θ=c*(s^2*D)^θ := by
    rw [Real.mul_rpow hs2.le hD.le]
    ring
  rw [hleft,hright] at hm2
  refine ⟨s,hs,hse,?_⟩
  have hG : G < |G|+1 := by linarith [le_abs_self G]
  exact (mul_lt_mul_of_pos_right hG hs2).trans hm2

end CoefficientStability
