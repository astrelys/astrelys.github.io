import CoefficientStability.SourceCubicMatrixDirectional
import Mathlib.Analysis.Calculus.LocalExtr.Basic

noncomputable section
open scoped BigOperators ComplexOrder Matrix.Norms.Elementwise Topology
namespace CoefficientStability
set_option maxHeartbeats 1800000
set_option backward.isDefEq.respectTransparency false

theorem source_hermitian_feasible_convex {n : ℕ} (t : Fin n → ℝ) : Convex ℝ (hermitianFeasibleTuples t) := by
  intro A hA B hB a b ha hb hab
  refine ⟨?_,?_⟩
  · intro i
    have hp : (a • A i+b • B i).PosSemidef := ((hA.1 i).2.1.smul ha).add ((hB.1 i).2.1.smul hb)
    refine ⟨hp.isHermitian,hp,?_⟩
    change Matrix.trace (a • A i+b • B i)=(t i : ℂ)
    rw [Matrix.trace_add,Matrix.trace_smul,Matrix.trace_smul,(hA.1 i).2.2,(hB.1 i).2.2,← add_smul,hab,one_smul]
  · change (∑ i,(a • A i+b • B i))=1
    rw [Finset.sum_add_distrib,← Finset.smul_sum,← Finset.smul_sum,hA.2,hB.2,← add_smul,hab,one_smul]

theorem source_cubic_strict_feasible_reference (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (hp : ∀ i,0 < t i) :
    complexReferenceTuple t ∈ hermitianFeasibleTuples t ∧ ∀ i,(complexReferenceTuple t i).PosDef := by
  have hpd (i : Fin 3) : (complexReferenceTuple t i).PosDef := by
    rw [complexReferenceTuple_source]
    exact Matrix.PosDef.one.smul (Complex.zero_lt_real.mpr (div_pos (hp i) (by norm_num)))
  refine ⟨⟨fun i => ⟨(hpd i).isHermitian,(hpd i).posSemidef,?_⟩,?_⟩,hpd⟩
  · rw [complexReferenceTuple_source,Matrix.trace_smul,Matrix.trace_one]
    norm_num
  · have h := complexBoundaryTuple_sum t (by norm_num) ht 0
    rw [complexBoundaryTuple_zero] at h
    exact h

theorem source_right_local_minimum_derivative_nonnegative (f : ℝ → ℝ) (g : ℝ)
    (hm : IsLocalMinOn f (Set.Icc 0 1) 0) (hd : HasDerivAt f g 0) : 0 ≤ g := by
  have hc : (1 : ℝ) ∈ posTangentConeAt (Set.Icc 0 1) 0 := by
    have h := sub_mem_posTangentConeAt_of_segment_subset
      (show segment ℝ (0 : ℝ) 1 ⊆ Set.Icc 0 1 by rw [segment_eq_Icc (by norm_num)])
    simpa using h
  have hn := hm.hasFDerivWithinAt_nonneg hd.hasFDerivAt.hasFDerivWithinAt hc
  simpa using hn

end CoefficientStability
