import CoefficientStability.GeneralDegreeReference

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {m : ℕ}

def sourceMultiIndexBaseline (α : Fin m → ℕ) (t : Fin m → ℝ) : ℝ :=
  ((sourceCloneCount α).factorial : ℝ)/(∏ i,((α i).factorial : ℝ))*
    (∏ i,(t i/(sourceCloneCount α : ℝ))^(α i))

theorem source_weighted_euclidean_global_gap (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (hN : 3 ≤ sourceCloneCount α) (p : MvPolynomial (Fin m) ℝ)
    (hp : p.IsHomogeneous (sourceCloneCount α)) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (t : Fin m → ℝ)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hnear : (∑ i,(t i-(α i : ℝ))^2/(α i : ℝ)) ≤ 1/(10000000000000000*(sourceCloneCount α : ℝ)^15)) :
    sourceVn (sourceCloneCount α)/(2000000000*(sourceCloneCount α : ℝ)^8*sourceCloneCoefficientWeight α)*
      sourceWeightedDeficit α p t ≤ p.coeff (sourceMultiExponent α)-sourceMultiIndexBaseline α t := by
  obtain ⟨hph,hps,hpn,hpc,hpg⟩ := sourceClonePolynomial_source_hypotheses α hα p hp hs hnorm t hgrad
  have hcg : (fun j => MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv j (sourceClonePolynomial α p)))=sourceClonedGradient α t := funext hpg
  have hclone : (∑ j,(MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv j (sourceClonePolynomial α p))-1)^2) ≤
      1/(10000000000000000*(sourceCloneCount α : ℝ)^15) := by
    simp only [hpg,sourceClonedGradient]
    rw [sourceCloneGradient_square_sum α hα t]
    exact hnear
  have hg := source_euclidean_global_coefficient_gap (sourceClonePolynomial α p) hN hph hps hpn hclone
  rw [hcg,sourceClonePolynomial_weighted_variance α hα p t hgrad,sourceClonePolynomial_squarefree_coefficient] at hg
  have href : sourceVn (sourceCloneCount α)*(∏ j,sourceClonedGradient α t j)=
      sourceCloneCoefficientWeight α*sourceMultiIndexBaseline α t := by
    rw [← sourceCloneReference_coefficient_identity,sourceScalarPower_multiindex_baseline]
    rfl
  rw [href,← mul_sub] at hg
  have hK := sourceCloneCoefficientWeight_pos α hα
  have hKne := ne_of_gt hK
  have hNne : (sourceCloneCount α : ℝ)≠0 := by exact_mod_cast (ne_of_gt (show 0<sourceCloneCount α by omega))
  calc
    _ = (sourceVn (sourceCloneCount α)/(2000000000*(sourceCloneCount α : ℝ)^8)*sourceWeightedDeficit α p t)/sourceCloneCoefficientWeight α := by field_simp
    _ ≤ _ := (div_le_iff₀ hK).mpr (by simpa only [mul_comm] using hg)

theorem source_weighted_euclidean_global_uniqueness (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (hN : 3 ≤ sourceCloneCount α) (p : MvPolynomial (Fin m) ℝ)
    (hp : p.IsHomogeneous (sourceCloneCount α)) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (t : Fin m → ℝ)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hnear : (∑ i,(t i-(α i : ℝ))^2/(α i : ℝ)) ≤ 1/(10000000000000000*(sourceCloneCount α : ℝ)^15)) :
    sourceMultiIndexBaseline α t ≤ p.coeff (sourceMultiExponent α) ∧
      (p.coeff (sourceMultiExponent α)=sourceMultiIndexBaseline α t ↔ p=scalarPower t (sourceCloneCount α)) := by
  obtain ⟨hph,hps,hpn,hpc,hpg⟩ := sourceClonePolynomial_source_hypotheses α hα p hp hs hnorm t hgrad
  have htotal : (∑ j,sourceClonedGradient α t j)=sourceCloneCount α := by
    have h := homogeneous_gradient_total (sourceClonePolynomial α p) (sourceCloneCount α) hph hpn
    simpa only [hpg] using h
  have hclone : (∑ j,(sourceClonedGradient α t j-1)^2) ≤ 1/(10000000000000000*(sourceCloneCount α : ℝ)^15) := by
    change (∑ j,(t (sourceCloneBlock α j)/(α (sourceCloneBlock α j) : ℝ)-1)^2) ≤ _
    rw [sourceCloneGradient_square_sum α hα t]
    exact hnear
  have h := source_euclidean_global_equality_iff (sourceClonePolynomial α p) (sourceClonedGradient α t)
    hN hph hps hpn htotal hpg hclone
  have href : sourceVn (sourceCloneCount α)*(∏ j,sourceClonedGradient α t j)=
      sourceCloneCoefficientWeight α*sourceMultiIndexBaseline α t := by
    rw [← sourceCloneReference_coefficient_identity,sourceScalarPower_multiindex_baseline]
    rfl
  rw [sourceClonePolynomial_squarefree_coefficient,href] at h
  have hK := sourceCloneCoefficientWeight_pos α hα
  refine ⟨?_,?_⟩
  · by_contra hh
    have hlt := mul_lt_mul_of_pos_left (lt_of_not_ge hh) hK
    linarith [h.1]
  · constructor
    · intro he
      have hcloneEq := h.2.mp (congrArg (fun a : ℝ => sourceCloneCoefficientWeight α*a) he)
      rw [← sourceClonePolynomial_scalarPower] at hcloneEq
      exact sourceClonePolynomial_injective α hα hcloneEq
    · intro he
      rw [he]
      exact sourceScalarPower_multiindex_baseline α t

theorem source_weighted_l1_global_gap_and_uniqueness (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (hN : 3 ≤ sourceCloneCount α) (p : MvPolynomial (Fin m) ℝ)
    (hp : p.IsHomogeneous (sourceCloneCount α)) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (t : Fin m → ℝ)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hnear : (∑ i,|t i-(α i : ℝ)|) ≤ 1/(1000000000*(sourceCloneCount α : ℝ)^8)) :
    sourceVn (sourceCloneCount α)/(2000000000*(sourceCloneCount α : ℝ)^8*sourceCloneCoefficientWeight α)*
      sourceWeightedDeficit α p t ≤ p.coeff (sourceMultiExponent α)-sourceMultiIndexBaseline α t ∧
    sourceMultiIndexBaseline α t ≤ p.coeff (sourceMultiExponent α) ∧
      (p.coeff (sourceMultiExponent α)=sourceMultiIndexBaseline α t ↔ p=scalarPower t (sourceCloneCount α)) := by
  have hclone : (∑ j,|sourceClonedGradient α t j-1|) ≤ 1/(1000000000*(sourceCloneCount α : ℝ)^8) := by
    change (∑ j,|t (sourceCloneBlock α j)/(α (sourceCloneBlock α j) : ℝ)-1|) ≤ _
    rw [sourceCloneGradient_l1 α hα t]
    exact hnear
  have hsquare := source_l1_radius_implies_euclidean hN (fun j => sourceClonedGradient α t j-1) hclone
  have hweight : (∑ i,(t i-(α i : ℝ))^2/(α i : ℝ)) ≤ 1/(10000000000000000*(sourceCloneCount α : ℝ)^15) := by
    simpa only [sourceClonedGradient,sourceCloneGradient_square_sum α hα t] using hsquare
  exact ⟨source_weighted_euclidean_global_gap α hα hN p hp hs hnorm t hgrad hweight,
    source_weighted_euclidean_global_uniqueness α hα hN p hp hs hnorm t hgrad hweight⟩

end CoefficientStability
