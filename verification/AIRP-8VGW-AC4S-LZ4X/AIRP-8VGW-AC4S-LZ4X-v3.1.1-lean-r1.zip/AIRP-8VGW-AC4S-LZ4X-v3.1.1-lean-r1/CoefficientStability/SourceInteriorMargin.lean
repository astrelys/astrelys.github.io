import CoefficientStability.RankOneNearOptimalExclusion
import CoefficientStability.UniformUnmixingGeometry

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n N : ℕ}

theorem actual_nonnegative_spectral_minimum_boundary (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (hN : 0<N)
    (x : Fin n → ℝ) (roots : Multiset ℝ) (hcard : roots.card=N)
    (hr : ∀ s∈roots,0≤s)
    (hf : lineRestriction p x=(roots.map (fun s => Polynomial.X+Polynomial.C s)).prod) :
    ∃ r : ℝ,0≤r ∧ (∀ s∈roots,r≤s) ∧ MvPolynomial.eval (fun i => x i-r) p=0 ∧
      (fun i => x i-r)∈closure (positiveSpectralCone p N) := by
  classical
  obtain ⟨f,henum⟩ := real_multiset_fin_enumeration roots
  have hcardpos : 0<roots.card := by omega
  letI : Nonempty (Fin roots.card) := ⟨⟨0,hcardpos⟩⟩
  obtain ⟨i,hi,hmin⟩ := Finset.exists_min_image Finset.univ f Finset.univ_nonempty
  let r : ℝ := f i
  have hrmem : r∈roots := by rw [← henum];simp [r]
  have hminimum : ∀ s∈roots,r≤s := by
    intro s hs
    rw [← henum] at hs
    have hex : ∃ j,f j=s := by simpa only [Multiset.mem_coe,List.mem_ofFn] using hs
    obtain ⟨j,rfl⟩ := hex
    exact hmin j (Finset.mem_univ j)
  have hzero := actual_linear_factor_root_zero (lineRestriction p x) roots hf r hrmem
  rw [eval_lineRestriction_real] at hzero
  have hvec : (fun j => -r+x j)=(fun j => x j-r) := by funext j;ring
  rw [hvec] at hzero
  refine ⟨r,hr r hrmem,hminimum,hzero,?_⟩
  apply nonnegative_spectral_factors_mem_closure p N (fun j => x j-r)
    (roots.map (fun s => s-r)) (by simpa only [Multiset.card_map] using hcard)
  · intro s hs
    obtain ⟨t,ht,rfl⟩ := Multiset.mem_map.mp hs
    exact sub_nonneg.mpr (hminimum t ht)
  · simpa only [sub_eq_add_neg] using lineRestriction_shift_factors p x roots hf (-r)

theorem source_polynomial_cone_margin (p : MvPolynomial (Fin n) ℝ) (hn : 3≤n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)≤capacityEta n/(64*(n : ℝ)))
    (hcoef : p.coeff (squarefreeExponent n)≤sourceVn n*(1+capacityEta n/2)) :
    coordinateSpectralMargin p n (sourceMixingRadius n) := by
  classical
  intro j
  have hjnonneg : ∀ i,0≤(Pi.single j (1 : ℝ) : Fin n → ℝ) i := by
    intro i
    simp only [Pi.single_apply]
    split_ifs <;> norm_num
  obtain ⟨roots,hcard,hr,hfactor⟩ := nonnegative_input_real_factors p n hp hs hnorm (Pi.single j 1) hjnonneg
  refine ⟨roots,hcard,?_,hfactor⟩
  intro s hsroot
  by_contra hbad
  have hsle : s≤sourceMixingRadius n := le_of_not_gt hbad
  obtain ⟨r,hr0,hmin,hzero,hclosed⟩ := actual_nonnegative_spectral_minimum_boundary p n (by omega)
    (Pi.single j 1) roots hcard hr hfactor
  have hsmall : r≤sourceMixingRadius n := (hmin s hsroot).trans hsle
  have hb : (fun i => (if i=j then 1 else 0)-r)∈closure (positiveSpectralCone p n) := by
    simpa [Pi.single_apply,eq_comm] using hclosed
  have hz : MvPolynomial.eval (fun i => (if i=j then 1 else 0)-r) p=0 := by
    simpa [Pi.single_apply,eq_comm] using hzero
  exact source_nearoptimal_small_boundary_impossible p hn hp hs hnorm hgrad hcoef j r hr0 hsmall hb hz

end CoefficientStability
