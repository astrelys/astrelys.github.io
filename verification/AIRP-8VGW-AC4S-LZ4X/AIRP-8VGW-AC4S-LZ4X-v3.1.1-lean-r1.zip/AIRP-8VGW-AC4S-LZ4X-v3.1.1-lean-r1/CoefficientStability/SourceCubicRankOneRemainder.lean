import CoefficientStability.SourceBoundedPolynomialConstant
import CoefficientStability.PolynomialLinearSubstitution

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000

theorem source_binary_rank_one_actual_line_constant (C : MvPolynomial (Fin 3) ℝ) (a k : ℝ)
    (hd : ∀ x y : ℝ,0≤4*(a*(x+k*y)^2)^3-27*(MvPolynomial.eval (![x,y,0] : Fin 3 → ℝ) C)^2)
    (r y : ℝ) :
    MvPolynomial.eval (![r-k*y,y,0] : Fin 3 → ℝ) C=MvPolynomial.eval (![r,0,0] : Fin 3 → ℝ) C := by
  let z : Fin 3 → Polynomial ℝ := ![Polynomial.C r-Polynomial.C k*Polynomial.X,Polynomial.X,0]
  have hz (s : ℝ) : (fun i => (z i).eval s)=(![r-k*s,s,0] : Fin 3 → ℝ) := by
    funext i
    fin_cases i <;> simp [z]
  have hb (s : ℝ) : (MvPolynomial.eval (fun i => (z i).eval s) C)^2≤4*(a*r^2)^3/27 := by
    rw [hz]
    have h := hd (r-k*s) s
    have he : r-k*s+k*s=r := by ring
    rw [he] at h
    linarith
  have h := source_polynomial_curve_square_bounded_constant C z _ hb y
  rw [hz y,hz 0] at h
  simpa only [mul_zero,sub_zero] using h

theorem source_binary_rank_one_actual_cubic_factor (C : MvPolynomial (Fin 3) ℝ)
    (hC : C.IsHomogeneous 3) (a k : ℝ)
    (hd : ∀ x y : ℝ,0≤4*(a*(x+k*y)^2)^3-27*(MvPolynomial.eval (![x,y,0] : Fin 3 → ℝ) C)^2)
    (x y : ℝ) :
    MvPolynomial.eval (![x,y,0] : Fin 3 → ℝ) C=
      (x+k*y)^3*MvPolynomial.eval (![1,0,0] : Fin 3 → ℝ) C := by
  have h := source_binary_rank_one_actual_line_constant C a k hd (x+k*y) y
  have he : x+k*y-k*y=x := by ring
  rw [he] at h
  rw [h]
  have hv : (fun i : Fin 3 => (x+k*y)*(![1,0,0] : Fin 3 → ℝ) i)=![x+k*y,0,0] := by
    funext i
    fin_cases i <;> simp
  have hs := homogeneous_eval_real_scale C 3 hC (x+k*y) (![1,0,0] : Fin 3 → ℝ)
  rw [hv] at hs
  exact hs

theorem source_binary_second_axis_actual_line_constant (C : MvPolynomial (Fin 3) ℝ) (a : ℝ)
    (hd : ∀ x y : ℝ,0≤4*(a*y^2)^3-27*(MvPolynomial.eval (![x,y,0] : Fin 3 → ℝ) C)^2)
    (x y : ℝ) :
    MvPolynomial.eval (![x,y,0] : Fin 3 → ℝ) C=MvPolynomial.eval (![0,y,0] : Fin 3 → ℝ) C := by
  let z : Fin 3 → Polynomial ℝ := ![Polynomial.X,Polynomial.C y,0]
  have hz (s : ℝ) : (fun i => (z i).eval s)=(![s,y,0] : Fin 3 → ℝ) := by
    funext i
    fin_cases i <;> simp [z]
  have hb (s : ℝ) : (MvPolynomial.eval (fun i => (z i).eval s) C)^2≤4*(a*y^2)^3/27 := by
    rw [hz]
    have h := hd s y
    linarith
  have h := source_polynomial_curve_square_bounded_constant C z _ hb x
  rwa [hz x,hz 0] at h

theorem source_binary_second_axis_actual_cubic_factor (C : MvPolynomial (Fin 3) ℝ)
    (hC : C.IsHomogeneous 3) (a : ℝ)
    (hd : ∀ x y : ℝ,0≤4*(a*y^2)^3-27*(MvPolynomial.eval (![x,y,0] : Fin 3 → ℝ) C)^2)
    (x y : ℝ) :
    MvPolynomial.eval (![x,y,0] : Fin 3 → ℝ) C=
      y^3*MvPolynomial.eval (![0,1,0] : Fin 3 → ℝ) C := by
  rw [source_binary_second_axis_actual_line_constant C a hd]
  have hv : (fun i : Fin 3 => y*(![0,1,0] : Fin 3 → ℝ) i)=![0,y,0] := by
    funext i
    fin_cases i <;> simp
  have hs := homogeneous_eval_real_scale C 3 hC y (![0,1,0] : Fin 3 → ℝ)
  rw [hv] at hs
  exact hs

end CoefficientStability
