import CoefficientStability.SourceOneZeroFeasibility

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 1200000

theorem source_one_zero_minimum_parameters (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b c : ℝ)
    (hpos : ∀ q ∈ sourceOneZeroEntrySet,0 < sourceTernaryOneZero t a b c q.1 q.2)
    (hmin : IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) (sourceTernaryOneZero t a b c)) :
    a=t 0/2 ∧ b=1/2 ∧ t 1=t 2 := by
  have hall := source_one_zero_minimum_line_conditions t ht a b c hpos hmin
  have hb : b=1/2 := by
    by_contra hh
    have hne : 2*b-1≠0 := by intro hz;apply hh;linarith
    let w := -(2*b+1)/(2*(2*b-1))
    have hq := (hall 1 0 w).2
    have he : sourceOneZeroLineQuadratic t a b c 1 0 w= -1 := by
      unfold sourceOneZeroLineQuadratic
      dsimp [w]
      field_simp [hne] <;> ring
    rw [he] at hq
    linarith
  have ha : a=t 0/2 := by
    by_contra hh
    have hne : 2*a-t 0≠0 := by intro hz;apply hh;linarith
    let w := -(2*a+1)/(2*(2*a-t 0))
    have hq := (hall 0 1 w).2
    have he : sourceOneZeroLineQuadratic t a b c 0 1 w= -1 := by
      unfold sourceOneZeroLineQuadratic
      dsimp [w]
      field_simp [hne] <;> ring
    rw [he] at hq
    linarith
  have hgrad := (hall 0 1 0).1
  have hap : 0 < a := by
    have h := hpos (0,1) (by decide)
    simpa [sourceTernaryOneZero] using h
  have ht0 : 0 < t 0 := by linarith
  have hs := ht
  simp only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero] at hs
  change t 0+(t 1+t 2)=3 at hs
  have ht2 : t 2=3-t 0-t 1 := by linarith
  unfold sourceOneZeroLineLinear sourceTernaryFacePartialB at hgrad
  rw [ha,hb] at hgrad
  have hprod : t 0*(t 2-t 1)=0 := by
    rw [ht2] at hgrad ⊢
    nlinarith [hgrad]
  have heq : t 1=t 2 := by
    rcases mul_eq_zero.mp hprod with hzero | hzero
    · exact False.elim ((ne_of_gt ht0) hzero)
    · linarith
  exact ⟨ha,hb,heq⟩

theorem source_one_zero_minimum_gap (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b c : ℝ)
    (hpos : ∀ q ∈ sourceOneZeroEntrySet,0 < sourceTernaryOneZero t a b c q.1 q.2)
    (hmin : IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) (sourceTernaryOneZero t a b c))
    (hbox : t 0 ≤ 3/2) :
    sourceTernaryBaseline t ≤ Matrix.permanent (sourceTernaryOneZero t a b c) ∧
      Matrix.permanent (sourceTernaryOneZero t a b c)-sourceTernaryBaseline t=t 0^2*(3-2*t 0)/36 := by
  obtain ⟨ha,hb,ht12⟩ := source_one_zero_minimum_parameters t ht a b c hpos hmin
  have hg := source_ternary_one_zero_stationary_gap t ht ht12 c
  rw [ha,hb]
  refine ⟨?_,hg⟩
  have hp : 0 ≤ t 0^2*(3-2*t 0)/36 := by
    have h : 0 ≤ 3-2*t 0 := by linarith
    positivity
  linarith

end CoefficientStability
