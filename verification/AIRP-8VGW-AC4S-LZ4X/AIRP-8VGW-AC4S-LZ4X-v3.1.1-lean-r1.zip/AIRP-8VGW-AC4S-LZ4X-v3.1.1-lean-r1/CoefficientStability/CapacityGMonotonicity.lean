import CoefficientStability.UnivariateGurvits
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Analysis.Calculus.Deriv.Inv

noncomputable section
open scoped Topology
namespace CoefficientStability

def capacityLogG (x : ℝ) : ℝ := (x-1)*Real.log (1-1/x)

theorem capacityLogG_hasDerivAt (x : ℝ) (hx : 1<x) :
    HasDerivAt capacityLogG (Real.log (1-1/x)+1/x) x := by
  have hxpos : 0<x := by linarith
  have hinner : 0<1-1/x := by
    apply sub_pos.mpr
    exact (div_lt_one hxpos).mpr hx
  have hd : HasDerivAt (fun y : ℝ => y-1) 1 x := by simpa using (hasDerivAt_id x).sub_const 1
  have hrec : HasDerivAt (fun y : ℝ => 1-1/y) (1/x^2) x := by
    simpa only [one_div,neg_neg] using (hasDerivAt_inv (ne_of_gt hxpos)).const_sub 1
  have hlog := hrec.log (ne_of_gt hinner)
  have h : HasDerivAt capacityLogG
      (1*Real.log (1-1/x)+(x-1)*(1/x^2/(1-1/x))) x := by
    convert! hd.mul hlog using 1
  have hfrac : (x-1)*(1/x^2/(1-1/x))=1/x := by
    field_simp [ne_of_gt hxpos,ne_of_gt (sub_pos.mpr hx)] <;> ring
  simpa only [hfrac,one_mul] using h

theorem capacityLogG_antitoneOn : AntitoneOn capacityLogG (Set.Ioi 1) := by
  have hc : ContinuousOn capacityLogG (Set.Ioi 1) := fun x hx =>
    (capacityLogG_hasDerivAt x hx).continuousAt.continuousWithinAt
  apply antitoneOn_of_hasDerivWithinAt_nonpos (convex_Ioi 1) hc
    (fun x hx => (capacityLogG_hasDerivAt x (interior_subset hx)).hasDerivWithinAt)
  intro x hx
  have hx1 : 1<x := interior_subset hx
  have hpos : 0<1-1/x := sub_pos.mpr ((div_lt_one (by linarith : (0 : ℝ)<x)).mpr hx1)
  have h := Real.log_le_sub_one_of_pos hpos
  linarith

theorem exp_capacityLogG_nat (n : ℕ) (hn : 2≤n) : Real.exp (capacityLogG n)=capacityG n := by
  have hn' : (2 : ℝ)≤n := by exact_mod_cast hn
  have hcast : ((n-1 : ℕ) : ℝ)=(n : ℝ)-1 := by rw [Nat.cast_sub (by omega : 1≤n),Nat.cast_one]
  have hpos : 0<1-1/(n : ℝ) := sub_pos.mpr ((div_lt_one (by linarith : (0 : ℝ)<n)).mpr (by linarith))
  rw [capacityLogG,← hcast,Real.exp_nat_mul,Real.exp_log hpos,capacityG]
  congr 1
  field_simp <;> ring

theorem capacityG_antitone : Antitone capacityG := by
  intro d k hdk
  by_cases hd : 2≤d
  · have hk : 2≤k := le_trans hd hdk
    have hd' : (1 : ℝ)<d := by exact_mod_cast (by omega : 1<d)
    have hk' : (1 : ℝ)<k := by exact_mod_cast (by omega : 1<k)
    have h := capacityLogG_antitoneOn hd' hk' (by exact_mod_cast hdk)
    have he := Real.exp_le_exp.mpr h
    simpa only [exp_capacityLogG_nat d hd,exp_capacityLogG_nat k hk] using he
  · have hgd : capacityG d=1 := by interval_cases d <;> norm_num [capacityG]
    rw [hgd]
    exact capacityG_le_one k

end CoefficientStability
