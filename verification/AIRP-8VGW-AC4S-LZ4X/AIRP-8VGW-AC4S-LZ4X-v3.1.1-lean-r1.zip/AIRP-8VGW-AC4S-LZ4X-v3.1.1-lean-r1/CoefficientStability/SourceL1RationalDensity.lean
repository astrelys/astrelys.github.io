import CoefficientStability.SourceL1RationalParameters

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 5000000

theorem source_l1_rational_parameter_d_continuous : ContinuousAt sourceL1RationalD sourceL1EtaStar := by
  have hn : sourceL1EtaStar^2-3≠0 := by nlinarith [source_l1_eta_star_bounds]
  exact continuousAt_const.div ((continuousAt_id.pow 2).sub continuousAt_const) hn

theorem source_l1_rational_parameter_distance_continuous :
    ContinuousAt (fun η : ℝ => (3-2*sourceL1RationalD η)*sourceL1RationalS η) sourceL1EtaStar := by
  have hn : sourceL1EtaStar^2-3≠0 := by nlinarith [source_l1_eta_star_bounds]
  have hs : ContinuousAt sourceL1RationalS sourceL1EtaStar :=
    continuousAt_id.div ((continuousAt_id.pow 2).sub continuousAt_const) hn
  exact (continuousAt_const.sub (continuousAt_const.mul source_l1_rational_parameter_d_continuous)).mul hs

theorem source_l1_rational_parameter_endpoint_distance :
    (3-2*sourceL1RationalD sourceL1EtaStar)*sourceL1RationalS sourceL1EtaStar=sourceCubicEpsilon0 := by
  rw [← source_l1_rational_parameter_actual_sqrt sourceL1EtaStar source_l1_eta_star_bounds,
    source_l1_eta_star_d_exact]
  have h := source_cubic_dstar_distance_exact
  norm_num [sourceCubicDistance,sourceCubicS] at h
  simpa [sourceL1BoundaryS,add_comm] using h

theorem source_l1_rational_parameter_arbitrarily_close (R : ℝ) (hR : sourceCubicEpsilon0<R) :
    ∃ η : ℚ,3<(η : ℝ) ∧ (η : ℝ)<sourceL1EtaStar ∧
      0<sourceL1RationalD (η : ℝ) ∧ sourceL1RationalD (η : ℝ)<1/8 ∧
      (3-2*sourceL1RationalD (η : ℝ))*sourceL1RationalS (η : ℝ)<R := by
  have h1 : ∀ᶠ η : ℝ in 𝓝 sourceL1EtaStar,3<η := lt_mem_nhds source_l1_eta_star_bounds
  have hdstar : sourceL1RationalD sourceL1EtaStar<1/8 := by
    rw [source_l1_eta_star_d_exact]
    exact source_l1_dstar_eighth_bound
  have h2 : ∀ᶠ η : ℝ in 𝓝 sourceL1EtaStar,sourceL1RationalD η<1/8 :=
    source_l1_rational_parameter_d_continuous.eventually (gt_mem_nhds hdstar)
  have hFstar : (3-2*sourceL1RationalD sourceL1EtaStar)*sourceL1RationalS sourceL1EtaStar<R := by
    rw [source_l1_rational_parameter_endpoint_distance]
    exact hR
  have h3 : ∀ᶠ η : ℝ in 𝓝 sourceL1EtaStar,(3-2*sourceL1RationalD η)*sourceL1RationalS η<R :=
    source_l1_rational_parameter_distance_continuous.eventually (gt_mem_nhds hFstar)
  have hall : ∀ᶠ η : ℝ in 𝓝 sourceL1EtaStar,3<η ∧ sourceL1RationalD η<1/8 ∧
      (3-2*sourceL1RationalD η)*sourceL1RationalS η<R := by
    filter_upwards [h1,h2,h3] with η h1 h2 h3
    exact ⟨h1,h2,h3⟩
  obtain ⟨δ,hδ,hnear⟩ := Metric.eventually_nhds_iff.mp hall
  obtain ⟨η,hleft,hright⟩ := exists_rat_btwn (show sourceL1EtaStar-δ/2<sourceL1EtaStar by linarith)
  have hdist : dist (η : ℝ) sourceL1EtaStar<δ := by
    rw [Real.dist_eq,abs_of_neg (by linarith : (η : ℝ)-sourceL1EtaStar<0)]
    linarith
  obtain ⟨hη,hd8,hF⟩ := hnear hdist
  have hd : 0<sourceL1RationalD (η : ℝ) := by
    unfold sourceL1RationalD
    apply one_div_pos.mpr
    nlinarith
  exact ⟨η,hη,hright,hd,hd8,hF⟩

end CoefficientStability
