import CoefficientStability.SourcePointwiseCapacity

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem source_nearbalanced_capacity_lower (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hδ : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)<2) :
    (1-(∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)/2)^n≤
      multivariatePositiveCapacity p := by
  apply le_csInf
  · exact ⟨_,⟨⟨fun _ => 1,fun _ => by norm_num⟩,rfl⟩⟩
  · rintro y ⟨x,rfl⟩
    change (1-(∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)/2)^n≤
      MvPolynomial.eval x.val p/(∏ i,x.val i)
    have hprod : 0<∏ i,x.val i := Finset.prod_pos (fun i hi => x.prop i)
    exact (le_div_iff₀ hprod).mpr
      (source_all_positive_pointwise_capacity_lower p hn hp hs hnorm x.val x.prop hδ)

theorem source_nearbalanced_capacity_manuscript_bound (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hδ : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)<1) :
    (1-(∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|))^n≤
      multivariatePositiveCapacity p := by
  have hδ0 : 0≤∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1| :=
    Finset.sum_nonneg (fun i hi => abs_nonneg _)
  have hq : 0≤1-(∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|) := by linarith
  have hbase : 1-(∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)≤
      1-(∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)/2 := by linarith
  exact (pow_le_pow_left₀ hq hbase n).trans
    (source_nearbalanced_capacity_lower p hn hp hs hnorm (by linarith))

end CoefficientStability
