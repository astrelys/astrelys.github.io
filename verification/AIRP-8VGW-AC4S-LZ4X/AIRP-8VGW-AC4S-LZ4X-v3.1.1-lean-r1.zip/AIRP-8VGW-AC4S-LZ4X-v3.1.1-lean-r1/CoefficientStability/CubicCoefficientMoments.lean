import CoefficientStability.CubicRootEstimate

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem contentRoots_sum_cubes (s : Finset (Fin n)) (g : Fin n → ℕ) (x : Fin n → ℝ) :
    ((contentRoots s g x).map (fun r => r^3)).sum=∑ i∈s,(g i : ℝ)*x i^3 := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [contentRoots]
  | @insert a s ha ih => simpa [contentRoots,Finset.sum_insert ha,nsmul_eq_mul] using ih

theorem monomialLine_third_coefficient (g : Fin n →₀ ℕ) (x : Fin n → ℝ) (N : ℕ)
    (hN : 3≤N) (hg : ∑ i,g i=N) :
    6*(monomialLine g x).coeff (N-3)=
      (∑ i,(g i : ℝ)*x i)^3-3*(∑ i,(g i : ℝ)*x i)*(∑ i,(g i : ℝ)*x i^2)+
        2*(∑ i,(g i : ℝ)*x i^3) := by
  let roots := contentRoots Finset.univ g x
  have hcard : roots.card=N := by rw [contentRoots_card,hg]
  have hpoly : realFactorPolynomial roots=monomialLine g x := by
    rw [contentRoots_factorPolynomial]
    rfl
  have hv := Multiset.prod_X_add_C_coeff roots (k := N-3) (by omega)
  rw [hcard,show N-(N-3)=3 by omega] at hv
  change (realFactorPolynomial roots).coeff (N-3)=roots.esymm 3 at hv
  rw [hpoly] at hv
  rw [hv,esymm_three_identity,contentRoots_sum,contentRoots_sum_squares,contentRoots_sum_cubes]

theorem lineRestriction_third_moments (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ)
    (N : ℕ) (hN : 3≤N) (hp : p.IsHomogeneous N) :
    6*(lineRestriction p x).coeff (N-3)=
      ∑ g∈p.support,p.coeff g*((∑ i,(g i : ℝ)*x i)^3-
        3*(∑ i,(g i : ℝ)*x i)*(∑ i,(g i : ℝ)*x i^2)+2*(∑ i,(g i : ℝ)*x i^3)) := by
  rw [lineRestriction_as_sum,Polynomial.finsetSum_coeff,Finset.mul_sum]
  simp only [Polynomial.coeff_C_mul]
  apply Finset.sum_congr rfl
  intro g hg
  have hm := monomialLine_third_coefficient g x N hN (homogeneous_mass p N hp g hg)
  nlinarith [congrArg (fun a : ℝ => p.coeff g*a) hm]

theorem lineRestriction_comp_sub (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ) (a : ℝ) :
    (lineRestriction p x).comp (Polynomial.X-Polynomial.C a)=
      lineRestriction p (fun i => x i-a) := by
  unfold lineRestriction
  change (Polynomial.compRingHom (Polynomial.X-Polynomial.C a)) (MvPolynomial.eval₂ _ _ p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext r
    simp
  · funext i
    change (Polynomial.X+Polynomial.C (x i)).comp (Polynomial.X-Polynomial.C a)=_
    simp only [Polynomial.add_comp,Polynomial.X_comp,Polynomial.C_comp,Polynomial.C_sub]
    ring

theorem central_cubic_actual_moments (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (N : ℕ) (hN : 3≤N) (hp : p.IsHomogeneous N) (x : Fin n → ℝ) :
    let y : Fin n → ℝ := fun i => x i-(∑ j,t j*x j)/(N : ℝ)
    6*MvPolynomial.eval x (centralCoefficientPolynomial p t N 3)=
      ∑ g∈p.support,p.coeff g*((∑ i,(g i : ℝ)*y i)^3-
        3*(∑ i,(g i : ℝ)*y i)*(∑ i,(g i : ℝ)*y i^2)+2*(∑ i,(g i : ℝ)*y i^3)) := by
  dsimp only
  rw [eval_centralCoefficientPolynomial,centralLineCoefficient,lineRestriction_comp_sub]
  exact lineRestriction_third_moments p _ N hN hp

end CoefficientStability
