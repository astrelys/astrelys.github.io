import CoefficientStability.SourceClonePolynomial
import Mathlib.Data.Nat.Factorial.Basic

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def sourceWordExponent : List (Fin n) → (Fin n →₀ ℕ)
  | [] => 0
  | i::l => Finsupp.single i 1+sourceWordExponent l

def sourceWordPartial : List (Fin n) → MvPolynomial (Fin n) ℝ → MvPolynomial (Fin n) ℝ
  | [],p => p
  | i::l,p => MvPolynomial.pderiv i (sourceWordPartial l p)

def sourceDerivativeNatFactor (d e : Fin n →₀ ℕ) : ℕ :=
  ∏ i,(d i+1).ascFactorial (e i)

theorem sourceDerivativeNatFactor_step (d e : Fin n →₀ ℕ) (i : Fin n) :
    sourceDerivativeNatFactor (d+Finsupp.single i 1) e*(d i+1)=
      sourceDerivativeNatFactor d (Finsupp.single i 1+e) := by
  classical
  have hstep (j : Fin n) :
      ((d+Finsupp.single i 1 : Fin n →₀ ℕ) j+1).ascFactorial (e j)*(if j=i then d i+1 else 1)=
        (d j+1).ascFactorial ((Finsupp.single i 1+e : Fin n →₀ ℕ) j) := by
    by_cases hji : j=i
    · subst j
      simp only [Finsupp.add_apply,Finsupp.single_eq_same,ite_true]
      have hid := Nat.succ_ascFactorial (d i+1) (e i)
      rw [← Nat.ascFactorial_succ] at hid
      simpa only [Nat.succ_eq_add_one,Nat.add_comm,Nat.add_left_comm,Nat.add_assoc,mul_comm] using hid
    · simp [Finsupp.add_apply,Finsupp.single_eq_of_ne hji,hji]
  have hprod := Finset.prod_congr (s₁ := (Finset.univ : Finset (Fin n))) rfl (fun j hj => hstep j)
  have hmask : (∏ j : Fin n,if j=i then d i+1 else 1)=d i+1 := by simp
  rw [Finset.prod_mul_distrib,hmask] at hprod
  exact hprod

theorem sourceWordPartial_coeff (l : List (Fin n)) (p : MvPolynomial (Fin n) ℝ) (d : Fin n →₀ ℕ) :
    (sourceWordPartial l p).coeff d=
      p.coeff (d+sourceWordExponent l)*(sourceDerivativeNatFactor d (sourceWordExponent l) : ℝ) := by
  induction l generalizing d with
  | nil => simp [sourceWordPartial,sourceWordExponent,sourceDerivativeNatFactor]
  | cons i l ih =>
    rw [sourceWordPartial,MvPolynomial.coeff_pderiv,ih]
    have he : (d+Finsupp.single i 1)+sourceWordExponent l=d+sourceWordExponent (i::l) := by
      simp only [sourceWordExponent,add_assoc]
    rw [he]
    have hf := sourceDerivativeNatFactor_step d (sourceWordExponent l) i
    have hr : (sourceDerivativeNatFactor (d+Finsupp.single i 1) (sourceWordExponent l) : ℝ)*(d i+1)=
        (sourceDerivativeNatFactor d (sourceWordExponent (i::l)) : ℝ) := by
      exact_mod_cast hf
    calc
      _ = p.coeff (d+sourceWordExponent (i::l))*
          ((sourceDerivativeNatFactor (d+Finsupp.single i 1) (sourceWordExponent l) : ℝ)*(d i+1)) := by ring
      _ = _ := by rw [hr]

theorem sourceWordPartial_zero_coeff (l : List (Fin n)) (p : MvPolynomial (Fin n) ℝ) :
    (sourceWordPartial l p).coeff 0=p.coeff (sourceWordExponent l)*
      (∏ i,((sourceWordExponent l i).factorial : ℝ)) := by
  rw [sourceWordPartial_coeff]
  simp only [zero_add,sourceDerivativeNatFactor,Finsupp.zero_apply,Nat.zero_add,Nat.one_ascFactorial,Nat.cast_prod]

end CoefficientStability
