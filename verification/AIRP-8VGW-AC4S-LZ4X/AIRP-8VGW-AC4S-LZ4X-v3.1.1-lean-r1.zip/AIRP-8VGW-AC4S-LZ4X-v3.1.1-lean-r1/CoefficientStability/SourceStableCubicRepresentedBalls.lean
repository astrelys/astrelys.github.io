import CoefficientStability.SourceStableCubicProductClass

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceStableCubicEuclideanEquality (t : Fin 3 → ℝ) (p : MvPolynomial (Fin 3) ℝ) : Prop :=
  ∃ B ∈ sourceTransportationPolytope t,p=sourceCubicProductPolynomial B ∧ sourceEuclideanEqualityDescription t B

def sourceStableCubicL1Equality (t : Fin 3 → ℝ) (p : MvPolynomial (Fin 3) ℝ) : Prop :=
  ∃ B ∈ sourceTransportationPolytope t,p=sourceCubicProductPolynomial B ∧ sourceL1EqualityDescription t B

theorem source_stable_cubic_represented_euclidean_bound (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,(t i-1)^2) ≤ 3/8) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) :
    sourceTernaryBaseline t ≤ (realDeterminantPolynomial A).coeff (squarefreeExponent 3) := by
  rw [source_realDeterminant_objective]
  exact source_cubic_matrix_euclidean_ball_inequality t ht hr A hA

theorem source_stable_cubic_represented_l1_bound (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,|t i-1|) ≤ sourceCubicEpsilon0) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) :
    sourceTernaryBaseline t ≤ (realDeterminantPolynomial A).coeff (squarefreeExponent 3) := by
  rw [source_realDeterminant_objective]
  exact source_cubic_matrix_l1_ball_inequality t ht hr A hA

theorem source_stable_cubic_represented_euclidean_equality (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,(t i-1)^2) ≤ 3/8) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) :
    (realDeterminantPolynomial A).coeff (squarefreeExponent 3)=sourceTernaryBaseline t ↔
      sourceStableCubicEuclideanEquality t (realDeterminantPolynomial A) := by
  constructor
  · intro he
    rw [source_realDeterminant_objective] at he
    obtain ⟨U,B,hB,htu,hdesc⟩ := (source_cubic_matrix_euclidean_equality_iff t ht hr A hA).mp he
    have hpoly : realDeterminantPolynomial A=sourceCubicProductPolynomial B := by
      rw [← source_cubic_actual_unitary_polynomial_invariant t A hA U,htu,source_cubic_diagonal_product_polynomial]
    exact ⟨B,hB,hpoly,hdesc⟩
  · rintro ⟨B,hB,hpoly,hdesc⟩
    rw [hpoly,source_cubic_product_squarefree_coefficient]
    exact (source_sharp_euclidean_equality_iff t ht hr B hB).mpr hdesc

theorem source_stable_cubic_represented_l1_equality (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,|t i-1|) ≤ sourceCubicEpsilon0) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) :
    (realDeterminantPolynomial A).coeff (squarefreeExponent 3)=sourceTernaryBaseline t ↔
      sourceStableCubicL1Equality t (realDeterminantPolynomial A) := by
  constructor
  · intro he
    rw [source_realDeterminant_objective] at he
    obtain ⟨U,B,hB,htu,hdesc⟩ := (source_cubic_matrix_l1_equality_iff t ht hr A hA).mp he
    have hpoly : realDeterminantPolynomial A=sourceCubicProductPolynomial B := by
      rw [← source_cubic_actual_unitary_polynomial_invariant t A hA U,htu,source_cubic_diagonal_product_polynomial]
    exact ⟨B,hB,hpoly,hdesc⟩
  · rintro ⟨B,hB,hpoly,hdesc⟩
    rw [hpoly,source_cubic_product_squarefree_coefficient]
    exact (source_sharp_l1_equality_iff t ht hr B hB).mpr hdesc

theorem source_stable_cubic_represented_euclidean_open_unique (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,(t i-1)^2) < 3/8) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) :
    (realDeterminantPolynomial A).coeff (squarefreeExponent 3)=sourceTernaryBaseline t ↔
      realDeterminantPolynomial A=scalarPower t 3 := by
  constructor
  · intro he
    rw [source_realDeterminant_objective] at he
    have hscalar := (source_cubic_matrix_euclidean_open_unique t ht hr A hA).mp he
    rw [hscalar,source_cubic_reference_determinant_polynomial]
  · intro he
    rw [he,← source_cubic_reference_determinant_polynomial,source_realDeterminant_objective,source_cubic_reference_objective]

theorem source_stable_cubic_represented_l1_open_unique (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,|t i-1|) < sourceCubicEpsilon0) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) :
    (realDeterminantPolynomial A).coeff (squarefreeExponent 3)=sourceTernaryBaseline t ↔
      realDeterminantPolynomial A=scalarPower t 3 := by
  constructor
  · intro he
    rw [source_realDeterminant_objective] at he
    have hscalar := (source_cubic_matrix_l1_open_unique t ht hr A hA).mp he
    rw [hscalar,source_cubic_reference_determinant_polynomial]
  · intro he
    rw [he,← source_cubic_reference_determinant_polynomial,source_realDeterminant_objective,source_cubic_reference_objective]

end CoefficientStability
