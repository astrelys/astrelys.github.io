import CoefficientStability.ActualShortFieldGlobalGap

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem source_large_coefficient_global_gap (p : MvPolynomial (Fin n) ℝ) (hn : 3 ≤ n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hlarge : sourceVn n*(1+capacityEta n/2) ≤ p.coeff (squarefreeExponent n)) :
    sourceVn n/(2000000000*(n : ℝ)^8)*actualTiltDeficit p 0 ≤
      p.coeff (squarefreeExponent n)-sourceVn n*(∏ i,tiltedMoment p 0 i) := by
  have hc := normalized_homogeneous_stable_coeff_nonneg p n hp hs hnorm
  have hn0 : (0 : ℝ)<n := by exact_mod_cast (show 0<n by omega)
  have hn1 : (1 : ℝ) ≤ n := by linarith [show (3 : ℝ) ≤ n by exact_mod_cast hn]
  obtain ⟨hQ,htrace,ht0,ht,hT⟩ := actual_tilt_relative_ingredients p 0 hn hp hc hnorm hs
  have hprod := marginal_product_upper (tiltedMoment p 0) ht0 ht
  have hδ : actualTiltDeficit p 0 ≤ ((n : ℝ)-1)/2 :=
    (actual_tilt_deficit_source_bounds p 0 (by omega) hp hc hnorm hs).2.2.2
  have hpow : (n : ℝ)^2 ≤ (n : ℝ)^8 := pow_le_pow_right₀ hn1 (by norm_num : 2 ≤ 8)
  have hη := capacityEta_lower n hn
  have hηbound : 1 ≤ 2*(n : ℝ)^2*capacityEta n := by
    have hh := (div_le_iff₀ (by positivity : 0 < 2*(n : ℝ)^2)).mp hη
    nlinarith
  have hη0 := (capacityEta_pos n hn).le
  have hnum : actualTiltDeficit p 0/(2000000000*(n : ℝ)^8) ≤ capacityEta n/2 := by
    apply (div_le_iff₀ (by positivity : 0 < 2000000000*(n : ℝ)^8)).mpr
    have hh := mul_le_mul_of_nonneg_right hpow hη0
    have hn2 : (n : ℝ) ≤ 2*(n : ℝ)^2 := by nlinarith
    have hbig : 1 ≤ (n : ℝ)^8*capacityEta n*2 := by nlinarith
    have hbigN : (n : ℝ) ≤ (n : ℝ)^8*capacityEta n*2000000000 := by
      have hp1 : (n : ℝ) ≤ (n : ℝ)^6 := by simpa only [pow_one] using pow_le_pow_right₀ hn1 (by norm_num : 1 ≤ 6)
      have hm := mul_le_mul_of_nonneg_left hηbound (pow_nonneg hn0.le 6)
      nlinarith
    nlinarith
  have hmul := mul_le_mul_of_nonneg_left hnum (sourceVn_pos (show 0<n by omega)).le
  have hbase := mul_le_mul_of_nonneg_left hprod (sourceVn_pos (show 0<n by omega)).le
  have he : sourceVn n/(2000000000*(n : ℝ)^8)*actualTiltDeficit p 0=
      sourceVn n*(actualTiltDeficit p 0/(2000000000*(n : ℝ)^8)) := by ring
  rw [he]
  nlinarith

theorem source_unbalanced_global_gap_criterion (p : MvPolynomial (Fin n) ℝ) (hn : 3 ≤ n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hpeel : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|) ≤ capacityEta n/(64*(n : ℝ)))
    (hhalf : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|) ≤ 1/2)
    (hrsmall : Real.sqrt (∑ i,(MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1)^2) < sourceNoiseStrength n)
    (hrshort : (n : ℝ)*(Real.sqrt (∑ i,(MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1)^2)/sourceNoiseStrength n) ≤ 1/24)
    (hrsq : (Real.sqrt (∑ i,(MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1)^2)/sourceNoiseStrength n)^2 ≤ 1/(64*(n : ℝ)*(100000000*(n : ℝ)^8))) :
    sourceVn n/(2000000000*(n : ℝ)^8)*actualTiltDeficit p 0 ≤
      p.coeff (squarefreeExponent n)-sourceVn n*(∏ i,tiltedMoment p 0 i) := by
  by_cases hlarge : sourceVn n*(1+capacityEta n/2) ≤ p.coeff (squarefreeExponent n)
  · exact source_large_coefficient_global_gap p hn hp hs hnorm hlarge
  have hcoef := (lt_of_not_ge hlarge).le
  have hc := normalized_homogeneous_stable_coeff_nonneg p n hp hs hnorm
  obtain ⟨u,hu,hbal,hcap⟩ := source_centered_balancing_field_exists p hn hp hs hnorm hpeel hcoef
  have hR := (source_centered_balancing_radius p hn hp hs hnorm hpeel hcoef hrsmall u hu hbal).2
  have hshort : (n : ℝ)*Real.sqrt (∑ i,u i^2) ≤ 1/24 :=
    (mul_le_mul_of_nonneg_left hR (by positivity)).trans hrshort
  have hsq : (∑ i,u i^2) ≤ 1/(64*(n : ℝ)*(100000000*(n : ℝ)^8)) := by
    have hh := pow_le_pow_left₀ (Real.sqrt_nonneg (∑ i,u i^2)) hR 2
    rw [Real.sq_sqrt (Finset.sum_nonneg (fun i hi => sq_nonneg _))] at hh
    exact hh.trans hrsq
  have hprod := marginal_product_lower (fun i => MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-0)
    (by simpa only [sub_zero] using hhalf.trans (by norm_num : (1/2 : ℝ) ≤ 1))
  have hmarg : (1/2 : ℝ) ≤ ∏ i,tiltedMoment p 0 i := by
    simp only [sub_zero] at hprod
    simp_rw [tiltedMoment_zero p hnorm]
    linarith
  exact actual_short_balancing_coefficient_gap p u hn hp hc hnorm hs
    (source_nearbalanced_squarefree_pos p (by omega) hp hs hnorm (hhalf.trans_lt (by norm_num))) hbal hshort hsq hmarg

end CoefficientStability
