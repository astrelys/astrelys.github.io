import CoefficientStability.DerivativePurePositivity

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem pure_term_le_eval (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ) (N : ℕ) (i : Fin n)
    (hc : ∀ g,0≤p.coeff g) (hx : ∀ j,0≤x j) (hpure : 0<p.coeff (Finsupp.single i N)) :
    p.coeff (Finsupp.single i N)*x i^N≤MvPolynomial.eval x p := by
  have he : MvPolynomial.eval x p=∑ g∈p.support,p.coeff g*(∏ j,x j^g j) := by
    conv_lhs => rw [p.as_sum]
    simp only [map_sum,eval_monomial_univ]
  rw [he]
  have hprod : (∏ j,x j^((Finsupp.single i N) j))=x i^N := by simp [Finsupp.single_apply]
  rw [← hprod]
  exact Finset.single_le_sum
    (fun g hg => mul_nonneg (hc g) (Finset.prod_nonneg (fun j hj => pow_nonneg (hx j) _)))
    (MvPolynomial.mem_support_iff.mpr (ne_of_gt hpure))

theorem exists_positive_pure_lower (hn : 0<n) (p : MvPolynomial (Fin n) ℝ)
    (hpure : ∀ i,0<p.coeff (Finsupp.single i n)) :
    ∃ c : ℝ,0<c ∧ ∀ i,c≤p.coeff (Finsupp.single i n) := by
  classical
  letI : Nonempty (Fin n) := ⟨⟨0,hn⟩⟩
  obtain ⟨i,hi,hmin⟩ := Finset.exists_min_image Finset.univ
    (fun i : Fin n => p.coeff (Finsupp.single i n)) Finset.univ_nonempty
  exact ⟨_,hpure i,fun j => hmin j (Finset.mem_univ j)⟩

theorem simplex_exists_coordinate_ge_one (hn : 0<n) (x : Fin n → ℝ) (hxs : ∑ i,x i=(n : ℝ)) :
    ∃ i,1≤x i := by
  classical
  by_contra h
  push_neg at h
  let i0 : Fin n := ⟨0,hn⟩
  have hh : (∑ i,x i)<∑ _ : Fin n,(1 : ℝ) := Finset.sum_lt_sum
    (fun i hi => (h i).le) ⟨i0,Finset.mem_univ i0,h i0⟩
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,mul_one] at hh
  linarith

theorem simplex_pure_eval_lower (hn : 0<n) (p : MvPolynomial (Fin n) ℝ)
    (hc : ∀ g,0≤p.coeff g) (c : ℝ) (hpos : 0<c)
    (hpure : ∀ i,c≤p.coeff (Finsupp.single i n))
    (x : Fin n → ℝ) (hx : ∀ i,0≤x i) (hxs : ∑ i,x i=(n : ℝ)) : c≤MvPolynomial.eval x p := by
  obtain ⟨i,hi⟩ := simplex_exists_coordinate_ge_one hn x hxs
  have hp : 0<p.coeff (Finsupp.single i n) := lt_of_lt_of_le hpos (hpure i)
  have hpow : 1≤x i^n := one_le_pow₀ hi
  have hterm := pure_term_le_eval p x n i hc hx hp
  nlinarith [hpure i,mul_nonneg hp.le (sub_nonneg.mpr hpow)]

theorem simplex_capacity_sublevel_product_lower (hn : 0<n) (p : MvPolynomial (Fin n) ℝ)
    (hc : ∀ g,0≤p.coeff g) (c M : ℝ) (hcpos : 0<c) (hM : 0<M)
    (hpure : ∀ i,c≤p.coeff (Finsupp.single i n))
    (x : Fin n → ℝ) (hx : ∀ i,0<x i) (hxs : ∑ i,x i=(n : ℝ))
    (hsub : MvPolynomial.eval x p/(∏ i,x i)≤M) : c/M≤∏ i,x i := by
  have hprod : 0<∏ i,x i := Finset.prod_pos (fun i hi => hx i)
  have hupper := (div_le_iff₀ hprod).mp hsub
  have hlower := simplex_pure_eval_lower hn p hc c hcpos hpure x (fun i => (hx i).le) hxs
  apply (div_le_iff₀ hM).mpr
  nlinarith

end CoefficientStability
