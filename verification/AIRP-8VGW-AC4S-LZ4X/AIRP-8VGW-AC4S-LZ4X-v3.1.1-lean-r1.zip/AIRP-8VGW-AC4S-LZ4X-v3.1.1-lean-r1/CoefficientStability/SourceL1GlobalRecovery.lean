import CoefficientStability.SourceL1StationaryRecovery

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1600000

theorem source_l1_separated_swap_positive (t : Fin 3 → ℝ) (a b : ℝ)
    (hpos : ∀ q ∈ sourceSeparatedEntrySet,0 < sourceTernarySeparatedZeros t a b q.1 q.2) :
    ∀ q ∈ sourceSeparatedEntrySet,0 < sourceTernarySeparatedZeros (sourcePermutedTraces t (Equiv.swap 0 1)) b a q.1 q.2 := by
  intro q hq
  have hm : ∀ q : Fin 3 × Fin 3,q ∈ sourceSeparatedEntrySet →
      ((Equiv.swap 0 1) q.1,(Equiv.swap 0 1) q.2) ∈ sourceSeparatedEntrySet := by decide
  have h := hpos _ (hm q hq)
  have he := congrFun (congrFun (source_l1_separated_swap t a b) q.1) q.2
  change sourceTernarySeparatedZeros t a b ((Equiv.swap 0 1) q.1) ((Equiv.swap 0 1) q.2)=_ at he
  rw [← he]
  exact h

theorem source_l1_every_separated_minimum_recovery (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b : ℝ)
    (hpos : ∀ q ∈ sourceSeparatedEntrySet,0 < sourceTernarySeparatedZeros t a b q.1 q.2)
    (hmin : IsMinOn Matrix.permanent (sourceTransportationPolytope t) (sourceTernarySeparatedZeros t a b)) :
    ∃ (r c : Equiv.Perm (Fin 3)) (u v : ℝ),0 < u ∧ 0 < v ∧ u+v < 1 ∧
      sourcePermutedTraces t r=sourceL1ChartTraces u v ∧
      sourcePermutedMatrix (sourceTernarySeparatedZeros t a b) r c=sourceL1ChartMatrix u v := by
  obtain ⟨ha0,ha1,hb0,hb1,hd0,hd1,heq,hrel,hor⟩ :=
    source_l1_actual_stationary_bounds t ht a b hpos hmin.isLocalMinOn
  rcases hor with hor | hor
  · obtain ⟨u,v,hu,hv,huv,htc,hmc⟩ := source_l1_actual_oriented_recovery t ht a b hpos hmin.isLocalMinOn hor.1 hor.2
    refine ⟨Equiv.refl _,Equiv.refl _,u,v,hu,hv,huv,?_,?_⟩
    · exact htc
    · exact hmc
  · let s : Equiv.Perm (Fin 3) := Equiv.swap 0 1
    have hts : (∑ i,sourcePermutedTraces t s i)=3 := (source_permuted_trace_sum t s).trans ht
    have hps := source_l1_separated_swap_positive t a b hpos
    have hms := source_permuted_global_minimum t (sourceTernarySeparatedZeros t a b) hmin s s
    rw [source_l1_separated_swap] at hms
    obtain ⟨u,v,hu,hv,huv,htc,hmc⟩ := source_l1_actual_oriented_recovery
      (sourcePermutedTraces t s) hts b a hps hms.isLocalMinOn hor.2 hor.1
    refine ⟨s,s,u,v,hu,hv,huv,htc,?_⟩
    rw [source_l1_separated_swap]
    exact hmc

theorem source_permuted_l1_distance {n : ℕ} (t : Fin n → ℝ) (r : Equiv.Perm (Fin n)) :
    (∑ i,|sourcePermutedTraces t r i-1|)=∑ i,|t i-1| :=
  Equiv.sum_comp r (fun i => |t i-1|)

end CoefficientStability
