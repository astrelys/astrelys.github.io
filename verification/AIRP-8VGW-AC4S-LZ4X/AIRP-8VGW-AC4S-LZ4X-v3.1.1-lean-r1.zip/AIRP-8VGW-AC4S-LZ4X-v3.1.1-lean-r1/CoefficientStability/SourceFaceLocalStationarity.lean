import CoefficientStability.SourceCubicStationaryChart
import Mathlib.Analysis.Calculus.LocalExtr.Basic
import Mathlib.Analysis.Calculus.Deriv.Polynomial

noncomputable section
open scoped BigOperators Topology
open Filter
namespace CoefficientStability
set_option maxHeartbeats 1200000

theorem source_local_min_curve_derivative_zero {E : Type*} [TopologicalSpace E]
    (f : E → ℝ) (C : Set E) (p : E) (γ : ℝ → E) (v : ℝ)
    (hγ : Continuous γ) (hzero : γ 0=p)
    (hfeas : ∃ e : ℝ,0 < e ∧ ∀ s : ℝ,|s| < e → γ s ∈ C)
    (hmin : IsLocalMinOn f C p) (hder : HasDerivAt (f ∘ γ) v 0) : v=0 := by
  obtain ⟨e,he,hnear⟩ := hfeas
  let J : Set ℝ := Set.Ioo (-e) e
  have hmem : J ⊆ γ ⁻¹' C := fun s hs => hnear s (abs_lt.mpr hs)
  have hz : (0 : ℝ) ∈ J := by constructor <;> linarith
  have hstart : IsLocalMinOn f C (γ 0) := by rw [hzero];exact hmin
  have hcomp := hstart.comp_continuousOn hmem hγ.continuousOn hz
  exact (hcomp.isLocalMin (isOpen_Ioo.mem_nhds hz)).hasDerivAt_eq_zero hder

def sourceSeparatedEntrySet : Finset (Fin 3 × Fin 3) := (Finset.univ.erase (0,0)).erase (1,1)

theorem source_ternary_separated_marginals (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b : ℝ) :
    (∀ i,∑ j,sourceTernarySeparatedZeros t a b i j=t i) ∧
      ∀ j,∑ i,sourceTernarySeparatedZeros t a b i j=1 := by
  have hs := ht
  simp only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero] at hs
  change t 0+(t 1+t 2)=3 at hs
  constructor
  · intro i
    fin_cases i <;> norm_num [sourceTernarySeparatedZeros,sourceTernaryOneZero,Fin.sum_univ_succ] <;> ring
  · intro j
    fin_cases j <;> norm_num [sourceTernarySeparatedZeros,sourceTernaryOneZero,Fin.sum_univ_succ] <;> linarith

theorem source_ternary_separated_affine (t : Fin 3 → ℝ) (a b u v s : ℝ) (i j : Fin 3) :
    sourceTernarySeparatedZeros t (a+s*u) (b+s*v) i j=sourceTernarySeparatedZeros t a b i j+
      s*(sourceTernarySeparatedZeros t (a+u) (b+v) i j-sourceTernarySeparatedZeros t a b i j) := by
  fin_cases i <;> fin_cases j <;> norm_num [sourceTernarySeparatedZeros,sourceTernaryOneZero] <;> ring

theorem source_ternary_separated_feasible_near (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b u v : ℝ)
    (hpos : ∀ q ∈ sourceSeparatedEntrySet,0 < sourceTernarySeparatedZeros t a b q.1 q.2) :
    ∃ e : ℝ,0 < e ∧ ∀ s : ℝ,|s| < e → sourceTernarySeparatedZeros t (a+s*u) (b+s*v) ∈ sourceTransportationPolytope t := by
  let base : {q // q ∈ sourceSeparatedEntrySet} → ℝ := fun q => sourceTernarySeparatedZeros t a b q.val.1 q.val.2
  let slope : {q // q ∈ sourceSeparatedEntrySet} → ℝ := fun q =>
    sourceTernarySeparatedZeros t (a+u) (b+v) q.val.1 q.val.2-sourceTernarySeparatedZeros t a b q.val.1 q.val.2
  obtain ⟨e,he,hnear⟩ := finite_affine_positive_near_zero base slope (fun q => hpos q.val q.property)
  refine ⟨e,he,?_⟩
  intro s hs
  obtain ⟨hrow,hcol⟩ := source_ternary_separated_marginals t ht (a+s*u) (b+s*v)
  refine ⟨?_,hrow,hcol⟩
  intro i j
  by_cases h0 : (i,j)=(0,0)
  · have hi : i=0 := congrArg Prod.fst h0
    have hj : j=0 := congrArg Prod.snd h0
    simp [hi,hj,sourceTernarySeparatedZeros,sourceTernaryOneZero]
  · by_cases h1 : (i,j)=(1,1)
    · have hi : i=1 := congrArg Prod.fst h1
      have hj : j=1 := congrArg Prod.snd h1
      simp [hi,hj,sourceTernarySeparatedZeros,sourceTernaryOneZero]
    · have hq : (i,j) ∈ sourceSeparatedEntrySet := by simp [sourceSeparatedEntrySet,h0,h1]
      have h := hnear s hs ⟨(i,j),hq⟩
      rw [source_ternary_separated_affine]
      exact h.le

theorem source_ternary_separated_curve_continuous (t : Fin 3 → ℝ) (a b u v : ℝ) :
    Continuous (fun s : ℝ => sourceTernarySeparatedZeros t (a+s*u) (b+s*v)) := by
  apply continuous_pi
  intro i
  apply continuous_pi
  intro j
  fin_cases i <;> fin_cases j <;> simp only [sourceTernarySeparatedZeros,sourceTernaryOneZero,Matrix.cons_val_zero,Matrix.cons_val_succ]
  all_goals fun_prop

theorem source_ternary_face_partialA_actual (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b : ℝ) :
    HasDerivAt (fun s : ℝ => Matrix.permanent (sourceTernarySeparatedZeros t (a+s) b)) (sourceTernaryFacePartialA t a b) 0 := by
  let P : Polynomial ℝ := Polynomial.C (2*b)*Polynomial.X^2+
    Polynomial.C (t 1+(2*t 2-7)*b+2*b^2)*Polynomial.X+Polynomial.C (t 0*b)
  have he : (fun s : ℝ => Matrix.permanent (sourceTernarySeparatedZeros t (a+s) b))=(fun s => P.eval (a+s)) := by
    funext s
    rw [sourceTernarySeparatedZeros,source_ternary_one_zero_expansion t ht]
    simp only [P,Polynomial.eval_add,Polynomial.eval_mul,Polynomial.eval_C,Polynomial.eval_pow,Polynomial.eval_X]
    ring
  rw [he]
  have h := (P.hasDerivAt (a+0)).comp 0 ((hasDerivAt_id (0 : ℝ)).const_add a)
  have hv : P.derivative.eval (a+0)*1=sourceTernaryFacePartialA t a b := by
    simp only [P,Polynomial.derivative_add,Polynomial.derivative_mul,Polynomial.derivative_C,
      Polynomial.derivative_pow,Polynomial.derivative_X,Polynomial.eval_add,Polynomial.eval_mul,
      Polynomial.eval_C,Polynomial.eval_X,Polynomial.eval_pow]
    norm_num
    unfold sourceTernaryFacePartialA
    ring
  rw [hv] at h
  simpa only [Function.comp_def] using h

theorem source_ternary_face_partialB_actual (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b : ℝ) :
    HasDerivAt (fun s : ℝ => Matrix.permanent (sourceTernarySeparatedZeros t a (b+s))) (sourceTernaryFacePartialB t a b) 0 := by
  let P : Polynomial ℝ := Polynomial.C (2*a)*Polynomial.X^2+
    Polynomial.C (t 0+(2*t 2-7)*a+2*a^2)*Polynomial.X+Polynomial.C (a*t 1)
  have he : (fun s : ℝ => Matrix.permanent (sourceTernarySeparatedZeros t a (b+s)))=(fun s => P.eval (b+s)) := by
    funext s
    rw [sourceTernarySeparatedZeros,source_ternary_one_zero_expansion t ht]
    simp only [P,Polynomial.eval_add,Polynomial.eval_mul,Polynomial.eval_C,Polynomial.eval_pow,Polynomial.eval_X]
    ring
  rw [he]
  have h := (P.hasDerivAt (b+0)).comp 0 ((hasDerivAt_id (0 : ℝ)).const_add b)
  have hv : P.derivative.eval (b+0)*1=sourceTernaryFacePartialB t a b := by
    simp only [P,Polynomial.derivative_add,Polynomial.derivative_mul,Polynomial.derivative_C,
      Polynomial.derivative_pow,Polynomial.derivative_X,Polynomial.eval_add,Polynomial.eval_mul,
      Polynomial.eval_C,Polynomial.eval_X,Polynomial.eval_pow]
    norm_num
    unfold sourceTernaryFacePartialB
    ring
  rw [hv] at h
  simpa only [Function.comp_def] using h

end CoefficientStability
