import CoefficientStability.MatrixHessianCoercivity

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem hermitian_trace_square_frobenius (B : Matrix (Fin n) (Fin n) ℂ) (hB : B.IsHermitian) :
    (Matrix.trace (B*B)).re=complexFrobeniusSq B := by
  change (∑ r,∑ c,B r c*B c r).re=complexFrobeniusSq B
  simp only [Complex.re_sum,complexFrobeniusSq]
  apply Finset.sum_congr rfl
  intro r hr
  apply Finset.sum_congr rfl
  intro c hc
  have he := congrArg (fun M : Matrix (Fin n) (Fin n) ℂ => M r c) hB.eq
  change star (B c r)=B r c at he
  have hre := congrArg Complex.re he
  have him := congrArg Complex.im he
  simp only [Complex.star_def,Complex.conj_re,Complex.conj_im] at hre him
  simp only [Complex.mul_re]
  rw [← hre,← him]
  ring

theorem trace_sum_square (B : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    Matrix.trace ((∑ i,B i)*(∑ i,B i))=∑ i,∑ j,Matrix.trace (B i*B j) := by
  simp only [Matrix.sum_mul,Matrix.mul_sum,Matrix.trace_sum]
  exact Finset.sum_comm

theorem trace_offdiagonal_sum (B : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    (∑ i,∑ j,if j=i then (0 : ℂ) else Matrix.trace (B i*B j))=
      Matrix.trace ((∑ i,B i)*(∑ i,B i))-∑ i,Matrix.trace (B i*B i) := by
  have he (i j : Fin n) : (if j=i then (0 : ℂ) else Matrix.trace (B i*B j))=
      Matrix.trace (B i*B j)-(if j=i then Matrix.trace (B i*B i) else 0) := by
    by_cases h : j=i <;> simp [h]
  simp only [he,Finset.sum_sub_distrib,Finset.sum_ite_eq',Finset.mem_univ,ite_true]
  rw [trace_sum_square]

theorem hermitian_offdiagonal_frobenius (B : Fin n → Matrix (Fin n) (Fin n) ℂ)
    (hB : ∀ i,(B i).IsHermitian) :
    (∑ i,∑ j,if j=i then (0 : ℂ) else Matrix.trace (B i*B j)).re=
      complexFrobeniusSq (∑ i,B i)-∑ i,complexFrobeniusSq (B i) := by
  rw [trace_offdiagonal_sum]
  simp only [Complex.sub_re,Complex.re_sum,hermitian_trace_square_frobenius _ (hB _)]
  have hsum : (∑ i,B i).IsHermitian := by
    change Matrix.conjTranspose (∑ i,B i)=∑ i,B i
    simp only [Matrix.conjTranspose_sum,fun i => (hB i).eq]
  rw [hermitian_trace_square_frobenius _ hsum]

end CoefficientStability
