import CoefficientStability.CentralNormBounds
import CoefficientStability.QuadraticNorm
import CoefficientStability.MixedDiagonalCoefficient

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def polarizationRemainderConstant (n : ℕ) : ℝ := ∑ j∈Finset.range (n-2),
  (n.choose (j+3) : ℝ)*(((j+3 : ℕ) : ℝ)*n)^(j+3)/((j+3).factorial : ℝ)*2^(j+3)

def stableHigherRemainder (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) : MvPolynomial (Fin n) ℝ :=
  ∑ j∈Finset.range (n-2),(scalarLinear t n)^(n-(j+3))*centralCoefficientPolynomial p t n (j+3)

theorem sqrt_variance_power_le_cubic (d : ℝ) (k : ℕ) (hk : 3≤k) (hd : 0≤d) (hd1 : d≤1) :
    Real.sqrt (2*d)^k≤2^k*d*Real.sqrt d := by
  have hs : 0≤Real.sqrt d := Real.sqrt_nonneg d
  have hs1 : Real.sqrt d≤1 := Real.sqrt_le_one.mpr hd1
  have hsq := Real.sq_sqrt hd
  have hs2 := Real.sq_sqrt (by positivity : 0≤2*d)
  have h : Real.sqrt (2*d)≤2*Real.sqrt d := by nlinarith [Real.sqrt_nonneg (2*d)]
  have hpow : Real.sqrt d^k≤d*Real.sqrt d := by
    have he : k=(k-3)+3 := by omega
    rw [he,pow_add]
    have hsmall : Real.sqrt d^(k-3)≤1 := pow_le_one₀ hs hs1
    have hmul := mul_le_mul_of_nonneg_right hsmall (pow_nonneg hs 3)
    have hc : Real.sqrt d^3=d*Real.sqrt d := by nlinarith [sq_nonneg (Real.sqrt d)]
    simpa only [one_mul,hc] using hmul
  calc
    _ ≤ (2*Real.sqrt d)^k := pow_le_pow_left₀ (Real.sqrt_nonneg _) h k
    _ = 2^k*Real.sqrt d^k := mul_pow _ _ _
    _ ≤ 2^k*(d*Real.sqrt d) := mul_le_mul_of_nonneg_left hpow (by positivity)
    _ = _ := by ring

theorem centralCoefficient_higher_cubic_bound (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hn : 2≤n) (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i)
    (hd : 0≤referenceDeficit p t n) (hd1 : referenceDeficit p t n≤1)
    (k : ℕ) (hk : 3≤k) (hkn : k≤n) :
    coefficientL1 (centralCoefficientPolynomial p t n k)≤
      ((n.choose k : ℝ)*((k : ℝ)*n)^k/(k.factorial : ℝ)*2^k)*
        (referenceDeficit p t n*Real.sqrt (referenceDeficit p t n)) := by
  have h := paper_central_coefficientL1_bound p t n k hn hkn hp hnorm hstable hgrad
  have hpow := sqrt_variance_power_le_cubic (referenceDeficit p t n) k hk hd hd1
  calc
    _ ≤ _ := h
    _ ≤ ((n.choose k : ℝ)*((k : ℝ)*n)^k/(k.factorial : ℝ))*
        (2^k*referenceDeficit p t n*Real.sqrt (referenceDeficit p t n)) := by
      exact mul_le_mul_of_nonneg_left hpow (by positivity)
    _ = _ := by ring

theorem stableHigherRemainder_coefficientL1 (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hn : 2≤n) (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p) (ht : ∑ i,t i=n) (ht0 : ∀ i,0≤t i)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i)
    (hd : 0≤referenceDeficit p t n) (hd1 : referenceDeficit p t n≤1) :
    coefficientL1 (stableHigherRemainder p t)≤
      polarizationRemainderConstant n*(referenceDeficit p t n*Real.sqrt (referenceDeficit p t n)) := by
  unfold stableHigherRemainder
  apply (coefficientL1_sum_le _ _).trans
  unfold polarizationRemainderConstant
  rw [Finset.sum_mul]
  apply Finset.sum_le_sum
  intro j hj
  have hmul := coefficientL1_mul_le ((scalarLinear t n)^(n-(j+3))) (centralCoefficientPolynomial p t n (j+3))
  rw [scalarLinear_power_coefficientL1 t n (n-(j+3)) (by omega) ht ht0,one_mul] at hmul
  apply hmul.trans
  exact centralCoefficient_higher_cubic_bound p t hn hp hnorm hstable hgrad hd hd1 (j+3)
    (by omega) (by have h := Finset.mem_range.mp hj;omega)

theorem abs_coefficient_le_coefficientL1 (p : MvPolynomial (Fin n) ℝ) (d : Fin n →₀ ℕ) :
    |p.coeff d|≤coefficientL1 p := by
  classical
  by_cases hd : d∈p.support
  · exact Finset.single_le_sum (fun i _ => abs_nonneg (p.coeff i)) hd
  · have hz : p.coeff d=0 := MvPolynomial.notMem_support_iff.mp hd
    simpa [hz] using coefficientL1_nonneg p

theorem stableHigherRemainder_coefficient_bound (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hn : 2≤n) (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p) (ht : ∑ i,t i=n) (ht0 : ∀ i,0≤t i)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i)
    (hd : 0≤referenceDeficit p t n) (hd1 : referenceDeficit p t n≤1) :
    |(stableHigherRemainder p t).coeff (squarefreeExponent n)|≤
      polarizationRemainderConstant n*(referenceDeficit p t n*Real.sqrt (referenceDeficit p t n)) :=
  (abs_coefficient_le_coefficientL1 _ _).trans
    (stableHigherRemainder_coefficientL1 p t hn hp hnorm hstable ht ht0 hgrad hd hd1)

end CoefficientStability
