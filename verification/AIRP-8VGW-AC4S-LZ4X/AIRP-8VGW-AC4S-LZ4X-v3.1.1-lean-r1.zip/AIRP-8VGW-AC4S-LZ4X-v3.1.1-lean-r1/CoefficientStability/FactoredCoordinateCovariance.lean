import CoefficientStability.BalancedSliceOptimizingField

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n m : ℕ}

theorem factored_coordinate_tiltedMoment (p : MvPolynomial (Fin n) ℝ)
    (u : Fin n → ℝ) (i : Fin n) (C z : ℝ) (hC : 0<C) (hz : 0<z)
    (b : Fin m → ℝ) (hb : ∀ j,0<b j)
    (hf : ∀ s : ℝ,tiltPartition p (u+s • Pi.single i 1)=C*∏ j,(1+b j*z*Real.exp s))
    (s : ℝ) :
    tiltedMoment p (u+s • Pi.single i 1) i=∑ j,b j*z*Real.exp s/(1+b j*z*Real.exp s) := by
  have hpos (t : ℝ) (j : Fin m) : 0<1+b j*z*Real.exp t := by
    have hbj := hb j
    positivity
  have hZ : tiltPartition p (u+s • Pi.single i 1)≠0 := by
    rw [hf];exact ne_of_gt (mul_pos hC (Finset.prod_pos (fun j hj => hpos s j)))
  have heq : (fun t : ℝ => Real.log (tiltPartition p (u+t • Pi.single i 1)))=
      (fun t => Real.log C+∑ j,Real.log (1+b j*z*Real.exp t)) := by
    funext t
    rw [hf,Real.log_mul (ne_of_gt hC) (Finset.prod_ne_zero_iff.mpr (fun j hj => ne_of_gt (hpos t j))),
      Real.log_prod (fun j hj => ne_of_gt (hpos t j))]
  have hlog := tiltLogPartition_path_hasDerivAt p u (Pi.single i 1) s hZ
  have hd : HasDerivAt (fun t : ℝ => Real.log C+∑ j,Real.log (1+b j*z*Real.exp t))
      (∑ j,b j*z*Real.exp s/(1+b j*z*Real.exp s)) s := by
    have h := (HasDerivAt.fun_sum (u := (Finset.univ : Finset (Fin m))) (fun j hj =>
      (((Real.hasDerivAt_exp s).const_mul (b j*z)).const_add 1).log (ne_of_gt (hpos s j)))).const_add (Real.log C)
    convert! h using 1
  rw [heq] at hlog
  have h := hlog.unique hd
  simpa [Pi.single_apply] using h

theorem factored_coordinate_covariance (p : MvPolynomial (Fin n) ℝ)
    (u : Fin n → ℝ) (i : Fin n) (C z : ℝ) (hC : 0<C) (hz : 0<z)
    (b : Fin m → ℝ) (hb : ∀ j,0<b j)
    (hf : ∀ s : ℝ,tiltPartition p (u+s • Pi.single i 1)=C*∏ j,(1+b j*z*Real.exp s)) :
    coefficientCovariance (tiltedPolynomial p u) (tiltedMoment p u) i i=
      ∑ j,(b j*z/(1+b j*z)-(b j*z/(1+b j*z))^2) := by
  have hpos (j : Fin m) : 0<1+b j*z := by
    have hbj := hb j
    positivity
  have hZ : tiltPartition p u≠0 := by
    have h := hf 0
    simp only [zero_smul,add_zero,Real.exp_zero,mul_one] at h
    rw [h];exact ne_of_gt (mul_pos hC (Finset.prod_pos (fun j hj => hpos j)))
  have hder (j : Fin m) : HasDerivAt (fun s : ℝ => b j*z*Real.exp s/(1+b j*z*Real.exp s))
      (b j*z/(1+b j*z)-(b j*z/(1+b j*z))^2) 0 := by
    have h := ((Real.hasDerivAt_exp (0 : ℝ)).const_mul (b j*z)).div
      (((Real.hasDerivAt_exp (0 : ℝ)).const_mul (b j*z)).const_add 1)
      (by simpa only [Real.exp_zero,mul_one] using ne_of_gt (hpos j))
    convert! h using 1
    simp only [Real.exp_zero,mul_one]
    field_simp <;> ring
  have hsum := HasDerivAt.fun_sum (u := (Finset.univ : Finset (Fin m))) (fun j hj => hder j)
  have heq : (fun s : ℝ => tiltedMoment p (u+s • Pi.single i 1) i)=
      (fun s : ℝ => ∑ j,b j*z*Real.exp s/(1+b j*z*Real.exp s)) :=
    funext (factored_coordinate_tiltedMoment p u i C z hC hz b hb hf)
  have hm := tiltedMoment_coordinate_hasDerivAt p u hZ i i
  rw [heq] at hm
  rw [tilted_covariance_from_moments p u hZ]
  exact hm.unique hsum

end CoefficientStability
