import CoefficientStability.SourceCubicBlockPositivity

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 2800000
set_option backward.isDefEq.respectTransparency false

def sourceCubicUnitaryAction (U : Matrix.unitaryGroup (Fin 3) ℂ) :
    (Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) →ₗ[ℂ] (Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) where
  toFun A := fun i => Unitary.conjStarAlgAut ℂ (Matrix (Fin 3) (Fin 3) ℂ) U (A i)
  map_add' A B := by funext i;exact map_add _ _ _
  map_smul' a A := by
    funext i
    change Unitary.conjStarAlgAut ℂ (Matrix (Fin 3) (Fin 3) ℂ) U (a • A i)=
      a • Unitary.conjStarAlgAut ℂ (Matrix (Fin 3) (Fin 3) ℂ) U (A i)
    simp only [Unitary.conjStarAlgAut_apply,mul_smul_comm,smul_mul_assoc]

@[simp] theorem source_cubic_unitary_action_apply (U : Matrix.unitaryGroup (Fin 3) ℂ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (i : Fin 3) :
    sourceCubicUnitaryAction U A i=Unitary.conjStarAlgAut ℂ (Matrix (Fin 3) (Fin 3) ℂ) U (A i) := rfl

theorem source_cubic_unitary_trace (U : Matrix.unitaryGroup (Fin 3) ℂ) (X : Matrix (Fin 3) (Fin 3) ℂ) :
    Matrix.trace (Unitary.conjStarAlgAut ℂ (Matrix (Fin 3) (Fin 3) ℂ) U X)=Matrix.trace X := by
  rw [Unitary.conjStarAlgAut_apply,Matrix.trace_mul_cycle,Unitary.coe_star_mul_self,one_mul]

theorem source_cubic_unitary_sum (U : Matrix.unitaryGroup (Fin 3) ℂ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hs : (∑ i,A i)=1) :
    (∑ i,sourceCubicUnitaryAction U A i)=1 := by
  simp only [source_cubic_unitary_action_apply]
  rw [← map_sum,hs,map_one]

theorem source_cubic_unitary_mixed_invariant (U : Matrix.unitaryGroup (Fin 3) ℂ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hs : (∑ i,A i)=1) :
    complexMixedDiscriminant (sourceCubicUnitaryAction U A)=complexMixedDiscriminant A := by
  rw [source_cubic_mixed_separable_objective _ (source_cubic_unitary_sum U A hs),
    source_cubic_mixed_separable_objective A hs]
  simp only [source_cubic_unitary_action_apply,← map_pow,source_cubic_unitary_trace]

theorem source_cubic_unitary_feasible (t : Fin 3 → ℝ) (U : Matrix.unitaryGroup (Fin 3) ℂ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : A ∈ hermitianFeasibleTuples t) :
    sourceCubicUnitaryAction U A ∈ hermitianFeasibleTuples t := by
  refine ⟨?_,source_cubic_unitary_sum U A hA.2⟩
  intro i
  have hp : (sourceCubicUnitaryAction U A i).PosSemidef := by
    simpa only [source_cubic_unitary_action_apply,Unitary.conjStarAlgAut_apply,Matrix.star_eq_conjTranspose]
      using (hA.1 i).2.1.mul_mul_conjTranspose_same (U : Matrix (Fin 3) (Fin 3) ℂ)
  refine ⟨hp.isHermitian,hp,?_⟩
  rw [source_cubic_unitary_action_apply,source_cubic_unitary_trace]
  exact (hA.1 i).2.2

theorem source_cubic_unitary_action_inverse (U : Matrix.unitaryGroup (Fin 3) ℂ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) :
    sourceCubicUnitaryAction (star U) (sourceCubicUnitaryAction U A)=A := by
  funext i
  simp only [source_cubic_unitary_action_apply]
  rw [← Unitary.conjStarAlgAut_mul_apply]
  simp

theorem source_cubic_unitary_local_minimum (t : Fin 3 → ℝ) (U : Matrix.unitaryGroup (Fin 3) ℂ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : A ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A) :
    IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (sourceCubicUnitaryAction U A) := by
  let D := sourceCubicUnitaryAction U A
  let ψ := sourceCubicUnitaryAction (star U)
  have hD : D ∈ hermitianFeasibleTuples t := source_cubic_unitary_feasible t U A hA
  have hm0 : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (ψ D) := by
    rw [source_cubic_unitary_action_inverse]
    exact hm
  have hc := hm0.comp_continuousOn (fun Y hY => source_cubic_unitary_feasible t (star U) Y hY)
    ψ.continuous_of_finiteDimensional.continuousOn hD
  have he : (hermitianMixedObjective ∘ ψ) =ᶠ[𝓝[hermitianFeasibleTuples t] D] hermitianMixedObjective := by
    filter_upwards [self_mem_nhdsWithin] with Y hY
    exact congrArg Complex.re (source_cubic_unitary_mixed_invariant (star U) Y hY.2)
  exact hc.congr he hD

end CoefficientStability
