import CoefficientStability.StableEffectiveGap

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem paper_stable_local_coefficient_growth (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : 0<scalarHessianLambda t) :
    ∃ a e : ℝ,0<a ∧ 0<e ∧ ∀ p : MvPolynomial (Fin n) ℝ,
      p.IsHomogeneous n → MvPolynomial.eval (fun _ => 1) p=1 → UpperHalfPlaneZeroFree p →
      (∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) →
      coefficientL1 (p-scalarPower t n)<e →
      a*referenceDeficit p t n≤(p-scalarPower t n).coeff (squarefreeExponent n) ∧
      (p≠scalarPower t n → 0<(p-scalarPower t n).coeff (squarefreeExponent n)) := by
  let a0 := sourceHessianFactor t*(scalarHessianLambda t/(n : ℝ)^2)
  let B := polarizationRemainderConstant n
  have hnpos : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
  have ha0 : 0<a0 := mul_pos (sourceHessianFactor_pos t hn htpos) (div_pos hl (sq_pos_of_pos hnpos))
  have hB : 0≤B := polarizationRemainderConstant_nonnegative n
  obtain ⟨r,hr,hr1,habsorb⟩ := cubic_remainder_absorption a0 B ha0 hB
  let C : ℝ := (n : ℝ)*((n : ℝ)-1)
  have hn2 : (2 : ℝ)≤n := by exact_mod_cast hn
  have hC : 0<C := mul_pos hnpos (by linarith)
  have hM : ∀ i,t i≤(n : ℝ) := by
    intro i
    have h := Finset.single_le_sum (fun j (_ : j∈(Finset.univ : Finset (Fin n))) => (htpos j).le)
      (Finset.mem_univ i)
    rw [ht] at h
    exact h
  refine ⟨a0/2,4*r/C,by positivity,by positivity,?_⟩
  intro p hp hnorm hstable hgrad hnear
  have hd := referenceDeficit_nonneg p t n hn hp hnorm hstable hgrad
  have hlow := paper_coefficient_distance_lower p t n hn hp hnorm ht
  change 4*referenceDeficit p t n/C≤coefficientL1 (p-scalarPower t n) at hlow
  have hdr : referenceDeficit p t n≤r := by
    have h := (div_lt_div_iff_of_pos_right hC).mp (lt_of_le_of_lt hlow hnear)
    linarith
  have hgap := paper_stable_effective_gap p t hn hp hnorm hstable ht htpos hgrad
    (n : ℝ) hM hl (hdr.trans hr1)
  change a0*referenceDeficit p t n-B*(referenceDeficit p t n*Real.sqrt (referenceDeficit p t n))≤_ at hgap
  have hfinal := (habsorb _ hd hdr).trans hgap
  refine ⟨hfinal,?_⟩
  intro hpne
  have hdne : referenceDeficit p t n≠0 := by
    intro he
    exact hpne ((referenceDeficit_zero_iff_scalarPower p t n hn hp hnorm hstable ht hgrad).mp he)
  have hdpos : 0<referenceDeficit p t n := lt_of_le_of_ne hd (Ne.symm hdne)
  exact lt_of_lt_of_le (mul_pos (by positivity : 0<a0/2) hdpos) hfinal

theorem paper_stable_local_variance_growth (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i)
    (hradius : (∑ i,(t i-1)^2)<(n : ℝ)/((n : ℝ)-1)) :
    ∃ a e : ℝ,0<a ∧ 0<e ∧ ∀ p : MvPolynomial (Fin n) ℝ,
      p.IsHomogeneous n → MvPolynomial.eval (fun _ => 1) p=1 → UpperHalfPlaneZeroFree p →
      (∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) →
      coefficientL1 (p-scalarPower t n)<e →
      a*referenceDeficit p t n≤p.coeff (squarefreeExponent n)-(n.factorial : ℝ)/(n : ℝ)^n*(∏ i,t i) ∧
      (p≠scalarPower t n → (n.factorial : ℝ)/(n : ℝ)^n*(∏ i,t i)<p.coeff (squarefreeExponent n)) := by
  obtain ⟨a,e,ha,he,h⟩ := paper_stable_local_coefficient_growth t hn ht htpos
    ((scalarHessianLambda_pos_iff_radius t hn ht).mpr hradius)
  refine ⟨a,e,ha,he,?_⟩
  intro p hp hnorm hstable hgrad hnear
  have hg := h p hp hnorm hstable hgrad hnear
  simpa [scalarPower_squarefree_coefficient,sub_pos] using hg

end CoefficientStability
