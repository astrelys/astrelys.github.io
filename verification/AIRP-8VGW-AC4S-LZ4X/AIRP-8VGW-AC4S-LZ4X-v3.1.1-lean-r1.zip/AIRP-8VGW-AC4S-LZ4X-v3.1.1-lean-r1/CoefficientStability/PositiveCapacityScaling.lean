import CoefficientStability.SourceNearBalancedCapacity

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem multivariatePositiveCapacity_positive_C_mul (p : MvPolynomial (Fin n) ℝ)
    (hp : ∀ g,0≤p.coeff g) (c : ℝ) (hc : 0<c) :
    multivariatePositiveCapacity (MvPolynomial.C c*p)=c*multivariatePositiveCapacity p := by
  have hcp : ∀ g,0≤(MvPolynomial.C c*p).coeff g := by
    intro g
    rw [MvPolynomial.coeff_C_mul]
    exact mul_nonneg hc.le (hp g)
  have hraw := multivariate_capacity_bddBelow p hp
  have hscaled := multivariate_capacity_bddBelow (MvPolynomial.C c*p) hcp
  have hlower : c*multivariatePositiveCapacity p≤multivariatePositiveCapacity (MvPolynomial.C c*p) := by
    apply le_csInf
    · exact ⟨_,⟨⟨fun _ => 1,fun _ => by norm_num⟩,rfl⟩⟩
    · rintro y ⟨x,rfl⟩
      have hpoint : multivariatePositiveCapacity p≤MvPolynomial.eval x.val p/(∏ i,x.val i) :=
        csInf_le hraw ⟨x,rfl⟩
      have h := mul_le_mul_of_nonneg_left hpoint hc.le
      simpa only [map_mul,MvPolynomial.eval_C,mul_div_assoc] using h
  have hupper : multivariatePositiveCapacity (MvPolynomial.C c*p)/c≤multivariatePositiveCapacity p := by
    apply le_csInf
    · exact ⟨_,⟨⟨fun _ => 1,fun _ => by norm_num⟩,rfl⟩⟩
    · rintro y ⟨x,rfl⟩
      apply (div_le_iff₀ hc).mpr
      have hpoint : multivariatePositiveCapacity (MvPolynomial.C c*p)≤
          MvPolynomial.eval x.val (MvPolynomial.C c*p)/(∏ i,x.val i) := csInf_le hscaled ⟨x,rfl⟩
      calc
        _≤MvPolynomial.eval x.val (MvPolynomial.C c*p)/(∏ i,x.val i) := hpoint
        _=(MvPolynomial.eval x.val p/(∏ i,x.val i))*c := by
          rw [map_mul,MvPolynomial.eval_C]
          ring
  apply le_antisymm _ hlower
  have h := (div_le_iff₀ hc).mp hupper
  simpa only [mul_comm] using h

end CoefficientStability
