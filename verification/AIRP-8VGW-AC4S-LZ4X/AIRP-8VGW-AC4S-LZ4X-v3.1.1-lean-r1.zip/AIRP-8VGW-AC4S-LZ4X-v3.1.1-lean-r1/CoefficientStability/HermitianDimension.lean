import CoefficientStability.HermitianQuadraticTrace
import Mathlib.Algebra.Star.Module
import Mathlib.LinearAlgebra.Dual.Lemmas
import Mathlib.LinearAlgebra.Dimension.Finrank

noncomputable section
namespace CoefficientStability
variable {n : ℕ}
abbrev ComplexSquare (n : ℕ) := Matrix (Fin n) (Fin n) ℂ

def hermitianSkewEquiv (n : ℕ) : selfAdjoint (ComplexSquare n) ≃ₗ[ℝ] skewAdjoint (ComplexSquare n) where
  toFun A := ⟨Complex.I • A.val,by
    change star (Complex.I • A.val)= -(Complex.I • A.val)
    simp only [star_smul,Complex.star_def,Complex.conj_I,A.property.star_eq,neg_smul]⟩
  invFun B := ⟨(-Complex.I) • B.val,by
    change star ((-Complex.I) • B.val)=(-Complex.I) • B.val
    have hB : star B.val= -B.val := B.property
    simp only [star_smul,star_neg,Complex.star_def,Complex.conj_I,neg_neg,hB,smul_neg,neg_smul]⟩
  left_inv A := by apply Subtype.ext;simp [smul_smul,Complex.I_mul_I]
  right_inv B := by apply Subtype.ext;simp [smul_smul,Complex.I_mul_I]
  map_add' A B := by apply Subtype.ext;simp [smul_add]
  map_smul' a A := by apply Subtype.ext;exact smul_comm _ _ _

instance hermitianFinite (n : ℕ) : FiniteDimensional ℝ (selfAdjoint (ComplexSquare n)) :=
  FiniteDimensional.of_injective (selfAdjoint.submodule ℝ (ComplexSquare n)).subtype Subtype.val_injective

instance skewHermitianFinite (n : ℕ) : FiniteDimensional ℝ (skewAdjoint (ComplexSquare n)) :=
  FiniteDimensional.of_injective (skewAdjoint.submodule ℝ (ComplexSquare n)).subtype Subtype.val_injective

theorem hermitian_finrank (n : ℕ) : Module.finrank ℝ (selfAdjoint (ComplexSquare n))=n^2 := by
  letI : Invertible (2 : ℝ) := invertibleOfNonzero (by norm_num)
  have hd := (StarModule.decomposeProdAdjoint ℝ (ComplexSquare n)).finrank_eq
  have he := (hermitianSkewEquiv n).finrank_eq
  rw [Module.finrank_prod,← he] at hd
  have hmat : Module.finrank ℝ (ComplexSquare n)=n*n*2 := by
    change Module.finrank ℝ (Fin n → Fin n → ℂ)=n*n*2
    rw [Module.finrank_pi_fintype]
    simp only [Module.finrank_pi_fintype,Complex.finrank_real_complex,
      Finset.sum_const,Finset.card_univ,Fintype.card_fin,smul_eq_mul]
    ring
  rw [hmat] at hd
  nlinarith

def hermitianTrace (n : ℕ) : selfAdjoint (ComplexSquare n) →ₗ[ℝ] ℝ where
  toFun A := (Matrix.trace A.val).re
  map_add' A B := by simp [Matrix.trace_add]
  map_smul' a A := by simp [Matrix.trace_smul]

def tracelessHermitian (n : ℕ) : Submodule ℝ (selfAdjoint (ComplexSquare n)) :=
  (hermitianTrace n).ker

theorem hermitianTrace_ne_zero (hn : 0<n) : hermitianTrace n≠0 := by
  intro he
  let one : selfAdjoint (ComplexSquare n) := ⟨1,by exact IsSelfAdjoint.one _⟩
  have h := congrArg (fun f : selfAdjoint (ComplexSquare n) →ₗ[ℝ] ℝ => f one) he
  have hn' : (0 : ℝ)<n := by exact_mod_cast hn
  simp [hermitianTrace,one,Matrix.trace_one] at h
  linarith

theorem tracelessHermitian_finrank (hn : 0<n) :
    Module.finrank ℝ (tracelessHermitian n)=n^2-1 := by
  have h := Module.Dual.finrank_ker_add_one_of_ne_zero (hermitianTrace_ne_zero hn)
  rw [hermitian_finrank] at h
  change Module.finrank ℝ (tracelessHermitian n)+1=n^2 at h
  omega

end CoefficientStability
