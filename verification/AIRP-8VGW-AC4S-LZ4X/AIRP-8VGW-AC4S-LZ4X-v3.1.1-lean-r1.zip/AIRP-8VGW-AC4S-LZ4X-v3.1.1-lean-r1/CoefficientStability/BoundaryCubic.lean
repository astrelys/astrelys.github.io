import CoefficientStability.ScalarHessianCriterion

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem esymm_three_identity (s : Multiset ℝ) :
    6*s.esymm 3=s.sum^3-3*s.sum*(s.map (fun r => r^2)).sum+2*(s.map (fun r => r^3)).sum := by
  induction s using Multiset.induction_on with
  | empty => simp [Multiset.esymm_of_card_lt (s := (0 : Multiset ℝ)) (n := 3) (by simp)]
  | @cons a s ih =>
    rw [show 3=2+1 from rfl,esymm_cons]
    simp only [Multiset.sum_cons,Multiset.map_cons]
    norm_num only at *
    have he := congrArg (fun v : ℝ => 3*a*v) (esymm_two_identity s)
    nlinarith

theorem centralCoefficient_three_identity (z : Fin n → ℝ) :
    6*centralCoefficient z 3=(∑ i,z i)^3-3*(∑ i,z i)*(∑ i,z i^2)+2*(∑ i,z i^3) := by
  rw [centralCoefficient_eq_esymm]
  have h := esymm_three_identity (Finset.univ.val.map z)
  simpa [Finset.sum,Multiset.map_map,Function.comp_def] using h

theorem boundary_third_central_coefficient_negative (z : Fin n → ℝ)
    (hs : ∑ i,z i=1) (hq : ∑ i,z i^2=1) (hz : ∀ i,z i<1) :
    centralCoefficient z 2=0 ∧ centralCoefficient z 3=((∑ i,z i^3)-1)/3 ∧ centralCoefficient z 3<0 := by
  have hex : ∃ i,z i≠0 := by
    by_contra! h
    simp [h] at hs
  obtain ⟨i,hi⟩ := hex
  have hle (j : Fin n) : z j^3≤z j^2 := by
    have h := mul_nonneg (sub_nonneg.mpr (hz j).le) (sq_nonneg (z j))
    nlinarith
  have hlt : z i^3<z i^2 := by
    have h := mul_pos (sub_pos.mpr (hz i)) (sq_pos_of_ne_zero hi)
    nlinarith
  have hsum := Finset.sum_lt_sum (fun j (_ : j∈(Finset.univ : Finset (Fin n))) => hle j)
    ⟨i,Finset.mem_univ i,hlt⟩
  rw [hq] at hsum
  have h2 := centralCoefficient_two z
  have h3 := centralCoefficient_three_identity z
  rw [hs,hq] at h2 h3
  constructor
  · nlinarith
  · constructor <;> nlinarith

theorem paper_boundary_third_coefficient (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : scalarHessianLambda t=0) :
    centralCoefficient (projectedOnes t) 2=0 ∧
    centralCoefficient (projectedOnes t) 3=((∑ i,(projectedOnes t i)^3)-1)/3 ∧
    centralCoefficient (projectedOnes t) 3<0 := by
  have h := paper_scalar_form_boundary_vector t hn ht htpos hl
  exact boundary_third_central_coefficient_negative (projectedOnes t) h.2.1 h.2.2.1 h.2.2.2.2

end CoefficientStability
