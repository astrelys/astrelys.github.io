import CoefficientStability.MixedFirstVariation

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem permutation_maps_distinct_pair (r c i j : Fin n) (hrc : r≠c) (hij : i≠j) :
    ∃ p : Equiv.Perm (Fin n),p r=i ∧ p c=j := by
  classical
  let p0 := Equiv.swap r i
  have hr : p0 r=i := by simp [p0]
  have hc : p0 c≠i := by
    intro h
    have he : c=r := p0.injective (h.trans hr.symm)
    exact hrc he.symm
  refine ⟨Equiv.swap (p0 c) j*p0,?_,?_⟩
  · simp only [Equiv.Perm.mul_apply,hr]
    exact Equiv.swap_apply_of_ne_of_ne hc.symm hij
  · simp [Equiv.Perm.mul_apply]

section Average
variable {R : Type*} [CommRing R] [IsDomain R] [CharZero R]

theorem permutation_pair_sum_equal (f : Fin n → Fin n → R)
    (r c i j : Fin n) (hrc : r≠c) (hij : i≠j) :
    (∑ p : Equiv.Perm (Fin n),f (p r) (p c))=
      ∑ p : Equiv.Perm (Fin n),f (p i) (p j) := by
  obtain ⟨q,hq1,hq2⟩ := permutation_maps_distinct_pair r c i j hrc hij
  have hi : q.symm i=r := by rw [← hq1];simp
  have hj : q.symm j=c := by rw [← hq2];simp
  apply Fintype.sum_equiv (Equiv.mulRight q.symm)
  intro p
  simp [Equiv.Perm.mul_apply,hi,hj]

theorem permutation_pair_sum (f : Fin n → Fin n → R) (hn : 2≤n)
    (i j : Fin n) (hij : i≠j) :
    (∑ p : Equiv.Perm (Fin n),f (p i) (p j))=
      ((n-2).factorial : R)*(∑ r,∑ c,if c=r then 0 else f r c) := by
  classical
  let S := ∑ p : Equiv.Perm (Fin n),f (p i) (p j)
  have hcount (r : Fin n) : (∑ c : Fin n,if c=r then (0 : R) else S)=((n-1 : ℕ) : R)*S := by
    rw [← Finset.sum_erase (Finset.univ : Finset (Fin n)) (a := r) (by simp)]
    have he : (∑ c ∈ Finset.univ.erase r,if c=r then (0 : R) else S)=∑ _c ∈ Finset.univ.erase r,S := by
      apply Finset.sum_congr rfl
      intro c hc
      simp only [Finset.mem_erase] at hc
      simp [hc.1]
    rw [he]
    simp
  have hdouble : (∑ r : Fin n,∑ c : Fin n,if c=r then (0 : R) else
      ∑ p : Equiv.Perm (Fin n),f (p r) (p c))=(n : R)*((n-1 : ℕ) : R)*S := by
    have he (r c : Fin n) : (if c=r then (0 : R) else
        ∑ p : Equiv.Perm (Fin n),f (p r) (p c))=if c=r then 0 else S := by
      by_cases hc : c=r
      · simp [hc]
      · simp only [hc,ite_false]
        exact permutation_pair_sum_equal f r c i j (Ne.symm hc) hij
    simp_rw [he,hcount]
    simp [mul_assoc]
  have hreindex (p : Equiv.Perm (Fin n)) :
      (∑ r : Fin n,∑ c : Fin n,if c=r then (0 : R) else f (p r) (p c))=
        ∑ r : Fin n,∑ c : Fin n,if c=r then 0 else f r c := by
    apply Fintype.sum_equiv p
    intro r
    apply Fintype.sum_equiv p
    intro c
    simp
  have he : (n : R)*((n-1 : ℕ) : R)*S=
      (n.factorial : R)*(∑ r : Fin n,∑ c : Fin n,if c=r then 0 else f r c) := by
    rw [← hdouble]
    have hi (r c : Fin n) : (if c=r then (0 : R) else
        ∑ p : Equiv.Perm (Fin n),f (p r) (p c))=
        ∑ p : Equiv.Perm (Fin n),if c=r then 0 else f (p r) (p c) := by
      split_ifs <;> simp
    simp_rw [hi]
    calc
      (∑ r : Fin n,∑ c : Fin n,∑ p : Equiv.Perm (Fin n),
          if c=r then (0 : R) else f (p r) (p c)) =
          ∑ r : Fin n,∑ p : Equiv.Perm (Fin n),∑ c : Fin n,
            if c=r then 0 else f (p r) (p c) := by
        apply Finset.sum_congr rfl
        intro r hr
        exact Finset.sum_comm
      _ = ∑ p : Equiv.Perm (Fin n),∑ r : Fin n,∑ c : Fin n,
            if c=r then 0 else f (p r) (p c) := Finset.sum_comm
      _ = _ := by simp only [hreindex,Finset.sum_const,Finset.card_univ,Fintype.card_perm,
          Fintype.card_fin,nsmul_eq_mul]
  have hf : (n.factorial : R)=(n : R)*((n-1 : ℕ) : R)*((n-2).factorial : R) := by
    have h1 := Nat.mul_factorial_pred (by omega : n≠0)
    have h2 := Nat.mul_factorial_pred (by omega : n-1≠0)
    have h3 : n-1-1=n-2 := by omega
    rw [h3] at h2
    exact_mod_cast (by nlinarith : n.factorial=n*(n-1)*(n-2).factorial)
  rw [hf,mul_assoc] at he
  have hnonzero : (n : R)*((n-1 : ℕ) : R)≠0 := mul_ne_zero
    (by exact_mod_cast (by omega : n≠0)) (by exact_mod_cast (by omega : n-1≠0))
  exact mul_left_cancel₀ hnonzero (by simpa only [mul_assoc] using he)

end Average
end CoefficientStability
