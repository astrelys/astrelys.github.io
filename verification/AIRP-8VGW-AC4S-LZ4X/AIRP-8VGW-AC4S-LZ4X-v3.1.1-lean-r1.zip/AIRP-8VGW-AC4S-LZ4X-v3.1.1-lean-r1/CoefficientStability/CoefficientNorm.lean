import CoefficientStability.MatrixTraceBounds

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem coefficientL1_nonneg (p : MvPolynomial (Fin n) ℝ) : 0 ≤ coefficientL1 p := by
  exact Finset.sum_nonneg (fun _ _ => abs_nonneg _)

theorem coefficientL1_eq_sum_on (p : MvPolynomial (Fin n) ℝ)
    (s : Finset (Fin n →₀ ℕ)) (hs : p.support ⊆ s) :
    coefficientL1 p = ∑ g ∈ s,|p.coeff g| := by
  unfold coefficientL1
  apply Finset.sum_subset hs
  intro g hg hnot
  rw [MvPolynomial.notMem_support_iff.mp hnot,abs_zero]

@[simp] theorem coefficientL1_zero : coefficientL1 (0 : MvPolynomial (Fin n) ℝ)=0 := by
  simp [coefficientL1]

@[simp] theorem coefficientL1_monomial (g : Fin n →₀ ℕ) (c : ℝ) :
    coefficientL1 (monomial g c)=|c| := by
  classical
  by_cases hc : c=0
  · simp [hc]
  · simp [coefficientL1,MvPolynomial.support_monomial,hc,MvPolynomial.coeff_monomial]

@[simp] theorem coefficientL1_one : coefficientL1 (1 : MvPolynomial (Fin n) ℝ)=1 := by
  simpa only [← MvPolynomial.C_apply,MvPolynomial.C_1,abs_one] using coefficientL1_monomial (0 : Fin n →₀ ℕ) (1 : ℝ)

@[simp] theorem coefficientL1_neg (p : MvPolynomial (Fin n) ℝ) : coefficientL1 (-p)=coefficientL1 p := by
  have hs : (-p).support=p.support := by
    ext g
    simp only [MvPolynomial.mem_support_iff,AddMonoidAlgebra.coeff_neg,Finsupp.neg_apply,neg_ne_zero]
  simp only [coefficientL1,hs,AddMonoidAlgebra.coeff_neg,Finsupp.neg_apply,abs_neg]

theorem coefficientL1_add_le (p q : MvPolynomial (Fin n) ℝ) :
    coefficientL1 (p+q) ≤ coefficientL1 p+coefficientL1 q := by
  classical
  let s := p.support ∪ q.support
  rw [coefficientL1_eq_sum_on (p+q) s (fun g hg => MvPolynomial.support_add hg),
    coefficientL1_eq_sum_on p s Finset.subset_union_left,
    coefficientL1_eq_sum_on q s Finset.subset_union_right,← Finset.sum_add_distrib]
  apply Finset.sum_le_sum
  intro g hg
  simpa only [AddMonoidAlgebra.coeff_add,Finsupp.add_apply] using abs_add_le (p.coeff g) (q.coeff g)

theorem coefficientL1_sub_le (p q : MvPolynomial (Fin n) ℝ) :
    coefficientL1 (p-q) ≤ coefficientL1 p+coefficientL1 q := by
  simpa only [sub_eq_add_neg,coefficientL1_neg] using coefficientL1_add_le p (-q)

theorem coefficientL1_sum_le {ι : Type*} (s : Finset ι) (f : ι → MvPolynomial (Fin n) ℝ) :
    coefficientL1 (∑ i ∈ s,f i) ≤ ∑ i ∈ s,coefficientL1 (f i) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert i s hi ih =>
    rw [Finset.sum_insert hi,Finset.sum_insert hi]
    exact (coefficientL1_add_le _ _).trans (add_le_add (le_refl _) ih)

theorem coefficientL1_mul_le (p q : MvPolynomial (Fin n) ℝ) :
    coefficientL1 (p*q) ≤ coefficientL1 p*coefficientL1 q := by
  classical
  have he : p*q = ∑ g ∈ p.support,∑ h ∈ q.support,
      monomial (g+h) (p.coeff g*q.coeff h) := by
    conv_lhs => rw [p.as_sum,q.as_sum]
    simp only [Finset.sum_mul,Finset.mul_sum,monomial_mul_monomial]
    exact Finset.sum_comm
  rw [he]
  calc
    coefficientL1 (∑ g ∈ p.support,∑ h ∈ q.support,monomial (g+h) (p.coeff g*q.coeff h))
      ≤ ∑ g ∈ p.support,coefficientL1 (∑ h ∈ q.support,monomial (g+h) (p.coeff g*q.coeff h)) := coefficientL1_sum_le _ _
    _ ≤ ∑ g ∈ p.support,∑ h ∈ q.support,coefficientL1 (monomial (g+h) (p.coeff g*q.coeff h)) := by
      apply Finset.sum_le_sum
      intro g hg
      exact coefficientL1_sum_le _ _
    _ = coefficientL1 p*coefficientL1 q := by
      simp_rw [coefficientL1_monomial,abs_mul]
      simp only [coefficientL1,Finset.sum_mul_sum]

theorem coefficientL1_pow_le (p : MvPolynomial (Fin n) ℝ) (k : ℕ) :
    coefficientL1 (p^k) ≤ (coefficientL1 p)^k := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [pow_succ,pow_succ]
    exact (coefficientL1_mul_le _ _).trans
      (mul_le_mul_of_nonneg_right ih (coefficientL1_nonneg p))

theorem abs_eval_one_le_coefficientL1 (p : MvPolynomial (Fin n) ℝ) :
    |MvPolynomial.eval (fun _ => 1) p| ≤ coefficientL1 p := by
  rw [← coefficient_sum_eq_eval_one]
  exact Finset.abs_sum_le_sum_abs _ _

theorem scalarLinear_coefficientL1_le_one (t : Fin n → ℝ) (N : ℕ) (hN : 0<N)
    (ht : ∑ i,t i=N) (ht0 : ∀ i,0 ≤ t i) : coefficientL1 (scalarLinear t N) ≤ 1 := by
  have h := coefficientL1_sum_le (Finset.univ : Finset (Fin n))
    (fun i => C (t i/N)*MvPolynomial.X i)
  simp only [C_mul_X_eq_monomial,coefficientL1_monomial] at h
  have hn : (0 : ℝ)<N := by exact_mod_cast hN
  have he : (∑ i : Fin n,|t i/(N : ℝ)|)=1 := by
    simp only [abs_of_nonneg (div_nonneg (ht0 _) hn.le)]
    rw [← Finset.sum_div,ht,div_self (ne_of_gt hn)]
  simpa only [scalarLinear,C_mul_X_eq_monomial,he] using h

theorem scalarLinear_power_coefficientL1 (t : Fin n → ℝ) (N k : ℕ) (hN : 0<N)
    (ht : ∑ i,t i=N) (ht0 : ∀ i,0 ≤ t i) : coefficientL1 ((scalarLinear t N)^k)=1 := by
  apply le_antisymm
  · have h := coefficientL1_pow_le (scalarLinear t N) k
    have hp := pow_le_pow_left₀ (coefficientL1_nonneg _) (scalarLinear_coefficientL1_le_one t N hN ht ht0) k
    exact h.trans (by simpa using hp)
  · have h := abs_eval_one_le_coefficientL1 ((scalarLinear t N)^k)
    simpa [eval_one_scalarLinear t N hN ht] using h

end CoefficientStability
