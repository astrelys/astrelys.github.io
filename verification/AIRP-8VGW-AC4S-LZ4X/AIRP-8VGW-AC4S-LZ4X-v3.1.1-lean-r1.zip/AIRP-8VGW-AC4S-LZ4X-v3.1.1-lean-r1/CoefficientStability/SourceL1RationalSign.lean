import CoefficientStability.SourceL1RationalParameters

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000

theorem source_l1_rational_gap_positive_factor (η : ℝ) (hη : 3<η) :
    ∃ K : ℝ,0<K ∧
      Matrix.permanent (sourceL1BoundaryMatrix (sourceL1RationalD η))-
        sourceTernaryBaseline (sourceL1BoundaryTraces (sourceL1RationalD η))=
          K*(η^4-16*η^2+27) := by
  have hden : 0<η^2-3 := by nlinarith
  have hd : 0<sourceL1RationalD η := one_div_pos.mpr hden
  have hd1 : sourceL1RationalD η<1 := by
    change 1/(η^2-3)<1
    exact (div_lt_one hden).mpr (by nlinarith)
  let K : ℝ := (1-sourceL1RationalD η)*(1+2*sourceL1RationalD η)/(36*(η^2-3)^2)
  have hK : 0<K := by dsimp [K];positivity
  refine ⟨K,hK,?_⟩
  rw [source_l1_boundary_family_gap _ hd.le,source_l1_rational_parameter_gap_polynomial η (ne_of_gt hden)]
  dsimp [K]
  field_simp [ne_of_gt hden] <;> ring

theorem source_l1_rational_gap_sign_exact (η : ℝ) (hη : 3<η) :
    let gap := Matrix.permanent (sourceL1BoundaryMatrix (sourceL1RationalD η))-
      sourceTernaryBaseline (sourceL1BoundaryTraces (sourceL1RationalD η))
    (gap<0 ↔ η^4-16*η^2+27<0) ∧
      (gap=0 ↔ η^4-16*η^2+27=0) ∧ (0<gap ↔ 0<η^4-16*η^2+27) := by
  obtain ⟨K,hK,he⟩ := source_l1_rational_gap_positive_factor η hη
  dsimp only
  rw [he]
  constructor
  · constructor
    · intro h
      by_contra hn
      exact (not_le_of_gt h) (mul_nonneg hK.le (le_of_not_gt hn))
    · exact mul_neg_of_pos_of_neg hK
  · constructor
    · simp only [mul_eq_zero,ne_of_gt hK,false_or]
    · exact mul_pos_iff_of_pos_left hK

end CoefficientStability
