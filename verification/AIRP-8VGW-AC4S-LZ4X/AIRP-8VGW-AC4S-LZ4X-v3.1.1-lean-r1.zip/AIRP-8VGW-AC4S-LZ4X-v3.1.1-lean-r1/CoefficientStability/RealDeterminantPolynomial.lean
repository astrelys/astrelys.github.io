import CoefficientStability.DeterminantPencilHessian
import CoefficientStability.HermitianHessianInertia

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def realDeterminantPolynomial (A : Fin n → ComplexSquare n) : MvPolynomial (Fin n) ℝ :=
  AddMonoidAlgebra.map Complex.reLm.toAddMonoidHom (determinantPolynomial A)

theorem determinantPolynomial_conjugation_fixed (A : Fin n → ComplexSquare n)
    (hA : ∀ i,(A i).IsHermitian) :
    MvPolynomial.map (starRingEnd ℂ) (determinantPolynomial A)=determinantPolynomial A := by
  have he : (MvPolynomial.map (starRingEnd ℂ)).mapMatrix (determinantPencil A)=
      (determinantPencil A).transpose := by
    apply Matrix.ext
    intro r c
    simp only [determinantPencil,RingHom.mapMatrix_apply,Matrix.map_apply,Matrix.sum_apply,
      Matrix.smul_apply,smul_eq_mul,map_sum,map_mul,MvPolynomial.map_X,MvPolynomial.map_C,
      Matrix.transpose_apply]
    apply Finset.sum_congr rfl
    intro i hi
    have hs := (hA i).apply c r
    simpa only [starRingEnd_apply,hs] using
      congrArg (fun z : ℂ => MvPolynomial.X i*MvPolynomial.C z) hs
  rw [determinantPolynomial,RingHom.map_det,he,Matrix.det_transpose]

theorem determinantPolynomial_coeff_im_zero (A : Fin n → ComplexSquare n)
    (hA : ∀ i,(A i).IsHermitian) (d : Fin n →₀ ℕ) :
    ((determinantPolynomial A).coeff d).im=0 := by
  have h := congrArg (fun p : MvPolynomial (Fin n) ℂ => p.coeff d)
    (determinantPolynomial_conjugation_fixed A hA)
  simp only [MvPolynomial.coeff_map] at h
  have hi := congrArg Complex.im h
  change -((determinantPolynomial A).coeff d).im=((determinantPolynomial A).coeff d).im at hi
  linarith

theorem realDeterminantPolynomial_complexification (A : Fin n → ComplexSquare n)
    (hA : ∀ i,(A i).IsHermitian) :
    MvPolynomial.map Complex.ofRealHom (realDeterminantPolynomial A)=determinantPolynomial A := by
  apply MvPolynomial.ext
  intro d
  simp only [MvPolynomial.coeff_map,realDeterminantPolynomial,MvPolynomial.coeff_addMonoidAlgebraMap]
  change Complex.ofReal (((determinantPolynomial A).coeff d).re)=(determinantPolynomial A).coeff d
  apply Complex.ext
  · rfl
  · exact (determinantPolynomial_coeff_im_zero A hA d).symm

theorem realDeterminantPolynomial_evaluation (A : Fin n → ComplexSquare n)
    (hA : ∀ i,(A i).IsHermitian) (x : Fin n → ℝ) :
    Complex.ofReal (MvPolynomial.eval x (realDeterminantPolynomial A))=
      Matrix.det (∑ i,Complex.ofReal (x i) • A i) := by
  change Complex.ofRealHom (MvPolynomial.eval x (realDeterminantPolynomial A))=_
  rw [MvPolynomial.map_eval Complex.ofRealHom,realDeterminantPolynomial_complexification A hA,
    determinantPolynomial_eval]
  rfl

end CoefficientStability
