import CoefficientStability.HomogeneousLine

noncomputable section
open scoped BigOperators
open Polynomial
namespace CoefficientStability
variable {n : ℕ}

def contentRoots (s : Finset (Fin n)) (g : Fin n → ℕ) (x : Fin n → ℝ) : Multiset ℝ :=
  ∑ i ∈ s, Multiset.replicate (g i) (x i)

def realFactorPolynomial (roots : Multiset ℝ) : ℝ[X] :=
  (roots.map (fun r => Polynomial.X + Polynomial.C r)).prod

theorem contentRoots_card (s : Finset (Fin n)) (g : Fin n → ℕ) (x : Fin n → ℝ) :
    (contentRoots s g x).card = ∑ i ∈ s, g i := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [contentRoots]
  | @insert a s ha ih => simpa [contentRoots, Finset.sum_insert ha] using ih

theorem contentRoots_sum (s : Finset (Fin n)) (g : Fin n → ℕ) (x : Fin n → ℝ) :
    (contentRoots s g x).sum = ∑ i ∈ s, (g i : ℝ)*x i := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [contentRoots]
  | @insert a s ha ih => simpa [contentRoots, Finset.sum_insert ha, nsmul_eq_mul] using ih

theorem contentRoots_sum_squares (s : Finset (Fin n)) (g : Fin n → ℕ) (x : Fin n → ℝ) :
    ((contentRoots s g x).map (fun r => r^2)).sum = ∑ i ∈ s, (g i : ℝ)*x i^2 := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [contentRoots]
  | @insert a s ha ih => simpa [contentRoots, Finset.sum_insert ha, nsmul_eq_mul] using ih

theorem contentRoots_factorPolynomial (s : Finset (Fin n)) (g : Fin n → ℕ) (x : Fin n → ℝ) :
    realFactorPolynomial (contentRoots s g x) =
      ∏ i ∈ s, (Polynomial.X + Polynomial.C (x i)) ^ g i := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [realFactorPolynomial, contentRoots]
  | @insert a s ha ih =>
    have hr : contentRoots (insert a s) g x =
        Multiset.replicate (g a) (x a) + contentRoots s g x := by
      simp [contentRoots, Finset.sum_insert ha]
    rw [hr]
    simp only [realFactorPolynomial, Multiset.map_add, Multiset.prod_add,
      Multiset.map_replicate, Multiset.prod_replicate, Finset.prod_insert ha]
    exact congrArg (fun r : ℝ[X] => (Polynomial.X + Polynomial.C (x a)) ^ g a * r) ih

theorem monomialLine_second_coefficient (g : Fin n →₀ ℕ) (x : Fin n → ℝ) (N : ℕ)
    (hN : 2 ≤ N) (hg : ∑ i, g i = N) :
    2 * (monomialLine g x).coeff (N-2) =
      (∑ i, (g i : ℝ)*x i)^2 - ∑ i, (g i : ℝ)*x i^2 := by
  let roots := contentRoots Finset.univ g x
  have hcard : roots.card = N := by rw [contentRoots_card, hg]
  have hpoly : realFactorPolynomial roots = monomialLine g x := by
    rw [contentRoots_factorPolynomial]
    rfl
  have hv := Multiset.prod_X_add_C_coeff roots (k := N-2) (by omega)
  have hnn : N-(N-2)=2 := by omega
  rw [hcard, hnn] at hv
  change (realFactorPolynomial roots).coeff (N-2) = roots.esymm 2 at hv
  rw [hpoly] at hv
  rw [hv, esymm_two_identity]
  rw [contentRoots_sum, contentRoots_sum_squares]

end CoefficientStability
