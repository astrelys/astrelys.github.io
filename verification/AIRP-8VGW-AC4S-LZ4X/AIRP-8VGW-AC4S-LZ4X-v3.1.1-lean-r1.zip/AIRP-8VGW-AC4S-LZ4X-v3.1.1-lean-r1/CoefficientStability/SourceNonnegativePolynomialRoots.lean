import CoefficientStability.SourceCubicConicPencil
import Mathlib.Analysis.Calculus.LocalExtr.Basic

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

theorem source_nonnegative_polynomial_root_derivative (p : Polynomial ℝ)
    (hp : ∀ x : ℝ,0 ≤ p.eval x) (r : ℝ) (hr : p.eval r=0) : p.derivative.eval r=0 := by
  have hm : IsLocalMin (fun x : ℝ => p.eval x) r := by
    apply Filter.Eventually.of_forall
    intro x
    change p.eval r ≤ p.eval x
    rw [hr]
    exact hp x
  exact hm.hasDerivAt_eq_zero (p.hasDerivAt r)

theorem source_nonnegative_polynomial_real_square_divisor (p : Polynomial ℝ)
    (hp : ∀ x : ℝ,0 ≤ p.eval x) (r : ℝ) (hr : p.eval r=0) :
    (Polynomial.X-Polynomial.C r)^2 ∣ p := by
  have hd := source_nonnegative_polynomial_root_derivative p hp r hr
  obtain ⟨q,hq⟩ := (Polynomial.dvd_iff_isRoot).mpr (show p.IsRoot r from hr)
  have hqr : q.eval r=0 := by
    rw [hq,Polynomial.derivative_mul] at hd
    simpa using hd
  obtain ⟨b,hb⟩ := (Polynomial.dvd_iff_isRoot).mpr (show q.IsRoot r from hqr)
  refine ⟨b,?_⟩
  rw [hq,hb]
  ring

theorem source_nonnegative_polynomial_square_quotient (p q : Polynomial ℝ)
    (hp : ∀ x : ℝ,0 ≤ p.eval x) (r : ℝ)
    (he : p=(Polynomial.X-Polynomial.C r)^2*q) : ∀ x : ℝ,0 ≤ q.eval x := by
  have haway (x : ℝ) (hx : x≠r) : 0 ≤ q.eval x := by
    have h := hp x
    rw [he] at h
    simp only [Polynomial.eval_mul,Polynomial.eval_pow,Polynomial.eval_sub,Polynomial.eval_X,Polynomial.eval_C] at h
    exact nonneg_of_mul_nonneg_left (by simpa only [mul_comm] using h) (sq_pos_of_ne_zero (sub_ne_zero.mpr hx))
  have hc : IsClosed {x : ℝ | 0 ≤ q.eval x} := isClosed_le continuous_const q.continuous
  have hs : ({r}ᶜ : Set ℝ)⊆{x : ℝ | 0 ≤ q.eval x} := by
    intro x hx
    exact haway x (by simpa using hx)
  have hd := closure_minimal hs hc
  rw [(dense_compl_singleton r).closure_eq] at hd
  intro x
  exact hd (Set.mem_univ x)

def sourceComplexRootNormQuadratic (z : ℂ) : Polynomial ℝ :=
  Polynomial.X^2-Polynomial.C (2*z.re)*Polynomial.X+Polynomial.C (Complex.normSq z)

theorem source_complex_root_norm_quadratic_eval (z : ℂ) (x : ℝ) :
    (sourceComplexRootNormQuadratic z).eval x=(x-z.re)^2+z.im^2 := by
  simp [sourceComplexRootNormQuadratic,Complex.normSq_apply]
  ring

theorem source_complex_root_norm_quadratic_norm (z : ℂ) (x : ℝ) :
    (sourceComplexRootNormQuadratic z).eval x=Complex.normSq ((x : ℂ)-z) := by
  rw [source_complex_root_norm_quadratic_eval]
  simp [Complex.normSq_apply,Complex.sub_re,Complex.sub_im]
  ring

theorem source_complex_root_norm_quadratic_degree (z : ℂ) :
    (sourceComplexRootNormQuadratic z).natDegree=2 := by
  apply Polynomial.natDegree_eq_of_le_of_coeff_ne_zero
  · apply (Polynomial.natDegree_add_le _ _).trans
    apply max_le
    · apply (Polynomial.natDegree_sub_le _ _).trans
      apply max_le
      · simp
      · exact (Polynomial.natDegree_C_mul_le _ _).trans (by simp)
    · simp
  · simp [sourceComplexRootNormQuadratic]

end CoefficientStability
