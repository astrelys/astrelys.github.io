import CoefficientStability.SourceCubicDepressedCoordinates

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000

theorem source_depressed_cubic_actual_quadratic_translation
    (Q : Matrix (Fin 3) (Fin 3) ℝ) (hQ : Q.IsHermitian)
    (hnull : Q.mulVec (fun _ => 1)=0) (t : Fin 3 → ℝ) (s x y : ℝ) :
    matrixQuadratic Q (sourceDepressedCubicCoordinates t s x y)=
      matrixQuadratic Q (![x,y,0] : Fin 3 → ℝ) := by
  have hv : sourceDepressedCubicCoordinates t s x y=
      (![x,y,0] : Fin 3 → ℝ)-(-(s-(t 0*x+t 1*y)/3)) • (fun _ => 1) := by
    funext i
    simp only [sourceDepressedCubicCoordinates,Pi.add_apply,Pi.sub_apply,Pi.smul_apply,smul_eq_mul]
    ring
  rw [hv]
  exact matrixQuadratic_sub_kernel Q hQ _ _ _ hnull

theorem source_stable_cubic_actual_depressed_normal_form
    (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ)
    (hp : p.IsHomogeneous 3) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) (ht : ∑ i,t i=3)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (s x y : ℝ) :
    MvPolynomial.eval (sourceDepressedCubicCoordinates t s x y) p=
      s^3-s*matrixQuadratic (deficitMatrix p t 3) (![x,y,0] : Fin 3 → ℝ)+
        MvPolynomial.eval (![x,y,0] : Fin 3 → ℝ) (centralCoefficientPolynomial p t 3 3) := by
  have he := paper_central_expansion p t 3 (sourceDepressedCubicCoordinates t s x y)
    (by omega) hp hn hs hg
  norm_num only [Nat.cast_ofNat] at he
  rw [source_depressed_cubic_coordinate_mean t ht,
    source_depressed_cubic_actual_quadratic_translation _ (deficitMatrix_isHermitian p t 3)
      (deficitMatrix_mulVec_one p t 3 (by omega) hp ht hg)] at he
  simpa only [show 3-2=1 by rfl,show 3-(0+3)=0 by rfl,Finset.sum_range_succ,Finset.sum_range_zero,
    zero_add,zero_mul,one_mul,pow_one,pow_zero,
    source_central_cubic_actual_translation p t ht] using he

theorem source_binary_restricted_quadratic_exact (Q : Matrix (Fin 3) (Fin 3) ℝ)
    (hQ : Q.IsHermitian) (x y : ℝ) :
    matrixQuadratic Q (![x,y,0] : Fin 3 → ℝ)=Q 0 0*x^2+2*Q 0 1*x*y+Q 1 1*y^2 := by
  have he : Q 1 0=Q 0 1 := by
    have h := congrArg (fun M : Matrix (Fin 3) (Fin 3) ℝ => M 0 1) hQ
    simpa only [Matrix.conjTranspose_apply,star_trivial] using h
  norm_num [matrixQuadratic,Fin.sum_univ_succ]
  rw [he]
  ring

end CoefficientStability
