import CoefficientStability.UniformRealRootBound

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def smoothedLineRestriction (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (ε : ℝ)
    (x : Fin n → ℝ) : Polynomial ℝ := (nuijUnivariateStep ε)^[N] (lineRestriction p x)

theorem smoothed_source_line_simple_real_roots (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (ε : ℝ) (hε : ε≠0) (x : Fin n → ℝ) :
    (smoothedLineRestriction p N ε x).Monic ∧ (smoothedLineRestriction p N ε x).Splits ∧
      (smoothedLineRestriction p N ε x).natDegree=N ∧ (smoothedLineRestriction p N ε x).roots.Nodup := by
  have hd := normalized_lineRestriction_natDegree p x N hp hnorm
  have h := finite_nuij_smoothing_simple_roots (lineRestriction p x)
    (normalized_lineRestriction_monic p x N hp hnorm) (lineRestriction_splits p hs x) ε hε
  rw [hd] at h
  exact h

theorem smoothedLineRestriction_zero (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (x : Fin n → ℝ) :
    smoothedLineRestriction p N 0 x=lineRestriction p x := by
  have heq : nuijUnivariateStep (0 : ℝ)=id := by funext P;simp [nuijUnivariateStep]
  rw [smoothedLineRestriction,heq]
  simp

theorem nuij_iterate_coefficient_continuous {α : Type*} [TopologicalSpace α]
    (P : α → Polynomial ℝ) (hP : ∀ j,Continuous (fun a => (P a).coeff j))
    (ε : α → ℝ) (hε : Continuous ε) (k : ℕ) :
    ∀ j,Continuous (fun a => ((nuijUnivariateStep (ε a))^[k] (P a)).coeff j) := by
  induction k with
  | zero => exact hP
  | succ k ih =>
    intro j
    have h0 := ih j
    have h1 := ih (j+1)
    have heq : (fun a => ((nuijUnivariateStep (ε a))^[k+1] (P a)).coeff j)=
        (fun a => ((nuijUnivariateStep (ε a))^[k] (P a)).coeff j+
          ε a*(((nuijUnivariateStep (ε a))^[k] (P a)).coeff (j+1)*(j+1 : ℝ))) := by
      funext a
      simp only [Function.iterate_succ_apply',nuijUnivariateStep,Polynomial.coeff_add,
        Polynomial.coeff_C_mul,Polynomial.coeff_derivative]
    rw [heq]
    fun_prop

theorem smoothedLineRestriction_joint_coefficient_continuous
    (p : MvPolynomial (Fin n) ℝ) (N j : ℕ) :
    Continuous (fun a : (Fin n → ℝ)×ℝ => (smoothedLineRestriction p N a.2 a.1).coeff j) := by
  exact nuij_iterate_coefficient_continuous (fun a : (Fin n → ℝ)×ℝ => lineRestriction p a.1)
    (fun j => (lineRestriction_coefficient_continuous p j).comp continuous_fst)
    (fun a => a.2) continuous_snd N j

end CoefficientStability
