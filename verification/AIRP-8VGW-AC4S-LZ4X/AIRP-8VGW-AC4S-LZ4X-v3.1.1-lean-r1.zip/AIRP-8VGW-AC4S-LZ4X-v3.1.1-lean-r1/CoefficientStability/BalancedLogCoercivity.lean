import CoefficientStability.ActualNoiseHessian
import CoefficientStability.ActualRelativeTilt
import CoefficientStability.StrongRayCoercivity

noncomputable section
open scoped BigOperators Topology
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def logGeneratingRay (p : MvPolynomial (Fin n) ℝ) (v : Fin n → ℝ) (s : ℝ) : ℝ :=
  Real.log (tiltPartition p (s • v))

theorem logGeneratingRay_hasDerivAt (p : MvPolynomial (Fin n) ℝ) (v : Fin n → ℝ)
    (s : ℝ) (hZ : tiltPartition p (s • v)≠0) :
    HasDerivAt (logGeneratingRay p v) (∑ i,tiltedMoment p (s • v) i*v i) s := by
  change HasDerivAt (fun z : ℝ => Real.log (tiltPartition p (z • v)))
    (∑ i,tiltedMoment p (s • v) i*v i) s
  simpa only [zero_add] using
    tiltLogPartition_path_hasDerivAt p 0 v s (by simpa only [zero_add] using hZ)

theorem logGeneratingRay_second_hasDerivAt (p : MvPolynomial (Fin n) ℝ) (v : Fin n → ℝ)
    (s : ℝ) (hZ : tiltPartition p (s • v)≠0) :
    HasDerivAt (deriv (logGeneratingRay p v))
      (matrixQuadratic (coefficientCovariance (tiltedPolynomial p (s • v)) (tiltedMoment p (s • v))) v) s := by
  change HasDerivAt (fun z : ℝ => deriv (fun w : ℝ => Real.log (tiltPartition p (w • v))) z)
    (matrixQuadratic (coefficientCovariance (tiltedPolynomial p (s • v)) (tiltedMoment p (s • v))) v) s
  simpa only [zero_add] using
    tiltLogPartition_second_hasDerivAt p 0 v s (by simpa only [zero_add] using hZ)

theorem logGeneratingRay_convex (p : MvPolynomial (Fin n) ℝ) (v : Fin n → ℝ)
    (hcoeff : ∀ g,0≤p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1) :
    ConvexOn ℝ Set.univ (logGeneratingRay p v) := by
  have hZ (s : ℝ) := ne_of_gt (tiltPartition_pos p (s • v) hcoeff hnorm)
  refine convexOn_of_deriv2_nonneg' convex_univ
    (fun s hs => (logGeneratingRay_hasDerivAt p v s (hZ s)).differentiableAt.differentiableWithinAt)
    (fun s hs => (logGeneratingRay_second_hasDerivAt p v s (hZ s)).differentiableAt.differentiableWithinAt) ?_
  intro s hs
  change 0≤deriv (deriv (logGeneratingRay p v)) s
  rw [(logGeneratingRay_second_hasDerivAt p v s (hZ s)).deriv]
  exact psd_matrixQuadratic_nonneg _ (coefficientCovariance_posSemidef _ _
    (tiltedPolynomial_coefficient_nonnegative p (s • v) hcoeff hnorm)) v

theorem paper_balanced_log_local_coercivity (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (hcoeff : ∀ g,0≤p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=1)
    (r : ℝ) (hr : 0≤r) (ha : 0<1-(n : ℝ)*r)
    (hUnmixed : ∀ g,0≤(uniformUnmixedPolynomial p n r).coeff g)
    (v : Fin n → ℝ) (hvnorm : (∑ j,v j^2)≤1) (hv : ∑ j,v j=0) :
    (((n : ℝ)*r/8)*(∑ j,v j^2))/2≤Real.log (MvPolynomial.eval (fun j => Real.exp (v j)) p) := by
  have hZ (s : ℝ) := ne_of_gt (tiltPartition_pos p (s • v) hcoeff hnorm)
  have hF (s : ℝ) : HasDerivAt (logGeneratingRay p v) (deriv (logGeneratingRay p v) s) s :=
    (logGeneratingRay_hasDerivAt p v s (hZ s)).differentiableAt.hasDerivAt
  have hD (s : ℝ) := logGeneratingRay_second_hasDerivAt p v s (hZ s)
  have hA (s : ℝ) (hs : s∈Set.Icc (0 : ℝ) 1) :
      ((n : ℝ)*r/8)*(∑ j,v j^2)≤
        matrixQuadratic (coefficientCovariance (tiltedPolynomial p (s • v)) (tiltedMoment p (s • v))) v := by
    have he : (∑ j,(s • v) j^2)=s^2*(∑ j,v j^2) := by
      simp only [Pi.smul_apply,smul_eq_mul,mul_pow,Finset.mul_sum]
    have hs2 : s^2≤1 := by nlinarith [hs.1,hs.2]
    have hss : (∑ j,(s • v) j^2)≤1 := by
      rw [he]
      nlinarith [mul_nonneg (sq_nonneg s) (sub_nonneg.mpr hvnorm)]
    have h := paper_noise_hessian_from_nonnegative_unmixing p hp hnorm r hr ha hUnmixed (s • v) v hss hv
    rwa [actualLogHessian_eq_covariance p (s • v) (hZ s)] at h
  have hf0 : logGeneratingRay p v 0=0 := by
    simp [logGeneratingRay,tiltPartition_eval_exp_all,hnorm]
  have hd0 : deriv (logGeneratingRay p v) 0=0 := by
    rw [(logGeneratingRay_hasDerivAt p v 0 (hZ 0)).deriv]
    simp only [zero_smul,tiltedMoment_zero p hnorm,hgrad,one_mul,hv]
  have h := scalar_strong_coercivity_segment (logGeneratingRay p v) (deriv (logGeneratingRay p v))
    (fun s => matrixQuadratic (coefficientCovariance (tiltedPolynomial p (s • v)) (tiltedMoment p (s • v))) v)
    (((n : ℝ)*r/8)*(∑ j,v j^2)) hF hD hA hf0 hd0
  simpa only [logGeneratingRay,one_smul,tiltPartition_eval_exp_all] using h

end CoefficientStability
