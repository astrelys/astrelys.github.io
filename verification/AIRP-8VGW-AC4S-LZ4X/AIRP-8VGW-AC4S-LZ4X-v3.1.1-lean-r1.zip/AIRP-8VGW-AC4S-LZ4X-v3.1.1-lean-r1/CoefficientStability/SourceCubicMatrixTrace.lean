import CoefficientStability.SourceOriginalL1Theorem
import CoefficientStability.MixedStationarity

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 2400000
set_option backward.isDefEq.respectTransparency false

theorem source_complex_three_det_trace (A : Matrix (Fin 3) (Fin 3) ℂ) :
    A.det=(Matrix.trace A)^3/6-(Matrix.trace A)*Matrix.trace (A^2)/2+Matrix.trace (A^3)/3 := by
  norm_num [Matrix.det_fin_three,Matrix.trace,Matrix.mul_apply,Fin.sum_univ_succ,pow_succ]
  ring

theorem source_fin_three_permutations : (Finset.univ : Finset (Equiv.Perm (Fin 3)))=
    {1,Equiv.swap 0 1,Equiv.swap 0 2,Equiv.swap 1 2,
      Equiv.swap 0 1*Equiv.swap 1 2,Equiv.swap 1 2*Equiv.swap 0 1} := by decide

theorem source_sum_three_permutations (f : Equiv.Perm (Fin 3) → ℂ) :
    (∑ p,f p)=f 1+f (Equiv.swap 0 1)+f (Equiv.swap 0 2)+f (Equiv.swap 1 2)+
      f (Equiv.swap 0 1*Equiv.swap 1 2)+f (Equiv.swap 1 2*Equiv.swap 0 1) := by
  rw [source_fin_three_permutations]
  rw [Finset.sum_insert (by decide),Finset.sum_insert (by decide),Finset.sum_insert (by decide),
    Finset.sum_insert (by decide),Finset.sum_insert (by decide),Finset.sum_singleton]
  ring

def sourceCubicColumnSelection (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (p : Equiv.Perm (Fin 3)) : Matrix (Fin 3) (Fin 3) ℂ :=
  fun r c => A (p c) r c

theorem source_cubic_selection_det (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (p : Equiv.Perm (Fin 3)) :
    (sourceCubicColumnSelection A p).det=
      A (p 0) 0 0*A (p 1) 1 1*A (p 2) 2 2-A (p 0) 0 0*A (p 2) 1 2*A (p 1) 2 1-
      A (p 1) 0 1*A (p 0) 1 0*A (p 2) 2 2+A (p 1) 0 1*A (p 2) 1 2*A (p 0) 2 0+
      A (p 2) 0 2*A (p 0) 1 0*A (p 1) 2 1-A (p 2) 0 2*A (p 1) 1 1*A (p 0) 2 0 := by
  exact Matrix.det_fin_three (sourceCubicColumnSelection A p)

theorem source_cubic_mixed_inclusion_exclusion (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) :
    complexMixedDiscriminant A=(A 0+A 1+A 2).det-
      (A 0+A 1).det-(A 0+A 2).det-(A 1+A 2).det+
      (A 0).det+(A 1).det+(A 2).det := by
  rw [complexMixedDiscriminant_generic,genericMixedDiscriminant_eq_rowDetSum]
  change (∑ p,(sourceCubicColumnSelection A p).det)=_
  rw [source_sum_three_permutations]
  simp only [source_cubic_selection_det]
  norm_num [Matrix.det_fin_three,Equiv.swap_apply_def,Equiv.Perm.mul_apply,Matrix.add_apply]
  ring

end CoefficientStability
