import CoefficientStability.SourceTernaryRadialExpansion

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1200000

theorem source_ternary_weighted_scalar_zero (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hbox : ∀ i,1/2 ≤ t i ∧ t i ≤ 3/2) (x : Fin 3 → ℝ) (hx : (∑ i,x i)=0)
    (hz : (∑ i,(3-2*t i)*(x i)^2)=0) : x=0 := by
  have hc (i : Fin 3) : 0 ≤ 3-2*t i := by linarith [(hbox i).2]
  have he (i : Fin 3) : (3-2*t i)*(x i)^2=0 :=
    (Finset.sum_eq_zero_iff_of_nonneg (fun j _ => mul_nonneg (hc j) (sq_nonneg (x j)))).mp hz i (Finset.mem_univ i)
  have hval (i : Fin 3) (hi : 0 < 3-2*t i) : x i=0 := by
    have hsq := (mul_eq_zero.mp (he i)).resolve_left (ne_of_gt hi)
    exact sq_eq_zero_iff.mp hsq
  have hts := ht
  have hxs := hx
  norm_num [Fin.sum_univ_succ] at hts hxs
  by_cases h0 : 0 < 3-2*t 0
  · have hx0 := hval 0 h0
    by_cases h1 : 0 < 3-2*t 1
    · have hx1 := hval 1 h1
      have hx2 : x 2=0 := by linarith
      funext i
      fin_cases i <;> simp [hx0,hx1,hx2]
    · have h1z : 3-2*t 1=0 := le_antisymm (le_of_not_gt h1) (hc 1)
      have h2 : 0 < 3-2*t 2 := by linarith [(hbox 0).1]
      have hx2 := hval 2 h2
      have hx1 : x 1=0 := by linarith
      funext i
      fin_cases i <;> simp [hx0,hx1,hx2]
  · have h0z : 3-2*t 0=0 := le_antisymm (le_of_not_gt h0) (hc 0)
    have h1 : 0 < 3-2*t 1 := by linarith [(hbox 2).1]
    have h2 : 0 < 3-2*t 2 := by linarith [(hbox 1).1]
    have hx1 := hval 1 h1
    have hx2 := hval 2 h2
    have hx0 : x 0=0 := by linarith
    funext i
    fin_cases i <;> simp [hx0,hx1,hx2]

theorem source_ternary_radial_quadratic_nonnegative (t : Fin 3 → ℝ)
    (hbox : ∀ i,t i ≤ 3/2) (A : Matrix (Fin 3) (Fin 3) ℝ) :
    0 ≤ sourceTernaryRadialQuadratic t A := by
  unfold sourceTernaryRadialQuadratic
  apply mul_nonneg (by norm_num)
  apply Finset.sum_nonneg
  intro i hi
  exact mul_nonneg (by linarith [hbox i]) (Finset.sum_nonneg (fun j _ => sq_nonneg _))

theorem source_ternary_radial_quadratic_zero_iff (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hbox : ∀ i,1/2 ≤ t i ∧ t i ≤ 3/2) (A : Matrix (Fin 3) (Fin 3) ℝ)
    (hcol : ∀ j,∑ i,A i j=0) : sourceTernaryRadialQuadratic t A=0 ↔ A=0 := by
  constructor
  · intro hz
    have he : 6*sourceTernaryRadialQuadratic t A=∑ j,∑ i,(3-2*t i)*(A i j)^2 := by
      unfold sourceTernaryRadialQuadratic
      simp only [Finset.mul_sum]
      rw [Finset.sum_comm]
      ring
    rw [hz,mul_zero] at he
    have hsum := he.symm
    have hn (j : Fin 3) : 0 ≤ ∑ i,(3-2*t i)*(A i j)^2 :=
      Finset.sum_nonneg (fun i _ => mul_nonneg (by linarith [(hbox i).2]) (sq_nonneg _))
    have hzero (j : Fin 3) : ∑ i,(3-2*t i)*(A i j)^2=0 :=
      (Finset.sum_eq_zero_iff_of_nonneg (fun j _ => hn j)).mp hsum j (Finset.mem_univ j)
    ext i j
    exact congrFun (source_ternary_weighted_scalar_zero t ht hbox (fun i => A i j) (hcol j) (hzero j)) i
  · intro hz
    simp [hz,sourceTernaryRadialQuadratic]

end CoefficientStability
