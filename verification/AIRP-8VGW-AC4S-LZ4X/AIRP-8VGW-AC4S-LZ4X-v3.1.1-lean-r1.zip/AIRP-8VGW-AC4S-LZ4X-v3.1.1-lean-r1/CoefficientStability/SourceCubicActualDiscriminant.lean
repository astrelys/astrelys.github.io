import CoefficientStability.CubicRootEstimate

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000

theorem source_centered_real_triple_discriminant (a b c q d : ℝ)
    (hs : a+b+c=0) (hq : q= -(a*b+a*c+b*c)) (hd : d=a*b*c) :
    4*q^3-27*d^2=((a-b)*(a-c)*(b-c))^2 := by
  rw [hq,hd]
  have hc : c= -a-b := by linarith
  rw [hc]
  ring

theorem source_stable_cubic_actual_central_discriminant {n : ℕ}
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hp : p.IsHomogeneous 3) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (x : Fin n → ℝ) :
    0≤4*(matrixQuadratic (deficitMatrix p t 3) x)^3-
      27*(MvPolynomial.eval x (centralCoefficientPolynomial p t 3 3))^2 := by
  obtain ⟨roots,hcard,hv,he⟩ := centralLineCoefficient_eq_centered_esymm p t 3 x (by omega) hp hnorm hstable hgrad
  have hs := centeredRoots_sum roots (by omega)
  have hc : (centeredRoots roots).card=3 := by rw [centeredRoots_card,hcard]
  obtain ⟨a,b,c,habc⟩ := Multiset.card_eq_three.mp hc
  have hq := (paper_first_second_central_coefficients p t 3 x (by omega) hp hnorm hstable hgrad).2
  rw [he 2 (by omega),habc] at hq
  have hd := he 3 (by omega)
  rw [habc,← eval_centralCoefficientPolynomial] at hd
  rw [habc] at hs
  simp at hs
  have hq' : matrixQuadratic (deficitMatrix p t 3) x= -(a*b+a*c+b*c) := by
    have h2 : ({a,b,c} : Multiset ℝ).esymm 2=a*b+a*c+b*c := by
      norm_num [esymm_cons,esymm_one,Multiset.esymm,Multiset.powersetCard_one]
      ring
    rw [h2] at hq
    linarith
  have hd' : MvPolynomial.eval x (centralCoefficientPolynomial p t 3 3)=a*b*c := by
    simpa [Multiset.esymm,Multiset.powersetCard_one,mul_assoc] using hd
  rw [source_centered_real_triple_discriminant a b c _ _ (by linarith) hq' hd']
  exact sq_nonneg _

end CoefficientStability
