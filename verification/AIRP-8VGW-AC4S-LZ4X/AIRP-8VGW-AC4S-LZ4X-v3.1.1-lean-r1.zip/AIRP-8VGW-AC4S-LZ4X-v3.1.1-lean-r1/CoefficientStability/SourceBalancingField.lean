import CoefficientStability.SourceNoiseConditioning
import CoefficientStability.LogCapacityStationarity

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem source_nearoptimal_pure_coeff_pos (p : MvPolynomial (Fin n) ℝ) (hn : 3 ≤ n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|) ≤ capacityEta n/(64*(n : ℝ)))
    (hcoef : p.coeff (squarefreeExponent n) ≤ sourceVn n*(1+capacityEta n/2)) :
    ∀ i,0 < p.coeff (Finsupp.single i n) := by
  intro i
  obtain ⟨roots,hcard,hr,hf⟩ := source_polynomial_cone_margin p hn hp hs hnorm hgrad hcoef i
  have hb : Pi.single i (1 : ℝ) ∈ positiveSpectralCone p n :=
    ⟨roots,hcard,fun s hs => (sourceMixingRadius_pos n hn).trans (hr s hs),hf⟩
  simpa only [homogeneous_eval_basis p n hp i] using positiveSpectralCone_eval_pos p hp hs hnorm _ hb

theorem source_centered_balancing_field_exists (p : MvPolynomial (Fin n) ℝ) (hn : 3 ≤ n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|) ≤ capacityEta n/(64*(n : ℝ)))
    (hcoef : p.coeff (squarefreeExponent n) ≤ sourceVn n*(1+capacityEta n/2)) :
    ∃ u : Fin n → ℝ,(∑ i,u i=0) ∧ (∀ i,tiltedMoment p u i=1) ∧
      multivariatePositiveCapacity p=MvPolynomial.eval (fun i => Real.exp (u i)) p := by
  have hc := normalized_homogeneous_stable_coeff_nonneg p n hp hs hnorm
  obtain ⟨u,hu,hcap⟩ := positive_pure_capacity_centered_field (by omega) p hp hc
    (source_nearoptimal_pure_coeff_pos p hn hp hs hnorm hgrad hcoef)
  refine ⟨u,hu,?_,hcap⟩
  apply capacity_attainment_tiltedMoment_one p (stable_polynomial_ne_zero p hs) hc u
  simpa only [zero_sum_exp_product u hu,div_one] using hcap

end CoefficientStability
