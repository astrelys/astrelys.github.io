import CoefficientStability.UniformRealRootBound
import Mathlib.Data.Finset.Sort

noncomputable section
namespace CoefficientStability

def orderedSimpleRoots (P : Polynomial ℝ) (N : ℕ) (hcard : P.roots.toFinset.card=N) : Fin N ↪o ℝ :=
  P.roots.toFinset.orderEmbOfFin hcard

theorem simple_real_roots_card (P : Polynomial ℝ) (hs : P.Splits) (hnodup : P.roots.Nodup)
    (N : ℕ) (hdegree : P.natDegree=N) : P.roots.toFinset.card=N := by
  classical
  rw [Multiset.toFinset_card_of_nodup hnodup,← hs.natDegree_eq_card_roots,hdegree]

theorem orderedSimpleRoots_mem (P : Polynomial ℝ) (N : ℕ) (hcard : P.roots.toFinset.card=N)
    (i : Fin N) : orderedSimpleRoots P N hcard i∈P.roots := by
  classical
  simpa only [orderedSimpleRoots,Multiset.mem_toFinset] using Finset.orderEmbOfFin_mem P.roots.toFinset hcard i

theorem orderedSimpleRoots_cover (P : Polynomial ℝ) (N : ℕ) (hcard : P.roots.toFinset.card=N)
    (r : ℝ) (hr : r∈P.roots) : ∃ i : Fin N,orderedSimpleRoots P N hcard i=r := by
  classical
  have hrset : r∈P.roots.toFinset := by simpa only [Multiset.mem_toFinset] using hr
  refine ⟨(P.roots.toFinset.orderIsoOfFin hcard).symm ⟨r,hrset⟩,?_⟩
  change (((P.roots.toFinset.orderIsoOfFin hcard) ((P.roots.toFinset.orderIsoOfFin hcard).symm ⟨r,hrset⟩)) : ℝ)=r
  simp

theorem orderedSimpleRoots_multiset (P : Polynomial ℝ) (N : ℕ) (hcard : P.roots.toFinset.card=N)
    (hnodup : P.roots.Nodup) :
    P.roots=(List.ofFn (fun i => orderedSimpleRoots P N hcard i) : Multiset ℝ) := by
  classical
  have hn : (List.ofFn (fun i => orderedSimpleRoots P N hcard i) : Multiset ℝ).Nodup := by
    simpa using List.nodup_ofFn_ofInjective (orderedSimpleRoots P N hcard).injective
  apply (Multiset.Nodup.ext hnodup hn).mpr
  intro r
  simp only [Multiset.mem_coe,List.mem_ofFn]
  constructor
  · exact orderedSimpleRoots_cover P N hcard r
  · rintro ⟨i,rfl⟩
    exact orderedSimpleRoots_mem P N hcard i

theorem orderedSimpleRoots_factorization (P : Polynomial ℝ) (hp : P.Monic) (hs : P.Splits)
    (N : ℕ) (hcard : P.roots.toFinset.card=N) (hnodup : P.roots.Nodup) :
    P=∏ i : Fin N,(Polynomial.X-Polynomial.C (orderedSimpleRoots P N hcard i)) := by
  calc
    P=(P.roots.map (fun r => Polynomial.X-Polynomial.C r)).prod := hs.eq_prod_roots_of_monic hp
    _=∏ i : Fin N,(Polynomial.X-Polynomial.C (orderedSimpleRoots P N hcard i)) := by
      conv_lhs => rw [orderedSimpleRoots_multiset P N hcard hnodup]
      simp only [Multiset.map_coe,List.map_ofFn,Multiset.prod_coe,List.prod_ofFn,Function.comp_def]

end CoefficientStability
