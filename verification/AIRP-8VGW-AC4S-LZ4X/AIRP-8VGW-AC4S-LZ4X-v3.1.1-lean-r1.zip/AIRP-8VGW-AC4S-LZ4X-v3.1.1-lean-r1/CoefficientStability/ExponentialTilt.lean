import CoefficientStability.ExactLocalStability
import Mathlib.Analysis.SpecialFunctions.ExpDeriv

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def tiltExponent (g : Fin n →₀ ℕ) (u : Fin n → ℝ) : ℝ := ∑ i,(g i : ℝ)*u i

def tiltWeight (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ) (g : Fin n →₀ ℕ) : ℝ :=
  p.coeff g*Real.exp (tiltExponent g u)

def tiltPartition (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ) : ℝ :=
  ∑ g ∈ p.support,tiltWeight p u g

def tiltedPolynomial (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ) : MvPolynomial (Fin n) ℝ :=
  ∑ g ∈ p.support,monomial g (tiltWeight p u g/tiltPartition p u)

theorem tiltedPolynomial_coeff (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ) (g : Fin n →₀ ℕ) :
    (tiltedPolynomial p u).coeff g=tiltWeight p u g/tiltPartition p u := by
  classical
  by_cases hg : g∈p.support
  · simp [tiltedPolynomial,MvPolynomial.coeff_sum,MvPolynomial.coeff_monomial,hg]
  · have hc : p.coeff g=0 := by
      by_contra h
      exact hg (MvPolynomial.mem_support_iff.mpr h)
    simp [tiltedPolynomial,MvPolynomial.coeff_sum,MvPolynomial.coeff_monomial,hg,tiltWeight,hc]

theorem tiltPartition_pos (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ)
    (hc : ∀ g,0≤p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1) :
    0<tiltPartition p u := by
  have hm := normalized_coefficient_mass p hnorm
  have hex : ∃ g∈p.support,0<p.coeff g := by
    by_contra! h
    have hz : ∑ g∈p.support,p.coeff g=0 := Finset.sum_eq_zero (fun g hg => le_antisymm (h g hg) (hc g))
    linarith
  obtain ⟨g,hg,hgpos⟩ := hex
  apply Finset.sum_pos_iff_of_nonneg (fun a ha => mul_nonneg (hc a) (Real.exp_pos _).le) |>.mpr
  exact ⟨g,hg,mul_pos hgpos (Real.exp_pos _)⟩

theorem tiltedPolynomial_normalized (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ)
    (hZ : tiltPartition p u≠0) : MvPolynomial.eval (fun _ => 1) (tiltedPolynomial p u)=1 := by
  simp only [tiltedPolynomial,map_sum,MvPolynomial.eval_monomial,one_pow,Finsupp.prod,Finset.prod_const_one,mul_one]
  rw [← Finset.sum_div]
  exact div_self hZ

theorem tiltedPolynomial_support (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ)
    (hZ : tiltPartition p u≠0) : (tiltedPolynomial p u).support=p.support := by
  ext g
  simp only [MvPolynomial.mem_support_iff,tiltedPolynomial_coeff,tiltWeight,ne_eq,div_eq_zero_iff,mul_eq_zero,
    Real.exp_ne_zero,or_false,hZ,or_false]

theorem eval_monomial_univ (g : Fin n →₀ ℕ) (a : ℝ) (x : Fin n → ℝ) :
    MvPolynomial.eval x (monomial g a)=a*(∏ i,x i^(g i)) := by
  rw [MvPolynomial.eval_monomial,Finsupp.prod_fintype g (fun i e => x i^e) (fun i => pow_zero _)]

theorem tiltedPolynomial_eval (p : MvPolynomial (Fin n) ℝ) (u x : Fin n → ℝ) :
    MvPolynomial.eval x (tiltedPolynomial p u)=
      MvPolynomial.eval (fun i => Real.exp (u i)*x i) p/tiltPartition p u := by
  classical
  have hev : MvPolynomial.eval (fun i => Real.exp (u i)*x i) p=
      ∑ g∈p.support,p.coeff g*(∏ i,(Real.exp (u i)*x i)^(g i)) := by
    conv_lhs => rw [p.as_sum]
    simp only [map_sum,eval_monomial_univ]
  rw [hev]
  simp only [tiltedPolynomial,map_sum,eval_monomial_univ]
  simp only [mul_pow,Finset.prod_mul_distrib]
  rw [Finset.sum_div]
  apply Finset.sum_congr rfl
  intro g hg
  have he : Real.exp (tiltExponent g u)=∏ i,Real.exp (u i)^(g i) := by
    rw [tiltExponent,Real.exp_sum]
    apply Finset.prod_congr rfl
    intro i hi
    rw [Real.exp_nat_mul]
  simp only [tiltWeight,he]
  ring

end CoefficientStability
