import CoefficientStability.NuijStablePerturbation

noncomputable section
namespace CoefficientStability

theorem monic_add_real_derivative_degree (P : Polynomial ℝ) (hp : P.Monic) (c : ℝ) :
    (P+Polynomial.C c*P.derivative).Monic ∧
      (P+Polynomial.C c*P.derivative).natDegree=P.natDegree := by
  by_cases hc : c=0
  · subst c
    simp only [Polynomial.C_0,zero_mul,add_zero]
    exact ⟨hp,True.intro⟩
  have hd : (Polynomial.C c*P.derivative).degree<P.degree := by
    rw [Polynomial.degree_C_mul hc]
    exact Polynomial.degree_derivative_lt hp.ne_zero
  exact ⟨hp.add_of_left hd,Polynomial.natDegree_add_eq_left_of_degree_lt hd⟩

theorem splits_real_upper_zero_free (P : Polynomial ℝ) (hs : P.Splits) (hp : P≠0) :
    realUnivariateUpperZeroFree P := by
  obtain ⟨roots,hfactor⟩ := Polynomial.splits_iff_exists_multiset'.mp hs
  intro z hz
  change (Polynomial.eval₂RingHom Complex.ofRealHom z) P≠0
  rw [hfactor,map_mul,map_multiset_prod]
  apply mul_ne_zero
  · simpa only [Polynomial.coe_eval₂RingHom,Polynomial.eval₂_C,Complex.ofRealHom_eq_coe] using
      Complex.ofReal_ne_zero.mpr (Polynomial.leadingCoeff_ne_zero.mpr hp)
  · apply Multiset.prod_ne_zero
    intro hmem
    obtain ⟨Q,hQ,hzero⟩ := Multiset.mem_map.mp hmem
    obtain ⟨r,hr,rfl⟩ := Multiset.mem_map.mp hQ
    change Polynomial.eval₂ Complex.ofRealHom z (Polynomial.X+Polynomial.C r)=0 at hzero
    simp only [Polynomial.eval₂_add,Polynomial.eval₂_X,Polynomial.eval₂_C] at hzero
    have him := congrArg Complex.im hzero
    simp only [Complex.add_im,Complex.ofRealHom_eq_coe,Complex.ofReal_im,add_zero,Complex.zero_im] at him
    linarith

theorem splits_add_real_derivative (P : Polynomial ℝ) (hs : P.Splits) (hp : P≠0) (c : ℝ) :
    (P+Polynomial.C c*P.derivative).Splits := by
  have hP : complexPolynomialUpperZeroFree (P.map Complex.ofRealHom) := by
    intro z hz
    simpa only [Polynomial.eval_map] using splits_real_upper_zero_free P hs hp z hz
  have hQ := upper_zero_free_add_real_derivative (P.map Complex.ofRealHom) hP c
  have heq : (P+Polynomial.C c*P.derivative).map Complex.ofRealHom=
      P.map Complex.ofRealHom+Polynomial.C (c : ℂ)*(P.map Complex.ofRealHom).derivative := by
    simp only [Polynomial.map_add,Polynomial.map_mul,Polynomial.map_C,Polynomial.derivative_map]
    rfl
  apply real_upper_zero_free_splits
  intro z hz
  have h := hQ z hz
  rw [← heq,Polynomial.eval_map] at h
  exact h

end CoefficientStability
