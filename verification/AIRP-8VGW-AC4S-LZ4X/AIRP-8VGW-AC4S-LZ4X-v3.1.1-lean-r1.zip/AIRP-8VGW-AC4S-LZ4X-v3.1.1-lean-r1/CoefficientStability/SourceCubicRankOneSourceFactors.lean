import CoefficientStability.SourceCubicRankOneRemainder
import CoefficientStability.SourceBinaryQuadraticRankConditions
import CoefficientStability.SourceCubicActualRootTriple

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

theorem source_stable_cubic_actual_first_rank_one_factors
    (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ)
    (hp : p.IsHomogeneous 3) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) (ht : ∑ i,t i=3)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (ha : deficitMatrix p t 3 0 0≠0)
    (hd : deficitMatrix p t 3 0 0*deficitMatrix p t 3 1 1-(deficitMatrix p t 3 0 1)^2=0) :
    ∃ a b c : ℝ,∀ s x y : ℝ,
      MvPolynomial.eval (sourceDepressedCubicCoordinates t s x y) p=
        (s+a*(x+(deficitMatrix p t 3 0 1/deficitMatrix p t 3 0 0)*y))*
        (s+b*(x+(deficitMatrix p t 3 0 1/deficitMatrix p t 3 0 0)*y))*
        (s+c*(x+(deficitMatrix p t 3 0 1/deficitMatrix p t 3 0 0)*y)) := by
  let Q := deficitMatrix p t 3
  let C := centralCoefficientPolynomial p t 3 3
  let k := Q 0 1/Q 0 0
  have hquad (x y : ℝ) : matrixQuadratic Q (![x,y,0] : Fin 3 → ℝ)=Q 0 0*(x+k*y)^2 := by
    rw [source_binary_restricted_quadratic_exact Q (deficitMatrix_isHermitian p t 3)]
    exact source_binary_rank_one_exact_quadratic _ _ _ ha hd x y
  have hdisc (x y : ℝ) : 0≤4*(Q 0 0*(x+k*y)^2)^3-27*(MvPolynomial.eval (![x,y,0] : Fin 3 → ℝ) C)^2 := by
    have h := source_stable_cubic_actual_central_discriminant p t hp hn hs hg (![x,y,0] : Fin 3 → ℝ)
    rw [← hquad x y]
    exact h
  have hC : C.IsHomogeneous 3 := centralCoefficientPolynomial_homogeneous p t 3 3 (by omega) hp
  have hfactor := source_binary_rank_one_actual_cubic_factor C hC (Q 0 0) k hdisc
  obtain ⟨a,b,c,hsum,hq,hc⟩ := source_stable_cubic_actual_centered_root_triple p t hp hn hs hg
    (![1,0,0] : Fin 3 → ℝ)
  rw [hquad 1 0] at hq
  norm_num only [mul_zero,add_zero,one_pow,mul_one] at hq
  refine ⟨a,b,c,?_⟩
  intro s x y
  rw [source_stable_cubic_actual_depressed_normal_form p t hp hn hs ht hg,hquad x y,hfactor x y]
  have h := source_actual_centered_root_triple_product a b c (Q 0 0) (MvPolynomial.eval (![1,0,0] : Fin 3 → ℝ) C)
    hsum hq hc s (x+k*y)
  dsimp only [Q,C,k] at *
  nlinarith only [h]

theorem source_stable_cubic_actual_second_axis_factors
    (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ)
    (hp : p.IsHomogeneous 3) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) (ht : ∑ i,t i=3)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (ha : deficitMatrix p t 3 0 0=0) (hb : deficitMatrix p t 3 0 1=0) :
    ∃ a b c : ℝ,∀ s x y : ℝ,
      MvPolynomial.eval (sourceDepressedCubicCoordinates t s x y) p=(s+a*y)*(s+b*y)*(s+c*y) := by
  let Q := deficitMatrix p t 3
  let C := centralCoefficientPolynomial p t 3 3
  have hquad (x y : ℝ) : matrixQuadratic Q (![x,y,0] : Fin 3 → ℝ)=Q 1 1*y^2 := by
    rw [source_binary_restricted_quadratic_exact Q (deficitMatrix_isHermitian p t 3)]
    simp only [show Q 0 0=0 from ha,show Q 0 1=0 from hb,zero_mul,mul_zero,zero_add]
  have hdisc (x y : ℝ) : 0≤4*(Q 1 1*y^2)^3-27*(MvPolynomial.eval (![x,y,0] : Fin 3 → ℝ) C)^2 := by
    have h := source_stable_cubic_actual_central_discriminant p t hp hn hs hg (![x,y,0] : Fin 3 → ℝ)
    rw [← hquad x y]
    exact h
  have hC : C.IsHomogeneous 3 := centralCoefficientPolynomial_homogeneous p t 3 3 (by omega) hp
  have hfactor := source_binary_second_axis_actual_cubic_factor C hC (Q 1 1) hdisc
  obtain ⟨a,b,c,hsum,hq,hc⟩ := source_stable_cubic_actual_centered_root_triple p t hp hn hs hg
    (![0,1,0] : Fin 3 → ℝ)
  rw [hquad 0 1] at hq
  norm_num only [one_pow,mul_one] at hq
  refine ⟨a,b,c,?_⟩
  intro s x y
  rw [source_stable_cubic_actual_depressed_normal_form p t hp hn hs ht hg,hquad x y,hfactor x y]
  have h := source_actual_centered_root_triple_product a b c (Q 1 1) (MvPolynomial.eval (![0,1,0] : Fin 3 → ℝ) C)
    hsum hq hc s y
  dsimp only [Q,C] at *
  nlinarith only [h]

end CoefficientStability
