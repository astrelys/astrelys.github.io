import CoefficientStability.SourceStableCubicHyperbolicInput

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

theorem source_homogeneous_stable_all_direction_real_zero {n : ℕ}
    (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (hp : p.IsHomogeneous N)
    (hs : UpperHalfPlaneZeroFree p) (x : Fin n → ℝ) (z : ℂ)
    (hz : Polynomial.eval₂ Complex.ofRealHom z
      (affineDirectionalRestriction p (fun _ => 1) x)=0) : z.im=0 := by
  by_cases hz0 : z=0
  · simp [hz0]
  have hscale := homogeneous_eval_complex_scale p N hp z (fun i => z⁻¹+(x i : ℂ))
  have hvec : (fun i => z*(z⁻¹+(x i : ℂ)))=(fun i => (1 : ℂ)+z*(x i : ℂ)) := by
    funext i
    field_simp
  rw [affineDirectionalRestriction_complex_eval] at hz
  simp only [Complex.ofReal_one] at hz
  rw [hvec,hz] at hscale
  have hroot : Polynomial.eval₂ Complex.ofRealHom z⁻¹ (lineRestriction p x)=0 := by
    rw [eval_lineRestriction]
    exact (mul_eq_zero.mp hscale.symm).resolve_left (pow_ne_zero N hz0)
  have him := lineRestriction_root_is_real p hs x z⁻¹ hroot
  have hre : (((z⁻¹).re : ℝ) : ℂ)=z⁻¹ := by
    apply Complex.ext
    · simp
    · simpa using him.symm
  calc
    z.im=(((((z⁻¹).re : ℝ) : ℂ))⁻¹).im := by rw [hre,inv_inv]
    _=0 := by simp

def sourceCubicPlaneV : Fin 3 → ℝ := ![2,1,1]
def sourceCubicPlaneW : Fin 3 → ℝ := ![1,2,1]
def sourceCubicPlanePoint (u : Fin 2 → ℝ) : Fin 3 → ℝ :=
  fun i => 1+u 0*sourceCubicPlaneV i+u 1*sourceCubicPlaneW i

def sourceCubicPlanePolynomial (p : MvPolynomial (Fin 3) ℝ) : MvPolynomial (Fin 2) ℝ :=
  MvPolynomial.eval₂ MvPolynomial.C (fun i => 1+
    MvPolynomial.C (sourceCubicPlaneV i)*MvPolynomial.X 0+
    MvPolynomial.C (sourceCubicPlaneW i)*MvPolynomial.X 1) p

theorem source_cubic_plane_actual_evaluation (p : MvPolynomial (Fin 3) ℝ)
    (u : Fin 2 → ℝ) :
    MvPolynomial.eval u (sourceCubicPlanePolynomial p)=MvPolynomial.eval (sourceCubicPlanePoint u) p := by
  unfold sourceCubicPlanePolynomial
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c;simp
  · funext i;simp [sourceCubicPlanePoint];ring

theorem source_cubic_plane_normalized (p : MvPolynomial (Fin 3) ℝ)
    (hn : MvPolynomial.eval (fun _ => 1) p=1) :
    MvPolynomial.eval (fun _ => 0) (sourceCubicPlanePolynomial p)=1 := by
  rw [source_cubic_plane_actual_evaluation]
  have hv : sourceCubicPlanePoint (fun _ => 0)=(fun _ => 1) := by
    funext i
    simp [sourceCubicPlanePoint]
  rw [hv]
  exact hn

theorem source_cubic_plane_actual_line (p : MvPolynomial (Fin 3) ℝ)
    (u : Fin 2 → ℝ) :
    affineDirectionalRestriction (sourceCubicPlanePolynomial p) (fun _ => 0) u=
      affineDirectionalRestriction p (fun _ => 1)
        (fun i => u 0*sourceCubicPlaneV i+u 1*sourceCubicPlaneW i) := by
  apply Polynomial.funext
  intro s
  rw [affineDirectionalRestriction_eval,source_cubic_plane_actual_evaluation,affineDirectionalRestriction_eval]
  apply congrArg (fun v => MvPolynomial.eval v p)
  funext i
  simp [sourceCubicPlanePoint]
  ring

theorem source_stable_cubic_actual_bivariate_real_zero (p : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3) (hs : UpperHalfPlaneZeroFree p) (u : Fin 2 → ℝ) (z : ℂ)
    (hz : Polynomial.eval₂ Complex.ofRealHom z
      (affineDirectionalRestriction (sourceCubicPlanePolynomial p) (fun _ => 0) u)=0) : z.im=0 := by
  rw [source_cubic_plane_actual_line] at hz
  exact source_homogeneous_stable_all_direction_real_zero p 3 hp hs _ z hz

theorem source_cubic_plane_homogeneous_inverse (x : Fin 3 → ℝ) (i : Fin 3) :
    (3*x 2-x 0-x 1)+(x 0-x 2)*sourceCubicPlaneV i+
      (x 1-x 2)*sourceCubicPlaneW i=x i := by
  fin_cases i <;> norm_num [sourceCubicPlaneV,sourceCubicPlaneW] <;> ring

end CoefficientStability
