import CoefficientStability.SourceClonePartials
import Mathlib.Algebra.BigOperators.Fin

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {m n : ℕ}

def sourceMultiExponent (α : Fin m → ℕ) : Fin m →₀ ℕ := ∑ i,Finsupp.single i (α i)

@[simp] theorem sourceMultiExponent_apply (α : Fin m → ℕ) (i : Fin m) : sourceMultiExponent α i=α i := by
  classical
  simp [sourceMultiExponent,Finsupp.single_apply]

theorem sourceWordExponent_eq_sum (l : List (Fin n)) :
    sourceWordExponent l=(l.map (fun i => Finsupp.single i 1)).sum := by
  induction l with
  | nil => rfl
  | cons i l ih => simp only [sourceWordExponent,List.map_cons,List.sum_cons,ih]

theorem sourceWordExponent_all_fin (n : ℕ) :
    sourceWordExponent (List.ofFn (fun i : Fin n => i))=squarefreeExponent n := by
  rw [sourceWordExponent_eq_sum,List.map_ofFn,Fin.sum_ofFn]
  rfl

theorem sourceWordExponent_clone_blocks (α : Fin m → ℕ) :
    sourceWordExponent (List.ofFn (sourceCloneBlock α))=sourceMultiExponent α := by
  classical
  rw [sourceWordExponent_eq_sum,List.map_ofFn,Fin.sum_ofFn]
  simp only [Function.comp_apply]
  rw [← Equiv.sum_comp (sourceCloneEquiv α) (fun j => Finsupp.single (sourceCloneBlock α j) (1 : ℕ))]
  simp only [Fintype.sum_sigma,sourceCloneBlock_equiv,Finset.sum_const,Finset.card_univ,Fintype.card_fin]
  unfold sourceMultiExponent
  apply Finset.sum_congr rfl
  intro i hi
  ext k
  simp [Finsupp.single_apply]

theorem sourceCloneWord_inverse_block_product (α : Fin m → ℕ) :
    ((List.ofFn (fun j : Fin (sourceCloneCount α) => j)).map
      (fun j => 1/(α (sourceCloneBlock α j) : ℝ))).prod=
      ∏ i,(1/(α i : ℝ))^(α i) := by
  rw [List.map_ofFn,Fin.prod_ofFn]
  simp only [Function.comp_apply]
  rw [← Equiv.prod_comp (sourceCloneEquiv α) (fun j => 1/(α (sourceCloneBlock α j) : ℝ))]
  simp only [Fintype.prod_sigma,sourceCloneBlock_equiv,Finset.prod_const,Finset.card_univ,Fintype.card_fin]

theorem sourceCloneWord_factorial_product (α : Fin m → ℕ) :
    (∏ i,((sourceWordExponent (List.ofFn (sourceCloneBlock α)) i).factorial : ℝ))=
      ∏ i,((α i).factorial : ℝ) := by
  simp only [sourceWordExponent_clone_blocks,sourceMultiExponent_apply]

end CoefficientStability
