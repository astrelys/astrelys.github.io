import CoefficientStability.SourceFaceLocalStationarity

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 1200000

theorem source_ternary_separated_minimum_stationary (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b : ℝ)
    (hpos : ∀ q ∈ sourceSeparatedEntrySet,0 < sourceTernarySeparatedZeros t a b q.1 q.2)
    (hmin : IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) (sourceTernarySeparatedZeros t a b)) :
    sourceTernaryFacePartialA t a b=0 ∧ sourceTernaryFacePartialB t a b=0 := by
  constructor
  · apply source_local_min_curve_derivative_zero Matrix.permanent (sourceTransportationPolytope t)
      (sourceTernarySeparatedZeros t a b) (fun s : ℝ => sourceTernarySeparatedZeros t (a+s) b) (sourceTernaryFacePartialA t a b)
    · simpa only [mul_one,mul_zero,add_zero] using source_ternary_separated_curve_continuous t a b 1 0
    · simp only [add_zero]
    · simpa only [mul_one,mul_zero,add_zero] using source_ternary_separated_feasible_near t ht a b 1 0 hpos
    · exact hmin
    · simpa only [Function.comp_def] using source_ternary_face_partialA_actual t ht a b
  · apply source_local_min_curve_derivative_zero Matrix.permanent (sourceTransportationPolytope t)
      (sourceTernarySeparatedZeros t a b) (fun s : ℝ => sourceTernarySeparatedZeros t a (b+s)) (sourceTernaryFacePartialB t a b)
    · simpa only [mul_one,mul_zero,add_zero] using source_ternary_separated_curve_continuous t a b 0 1
    · simp only [add_zero]
    · simpa only [mul_one,mul_zero,add_zero] using source_ternary_separated_feasible_near t ht a b 0 1 hpos
    · exact hmin
    · simpa only [Function.comp_def] using source_ternary_face_partialB_actual t ht a b

theorem source_ternary_separated_minimum_strict_gap (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b : ℝ)
    (hpos : ∀ q ∈ sourceSeparatedEntrySet,0 < sourceTernarySeparatedZeros t a b q.1 q.2)
    (hmin : IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) (sourceTernarySeparatedZeros t a b))
    (hradius : (∑ i,(t i-1)^2) ≤ 3/8) :
    sourceTernaryBaseline t < Matrix.permanent (sourceTernarySeparatedZeros t a b) := by
  obtain ⟨hPa,hPb⟩ := source_ternary_separated_minimum_stationary t ht a b hpos hmin
  let d := t 2-2+a+b
  obtain ⟨heq,hrel⟩ := source_ternary_face_stationary_relations t ht a b d rfl hPa hPb
  have ha : 0 < a := by
    have h := hpos (0,1) (by decide)
    simpa [sourceTernarySeparatedZeros,sourceTernaryOneZero] using h
  have hb : 0 < b := by
    have h := hpos (1,0) (by decide)
    simpa [sourceTernarySeparatedZeros,sourceTernaryOneZero] using h
  have hd : 0 < d := by
    have h := hpos (2,2) (by decide)
    simpa [sourceTernarySeparatedZeros,sourceTernaryOneZero,d] using h
  have hd1 : d < 1 := by
    have h0 := hpos (0,2) (by decide)
    have h1 := hpos (1,2) (by decide)
    norm_num [sourceTernarySeparatedZeros,sourceTernaryOneZero] at h0 h1
    have hs := ht
    simp only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero] at hs
    change t 0+(t 1+t 2)=3 at hs
    dsimp [d]
    linarith
  rw [heq] at hradius ⊢
  exact source_ternary_stationary_chart_strict_gap a b d ha hb hd hd1 hrel hradius

end CoefficientStability
