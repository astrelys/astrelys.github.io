import CoefficientStability.SourceClosedConeOperations
import Mathlib.Data.Fintype.Lattice

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n N : ℕ}

theorem cone_columns_positive_input_interior (p : MvPolynomial (Fin n) ℝ) (hN : 0<N) (hn : 0<n)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (M : Matrix (Fin n) (Fin n) ℝ)
    (hcols : ∀ j,(fun i => M i j)∈closure (positiveSpectralCone p N))
    (hsum : (fun i => ∑ j,M i j)∈positiveSpectralCone p N)
    (y : Fin n → ℝ) (hy : ∀ i,0<y i) : M.mulVec y∈positiveSpectralCone p N := by
  classical
  letI : Nonempty (Fin n) := ⟨⟨0,hn⟩⟩
  obtain ⟨j0,hj0,hmin⟩ := Finset.exists_min_image Finset.univ y Finset.univ_nonempty
  have hrem : (∑ j,(y j-y j0) • (fun i => M i j))∈closure (positiveSpectralCone p N) := by
    apply source_closedCone_finset_sum p hN hp hs hnorm
    intro j hj
    exact source_closedCone_nonneg_smul p hp hs hnorm _ (hcols j) _
      (sub_nonneg.mpr (hmin j (Finset.mem_univ j)))
  have hbase := source_positiveSpectralCone_smul p hp hs hnorm _ hsum (y j0) (hy j0)
  have heq : M.mulVec y=y j0 • (fun i => ∑ j,M i j)+∑ j,(y j-y j0) • (fun i => M i j) := by
    funext i
    simp only [Matrix.mulVec,dotProduct,Pi.add_apply,Pi.smul_apply,smul_eq_mul,Finset.sum_apply]
    rw [Finset.mul_sum,← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro j hj
    ring
  rw [heq]
  exact source_spectralCone_add_closed p hN hp hs hnorm _ _ hbase hrem

theorem matrixSubstitution_complex_eval (M : Matrix (Fin n) (Fin n) ℝ)
    (p : MvPolynomial (Fin n) ℝ) (z : Fin n → ℂ) :
    MvPolynomial.eval₂ Complex.ofRealHom z (matrixSubstitution M p)=
      MvPolynomial.eval₂ Complex.ofRealHom (fun i => ∑ j,(M i j : ℂ)*z j) p := by
  change (MvPolynomial.eval₂Hom Complex.ofRealHom z) (MvPolynomial.eval₂ _ _ p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c;simp
  · funext i
    simp [rowLinearPolynomial]

theorem cone_columns_matrixSubstitution_stable (p : MvPolynomial (Fin n) ℝ) (hN : 0<N) (hn : 0<n)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (M : Matrix (Fin n) (Fin n) ℝ)
    (hcols : ∀ j,(fun i => M i j)∈closure (positiveSpectralCone p N))
    (hsum : (fun i => ∑ j,M i j)∈positiveSpectralCone p N) :
    UpperHalfPlaneZeroFree (matrixSubstitution M p) := by
  intro z hz
  rw [matrixSubstitution_complex_eval]
  apply source_cone_tube_nonzero p hN hp hs hnorm
  have heq : (fun i => (∑ j,(M i j : ℂ)*z j).im)=M.mulVec (fun j => (z j).im) := by
    funext i
    simp [Matrix.mulVec,dotProduct]
  rw [heq]
  exact cone_columns_positive_input_interior p hN hn hp hs hnorm M hcols hsum _ hz

end CoefficientStability
