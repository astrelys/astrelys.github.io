import CoefficientStability.SourceCubicBlockNegativeCase
import CoefficientStability.SourceThreeSwapGeometry
import Mathlib.Analysis.Matrix.Hermitian

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 3500000
set_option backward.isDefEq.respectTransparency false

def sourceThreeLowerBlock (X : Matrix (Fin 3) (Fin 3) ℂ) : Matrix (Fin 2) (Fin 2) ℂ :=
  X.submatrix Fin.succ Fin.succ

def sourceThreeBlockScalar (X : Matrix (Fin 3) (Fin 3) ℂ) : ℝ := (X 0 0).re

def sourceThreeBlockTrace (X : Matrix (Fin 3) (Fin 3) ℂ) : ℝ := (Matrix.trace (sourceThreeLowerBlock X)).re

def sourceThreeBlockCentered (X : Matrix (Fin 3) (Fin 3) ℂ) : Matrix (Fin 2) (Fin 2) ℂ :=
  sourceThreeLowerBlock X-(((sourceThreeBlockTrace X : ℝ) : ℂ)/2) • 1

theorem source_three_lower_block_hermitian (X : Matrix (Fin 3) (Fin 3) ℂ) (hX : X.IsHermitian) :
    (sourceThreeLowerBlock X).IsHermitian := hX.submatrix Fin.succ

theorem source_hermitian_two_trace_real (B : Matrix (Fin 2) (Fin 2) ℂ) (hB : B.IsHermitian) :
    ((Matrix.trace B).re : ℂ)=Matrix.trace B := by
  simp only [Matrix.trace,Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero,Complex.add_re,Complex.ofReal_add]
  change ((B 0 0).re : ℂ)+((B 1 1).re : ℂ)=B 0 0+B 1 1
  have h0 : ((B 0 0).re : ℂ)=B 0 0 := hB.coe_re_apply_self 0
  have h1 : ((B 1 1).re : ℂ)=B 1 1 := hB.coe_re_apply_self 1
  rw [h0,h1]

theorem source_three_block_centered_hermitian (X : Matrix (Fin 3) (Fin 3) ℂ) (hX : X.IsHermitian) :
    (sourceThreeBlockCentered X).IsHermitian := by
  exact (source_three_lower_block_hermitian X hX).sub
    (Matrix.isHermitian_one.smul (by simp [IsSelfAdjoint]))

theorem source_three_block_centered_traceless (X : Matrix (Fin 3) (Fin 3) ℂ) (hX : X.IsHermitian) :
    Matrix.trace (sourceThreeBlockCentered X)=0 := by
  have h := source_hermitian_two_trace_real (sourceThreeLowerBlock X) (source_three_lower_block_hermitian X hX)
  norm_num [sourceThreeBlockCentered,Matrix.trace_sub,Matrix.trace_smul,Matrix.trace_one,sourceThreeBlockTrace,h] <;> ring

theorem source_three_double_diagonal_block (a b : ℝ) (hb : b ≠ 0)
    (X : Matrix (Fin 3) (Fin 3) ℂ) (hX : X.IsHermitian)
    (hc : Matrix.diagonal (fun i : Fin 3 => ((a+b*(if i=0 then 1 else 0) : ℝ) : ℂ))*X=
      X*Matrix.diagonal (fun i : Fin 3 => ((a+b*(if i=0 then 1 else 0) : ℝ) : ℂ))) :
    X=sourceOneTwoBlock (sourceThreeBlockScalar X) (sourceThreeLowerBlock X) := by
  have hzero (i j : Fin 3) (hd : (a+b*(if i=0 then 1 else 0)) ≠ (a+b*(if j=0 then 1 else 0))) : X i j=0 := by
    have h := congrFun (congrFun hc i) j
    simp only [Matrix.diagonal_mul,Matrix.mul_diagonal] at h
    have hn : (((a+b*(if i=0 then 1 else 0) : ℝ) : ℂ)-((a+b*(if j=0 then 1 else 0) : ℝ) : ℂ)) ≠ 0 :=
      sub_ne_zero.mpr (fun he => hd (Complex.ofReal_injective he))
    have hz : (((a+b*(if i=0 then 1 else 0) : ℝ) : ℂ)-((a+b*(if j=0 then 1 else 0) : ℝ) : ℂ))*X i j=0 := by
      linear_combination h
    exact (mul_eq_zero.mp hz).resolve_left hn
  have h01 : X 0 1=0 := hzero 0 1 (by norm_num;exact hb)
  have h02 : X 0 2=0 := hzero 0 2 (by norm_num;exact hb)
  have h10 : X 1 0=0 := hzero 1 0 (by norm_num;exact hb)
  have h20 : X 2 0=0 := hzero 2 0 (by norm_num;exact hb)
  have hd : X 0 0=((X 0 0).re : ℂ) := (hX.coe_re_apply_self 0).symm
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [sourceOneTwoBlock,sourceThreeLowerBlock,sourceThreeBlockScalar,h01,h02,h10,h20]
  exact hd

theorem source_three_double_block_tuple_recovery (a b : ℝ) (hb : b ≠ 0)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : ∀ i,(A i).IsHermitian)
    (hc : ∀ j,Matrix.diagonal (fun i : Fin 3 => ((a+b*(if i=0 then 1 else 0) : ℝ) : ℂ))*A j=
      A j*Matrix.diagonal (fun i : Fin 3 => ((a+b*(if i=0 then 1 else 0) : ℝ) : ℂ))) :
    A=sourceCubicBlockTuple (fun i => sourceThreeBlockScalar (A i)) (fun i => sourceThreeBlockTrace (A i))
      (fun i => sourceThreeBlockCentered (A i)) := by
  funext i
  rw [source_three_double_diagonal_block a b hb (A i) (hA i) (hc i)]
  change sourceOneTwoBlock _ _=sourceOneTwoBlock _ (_+(_-_))
  congr 1
  abel

theorem source_three_block_centered_sum (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hs : (∑ i,A i)=1) : (∑ i,sourceThreeBlockCentered (A i))=0 := by
  have hB : (∑ i,sourceThreeLowerBlock (A i))=1 := by
    ext i j
    have h := congrArg (fun M : Matrix (Fin 3) (Fin 3) ℂ => M i.succ j.succ) hs
    simpa [sourceThreeLowerBlock,Matrix.sum_apply,Matrix.one_apply] using h
  have hb : (∑ i,sourceThreeBlockTrace (A i))=2 := by
    have h := congrArg (fun B : Matrix (Fin 2) (Fin 2) ℂ => (Matrix.trace B).re) hB
    simpa [sourceThreeBlockTrace,Matrix.trace_sum,Complex.re_sum,Matrix.trace_one] using h
  have hbc : (∑ i,((sourceThreeBlockTrace (A i) : ℝ) : ℂ)/2)=1 := by
    rw [← Finset.sum_div,← Complex.ofReal_sum,hb]
    norm_num
  simp only [sourceThreeBlockCentered,Finset.sum_sub_distrib,← Finset.sum_smul,hB,hbc,one_smul,sub_self]

theorem source_cubic_double_diagonal_local_minimum_commutes (t : Fin 3 → ℝ)
    (a b : ℝ) (hb : b ≠ 0) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A)
    (hc : ∀ j,Matrix.diagonal (fun i : Fin 3 => ((a+b*(if i=0 then 1 else 0) : ℝ) : ℂ))*A j=
      A j*Matrix.diagonal (fun i : Fin 3 => ((a+b*(if i=0 then 1 else 0) : ℝ) : ℂ))) :
    ∀ i j,A i*A j=A j*A i := by
  have hr := source_three_double_block_tuple_recovery a b hb A (fun i => (hA.1 i).1) hc
  have hh := source_cubic_block_local_minimum_commutes t (fun i => sourceThreeBlockScalar (A i))
    (fun i => sourceThreeBlockTrace (A i)) (fun i => sourceThreeBlockCentered (A i))
    (fun i => source_three_block_centered_hermitian (A i) (hA.1 i).1)
    (fun i => source_three_block_centered_traceless (A i) (hA.1 i).1)
    (source_three_block_centered_sum A hA.2) (by rw [← hr];exact hA) (by rw [← hr];exact hm)
  simpa only [← hr] using hh

end CoefficientStability
