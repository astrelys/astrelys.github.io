import CoefficientStability.CubicPolarizationBound
import CoefficientStability.CubicRootEstimate
import CoefficientStability.HomogeneousMultilinear

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem paper_central_cubic_tensor (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (N : ℕ) (hN : 3≤N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) :
    ∃ S : MultilinearMap ℝ (fun _ : Fin 3 => Fin n → ℝ) ℝ,
      (∀ x,S (fun _ => x)=6*MvPolynomial.eval x (centralCoefficientPolynomial p t N 3)) ∧
      (∀ v (s : Equiv.Perm (Fin 3)),S (fun j => v (s j))=S v) ∧
      ∀ v,|S v|≤18*Real.sqrt 2*(∏ j,deficitSeminorm (deficitMatrix p t N) (v j)) := by
  obtain ⟨T,hT⟩ := homogeneous_exists_multilinear (centralCoefficientPolynomial p t N 3) 3
    (centralCoefficientPolynomial_homogeneous p t N 3 hN hp)
  let Q := deficitMatrix p t N
  have hQ : Q.PosSemidef := deficitMatrix_posSemidef p t N (by omega) hp hnorm hstable hgrad
  have hsqrt : Real.sqrt 2^3=2*Real.sqrt 2 := by
    rw [show 3=2+1 from rfl,pow_succ,Real.sq_sqrt (by norm_num : (0 : ℝ)≤2)]
  have hdiag : ∀ x,|T (fun _ => x)|≤(2*Real.sqrt 2/3)*deficitSeminorm Q x^3 := by
    intro x
    rw [hT]
    have h := paper_central_cubic_sharp_bound p t N hN hp hnorm hstable hgrad x
    have he : Real.sqrt (2*matrixQuadratic Q x)=Real.sqrt 2*deficitSeminorm Q x :=
      Real.sqrt_mul (by norm_num) _
    change |MvPolynomial.eval x (centralCoefficientPolynomial p t N 3)|≤_ at h
    rw [he,mul_pow,hsqrt] at h
    exact h.trans_eq (by ring)
  refine ⟨(6 : ℝ) • symmetrizedMultilinear T,?_,?_,?_⟩
  · intro x
    simp only [MultilinearMap.smul_apply,smul_eq_mul,symmetrizedMultilinear_diagonal,hT]
  · intro v s
    simp only [MultilinearMap.smul_apply,symmetrizedMultilinear_permutation]
  · intro v
    have h := cubic_polarization_seminorm_bound T Q hQ (2*Real.sqrt 2/3) (by positivity) hdiag v
    simp only [MultilinearMap.smul_apply,smul_eq_mul,abs_mul,abs_of_pos (by norm_num : (0 : ℝ)<6)]
    have hm := mul_le_mul_of_nonneg_left h (by norm_num : (0 : ℝ)≤6)
    exact hm.trans_eq (by ring)

end CoefficientStability
