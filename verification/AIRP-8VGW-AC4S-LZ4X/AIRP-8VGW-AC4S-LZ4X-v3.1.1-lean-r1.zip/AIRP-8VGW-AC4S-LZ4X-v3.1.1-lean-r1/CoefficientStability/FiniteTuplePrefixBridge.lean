import CoefficientStability.PositivePrefixProduct
import CoefficientStability.CumulativeIndicatorInput

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def tupleNatExtension (u : Fin n → ℝ) (i : ℕ) : ℝ := if h : i < n then u ⟨i,h⟩ else 1

theorem finiteInputPrefix_eq_range (u : Fin n → ℝ) (k : ℕ) (hk : k ≤ n) :
    finiteInputPrefix u k=∑ i∈Finset.range k,tupleNatExtension u i := by
  classical
  unfold finiteInputPrefix
  apply Finset.sum_bij (fun i hi => i.val)
  · intro i hi
    exact Finset.mem_range.mpr (Finset.mem_filter.mp hi).2
  · intro i hi j hj heq
    exact Fin.ext heq
  · intro a ha
    have hak := Finset.mem_range.mp ha
    refine ⟨⟨a,lt_of_lt_of_le hak hk⟩,?_,rfl⟩
    simp [hak]
  · intro i hi
    simp [tupleNatExtension,i.isLt]

theorem finiteTuple_product_eq_range (u : Fin n → ℝ) :
    (∏ i,u i)=∏ i∈Finset.range n,tupleNatExtension u i := by
  classical
  apply Finset.prod_bij (fun i hi => i.val)
  · intro i hi
    exact Finset.mem_range.mpr i.isLt
  · intro i hi j hj heq
    exact Fin.ext heq
  · intro a ha
    refine ⟨⟨a,Finset.mem_range.mp ha⟩,Finset.mem_univ _,rfl⟩
  · intro i hi
    simp [tupleNatExtension,i.isLt]

theorem finiteInputPrefix_scalar (u : Fin n → ℝ) (c : ℝ) (k : ℕ) :
    finiteInputPrefix (fun i => c*u i) k=c*finiteInputPrefix u k := by
  unfold finiteInputPrefix
  rw [Finset.mul_sum]

theorem positive_finiteTuple_product_comparison (x r : Fin n → ℝ)
    (hx : ∀ i,0<x i) (hr : ∀ i,0<r i) (hmono : Monotone r)
    (hprefix : ∀ k,k ≤ n → finiteInputPrefix x k≤finiteInputPrefix r k) :
    (∏ i,x i)≤∏ i,r i := by
  have h := positive_product_comparison_of_prefix_sums n (tupleNatExtension x) (tupleNatExtension r)
    (by intro i hi;simpa [tupleNatExtension,hi] using hx ⟨i,hi⟩)
    (by intro i hi;simpa [tupleNatExtension,hi] using hr ⟨i,hi⟩)
    (by
      intro i j hij hj
      have hi : i < n := lt_of_le_of_lt hij hj
      simpa [tupleNatExtension,hi,hj] using hmono (show (⟨i,hi⟩ : Fin n) ≤ ⟨j,hj⟩ from hij))
    (by
      intro k hk
      rw [← finiteInputPrefix_eq_range x k hk,← finiteInputPrefix_eq_range r k hk]
      exact hprefix k hk)
  rwa [← finiteTuple_product_eq_range x,← finiteTuple_product_eq_range r] at h

end CoefficientStability
