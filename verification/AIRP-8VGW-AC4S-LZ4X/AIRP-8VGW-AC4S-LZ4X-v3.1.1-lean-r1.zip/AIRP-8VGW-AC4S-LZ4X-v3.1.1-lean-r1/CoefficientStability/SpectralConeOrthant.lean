import CoefficientStability.OpenSpectralCone

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem nonnegative_input_mem_spectral_closure (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (x : Fin n → ℝ) (hx : ∀ i,0≤x i) : x∈closure (positiveSpectralCone p N) := by
  apply Metric.mem_closure_iff.mpr
  intro ε hε
  let y : Fin n → ℝ := fun i => x i+ε/2
  have hy : ∀ i,0<y i := by intro i;dsimp [y];linarith [hx i]
  refine ⟨y,positive_input_mem_spectral_cone p N hp hs hnorm y hy,?_⟩
  have hnorm : ‖y-x‖≤ε/2 := by
    apply (pi_norm_le_iff_of_nonneg (by linarith : (0 : ℝ)≤ε/2)).mpr
    intro i
    simp only [Pi.sub_apply,y,add_sub_cancel_left,Real.norm_eq_abs]
    exact le_of_eq (abs_of_nonneg (by linarith))
  rw [dist_comm,dist_eq_norm]
  exact hnorm.trans_lt (by linarith)

theorem nonnegative_input_real_factors (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (x : Fin n → ℝ) (hx : ∀ i,0≤x i) :
    ∃ roots : Multiset ℝ,roots.card=N ∧ (∀ r∈roots,0≤r) ∧
      lineRestriction p x=(roots.map (fun r => Polynomial.X+Polynomial.C r)).prod := by
  have hc := normalized_homogeneous_stable_coeff_nonneg p N hp hs hnorm
  have hpos : ∀ t : ℝ,0<t → 0<(lineRestriction p x).eval t := by
    intro t ht
    rw [eval_lineRestriction_real]
    exact nonnegative_coeff_eval_pos p (stable_polynomial_ne_zero p hs) hc _ (fun i => by linarith [hx i])
  obtain ⟨roots,hcard,hr,hlead,hfactor⟩ := positive_split_nonnegative_multiset_factors
    (lineRestriction p x) (lineRestriction_splits p hs x) hpos
  have hm := normalized_lineRestriction_monic p x N hp hnorm
  refine ⟨roots,hcard.trans (normalized_lineRestriction_natDegree p x N hp hnorm),hr,?_⟩
  simpa only [hm.leadingCoeff,Polynomial.C_1,one_mul] using hfactor

end CoefficientStability
