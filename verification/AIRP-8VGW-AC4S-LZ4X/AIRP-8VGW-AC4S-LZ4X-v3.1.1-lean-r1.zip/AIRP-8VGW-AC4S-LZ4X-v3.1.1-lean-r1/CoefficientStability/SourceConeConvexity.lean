import CoefficientStability.SpectralDirectionPositive

noncomputable section
namespace CoefficientStability
variable {n N : ℕ}

theorem source_cone_pair_forward_eval_pos (p : MvPolynomial (Fin n) ℝ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N)
    (y : Fin n → ℝ) (hy : y∈positiveSpectralCone p N) (t : ℝ) (ht : 0≤t) :
    0<MvPolynomial.eval (fun i => y i+t*b i) p := by
  let P := normalizedDirectionalRestriction p b y
  have hpcoef := source_cone_direction_coeff_positive p hN hp hs hnorm b hb y hy
  have hdegree := (normalizedDirectionalRestriction_properties p hN hp hs hnorm b hb y).2.2
  have hc (k : ℕ) : 0≤P.coeff k := by
    by_cases hk : k≤N
    · exact (hpcoef ⟨k,by omega⟩).le
    · rw [Polynomial.coeff_eq_zero_of_natDegree_lt (by change (normalizedDirectionalRestriction p b y).natDegree<k;rw [hdegree];omega)]
  have hpos : 0<P.eval t := lt_of_lt_of_le (hpcoef ⟨0,by omega⟩)
    (univariate_constant_coeff_le_eval P hc t ht)
  rw [normalizedDirectionalRestriction_eval] at hpos
  exact (mul_pos_iff_of_pos_left (inv_pos.mpr (positiveSpectralCone_eval_pos p hp hs hnorm b hb))).mp hpos

theorem source_cone_pair_combination_eval_pos (p : MvPolynomial (Fin n) ℝ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (x : Fin n → ℝ) (hx : x∈positiveSpectralCone p N)
    (y : Fin n → ℝ) (hy : y∈positiveSpectralCone p N)
    (a c : ℝ) (ha : 0≤a) (hc : 0≤c) (hac : 0<a+c) :
    0<MvPolynomial.eval (fun i => a*x i+c*y i) p := by
  by_cases hz : a=0
  · subst a
    have hcpos : 0<c := by simpa using hac
    simpa only [zero_mul,zero_add] using
      (show 0<MvPolynomial.eval (fun i => c*y i) p by
        rw [homogeneous_eval_real_scale p N hp]
        exact mul_pos (pow_pos hcpos _) (positiveSpectralCone_eval_pos p hp hs hnorm y hy))
  · have hapos : 0<a := lt_of_le_of_ne ha (Ne.symm hz)
    have heq : (fun i => a*(x i+(c/a)*y i))=(fun i => a*x i+c*y i) := by
      funext i
      field_simp
      <;> ring
    have h := homogeneous_eval_real_scale p N hp a (fun i => x i+(c/a)*y i)
    rw [heq] at h
    rw [h]
    exact mul_pos (pow_pos hapos _) (source_cone_pair_forward_eval_pos p hN hp hs hnorm y hy x hx
      (c/a) (div_nonneg hc ha))

theorem source_positiveSpectralCone_convex (p : MvPolynomial (Fin n) ℝ) (hN : 0<N)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) : Convex ℝ (positiveSpectralCone p N) := by
  intro x hx y hy a c ha hc hac
  let A := Set.Icc (0 : ℝ) 1
  letI : PreconnectedSpace A := Subtype.preconnectedSpace (isPreconnected_Icc : IsPreconnected (Set.Icc (0 : ℝ) 1))
  let ψ : A → Fin n → ℝ := fun t i => (1-t.val)*x i+t.val*y i
  have hψ : Continuous ψ := by
    apply continuous_pi
    intro i
    convert! ((continuous_const.sub continuous_subtype_val).mul_const (x i)).add
      (continuous_subtype_val.mul_const (y i)) using 1
  let P : A → Polynomial ℝ := fun t => lineRestriction p (ψ t)
  have hm (t : A) : (P t).Monic := normalized_lineRestriction_monic p (ψ t) N hp hnorm
  have hspl (t : A) : (P t).Splits := lineRestriction_splits p hs (ψ t)
  have hd (t : A) : (P t).natDegree=N := normalized_lineRestriction_natDegree p (ψ t) N hp hnorm
  have hcont (k : ℕ) : Continuous (fun t : A => (P t).coeff k) :=
    (lineRestriction_coefficient_continuous p k).comp hψ
  have hzero (t : A) : (P t).coeff 0≠0 := by
    rw [Polynomial.coeff_zero_eq_eval_zero]
    change (lineRestriction p (ψ t)).eval 0≠0
    rw [eval_lineRestriction_real]
    simp only [zero_add]
    apply ne_of_gt
    exact source_cone_pair_combination_eval_pos p hN hp hs hnorm x hx y hy (1-t.val) t.val
      (by linarith [t.property.2]) t.property.1 (by linarith)
  let t0 : A := ⟨0,by constructor <;> norm_num⟩
  have hxcoef : ∀ k : Fin (N+1),0<(lineRestriction p x).coeff k.val := by
    rw [positiveSpectralCone_eq_coefficientPositiveCone p N hp hs hnorm] at hx
    exact hx
  have hstart : ∀ k : Fin (N+1),0<(P t0).coeff k.val := by
    simpa only [P,ψ,t0,sub_zero,one_mul,zero_mul,add_zero] using hxcoef
  have h := connected_real_split_positive_coefficients P hm hspl hd hcont hzero t0 hstart
  rw [positiveSpectralCone_eq_coefficientPositiveCone p N hp hs hnorm]
  have hvec : ψ ⟨c,⟨hc,by linarith⟩⟩=a • x+c • y := by
    funext i
    change (1-c)*x i+c*y i=a*x i+c*y i
    rw [show 1-c=a by linarith]
  change ∀ k : Fin (N+1),0<(lineRestriction p (a • x+c • y)).coeff k.val
  rw [← hvec]
  exact h ⟨c,⟨hc,by linarith⟩⟩

end CoefficientStability
