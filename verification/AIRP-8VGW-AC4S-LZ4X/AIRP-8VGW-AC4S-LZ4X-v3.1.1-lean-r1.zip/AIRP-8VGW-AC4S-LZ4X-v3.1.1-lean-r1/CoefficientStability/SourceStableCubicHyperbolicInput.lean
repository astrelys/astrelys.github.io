import CoefficientStability.SourceStableCubicRepresentedBalls
import CoefficientStability.PositiveDirectionFactors

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

theorem source_stable_cubic_positive_orthant (p : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3) (hs : UpperHalfPlaneZeroFree p) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (v : Fin 3 → ℝ) (hv : ∀ i,0 < v i) : 0 < MvPolynomial.eval v p :=
  nonnegative_coeff_eval_pos p (stable_polynomial_ne_zero p hs)
    (normalized_homogeneous_stable_coeff_nonneg p 3 hp hs hn) v hv

theorem source_stable_cubic_actual_hyperbolicity (p : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3) (hs : UpperHalfPlaneZeroFree p) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (x : Fin 3 → ℝ) :
    (affineDirectionalRestriction p x (fun _ => 1)).natDegree=3 ∧
    (affineDirectionalRestriction p x (fun _ => 1)).coeff 3=1 ∧
    (affineDirectionalRestriction p x (fun _ => 1)).Splits := by
  have hd := positive_direction_degree_and_top p 3 hp x (fun _ => 1) (by intro i;norm_num)
    (by rw [hn];norm_num)
  exact ⟨hd.1,hd.2.trans hn,stable_positive_direction_splits p hs x (fun _ => 1) (by intro i;norm_num)⟩

theorem source_stable_cubic_actual_gradient_total (p : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3) (hn : MvPolynomial.eval (fun _ => 1) p=1) :
    (∑ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p))=3 := homogeneous_gradient_total p 3 hp hn

end CoefficientStability
