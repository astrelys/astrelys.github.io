import CoefficientStability.CubicCoefficientMoments
import CoefficientStability.CentralCubicTensor

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def cubicLinearProduct (A B C : (Fin n → ℝ) →ₗ[ℝ] ℝ) :
    MultilinearMap ℝ (fun _ : Fin 3 => Fin n → ℝ) ℝ :=
  (MultilinearMap.mkPiAlgebra ℝ (Fin 3) ℝ).compLinearMap ![A,B,C]

@[simp] theorem cubicLinearProduct_apply (A B C : (Fin n → ℝ) →ₗ[ℝ] ℝ)
    (v : Fin 3 → Fin n → ℝ) : cubicLinearProduct A B C v=A (v 0)*B (v 1)*C (v 2) := by
  simp [cubicLinearProduct,MultilinearMap.compLinearMap_apply,MultilinearMap.mkPiAlgebra_apply,
    Fin.prod_univ_succ,mul_assoc]

def exponentLinear (g : Fin n →₀ ℕ) : (Fin n → ℝ) →ₗ[ℝ] ℝ :=
  ∑ i,(g i : ℝ) • LinearMap.proj i

@[simp] theorem exponentLinear_apply (g : Fin n →₀ ℕ) (x : Fin n → ℝ) :
    exponentLinear g x=∑ i,(g i : ℝ)*x i := by simp [exponentLinear]

def rawCubicTensor (p : MvPolynomial (Fin n) ℝ) :
    MultilinearMap ℝ (fun _ : Fin 3 => Fin n → ℝ) ℝ :=
  symmetrizedMultilinear (∑ g∈p.support,p.coeff g •
    (cubicLinearProduct (exponentLinear g) (exponentLinear g) (exponentLinear g)-
      (3 : ℝ) • ∑ i,(g i : ℝ) • cubicLinearProduct (LinearMap.proj i) (LinearMap.proj i) (exponentLinear g)+
      (2 : ℝ) • ∑ i,(g i : ℝ) • cubicLinearProduct (LinearMap.proj i) (LinearMap.proj i) (LinearMap.proj i)))

theorem rawCubicTensor_diagonal (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ) :
    rawCubicTensor p (fun _ => x)=
      ∑ g∈p.support,p.coeff g*((∑ i,(g i : ℝ)*x i)^3-
        3*(∑ i,(g i : ℝ)*x i)*(∑ i,(g i : ℝ)*x i^2)+2*(∑ i,(g i : ℝ)*x i^3)) := by
  simp only [rawCubicTensor,symmetrizedMultilinear_diagonal,MultilinearMap.sum_apply,
    MultilinearMap.smul_apply,MultilinearMap.add_apply,MultilinearMap.sub_apply,
    cubicLinearProduct_apply,exponentLinear_apply,LinearMap.proj_apply,smul_eq_mul]
  apply Finset.sum_congr rfl
  intro g hg
  have h2 : (∑ i,(g i : ℝ)*(x i*x i*(∑ i,(g i : ℝ)*x i)))=
      (∑ i,(g i : ℝ)*x i^2)*(∑ i,(g i : ℝ)*x i) := by
    rw [Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro i hi
    ring
  have h3 : (∑ i,(g i : ℝ)*(x i*x i*x i))=(∑ i,(g i : ℝ)*x i^3) := by
    apply Finset.sum_congr rfl
    intro i hi
    ring
  rw [h2,h3]
  ring

def centralProjection (t : Fin n → ℝ) (N : ℕ) : (Fin n → ℝ) →ₗ[ℝ] (Fin n → ℝ) where
  toFun x := fun i => x i-(∑ j,t j*x j)/(N : ℝ)
  map_add' x y := by
    ext i
    simp only [Pi.add_apply,mul_add,Finset.sum_add_distrib]
    ring
  map_smul' c x := by
    ext i
    simp only [Pi.smul_apply,smul_eq_mul,RingHom.id_apply]
    have h : (∑ j,t j*(c*x j))=c*(∑ j,t j*x j) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro j hj
      ring
    rw [h]
    ring

def actualCentralCubicTensor (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) :
    MultilinearMap ℝ (fun _ : Fin 3 => Fin n → ℝ) ℝ :=
  (rawCubicTensor p).compLinearMap (fun _ => centralProjection t N)

theorem actualCentralCubicTensor_diagonal (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (N : ℕ) (hN : 3≤N) (hp : p.IsHomogeneous N) (x : Fin n → ℝ) :
    actualCentralCubicTensor p t N (fun _ => x)=
      6*MvPolynomial.eval x (centralCoefficientPolynomial p t N 3) := by
  rw [actualCentralCubicTensor,MultilinearMap.compLinearMap_apply,rawCubicTensor_diagonal]
  exact (central_cubic_actual_moments p t N hN hp x).symm

theorem actualCentralCubicTensor_permutation (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (N : ℕ) (v : Fin 3 → Fin n → ℝ) (s : Equiv.Perm (Fin 3)) :
    actualCentralCubicTensor p t N (fun j => v (s j))=actualCentralCubicTensor p t N v := by
  exact symmetrizedMultilinear_permutation _ (fun j => centralProjection t N (v j)) s

end CoefficientStability
