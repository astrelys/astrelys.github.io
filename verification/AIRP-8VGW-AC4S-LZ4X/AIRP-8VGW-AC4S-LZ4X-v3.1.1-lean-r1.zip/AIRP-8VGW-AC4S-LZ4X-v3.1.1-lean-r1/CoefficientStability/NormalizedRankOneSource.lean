import CoefficientStability.RankOneCoefficientComparison
import CoefficientStability.RankOneGradientDistance

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem normalizedRankOne_source_properties (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (j : Fin n) (r : ℝ) (hr : r<1)
    (hboundary : (fun i => (if i=j then 1 else 0)-r)∈closure (positiveSpectralCone p n)) :
    (normalizedRankOnePolynomial p n j r).IsHomogeneous n ∧
      UpperHalfPlaneZeroFree (normalizedRankOnePolynomial p n j r) ∧
      MvPolynomial.eval (fun _ => 1) (normalizedRankOnePolynomial p n j r)=1 := by
  have hnonzero : 1-r≠0 := ne_of_gt (by linarith)
  refine ⟨(matrixSubstitution_homogeneous _ p n hp).C_mul _,
    stable_scalar_mul _ (rankOne_source_substitution_stable p hn hn hp hs hnorm j r hr hboundary)
      _ (inv_ne_zero (pow_ne_zero _ hnonzero)),?_⟩
  rw [normalizedRankOnePolynomial,map_mul,MvPolynomial.eval_C,rankOne_source_substitution_at_one p hp hnorm]
  exact inv_mul_cancel₀ (pow_ne_zero n hnonzero)

theorem normalizedRankOne_source_gradient (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (j : Fin n) (r : ℝ) (hr : 1-r≠0) (k : Fin n) :
    MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv k (normalizedRankOnePolynomial p n j r))=
      (MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv k p)-(if k=j then (n : ℝ)*r else 0))/(1-r) := by
  cases n with
  | zero => omega
  | succ N =>
    exact normalizedRankOnePolynomial_gradient p hp
      (fun i => MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p))
      (homogeneous_gradient_total p (N+1) hp hnorm) (fun i => rfl) j k r hr

theorem normalizedRankOne_source_gradient_distance (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (j : Fin n) (r : ℝ) (hr0 : 0≤r) (hrhalf : r≤1/2) :
    (∑ k,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv k (normalizedRankOnePolynomial p n j r))-1|)≤
      2*(∑ k,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv k p)-1|)+4*(n : ℝ)*r := by
  have hnonzero : 1-r≠0 := ne_of_gt (by linarith)
  simp_rw [normalizedRankOne_source_gradient p hn hp hnorm j r hnonzero]
  exact rankOne_normalized_gradient_distance_coarse (by omega)
    (fun k => MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv k p)) j r hr0 hrhalf

end CoefficientStability
