import Mathlib.RingTheory.Polynomial.Vieta
import Mathlib.Algebra.Order.BigOperators.Ring.Finset
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.NormNum

noncomputable section
open scoped BigOperators
open Polynomial
namespace CoefficientStability

theorem esymm_cons (a : ℝ) (s : Multiset ℝ) (k : ℕ) :
    (a ::ₘ s).esymm (k+1) = s.esymm (k+1) + a * s.esymm k := by
  simp [Multiset.esymm, Multiset.powersetCard_cons, Multiset.map_map,
    Multiset.sum_map_mul_left]

theorem esymm_one (s : Multiset ℝ) : s.esymm 1 = s.sum := by
  simp [Multiset.esymm, Multiset.powersetCard_one]

theorem esymm_two_identity (s : Multiset ℝ) :
    2 * s.esymm 2 = s.sum ^ 2 - (s.map (fun x => x^2)).sum := by
  induction s using Multiset.induction_on with
  | empty => simp [Multiset.esymm_of_card_lt (s := (0 : Multiset ℝ)) (n := 2) (by simp)]
  | @cons a s ih =>
    rw [show 2 = 1+1 from rfl, esymm_cons]
    simp only [esymm_one, Multiset.sum_cons, Multiset.map_cons]
    norm_num at *
    nlinarith

variable {n : ℕ}

def rootVariance (mu : Fin n → ℝ) : ℝ := (∑ i, mu i ^ 2) / 2

def centralCoefficient (mu : Fin n → ℝ) (k : ℕ) : ℝ :=
  ∑ s ∈ Finset.univ.powersetCard k, ∏ i ∈ s, mu i

def rootPolynomial (mu : Fin n → ℝ) : ℝ[X] := ∏ i, (X + C (mu i))

theorem centralCoefficient_eq_esymm (mu : Fin n → ℝ) (k : ℕ) :
    centralCoefficient mu k = (Finset.univ.val.map mu).esymm k := by
  rw [Finset.esymm_map_val]
  rfl

theorem centralCoefficient_one (mu : Fin n → ℝ) : centralCoefficient mu 1 = ∑ i, mu i := by
  rw [centralCoefficient_eq_esymm, esymm_one]
  rfl

theorem centralCoefficient_two (mu : Fin n → ℝ) :
    2 * centralCoefficient mu 2 = (∑ i, mu i)^2 - ∑ i, mu i ^ 2 := by
  rw [centralCoefficient_eq_esymm, esymm_two_identity]
  simp [Finset.sum, Function.comp_def]

theorem centralCoefficient_two_centered (mu : Fin n → ℝ) (h : ∑ i, mu i = 0) :
    centralCoefficient mu 2 = -rootVariance mu := by
  have hh := centralCoefficient_two mu
  rw [h] at hh
  unfold rootVariance
  linarith

theorem rootPolynomial_coeff (mu : Fin n → ℝ) (k : ℕ) (hk : k ≤ n) :
    (rootPolynomial mu).coeff (n-k) = centralCoefficient mu k := by
  have h := Finset.prod_X_add_C_coeff (Finset.univ : Finset (Fin n)) mu
    (k := n-k) (by simp)
  have hn : n-(n-k)=k := by omega
  simpa [rootPolynomial, centralCoefficient, hn] using h

theorem rootPolynomial_second_centered (mu : Fin n → ℝ) (hn : 2 ≤ n)
    (h : ∑ i, mu i = 0) : (rootPolynomial mu).coeff (n-2) = -rootVariance mu := by
  rw [rootPolynomial_coeff mu 2 hn, centralCoefficient_two_centered mu h]

theorem rootVariance_nonneg (mu : Fin n → ℝ) : 0 ≤ rootVariance mu := by
  unfold rootVariance
  positivity

theorem root_square_le_two_variance (mu : Fin n → ℝ) (i : Fin n) :
    mu i ^ 2 ≤ 2 * rootVariance mu := by
  have h := Finset.single_le_sum (fun j (_ : j ∈ (Finset.univ : Finset (Fin n))) => sq_nonneg (mu j)) (Finset.mem_univ i)
  unfold rootVariance
  nlinarith [h]

theorem root_abs_le_sqrt (mu : Fin n → ℝ) (i : Fin n) :
    |mu i| ≤ Real.sqrt (2 * rootVariance mu) := by
  apply Real.le_sqrt_of_sq_le
  simpa only [sq_abs] using root_square_le_two_variance mu i

theorem centralCoefficient_abs_bound (mu : Fin n → ℝ) (k : ℕ) :
    |centralCoefficient mu k| ≤ (n.choose k : ℝ) * Real.sqrt (2 * rootVariance mu) ^ k := by
  classical
  unfold centralCoefficient
  calc
    |∑ s ∈ Finset.univ.powersetCard k, ∏ i ∈ s, mu i|
        ≤ ∑ s ∈ Finset.univ.powersetCard k, |∏ i ∈ s, mu i| :=
      Finset.abs_sum_le_sum_abs _ _
    _ = ∑ s ∈ Finset.univ.powersetCard k, ∏ i ∈ s, |mu i| := by simp only [Finset.abs_prod]
    _ ≤ ∑ _s ∈ Finset.univ.powersetCard k, Real.sqrt (2 * rootVariance mu)^k := by
      apply Finset.sum_le_sum
      intro s hs
      have hc := (Finset.mem_powersetCard.mp hs).2
      calc
        ∏ i ∈ s, |mu i| ≤ ∏ _i ∈ s, Real.sqrt (2 * rootVariance mu) :=
          Finset.prod_le_prod₀ (fun _ _ => abs_nonneg _) (fun i _ => root_abs_le_sqrt mu i)
        _ = Real.sqrt (2 * rootVariance mu)^k := by simp [hc]
    _ = (n.choose k : ℝ) * Real.sqrt (2 * rootVariance mu)^k := by
      simp [Finset.card_powersetCard, nsmul_eq_mul]

theorem rootVariance_eq_zero_iff (mu : Fin n → ℝ) :
    rootVariance mu = 0 ↔ ∀ i, mu i = 0 := by
  constructor
  · intro h i
    have hs := root_square_le_two_variance mu i
    rw [h] at hs
    nlinarith [sq_nonneg (mu i)]
  · intro h
    simp [rootVariance, h]

theorem rootPolynomial_eq_X_pow_of_zero_variance (mu : Fin n → ℝ)
    (h : rootVariance mu = 0) : rootPolynomial mu = X ^ n := by
  have hz := (rootVariance_eq_zero_iff mu).mp h
  simp [rootPolynomial, hz]

theorem centered_second_nonpos (mu : Fin n → ℝ) (h : ∑ i, mu i = 0) :
    centralCoefficient mu 2 ≤ 0 := by
  rw [centralCoefficient_two_centered mu h]
  exact neg_nonpos.mpr (rootVariance_nonneg mu)

theorem centralCoefficient_abs_rpow_bound (mu : Fin n → ℝ) (k : ℕ) :
    |centralCoefficient mu k| ≤ (n.choose k : ℝ) *
      (2 * rootVariance mu) ^ ((k : ℝ) / 2) := by
  have h0 : 0 ≤ 2 * rootVariance mu := mul_nonneg (by norm_num) (rootVariance_nonneg mu)
  have he : Real.sqrt (2 * rootVariance mu)^k =
      (2 * rootVariance mu) ^ ((k : ℝ) / 2) := by
    rw [Real.sqrt_eq_rpow, ← Real.rpow_natCast, ← Real.rpow_mul h0]
    congr 1
    ring
  simpa only [he] using centralCoefficient_abs_bound mu k

end CoefficientStability
