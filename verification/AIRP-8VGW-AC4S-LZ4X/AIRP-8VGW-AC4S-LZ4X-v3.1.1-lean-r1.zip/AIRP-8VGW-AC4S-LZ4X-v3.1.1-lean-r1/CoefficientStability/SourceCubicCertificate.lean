import CoefficientStability.SourcePermanentClosure

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1200000

def sourceCubicH (d h : ℝ) := 1-10*d-12*d^2+(2+30*d-12*d^2)*h-4*(2-d)*h^2
def sourceCubicS (d h : ℝ) := h^2-4*d*h+3*d^2+d
def sourceCubicHd (d h : ℝ) := -10-24*d+(30-24*d)*h+4*h^2
def sourceCubicHh (d h : ℝ) := 2+30*d-12*d^2-8*(2-d)*h
def sourceCubicN (d h : ℝ) := (3-2*d)*((-4*h+6*d+1)*sourceCubicHh d h-(2*h-4*d)*sourceCubicHd d h)-4*sourceCubicS d h*sourceCubicHh d h
def sourceCubicW (d h : ℝ) := 4*sourceCubicS d h*(sourceCubicHd d h)^2-(sourceCubicN d h)^2

def sourceCubicA (d : ℝ) := (1570) * d^0 + (-13777) * d^1 + (68559) * d^2 + (-290171) * d^3 + (821303) * d^4 + (-1536384) * d^5 + (1879620) * d^6 + (-1471392) * d^7 + (704448) * d^8 + (-186624) * d^9 + (20736) * d^10
def sourceCubicB (d : ℝ) := (-34) * d^0 + (-1771) * d^1 + (29751) * d^2 + (-110731) * d^3 + (225671) * d^4 + (-286998) * d^5 + (230640) * d^6 + (-112896) * d^7 + (30528) * d^8 + (-3456) * d^9

theorem source_cubic_certificate_identity (d h : ℝ) (hH : sourceCubicH d h=0) :
    (2-d)^3*sourceCubicW d h=4*d*(sourceCubicA d+2*h*sourceCubicB d) := by
  unfold sourceCubicW sourceCubicN sourceCubicS sourceCubicHd sourceCubicHh sourceCubicA sourceCubicB
  unfold sourceCubicH at hH
  linear_combination ((64) * d^4 * h^4 + (-576) * d^3 * h^4 + (1920) * d^2 * h^4 + (-2816) * d^1 * h^4 + (1536) * h^4 + (-704) * d^5 * h^3 + (6304) * d^4 * h^3 + (-20896) * d^3 * h^3 + (30400) * d^2 * h^3 + (-16256) * d^1 * h^3 + (-256) * h^3 + (3328) * d^6 * h^2 + (-29248) * d^5 * h^2 + (95584) * d^4 * h^2 + (-137856) * d^3 * h^2 + (73088) * d^2 * h^2 + (4096) * d^1 * h^2 + (-4096) * h^2 + (-8448) * d^7 * h^1 + (71808) * d^6 * h^1 + (-229792) * d^5 * h^1 + (334240) * d^4 * h^1 + (-199344) * d^3 * h^1 + (19664) * d^2 * h^1 + (2752) * d^1 * h^1 + (1728) * h^1 + (11520) * d^8 + (-92160) * d^7 + (282944) * d^6 + (-413920) * d^5 + (284428) * d^4 + (-78496) * d^3 + (14396) * d^2 + (-4952) * d^1 + (-288)) * hH

def sourceCubicBeta0 : Fin 11 → ℝ := ![1587,69131/60,44833/54,26551/45,3510302/8505,3888835/13608,20377997/102060,1425187/9720,3935542/32805,138394/1215,10000/81]
def sourceCubicBeta1 : Fin 11 → ℝ := ![1536,15266/15,100198/135,316271/540,4133324/8505,26000/63,1280093/3645,1430671/4860,7829188/32805,221212/1215,10000/81]

def sourceCubicBernsteinBasis (d : ℝ) (k : Fin 11) : ℝ :=
  (Nat.choose 10 k.val : ℝ)*(3*d)^k.val*(1-3*d)^(10-k.val)

theorem source_cubic_beta0_positive (k : Fin 11) : 100 ≤ sourceCubicBeta0 k := by
  fin_cases k <;> norm_num [sourceCubicBeta0]

theorem source_cubic_beta1_positive (k : Fin 11) : 100 ≤ sourceCubicBeta1 k := by
  fin_cases k <;> norm_num [sourceCubicBeta1]

theorem source_cubic_bernstein_partition (d : ℝ) : (∑ k : Fin 11,sourceCubicBernsteinBasis d k)=1 := by
  norm_num [sourceCubicBernsteinBasis,Fin.sum_univ_succ,Nat.choose]
  ring

theorem source_cubic_bernstein_nonnegative (d : ℝ) (hd : 0 ≤ d) (hd3 : d ≤ 1/3) (k : Fin 11) :
    0 ≤ sourceCubicBernsteinBasis d k := by
  unfold sourceCubicBernsteinBasis
  have hbase : 0 ≤ 1-3*d := by linarith
  positivity

theorem source_cubic_bernstein_endpoint0 (d : ℝ) :
    sourceCubicA d+(9*d-1)*sourceCubicB d/2=∑ k : Fin 11,sourceCubicBeta0 k*sourceCubicBernsteinBasis d k := by
  norm_num [sourceCubicA,sourceCubicB,sourceCubicBeta0,sourceCubicBernsteinBasis,Fin.sum_univ_succ,Nat.choose]
  ring

theorem source_cubic_bernstein_endpoint1 (d : ℝ) :
    sourceCubicA d+sourceCubicB d=∑ k : Fin 11,sourceCubicBeta1 k*sourceCubicBernsteinBasis d k := by
  norm_num [sourceCubicA,sourceCubicB,sourceCubicBeta1,sourceCubicBernsteinBasis,Fin.sum_univ_succ,Nat.choose]
  ring

theorem source_cubic_certificate_endpoints_positive (d : ℝ) (hd : 0 ≤ d) (hd3 : d ≤ 1/3) :
    0 < sourceCubicA d+(9*d-1)*sourceCubicB d/2 ∧ 0 < sourceCubicA d+sourceCubicB d := by
  have h0 := Finset.sum_le_sum (fun (k : Fin 11) (_ : k ∈ Finset.univ) =>
    mul_le_mul_of_nonneg_right (source_cubic_beta0_positive k) (source_cubic_bernstein_nonnegative d hd hd3 k))
  have h1 := Finset.sum_le_sum (fun (k : Fin 11) (_ : k ∈ Finset.univ) =>
    mul_le_mul_of_nonneg_right (source_cubic_beta1_positive k) (source_cubic_bernstein_nonnegative d hd hd3 k))
  rw [← Finset.mul_sum,source_cubic_bernstein_partition,mul_one,← source_cubic_bernstein_endpoint0] at h0
  rw [← Finset.mul_sum,source_cubic_bernstein_partition,mul_one,← source_cubic_bernstein_endpoint1] at h1
  constructor <;> linarith

theorem source_cubic_certificate_affine_positive (d h : ℝ) (hd : 0 ≤ d) (hd3 : d ≤ 1/3)
    (hl : (9*d-1)/4 ≤ h) (hu : h ≤ 1/2) : 0 < sourceCubicA d+2*h*sourceCubicB d := by
  obtain ⟨h0,h1⟩ := source_cubic_certificate_endpoints_positive d hd hd3
  by_cases hb : 0 ≤ sourceCubicB d
  · nlinarith
  · nlinarith

theorem source_cubic_certificate_W_positive (d h : ℝ) (hd : 0 < d) (hd3 : d < 1/3)
    (hl : (9*d-1)/4 ≤ h) (hu : h ≤ 1/2) (hH : sourceCubicH d h=0) : 0 < sourceCubicW d h := by
  have ha := source_cubic_certificate_affine_positive d h hd.le hd3.le hl hu
  have hp : 0 < (2-d)^3*sourceCubicW d h := by
    rw [source_cubic_certificate_identity d h hH]
    positivity
  have hb : 0 ≤ (2-d)^3 := by
    have : 0 < 2-d := by linarith
    positivity
  by_contra hh
  have hm := mul_nonpos_of_nonneg_of_nonpos hb (le_of_not_gt hh)
  linarith

end CoefficientStability
