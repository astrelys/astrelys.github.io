import CoefficientStability.SourceUnbalancedGapCriterion
import Mathlib.Algebra.Order.Chebyshev

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem source_euclidean_squared_short_field (hn : 3 ≤ n) (r : ℝ)
    (hr : r^2 ≤ 1/(10000000000000000*(n : ℝ)^15)) :
    (r/sourceNoiseStrength n)^2 ≤ 1/(64*(n : ℝ)*(100000000*(n : ℝ)^8)) := by
  have hn0 : (0 : ℝ)<n := by exact_mod_cast (show 0<n by omega)
  have hm := sourceNoiseStrength_pos n hn
  have hm2 := pow_le_pow_left₀ (by positivity : (0 : ℝ) ≤ 1/(1024*(n : ℝ)^3)) (sourceNoiseStrength_lower n hn) 2
  have he : (1/(1024*(n : ℝ)^3))^2=1/(1048576*(n : ℝ)^6) := by field_simp;ring
  rw [he] at hm2
  have hscale : (64*(n : ℝ)*(100000000*(n : ℝ)^8))/(10000000000000000*(n : ℝ)^15) ≤ 1/(1048576*(n : ℝ)^6) := by
    apply (div_le_div_iff₀ (by positivity) (by positivity)).mpr
    nlinarith [pow_pos hn0 15]
  have hmul := mul_le_mul_of_nonneg_left hr (by positivity : 0 ≤ 64*(n : ℝ)*(100000000*(n : ℝ)^8))
  have hh : (64*(n : ℝ)*(100000000*(n : ℝ)^8))*r^2 ≤ (sourceNoiseStrength n)^2 := by
    apply hmul.trans
    simpa only [mul_one_div] using hscale.trans hm2
  rw [div_pow]
  apply (div_le_iff₀ (sq_pos_of_pos hm)).mpr
  rw [one_div_mul_eq_div]
  apply (le_div_iff₀ (by positivity : 0 < 64*(n : ℝ)*(100000000*(n : ℝ)^8))).mpr
  simpa only [mul_comm] using hh

theorem source_squared_condition_short (hn : 3 ≤ n) (r : ℝ) (hr0 : 0 ≤ r)
    (hsq : (r/sourceNoiseStrength n)^2 ≤ 1/(64*(n : ℝ)*(100000000*(n : ℝ)^8))) :
    r < sourceNoiseStrength n ∧ (n : ℝ)*(r/sourceNoiseStrength n) ≤ 1/24 := by
  have hn1 : (1 : ℝ) ≤ n := by exact_mod_cast (show 1 ≤ n by omega)
  have hn0 : (0 : ℝ)<n := by linarith
  have hm := sourceNoiseStrength_pos n hn
  have hx : 0 ≤ r/sourceNoiseStrength n := div_nonneg hr0 hm.le
  have hpow : (n : ℝ)^2 ≤ (n : ℝ)^9 := pow_le_pow_right₀ hn1 (by norm_num : 2 ≤ 9)
  have hmul := (le_div_iff₀ (by positivity : 0 < 64*(n : ℝ)*(100000000*(n : ℝ)^8))).mp hsq
  have hcoef : 576*(n : ℝ)^2 ≤ 64*(n : ℝ)*(100000000*(n : ℝ)^8) := by nlinarith
  have hh := mul_le_mul_of_nonneg_right hcoef (sq_nonneg (r/sourceNoiseStrength n))
  have hshort : (n : ℝ)*(r/sourceNoiseStrength n) ≤ 1/24 := by
    nlinarith [mul_nonneg hn0.le hx]
  have hxlt : r/sourceNoiseStrength n < 1 := by
    have hnx := mul_le_mul_of_nonneg_right hn1 hx
    nlinarith
  exact ⟨(div_lt_one hm).mp hxlt,hshort⟩

theorem finite_l1_l2_square (v : Fin n → ℝ) :
    (∑ i,|v i|)^2 ≤ (n : ℝ)*(∑ i,v i^2) := by
  have h := sq_sum_le_card_mul_sum_sq (s := Finset.univ) (f := fun i => |v i|)
  simpa only [sq_abs,Finset.card_univ,Fintype.card_fin] using h

end CoefficientStability
