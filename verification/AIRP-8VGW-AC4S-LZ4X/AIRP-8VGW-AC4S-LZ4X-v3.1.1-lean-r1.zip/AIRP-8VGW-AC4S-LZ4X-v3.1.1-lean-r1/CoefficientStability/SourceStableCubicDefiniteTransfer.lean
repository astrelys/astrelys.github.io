import CoefficientStability.SourceStableCubicDefiniteNormalization

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceStableCubicDefiniteRepresentation (p : MvPolynomial (Fin 3) ℝ) : Prop :=
  ∃ A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ,(∀ i,(A i).IsHermitian) ∧ (∑ i,A i).PosDef ∧
    p=(MvPolynomial.eval (fun _ => 1) (realDeterminantPolynomial A))⁻¹ • realDeterminantPolynomial A

theorem source_stable_cubic_definite_payload_feasible (p : MvPolynomial (Fin 3) ℝ)
    (t : Fin 3 → ℝ) (hs : UpperHalfPlaneZeroFree p)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hrep : sourceStableCubicDefiniteRepresentation p) :
    ∃ B ∈ hermitianFeasibleTuples t,p=realDeterminantPolynomial B := by
  obtain ⟨A,hA,hM,he⟩ := hrep
  exact source_stable_cubic_definite_representation_feasible p t hs hg A hA hM he

theorem source_stable_cubic_prescribed_gradient_total (p : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3) (hn : MvPolynomial.eval (fun _ => 1) p=1) (t : Fin 3 → ℝ)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) : (∑ i,t i)=3 := by
  simpa only [hg] using source_stable_cubic_actual_gradient_total p hp hn

theorem source_stable_cubic_definite_euclidean_transfer (p : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3) (hs : UpperHalfPlaneZeroFree p) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (t : Fin 3 → ℝ) (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hrep : sourceStableCubicDefiniteRepresentation p) (hr : (∑ i,(t i-1)^2) ≤ 3/8) :
    sourceTernaryBaseline t ≤ p.coeff (squarefreeExponent 3) ∧
      (p.coeff (squarefreeExponent 3)=sourceTernaryBaseline t ↔ sourceStableCubicEuclideanEquality t p) ∧
      ((∑ i,(t i-1)^2) < 3/8 → (p.coeff (squarefreeExponent 3)=sourceTernaryBaseline t ↔ p=scalarPower t 3)) := by
  have ht := source_stable_cubic_prescribed_gradient_total p hp hn t hg
  obtain ⟨A,hA,he⟩ := source_stable_cubic_definite_payload_feasible p t hs hg hrep
  rw [he]
  exact ⟨source_stable_cubic_represented_euclidean_bound t ht hr A hA,
    source_stable_cubic_represented_euclidean_equality t ht hr A hA,
    fun hstrict => source_stable_cubic_represented_euclidean_open_unique t ht hstrict A hA⟩

theorem source_stable_cubic_definite_l1_transfer (p : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3) (hs : UpperHalfPlaneZeroFree p) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (t : Fin 3 → ℝ) (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hrep : sourceStableCubicDefiniteRepresentation p) (hr : (∑ i,|t i-1|) ≤ sourceCubicEpsilon0) :
    sourceTernaryBaseline t ≤ p.coeff (squarefreeExponent 3) ∧
      (p.coeff (squarefreeExponent 3)=sourceTernaryBaseline t ↔ sourceStableCubicL1Equality t p) ∧
      ((∑ i,|t i-1|) < sourceCubicEpsilon0 → (p.coeff (squarefreeExponent 3)=sourceTernaryBaseline t ↔ p=scalarPower t 3)) := by
  have ht := source_stable_cubic_prescribed_gradient_total p hp hn t hg
  obtain ⟨A,hA,he⟩ := source_stable_cubic_definite_payload_feasible p t hs hg hrep
  rw [he]
  exact ⟨source_stable_cubic_represented_l1_bound t ht hr A hA,
    source_stable_cubic_represented_l1_equality t ht hr A hA,
    fun hstrict => source_stable_cubic_represented_l1_open_unique t ht hstrict A hA⟩

end CoefficientStability
