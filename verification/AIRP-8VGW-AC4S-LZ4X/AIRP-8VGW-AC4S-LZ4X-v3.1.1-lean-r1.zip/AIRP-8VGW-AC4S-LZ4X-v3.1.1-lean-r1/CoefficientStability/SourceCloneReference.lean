import CoefficientStability.SourceCloneCoefficient

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {m N : ℕ}

theorem rectangularSubstitution_scalarLinear (B : Matrix (Fin m) (Fin N) ℝ) (t : Fin m → ℝ) (d : ℕ) :
    rectangularSubstitution B (scalarLinear t d)=scalarLinear (rectangularSourceGradient B t) d := by
  apply MvPolynomial.funext
  intro x
  rw [rectangularSubstitution_eval]
  simp only [scalarLinear,map_sum,map_mul,MvPolynomial.eval_C,MvPolynomial.eval_X,
    Matrix.mulVec,dotProduct,rectangularSourceGradient,Finset.mul_sum,Finset.sum_mul,Finset.sum_div]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j hj
  apply Finset.sum_congr rfl
  intro i hi
  ring

theorem sourceClonePolynomial_scalarPower (α : Fin m → ℕ) (t : Fin m → ℝ) :
    sourceClonePolynomial α (scalarPower t (sourceCloneCount α))=
      scalarPower (sourceClonedGradient α t) (sourceCloneCount α) := by
  rw [sourceClonePolynomial,scalarPower,map_pow,rectangularSubstitution_scalarLinear]
  have he : rectangularSourceGradient (sourceCloneAveragingMatrix α) t=sourceClonedGradient α t :=
    funext (sourceCloneAveragingMatrix_gradient_column α t)
  rw [he]
  rfl

theorem sourceClonedGradient_product (α : Fin m → ℕ) (t : Fin m → ℝ) :
    (∏ j,sourceClonedGradient α t j)=∏ i,(t i/(α i : ℝ))^(α i) := by
  rw [← Equiv.prod_comp (sourceCloneEquiv α) (sourceClonedGradient α t)]
  simp only [Fintype.prod_sigma,sourceClonedGradient,sourceCloneBlock_equiv,
    Finset.prod_const,Finset.card_univ,Fintype.card_fin]

theorem sourceCloneReference_coefficient_identity (α : Fin m → ℕ) (t : Fin m → ℝ) :
    sourceCloneCoefficientWeight α*(scalarPower t (sourceCloneCount α)).coeff (sourceMultiExponent α)=
      sourceVn (sourceCloneCount α)*(∏ j,sourceClonedGradient α t j) := by
  have h := sourceClonePolynomial_squarefree_coefficient α (scalarPower t (sourceCloneCount α))
  rw [sourceClonePolynomial_scalarPower,scalarPower_squarefree_coefficient] at h
  exact h.symm

theorem sourceMultiExponent_sum (α : Fin m → ℕ) :
    (sourceMultiExponent α).sum (fun _ k => k)=sourceCloneCount α := by
  rw [Finsupp.sum_fintype]
  · simp only [sourceMultiExponent_apply,sourceCloneCount]
  · intro i
    rfl

theorem sourceMultiExponent_multinomial_real (α : Fin m → ℕ) :
    ((sourceMultiExponent α).multinomial : ℝ)=
      ((sourceCloneCount α).factorial : ℝ)/(∏ i,((α i).factorial : ℝ)) := by
  classical
  have hm : (sourceMultiExponent α).multinomial=Nat.multinomial Finset.univ α := by
    rw [Finsupp.multinomial_eq_of_support_subset (Finset.subset_univ _)]
    exact congrArg (Nat.multinomial (Finset.univ : Finset (Fin m)))
      (show (fun i => sourceMultiExponent α i)=α from funext (sourceMultiExponent_apply α))
  have hnat : (∏ i,(α i).factorial)*(sourceMultiExponent α).multinomial=(sourceCloneCount α).factorial := by
    rw [hm]
    exact Nat.multinomial_spec Finset.univ α
  have hreal : (∏ i,((α i).factorial : ℝ))*((sourceMultiExponent α).multinomial : ℝ)=((sourceCloneCount α).factorial : ℝ) := by
    exact_mod_cast hnat
  have hpos : 0 < ∏ i,((α i).factorial : ℝ) := Finset.prod_pos (fun i hi => by exact_mod_cast Nat.factorial_pos (α i))
  apply (eq_div_iff (ne_of_gt hpos)).mpr
  simpa only [mul_comm] using hreal

theorem sourceScalarPower_multiindex_baseline (α : Fin m → ℕ) (t : Fin m → ℝ) :
    (scalarPower t (sourceCloneCount α)).coeff (sourceMultiExponent α)=
      ((sourceCloneCount α).factorial : ℝ)/(∏ i,((α i).factorial : ℝ))*
        (∏ i,(t i/(sourceCloneCount α : ℝ))^(α i)) := by
  rw [scalarPower_multinomial_coefficient,if_pos (sourceMultiExponent_sum α),sourceMultiExponent_multinomial_real]
  congr 1
  rw [Finsupp.prod_fintype]
  · simp only [sourceMultiExponent_apply]
  · intro i
    exact pow_zero _

end CoefficientStability
