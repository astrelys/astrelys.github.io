import CoefficientStability.NormalizedSourceSubset

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem actual_source_root_tuple_shift (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (x : Fin n → ℝ) (roots : Fin N → ℝ)
    (hf : lineRestriction p x=∏ i : Fin N,(Polynomial.X+Polynomial.C (roots i))) (s : ℝ) :
    lineRestriction p (fun i => x i+s)=∏ i : Fin N,(Polynomial.X+Polynomial.C (roots i+s)) := by
  apply Polynomial.funext
  intro t
  have heq : (lineRestriction p (fun i => x i+s)).eval t=(lineRestriction p x).eval (t+s) := by
    rw [eval_lineRestriction_real,eval_lineRestriction_real]
    apply congrArg (fun z : Fin n → ℝ => MvPolynomial.eval z p)
    funext i
    ring
  rw [heq,hf,Polynomial.eval_prod,Polynomial.eval_prod]
  simp only [Polynomial.eval_add,Polynomial.eval_X,Polynomial.eval_C]
  apply Finset.prod_congr rfl
  intro i hi
  ring

theorem normalizedSourceSubsetPolynomial_line_factors (p : MvPolynomial (Fin n) ℝ) (N k : ℕ)
    (x : Fin n → ℝ) (roots : Fin N → ℝ)
    (hf : lineRestriction p x=∏ i : Fin N,(Polynomial.X+Polynomial.C (roots i))) (hk : 0<k) :
    lineRestriction (normalizedSourceSubsetPolynomial p N k) x=
      ∏ s∈Finset.univ.powersetCard k,(Polynomial.X+Polynomial.C ((∑ i∈s,roots i)/(k : ℝ))) := by
  classical
  have hkreal : (k : ℝ)≠0 := by exact_mod_cast Nat.ne_zero_of_lt hk
  apply Polynomial.funext
  intro t
  rw [eval_lineRestriction_real]
  simp only [normalizedSourceSubsetPolynomial,map_mul,MvPolynomial.eval_C]
  have heq : (fun i => t+x i)=(fun i => x i+t) := by funext i;ring
  rw [heq,sourceSubsetRootSumPolynomial_real_eval_of_factors p N k (fun i => x i+t)
    (fun i => roots i+t) (actual_source_root_tuple_shift p N x roots hf t),Polynomial.eval_prod]
  simp only [Polynomial.eval_add,Polynomial.eval_X,Polynomial.eval_C]
  have hsum (s : Finset (Fin N)) (hs : s∈Finset.univ.powersetCard k) :
      (∑ i∈s,(roots i+t))=(∑ i∈s,roots i)+(k : ℝ)*t := by
    have hcard : s.card=k := by simpa only [Finset.mem_powersetCard_univ] using hs
    simp only [Finset.sum_add_distrib,Finset.sum_const,nsmul_eq_mul,hcard]
  rw [Finset.prod_congr rfl hsum]
  have hscalar : ((k : ℝ)^(N.choose k))⁻¹=(∏ _s∈(Finset.univ : Finset (Fin N)).powersetCard k,(k : ℝ)⁻¹) := by
    simp [inv_pow]
  rw [hscalar,← Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro s hs
  field_simp
  <;> ring

end CoefficientStability
