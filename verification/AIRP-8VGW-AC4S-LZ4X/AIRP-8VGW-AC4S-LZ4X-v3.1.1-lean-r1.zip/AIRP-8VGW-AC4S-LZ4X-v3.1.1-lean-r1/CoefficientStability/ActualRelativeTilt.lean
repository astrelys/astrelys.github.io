import CoefficientStability.ActualTiltRelativeDerivative
import CoefficientStability.RelativeGronwall

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem tiltedPolynomial_zero (p : MvPolynomial (Fin n) ℝ)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) : tiltedPolynomial p 0=p := by
  have hZ : tiltPartition p 0=1 := by
    simpa only [tiltPartition,tiltWeight,tiltExponent,Pi.zero_apply,mul_zero,Finset.sum_const_zero,
      Real.exp_zero,mul_one] using normalized_coefficient_mass p hnorm
  ext g
  rw [tiltedPolynomial_coeff,hZ]
  simp [tiltWeight,tiltExponent]

theorem tiltedMoment_zero (p : MvPolynomial (Fin n) ℝ)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (i : Fin n) :
    tiltedMoment p 0 i=MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p) := by
  have hZ : tiltPartition p 0=1 := by
    simpa only [tiltPartition,tiltWeight,tiltExponent,Pi.zero_apply,mul_zero,Finset.sum_const_zero,
      Real.exp_zero,mul_one] using normalized_coefficient_mass p hnorm
  rw [tiltedMoment_actual_gradient p 0 (by rw [hZ];norm_num),tiltedPolynomial_zero p hnorm]

theorem actualTiltDeficit_zero (p : MvPolynomial (Fin n) ℝ)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) :
    actualTiltDeficit p 0=referenceDeficit p
      (fun i => MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)) n := by
  unfold actualTiltDeficit
  rw [tiltedPolynomial_zero p hnorm]
  congr 1
  funext i
  exact tiltedMoment_zero p hnorm i

theorem paper_actual_relative_tilt_endpoints (p : MvPolynomial (Fin n) ℝ)
    (u v : Fin n → ℝ) (hn : 3≤n) (hp : p.IsHomogeneous n) (hcoeff : ∀ g,0≤p.coeff g)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p) :
    Real.exp (-(12*(n : ℝ)*‖v‖))*actualTiltDeficit p u≤actualTiltDeficit p (u+v) ∧
    actualTiltDeficit p (u+v)≤Real.exp (12*(n : ℝ)*‖v‖)*actualTiltDeficit p u := by
  have hf (s : ℝ) : 0≤actualTiltDeficit p (u+s • v) :=
    (actual_tilt_deficit_source_bounds p (u+s • v) (by omega) hp hcoeff hnorm hstable).2.2.1
  have hd (s : ℝ) := actual_tilt_deficit_hasDerivAt p u v s (by omega) hp hcoeff hnorm
  have hb (s : ℝ) := paper_actual_tilt_deficit_derivative_bound p (u+s • v) v hn hp hcoeff hnorm hstable
  have h := nonnegative_relative_gronwall_endpoints (fun s => actualTiltDeficit p (u+s • v))
    (fun s => ∑ i,actualTiltDiagonalDerivative p (u+s • v) v i) (12*(n : ℝ)*‖v‖) hf hd hb
  simpa only [zero_smul,add_zero,one_smul] using h

theorem paper_relative_tilt_from_original (p : MvPolynomial (Fin n) ℝ)
    (v : Fin n → ℝ) (hn : 3≤n) (hp : p.IsHomogeneous n) (hcoeff : ∀ g,0≤p.coeff g)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p) :
    let δ := referenceDeficit p (fun i => MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)) n
    Real.exp (-(12*(n : ℝ)*‖v‖))*δ≤actualTiltDeficit p v ∧
    actualTiltDeficit p v≤Real.exp (12*(n : ℝ)*‖v‖)*δ := by
  simpa only [zero_add,actualTiltDeficit_zero p hnorm] using
    paper_actual_relative_tilt_endpoints p 0 v hn hp hcoeff hnorm hstable

theorem paper_relative_tilt_distortion (p : MvPolynomial (Fin n) ℝ)
    (v : Fin n → ℝ) (hn : 3≤n) (hp : p.IsHomogeneous n) (hcoeff : ∀ g,0≤p.coeff g)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p) :
    (∀ s : ℝ,|deriv (fun z : ℝ => actualTiltDeficit p (z • v)) s|≤
      12*(n : ℝ)*‖v‖*actualTiltDeficit p (s • v)) ∧
    (∀ (s : ℝ) (i : Fin n),|deriv (fun z : ℝ => deficitMatrix (tiltedPolynomial p (z • v))
      (tiltedMoment p (z • v)) n i i) s|≤12*(n : ℝ)*‖v‖*actualTiltDeficit p (s • v)) ∧
    (Real.exp (-(12*(n : ℝ)*‖v‖))*actualTiltDeficit p 0≤actualTiltDeficit p v ∧
      actualTiltDeficit p v≤Real.exp (12*(n : ℝ)*‖v‖)*actualTiltDeficit p 0) := by
  refine ⟨?_,?_,?_⟩
  · intro s
    have hd := actual_tilt_deficit_hasDerivAt p 0 v s (by omega) hp hcoeff hnorm
    simp only [zero_add] at hd
    rw [hd.deriv]
    exact paper_actual_tilt_deficit_derivative_bound p (s • v) v hn hp hcoeff hnorm hstable
  · intro s i
    have hd := actual_tilt_diagonal_hasDerivAt p 0 v s (by omega) hp hcoeff hnorm i
    simp only [zero_add] at hd
    rw [hd.deriv]
    exact paper_actual_tilt_diagonal_derivative_bound p (s • v) v hn hp hcoeff hnorm hstable i
  · simpa only [zero_add] using paper_actual_relative_tilt_endpoints p 0 v hn hp hcoeff hnorm hstable

end CoefficientStability
