import CoefficientStability.IndicatorSpectralMass
import Mathlib.Data.Fin.Tuple.Sort

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n N : ℕ}

theorem actual_source_positive_input_root_pos (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (x : Fin n → ℝ) (hx : ∀ i,0<x i)
    (roots : Fin N → ℝ) (hf : lineRestriction p x=∏ i : Fin N,(Polynomial.X+Polynomial.C (roots i))) :
    ∀ i,0<roots i := by
  classical
  have hxcone := positive_input_mem_spectral_cone p N hp hs hnorm x hx
  intro i
  by_contra hbad
  have hnonpos : roots i≤0 := le_of_not_gt hbad
  have hpositive := source_cone_forward_eval_pos p x hxcone (-roots i) (neg_nonneg.mpr hnonpos)
  have hzero : (lineRestriction p x).eval (-roots i)=0 := by
    rw [hf,Polynomial.eval_prod]
    apply Finset.prod_eq_zero (Finset.mem_univ i)
    simp
  rw [eval_lineRestriction_real] at hzero
  rw [hzero] at hpositive
  exact (lt_irrefl 0) hpositive

theorem actual_source_ordered_root_tuple (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (x : Fin n → ℝ) :
    ∃ roots : Fin N → ℝ,Monotone roots ∧
      lineRestriction p x=∏ i : Fin N,(Polynomial.X+Polynomial.C (roots i)) := by
  classical
  obtain ⟨r,hf⟩ := actual_source_real_root_tuple p N hp hs hnorm x
  refine ⟨r ∘ Tuple.sort r,Tuple.monotone_sort r,?_⟩
  rw [hf]
  exact (Equiv.prod_comp (Tuple.sort r) (fun i => Polynomial.X+Polynomial.C (r i))).symm

end CoefficientStability
