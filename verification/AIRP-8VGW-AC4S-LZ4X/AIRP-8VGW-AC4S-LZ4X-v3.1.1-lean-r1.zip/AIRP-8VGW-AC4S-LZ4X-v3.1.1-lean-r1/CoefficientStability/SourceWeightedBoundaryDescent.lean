import CoefficientStability.SourceWeightedCurveContinuity

noncomputable section
open scoped BigOperators Topology
open Filter
namespace CoefficientStability
variable {m n : ℕ}

theorem source_actual_squarefree_curve_descent (t : Fin n → ℝ) (hn : 2 ≤ n)
    (ht : (∑ i,t i)=n) (htpos : ∀ i,0 < t i) (hl : scalarHessianLambda t ≤ 0) :
    ∃ e : ℝ,0 < e ∧ ∀ s : ℝ,0 < s → s < e →
      fixedDegreeObjective (stableBoundaryCurve t s) < fixedDegreeObjective (fixedDegreeReference t) := by
  rcases lt_or_eq_of_le hl with hneg | hzero
  · obtain ⟨e,he,hdesc⟩ := polynomial_strict_descent_of_negative_quadratic (boundaryMixedPolynomial t)
      (boundaryMixedPolynomial_coeff_one t (by omega)) (boundaryMixedPolynomial_negative_coeff_two t hn ht htpos hneg)
    refine ⟨e,he,?_⟩
    intro s hs hse
    rw [← stableBoundaryCurve_zero t,stableBoundaryCurve_objective t (by omega) s,
      stableBoundaryCurve_objective t (by omega) 0]
    exact hdesc s hs hse
  · have hn3 : 3 ≤ n := by
      by_contra hh
      have he : n=2 := by omega
      subst n
      have hp := scalarHessian_dimension_two_positive t ht htpos
      rw [hzero] at hp
      linarith
    obtain ⟨e,he,hdesc⟩ := polynomial_strict_descent_of_negative_cubic (boundaryMixedPolynomial t)
      (boundaryMixedPolynomial_coeff_one t (by omega))
      (boundaryMixedPolynomial_boundary_coeff_two t (by omega) ht htpos hzero)
      (boundaryMixedPolynomial_boundary_coeff_three_neg t hn3 ht htpos hzero)
    refine ⟨e,he,?_⟩
    intro s hs hse
    rw [← stableBoundaryCurve_zero t,stableBoundaryCurve_objective t (by omega) s,
      stableBoundaryCurve_objective t (by omega) 0]
    exact hdesc s hs hse

theorem source_actual_weighted_curve_descent (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (hN : 2 ≤ sourceCloneCount α) (t : Fin m → ℝ)
    (ht : (∑ i,t i)=sourceCloneCount α) (htpos : ∀ i,0 < t i)
    (hl : scalarHessianLambda (sourceClonedGradient α t) ≤ 0) :
    ∃ e : ℝ,0 < e ∧ ∀ s : ℝ,0 < s → s < e →
      sourceMultiindexObjective α (sourceWeightedBoundaryCurve α t s) <
        sourceMultiindexObjective α (sourceWeightedReference α t) := by
  obtain ⟨e,he,hdesc⟩ := source_actual_squarefree_curve_descent (sourceClonedGradient α t) hN
    ((sourceClonedGradient_sum α hα t).trans ht) (sourceClonedGradient_pos α hα t htpos) hl
  have hK := sourceCloneCoefficientWeight_pos α hα
  refine ⟨e,he,?_⟩
  intro s hs hse
  have h := hdesc s hs hse
  rw [← stableBoundaryCurve_zero (sourceClonedGradient α t)] at h
  rw [← sourceWeightedBoundaryCurve_coefficient α hα t s,
    ← sourceWeightedBoundaryCurve_coefficient α hα t 0,sourceWeightedBoundaryCurve_zero α hα] at h
  by_contra hh
  have hle := mul_le_mul_of_nonneg_left (le_of_not_gt hh) hK.le
  linarith

theorem source_not_localMin_of_actual_weighted_curve (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (hN : 2 ≤ sourceCloneCount α) (t : Fin m → ℝ)
    (ht : (∑ i,t i)=sourceCloneCount α) (htpos : ∀ i,0 < t i)
    (hdesc : ∃ e : ℝ,0 < e ∧ ∀ s : ℝ,0 < s → s < e →
      sourceMultiindexObjective α (sourceWeightedBoundaryCurve α t s) < sourceMultiindexObjective α (sourceWeightedReference α t)) :
    ¬IsLocalMinOn (sourceMultiindexObjective α) (sourceMultiindexCoefficientClass α t) (sourceWeightedReference α t) := by
  intro hf
  obtain ⟨ef,hef,hfeas⟩ := sourceWeightedBoundaryCurve_feasible α hα hN t ht htpos
  let J : Set ℝ := Set.Ioo (-ef) ef
  have hmem : J ⊆ (sourceWeightedBoundaryCurve α t) ⁻¹' sourceMultiindexCoefficientClass α t := by
    intro s hs
    exact hfeas s (abs_lt.mpr hs)
  have hz : (0 : ℝ) ∈ J := by constructor <;> linarith
  have hstart : IsLocalMinOn (sourceMultiindexObjective α) (sourceMultiindexCoefficientClass α t)
      (sourceWeightedBoundaryCurve α t 0) := by
    simpa only [sourceWeightedBoundaryCurve_zero α hα] using hf
  have hcomp := hstart.comp_continuousOn hmem (sourceWeightedBoundaryCurve_continuous α hα t).continuousOn hz
  have hloc := hcomp.isLocalMin (isOpen_Ioo.mem_nhds hz)
  change ∀ᶠ s in 𝓝 (0 : ℝ),sourceMultiindexObjective α (sourceWeightedBoundaryCurve α t 0) ≤
    sourceMultiindexObjective α (sourceWeightedBoundaryCurve α t s) at hloc
  obtain ⟨r,hr,hnear⟩ := Metric.eventually_nhds_iff.mp hloc
  obtain ⟨ed,hed,hdes⟩ := hdesc
  let s := min r ed/2
  have hs : 0 < s := by dsimp [s];exact div_pos (lt_min hr hed) (by norm_num)
  have hsr : s < r := by have h := min_le_left r ed;dsimp [s];nlinarith [lt_min hr hed]
  have hsd : s < ed := by have h := min_le_right r ed;dsimp [s];nlinarith [lt_min hr hed]
  have hle := hnear (y := s) (by simpa [Real.dist_eq,abs_of_pos hs] using hsr)
  rw [sourceWeightedBoundaryCurve_zero α hα] at hle
  have hlt := hdes s hs hsd
  linarith

end CoefficientStability
