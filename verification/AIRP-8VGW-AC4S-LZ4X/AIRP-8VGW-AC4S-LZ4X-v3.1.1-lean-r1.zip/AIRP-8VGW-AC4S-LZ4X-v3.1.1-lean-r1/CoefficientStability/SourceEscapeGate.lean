import CoefficientStability.SourceEscapeAlgebra

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 3500000
set_option backward.isDefEq.respectTransparency false

def sourceEscapeD (a b : ℝ) : ℝ := (2*a+b)/12
def sourceEscapeV (a b : ℝ) : ℝ := Real.sqrt (b*(4*a-b)/48)
def sourceEscapeGate (a b v : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  ![![0,b/2,b/2],![1/2,sourceEscapeD a b+v,sourceEscapeD a b-v],![1/2,sourceEscapeD a b-v,sourceEscapeD a b+v]]
def sourceEscapeFlatDirection : Matrix (Fin 3) (Fin 3) ℝ :=
  ![![0,0,0],![0,1,-1],![0,-1,1]]

theorem source_escape_v_properties (a b : ℝ) (hb : 0 < b) (hab : b/4 ≤ a) :
    0 ≤ sourceEscapeV a b ∧ (sourceEscapeV a b)^2=b*(4*a-b)/48 := by
  exact ⟨Real.sqrt_nonneg _,Real.sq_sqrt (div_nonneg (mul_nonneg hb.le (by linarith)) (by norm_num))⟩

theorem source_escape_dv_identity (a b v : ℝ) (hv : v^2=b*(4*a-b)/48) :
    (sourceEscapeD a b)^2-v^2=(a-b)^2/36 := by
  rw [hv]
  unfold sourceEscapeD
  ring

theorem source_escape_v_le_d (a b : ℝ) (ha : 0 < a) (hb : 0 < b) (hab : b/4 ≤ a) :
    sourceEscapeV a b ≤ sourceEscapeD a b := by
  have hv := source_escape_v_properties a b hb hab
  have he := source_escape_dv_identity a b (sourceEscapeV a b) hv.2
  have hd : 0 < sourceEscapeD a b := by unfold sourceEscapeD;positivity
  nlinarith [sq_nonneg (a-b)]

theorem source_escape_v_lt_d_of_unbalanced (a b : ℝ) (ha : 0 < a) (hb : 0 < b)
    (hab : b/4 ≤ a) (hne : a ≠ b) : sourceEscapeV a b < sourceEscapeD a b := by
  have hv := source_escape_v_properties a b hb hab
  have he := source_escape_dv_identity a b (sourceEscapeV a b) hv.2
  have hd : 0 < sourceEscapeD a b := by unfold sourceEscapeD;positivity
  have hs : 0 < (a-b)^2 := sq_pos_of_ne_zero (sub_ne_zero.mpr hne)
  nlinarith

theorem source_escape_gate_flat_feasible (a b v z : ℝ) (hb : 0 ≤ b) (hs : a+2*b=3)
    (hv : |v+z| ≤ sourceEscapeD a b) :
    sourceEscapeGate a b v+z • sourceEscapeFlatDirection ∈ sourceTransportationPolytope (sourceEscapeTraces a b) := by
  have hlow := (abs_le.mp hv).1
  have hupp := (abs_le.mp hv).2
  refine ⟨?_,?_,?_⟩
  · intro i j
    fin_cases i <;> fin_cases j <;>
      norm_num [sourceEscapeGate,sourceEscapeFlatDirection,Matrix.add_apply,Matrix.smul_apply] <;> linarith
  · intro i
    fin_cases i <;> norm_num [sourceEscapeGate,sourceEscapeFlatDirection,sourceEscapeTraces,
      sourceEscapeD,Matrix.add_apply,Matrix.smul_apply,Fin.sum_univ_succ] <;> linarith
  · intro j
    fin_cases j <;> norm_num [sourceEscapeGate,sourceEscapeFlatDirection,sourceEscapeD,
      Matrix.add_apply,Matrix.smul_apply,Fin.sum_univ_succ] <;> linarith

theorem source_escape_gate_flat_permanent (a b v z : ℝ) :
    Matrix.permanent (sourceEscapeGate a b v+z • sourceEscapeFlatDirection)=b*sourceEscapeD a b := by
  rw [source_permanent_three]
  norm_num [sourceEscapeGate,sourceEscapeFlatDirection,sourceEscapeD,Matrix.add_apply,Matrix.smul_apply]
  ring

theorem source_escape_gate_flat_quadratic_increment (a b v z : ℝ) :
    sourceEscapeQuadratic a b (sourceEscapeGate a b v-sourceEscapeCenter a b+z • sourceEscapeFlatDirection)=
      sourceEscapeQuadratic a b (sourceEscapeGate a b v-sourceEscapeCenter a b)+(4*b*v/3)*z+(2*b/3)*z^2 := by
  norm_num [sourceEscapeQuadratic,sourceEscapeWeights,sourceEscapeGate,sourceEscapeFlatDirection,
    sourceEscapeCenter,sourceEscapeTraces,sourcePermanentReference,sourceEscapeD,
    Matrix.add_apply,Matrix.sub_apply,Matrix.smul_apply,Fin.sum_univ_succ]
  ring

theorem source_escape_gate_quadratic (a b v : ℝ) (hs : a+2*b=3) (hv : v^2=b*(4*a-b)/48) :
    sourceEscapeQuadratic a b (sourceEscapeGate a b v-sourceEscapeCenter a b)=sourceEscapeQ a b := by
  have he : a=3-2*b := by linarith
  rw [he] at hv ⊢
  norm_num [sourceEscapeQuadratic,sourceEscapeWeights,sourceEscapeGate,sourceEscapeCenter,
    sourceEscapeTraces,sourcePermanentReference,sourceEscapeD,sourceEscapeQ,Matrix.sub_apply,Fin.sum_univ_succ]
  ring_nf
  rw [hv]
  ring

theorem source_escape_gate_height (a b v : ℝ) (hs : a+2*b=3) :
    Matrix.permanent (sourceEscapeGate a b v)-Matrix.permanent (sourceEscapeCenter a b)=sourceEscapeDelta a b := by
  have he : a=3-2*b := by linarith
  have hp := source_escape_gate_flat_permanent a b v 0
  simp only [zero_smul,add_zero] at hp
  rw [hp,he,source_permanent_three]
  norm_num [sourceEscapeCenter,sourceEscapeTraces,sourcePermanentReference,sourceEscapeD,sourceEscapeDelta]
  ring

end CoefficientStability
