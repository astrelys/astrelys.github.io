import CoefficientStability.PolynomialCoefficientTopology

noncomputable section
open scoped BigOperators Topology
open MvPolynomial Filter
namespace CoefficientStability
variable {n : ℕ}

theorem scalarPower_stable (t : Fin n → ℝ) (hn : 0<n) (htpos : ∀ i,0<t i) :
    UpperHalfPlaneZeroFree (scalarPower t n) := by
  intro z hz
  have hnpos : (0 : ℝ)<n := by exact_mod_cast hn
  have him : 0<((MvPolynomial.eval₂Hom Complex.ofRealHom z) (scalarLinear t n)).im := by
    have he : ((MvPolynomial.eval₂Hom Complex.ofRealHom z) (scalarLinear t n)).im=
        ∑ i,t i/(n : ℝ)*(z i).im := by
      simp [scalarLinear,Complex.mul_im]
    rw [he]
    apply Finset.sum_pos'
    · intro i hi
      exact (mul_pos (div_pos (htpos i) hnpos) (hz i)).le
    · let i : Fin n := ⟨0,hn⟩
      exact ⟨i,Finset.mem_univ i,mul_pos (div_pos (htpos i) hnpos) (hz i)⟩
  have hne : (MvPolynomial.eval₂Hom Complex.ofRealHom z) (scalarLinear t n)≠0 := by
    intro he
    rw [he,Complex.zero_im] at him
    linarith
  change (MvPolynomial.eval₂Hom Complex.ofRealHom z) (scalarPower t n)≠0
  rw [scalarPower,map_pow]
  exact pow_ne_zero _ hne

theorem fixedDegreeReference_feasible (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) : fixedDegreeReference t∈stableCoefficientClass t := by
  refine ⟨eval_one_scalarPower t n (by omega) ht,scalarPower_stable t (by omega) htpos,
    scalarPower_coefficient_nonnegative t n (fun i => (htpos i).le),?_⟩
  exact scalarPower_gradient t n (by omega) ht

theorem paper_stable_topological_strict_local (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i)
    (hradius : (∑ i,(t i-1)^2)<(n : ℝ)/((n : ℝ)-1)) :
    ∀ᶠ p in 𝓝[stableCoefficientClass t] (fixedDegreeReference t),
      p≠fixedDegreeReference t → fixedDegreeObjective (fixedDegreeReference t)<fixedDegreeObjective p := by
  obtain ⟨a,e,ha,he,hgrowth⟩ := paper_stable_local_coefficient_growth t hn ht htpos
    ((scalarHessianLambda_pos_iff_radius t hn ht).mpr hradius)
  have hopen : IsOpen {p : FixedDegreePolynomials n | coefficientL1 (p.val-(fixedDegreeReference t).val)<e} :=
    isOpen_lt (fixedDegree_coefficientL1_continuous n _) continuous_const
  have hnear : ∀ᶠ p in 𝓝 (fixedDegreeReference t),coefficientL1 (p.val-(fixedDegreeReference t).val)<e :=
    hopen.mem_nhds (by simpa only [sub_self,coefficientL1_zero,Set.mem_setOf_eq] using he)
  filter_upwards [self_mem_nhdsWithin,hnear.filter_mono nhdsWithin_le_nhds] with p hp hclose
  intro hpne
  have hpolyne : p.val≠scalarPower t n := fun h => hpne (Subtype.ext h)
  have hg := (hgrowth p.val p.property hp.1 hp.2.1 hp.2.2.2 hclose).2 hpolyne
  change (scalarPower t n).coeff (squarefreeExponent n)<p.val.coeff (squarefreeExponent n)
  simpa [sub_pos] using hg

end CoefficientStability
