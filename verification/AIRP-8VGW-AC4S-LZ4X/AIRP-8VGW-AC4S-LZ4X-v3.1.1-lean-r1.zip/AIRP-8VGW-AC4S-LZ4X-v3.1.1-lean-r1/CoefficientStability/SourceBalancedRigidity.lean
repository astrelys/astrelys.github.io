import CoefficientStability.SourceNoiseConditioning
import CoefficientStability.BalancedRigidityConditionalClosure

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem source_balanced_small_excess_unmixed_nonnegative (p : MvPolynomial (Fin n) ℝ) (hn : 3≤n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=1)
    (hsmall : p.coeff (squarefreeExponent n)/sourceVn n-1≤sourceSmallExcessThreshold n) :
    ∀ g,0≤(uniformUnmixedPolynomial p n (sourceMixingRadius n)).coeff g := by
  have hn0 : 0<(n : ℝ) := by exact_mod_cast (show 0<n by omega)
  have hsmallgrad : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)≤capacityEta n/(64*(n : ℝ)) := by
    simp_rw [hgrad]
    simp only [sub_self,abs_zero,Finset.sum_const_zero]
    exact (div_pos (capacityEta_pos n hn) (by positivity)).le
  have hcoef : p.coeff (squarefreeExponent n)≤sourceVn n*(1+capacityEta n/2) := by
    have hτ := hsmall.trans (sourceSmallExcessThreshold_bounds hn).1
    have hratio : p.coeff (squarefreeExponent n)/sourceVn n≤1+capacityEta n/2 := by linarith
    have h := (div_le_iff₀ (sourceVn_pos (by omega : 0<n))).mp hratio
    simpa only [mul_comm] using h
  exact source_uniform_unmixed_coeff_nonnegative p hn hp hs hnorm hsmallgrad hcoef

theorem source_actual_balanced_rigidity (p : MvPolynomial (Fin n) ℝ) (hn : 3≤n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=1) :
    actualTiltDeficit p 0/(100000000*(n : ℝ)^8)≤p.coeff (squarefreeExponent n)/sourceVn n-1 := by
  exact actual_balanced_rigidity_from_source_unmixing n hn p hp hs hnorm hgrad
    (fun hsmall => source_balanced_small_excess_unmixed_nonnegative p hn hp hs hnorm hgrad hsmall)

theorem source_normalized_balanced_gap (p : MvPolynomial (Fin n) ℝ) (hn : 3≤n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=1) :
    sourceVn n*(1+referenceDeficit p (fun _ => 1) n/(100000000*(n : ℝ)^8))≤p.coeff (squarefreeExponent n) := by
  exact normalized_balanced_gap_from_source_unmixing n hn p hp hs hnorm hgrad
    (fun hsmall => source_balanced_small_excess_unmixed_nonnegative p hn hp hs hnorm hgrad hsmall)

end CoefficientStability
