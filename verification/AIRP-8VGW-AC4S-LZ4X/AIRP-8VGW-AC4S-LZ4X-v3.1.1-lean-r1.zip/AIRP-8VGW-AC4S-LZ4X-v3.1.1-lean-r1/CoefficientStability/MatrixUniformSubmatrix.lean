import CoefficientStability.MatrixSupportMatching
import Mathlib.Analysis.Convex.DoublyStochasticMatrix
import Mathlib.Topology.Instances.RealVectorSpace
import Mathlib.Tactic.FunProp

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def matrixEntrywiseOrder : PartialOrder (Matrix (Fin n) (Fin n) ℝ) :=
  inferInstanceAs (PartialOrder (Fin n → Fin n → ℝ))
attribute [local instance] matrixEntrywiseOrder

def matrixEntrywiseCompactIcc : CompactIccSpace (Matrix (Fin n) (Fin n) ℝ) :=
  inferInstanceAs (CompactIccSpace (Fin n → Fin n → ℝ))
attribute [local instance] matrixEntrywiseCompactIcc

def matrixRowMass (B : Matrix (Fin n) (Fin n) ℝ) (i0 : Fin n) : ℝ := ∑ j,B i0 j

def uniformSubmatrixSet (A : Matrix (Fin n) (Fin n) ℝ) (i0 : Fin n) : Set (Matrix (Fin n) (Fin n) ℝ) :=
  (Set.Icc 0 A ∩ {B | ∀ i,(∑ j,B i j)=matrixRowMass B i0}) ∩
    {B | ∀ j,(∑ i,B i j)=matrixRowMass B i0}

theorem matrixRowMass_continuous (i0 : Fin n) :
    Continuous (fun B : Matrix (Fin n) (Fin n) ℝ => matrixRowMass B i0) := by
  unfold matrixRowMass
  fun_prop

theorem uniformSubmatrixSet_isCompact (A : Matrix (Fin n) (Fin n) ℝ) (i0 : Fin n) :
    IsCompact (uniformSubmatrixSet A i0) := by
  have hrow : IsClosed {B : Matrix (Fin n) (Fin n) ℝ | ∀ i,(∑ j,B i j)=matrixRowMass B i0} := by
    have h (i : Fin n) : IsClosed {B : Matrix (Fin n) (Fin n) ℝ | (∑ j,B i j)=matrixRowMass B i0} :=
      isClosed_eq (by fun_prop) (matrixRowMass_continuous i0)
    simpa only [Set.ofPred_forall] using isClosed_iInter h
  have hcol : IsClosed {B : Matrix (Fin n) (Fin n) ℝ | ∀ j,(∑ i,B i j)=matrixRowMass B i0} := by
    have h (j : Fin n) : IsClosed {B : Matrix (Fin n) (Fin n) ℝ | (∑ i,B i j)=matrixRowMass B i0} :=
      isClosed_eq (by fun_prop) (matrixRowMass_continuous i0)
    simpa only [Set.ofPred_forall] using isClosed_iInter h
  exact (isCompact_Icc.inter_right hrow).inter_right hcol

theorem uniformSubmatrixSet_zero_mem (A : Matrix (Fin n) (Fin n) ℝ)
    (hA : ∀ i j,0≤A i j) (i0 : Fin n) : (0 : Matrix (Fin n) (Fin n) ℝ)∈uniformSubmatrixSet A i0 := by
  refine ⟨⟨⟨le_refl _,?_⟩,?_⟩,?_⟩
  · exact hA
  · intro i
    simp [matrixRowMass]
  · intro j
    simp [matrixRowMass]

theorem exists_maximal_uniform_submatrix (A : Matrix (Fin n) (Fin n) ℝ)
    (hA : ∀ i j,0≤A i j) (i0 : Fin n) :
    ∃ B∈uniformSubmatrixSet A i0,∀ C∈uniformSubmatrixSet A i0,matrixRowMass C i0≤matrixRowMass B i0 := by
  exact (uniformSubmatrixSet_isCompact A i0).exists_isMaxOn
    ⟨0,uniformSubmatrixSet_zero_mem A hA i0⟩ (matrixRowMass_continuous i0).continuousOn

end CoefficientStability
