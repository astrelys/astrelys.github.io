import CoefficientStability.BoundaryVariation
import Mathlib.Algebra.Polynomial.Div
import Mathlib.Topology.Algebra.Polynomial

noncomputable section
open scoped BigOperators Topology
open Polynomial
namespace CoefficientStability
variable {n : ℕ}

theorem polynomial_strict_descent_of_negative_cubic (p : ℝ[X])
    (h1 : p.coeff 1=0) (h2 : p.coeff 2=0) (h3 : p.coeff 3<0) :
    ∃ e : ℝ,0<e ∧ ∀ s : ℝ,0<s → s<e → p.eval s<p.eval 0 := by
  have hd : Polynomial.X^3 ∣ p-Polynomial.C (p.coeff 0) := by
    apply Polynomial.X_pow_dvd_iff.mpr
    intro d hd
    have hcases : d=0 ∨ d=1 ∨ d=2 := by omega
    rcases hcases with rfl | rfl | rfl <;> simp [Polynomial.coeff_sub,Polynomial.coeff_C,h1,h2]
  obtain ⟨q,hq⟩ := hd
  have hqcoeff : p.coeff 3=q.coeff 0 := by
    have h := congrArg (fun f : ℝ[X] => f.coeff 3) hq
    have hc : (Polynomial.X^3*q).coeff 3=q.coeff 0 := Polynomial.coeff_X_pow_mul q 3 0
    simpa [Polynomial.coeff_sub,Polynomial.coeff_C,hc] using h
  have hq0 : q.eval 0<0 := by simpa only [← Polynomial.coeff_zero_eq_eval_zero,← hqcoeff] using h3
  have hnear : ∀ᶠ s in 𝓝 (0 : ℝ),q.eval s<0 :=
    q.continuousAt.eventually (eventually_lt_nhds hq0)
  obtain ⟨e,he,hbound⟩ := Metric.eventually_nhds_iff.mp hnear
  refine ⟨e,he,?_⟩
  intro s hs hse
  have hqs : q.eval s<0 := hbound (by simpa [Real.dist_eq,abs_of_pos hs] using hse)
  have hval := congrArg (Polynomial.eval s) hq
  simp only [Polynomial.eval_sub,Polynomial.eval_C,Polynomial.eval_mul,Polynomial.eval_pow,Polynomial.eval_X] at hval
  rw [Polynomial.coeff_zero_eq_eval_zero] at hval
  have hneg := mul_neg_of_pos_of_neg (pow_pos hs 3) hqs
  linarith

theorem paper_boundary_actual_descent (t : Fin n → ℝ) (hn : 3≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : scalarHessianLambda t=0) :
    ∃ e : ℝ,0<e ∧ ∀ s : ℝ,0<s → s<e →
      (∀ i,(boundaryPerturbedTuple t s i).PosDef) ∧
      (∑ i,boundaryPerturbedTuple t s i)=1 ∧
      (∀ i,Matrix.trace (boundaryPerturbedTuple t s i)=t i) ∧
      mixedDiscriminant (boundaryPerturbedTuple t s)<mixedDiscriminant (scalarReferenceTuple t) := by
  obtain ⟨e1,he1,hfeas⟩ := paper_boundary_feasible_line t (by omega) ht htpos
  obtain ⟨e2,he2,hdesc⟩ := polynomial_strict_descent_of_negative_cubic (boundaryMixedPolynomial t)
    (boundaryMixedPolynomial_coeff_one t (by omega))
    (boundaryMixedPolynomial_boundary_coeff_two t (by omega) ht htpos hl)
    (boundaryMixedPolynomial_boundary_coeff_three_neg t hn ht htpos hl)
  refine ⟨min e1 e2,lt_min he1 he2,?_⟩
  intro s hs hse
  have habs : |s|<e1 := by rw [abs_of_pos hs];exact lt_of_lt_of_le hse (min_le_left _ _)
  have hf := hfeas s habs
  have hd := hdesc s hs (lt_of_lt_of_le hse (min_le_right _ _))
  rw [boundaryMixedPolynomial_eval t (by omega) s,boundaryMixedPolynomial_eval t (by omega) 0] at hd
  have hzero : boundaryPerturbedTuple t 0=scalarReferenceTuple t := by funext i;simp [boundaryPerturbedTuple]
  rw [hzero] at hd
  exact ⟨hf.1,hf.2.1,hf.2.2,hd⟩

end CoefficientStability
