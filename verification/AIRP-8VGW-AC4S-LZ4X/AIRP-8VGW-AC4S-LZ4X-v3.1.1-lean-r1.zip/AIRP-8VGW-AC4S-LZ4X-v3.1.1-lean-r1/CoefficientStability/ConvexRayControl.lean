import Mathlib.Analysis.Convex.Deriv

noncomputable section
namespace CoefficientStability

theorem convex_unit_chord (f : ℝ → ℝ) (hc : ConvexOn ℝ Set.univ f)
    (hf0 : f 0=0) (s : ℝ) (hs : s∈Set.Icc (0 : ℝ) 1) : f s≤s*f 1 := by
  have h := hc.2 (Set.mem_univ (0 : ℝ)) (Set.mem_univ (1 : ℝ))
    (sub_nonneg.mpr hs.2) hs.1 (by ring)
  simpa only [smul_eq_mul,mul_zero,zero_add,mul_one,hf0] using h

theorem convex_outer_linear_lower (f : ℝ → ℝ) (hc : ConvexOn ℝ Set.univ f)
    (hf0 : f 0=0) (A R : ℝ) (hR : 1≤R) (hlocal : A/2≤f (1/R)) :
    A*R/2≤f 1 := by
  have hR0 : 0<R := by linarith
  have hs : 1/R∈Set.Icc (0 : ℝ) 1 := by
    constructor
    · positivity
    · exact (div_le_one hR0).mpr hR
  have h := mul_le_mul_of_nonneg_left (hlocal.trans (convex_unit_chord f hc hf0 (1/R) hs)) hR0.le
  have he : R*((1/R)*f 1)=f 1 := by field_simp
  rw [he] at h
  nlinarith only [h]

end CoefficientStability
