import CoefficientStability.SourceHermitianGlobalGrowth
import Mathlib.LinearAlgebra.Matrix.Permanent

noncomputable section
open scoped BigOperators ComplexOrder Topology Matrix.Norms.Elementwise
namespace CoefficientStability
variable {n : ℕ}

def sourceTransportationPolytope (t : Fin n → ℝ) : Set (Matrix (Fin n) (Fin n) ℝ) :=
  {B | (∀ i j,0 ≤ B i j) ∧ (∀ i,∑ j,B i j=t i) ∧ ∀ j,∑ i,B i j=1}

def sourcePermanentReference (t : Fin n → ℝ) : Matrix (Fin n) (Fin n) ℝ := fun i _ => t i/n

def sourcePermanentDiagonalTuple (B : Matrix (Fin n) (Fin n) ℝ) : Fin n → ComplexSquare n :=
  fun i => Matrix.diagonal (fun j => Complex.ofReal (B i j))

theorem source_permanent_coefficient_identity (B : Matrix (Fin n) (Fin n) ℝ) :
    diagonalMixedDeterminant (fun r i => B i r)=Matrix.permanent B := by
  rw [diagonalMixedDeterminant_eq_permutation_sum]
  rfl

theorem source_permanent_diagonal_objective (B : Matrix (Fin n) (Fin n) ℝ) :
    hermitianMixedObjective (sourcePermanentDiagonalTuple B)=Matrix.permanent B := by
  have he := complexMixedDiscriminant_diagonal (fun r i => Complex.ofReal (B i r))
  have hm : diagonalMixedDeterminant (fun r i => Complex.ofReal (B i r))=
      Complex.ofReal (diagonalMixedDeterminant (fun r i => B i r)) :=
    diagonalMixedDeterminant_map Complex.ofRealHom (fun r i => B i r)
  rw [hm,source_permanent_coefficient_identity] at he
  exact congrArg Complex.re he

theorem source_permanent_diagonal_feasible (t : Fin n → ℝ) (B : Matrix (Fin n) (Fin n) ℝ)
    (hB : B ∈ sourceTransportationPolytope t) :
    sourcePermanentDiagonalTuple B ∈ hermitianFeasibleTuples t := by
  refine ⟨?_,?_⟩
  · intro i
    have hPSD : (sourcePermanentDiagonalTuple B i).PosSemidef :=
      Matrix.PosSemidef.diagonal (fun j => Complex.nonneg_iff.mpr ⟨hB.1 i j,rfl⟩)
    refine ⟨hPSD.isHermitian,hPSD,?_⟩
    simp only [sourcePermanentDiagonalTuple,Matrix.trace_diagonal,← Complex.ofReal_sum,hB.2.1 i]
  · ext r c
    by_cases hrc : r=c
    · subst c
      simpa only [Matrix.sum_apply,sourcePermanentDiagonalTuple,Matrix.diagonal_apply_eq,
        ← Complex.ofReal_sum,hB.2.2 r,Complex.ofReal_one,Matrix.one_apply_eq]
    · simp only [Matrix.sum_apply,sourcePermanentDiagonalTuple,Matrix.diagonal_apply,hrc,ite_false,
        Finset.sum_const_zero,Matrix.one_apply,hrc,ite_false]

theorem source_permanent_diagonal_reference (t : Fin n → ℝ) :
    sourcePermanentDiagonalTuple (sourcePermanentReference t)=complexReferenceTuple t := by
  funext i
  rw [complexReferenceTuple_source]
  ext r c
  by_cases hrc : r=c <;> simp [sourcePermanentDiagonalTuple,sourcePermanentReference,Matrix.diagonal_apply,
    Matrix.smul_apply,Matrix.one_apply,hrc]

theorem source_permanent_diagonal_continuous : Continuous (sourcePermanentDiagonalTuple (n := n)) := by
  apply continuous_pi
  intro i
  apply continuous_pi
  intro r
  apply continuous_pi
  intro c
  by_cases h : r=c
  · subst c
    simp only [sourcePermanentDiagonalTuple,Matrix.diagonal_apply_eq]
    fun_prop
  · simp only [sourcePermanentDiagonalTuple,Matrix.diagonal_apply,h,ite_false]
    exact continuous_const

theorem source_permanent_diagonal_distance (t : Fin n → ℝ) (B : Matrix (Fin n) (Fin n) ℝ) :
    complexTupleSq (sourcePermanentDiagonalTuple B-complexReferenceTuple t)=∑ i,∑ j,(B i j-t i/n)^2 := by
  have he : sourcePermanentDiagonalTuple B-complexReferenceTuple t=
      fun i => Matrix.diagonal (fun j => Complex.ofReal (B i j-t i/n)) := by
    rw [← source_permanent_diagonal_reference]
    ext i r c
    by_cases h : r=c <;> simp [sourcePermanentDiagonalTuple,sourcePermanentReference,Matrix.diagonal_apply,h]
  rw [he]
  simp only [complexTupleSq,complexFrobeniusSq]
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro j hj
  rw [Finset.sum_eq_single j]
  · simp
  · intro k hk hkj
    simp [Matrix.diagonal_apply,Ne.symm hkj]
  · simp

theorem source_permanent_local_sufficiency (t : Fin n → ℝ) (hn : 2 ≤ n)
    (ht : (∑ i,t i)=n) (htpos : ∀ i,0 < t i)
    (hradius : (∑ i,(t i-1)^2) < (n : ℝ)/((n : ℝ)-1)) :
    IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) (sourcePermanentReference t) := by
  have href : sourcePermanentReference t ∈ sourceTransportationPolytope t := by
    have hn0 : (n : ℝ)≠0 := by exact_mod_cast (show n≠0 by omega)
    refine ⟨fun i j => (div_pos (htpos i) (by exact_mod_cast (show 0<n by omega))).le,?_,?_⟩
    · intro i
      simp only [sourcePermanentReference,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
      field_simp
    · intro j
      simp only [sourcePermanentReference,← Finset.sum_div,ht,div_self hn0]
  have hmin := (paper_exact_local t hn ht htpos).mpr hradius
  rw [← source_permanent_diagonal_reference] at hmin
  have h := hmin.comp_continuousOn (fun B hB => source_permanent_diagonal_feasible t B hB)
    source_permanent_diagonal_continuous.continuousOn href
  simpa only [Function.comp_def,source_permanent_diagonal_objective] using h

end CoefficientStability
