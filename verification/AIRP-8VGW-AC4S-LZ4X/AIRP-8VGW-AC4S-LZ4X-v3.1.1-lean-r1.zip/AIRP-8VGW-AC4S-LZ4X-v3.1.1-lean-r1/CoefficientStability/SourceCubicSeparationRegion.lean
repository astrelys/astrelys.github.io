import CoefficientStability.SourceCubicConicProblem
import Mathlib.Analysis.LocallyConvex.Separation

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 2500000
set_option backward.isDefEq.respectTransparency false

def sourceCubicSeparationRegion (g : Module.Dual ℝ SourceCubicHermitianTuples)
    (b : SourceCubicConstraintSpace) (v : ℝ) : Set (SourceCubicConstraintSpace × ℝ) :=
  (fun q => -(b,v)+q) '' ((sourceCubicAugmentedConstraintMap g) ''
    ((interior sourceCubicPSDCone) ×ˢ Set.Ioi 0))

theorem source_cubic_separation_region_mem (g : Module.Dual ℝ SourceCubicHermitianTuples)
    (b : SourceCubicConstraintSpace) (v : ℝ) (q : SourceCubicConstraintSpace × ℝ) :
    q ∈ sourceCubicSeparationRegion g b v ↔
      ∃ Y ∈ interior sourceCubicPSDCone,∃ s : ℝ,0 < s ∧
        q=(sourceCubicConstraintMap Y-b,g Y-v+s) := by
  constructor
  · rintro ⟨z,⟨⟨Y,s⟩,⟨hY,hs⟩,rfl⟩,rfl⟩
    refine ⟨Y,hY,s,hs,?_⟩
    apply Prod.ext
    · change -b+sourceCubicConstraintMap Y=sourceCubicConstraintMap Y-b
      abel
    · change -v+(g Y+s)=g Y-v+s
      ring
  · rintro ⟨Y,hY,s,hs,rfl⟩
    refine ⟨sourceCubicAugmentedConstraintMap g (Y,s),⟨(Y,s),⟨hY,hs⟩,rfl⟩,?_⟩
    apply Prod.ext
    · change -b+sourceCubicConstraintMap Y=sourceCubicConstraintMap Y-b
      abel
    · change -v+(g Y+s)=g Y-v+s
      ring

theorem source_cubic_separation_region_open (g : Module.Dual ℝ SourceCubicHermitianTuples)
    (b : SourceCubicConstraintSpace) (v : ℝ) : IsOpen (sourceCubicSeparationRegion g b v) := by
  have hp : IsOpen ((interior sourceCubicPSDCone) ×ˢ Set.Ioi (0 : ℝ)) := isOpen_interior.prod isOpen_Ioi
  have ho := source_cubic_augmented_constraint_open g _ hp
  exact (Homeomorph.addLeft (-(b,v))).isOpenMap _ ho

theorem source_cubic_separation_region_convex (g : Module.Dual ℝ SourceCubicHermitianTuples)
    (b : SourceCubicConstraintSpace) (v : ℝ) : Convex ℝ (sourceCubicSeparationRegion g b v) := by
  have hc := source_cubic_psd_cone_convex.interior.prod (convex_Ioi (0 : ℝ))
  exact (hc.linear_image (sourceCubicAugmentedConstraintMap g)).translate (-(b,v))

theorem source_cubic_original_separation_zero_not_mem (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : A ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A) :
    (0 : SourceCubicConstraintSpace × ℝ) ∉ sourceCubicSeparationRegion (sourceCubicGradientDual t A)
      (sourceCubicConstraintTarget t)
      (sourceCubicGradientDual t A (sourceCubicHermitianBundle A (fun i => (hA.1 i).1))) := by
  intro hh
  obtain ⟨Y,hY,s,hs,he⟩ := (source_cubic_separation_region_mem _ _ _ _).mp hh
  have hc : sourceCubicConstraintMap Y=sourceCubicConstraintTarget t := by
    have h := congrArg Prod.fst he
    change 0=sourceCubicConstraintMap Y-sourceCubicConstraintTarget t at h
    exact sub_eq_zero.mp h.symm
  have hn := source_cubic_actual_conic_linear_minimum t ht A hA hm Y (interior_subset hY) hc
  have h := congrArg Prod.snd he
  change 0=sourceCubicGradientDual t A Y-
    sourceCubicGradientDual t A (sourceCubicHermitianBundle A (fun i => (hA.1 i).1))+s at h
  linarith

theorem source_cubic_original_separator_exists (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : A ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A) :
    ∃ f : StrongDual ℝ (SourceCubicConstraintSpace × ℝ),
      ∀ Y ∈ interior sourceCubicPSDCone,∀ s : ℝ,0 < s →
        0 < f (sourceCubicConstraintMap Y-sourceCubicConstraintTarget t,
          sourceCubicGradientDual t A Y-
            sourceCubicGradientDual t A (sourceCubicHermitianBundle A (fun i => (hA.1 i).1))+s) := by
  obtain ⟨f,hf⟩ := geometric_hahn_banach_point_open
    (source_cubic_separation_region_convex (sourceCubicGradientDual t A) _ _)
    (source_cubic_separation_region_open (sourceCubicGradientDual t A) _ _)
    (source_cubic_original_separation_zero_not_mem t ht A hA hm)
  refine ⟨f,?_⟩
  intro Y hY s hs
  have h := hf _ ((source_cubic_separation_region_mem _ _ _ _).mpr ⟨Y,hY,s,hs,rfl⟩)
  simpa only [map_zero] using h

end CoefficientStability
