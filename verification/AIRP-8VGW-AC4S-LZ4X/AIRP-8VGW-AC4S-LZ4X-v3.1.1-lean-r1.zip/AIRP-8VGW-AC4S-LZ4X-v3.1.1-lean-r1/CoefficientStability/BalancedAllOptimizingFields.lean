import CoefficientStability.TiltPermutation

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability

theorem balanced_all_optimizing_fields_deficit (n : ℕ) (hn : 3≤n)
    (p : MvPolynomial (Fin n) ℝ) (hp : p.IsHomogeneous n)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=1)
    (hL : p.coeff (squarefreeExponent n)≤sourceVn n*(1+capacityEta n/2)) :
    ∀ i : Fin n,∃ u : Fin n → ℝ,(∑ j,u j=0) ∧
      1≤MvPolynomial.eval (fun j => Real.exp (u j)) p ∧
      MvPolynomial.eval (fun j => Real.exp (u j)) p≤p.coeff (squarefreeExponent n)/sourceVn n ∧
      tiltedMoment p u i=1 ∧
      deficitMatrix (tiltedPolynomial p u) (tiltedMoment p u) n i i≤
        64*(p.coeff (squarefreeExponent n)/sourceVn n-1) := by
  cases n with
  | zero => omega
  | succ n =>
    intro i
    let e : Equiv.Perm (Fin (n+1)) := Equiv.swap i (Fin.last n)
    have hei : e i=Fin.last n := Equiv.swap_apply_left i (Fin.last n)
    let q := MvPolynomial.rename e p
    have hqhom : q.IsHomogeneous (n+1) := hp.rename_isHomogeneous
    have hqs : UpperHalfPlaneZeroFree q := stable_rename_polynomial p hs e
    have hqnorm : MvPolynomial.eval (fun _ => 1) q=1 := by
      simpa only [q,MvPolynomial.eval_rename,Function.comp_def] using hnorm
    have hqgrad := normalized_gradient_rename_equiv p e hgrad
    have hqL : q.coeff (squarefreeExponent (n+1))≤sourceVn (n+1)*(1+capacityEta (n+1)/2) := by
      simpa only [q,rename_equiv_squarefree_coeff] using hL
    obtain ⟨v,hv,hvlower,hvupper,hvstat,hvQ⟩ :=
      balanced_last_optimizing_field_deficit hn q hqhom hqs hqnorm hqgrad hqL
    let u : Fin (n+1) → ℝ := v∘e
    have hc := normalized_homogeneous_stable_coeff_nonneg p (n+1) hp hs hnorm
    have hZ : tiltPartition p (v∘e)≠0 := ne_of_gt (tiltPartition_pos p (v∘e) hc hnorm)
    have hsum : (∑ j,u j)=0 := (Equiv.sum_comp e v).trans hv
    have heval : MvPolynomial.eval (fun j => Real.exp (v j)) q=
        MvPolynomial.eval (fun j => Real.exp (u j)) p := by
      simp only [q,MvPolynomial.eval_rename,u,Function.comp_def]
    rw [heval] at hvlower hvupper
    rw [rename_equiv_squarefree_coeff] at hvupper hvQ
    have hm := tiltedMoment_rename_equiv p e v hZ i
    rw [hei] at hm
    have hQ := tilted_deficit_rename_equiv p e v (n+1) hZ i i
    rw [hei] at hQ
    refine ⟨u,hsum,hvlower,hvupper,hm.symm.trans hvstat,?_⟩
    rw [hQ] at hvQ
    exact hvQ

end CoefficientStability
