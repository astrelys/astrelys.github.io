import CoefficientStability.StrictLogDerivative

noncomputable section
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem stable_add_real_partial (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (i : Fin n) (c : ℝ) :
    UpperHalfPlaneZeroFree (p+MvPolynomial.C c*pderiv i p) := by
  classical
  intro z hz
  have hP : complexPolynomialUpperZeroFree (coordinateRestriction z i p) := by
    intro w hw
    rw [coordinateRestriction_eval]
    apply hp
    intro j
    by_cases hji : j=i
    · subst j;simpa only [Function.update_self] using hw
    · simpa only [Function.update_of_ne hji] using hz j
  have h := upper_zero_free_add_real_derivative (coordinateRestriction z i p) hP c (z i) (hz i)
  have heq : coordinateRestriction z i (p+MvPolynomial.C c*pderiv i p)=
      coordinateRestriction z i p+Polynomial.C (c : ℂ)*(coordinateRestriction z i p).derivative := by
    simp only [map_add,map_mul,coordinateRestriction_C,coordinateRestriction_partial]
  rw [← heq,coordinateRestriction_eval,Function.update_eq_self] at h
  exact h

def nuijPartialStep (i : Fin n) (c : ℝ) (p : MvPolynomial (Fin n) ℝ) : MvPolynomial (Fin n) ℝ :=
  p+MvPolynomial.C c*pderiv i p

theorem stable_nuij_partial_iterate (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (i : Fin n) (c : ℝ) (k : ℕ) :
    UpperHalfPlaneZeroFree ((nuijPartialStep i c)^[k] p) := by
  induction k with
  | zero => exact hp
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    exact stable_add_real_partial _ ih i c

end CoefficientStability
