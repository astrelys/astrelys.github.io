import CoefficientStability.StableRealSpecialization

noncomputable section
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def finiteRealSpecialization (s : Finset (Fin n)) (x : Fin n → ℝ) :
    MvPolynomial (Fin n) ℝ →+* MvPolynomial (Fin n) ℝ :=
  MvPolynomial.eval₂Hom MvPolynomial.C (fun j => if j∈s then MvPolynomial.C (x j) else MvPolynomial.X j)

theorem finiteRealSpecialization_empty (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ) :
    finiteRealSpecialization ∅ x p=p := by
  simp [finiteRealSpecialization]

theorem finiteRealSpecialization_insert (p : MvPolynomial (Fin n) ℝ) (s : Finset (Fin n))
    (x : Fin n → ℝ) (i : Fin n) (hi : i∉s) :
    finiteRealSpecialization (insert i s) x p=
      coordinateSpecialization i (x i) (finiteRealSpecialization s x p) := by
  classical
  induction p using MvPolynomial.induction_on with
  | C c => simp [finiteRealSpecialization,coordinateSpecialization]
  | add p q hp hq => simp only [map_add,hp,hq]
  | mul_X p j hp =>
    simp only [map_mul,hp]
    congr 1
    by_cases hji : j=i
    · subst j
      simp [finiteRealSpecialization,coordinateSpecialization,hi]
    · by_cases hjs : j∈s <;> simp [finiteRealSpecialization,coordinateSpecialization,hji,hjs]

theorem stable_finite_real_specialization_zero_or_stable (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (s : Finset (Fin n)) (x : Fin n → ℝ) :
    finiteRealSpecialization s x p=0 ∨ UpperHalfPlaneZeroFree (finiteRealSpecialization s x p) := by
  classical
  induction s using Finset.induction_on with
  | empty => simpa only [finiteRealSpecialization_empty] using (Or.inr hp : p=0 ∨ UpperHalfPlaneZeroFree p)
  | @insert i s hi ih =>
    rw [finiteRealSpecialization_insert p s x i hi]
    rcases ih with hz | hs
    · left
      simp [hz]
    · exact stable_real_specialization_zero_or_stable _ hs i (x i)

theorem finiteRealSpecialization_complex_eval (p : MvPolynomial (Fin n) ℝ)
    (s : Finset (Fin n)) (x : Fin n → ℝ) (z : Fin n → ℂ) :
    MvPolynomial.eval₂ Complex.ofRealHom z (finiteRealSpecialization s x p)=
      MvPolynomial.eval₂ Complex.ofRealHom (fun j => if j∈s then (x j : ℂ) else z j) p := by
  classical
  change (MvPolynomial.eval₂Hom Complex.ofRealHom z) (MvPolynomial.eval₂ _ _ p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c
    simp
  · funext j
    by_cases hj : j∈s <;> simp [hj]

end CoefficientStability
