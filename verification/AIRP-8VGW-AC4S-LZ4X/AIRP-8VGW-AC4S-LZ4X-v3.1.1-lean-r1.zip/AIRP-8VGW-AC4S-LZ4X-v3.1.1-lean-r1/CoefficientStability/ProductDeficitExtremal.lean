import CoefficientStability.CovarianceBridge
import CoefficientStability.ExponentialTilt
import CoefficientStability.DeterminantPartialDerivative

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def productPolynomial (n : ℕ) : MvPolynomial (Fin n) ℝ := ∏ i : Fin n,MvPolynomial.X i

theorem productPolynomial_monomial (n : ℕ) :
    productPolynomial n=MvPolynomial.monomial (squarefreeExponent n) 1 := by
  simpa only [productPolynomial,squarefreeExponent,MvPolynomial.C_1,one_mul,Finset.prod_const_one] using
    product_linear_assignment_monomial (fun i : Fin n => i) (fun _ => (1 : ℝ)) Finset.univ

theorem squarefreeExponent_value (i : Fin n) : squarefreeExponent n i=1 := by
  classical
  simp [squarefreeExponent,Finsupp.single_apply]

theorem productPolynomial_normalized (n : ℕ) : MvPolynomial.eval (fun _ => 1) (productPolynomial n)=1 := by
  simp [productPolynomial]

theorem productPolynomial_gradient (i : Fin n) :
    MvPolynomial.eval (fun _ => 1) (pderiv i (productPolynomial n))=1 := by
  rw [productPolynomial_monomial,pderiv_monomial]
  simp [squarefreeExponent_value,eval_monomial_univ]

theorem productPolynomial_diagonal_hessian (i : Fin n) :
    pderiv i (pderiv i (productPolynomial n))=0 := by
  rw [productPolynomial_monomial,pderiv_monomial,pderiv_monomial]
  simp [squarefreeExponent_value,Finsupp.tsub_apply]

theorem productPolynomial_nonnegative (n : ℕ) (d : Fin n →₀ ℕ) :
    0≤(productPolynomial n).coeff d := by
  classical
  rw [productPolynomial_monomial,MvPolynomial.coeff_monomial]
  split_ifs <;> norm_num

theorem productPolynomial_homogeneous (n : ℕ) : (productPolynomial n).IsHomogeneous n := by
  simpa only [productPolynomial,Finset.sum_const,Finset.card_univ,Fintype.card_fin,smul_eq_mul,mul_one] using
    MvPolynomial.IsHomogeneous.prod (Finset.univ : Finset (Fin n))
      (fun i => (MvPolynomial.X i : MvPolynomial (Fin n) ℝ)) (fun _ => 1)
      (fun i _ => MvPolynomial.isHomogeneous_X ℝ i)

theorem productPolynomial_stable (n : ℕ) : UpperHalfPlaneZeroFree (productPolynomial n) := by
  intro z hz
  change MvPolynomial.eval₂Hom Complex.ofRealHom z (productPolynomial n)≠0
  simp only [productPolynomial,map_prod,MvPolynomial.eval₂Hom_X']
  apply Finset.prod_ne_zero_iff.mpr
  intro i hi he
  have h := hz i
  rw [he,Complex.zero_im] at h
  exact lt_irrefl _ h

theorem paper_product_deficit_extremal (hn : 0<n) :
    referenceDeficit (productPolynomial n) (fun _ => 1) n=((n : ℝ)-1)/2 := by
  have hn0 : (n : ℝ)≠0 := by exact_mod_cast (by omega : n≠0)
  have hh : hessianTraceAtOne (productPolynomial n)=0 := by
    simp [hessianTraceAtOne,productPolynomial_diagonal_hessian]
  unfold referenceDeficit
  rw [hh]
  simp only [one_pow,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,mul_one,sub_zero]
  field_simp

end CoefficientStability
