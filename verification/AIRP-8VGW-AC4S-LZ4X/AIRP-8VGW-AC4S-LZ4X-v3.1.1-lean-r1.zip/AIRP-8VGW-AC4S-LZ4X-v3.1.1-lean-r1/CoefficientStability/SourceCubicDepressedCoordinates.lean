import CoefficientStability.SourceCubicActualDiscriminant
import CoefficientStability.StableLeadingMatrix
import CoefficientStability.CubicCoefficientMoments

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000

def sourceDepressedCubicCoordinates (t : Fin 3 → ℝ) (s x y : ℝ) : Fin 3 → ℝ :=
  ![x,y,0]+(s-(t 0*x+t 1*y)/3) • (fun _ => 1)

theorem source_depressed_cubic_coordinate_mean (t : Fin 3 → ℝ)
    (ht : ∑ i,t i=3) (s x y : ℝ) :
    (∑ i,t i*sourceDepressedCubicCoordinates t s x y i)/3=s := by
  have ht2 : t 2=3-t 0-t 1 := by
    norm_num [Fin.sum_univ_succ] at ht
    linarith
  norm_num [Fin.sum_univ_succ,sourceDepressedCubicCoordinates]
  rw [ht2]
  ring

theorem source_depressed_cubic_coordinates_recover (t : Fin 3 → ℝ)
    (ht : ∑ i,t i=3) (z : Fin 3 → ℝ) :
    sourceDepressedCubicCoordinates t ((∑ i,t i*z i)/3) (z 0-z 2) (z 1-z 2)=z := by
  have ht2 : t 2=3-t 0-t 1 := by
    norm_num [Fin.sum_univ_succ] at ht
    linarith
  funext i
  fin_cases i <;> norm_num [sourceDepressedCubicCoordinates,Fin.sum_univ_succ,ht2] <;> ring

theorem source_central_cubic_as_actual_centered_value {n : ℕ}
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (x : Fin n → ℝ) :
    MvPolynomial.eval x (centralCoefficientPolynomial p t 3 3)=
      MvPolynomial.eval (fun i => x i-(∑ j,t j*x j)/3) p := by
  rw [eval_centralCoefficientPolynomial]
  simp only [centralLineCoefficient,show 3-3=0 by rfl,lineRestriction_comp_sub,
    Polynomial.coeff_zero_eq_eval_zero]
  simpa only [zero_add,Nat.cast_ofNat] using (eval_lineRestriction_real p (fun i => x i-(∑ j,t j*x j)/3) 0)

theorem source_central_cubic_actual_translation (p : MvPolynomial (Fin 3) ℝ)
    (t : Fin 3 → ℝ) (ht : ∑ i,t i=3) (s x y : ℝ) :
    MvPolynomial.eval (sourceDepressedCubicCoordinates t s x y)
      (centralCoefficientPolynomial p t 3 3)=
    MvPolynomial.eval (![x,y,0] : Fin 3 → ℝ) (centralCoefficientPolynomial p t 3 3) := by
  rw [source_central_cubic_as_actual_centered_value,source_central_cubic_as_actual_centered_value,
    source_depressed_cubic_coordinate_mean t ht]
  apply congrArg (fun v : Fin 3 → ℝ => MvPolynomial.eval v p)
  funext i
  fin_cases i <;> norm_num [sourceDepressedCubicCoordinates,Fin.sum_univ_succ] <;> ring

end CoefficientStability
