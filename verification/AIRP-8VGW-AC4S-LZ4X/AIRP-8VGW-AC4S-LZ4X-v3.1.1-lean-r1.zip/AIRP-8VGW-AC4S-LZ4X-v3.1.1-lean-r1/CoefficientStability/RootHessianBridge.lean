import CoefficientStability.HessianQuadratic

noncomputable section
open scoped BigOperators
open Polynomial MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def centeredVariance (roots : Multiset ℝ) : ℝ :=
  ((centeredRoots roots).map (fun r => r^2)).sum / 2

theorem centeredVariance_nonneg (roots : Multiset ℝ) : 0 ≤ centeredVariance roots := by
  unfold centeredVariance
  apply div_nonneg _ (by norm_num)
  apply Multiset.sum_nonneg
  intro r hr
  obtain ⟨a,ha,rfl⟩ := Multiset.mem_map.mp hr
  exact sq_nonneg a

theorem sum_squares_sub_constant (s : Multiset ℝ) (a : ℝ) :
    (s.map (fun r => (r-a)^2)).sum =
      (s.map (fun r => r^2)).sum - 2*a*s.sum + s.card*a^2 := by
  induction s using Multiset.induction_on with
  | empty => simp
  | @cons r s ih =>
    simp only [Multiset.map_cons, Multiset.sum_cons, Multiset.card_cons, Nat.cast_add,
      Nat.cast_one, ih]
    ring

theorem centeredVariance_eq_esymm (roots : Multiset ℝ) (h : 0 < roots.card) :
    centeredVariance roots = ((roots.card : ℝ)-1)/(2*roots.card)*roots.sum^2 - roots.esymm 2 := by
  have hn : (roots.card : ℝ) ≠ 0 := by exact_mod_cast Nat.ne_zero_of_lt h
  have he := esymm_two_identity roots
  have hs : (roots.map (fun r => r^2)).sum = roots.sum^2 - 2*roots.esymm 2 := by linarith
  unfold centeredVariance centeredRoots
  rw [Multiset.map_map]
  change (roots.map (fun r => (r-roots.sum/roots.card)^2)).sum/2 = _
  rw [sum_squares_sub_constant, hs]
  field_simp
  ring

def matrixQuadratic (Q : Matrix (Fin n) (Fin n) ℝ) (x : Fin n → ℝ) : ℝ :=
  ∑ i, ∑ j, Q i j*x i*x j

theorem deficitMatrix_quadratic_formula (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (N : ℕ) (x : Fin n → ℝ) :
    matrixQuadratic (deficitMatrix p t N) x =
      ((N : ℝ)-1)/(2*N)*(∑ i, t i*x i)^2 - hessianQuadraticAtOne p x/2 := by
  unfold matrixQuadratic deficitMatrix
  simp_rw [sub_mul, Finset.sum_sub_distrib]
  have hfirst : (∑ i, ∑ j, ((N : ℝ)-1)/(2*N)*t i*t j*x i*x j) =
      ((N : ℝ)-1)/(2*N)*(∑ i, t i*x i)^2 := by
    rw [pow_two, Finset.sum_mul_sum, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i hi
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j hj
    ring
  rw [hfirst]
  congr 1
  unfold hessianQuadraticAtOne
  simp only [div_eq_mul_inv, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro j hj
  ring

theorem deficitMatrix_quadratic_is_rootVariance
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) (x : Fin n → ℝ)
    (hN : 2 ≤ N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p) = t i) :
    ∃ roots : Multiset ℝ, roots.card = N ∧
      lineRestriction p x = (roots.map (fun r => Polynomial.X + Polynomial.C r)).prod ∧
      centeredVariance roots = matrixQuadratic (deficitMatrix p t N) x := by
  obtain ⟨roots,hcard,hr,hsum⟩ := normalized_stable_line_real_factors_sum p x N (by omega) hp hnorm hstable
  refine ⟨roots,hcard,hr,?_⟩
  have hsumt : roots.sum = ∑ i, t i*x i := by simpa only [hgrad] using hsum
  have hv := Multiset.prod_X_add_C_coeff roots (k := N-2) (by omega)
  have hnn : N-(N-2)=2 := by omega
  rw [hcard, hnn, ← hr] at hv
  have hsecond := lineRestriction_second_coefficient p x N hN hp
  rw [hv] at hsecond
  rw [centeredVariance_eq_esymm roots (by omega), hcard, hsumt, deficitMatrix_quadratic_formula]
  linarith

theorem deficitMatrix_quadratic_nonneg
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) (x : Fin n → ℝ)
    (hN : 2 ≤ N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p) = t i) :
    0 ≤ matrixQuadratic (deficitMatrix p t N) x := by
  obtain ⟨roots,hcard,hr,he⟩ := deficitMatrix_quadratic_is_rootVariance p t N x hN hp hnorm hstable hgrad
  rw [← he]
  exact centeredVariance_nonneg roots

end CoefficientStability
