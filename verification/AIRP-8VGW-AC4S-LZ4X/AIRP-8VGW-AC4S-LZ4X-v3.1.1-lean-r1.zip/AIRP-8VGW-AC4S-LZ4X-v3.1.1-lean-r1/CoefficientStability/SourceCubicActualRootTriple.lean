import CoefficientStability.SourceCubicActualDiscriminant

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000

theorem source_stable_cubic_actual_centered_root_triple {n : ℕ}
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hp : p.IsHomogeneous 3) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (x : Fin n → ℝ) :
    ∃ a b c : ℝ,a+b+c=0 ∧ a*b+a*c+b*c= -matrixQuadratic (deficitMatrix p t 3) x ∧
      a*b*c=MvPolynomial.eval x (centralCoefficientPolynomial p t 3 3) := by
  obtain ⟨roots,hcard,hv,he⟩ := centralLineCoefficient_eq_centered_esymm p t 3 x (by omega) hp hn hs hg
  have hsum := centeredRoots_sum roots (by omega)
  have hc : (centeredRoots roots).card=3 := by rw [centeredRoots_card,hcard]
  obtain ⟨a,b,c,habc⟩ := Multiset.card_eq_three.mp hc
  have hq := (paper_first_second_central_coefficients p t 3 x (by omega) hp hn hs hg).2
  rw [he 2 (by omega),habc] at hq
  have hd := he 3 (by omega)
  rw [habc,← eval_centralCoefficientPolynomial] at hd
  rw [habc] at hsum
  simp at hsum
  have h2 : ({a,b,c} : Multiset ℝ).esymm 2=a*b+a*c+b*c := by
    norm_num [esymm_cons,esymm_one,Multiset.esymm,Multiset.powersetCard_one]
    ring
  rw [h2] at hq
  have h3 : MvPolynomial.eval x (centralCoefficientPolynomial p t 3 3)=a*b*c := by
    simpa [Multiset.esymm,Multiset.powersetCard_one,mul_assoc] using hd
  exact ⟨a,b,c,by linarith,hq,h3.symm⟩

theorem source_actual_centered_root_triple_product (a b c q d : ℝ)
    (hs : a+b+c=0) (hq : a*b+a*c+b*c= -q) (hd : a*b*c=d) (s r : ℝ) :
    s^3-s*q*r^2+d*r^3=(s+a*r)*(s+b*r)*(s+c*r) := by
  have he : (s+a*r)*(s+b*r)*(s+c*r)=
      s^3+(a+b+c)*s^2*r+(a*b+a*c+b*c)*s*r^2+(a*b*c)*r^3 := by ring
  rw [hs,hq,hd] at he
  nlinarith only [he]

end CoefficientStability
