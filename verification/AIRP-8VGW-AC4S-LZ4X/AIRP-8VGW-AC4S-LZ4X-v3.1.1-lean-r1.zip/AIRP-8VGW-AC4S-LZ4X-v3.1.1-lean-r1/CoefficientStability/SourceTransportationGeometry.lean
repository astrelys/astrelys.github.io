import CoefficientStability.SourceEuclideanEqualityFaces
import CoefficientStability.SourceTernaryZeroPatterns
import Mathlib.Topology.Order.Compact

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
variable {n : ℕ}

def sourcePermutedMatrix (B : Matrix (Fin n) (Fin n) ℝ) (r c : Equiv.Perm (Fin n)) : Matrix (Fin n) (Fin n) ℝ :=
  B.submatrix r c

def sourcePermutedTraces (t : Fin n → ℝ) (r : Equiv.Perm (Fin n)) : Fin n → ℝ := fun i => t (r i)

theorem source_permuted_permanent (B : Matrix (Fin n) (Fin n) ℝ) (r c : Equiv.Perm (Fin n)) :
    Matrix.permanent (sourcePermutedMatrix B r c)=Matrix.permanent B := by
  change Matrix.permanent ((B.submatrix id c).submatrix r id)=_
  rw [Matrix.permanent_permute_cols,Matrix.permanent_permute_rows]

theorem source_permuted_feasible (t : Fin n → ℝ) (B : Matrix (Fin n) (Fin n) ℝ)
    (hB : B ∈ sourceTransportationPolytope t) (r c : Equiv.Perm (Fin n)) :
    sourcePermutedMatrix B r c ∈ sourceTransportationPolytope (sourcePermutedTraces t r) := by
  refine ⟨fun i j => hB.1 (r i) (c j),?_,?_⟩
  · intro i
    change (∑ j,B (r i) (c j))=t (r i)
    exact (Equiv.sum_comp c (fun j : Fin n => B (r i) j)).trans (hB.2.1 (r i))
  · intro j
    change (∑ i,B (r i) (c j))=1
    exact (Equiv.sum_comp r (fun i : Fin n => B i (c j))).trans (hB.2.2 (c j))

theorem source_permuted_matrix_inverse (B : Matrix (Fin n) (Fin n) ℝ) (r c : Equiv.Perm (Fin n)) :
    sourcePermutedMatrix (sourcePermutedMatrix B r c) r.symm c.symm=B := by
  ext i j
  simp [sourcePermutedMatrix,Matrix.submatrix_apply]

theorem source_permuted_traces_inverse (t : Fin n → ℝ) (r : Equiv.Perm (Fin n)) :
    sourcePermutedTraces (sourcePermutedTraces t r) r.symm=t := by
  funext i
  simp [sourcePermutedTraces]

theorem source_permuted_global_minimum (t : Fin n → ℝ) (B : Matrix (Fin n) (Fin n) ℝ)
    (hmin : IsMinOn Matrix.permanent (sourceTransportationPolytope t) B) (r c : Equiv.Perm (Fin n)) :
    IsMinOn Matrix.permanent (sourceTransportationPolytope (sourcePermutedTraces t r)) (sourcePermutedMatrix B r c) := by
  intro X hX
  have hY := source_permuted_feasible (sourcePermutedTraces t r) X hX r.symm c.symm
  rw [source_permuted_traces_inverse] at hY
  have h := hmin hY
  change Matrix.permanent B ≤ Matrix.permanent (sourcePermutedMatrix X r.symm c.symm) at h
  change Matrix.permanent (sourcePermutedMatrix B r c) ≤ Matrix.permanent X
  simpa only [source_permuted_permanent] using h

theorem source_permuted_trace_sum (t : Fin n → ℝ) (r : Equiv.Perm (Fin n)) :
    (∑ i,sourcePermutedTraces t r i)=∑ i,t i := Equiv.sum_comp r t

theorem source_permuted_radius (t : Fin n → ℝ) (r : Equiv.Perm (Fin n)) :
    (∑ i,(sourcePermutedTraces t r i-1)^2)=∑ i,(t i-1)^2 := Equiv.sum_comp r (fun i => (t i-1)^2)

theorem source_permuted_ternary_baseline (t : Fin 3 → ℝ) (r : Equiv.Perm (Fin 3)) :
    sourceTernaryBaseline (sourcePermutedTraces t r)=sourceTernaryBaseline t := by
  rw [source_ternary_baseline_literal,source_ternary_baseline_literal]
  change sourceVn 3*(∏ i,t (r i))=sourceVn 3*(∏ i,t i)
  rw [Equiv.prod_comp r]

theorem source_transportation_closed (t : Fin n → ℝ) : IsClosed (sourceTransportationPolytope t) := by
  have hn : IsClosed (⋂ i : Fin n,⋂ j : Fin n,{B : Matrix (Fin n) (Fin n) ℝ | 0 ≤ B i j}) :=
    isClosed_iInter (fun i => isClosed_iInter (fun j => isClosed_le continuous_const (by fun_prop)))
  have hr : IsClosed (⋂ i : Fin n,{B : Matrix (Fin n) (Fin n) ℝ | (∑ j,B i j)=t i}) :=
    isClosed_iInter (fun i => isClosed_eq (by fun_prop) continuous_const)
  have hc : IsClosed (⋂ j : Fin n,{B : Matrix (Fin n) (Fin n) ℝ | (∑ i,B i j)=1}) :=
    isClosed_iInter (fun j => isClosed_eq (by fun_prop) continuous_const)
  convert! hn.inter (hr.inter hc) using 1
  ext B
  simp [sourceTransportationPolytope]

theorem source_transportation_compact (t : Fin n → ℝ) : IsCompact (sourceTransportationPolytope t) := by
  apply (isCompact_Icc : IsCompact (Set.Icc (0 : Fin n → Fin n → ℝ) (fun _ _ => 1))).of_isClosed_subset (source_transportation_closed t)
  intro B hB
  refine ⟨fun i j => hB.1 i j,?_⟩
  intro i j
  have h := Finset.single_le_sum (fun k (_ : k ∈ Finset.univ) => hB.1 k j) (Finset.mem_univ i)
  simpa only [hB.2.2 j] using h

theorem source_permanent_continuous : Continuous (Matrix.permanent (n := Fin n) (R := ℝ)) := by
  unfold Matrix.permanent
  fun_prop

theorem source_ternary_reference_feasible (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (htpos : ∀ i,0 < t i) :
    sourcePermanentReference t ∈ sourceTransportationPolytope t := by
  obtain ⟨hrow,hcol⟩ := source_ternary_reference_marginals t ht
  exact ⟨fun i j => (div_pos (htpos i) (by norm_num)).le,hrow,hcol⟩

theorem source_ternary_global_minimum_exists (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (htpos : ∀ i,0 < t i) :
    ∃ B ∈ sourceTransportationPolytope t,IsMinOn Matrix.permanent (sourceTransportationPolytope t) B :=
  (source_transportation_compact t).exists_isMinOn ⟨sourcePermanentReference t,source_ternary_reference_feasible t ht htpos⟩ source_permanent_continuous.continuousOn

end CoefficientStability
