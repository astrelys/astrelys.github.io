import CoefficientStability.CentralBounds

noncomputable section
open scoped BigOperators
open Polynomial MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def centralLift (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) :
    MvPolynomial (Option (Fin n)) ℝ :=
  MvPolynomial.aeval (fun i => MvPolynomial.X none + MvPolynomial.X (some i) -
    MvPolynomial.rename some (scalarLinear t N)) p

def centralPolynomial (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) :
    Polynomial (MvPolynomial (Fin n) ℝ) :=
  MvPolynomial.optionEquivLeft ℝ (Fin n) (centralLift p t N)

def centralCoefficientPolynomial (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (N k : ℕ) : MvPolynomial (Fin n) ℝ := (centralPolynomial p t N).coeff (N-k)

theorem centralLift_homogeneous (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) : (centralLift p t N).IsHomogeneous N := by
  unfold centralLift
  simpa using hp.aeval _ (fun i =>
    ((MvPolynomial.isHomogeneous_X (R := ℝ) none).add
      (MvPolynomial.isHomogeneous_X (R := ℝ) (some i))).sub
        (scalarLinear_homogeneous t N).rename_isHomogeneous)

theorem centralCoefficientPolynomial_homogeneous
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N k : ℕ)
    (hk : k ≤ N) (hp : p.IsHomogeneous N) :
    (centralCoefficientPolynomial p t N k).IsHomogeneous k := by
  apply MvPolynomial.IsHomogeneous.coeff_isHomogeneous_of_optionEquivLeft_symm
    (p := centralPolynomial p t N) (n := N)
  · simpa only [centralPolynomial, AlgEquiv.symm_apply_apply] using
      centralLift_homogeneous p t N hp
  · omega

theorem optionEquivLeft_rename_some (f : MvPolynomial (Fin n) ℝ) :
    MvPolynomial.optionEquivLeft ℝ (Fin n) (MvPolynomial.rename some f) = Polynomial.C f := by
  induction f using MvPolynomial.induction_on with
  | C c => simp
  | add f g hf hg => simp [hf,hg]
  | mul_X f i hf => simp [hf]

theorem centralPolynomial_as_substitution
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) :
    centralPolynomial p t N = MvPolynomial.eval₂ (Polynomial.C.comp MvPolynomial.C)
      (fun i => Polynomial.X+Polynomial.C (MvPolynomial.X i)-Polynomial.C (scalarLinear t N)) p := by
  unfold centralPolynomial centralLift
  change (MvPolynomial.optionEquivLeft ℝ (Fin n)).toRingHom
    (MvPolynomial.eval₂ MvPolynomial.C _ p) = _
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext r
    simp
  · funext i
    simp [optionEquivLeft_rename_some]

theorem centralPolynomial_map_eval
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) (x : Fin n → ℝ) :
    (centralPolynomial p t N).map (MvPolynomial.eval x) =
      (lineRestriction p x).comp
        (Polynomial.X-Polynomial.C ((∑ i, t i*x i)/N)) := by
  rw [centralPolynomial_as_substitution]
  change (Polynomial.mapRingHom (MvPolynomial.eval x)) (MvPolynomial.eval₂ _ _ p) = _
  rw [MvPolynomial.hom_eval₂]
  unfold lineRestriction
  change _ = (Polynomial.compRingHom (Polynomial.X-Polynomial.C ((∑ i, t i*x i)/N))) (MvPolynomial.eval₂ (Polynomial.C : ℝ →+* ℝ[X]) (fun i => Polynomial.X+Polynomial.C (x i)) p)
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext r
    simp
  · funext i
    change (Polynomial.X+Polynomial.C (MvPolynomial.X i)-Polynomial.C (scalarLinear t N)).map (MvPolynomial.eval x) =
      (Polynomial.X+Polynomial.C (x i)).comp (Polynomial.X-Polynomial.C ((∑ i, t i*x i)/N))
    simp only [Polynomial.map_sub,Polynomial.map_add,Polynomial.map_X,Polynomial.map_C,MvPolynomial.eval_X,
      Polynomial.add_comp,Polynomial.X_comp,Polynomial.C_comp]
    have he : MvPolynomial.eval x (scalarLinear t N) = (∑ i, t i*x i)/N := by
      simp only [scalarLinear,map_sum,map_mul,MvPolynomial.eval_C,MvPolynomial.eval_X]
      rw [Finset.sum_div]
      apply Finset.sum_congr rfl
      intro j hj
      ring
    rw [he]
    ring

theorem eval_centralCoefficientPolynomial
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N k : ℕ) (x : Fin n → ℝ) :
    MvPolynomial.eval x (centralCoefficientPolynomial p t N k) =
      centralLineCoefficient p t N x k := by
  have h := congrArg (fun f : ℝ[X] => f.coeff (N-k)) (centralPolynomial_map_eval p t N x)
  simpa [centralCoefficientPolynomial,centralLineCoefficient,Polynomial.coeff_map] using h

theorem paper_central_coefficient_zero
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) (x : Fin n → ℝ)
    (hp : p.IsHomogeneous N) (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) :
    centralLineCoefficient p t N x 0 = 1 := by
  have hm := (normalized_lineRestriction_monic p x N hp hnorm).comp_X_sub_C ((∑ i, t i*x i)/N)
  have hd : ((lineRestriction p x).comp (Polynomial.X-Polynomial.C ((∑ i,t i*x i)/N))).natDegree = N := by
    rw [Polynomial.natDegree_comp,normalized_lineRestriction_natDegree p x N hp hnorm]
    simp
  simpa only [centralLineCoefficient,Nat.sub_zero,hd] using hm.coeff_natDegree

theorem central_evaluation_expansion
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) (x : Fin n → ℝ)
    (hp : p.IsHomogeneous N) (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) :
    MvPolynomial.eval x p = ∑ k ∈ Finset.range (N+1),
      centralLineCoefficient p t N x k * ((∑ i,t i*x i)/N)^(N-k) := by
  let L : ℝ := (∑ i,t i*x i)/N
  let q := (lineRestriction p x).comp (Polynomial.X-Polynomial.C L)
  have hd : q.natDegree = N := by
    dsimp only [q]
    rw [Polynomial.natDegree_comp,normalized_lineRestriction_natDegree p x N hp hnorm]
    simp
  have he : q.eval L = MvPolynomial.eval x p := by
    simp only [q,Polynomial.eval_comp,Polynomial.eval_sub,Polynomial.eval_X,Polynomial.eval_C,sub_self]
    simpa using eval_lineRestriction_real p x 0
  rw [← he,Polynomial.eval_eq_sum_range' (n := N+1) (by omega)]
  rw [← Finset.sum_range_reflect]
  apply Finset.sum_congr rfl
  intro k hk
  simp only [Nat.add_sub_cancel,centralLineCoefficient,L,q]

theorem paper_central_expansion
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) (x : Fin n → ℝ)
    (hN : 2 ≤ N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p) = t i) :
    MvPolynomial.eval x p = ((∑ i,t i*x i)/N)^N -
      ((∑ i,t i*x i)/N)^(N-2)*matrixQuadratic (deficitMatrix p t N) x +
      ∑ j ∈ Finset.range (N-2), ((∑ i,t i*x i)/N)^(N-(j+3))*
        MvPolynomial.eval x (centralCoefficientPolynomial p t N (j+3)) := by
  have he := central_evaluation_expansion p t N x hp hnorm
  have h01 := paper_central_coefficient_zero p t N x hp hnorm
  obtain ⟨h1,h2⟩ := paper_first_second_central_coefficients p t N x hN hp hnorm hstable hgrad
  have hs : N+1=3+(N-2) := by omega
  rw [hs,Finset.sum_range_add] at he
  have hsmall : (∑ k ∈ Finset.range 3, centralLineCoefficient p t N x k *
      ((∑ i,t i*x i)/N)^(N-k)) = ((∑ i,t i*x i)/N)^N -
      ((∑ i,t i*x i)/N)^(N-2)*matrixQuadratic (deficitMatrix p t N) x := by
    simp [Finset.sum_range_succ,h01,h1,h2]
    ring
  rw [hsmall] at he
  rw [he]
  congr 1
  apply Finset.sum_congr rfl
  intro j hj
  rw [eval_centralCoefficientPolynomial]
  simp only [Nat.add_comm 3 j,mul_comm]

end CoefficientStability
