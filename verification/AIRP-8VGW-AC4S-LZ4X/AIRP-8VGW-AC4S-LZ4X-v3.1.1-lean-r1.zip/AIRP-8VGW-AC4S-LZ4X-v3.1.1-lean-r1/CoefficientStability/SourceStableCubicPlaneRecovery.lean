import CoefficientStability.SourceStableCubicPlaneDegree
import CoefficientStability.PolynomialLinearSubstitution

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

def sourceCubicPlaneScale (x : Fin 3 → ℝ) : ℝ := 3*x 2-x 0-x 1

theorem source_cubic_plane_homogeneous_evaluation (p : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3) (x : Fin 3 → ℝ) (hx : sourceCubicPlaneScale x ≠ 0) :
    MvPolynomial.eval x p=(sourceCubicPlaneScale x)^3*
      MvPolynomial.eval (![ (x 0-x 2)/sourceCubicPlaneScale x,
        (x 1-x 2)/sourceCubicPlaneScale x] : Fin 2 → ℝ) (sourceCubicPlanePolynomial p) := by
  let s := sourceCubicPlaneScale x
  let u : Fin 2 → ℝ := ![(x 0-x 2)/s,(x 1-x 2)/s]
  have he : (fun i => s*sourceCubicPlanePoint u i)=x := by
    funext i
    have hi := source_cubic_plane_homogeneous_inverse x i
    dsimp [sourceCubicPlanePoint,u]
    dsimp [s] at *
    field_simp [hx]
    dsimp [sourceCubicPlaneScale] at *
    nlinarith [hi]
  rw [source_cubic_plane_actual_evaluation]
  have h := homogeneous_eval_real_scale p 3 hp s (sourceCubicPlanePoint u)
  rw [he] at h
  exact h

theorem source_cubic_plane_homogeneous_injective (p q : MvPolynomial (Fin 3) ℝ)
    (hp : p.IsHomogeneous 3) (hq : q.IsHomogeneous 3)
    (he : sourceCubicPlanePolynomial p=sourceCubicPlanePolynomial q) : p=q := by
  have hnonzero (x : Fin 3 → ℝ) (hx : sourceCubicPlaneScale x≠0) : MvPolynomial.eval x p=MvPolynomial.eval x q := by
    rw [source_cubic_plane_homogeneous_evaluation p hp x hx,
      source_cubic_plane_homogeneous_evaluation q hq x hx,he]
  apply MvPolynomial.funext
  intro x
  have hpoly : affineDirectionalRestriction p x (fun _ => 1)=affineDirectionalRestriction q x (fun _ => 1) := by
    apply Polynomial.eq_of_infinite_eval_eq
    apply ((Set.infinite_univ : (Set.univ : Set ℝ).Infinite).sdiff (Set.finite_singleton (-sourceCubicPlaneScale x))).mono
    intro s hs
    change s∈{a : ℝ | (affineDirectionalRestriction p x (fun _ => 1)).eval a=
      (affineDirectionalRestriction q x (fun _ => 1)).eval a}
    rw [Set.mem_setOf_eq,affineDirectionalRestriction_eval,affineDirectionalRestriction_eval]
    apply hnonzero
    have hs' : s≠ -sourceCubicPlaneScale x := by simpa using hs.2
    dsimp [sourceCubicPlaneScale]
    simp only [mul_one]
    intro hz
    apply hs'
    dsimp [sourceCubicPlaneScale]
    linarith
  have h := congrArg (fun P : Polynomial ℝ => P.eval 0) hpoly
  simpa only [affineDirectionalRestriction_eval,zero_mul,add_zero] using h

end CoefficientStability
