import CoefficientStability.PositiveRootCoefficients
import CoefficientStability.LineCoefficientContinuity

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def positiveSpectralCone (p : MvPolynomial (Fin n) ℝ) (N : ℕ) : Set (Fin n → ℝ) :=
  {x | ∃ roots : Multiset ℝ,roots.card=N ∧ (∀ r∈roots,0<r) ∧
    lineRestriction p x=(roots.map (fun r => Polynomial.X+Polynomial.C r)).prod}

theorem positiveSpectralCone_eq_coefficientPositiveCone (p : MvPolynomial (Fin n) ℝ)
    (N : ℕ) (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) :
    positiveSpectralCone p N=coefficientPositiveCone p N := by
  ext x
  constructor
  · rintro ⟨roots,hcard,hr,hfactor⟩
    intro k
    rw [hfactor]
    exact (positive_root_product_coefficients roots hr).2 k.val (by rw [hcard];exact Nat.le_of_lt_succ k.isLt)
  · intro hcoeff
    let P := lineRestriction p x
    have hd : P.natDegree=N := normalized_lineRestriction_natDegree p x N hp hnorm
    have hc : ∀ k,0≤P.coeff k := by
      intro k
      by_cases hk : k≤N
      · exact (hcoeff ⟨k,by omega⟩).le
      · rw [Polynomial.coeff_eq_zero_of_natDegree_lt (by omega)]
    have hc0 : 0<P.coeff 0 := hcoeff ⟨0,by omega⟩
    have hpositive : ∀ t : ℝ,0<t → 0<P.eval t := by
      intro t ht
      exact lt_of_lt_of_le hc0 (univariate_constant_coeff_le_eval P hc t ht.le)
    have hzero : 0<P.eval 0 := by simpa only [Polynomial.coeff_zero_eq_eval_zero] using hc0
    obtain ⟨roots,hcard,hr,hlead,hfactor⟩ := positive_constant_split_positive_multiset_factors P
      (lineRestriction_splits p hs x) hpositive hzero
    have hm : P.Monic := normalized_lineRestriction_monic p x N hp hnorm
    refine ⟨roots,hcard.trans hd,hr,?_⟩
    simpa only [hm.leadingCoeff,Polynomial.C_1,one_mul] using hfactor

theorem positiveSpectralCone_isOpen (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) : IsOpen (positiveSpectralCone p N) := by
  rw [positiveSpectralCone_eq_coefficientPositiveCone p N hp hs hnorm]
  exact coefficientPositiveCone_isOpen p N

theorem positive_input_mem_spectral_cone (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (x : Fin n → ℝ) (hx : ∀ i,0<x i) : x∈positiveSpectralCone p N := by
  have hc := normalized_homogeneous_stable_coeff_nonneg p N hp hs hnorm
  have hpos : ∀ t : ℝ,0<t → 0<(lineRestriction p x).eval t := by
    intro t ht
    rw [eval_lineRestriction_real]
    exact nonnegative_coeff_eval_pos p (stable_polynomial_ne_zero p hs) hc _ (fun i => by linarith [hx i])
  have hzero : 0<(lineRestriction p x).eval 0 := by
    rw [eval_lineRestriction_real]
    simpa only [zero_add] using nonnegative_coeff_eval_pos p (stable_polynomial_ne_zero p hs) hc x hx
  obtain ⟨roots,hcard,hr,hlead,hfactor⟩ := positive_constant_split_positive_multiset_factors
    (lineRestriction p x) (lineRestriction_splits p hs x) hpos hzero
  have hm := normalized_lineRestriction_monic p x N hp hnorm
  refine ⟨roots,hcard.trans (normalized_lineRestriction_natDegree p x N hp hnorm),hr,?_⟩
  simpa only [hm.leadingCoeff,Polynomial.C_1,one_mul] using hfactor

end CoefficientStability
