import CoefficientStability.SourceNonnegativePolynomialRoots

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

theorem source_nonnegative_polynomial_norm_quadratic_factor (p : Polynomial ℝ)
    (hp : ∀ x : ℝ,0 ≤ p.eval x) (z : ℂ) (hz : Polynomial.aeval z p=0) :
    ∃ q : Polynomial ℝ,(∀ x : ℝ,0 ≤ q.eval x) ∧ p=sourceComplexRootNormQuadratic z*q := by
  by_cases him : z.im=0
  · have hre : z=(z.re : ℂ) := by
      apply Complex.ext
      · simp
      · simpa using him
    have hr : p.eval z.re=0 := by
      apply Polynomial.isRoot_of_aeval_algebraMap_eq_zero (S := ℂ)
      change Polynomial.aeval (z.re : ℂ) p=0
      rw [← hre]
      exact hz
    obtain ⟨q,hq⟩ := source_nonnegative_polynomial_real_square_divisor p hp z.re hr
    have he : sourceComplexRootNormQuadratic z=(Polynomial.X-Polynomial.C z.re)^2 := by
      apply Polynomial.funext
      intro x
      rw [source_complex_root_norm_quadratic_eval]
      simp [him]
    refine ⟨q,source_nonnegative_polynomial_square_quotient p q hp z.re hq,?_⟩
    rw [he]
    exact hq
  · have hd : sourceComplexRootNormQuadratic z ∣ p := by
      have h := Polynomial.quadratic_dvd_of_aeval_eq_zero_im_ne_zero p hz him
      simpa only [sourceComplexRootNormQuadratic,Complex.normSq_eq_norm_sq] using h
    obtain ⟨q,hq⟩ := hd
    refine ⟨q,?_,hq⟩
    intro x
    have hpos : 0 < (sourceComplexRootNormQuadratic z).eval x := by
      rw [source_complex_root_norm_quadratic_eval]
      exact add_pos_of_nonneg_of_pos (sq_nonneg _) (sq_pos_of_ne_zero him)
    have h := hp x
    rw [hq,Polynomial.eval_mul] at h
    exact nonneg_of_mul_nonneg_left (by simpa only [mul_comm] using h) hpos

theorem source_nonnegative_polynomial_norm_factor_degree (p q : Polynomial ℝ)
    (hp : p≠0) (z : ℂ) (he : p=sourceComplexRootNormQuadratic z*q) :
    p.natDegree=2+q.natDegree ∧ q.natDegree < p.natDegree := by
  have hq : q≠0 := by
    intro hz
    rw [hz,mul_zero] at he
    exact hp he
  have hf : sourceComplexRootNormQuadratic z≠0 := by
    intro hz
    have h := source_complex_root_norm_quadratic_degree z
    rw [hz,Polynomial.natDegree_zero] at h
    norm_num at h
  have hd : p.natDegree=2+q.natDegree := by
    rw [he,Polynomial.natDegree_mul hf hq,source_complex_root_norm_quadratic_degree]
  exact ⟨hd,by omega⟩

end CoefficientStability
