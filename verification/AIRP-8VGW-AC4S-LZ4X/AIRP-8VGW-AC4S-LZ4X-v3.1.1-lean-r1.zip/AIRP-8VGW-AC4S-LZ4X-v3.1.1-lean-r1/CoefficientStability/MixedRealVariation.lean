import CoefficientStability.SourceMixedHessian
import Mathlib.Analysis.Complex.RealDeriv

noncomputable section
open scoped BigOperators Matrix.Norms.Elementwise
namespace CoefficientStability
variable {n : ℕ}

theorem actual_mixed_curve_second_hasDerivAt
    (A H : Fin n → Matrix (Fin n) (Fin n) ℂ) (s : ℂ) :
    HasDerivAt (fun z : ℂ => deriv (fun w : ℂ => complexMixedDiscriminant (A+w • H)) z)
      (∑ i,∑ j,complexMixedDiscriminant
        (Function.update (Function.update (A+s • H) i (H i)) j ((Function.update H i 0) j))) s := by
  have he : (fun z : ℂ => deriv (fun w : ℂ => complexMixedDiscriminant (A+w • H)) z)=
      (fun z : ℂ => ∑ i,complexMixedDiscriminant (Function.update (A+z • H) i (H i))) :=
    funext (actual_mixed_curve_derivative A H)
  rw [he]
  exact HasDerivAt.fun_sum (u := Finset.univ) (fun i hi => actual_mixed_comp_hasDerivAt
    (fun z : ℂ => Function.update (A+z • H) i (H i)) (Function.update H i 0) s
    (updated_affine_tuple_hasDerivAt A H s i))

theorem real_second_derivative_of_complex (e : ℂ → ℂ)
    (he : Differentiable ℂ e) (he2 : DifferentiableAt ℂ (deriv e) 0) :
    deriv (fun s : ℝ => deriv (fun z : ℝ => (e z).re) s) 0=(deriv (deriv e) 0).re := by
  have hfirst (s : ℝ) : deriv (fun z : ℝ => (e z).re) s=(deriv e (s : ℂ)).re :=
    (he (s : ℂ)).hasDerivAt.real_of_complex.deriv
  simp_rw [hfirst]
  have h := he2.hasDerivAt.real_of_complex
  simpa only [Complex.ofReal_zero] using h.deriv

theorem actual_mixed_real_second_derivative (A H : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    deriv (fun s : ℝ => deriv (fun z : ℝ => hermitianMixedObjective (A+(z : ℂ) • H)) s) 0=
      (deriv (fun s : ℂ => deriv (fun z : ℂ => complexMixedDiscriminant (A+z • H)) s) 0).re := by
  unfold hermitianMixedObjective
  apply real_second_derivative_of_complex (fun z : ℂ => complexMixedDiscriminant (A+z • H))
  · intro s
    exact (actual_mixed_comp_hasDerivAt _ H s (affine_tuple_hasDerivAt A H s)).differentiableAt
  · exact (actual_mixed_curve_second_hasDerivAt A H 0).differentiableAt

theorem paper_real_scalar_hessian (t : Fin n → ℝ) (hn : 2≤n) (htpos : ∀ i,0<t i)
    (A : Fin n → Matrix (Fin n) (Fin n) ℂ)
    (htrace : ∀ i,Matrix.trace (A i)=0) (hA : ∀ i,(A i).IsHermitian) :
    deriv (fun s : ℝ => deriv (fun z : ℝ =>
      hermitianMixedObjective (complexReferenceTuple t+(z : ℂ) • A)) s) 0=sourceHessianCandidate t A := by
  rw [actual_mixed_real_second_derivative,paper_actual_scalar_hessian t hn htpos A htrace hA]

end CoefficientStability
