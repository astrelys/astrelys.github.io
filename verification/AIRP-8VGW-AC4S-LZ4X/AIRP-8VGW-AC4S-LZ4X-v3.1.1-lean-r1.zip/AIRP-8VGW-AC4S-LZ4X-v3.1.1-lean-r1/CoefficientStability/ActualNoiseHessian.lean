import CoefficientStability.TiltLogHessian
import CoefficientStability.UniformMixingRecovery

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem actual_routed_log_hessian_lower (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (hcoeff : ∀ g,0≤p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (M : Matrix (Fin n) (Fin n) ℝ) (hrow : ∀ i,∑ j,M i j=1)
    (r : ℝ) (hr : 0≤r) (hmin : ∀ i j,r≤M i j)
    (u v : Fin n → ℝ) (hu : (∑ j,u j^2)≤1) (hv : ∑ j,v j=0) :
    ((n : ℝ)*r/8)*(∑ j,v j^2)≤matrixQuadratic (actualLogHessian (matrixSubstitution M p) u) v := by
  have huabs (j : Fin n) : |u j|≤1 := coordinate_abs_le_one_of_square_sum u hu j
  have hden (i : Fin n) : 0<routingDenominator M u i :=
    (Real.exp_pos _).trans_le (routingDenominator_bounds M u i (fun j => hr.trans (hmin i j)) (hrow i) huabs).1
  have hZ : tiltPartition (matrixSubstitution M p) u≠0 := by
    rw [routing_partition_identity M p u hden]
    exact ne_of_gt (tiltPartition_pos p (logRoutingField M u) hcoeff hnorm)
  rw [actualLogHessian_eq_covariance _ u hZ]
  exact actual_routed_polynomial_covariance_lower p hp hcoeff hnorm M hrow r hr hmin u v hu hv

theorem paper_noise_hessian_from_nonnegative_unmixing (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (r : ℝ) (hr : 0≤r) (ha : 0<1-(n : ℝ)*r)
    (hUnmixed : ∀ g,0≤(uniformUnmixedPolynomial p n r).coeff g)
    (u v : Fin n → ℝ) (hu : (∑ j,u j^2)≤1) (hv : ∑ j,v j=0) :
    ((n : ℝ)*r/8)*(∑ j,v j^2)≤matrixQuadratic (actualLogHessian p u) v := by
  have h := actual_routed_log_hessian_lower (uniformUnmixedPolynomial p n r)
    (uniformUnmixedPolynomial_homogeneous p n r hp) hUnmixed
    (uniformUnmixedPolynomial_normalized p n r hp hnorm (ne_of_gt ha))
    (uniformMixingMatrix n r) (uniformMixingMatrix_row_sum n r) r hr
    (uniformMixingMatrix_entry_lower n r ha.le) u v hu hv
  rw [uniformUnmixedPolynomial_recovers p n r hp (ne_of_gt ha)] at h
  exact h

theorem paper_noise_literal_hessian_from_nonnegative_unmixing (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (r : ℝ) (hr : 0≤r) (ha : 0<1-(n : ℝ)*r)
    (hUnmixed : ∀ g,0≤(uniformUnmixedPolynomial p n r).coeff g)
    (u v : Fin n → ℝ) (hu : (∑ j,u j^2)≤1) (hv : ∑ j,v j=0) :
    ((n : ℝ)*r/8)*(∑ j,v j^2)≤matrixQuadratic
      (fun i j => (fderiv ℝ (fun w : Fin n → ℝ =>
        (fderiv ℝ (fun z : Fin n → ℝ => Real.log (MvPolynomial.eval (fun k => Real.exp (z k)) p)) w)
          (Pi.single i (1 : ℝ))) u) (Pi.single j (1 : ℝ))) v := by
  simp only [← tiltPartition_eval_exp_all]
  change ((n : ℝ)*r/8)*(∑ j,v j^2)≤matrixQuadratic (actualLogHessian p u) v
  exact paper_noise_hessian_from_nonnegative_unmixing p hp hnorm r hr ha hUnmixed u v hu hv

end CoefficientStability
