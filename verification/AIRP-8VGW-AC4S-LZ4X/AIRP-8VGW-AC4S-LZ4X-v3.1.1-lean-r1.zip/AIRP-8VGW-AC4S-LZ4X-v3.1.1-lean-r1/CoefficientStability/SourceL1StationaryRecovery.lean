import CoefficientStability.SourceL1ChartBasics
import CoefficientStability.SourceRealZeroPatternBridge

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1600000

theorem source_l1_oriented_parameters (a b d : ℝ)
    (ha : 1/2 < a) (ha1 : a < 1) (hb : 0 < b) (hb1 : b < 1/2)
    (hrel : 4*a*b=(1-d)*(2*(a+b)-1))
    (hthird : 0 < b*(2-2*d-2*a)) :
    ∃ u v : ℝ,0 < u ∧ 0 < v ∧ u+v < 1 ∧
      a=(1+v)/2 ∧ b=(1-u)/2 ∧ d=sourceL1ChartD u v := by
  let u := 1-2*b
  let v := 2*a-1
  have hu : 0 < u := by dsimp [u]; linarith
  have hv : 0 < v := by dsimp [v]; linarith
  have hu1 : u < 1 := by dsimp [u]; linarith
  have hn : 0 < 1+v-u := by linarith
  have hr : d*(1+v-u)=u*v := by dsimp [u,v]; linear_combination hrel
  have hf : 0 < 1-v-2*d := by
    have ht : 0 < 2-2*d-2*a := (mul_pos_iff_of_pos_left hb).mp hthird
    dsimp [v]; linarith
  have he : (1-v-2*d)*(1+v-u)=(1+v)*(1-u-v) := by linear_combination -2*hr
  have hp : 0 < (1+v)*(1-u-v) := by rw [← he]; exact mul_pos hf hn
  have huv : u+v < 1 := by
    have := (mul_pos_iff_of_pos_left (by linarith : 0 < 1+v)).mp hp
    linarith
  refine ⟨u,v,hu,hv,huv,?_,?_,?_⟩
  · dsimp [v]; ring
  · dsimp [u]; ring
  · unfold sourceL1ChartD
    exact (eq_div_iff (ne_of_gt hn)).mpr hr

theorem source_l1_actual_stationary_bounds (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b : ℝ)
    (hpos : ∀ q ∈ sourceSeparatedEntrySet,0 < sourceTernarySeparatedZeros t a b q.1 q.2)
    (hmin : IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) (sourceTernarySeparatedZeros t a b)) :
    let d := t 2-2+a+b
    0 < a ∧ a < 1 ∧ 0 < b ∧ b < 1 ∧ 0 < d ∧ d < 1 ∧
      t=sourceTernaryStationaryTraces a b d ∧ 4*a*b=(1-d)*(2*(a+b)-1) ∧
      ((1/2 < a ∧ b < 1/2) ∨ (a < 1/2 ∧ 1/2 < b)) := by
  dsimp only
  let d := t 2-2+a+b
  obtain ⟨hPa,hPb⟩ := source_ternary_separated_minimum_stationary t ht a b hpos hmin
  obtain ⟨heq,hrel⟩ := source_ternary_face_stationary_relations t ht a b d rfl hPa hPb
  have ha := hpos (0,1) (by decide)
  have hb := hpos (1,0) (by decide)
  have ha1 := hpos (2,1) (by decide)
  have hb1 := hpos (2,0) (by decide)
  have hd := hpos (2,2) (by decide)
  have hx := hpos (0,2) (by decide)
  have hy := hpos (1,2) (by decide)
  norm_num [sourceTernarySeparatedZeros,sourceTernaryOneZero] at ha hb ha1 hb1 hd hx hy
  have hdp : 0 < d := by dsimp [d]; linarith
  have hs := ht
  norm_num [Fin.sum_univ_succ] at hs
  have hd1 : d < 1 := by dsimp [d]; linarith
  have hspos : 0 < 2*(a+b)-1 := by
    have hp : 0 < 4*a*b := by positivity
    rw [hrel] at hp
    exact (mul_pos_iff_of_pos_left (by linarith : 0 < 1-d)).mp hp
  have hc : (2*a-1)*(2*b-1)=d*(1-2*(a+b)) := by linear_combination hrel
  have hneg : (2*a-1)*(2*b-1) < 0 := by rw [hc]; exact mul_neg_of_pos_of_neg hdp (by linarith)
  have hor : (1/2 < a ∧ b < 1/2) ∨ (a < 1/2 ∧ 1/2 < b) := by
    rcases mul_neg_iff.mp hneg with h | h
    · left; constructor <;> linarith [h.1,h.2]
    · right; constructor <;> linarith [h.1,h.2]
  exact ⟨ha,by linarith,hb,by linarith,hdp,hd1,heq,hrel,hor⟩

theorem source_l1_actual_oriented_recovery (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b : ℝ)
    (hpos : ∀ q ∈ sourceSeparatedEntrySet,0 < sourceTernarySeparatedZeros t a b q.1 q.2)
    (hmin : IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) (sourceTernarySeparatedZeros t a b))
    (ha : 1/2 < a) (hb : b < 1/2) :
    ∃ u v : ℝ,0 < u ∧ 0 < v ∧ u+v < 1 ∧
      t=sourceL1ChartTraces u v ∧ sourceTernarySeparatedZeros t a b=sourceL1ChartMatrix u v := by
  obtain ⟨ha0,ha1,hb0,hb1,hd0,hd1,heq,hrel,hor⟩ := source_l1_actual_stationary_bounds t ht a b hpos hmin
  let d := t 2-2+a+b
  have hy := hpos (1,2) (by decide)
  norm_num [sourceTernarySeparatedZeros,sourceTernaryOneZero] at hy
  have ht1 : t 1=b*(3-2*d-2*a) := by rw [heq]; rfl
  have hthird : 0 < b*(2-2*d-2*a) := by nlinarith [hy,ht1]
  obtain ⟨u,v,hu,hv,huv,hae,hbe,hde⟩ := source_l1_oriented_parameters a b d ha ha1 hb0 hb hrel hthird
  have htrace : t=sourceL1ChartTraces u v := by
    change t=sourceTernaryStationaryTraces ((1+v)/2) ((1-u)/2) (sourceL1ChartD u v)
    rw [← hae,← hbe,← hde]
    exact heq
  refine ⟨u,v,hu,hv,huv,htrace,?_⟩
  unfold sourceL1ChartMatrix
  rw [← htrace,← hae,← hbe]

theorem source_l1_separated_swap (t : Fin 3 → ℝ) (a b : ℝ) :
    sourcePermutedMatrix (sourceTernarySeparatedZeros t a b) (Equiv.swap 0 1) (Equiv.swap 0 1)=
      sourceTernarySeparatedZeros (sourcePermutedTraces t (Equiv.swap 0 1)) b a := by
  ext i j
  change sourceTernarySeparatedZeros t a b ((Equiv.swap 0 1) i) ((Equiv.swap 0 1) j)=_
  fin_cases i <;> fin_cases j <;>
    norm_num [sourceTernarySeparatedZeros,sourceTernaryOneZero,sourcePermutedTraces,Equiv.swap_apply_def] <;> ring

end CoefficientStability
