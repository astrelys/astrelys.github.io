import CoefficientStability.DeficitBounds
import Mathlib.Algebra.QuadraticDiscriminant

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem psd_matrixQuadratic_nonneg (A : Matrix (Fin n) (Fin n) ℝ)
    (hA : A.PosSemidef) (v : Fin n → ℝ) : 0 ≤ matrixQuadratic A v := by
  have h := hA.dotProduct_mulVec_nonneg v
  simpa [matrixQuadratic,dotProduct,Matrix.mulVec,Finset.mul_sum,
    mul_assoc,mul_left_comm,mul_comm] using h

theorem psd_entry_square_le (A : Matrix (Fin n) (Fin n) ℝ) (hA : A.PosSemidef)
    (i j : Fin n) : (A i j)^2 ≤ A i i*A j j := by
  have hsym : A j i=A i j := by simpa using hA.isHermitian.apply i j
  have hq : ∀ s : ℝ, 0 ≤ A i i*(s*s)+(2*A i j)*s+A j j := by
    intro s
    have h := psd_matrixQuadratic_nonneg A hA (Pi.single i s+Pi.single j 1)
    simp only [matrixQuadratic,Pi.add_apply,mul_add,add_mul,Finset.sum_add_distrib] at h
    simp [Pi.single_apply,hsym] at h
    nlinarith
  have h := discrim_le_zero hq
  simp only [discrim] at h
  nlinarith

theorem psd_entry_abs_le_sqrt (A : Matrix (Fin n) (Fin n) ℝ) (hA : A.PosSemidef)
    (i j : Fin n) : |A i j| ≤ Real.sqrt (A i i)*Real.sqrt (A j j) := by
  have hi := hA.diag_nonneg (i := i)
  have hj := hA.diag_nonneg (i := j)
  have h := psd_entry_square_le A hA i j
  have hs1 := Real.sq_sqrt hi
  have hs2 := Real.sq_sqrt hj
  have h0 := mul_nonneg (Real.sqrt_nonneg (A i i)) (Real.sqrt_nonneg (A j j))
  have he : (Real.sqrt (A i i)*Real.sqrt (A j j))^2=A i i*A j j := by
    rw [mul_pow,hs1,hs2]
  nlinarith [sq_abs (A i j)]

theorem psd_quadratic_le_trace (A : Matrix (Fin n) (Fin n) ℝ) (hA : A.PosSemidef)
    (x : Fin n → ℝ) : matrixQuadratic A x ≤ Matrix.trace A * ∑ i,x i^2 := by
  have h1 : matrixQuadratic A x ≤ (∑ i,Real.sqrt (A i i)*|x i|)^2 := by
    unfold matrixQuadratic
    rw [pow_two,Finset.sum_mul_sum]
    apply Finset.sum_le_sum
    intro i hi
    apply Finset.sum_le_sum
    intro j hj
    calc
      A i j*x i*x j ≤ |A i j*x i*x j| := le_abs_self _
      _ = |A i j| * |x i| * |x j| := by simp only [abs_mul]
      _ ≤ (Real.sqrt (A i i)*Real.sqrt (A j j))*|x i| * |x j| := by
        gcongr
        exact psd_entry_abs_le_sqrt A hA i j
      _ = (Real.sqrt (A i i)*|x i|)*(Real.sqrt (A j j)*|x j|) := by ring
  have h2 := Finset.sum_mul_sq_le_sq_mul_sq (Finset.univ : Finset (Fin n))
    (fun i => Real.sqrt (A i i)) (fun i => |x i|)
  simp only [Real.sq_sqrt (hA.diag_nonneg),sq_abs] at h2
  exact h1.trans h2

theorem paper_root_variance_trace_bound
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) (x : Fin n → ℝ)
    (hN : 2 ≤ N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) :
    matrixQuadratic (deficitMatrix p t N) x ≤ referenceDeficit p t N * ∑ i,x i^2 := by
  have h := psd_quadratic_le_trace (deficitMatrix p t N)
    (deficitMatrix_posSemidef p t N hN hp hnorm hstable hgrad) x
  simpa only [trace_deficitMatrix] using h

end CoefficientStability
