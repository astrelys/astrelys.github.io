import CoefficientStability.SourceCubicDerivativeConicSign

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000

def sourceBinaryWhiteningInverse (a b c u v : ℝ) : Fin 2 → ℝ :=
  ![u/Real.sqrt a-b*v/(Real.sqrt a*Real.sqrt (a*c-b^2)),
    Real.sqrt a*v/Real.sqrt (a*c-b^2)]

def sourceBinaryWhiteningForward (a b c x y : ℝ) : Fin 2 → ℝ :=
  ![Real.sqrt a*x+b/Real.sqrt a*y,Real.sqrt (a*c-b^2)/Real.sqrt a*y]

theorem source_binary_whitening_inverse_forward (a b c x y : ℝ)
    (ha : 0<a) (hd : 0<a*c-b^2) :
    sourceBinaryWhiteningInverse a b c (sourceBinaryWhiteningForward a b c x y 0)
      (sourceBinaryWhiteningForward a b c x y 1)=![x,y] := by
  have hr : Real.sqrt a≠0 := ne_of_gt (Real.sqrt_pos.mpr ha)
  have hs : Real.sqrt (a*c-b^2)≠0 := ne_of_gt (Real.sqrt_pos.mpr hd)
  funext i
  fin_cases i
  · change (Real.sqrt a*x+b/Real.sqrt a*y)/Real.sqrt a-
      b*(Real.sqrt (a*c-b^2)/Real.sqrt a*y)/(Real.sqrt a*Real.sqrt (a*c-b^2))=x
    field_simp [hr,hs] <;> ring
  · change Real.sqrt a*(Real.sqrt (a*c-b^2)/Real.sqrt a*y)/Real.sqrt (a*c-b^2)=y
    field_simp [hr,hs]

theorem source_binary_whitening_forward_inverse (a b c u v : ℝ)
    (ha : 0<a) (hd : 0<a*c-b^2) :
    sourceBinaryWhiteningForward a b c (sourceBinaryWhiteningInverse a b c u v 0)
      (sourceBinaryWhiteningInverse a b c u v 1)=![u,v] := by
  have hr : Real.sqrt a≠0 := ne_of_gt (Real.sqrt_pos.mpr ha)
  have hs : Real.sqrt (a*c-b^2)≠0 := ne_of_gt (Real.sqrt_pos.mpr hd)
  funext i
  fin_cases i
  · change Real.sqrt a*(u/Real.sqrt a-b*v/(Real.sqrt a*Real.sqrt (a*c-b^2)))+
      b/Real.sqrt a*(Real.sqrt a*v/Real.sqrt (a*c-b^2))=u
    field_simp [hr,hs] <;> ring
  · change Real.sqrt (a*c-b^2)/Real.sqrt a*(Real.sqrt a*v/Real.sqrt (a*c-b^2))=v
    field_simp [hr,hs]

theorem source_binary_whitening_actual_quadratic (a b c u v : ℝ)
    (ha : 0<a) (hd : 0<a*c-b^2) :
    a*(sourceBinaryWhiteningInverse a b c u v 0)^2+
      2*b*(sourceBinaryWhiteningInverse a b c u v 0)*(sourceBinaryWhiteningInverse a b c u v 1)+
      c*(sourceBinaryWhiteningInverse a b c u v 1)^2=u^2+v^2 := by
  let r := Real.sqrt a
  let d := Real.sqrt (a*c-b^2)
  have hr : r≠0 := ne_of_gt (Real.sqrt_pos.mpr ha)
  have hd0 : d≠0 := ne_of_gt (Real.sqrt_pos.mpr hd)
  have hr2 : r^2=a := Real.sq_sqrt ha.le
  have hd2 : d^2=a*c-b^2 := Real.sq_sqrt hd.le
  have hc : c=(d^2+b^2)/r^2 := by
    apply (eq_div_iff (pow_ne_zero _ hr)).mpr
    rw [hr2,hd2]
    ring
  change a*(u/r-b*v/(r*d))^2+2*b*(u/r-b*v/(r*d))*(r*v/d)+c*(r*v/d)^2=u^2+v^2
  rw [hc,← hr2]
  field_simp [hr,hd0] <;> ring

end CoefficientStability
