import CoefficientStability.SpectralFiniteCombination
import CoefficientStability.GradientSubsetMass

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def suffixIndicator (j : Fin n) : Fin n → ℝ := fun i => if j ≤ i then 1 else 0

def cumulativeInput (c : Fin n → ℝ) : Fin n → ℝ :=
  fun i => ∑ j∈Finset.univ.filter (fun j => j ≤ i),c j

def finiteInputPrefix (x : Fin n → ℝ) (k : ℕ) : ℝ :=
  ∑ i∈Finset.univ.filter (fun i => i.val < k),x i

theorem cumulativeInput_indicator_decomposition (c : Fin n → ℝ) :
    cumulativeInput c=∑ j,c j • suffixIndicator j := by
  classical
  funext i
  simp only [cumulativeInput,suffixIndicator,Finset.sum_apply,Pi.smul_apply,smul_eq_mul,
    Finset.sum_filter,mul_ite,mul_one,mul_zero]

theorem suffix_prefix_coordinate_count (j : Fin n) (k : ℕ) (hk : k ≤ n) :
    ((Finset.univ.filter (fun i : Fin n => i.val < k)).filter (fun i => j ≤ i)).card=k-j.val := by
  classical
  rw [← Nat.card_Ico j.val k]
  apply Finset.card_bij (fun i hi => i.val)
  · intro i hi
    simp only [Finset.mem_filter,Finset.mem_univ,true_and] at hi
    exact Finset.mem_Ico.mpr ⟨hi.2,hi.1⟩
  · intro i hi l hl heq
    exact Fin.ext heq
  · intro a ha
    have hmem := Finset.mem_Ico.mp ha
    refine ⟨⟨a,lt_of_lt_of_le hmem.2 hk⟩,?_,rfl⟩
    simp only [Finset.mem_filter,Finset.mem_univ,true_and]
    exact ⟨hmem.2,hmem.1⟩

theorem cumulativeInput_prefix_mass (c : Fin n → ℝ) (k : ℕ) (hk : k ≤ n) :
    finiteInputPrefix (cumulativeInput c) k=∑ j : Fin n,((k-j.val : ℕ) : ℝ)*c j := by
  classical
  have hinner (i : Fin n) : cumulativeInput c i=∑ j : Fin n,if j ≤ i then c j else 0 := by
    simp only [cumulativeInput,Finset.sum_filter]
  unfold finiteInputPrefix
  simp_rw [hinner]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j hj
  have heq : (∑ i∈Finset.univ.filter (fun i : Fin n => i.val < k),if j ≤ i then c j else 0)=
      (((Finset.univ.filter (fun i : Fin n => i.val < k)).filter (fun i => j ≤ i)).card : ℝ)*c j := by
    rw [← Finset.sum_filter]
    simp
  rw [heq,suffix_prefix_coordinate_count j k hk]

end CoefficientStability
