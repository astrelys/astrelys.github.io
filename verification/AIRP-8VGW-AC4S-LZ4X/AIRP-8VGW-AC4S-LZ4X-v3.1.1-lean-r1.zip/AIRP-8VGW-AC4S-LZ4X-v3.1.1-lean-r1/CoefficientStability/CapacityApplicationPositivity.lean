import CoefficientStability.PositiveCapacityPolynomial

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem polynomial_nonnegative_evaluation (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ)
    (hp : ∀ g,0≤p.coeff g) (hx : ∀ i,0≤x i) : 0≤MvPolynomial.eval x p := by
  rw [p.as_sum]
  simp only [map_sum,eval_monomial_univ]
  apply Finset.sum_nonneg
  intro g hg
  exact mul_nonneg (hp g) (Finset.prod_nonneg (fun i hi => pow_nonneg (hx i) _))

theorem polynomial_eval_pos_of_positive_pure_coefficient (p : MvPolynomial (Fin n) ℝ)
    (x : Fin n → ℝ) (N : ℕ) (j : Fin n)
    (hp : ∀ g,0≤p.coeff g) (hx : ∀ i,0≤x i)
    (hc : 0<p.coeff (Finsupp.single j N)) (hxj : 0<x j) : 0<MvPolynomial.eval x p := by
  have he : MvPolynomial.eval x p=∑ g∈p.support,p.coeff g*(∏ i,x i^(g i)) := by
    conv_lhs => rw [p.as_sum]
    simp only [map_sum,eval_monomial_univ]
  rw [he]
  have hg : Finsupp.single j N∈p.support := MvPolynomial.mem_support_iff.mpr (ne_of_gt hc)
  have hterm : 0<p.coeff (Finsupp.single j N)*(∏ i,x i^((Finsupp.single j N) i)) := by
    have hprod : (∏ i,x i^((Finsupp.single j N) i))=x j^N := by
      simp [Finsupp.single_apply]
    rw [hprod]
    exact mul_pos hc (pow_pos hxj N)
  exact lt_of_lt_of_le hterm (Finset.single_le_sum
    (fun g hg => mul_nonneg (hp g) (Finset.prod_nonneg (fun i hi => pow_nonneg (hx i) _))) hg)

theorem paper_capacity_section_constant_pos (p : MvPolynomial (Fin n) ℝ)
    (y : Fin n → ℝ) (N : ℕ) (i j : Fin n) (hji : j≠i)
    (hp : ∀ g,0≤p.coeff g) (hy : ∀ k,0<y k)
    (hc : 0<p.coeff (Finsupp.single j N)) :
    0<MvPolynomial.eval (Function.update y i 0) p := by
  refine polynomial_eval_pos_of_positive_pure_coefficient p _ N j hp ?_ hc ?_
  · intro k
    by_cases hki : k=i
    · subst k;simp
    · simpa only [Function.update_of_ne hki] using (hy k).le
  · simpa only [Function.update_of_ne hji] using hy j

end CoefficientStability
