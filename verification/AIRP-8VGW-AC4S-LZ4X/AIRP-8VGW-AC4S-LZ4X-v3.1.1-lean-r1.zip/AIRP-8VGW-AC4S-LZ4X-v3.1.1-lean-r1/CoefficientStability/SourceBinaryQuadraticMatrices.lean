import CoefficientStability.SourceCubicCoordinateMatrices

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000

def sourceBinaryWhiteningMatrix (a b c : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  !![1,0,0;0,1/Real.sqrt a,-b/(Real.sqrt a*Real.sqrt (a*c-b^2));
    0,0,Real.sqrt a/Real.sqrt (a*c-b^2)]
def sourceBinaryWhiteningRecoveryMatrix (a b c : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  !![1,0,0;0,Real.sqrt a,b/Real.sqrt a;0,0,Real.sqrt (a*c-b^2)/Real.sqrt a]

theorem source_binary_whitening_matrix_actual (a b c : ℝ) (z : Fin 3 → ℝ) :
    (sourceBinaryWhiteningMatrix a b c).mulVec z=
      ![z 0,sourceBinaryWhiteningInverse a b c (z 1) (z 2) 0,
        sourceBinaryWhiteningInverse a b c (z 1) (z 2) 1] := by
  funext i
  rw [source_real_three_mulvec_entry]
  fin_cases i
  · change 1*z 0+0*z 1+0*z 2=z 0
    ring
  · change 0*z 0+(1/Real.sqrt a)*z 1+(-b/(Real.sqrt a*Real.sqrt (a*c-b^2)))*z 2=
      z 1/Real.sqrt a-b*z 2/(Real.sqrt a*Real.sqrt (a*c-b^2))
    ring
  · change 0*z 0+0*z 1+(Real.sqrt a/Real.sqrt (a*c-b^2))*z 2=
      Real.sqrt a*z 2/Real.sqrt (a*c-b^2)
    ring

theorem source_binary_whitening_recovery_matrix_actual (a b c : ℝ) (z : Fin 3 → ℝ) :
    (sourceBinaryWhiteningRecoveryMatrix a b c).mulVec z=
      ![z 0,sourceBinaryWhiteningForward a b c (z 1) (z 2) 0,
        sourceBinaryWhiteningForward a b c (z 1) (z 2) 1] := by
  funext i
  rw [source_real_three_mulvec_entry]
  fin_cases i
  · change 1*z 0+0*z 1+0*z 2=z 0
    ring
  · change 0*z 0+Real.sqrt a*z 1+(b/Real.sqrt a)*z 2=
      Real.sqrt a*z 1+b/Real.sqrt a*z 2
    ring
  · change 0*z 0+0*z 1+(Real.sqrt (a*c-b^2)/Real.sqrt a)*z 2=
      Real.sqrt (a*c-b^2)/Real.sqrt a*z 2
    ring

theorem source_binary_whitening_matrix_entire_recovery (a b c : ℝ)
    (ha : 0<a) (hd : 0<a*c-b^2) (z : Fin 3 → ℝ) :
    (sourceBinaryWhiteningMatrix a b c).mulVec
      ((sourceBinaryWhiteningRecoveryMatrix a b c).mulVec z)=z := by
  rw [source_binary_whitening_matrix_actual,source_binary_whitening_recovery_matrix_actual]
  have h := source_binary_whitening_inverse_forward a b c (z 1) (z 2) ha hd
  have h0 := congrFun h 0
  have h1 := congrFun h 1
  funext i
  fin_cases i
  · rfl
  · exact h0
  · exact h1

end CoefficientStability
