import CoefficientStability.NuijTranslation
import CoefficientStability.ActualOrderedRootFamily
import Mathlib.Topology.Order.IntermediateValue

noncomputable section
open scoped Topology
open Filter
namespace CoefficientStability
variable {n N : ℕ}

theorem source_smoothed_roots_lt_atTop
    (p : MvPolynomial (Fin n) ℝ) (hp : p.IsHomogeneous N)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N) (x : Fin n → ℝ) (ε a : ℝ) :
    ∀ᶠ t : ℝ in atTop,∀ r : ℝ,(smoothedLineRestriction p N ε (x+t • b)).IsRoot r → r<a := by
  have hneg := source_smoothed_roots_negative_atTop p N hp hs hnorm b hb (fun i => x i+a) ε
  have heq (t : ℝ) : (fun i => x i+a)+t • b=(fun i => (x+t • b) i+a) := by
    funext i
    simp only [Pi.add_apply,Pi.smul_apply,smul_eq_mul]
    ring
  filter_upwards [hneg] with t ht
  intro r hr
  have hroot := smoothed_source_line_root_translation p N ε (x+t • b) a r hr
  rw [← heq t] at hroot
  have h := ht (r-a) hroot
  linarith

theorem source_smoothed_roots_gt_atBot
    (p : MvPolynomial (Fin n) ℝ) (hp : p.IsHomogeneous N)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N) (x : Fin n → ℝ) (ε a : ℝ) :
    ∀ᶠ t : ℝ in atBot,∀ r : ℝ,(smoothedLineRestriction p N ε (x+t • b)).IsRoot r → a<r := by
  have hpos := source_smoothed_roots_positive_atBot p N hp hs hnorm b hb (fun i => x i+a) ε
  have heq (t : ℝ) : (fun i => x i+a)+t • b=(fun i => (x+t • b) i+a) := by
    funext i
    simp only [Pi.add_apply,Pi.smul_apply,smul_eq_mul]
    ring
  filter_upwards [hpos] with t ht
  intro r hr
  have hroot := smoothed_source_line_root_translation p N ε (x+t • b) a r hr
  rw [← heq t] at hroot
  have h := ht (r-a) hroot
  linarith

theorem actual_smoothed_root_curve_limits
    (p : MvPolynomial (Fin n) ℝ) (hp : p.IsHomogeneous N)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N) (x : Fin n → ℝ) (ε : ℝ)
    (roots : ℝ → Fin N → ℝ)
    (hf : ∀ t : ℝ,smoothedLineRestriction p N ε (x+t • b)=realRootProduct (roots t)) :
    ∀ i : Fin N,Tendsto (fun t => roots t i) atTop atBot ∧ Tendsto (fun t => roots t i) atBot atTop := by
  have hroot (t : ℝ) (i : Fin N) : (smoothedLineRestriction p N ε (x+t • b)).IsRoot (roots t i) := by
    rw [hf t]
    apply Polynomial.isRoot_of_mem_roots
    rw [realRootProduct_roots]
    simp
  intro i
  constructor
  · apply tendsto_atBot.mpr
    intro a
    filter_upwards [source_smoothed_roots_lt_atTop p hp hs hnorm b hb x ε a] with t ht
    exact (ht (roots t i) (hroot t i)).le
  · apply tendsto_atTop.mpr
    intro a
    filter_upwards [source_smoothed_roots_gt_atBot p hp hs hnorm b hb x ε a] with t ht
    exact (ht (roots t i) (hroot t i)).le

theorem source_smoothed_distinct_real_crossings
    (p : MvPolynomial (Fin n) ℝ) (hp : p.IsHomogeneous N)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N) (x : Fin n → ℝ)
    (ε : ℝ) (hε : ε≠0) (s : ℝ) :
    ∃ times : Fin N → ℝ,Function.Injective times ∧
      ∀ i : Fin N,(smoothedLineRestriction p N ε (x+times i • b)).eval s=0 := by
  classical
  obtain ⟨roots,hcont,hprops⟩ := actual_smoothed_line_continuous_ordered_roots p hp hs hnorm ε hε x b
  have hf : ∀ t : ℝ,smoothedLineRestriction p N ε (x+t • b)=realRootProduct (roots t) := fun t => (hprops t).2
  have hlimits := actual_smoothed_root_curve_limits p hp hs hnorm b hb x ε roots hf
  have hex (i : Fin N) : ∃ t : ℝ,roots t i=s :=
    ((continuous_apply i).comp hcont).surjective' (hlimits i).2 (hlimits i).1 s
  choose times htimes using hex
  refine ⟨times,?_,?_⟩
  · intro i j hij
    have heq : roots (times j) i=roots (times j) j := by
      rw [← hij,htimes i]
      rw [hij,htimes j]
    exact (hprops (times j)).1.injective heq
  · intro i
    have hr : (smoothedLineRestriction p N ε (x+times i • b)).IsRoot (roots (times i) i) := by
      rw [hf]
      apply Polynomial.isRoot_of_mem_roots
      rw [realRootProduct_roots]
      simp
    simpa only [htimes i,Polynomial.IsRoot] using hr

end CoefficientStability
