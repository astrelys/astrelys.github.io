import CoefficientStability.SourceCubicSeparatedExclusion

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1200000

def sourceTernaryStationaryTraces (a b d : ℝ) : Fin 3 → ℝ :=
  ![a*(3-2*d-2*b),b*(3-2*d-2*a),1+d+(2-2*(a+b))/2]

def sourceTernaryFacePartialA (t : Fin 3 → ℝ) (a b : ℝ) := t 1+(2*t 2-7)*b+4*a*b+2*b^2
def sourceTernaryFacePartialB (t : Fin 3 → ℝ) (a b : ℝ) := t 0+(2*t 2-7)*a+2*a^2+4*a*b

theorem source_ternary_stationary_chart_trace_sum (a b d : ℝ)
    (hrel : 4*a*b=(1-d)*(2*(a+b)-1)) : (∑ i,sourceTernaryStationaryTraces a b d i)=3 := by
  norm_num [sourceTernaryStationaryTraces,Fin.sum_univ_succ]
  nlinarith [hrel]

theorem source_ternary_stationary_chart_gap (a b d : ℝ)
    (hrel : 4*a*b=(1-d)*(2*(a+b)-1)) :
    Matrix.permanent (sourceTernarySeparatedZeros (sourceTernaryStationaryTraces a b d) a b)-
      sourceTernaryBaseline (sourceTernaryStationaryTraces a b d)=a*b/9*sourceCubicEuclideanH d (2-2*(a+b)) := by
  have hh := sub_eq_zero.mpr hrel
  rw [source_permanent_three]
  norm_num [sourceTernarySeparatedZeros,sourceTernaryOneZero,sourceTernaryStationaryTraces,sourceTernaryBaseline]
  unfold sourceCubicEuclideanH
  linear_combination ((2/9) * a^2 * b^1 + (2/9) * a^1 * b^2 + (-2/9) * a^1 * b^1 * d^1 + (5/9) * a^1 * b^1) * hh

theorem source_ternary_stationary_chart_radius (a b d : ℝ)
    (hrel : 4*a*b=(1-d)*(2*(a+b)-1)) :
    (∑ i,(sourceTernaryStationaryTraces a b d i-1)^2)=sourceCubicR d (2-2*(a+b)) := by
  have hh := sub_eq_zero.mpr hrel
  norm_num [sourceTernaryStationaryTraces,Fin.sum_univ_succ]
  unfold sourceCubicR
  linear_combination ((2) * a^1 * b^1 + (1) * a^1 * d^1 + (-2) * a^1 + (1) * b^1 * d^1 + (-2) * b^1 + (-2) * d^2 + (13/2) * d^1 + (-3)) * hh

theorem source_ternary_stationary_chart_strict_gap (a b d : ℝ) (ha : 0 < a) (hb : 0 < b)
    (hd : 0 < d) (hd1 : d < 1) (hrel : 4*a*b=(1-d)*(2*(a+b)-1))
    (hradius : (∑ i,(sourceTernaryStationaryTraces a b d i-1)^2) ≤ 3/8) :
    sourceTernaryBaseline (sourceTernaryStationaryTraces a b d) <
      Matrix.permanent (sourceTernarySeparatedZeros (sourceTernaryStationaryTraces a b d) a b) := by
  rw [source_ternary_stationary_chart_radius a b d hrel] at hradius
  have hH := source_cubic_separated_H_positive d (2-2*(a+b)) hd hd1 hradius
  have hgap := source_ternary_stationary_chart_gap a b d hrel
  have hp : 0 < a*b/9*sourceCubicEuclideanH d (2-2*(a+b)) := by positivity
  linarith

theorem source_ternary_face_stationary_relations (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (a b d : ℝ) (hd : d=t 2-2+a+b)
    (hPa : sourceTernaryFacePartialA t a b=0) (hPb : sourceTernaryFacePartialB t a b=0) :
    t=sourceTernaryStationaryTraces a b d ∧ 4*a*b=(1-d)*(2*(a+b)-1) := by
  have hd' : t 2=d+2-a-b := by linarith
  unfold sourceTernaryFacePartialA at hPa
  unfold sourceTernaryFacePartialB at hPb
  rw [hd'] at hPa hPb
  have h0 : t 0=a*(3-2*d-2*b) := by nlinarith [hPb]
  have h1 : t 1=b*(3-2*d-2*a) := by nlinarith [hPa]
  have hs := ht
  simp only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero] at hs
  change t 0+(t 1+t 2)=3 at hs
  rw [h0,h1,hd'] at hs
  refine ⟨?_,by nlinarith [hs]⟩
  funext i
  fin_cases i
  · change t 0=a*(3-2*d-2*b)
    exact h0
  · change t 1=b*(3-2*d-2*a)
    exact h1
  · change t 2=1+d+(2-2*(a+b))/2
    linarith

end CoefficientStability
