import CoefficientStability.SourceCubicMatrixTrace

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 2400000
set_option backward.isDefEq.respectTransparency false

theorem source_complex_three_det_one_sub (A : Matrix (Fin 3) (Fin 3) ℂ) :
    (1-A).det=1-Matrix.trace A+((Matrix.trace A)^2-Matrix.trace (A^2))/2-A.det := by
  norm_num [Matrix.det_fin_three,Matrix.trace,Matrix.mul_apply,Matrix.sub_apply,Matrix.one_apply,Fin.sum_univ_succ,pow_succ]
  ring

theorem source_cubic_mixed_separable_objective (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : (∑ i,A i)=1) :
    complexMixedDiscriminant A=1-(1/2 : ℂ)*(∑ i,(Matrix.trace (A i))^2)+
      (1/3 : ℂ)*(∑ i,(Matrix.trace (A i))^3)+
      ∑ i,((2/3 : ℂ)*Matrix.trace ((A i)^3)+((1/2 : ℂ)-Matrix.trace (A i))*Matrix.trace ((A i)^2)) := by
  have hs := hA
  norm_num [Fin.sum_univ_succ] at hs
  have h01 : A 0+A 1=1-A 2 := by rw [← hs];abel
  have h02 : A 0+A 2=1-A 1 := by rw [← hs];abel
  have h12 : A 1+A 2=1-A 0 := by rw [← hs];abel
  have hs' : A 0+A 1+A 2=1 := by simpa only [add_assoc] using hs
  have ht := congrArg Matrix.trace hs
  norm_num [Matrix.trace_add,Matrix.trace_one] at ht
  rw [source_cubic_mixed_inclusion_exclusion,hs',h01,h02,h12,Matrix.det_one]
  rw [source_complex_three_det_one_sub (A 0),source_complex_three_det_one_sub (A 1),source_complex_three_det_one_sub (A 2)]
  rw [source_complex_three_det_trace (A 0),source_complex_three_det_trace (A 1),source_complex_three_det_trace (A 2)]
  norm_num [Fin.sum_univ_succ]
  linear_combination ht

end CoefficientStability
