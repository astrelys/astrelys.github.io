import CoefficientStability.StableGlobalGrowth

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem paperCoefficientConstant_pos (hn : 2 ≤ n) : 0 < paperCoefficientConstant n := by
  have hn0 : (0 : ℝ)<n := by exact_mod_cast (show 0<n by omega)
  have hn1 : (1 : ℝ) ≤ n := by exact_mod_cast (show 1 ≤ n by omega)
  have hsub : 0 ≤ (n : ℝ)-1 := sub_nonneg.mpr hn1
  unfold paperCoefficientConstant
  have hs : 0 ≤ ∑ j ∈ Finset.range (n-2),
      (n.choose (j+3) : ℝ)*(((j+3 : ℕ) : ℝ)*n)^(j+3)/((j+3).factorial : ℝ)*
        ((n : ℝ)-1)^((j+2)/2) := by
    exact Finset.sum_nonneg (fun j hj => by positivity)
  linarith

theorem source_linear_coefficient_stability_exists (hn : 2 ≤ n) :
    ∃ ε c : ℝ,0 < ε ∧ 0 < c ∧
      ∀ (t : Fin n → ℝ) (p : MvPolynomial (Fin n) ℝ),p.IsHomogeneous n →
        UpperHalfPlaneZeroFree p → MvPolynomial.eval (fun _ => 1) p=1 →
        (∑ i,t i)=n → (∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) →
        (∑ i,|t i-1|) < ε →
        c*coefficientL1 (p-scalarPower t n) ≤ p.coeff (squarefreeExponent n)-sourceVn n*(∏ i,t i) := by
  obtain ⟨ε,κ,hε,hκ,hgrowth⟩ := source_stable_global_growth_exists hn
  have hK := paperCoefficientConstant_pos hn
  refine ⟨ε,κ/paperCoefficientConstant n,hε,div_pos hκ hK,?_⟩
  intro t p hp hs hnorm ht hgrad hnear
  have hc := normalized_homogeneous_stable_coeff_nonneg p n hp hs hnorm
  have hd := paper_coefficient_distance_upper p t hn hp hnorm hs hc ht hgrad
  have hm := mul_le_mul_of_nonneg_left hd (div_pos hκ hK).le
  have he : κ/paperCoefficientConstant n*(paperCoefficientConstant n*referenceDeficit p t n)=κ*referenceDeficit p t n := by
    field_simp
  rw [he] at hm
  exact hm.trans (hgrowth t p hp hs hnorm ht hgrad hnear)

end CoefficientStability
