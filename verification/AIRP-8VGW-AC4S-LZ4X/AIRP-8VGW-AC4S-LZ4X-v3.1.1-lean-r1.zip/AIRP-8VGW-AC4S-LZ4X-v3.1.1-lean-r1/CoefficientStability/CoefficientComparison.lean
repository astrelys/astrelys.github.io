import CoefficientStability.CentralNormBounds

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def paperCoefficientConstant (n : ℕ) : ℝ := (n : ℝ)+2*∑ j ∈ Finset.range (n-2),
  (n.choose (j+3) : ℝ)*(((j+3 : ℕ) : ℝ)*n)^(j+3)/((j+3).factorial : ℝ)*
    ((n : ℝ)-1)^((j+2)/2)

@[simp] theorem paperCoefficientConstant_two : paperCoefficientConstant 2=2 := by
  norm_num [paperCoefficientConstant]

theorem actual_gradient_nonneg (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hcoeff : ∀ g,0≤p.coeff g)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) (i : Fin n) : 0≤t i := by
  rw [← hgrad i,eval_one_first_as_sum]
  exact Finset.sum_nonneg (fun g hg => mul_nonneg (hcoeff g) (Nat.cast_nonneg _))

theorem paper_coefficient_distance_upper
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (hn : 2≤n)
    (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p) (hcoeff : ∀ g,0≤p.coeff g) (ht : ∑ i,t i=n)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    coefficientL1 (p-scalarPower t n) ≤ paperCoefficientConstant n*referenceDeficit p t n := by
  have h := paper_coefficient_distance_upper_reduction p t n hn hp hnorm hstable ht
    (actual_gradient_nonneg p t hcoeff hgrad) hgrad
  have hsum : (∑ j ∈ Finset.range (n-2),coefficientL1 (centralCoefficientPolynomial p t n (j+3))) ≤
      ∑ j ∈ Finset.range (n-2),2*((n.choose (j+3) : ℝ)*(((j+3 : ℕ) : ℝ)*n)^(j+3)/
        ((j+3).factorial : ℝ)*((n : ℝ)-1)^((j+2)/2))*referenceDeficit p t n := by
    apply Finset.sum_le_sum
    intro j hj
    have hjn : j+3≤n := by have h := Finset.mem_range.mp hj; omega
    simpa only [show j+3-1=j+2 by omega] using
      paper_central_coefficientL1_linear_bound p t (j+3) hn (by omega) hjn hp hnorm hstable hcoeff ht hgrad
  apply h.trans
  calc
    _ ≤ (n : ℝ)*referenceDeficit p t n +
        ∑ j ∈ Finset.range (n-2),2*((n.choose (j+3) : ℝ)*(((j+3 : ℕ) : ℝ)*n)^(j+3)/
          ((j+3).factorial : ℝ)*((n : ℝ)-1)^((j+2)/2))*referenceDeficit p t n :=
      add_le_add (le_refl _) hsum
    _ = _ := by
      unfold paperCoefficientConstant
      rw [add_mul,Finset.mul_sum,Finset.sum_mul]

theorem paper_coefficient_deficit_comparison
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (hn : 2≤n)
    (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p) (hcoeff : ∀ g,0≤p.coeff g) (ht : ∑ i,t i=n)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    4*Matrix.trace (deficitMatrix p t n)/((n : ℝ)*((n : ℝ)-1)) ≤
      coefficientL1 (p-scalarPower t n) ∧
    coefficientL1 (p-scalarPower t n) ≤ paperCoefficientConstant n*Matrix.trace (deficitMatrix p t n) := by
  constructor
  · exact paper_coefficient_distance_lower_trace p t n hn hp hnorm ht
  · rw [trace_deficitMatrix]
    exact paper_coefficient_distance_upper p t hn hp hnorm hstable hcoeff ht hgrad

end CoefficientStability
