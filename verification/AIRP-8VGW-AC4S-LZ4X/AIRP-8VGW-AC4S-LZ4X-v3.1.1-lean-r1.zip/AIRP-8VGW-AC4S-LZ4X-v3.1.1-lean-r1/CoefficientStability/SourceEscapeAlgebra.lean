import CoefficientStability.SourceOriginalCubicMatrixBalls
import Mathlib.Topology.UnitInterval

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 3500000
set_option backward.isDefEq.respectTransparency false

def sourceEscapeTraces (a b : ℝ) : Fin 3 → ℝ := ![b,(a+b)/2,(a+b)/2]
def sourceEscapeWeights (a b : ℝ) : Fin 3 → ℝ := ![a,b,b]
def sourceEscapeCenter (a b : ℝ) : Matrix (Fin 3) (Fin 3) ℝ := sourcePermanentReference (sourceEscapeTraces a b)
def sourceEscapeTangent : Set (Matrix (Fin 3) (Fin 3) ℝ) :=
  {A | (∀ i,(∑ j,A i j)=0) ∧ ∀ j,(∑ i,A i j)=0}
def sourceEscapeQuadratic (a b : ℝ) (A : Matrix (Fin 3) (Fin 3) ℝ) : ℝ :=
  (∑ i,sourceEscapeWeights a b i*(∑ j,(A i j)^2))/6
def sourceEscapeQ (a b : ℝ) : ℝ := a*b^2/12
def sourceEscapeDelta (a b : ℝ) : ℝ := a*b^2/36

def sourceZeroMarginalChart (x y z w : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  ![![x,y,-x-y],![z,w,-z-w],![-x-z,-y-w,x+y+z+w]]

theorem source_zero_marginal_chart_tangent (x y z w : ℝ) :
    sourceZeroMarginalChart x y z w ∈ sourceEscapeTangent := by
  constructor <;> intro i <;> fin_cases i <;> norm_num [sourceZeroMarginalChart,Fin.sum_univ_succ] <;> ring

theorem source_zero_marginal_chart_recovery (A : Matrix (Fin 3) (Fin 3) ℝ) (hA : A ∈ sourceEscapeTangent) :
    A=sourceZeroMarginalChart (A 0 0) (A 0 1) (A 1 0) (A 1 1) := by
  have h02 : A 0 2=-A 0 0-A 0 1 := by have h := hA.1 0;norm_num [Fin.sum_univ_succ] at h;linarith
  have h12 : A 1 2=-A 1 0-A 1 1 := by have h := hA.1 1;norm_num [Fin.sum_univ_succ] at h;linarith
  have h20 : A 2 0=-A 0 0-A 1 0 := by have h := hA.2 0;norm_num [Fin.sum_univ_succ] at h;linarith
  have h21 : A 2 1=-A 0 1-A 1 1 := by have h := hA.2 1;norm_num [Fin.sum_univ_succ] at h;linarith
  have h22 : A 2 2=A 0 0+A 0 1+A 1 0+A 1 1 := by
    have h := hA.2 2
    norm_num [Fin.sum_univ_succ] at h
    rw [h02,h12] at h
    linarith
  ext i j
  fin_cases i <;> fin_cases j <;> simp [sourceZeroMarginalChart,h02,h12,h20,h21,h22]

theorem source_escape_actual_cubic_expansion (a b : ℝ) (A : Matrix (Fin 3) (Fin 3) ℝ)
    (hA : A ∈ sourceEscapeTangent) :
    Matrix.permanent (sourceEscapeCenter a b+A)-Matrix.permanent (sourceEscapeCenter a b)=
      sourceEscapeQuadratic a b A+Matrix.permanent A := by
  rw [source_zero_marginal_chart_recovery A hA]
  simp only [source_permanent_three]
  norm_num [sourceEscapeCenter,sourcePermanentReference,sourceEscapeTraces,sourceZeroMarginalChart,
    sourceEscapeQuadratic,sourceEscapeWeights,Matrix.add_apply,Fin.sum_univ_succ]
  ring

theorem source_escape_quadratic_nonnegative (a b : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b)
    (A : Matrix (Fin 3) (Fin 3) ℝ) : 0 ≤ sourceEscapeQuadratic a b A := by
  apply div_nonneg _ (by norm_num)
  apply Finset.sum_nonneg
  intro i hi
  have hw : 0 ≤ sourceEscapeWeights a b i := by fin_cases i <;> simpa [sourceEscapeWeights]
  exact mul_nonneg hw (Finset.sum_nonneg (fun j _ => sq_nonneg _))

@[simp] theorem source_escape_quadratic_zero (a b : ℝ) : sourceEscapeQuadratic a b 0=0 := by
  simp [sourceEscapeQuadratic]

theorem source_escape_quadratic_homogeneous (a b r : ℝ) (A : Matrix (Fin 3) (Fin 3) ℝ) :
    sourceEscapeQuadratic a b (r • A)=r^2*sourceEscapeQuadratic a b A := by
  norm_num [sourceEscapeQuadratic,sourceEscapeWeights,Matrix.smul_apply,Fin.sum_univ_succ]
  ring

theorem source_escape_quadratic_continuous (a b : ℝ) : Continuous (sourceEscapeQuadratic a b) := by
  unfold sourceEscapeQuadratic
  fun_prop

theorem source_escape_trace_sum (a b : ℝ) (hs : a+2*b=3) : (∑ i,sourceEscapeTraces a b i)=3 := by
  norm_num [sourceEscapeTraces,Fin.sum_univ_succ]
  linarith

theorem source_escape_center_feasible (a b : ℝ) (ha : 0 < a) (hb : 0 < b) (hs : a+2*b=3) :
    sourceEscapeCenter a b ∈ sourceTransportationPolytope (sourceEscapeTraces a b) := by
  apply source_ternary_reference_feasible _ (source_escape_trace_sum a b hs)
  intro i
  fin_cases i <;> norm_num [sourceEscapeTraces] <;> linarith

theorem source_escape_feasible_displacement_tangent (a b : ℝ) (ha : 0 < a) (hb : 0 < b) (hs : a+2*b=3)
    (X : Matrix (Fin 3) (Fin 3) ℝ) (hX : X ∈ sourceTransportationPolytope (sourceEscapeTraces a b)) :
    X-sourceEscapeCenter a b ∈ sourceEscapeTangent := by
  have hC := source_escape_center_feasible a b ha hb hs
  constructor
  · intro i
    simp only [Matrix.sub_apply,Finset.sum_sub_distrib,hX.2.1 i,hC.2.1 i,sub_self]
  · intro j
    simp only [Matrix.sub_apply,Finset.sum_sub_distrib,hX.2.2 j,hC.2.2 j,sub_self]

end CoefficientStability
