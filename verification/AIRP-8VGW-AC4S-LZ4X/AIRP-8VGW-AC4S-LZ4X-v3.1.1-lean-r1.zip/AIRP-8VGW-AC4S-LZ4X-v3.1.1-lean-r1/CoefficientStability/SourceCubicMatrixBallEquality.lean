import CoefficientStability.SourceCubicMatrixBallInequalities

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 3000000
set_option backward.isDefEq.respectTransparency false

def sourceCubicMatrixEuclideanEquality (t : Fin 3 → ℝ) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) : Prop :=
  ∃ (U : Matrix.unitaryGroup (Fin 3) ℂ) (B : Matrix (Fin 3) (Fin 3) ℝ),
    B ∈ sourceTransportationPolytope t ∧ sourceCubicUnitaryAction U A=sourcePermanentDiagonalTuple B ∧
    sourceEuclideanEqualityDescription t B

def sourceCubicMatrixL1Equality (t : Fin 3 → ℝ) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) : Prop :=
  ∃ (U : Matrix.unitaryGroup (Fin 3) ℂ) (B : Matrix (Fin 3) (Fin 3) ℝ),
    B ∈ sourceTransportationPolytope t ∧ sourceCubicUnitaryAction U A=sourcePermanentDiagonalTuple B ∧
    sourceL1EqualityDescription t B

theorem source_cubic_matrix_euclidean_equality_iff (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,(t i-1)^2) ≤ 3/8) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) :
    hermitianMixedObjective A=sourceTernaryBaseline t ↔ sourceCubicMatrixEuclideanEquality t A := by
  constructor
  · intro he
    have hp : ∀ i,0 < t i := fun i => lt_of_lt_of_le (by norm_num) (source_ternary_euclidean_trace_box t ht hr i).1
    obtain ⟨U,B,hB,htu,hval⟩ := source_cubic_equality_permanent_recovery t ht hp _
      (source_cubic_matrix_euclidean_ball_inequality t ht hr) A hA he
    exact ⟨U,B,hB,htu,(source_sharp_euclidean_equality_iff t ht hr B hB).mp hval⟩
  · rintro ⟨U,B,hB,htu,hdesc⟩
    exact (source_cubic_unitary_permanent_objective t A hA U B htu).trans
      ((source_sharp_euclidean_equality_iff t ht hr B hB).mpr hdesc)

theorem source_cubic_matrix_l1_equality_iff (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,|t i-1|) ≤ sourceCubicEpsilon0) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) :
    hermitianMixedObjective A=sourceTernaryBaseline t ↔ sourceCubicMatrixL1Equality t A := by
  constructor
  · intro he
    have hp : ∀ i,0 < t i := fun i => lt_trans (by norm_num) (source_ternary_l1_strict_trace_box t ht hr i).1
    obtain ⟨U,B,hB,htu,hval⟩ := source_cubic_equality_permanent_recovery t ht hp _
      (source_cubic_matrix_l1_ball_inequality t ht hr) A hA he
    exact ⟨U,B,hB,htu,(source_sharp_l1_equality_iff t ht hr B hB).mp hval⟩
  · rintro ⟨U,B,hB,htu,hdesc⟩
    exact (source_cubic_unitary_permanent_objective t A hA U B htu).trans
      ((source_sharp_l1_equality_iff t ht hr B hB).mpr hdesc)

theorem source_cubic_matrix_euclidean_open_unique (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,(t i-1)^2) < 3/8) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) :
    hermitianMixedObjective A=sourceTernaryBaseline t ↔ A=complexReferenceTuple t := by
  constructor
  · intro he
    have hp : ∀ i,0 < t i := fun i => lt_of_lt_of_le (by norm_num) (source_ternary_euclidean_trace_box t ht hr.le i).1
    obtain ⟨U,B,hB,htu,hval⟩ := source_cubic_equality_permanent_recovery t ht hp _
      (source_cubic_matrix_euclidean_ball_inequality t ht hr.le) A hA he
    have hscalar := (source_sharp_euclidean_open_unique t ht hr B hB).mp hval
    rw [hscalar,source_permanent_diagonal_reference] at htu
    exact source_cubic_unitary_scalar_recovery t U A htu
  · intro he
    rw [he,source_cubic_reference_objective]

theorem source_cubic_matrix_l1_open_unique (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,|t i-1|) < sourceCubicEpsilon0) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) :
    hermitianMixedObjective A=sourceTernaryBaseline t ↔ A=complexReferenceTuple t := by
  constructor
  · intro he
    have hp : ∀ i,0 < t i := fun i => lt_trans (by norm_num) (source_ternary_l1_strict_trace_box t ht hr.le i).1
    obtain ⟨U,B,hB,htu,hval⟩ := source_cubic_equality_permanent_recovery t ht hp _
      (source_cubic_matrix_l1_ball_inequality t ht hr.le) A hA he
    have hscalar := (source_sharp_l1_open_unique t ht hr B hB).mp hval
    rw [hscalar,source_permanent_diagonal_reference] at htu
    exact source_cubic_unitary_scalar_recovery t U A htu
  · intro he
    rw [he,source_cubic_reference_objective]

theorem source_cubic_matrix_euclidean_normalized (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,(t i-1)^2) ≤ 3/8) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) :
    sourceTernaryBaseline t/6 ≤ hermitianMixedObjective A/6 ∧
      (hermitianMixedObjective A/6=sourceTernaryBaseline t/6 ↔ sourceCubicMatrixEuclideanEquality t A) := by
  refine ⟨by linarith [source_cubic_matrix_euclidean_ball_inequality t ht hr A hA],?_⟩
  have h := source_cubic_matrix_euclidean_equality_iff t ht hr A hA
  constructor
  · intro he
    exact h.mp (by linarith)
  · intro he
    rw [h.mpr he]

theorem source_cubic_matrix_l1_normalized (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hr : (∑ i,|t i-1|) ≤ sourceCubicEpsilon0) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t) :
    sourceTernaryBaseline t/6 ≤ hermitianMixedObjective A/6 ∧
      (hermitianMixedObjective A/6=sourceTernaryBaseline t/6 ↔ sourceCubicMatrixL1Equality t A) := by
  refine ⟨by linarith [source_cubic_matrix_l1_ball_inequality t ht hr A hA],?_⟩
  have h := source_cubic_matrix_l1_equality_iff t ht hr A hA
  constructor
  · intro he
    exact h.mp (by linarith)
  · intro he
    rw [h.mpr he]

end CoefficientStability
