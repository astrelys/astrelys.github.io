import CoefficientStability.UniversalSourceDegree
import Mathlib.Analysis.Complex.Polynomial.Basic

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n N : ℕ}

theorem complex_multiset_fin_enumeration (s : Multiset ℂ) :
    ∃ f : Fin s.card → ℂ,(List.ofFn f : Multiset ℂ)=s := by
  let L := s.toList
  have hlen : L.length=s.card := Multiset.length_toList s
  refine ⟨fun i => L.get (Fin.cast hlen.symm i),?_⟩
  rw [← List.ofFn_congr hlen L.get,List.ofFn_get]
  simp only [L,Multiset.coe_toList]

theorem complex_linear_product_natDegree (roots : Multiset ℂ) :
    ((roots.map (fun r => Polynomial.X+Polynomial.C r)).prod).natDegree=roots.card := by
  have hm : ∀ Q∈roots.map (fun r => Polynomial.X+Polynomial.C r),Q.Monic := by
    intro Q hQ
    obtain ⟨r,hr,rfl⟩ := Multiset.mem_map.mp hQ
    exact Polynomial.monic_X_add_C r
  rw [Polynomial.natDegree_multiset_prod_of_monic _ hm]
  simp

theorem actual_source_complex_root_tuple (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (z : Fin n → ℂ) :
    ∃ roots : Fin N → ℂ,sourceCharacteristicPolynomial p z=
      ∏ i : Fin N,(Polynomial.X+Polynomial.C (roots i)) := by
  let Q := sourceCharacteristicPolynomial p z
  obtain ⟨hm,hd⟩ := sourceCharacteristicPolynomial_monic_degree p N hp hnorm z
  obtain ⟨r,hfactor⟩ := Polynomial.splits_iff_exists_multiset'.mp (IsAlgClosed.splits Q)
  have hmQ : Q.Monic := hm
  have hf : Q=(r.map (fun r => Polynomial.X+Polynomial.C r)).prod := by
    simpa only [hmQ.leadingCoeff,Polynomial.C_1,one_mul] using hfactor
  have hcard : r.card=N := by
    calc
      r.card=Q.natDegree := by rw [hf,complex_linear_product_natDegree]
      _=N := hd
  clear hd
  obtain ⟨f,henum⟩ := complex_multiset_fin_enumeration r
  subst N
  refine ⟨f,?_⟩
  rw [← henum] at hf
  simpa only [Multiset.map_coe,List.map_ofFn,Multiset.prod_coe,List.prod_ofFn,Function.comp_def] using hf

theorem sourceCharacteristicPolynomial_complex_eval (p : MvPolynomial (Fin n) ℝ)
    (z : Fin n → ℂ) (t : ℂ) :
    (sourceCharacteristicPolynomial p z).eval t=
      MvPolynomial.eval₂ Complex.ofRealHom (fun i => t+z i) p := by
  change (Polynomial.evalRingHom t) (MvPolynomial.eval₂ _ _ p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c;simp
  · funext i;simp

theorem actual_source_complex_root_im_pos (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (z : Fin n → ℂ) (hz : ∀ i,0<(z i).im) :
    ∃ roots : Fin N → ℂ,sourceCharacteristicPolynomial p z=
      (∏ i : Fin N,(Polynomial.X+Polynomial.C (roots i))) ∧ ∀ i,0<(roots i).im := by
  classical
  obtain ⟨roots,hfactor⟩ := actual_source_complex_root_tuple p N hp hnorm z
  refine ⟨roots,hfactor,?_⟩
  intro i
  by_contra hi
  have hnonpos : (roots i).im≤0 := le_of_not_gt hi
  have hzero : (sourceCharacteristicPolynomial p z).eval (-roots i)=0 := by
    rw [hfactor,Polynomial.eval_prod]
    apply Finset.prod_eq_zero (Finset.mem_univ i)
    simp
  have h := hs (fun j => -roots i+z j) (by
    intro j
    simp only [Complex.add_im,Complex.neg_im]
    linarith [hz j])
  rw [← sourceCharacteristicPolynomial_complex_eval] at h
  exact h hzero

end CoefficientStability
