import CoefficientStability.SourceCubicDepressedNormalForm
import CoefficientStability.SourceBinaryQuadraticWhitening
import CoefficientStability.UniformMixingRecovery

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000

theorem source_real_three_mulvec_entry (L : Matrix (Fin 3) (Fin 3) ℝ)
    (z : Fin 3 → ℝ) (i : Fin 3) :
    L.mulVec z i=L i 0*z 0+L i 1*z 1+L i 2*z 2 := by
  norm_num [Matrix.mulVec,dotProduct,Fin.sum_univ_succ]
  ring

def sourceDepressedCoordinateMatrix (t : Fin 3 → ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  !![1,1-t 0/3,-t 1/3;1,-t 0/3,1-t 1/3;1,-t 0/3,-t 1/3]

def sourceDepressedRecoveryMatrix (t : Fin 3 → ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  !![t 0/3,t 1/3,t 2/3;1,0,-1;0,1,-1]

theorem source_depressed_coordinate_matrix_actual (t : Fin 3 → ℝ) (z : Fin 3 → ℝ) :
    (sourceDepressedCoordinateMatrix t).mulVec z=sourceDepressedCubicCoordinates t (z 0) (z 1) (z 2) := by
  funext i
  rw [source_real_three_mulvec_entry]
  fin_cases i
  · change 1*z 0+(1-t 0/3)*z 1+(-t 1/3)*z 2=z 1+(z 0-(t 0*z 1+t 1*z 2)/3)*1
    ring
  · change 1*z 0+(-t 0/3)*z 1+(1-t 1/3)*z 2=z 2+(z 0-(t 0*z 1+t 1*z 2)/3)*1
    ring
  · change 1*z 0+(-t 0/3)*z 1+(-t 1/3)*z 2=0+(z 0-(t 0*z 1+t 1*z 2)/3)*1
    ring

theorem source_depressed_recovery_matrix_actual (t : Fin 3 → ℝ) (z : Fin 3 → ℝ) :
    (sourceDepressedRecoveryMatrix t).mulVec z=
      ![(∑ i,t i*z i)/3,z 0-z 2,z 1-z 2] := by
  funext i
  rw [source_real_three_mulvec_entry]
  fin_cases i
  · change (t 0/3)*z 0+(t 1/3)*z 1+(t 2/3)*z 2=(∑ i,t i*z i)/3
    norm_num [Fin.sum_univ_succ]
    ring
  · change 1*z 0+0*z 1+(-1)*z 2=z 0-z 2
    ring
  · change 0*z 0+1*z 1+(-1)*z 2=z 1-z 2
    ring

theorem source_depressed_matrix_entire_recovery (t : Fin 3 → ℝ) (ht : ∑ i,t i=3)
    (z : Fin 3 → ℝ) :
    (sourceDepressedCoordinateMatrix t).mulVec ((sourceDepressedRecoveryMatrix t).mulVec z)=z := by
  rw [source_depressed_coordinate_matrix_actual,source_depressed_recovery_matrix_actual]
  exact source_depressed_cubic_coordinates_recover t ht z

end CoefficientStability
