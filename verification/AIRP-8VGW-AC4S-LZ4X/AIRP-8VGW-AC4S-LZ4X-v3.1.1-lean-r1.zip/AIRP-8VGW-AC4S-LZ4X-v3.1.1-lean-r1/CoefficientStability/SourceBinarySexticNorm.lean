import CoefficientStability.SourceNonnegativePolynomialNorm
import CoefficientStability.PolynomialLinearSubstitution
import Mathlib.Topology.Algebra.MvPolynomial

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceBinaryCubicValue (a : Fin 4 → ℂ) (u v : ℂ) : ℂ :=
  a 0*u^3+a 1*u^2*v+a 2*u*v^2+a 3*v^3

theorem source_degree_three_polynomial_eval (G : Polynomial ℂ) (hG : G.natDegree ≤ 3) (t : ℂ) :
    G.eval t=G.coeff 0+G.coeff 1*t+G.coeff 2*t^2+G.coeff 3*t^3 := by
  rw [Polynomial.eval_eq_sum_range' (n := 4) (by omega)]
  norm_num [Finset.sum_range_succ]

theorem source_binary_cubic_actual_homogenization (G : Polynomial ℂ) (hG : G.natDegree ≤ 3)
    (u v : ℝ) (hu : u≠0) :
    sourceBinaryCubicValue (fun i => G.coeff i.val) (u : ℂ) (v : ℂ)=
      (u : ℂ)^3*G.eval ((v/u : ℝ) : ℂ) := by
  rw [source_degree_three_polynomial_eval G hG]
  simp only [sourceBinaryCubicValue,Fin.val_zero,Fin.val_one,Fin.val_two,Complex.ofReal_div]
  change G.coeff 0*(u : ℂ)^3+G.coeff 1*(u : ℂ)^2*(v : ℂ)+
    G.coeff 2*(u : ℂ)*(v : ℂ)^2+G.coeff 3*(v : ℂ)^3=
    (u : ℂ)^3*(G.coeff 0+G.coeff 1*((v : ℂ)/(u : ℂ))+
      G.coeff 2*((v : ℂ)/(u : ℂ))^2+G.coeff 3*((v : ℂ)/(u : ℂ))^3)
  have huC : (u : ℂ)≠0 := Complex.ofReal_ne_zero.mpr hu
  field_simp

theorem source_binary_homogeneous_chart_eval (B : MvPolynomial (Fin 2) ℝ)
    (hB : B.IsHomogeneous 6) (u v : ℝ) (hu : u≠0) :
    MvPolynomial.eval (![u,v] : Fin 2 → ℝ) B=
      u^6*MvPolynomial.eval (![1,v/u] : Fin 2 → ℝ) B := by
  have he : (fun i => u*(![1,v/u] : Fin 2 → ℝ) i)=(![u,v] : Fin 2 → ℝ) := by
    funext i
    fin_cases i
    · change u*1=u
      ring
    · change u*(v/u)=v
      field_simp
  have h := homogeneous_eval_real_scale B 6 hB u (![1,v/u] : Fin 2 → ℝ)
  rw [he] at h
  exact h

theorem source_nonnegative_binary_sextic_norm_factor (B : MvPolynomial (Fin 2) ℝ)
    (hB : B.IsHomogeneous 6)
    (hpos : ∀ u v : ℝ,0 ≤ MvPolynomial.eval (![u,v] : Fin 2 → ℝ) B) :
    ∃ a : Fin 4 → ℂ,∀ u v : ℝ,
      MvPolynomial.eval (![u,v] : Fin 2 → ℝ) B=Complex.normSq (sourceBinaryCubicValue a (u : ℂ) (v : ℂ)) := by
  let q := affineDirectionalRestriction B (![1,0] : Fin 2 → ℝ) (![0,1] : Fin 2 → ℝ)
  have hqe (t : ℝ) : q.eval t=MvPolynomial.eval (![1,t] : Fin 2 → ℝ) B := by
    rw [affineDirectionalRestriction_eval]
    apply congrArg (fun x => MvPolynomial.eval x B)
    funext i
    fin_cases i
    · change 1+t*0=1
      ring
    · change 0+t*1=t
      ring
  have hqd : q.natDegree ≤ 6 := (source_affine_restriction_degree_le B _ _).trans hB.totalDegree_le
  obtain ⟨G,hG,hGd⟩ := source_nonnegative_real_polynomial_norm_factor q (fun t => by rw [hqe];exact hpos 1 t)
  have hd : G.natDegree ≤ 3 := by omega
  let a : Fin 4 → ℂ := fun i => G.coeff i.val
  have hgood (u v : ℝ) (hu : u≠0) :
      MvPolynomial.eval (![u,v] : Fin 2 → ℝ) B=Complex.normSq (sourceBinaryCubicValue a (u : ℂ) (v : ℂ)) := by
    rw [source_binary_homogeneous_chart_eval B hB u v hu]
    rw [source_binary_cubic_actual_homogenization G hd u v hu,map_mul,map_pow,Complex.normSq_ofReal]
    rw [← hG (v/u),hqe]
    ring
  refine ⟨a,?_⟩
  intro u v
  have hcinput : Continuous (fun u : ℝ => (![u,v] : Fin 2 → ℝ)) := by
    apply continuous_pi
    intro i
    fin_cases i
    · change Continuous (fun u : ℝ => u)
      exact continuous_id
    · change Continuous (fun _ : ℝ => v)
      exact continuous_const
  have hc : IsClosed {u : ℝ | MvPolynomial.eval (![u,v] : Fin 2 → ℝ) B=
      Complex.normSq (sourceBinaryCubicValue a (u : ℂ) (v : ℂ))} :=
    isClosed_eq (B.continuous_eval.comp hcinput) (by unfold sourceBinaryCubicValue;fun_prop)
  have hs : ({(0 : ℝ)}ᶜ : Set ℝ)⊆{u : ℝ | MvPolynomial.eval (![u,v] : Fin 2 → ℝ) B=
      Complex.normSq (sourceBinaryCubicValue a (u : ℂ) (v : ℂ))} := by
    intro u hu
    exact hgood u v (by simpa using hu)
  have hh := closure_minimal hs hc
  rw [(dense_compl_singleton (0 : ℝ)).closure_eq] at hh
  exact hh (Set.mem_univ u)

end CoefficientStability
