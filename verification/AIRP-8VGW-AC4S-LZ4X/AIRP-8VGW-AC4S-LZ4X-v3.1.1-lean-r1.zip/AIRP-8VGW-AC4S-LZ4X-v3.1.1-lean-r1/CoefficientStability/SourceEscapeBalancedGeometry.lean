import CoefficientStability.SourceEscapeGateRadial

noncomputable section
open scoped BigOperators Topology unitInterval
namespace CoefficientStability
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

def sourceBalancedEscapeGate : Matrix (Fin 3) (Fin 3) ℝ :=
  ![![0,1/2,1/2],![1/2,0,1/2],![1/2,1/2,0]]

def sourceBalancedEscapeDirection : Matrix (Fin 3) (Fin 3) ℝ :=
  ![![0,1,-1],![-1,0,1],![1,-1,0]]

theorem source_escape_balanced_flat_feasible (z : ℝ) (hz : |z| ≤ 1/2) :
    sourceBalancedEscapeGate+z • sourceBalancedEscapeDirection ∈ sourceTransportationPolytope (sourceEscapeTraces 1 1) := by
  have hlo := (abs_le.mp hz).1
  have hhi := (abs_le.mp hz).2
  refine ⟨?_,?_,?_⟩
  · intro i j
    fin_cases i <;> fin_cases j <;>
      norm_num [sourceBalancedEscapeGate,sourceBalancedEscapeDirection,Matrix.add_apply,Matrix.smul_apply] <;> linarith
  · intro i
    fin_cases i <;> norm_num [sourceBalancedEscapeGate,sourceBalancedEscapeDirection,sourceEscapeTraces,
      Matrix.add_apply,Matrix.smul_apply,Fin.sum_univ_succ] <;> ring
  · intro j
    fin_cases j <;> norm_num [sourceBalancedEscapeGate,sourceBalancedEscapeDirection,
      Matrix.add_apply,Matrix.smul_apply,Fin.sum_univ_succ] <;> ring

theorem source_escape_balanced_gate_feasible :
    sourceBalancedEscapeGate ∈ sourceTransportationPolytope (sourceEscapeTraces 1 1) := by
  simpa only [zero_smul,add_zero] using source_escape_balanced_flat_feasible 0 (by norm_num)

theorem source_escape_balanced_flat_quadratic (z : ℝ) :
    sourceEscapeQuadratic 1 1 (sourceBalancedEscapeGate+z • sourceBalancedEscapeDirection-sourceEscapeCenter 1 1)=1/12+z^2 := by
  norm_num [sourceEscapeQuadratic,sourceEscapeWeights,sourceBalancedEscapeGate,sourceBalancedEscapeDirection,
    sourceEscapeCenter,sourceEscapeTraces,sourcePermanentReference,Matrix.add_apply,Matrix.sub_apply,Matrix.smul_apply,Fin.sum_univ_succ]
  ring

theorem source_escape_balanced_flat_permanent (z : ℝ) :
    Matrix.permanent (sourceBalancedEscapeGate+z • sourceBalancedEscapeDirection)=1/4+3*z^2 := by
  rw [source_permanent_three]
  norm_num [sourceBalancedEscapeGate,sourceBalancedEscapeDirection,Matrix.add_apply,Matrix.smul_apply]
  ring

theorem source_escape_balanced_gate_tangent :
    sourceBalancedEscapeGate-sourceEscapeCenter 1 1 ∈ sourceEscapeTangent :=
  source_escape_feasible_displacement_tangent 1 1 (by norm_num) (by norm_num) (by norm_num)
    sourceBalancedEscapeGate source_escape_balanced_gate_feasible

theorem source_escape_balanced_gate_q_and_cubic :
    sourceEscapeQuadratic 1 1 (sourceBalancedEscapeGate-sourceEscapeCenter 1 1)=sourceEscapeQ 1 1 ∧
    Matrix.permanent (sourceBalancedEscapeGate-sourceEscapeCenter 1 1)=-(2/3)*sourceEscapeQ 1 1 := by
  constructor <;> norm_num [sourceEscapeQuadratic,sourceEscapeWeights,sourceBalancedEscapeGate,
    sourceEscapeCenter,sourceEscapeTraces,sourcePermanentReference,sourceEscapeQ,
    source_permanent_three,Matrix.sub_apply,Fin.sum_univ_succ]

theorem source_escape_balanced_gate_actual_segment_bound (u : unitInterval) :
    sourceEscapeExcess 1 1 (Path.segment (sourceEscapeCenter 1 1) sourceBalancedEscapeGate u) ≤ sourceEscapeDelta 1 1 := by
  rw [source_actual_segment_radial,source_escape_actual_radial_excess 1 1 _ source_escape_balanced_gate_tangent,
    source_escape_balanced_gate_q_and_cubic.1,source_escape_balanced_gate_q_and_cubic.2]
  have h := (source_escape_cubic_shape_bounds (u : ℝ) u.2).2
  norm_num [sourceEscapeQ,sourceEscapeDelta]
  nlinarith

theorem source_escape_balanced_actual_flat_segment_bound (z : ℝ) (u : unitInterval) :
    sourceEscapeExcess 1 1 (Path.segment sourceBalancedEscapeGate
      (sourceBalancedEscapeGate+z • sourceBalancedEscapeDirection) u) ≤ sourceEscapeDelta 1 1+3*z^2 := by
  rw [source_actual_segment_radial]
  have he : sourceBalancedEscapeGate+(u : ℝ) •
      ((sourceBalancedEscapeGate+z • sourceBalancedEscapeDirection)-sourceBalancedEscapeGate)=
      sourceBalancedEscapeGate+((u : ℝ)*z) • sourceBalancedEscapeDirection := by module
  rw [he]
  unfold sourceEscapeExcess
  rw [source_escape_balanced_flat_permanent]
  norm_num [sourceEscapeCenter,sourceEscapeTraces,sourcePermanentReference,source_permanent_three,sourceEscapeDelta]
  have hu : (u : ℝ)^2 ≤ 1 := by nlinarith [u.2.1,u.2.2]
  have hm := mul_le_mul_of_nonneg_right hu (sq_nonneg z)
  nlinarith

end CoefficientStability
