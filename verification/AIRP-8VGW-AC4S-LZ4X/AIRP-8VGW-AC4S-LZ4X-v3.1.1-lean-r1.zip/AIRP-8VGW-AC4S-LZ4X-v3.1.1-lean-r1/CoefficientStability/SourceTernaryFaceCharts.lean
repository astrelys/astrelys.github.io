import CoefficientStability.SourceTransportationGeometry

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1200000

theorem source_actual_one_zero_chart (t : Fin 3 → ℝ) (B : Matrix (Fin 3) (Fin 3) ℝ)
    (hB : B ∈ sourceTransportationPolytope t) (h00 : B 0 0=0) :
    B=sourceTernaryOneZero t (B 0 1) (B 1 0) (B 1 1) := by
  have hr0 := hB.2.1 0
  have hr1 := hB.2.1 1
  have hr2 := hB.2.1 2
  have hc0 := hB.2.2 0
  have hc1 := hB.2.2 1
  have hc2 := hB.2.2 2
  norm_num [Fin.sum_univ_succ] at hr0 hr1 hr2 hc0 hc1 hc2
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [sourceTernaryOneZero] <;> linarith

theorem source_actual_separated_zero_chart (t : Fin 3 → ℝ) (B : Matrix (Fin 3) (Fin 3) ℝ)
    (hB : B ∈ sourceTransportationPolytope t) (h00 : B 0 0=0) (h11 : B 1 1=0) :
    B=sourceTernarySeparatedZeros t (B 0 1) (B 1 0) := by
  have h := source_actual_one_zero_chart t B hB h00
  rw [h11] at h
  exact h

theorem source_actual_double_row_chart (t : Fin 3 → ℝ) (B : Matrix (Fin 3) (Fin 3) ℝ)
    (hB : B ∈ sourceTransportationPolytope t) (h00 : B 0 0=0) (h01 : B 0 1=0) :
    B=sourceTernaryDoubleRowZero t (B 1 0+B 1 1) (B 1 0) := by
  have hr0 := hB.2.1 0
  have hr1 := hB.2.1 1
  have hr2 := hB.2.1 2
  have hc0 := hB.2.2 0
  have hc1 := hB.2.2 1
  have hc2 := hB.2.2 2
  norm_num [Fin.sum_univ_succ] at hr0 hr1 hr2 hc0 hc1 hc2
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [sourceTernaryDoubleRowZero] <;> linarith

theorem source_actual_double_column_chart (t : Fin 3 → ℝ) (B : Matrix (Fin 3) (Fin 3) ℝ)
    (hB : B ∈ sourceTransportationPolytope t) (h10 : B 1 0=0) (h20 : B 2 0=0) :
    B=sourceTernaryDoubleColumnZero t (B 0 1) (B 1 1) := by
  have hr0 := hB.2.1 0
  have hr1 := hB.2.1 1
  have hr2 := hB.2.1 2
  have hc0 := hB.2.2 0
  have hc1 := hB.2.2 1
  have hc2 := hB.2.2 2
  norm_num [Fin.sum_univ_succ] at hr0 hr1 hr2 hc0 hc1 hc2
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [sourceTernaryDoubleColumnZero] <;> linarith

theorem source_actual_matching_chart (t : Fin 3 → ℝ) (B : Matrix (Fin 3) (Fin 3) ℝ)
    (hB : B ∈ sourceTransportationPolytope t) (hzero : ∀ i,B i i=0) :
    B=sourceTernaryMatchingZeros t (B 0 1) := by
  have hz0 := hzero 0
  have hz1 := hzero 1
  have hz2 := hzero 2
  have hr0 := hB.2.1 0
  have hr1 := hB.2.1 1
  have hr2 := hB.2.1 2
  have hc0 := hB.2.2 0
  have hc1 := hB.2.2 1
  have hc2 := hB.2.2 2
  norm_num [Fin.sum_univ_succ] at hr0 hr1 hr2 hc0 hc1 hc2
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [sourceTernaryMatchingZeros] <;> linarith

end CoefficientStability
