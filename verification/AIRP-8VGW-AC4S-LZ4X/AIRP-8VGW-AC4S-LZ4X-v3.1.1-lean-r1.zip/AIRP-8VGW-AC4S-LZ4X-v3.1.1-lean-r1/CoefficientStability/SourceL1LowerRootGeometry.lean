import CoefficientStability.SourceL1SharpConstants

noncomputable section
namespace CoefficientStability
set_option maxHeartbeats 1200000

def sourceCubicHIntercept (d : ℝ) := 1-10*d-12*d^2
def sourceCubicHSlope (d : ℝ) := 2+30*d-12*d^2
def sourceCubicHDiscriminant (d : ℝ) := (sourceCubicHSlope d)^2+16*(2-d)*sourceCubicHIntercept d
def sourceCubicLowerRoot (d : ℝ) := (sourceCubicHSlope d-Real.sqrt (sourceCubicHDiscriminant d))/(8*(2-d))

theorem source_cubic_H_half_identity (d : ℝ) : sourceCubicH d (1/2)=6*d*(1-3*d) := by unfold sourceCubicH;ring

theorem source_cubic_H_upper_identity (d : ℝ) : sourceCubicH d (3*d/2)=(1-d)*(1-3*d)^2 := by unfold sourceCubicH;ring

theorem source_cubic_H_lower_identity (d : ℝ) : sourceCubicH d ((9*d-1)/4)= -3*d*(3*d-1)*(3*d-5)/4 := by unfold sourceCubicH;ring

theorem source_cubic_H_discriminant_identity (d y : ℝ) :
    16*(2-d)*sourceCubicH d y=sourceCubicHDiscriminant d-(sourceCubicHSlope d-8*(2-d)*y)^2 := by
  unfold sourceCubicH sourceCubicHDiscriminant sourceCubicHIntercept sourceCubicHSlope
  ring

theorem source_cubic_H_discriminant_positive (d : ℝ) (hd : 0 ≤ d) (hd3 : d ≤ 1/3) :
    0 < sourceCubicHDiscriminant d := by
  by_cases h0 : d=0
  · subst d
    norm_num [sourceCubicHDiscriminant,sourceCubicHSlope,sourceCubicHIntercept]
  · by_cases h3 : d=1/3
    · subst d
      norm_num [sourceCubicHDiscriminant,sourceCubicHSlope,sourceCubicHIntercept]
    · have hdpos : 0 < d := lt_of_le_of_ne hd (Ne.symm h0)
      have hdlt : d < 1/3 := lt_of_le_of_ne hd3 h3
      have hH : 0 < sourceCubicH d (1/2) := by
        rw [source_cubic_H_half_identity]
        have hh : 0 < 1-3*d := by linarith
        positivity
      have hp := mul_pos (by linarith : 0 < 16*(2-d)) hH
      have he := source_cubic_H_discriminant_identity d (1/2)
      nlinarith [sq_nonneg (sourceCubicHSlope d-8*(2-d)*(1/2))]

theorem source_cubic_lower_root_substitution (d y : ℝ) (hd : 2-d≠0) :
    sourceCubicH d ((sourceCubicHSlope d-y)/(8*(2-d)))=
      (sourceCubicHDiscriminant d-y^2)/(16*(2-d)) := by
  unfold sourceCubicH sourceCubicHDiscriminant sourceCubicHIntercept sourceCubicHSlope
  field_simp [hd] <;> ring

theorem source_cubic_lower_root_zero (d : ℝ) (hd : 0 ≤ d) (hd3 : d ≤ 1/3) :
    sourceCubicH d (sourceCubicLowerRoot d)=0 := by
  have hD := source_cubic_H_discriminant_positive d hd hd3
  unfold sourceCubicLowerRoot
  rw [source_cubic_lower_root_substitution d _ (by linarith),Real.sq_sqrt hD.le]
  simp

theorem source_cubic_lower_root_Hh (d : ℝ) (hd : 0 ≤ d) (hd3 : d ≤ 1/3) :
    sourceCubicHh d (sourceCubicLowerRoot d)=Real.sqrt (sourceCubicHDiscriminant d) := by
  unfold sourceCubicHh sourceCubicLowerRoot sourceCubicHSlope
  have hn : 2-d≠0 := by linarith
  field_simp [hn] <;> ring

theorem source_cubic_lower_root_upper_bound (d : ℝ) (hd : 0 ≤ d) (hd3 : d ≤ 1/3) :
    sourceCubicLowerRoot d ≤ 3*d/2 := by
  have hD := source_cubic_H_discriminant_positive d hd hd3
  have hs := Real.sq_sqrt hD.le
  let L := sourceCubicHSlope d-8*(2-d)*(3*d/2)
  have hL : 0 < L := by dsimp [L,sourceCubicHSlope];nlinarith
  have hH : 0 ≤ sourceCubicH d (3*d/2) := by
    rw [source_cubic_H_upper_identity]
    exact mul_nonneg (by linarith) (sq_nonneg _)
  have he := source_cubic_H_discriminant_identity d (3*d/2)
  have hp := mul_nonneg (by linarith : 0 ≤ 16*(2-d)) hH
  have hsq : L^2 ≤ sourceCubicHDiscriminant d := by dsimp [L];nlinarith
  have hge : L ≤ Real.sqrt (sourceCubicHDiscriminant d) := by
    by_contra hh
    have hm := mul_pos (by linarith : 0 < L-Real.sqrt (sourceCubicHDiscriminant d))
      (by linarith [Real.sqrt_nonneg (sourceCubicHDiscriminant d)] : 0 < L+Real.sqrt (sourceCubicHDiscriminant d))
    nlinarith [hs]
  unfold sourceCubicLowerRoot
  apply (div_le_iff₀ (by linarith : 0 < 8*(2-d))).mpr
  dsimp [L] at hge
  linarith

theorem source_cubic_lower_root_lower_bound (d : ℝ) (hd : 0 ≤ d) (hd3 : d ≤ 1/3) :
    (9*d-1)/4 ≤ sourceCubicLowerRoot d := by
  have hD := source_cubic_H_discriminant_positive d hd hd3
  have hs := Real.sq_sqrt hD.le
  let L := sourceCubicHSlope d-8*(2-d)*((9*d-1)/4)
  have hL : 0 < L := by dsimp [L,sourceCubicHSlope];nlinarith [sq_nonneg d]
  have hH : sourceCubicH d ((9*d-1)/4) ≤ 0 := by
    rw [source_cubic_H_lower_identity]
    have hm := mul_nonneg hd (mul_nonneg_of_nonpos_of_nonpos (by linarith : 3*d-1 ≤ 0) (by linarith : 3*d-5 ≤ 0))
    nlinarith [hm]
  have he := source_cubic_H_discriminant_identity d ((9*d-1)/4)
  have hp := mul_nonpos_of_nonneg_of_nonpos (by linarith : 0 ≤ 16*(2-d)) hH
  have hsq : sourceCubicHDiscriminant d ≤ L^2 := by dsimp [L];nlinarith
  have hle : Real.sqrt (sourceCubicHDiscriminant d) ≤ L := by
    by_contra hh
    have hm := mul_pos (by linarith : 0 < Real.sqrt (sourceCubicHDiscriminant d)-L)
      (by linarith [Real.sqrt_nonneg (sourceCubicHDiscriminant d)] : 0 < Real.sqrt (sourceCubicHDiscriminant d)+L)
    nlinarith [hs]
  unfold sourceCubicLowerRoot
  apply (le_div_iff₀ (by linarith : 0 < 8*(2-d))).mpr
  dsimp [L] at hle
  linarith

theorem source_cubic_lower_root_endpoints : sourceCubicLowerRoot 0= -1/4 ∧ sourceCubicLowerRoot (1/3)=1/2 := by
  have h36 : Real.sqrt (36 : ℝ)=6 := by
    simpa only [show (6 : ℝ)^2=36 by norm_num,abs_of_pos (by norm_num : (0 : ℝ)<6)] using Real.sqrt_sq_eq_abs (6 : ℝ)
  have h16 : Real.sqrt (16 : ℝ)=4 := by
    simpa only [show (4 : ℝ)^2=16 by norm_num,abs_of_pos (by norm_num : (0 : ℝ)<4)] using Real.sqrt_sq_eq_abs (4 : ℝ)
  norm_num [sourceCubicLowerRoot,sourceCubicHDiscriminant,sourceCubicHSlope,sourceCubicHIntercept,h36,h16]

theorem source_cubic_Hd_strip_bound (d h : ℝ) (hd : 0 ≤ d) (hd3 : d ≤ 1/3)
    (hl : (9*d-1)/4 ≤ h) (hu : h ≤ 3*d/2) : sourceCubicHd d h ≤ -6 := by
  have hlow : -1/4 ≤ h := by linarith
  have hfac := mul_nonneg (by linarith : 0 ≤ 3*d/2-h) (by linarith : 0 ≤ 30-18*d+4*h)
  have hp := mul_nonneg_of_nonpos_of_nonpos (by linarith : 3*d-1 ≤ 0) (by linarith : 9*d-4 ≤ 0)
  unfold sourceCubicHd
  nlinarith [hfac,hp]

end CoefficientStability
