import CoefficientStability.CapacityCandidate

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem simplex_centered_variance (a : Fin n → ℝ) (hn : 0<n) (ha : ∑ i,a i=1) :
    (∑ i,(a i-1/(n : ℝ))^2)=(∑ i,a i^2)-1/(n : ℝ) := by
  have h := simplex_projection_identity a 0 hn ha
  simp only [sub_zero] at h
  have hn0 : (n : ℝ)≠0 := by exact_mod_cast (by omega : n≠0)
  have he : (n : ℝ)*(0-1/(n : ℝ))^2=1/(n : ℝ) := by field_simp;ring
  rw [he] at h
  linarith

theorem positive_capacity_loss (c : ℝ) (b : Fin n → ℝ) (zstar : ℝ)
    (hn : 2≤n) (hc : 0<c) (hb : ∀ i,0<b i) (hz : 0<zstar)
    (hmin : ∀ z : ℝ,0<z → (c*∏ i,(1+b i*zstar))/zstar≤(c*∏ i,(1+b i*z))/z) :
    (c*(∑ i,b i))/((c*∏ i,(1+b i*zstar))/zstar)≥capacityG n*
      (1+((∑ i,(b i*zstar/(1+b i*zstar))^2)-1/(n : ℝ))/128) := by
  let S0 := ∑ i,b i
  let v : Fin n → ℝ := fun i => b i/S0
  let w := ∑ i,(v i-1/(n : ℝ))^2
  let M := (c*∏ i,(1+b i*zstar))/zstar
  have hS0 : 0<S0 := positive_vector_sum_pos b (by omega) hb
  have hv : ∀ i,0<v i := fun i => div_pos (hb i) hS0
  have hvs : ∑ i,v i=1 := normalized_positive_vector_sum b (ne_of_gt hS0)
  have hM : 0<M := div_pos (mul_pos hc (Finset.prod_pos (fun i hi => by nlinarith [hb i]))) hz
  have hg : 0<capacityG n := capacityG_pos hn
  let z0 := (n : ℝ)/(((n : ℝ)-1)*S0)
  have hn' : (2 : ℝ)≤n := by exact_mod_cast hn
  have hz0 : 0<z0 := div_pos (by linarith) (mul_pos (by linarith) hS0)
  have hcandidate := capacity_candidate_identity c b hn hb
  have hfirst : capacityG n*M≤c*S0*(∏ i,(1+v i-1/(n : ℝ))) := by
    have h := mul_le_mul_of_nonneg_left (hmin z0 hz0) hg.le
    change capacityG n*M≤capacityG n*((c*∏ i,(1+b i*z0))/z0) at h
    change capacityG n*((c*∏ i,(1+b i*z0))/z0)=c*S0*(∏ i,(1+v i-1/(n : ℝ))) at hcandidate
    rw [hcandidate] at h
    exact h
  have hprod := capacity_normalized_product_bound v hn hv hvs
  have hbound : capacityG n*M≤c*S0*Real.exp (-w/8) :=
    le_trans hfirst (mul_le_mul_of_nonneg_left hprod (mul_nonneg hc.le hS0.le))
  have he : Real.exp (-w/8)*Real.exp (w/8)=1 := by rw [← Real.exp_add];convert Real.exp_zero using 1 <;> ring
  have hmul := mul_le_mul_of_nonneg_right hbound (Real.exp_pos (w/8)).le
  have hmul' : capacityG n*M*Real.exp (w/8)≤c*S0 := by
    simpa only [mul_assoc,he,mul_one] using hmul
  have hexp : 1+w/8≤Real.exp (w/8) := by simpa [add_comm] using Real.add_one_le_exp (w/8)
  have hlinear : capacityG n*M*(1+w/8)≤c*S0 :=
    le_trans (mul_le_mul_of_nonneg_left hexp (mul_nonneg hg.le hM.le)) hmul'
  have hratio : capacityG n*(1+w/8)≤c*S0/M := by
    apply (le_div_iff₀ hM).mpr
    nlinarith
  have ha : ∑ i,b i*zstar/(1+b i*zstar)=1 := positive_capacity_minimizer_stationarity c b zstar hc hb hz hmin
  have hvar := capacity_fraction_variance_bound v (S0*zstar) hn hv hvs (mul_pos hS0 hz)
  have harg (i : Fin n) : (S0*zstar)*v i=b i*zstar := by dsimp [v];field_simp <;> ring
  simp only [harg] at hvar
  have hvariance := hvar ha
  rw [simplex_centered_variance _ (by omega) ha] at hvariance
  have hsmall : 1+((∑ i,(b i*zstar/(1+b i*zstar))^2)-1/(n : ℝ))/128≤1+w/8 := by
    change _≤16*w at hvariance
    linarith
  exact le_trans (mul_le_mul_of_nonneg_left hsmall hg.le) hratio

end CoefficientStability
