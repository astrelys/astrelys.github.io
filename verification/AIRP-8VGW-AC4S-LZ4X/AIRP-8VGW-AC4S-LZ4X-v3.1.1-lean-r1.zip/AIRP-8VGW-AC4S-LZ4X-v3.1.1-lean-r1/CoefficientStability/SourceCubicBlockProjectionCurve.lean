import CoefficientStability.SourceTwoTraceProjection
import CoefficientStability.SourceCubicBlockRadialMinimum

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 3200000
set_option backward.isDefEq.respectTransparency false

def sourceBlockProjection (K : Matrix (Fin 2) (Fin 2) ℂ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (r : ℝ) : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ :=
  fun i => sourceTwoProjectionCurve K (V i) r

theorem source_block_projection_hermitian (K : Matrix (Fin 2) (Fin 2) ℂ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hK : K.IsHermitian) (hV : ∀ i,(V i).IsHermitian) (r : ℝ) :
    ∀ i,(sourceBlockProjection K V r i).IsHermitian := by
  intro i
  exact (source_two_parallel_hermitian K (V i) hK).add
    ((source_two_perpendicular_hermitian K (V i) hK (hV i)).smul (by simp [IsSelfAdjoint]))

theorem source_block_projection_traceless (K : Matrix (Fin 2) (Fin 2) ℂ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hK : Matrix.trace K=0)
    (hV : ∀ i,Matrix.trace (V i)=0) (r : ℝ) : ∀ i,Matrix.trace (sourceBlockProjection K V r i)=0 := by
  intro i
  simp only [sourceBlockProjection,sourceTwoProjectionCurve,Matrix.trace_add,Matrix.trace_smul,
    source_two_parallel_trace K (V i) hK,source_two_perpendicular_trace K (V i) hK (hV i),smul_zero,add_zero]

theorem source_block_projection_sum (K : Matrix (Fin 2) (Fin 2) ℂ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hs : (∑ i,V i)=0) (r : ℝ) :
    (∑ i,sourceBlockProjection K V r i)=∑ i,V i := by
  simp only [sourceBlockProjection,sourceTwoProjectionCurve,Finset.sum_add_distrib,← Finset.smul_sum,
    source_two_parallel_sum K V hs,source_two_perpendicular_sum K V hs,smul_zero,zero_add,hs]

theorem source_block_projection_continuous (K : Matrix (Fin 2) (Fin 2) ℂ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) : Continuous (sourceBlockProjection K V) := by
  exact continuous_pi (fun i => source_two_projection_curve_continuous K (V i))

@[simp] theorem source_block_projection_zero (K : Matrix (Fin 2) (Fin 2) ℂ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) : sourceBlockProjection K V 0=V := by
  funext i
  exact source_two_projection_curve_zero K (V i)

theorem source_cubic_block_projection_feasible (t a b : Fin 3 → ℝ)
    (K : Matrix (Fin 2) (Fin 2) ℂ) (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (hK : K.IsHermitian) (htK : Matrix.trace K=0) (hq : sourceTwoTraceQuadratic K ≠ 0)
    (hV : ∀ i,(V i).IsHermitian) (ht : ∀ i,Matrix.trace (V i)=0) (hs : (∑ i,V i)=0)
    (hA : sourceCubicBlockTuple a b V ∈ hermitianFeasibleTuples t) (r : ℝ) (hr : r ∈ Set.Icc 0 1) :
    sourceCubicBlockTuple a b (sourceBlockProjection K V r) ∈ hermitianFeasibleTuples t :=
  source_cubic_block_replacement_feasible t a b V _ hV (source_block_projection_hermitian K V hK hV r)
    ht (source_block_projection_traceless K V htK ht r) (source_block_projection_sum K V hs r)
    (fun i => source_two_projection_curve_quadratic_decrease K (V i) hK (hV i) hq r hr) hA

theorem source_cubic_block_projection_objective (a b : Fin 3 → ℝ)
    (K : Matrix (Fin 2) (Fin 2) ℂ) (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (htK : Matrix.trace K=0) (hq : sourceTwoTraceQuadratic K ≠ 0)
    (ht : ∀ i,Matrix.trace (V i)=0) (hs : (∑ i,V i)=0)
    (hN : (∑ i,sourceCubicBlockTuple a b V i)=1) (r : ℝ) :
    hermitianMixedObjective (sourceCubicBlockTuple a b (sourceBlockProjection K V r))=
      hermitianMixedObjective (sourceCubicBlockTuple a b V)+((1-r)^2-1)*
        ∑ i,(1-2*a i)*sourceTwoTraceQuadratic (sourceTwoPerpendicular K (V i)) := by
  have hNr : (∑ i,sourceCubicBlockTuple a b (sourceBlockProjection K V r) i)=1 :=
    (source_cubic_block_sum_replacement a b V _ (source_block_projection_sum K V hs r)).trans hN
  have h := source_cubic_block_tuple_objective_difference a b V (sourceBlockProjection K V r)
    ht (source_block_projection_traceless K V htK ht r) hN hNr
  have he : (∑ i,(1-2*a i)*(sourceTwoTraceQuadratic (sourceBlockProjection K V r i)-sourceTwoTraceQuadratic (V i)))=
      ((1-r)^2-1)*(∑ i,(1-2*a i)*sourceTwoTraceQuadratic (sourceTwoPerpendicular K (V i))) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i hi
    rw [sourceBlockProjection,source_two_projection_curve_quadratic K (V i) hq r,source_two_projection_pythagoras K (V i) hq]
    ring
  rw [he] at h
  linarith

theorem source_cubic_block_projection_hasDerivAt (a b : Fin 3 → ℝ)
    (K : Matrix (Fin 2) (Fin 2) ℂ) (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (htK : Matrix.trace K=0) (hq : sourceTwoTraceQuadratic K ≠ 0)
    (ht : ∀ i,Matrix.trace (V i)=0) (hs : (∑ i,V i)=0)
    (hN : (∑ i,sourceCubicBlockTuple a b V i)=1) :
    HasDerivAt (fun r : ℝ => hermitianMixedObjective (sourceCubicBlockTuple a b (sourceBlockProjection K V r)))
      (-2*∑ i,(1-2*a i)*sourceTwoTraceQuadratic (sourceTwoPerpendicular K (V i))) 0 := by
  rw [funext (source_cubic_block_projection_objective a b K V htK hq ht hs hN)]
  have h := (((((hasDerivAt_id (0 : ℝ)).const_sub 1).pow 2).sub_const 1).mul_const
    (∑ i,(1-2*a i)*sourceTwoTraceQuadratic (sourceTwoPerpendicular K (V i)))).const_add
      (hermitianMixedObjective (sourceCubicBlockTuple a b V))
  simpa using h

theorem source_cubic_block_local_minimum_perpendicular_energy_nonpositive (t a b : Fin 3 → ℝ)
    (K : Matrix (Fin 2) (Fin 2) ℂ) (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (hK : K.IsHermitian) (htK : Matrix.trace K=0) (hq : sourceTwoTraceQuadratic K ≠ 0)
    (hV : ∀ i,(V i).IsHermitian) (ht : ∀ i,Matrix.trace (V i)=0) (hs : (∑ i,V i)=0)
    (hA : sourceCubicBlockTuple a b V ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (sourceCubicBlockTuple a b V)) :
    (∑ i,(1-2*a i)*sourceTwoTraceQuadratic (sourceTwoPerpendicular K (V i))) ≤ 0 := by
  let γ : ℝ → (Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) := fun r => sourceCubicBlockTuple a b (sourceBlockProjection K V r)
  have hc : Continuous γ := source_cubic_block_curve_continuous a b _ (source_block_projection_continuous K V)
  have hz : γ 0=sourceCubicBlockTuple a b V := by simp [γ]
  have hf (r : ℝ) (hr : r ∈ Set.Icc 0 1) : γ r ∈ hermitianFeasibleTuples t :=
    source_cubic_block_projection_feasible t a b K V hK htK hq hV ht hs hA r hr
  have hd := source_cubic_block_projection_hasDerivAt a b K V htK hq ht hs hA.2
  have hn := source_actual_feasible_right_curve_derivative hermitianMixedObjective (hermitianFeasibleTuples t)
    (sourceCubicBlockTuple a b V) γ _ hc hz hf hm hd
  linarith

end CoefficientStability
