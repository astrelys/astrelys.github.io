import CoefficientStability.SmoothedLineFamily

noncomputable section
open scoped Topology
namespace CoefficientStability
variable {n : ℕ}

def smoothedCoefficientPositiveCone (p : MvPolynomial (Fin n) ℝ) (N : ℕ) : Set ((Fin n → ℝ)×ℝ) :=
  {a | ∀ k : Fin (N+1),0<(smoothedLineRestriction p N a.2 a.1).coeff k.val}

theorem smoothedCoefficientPositiveCone_isOpen (p : MvPolynomial (Fin n) ℝ) (N : ℕ) :
    IsOpen (smoothedCoefficientPositiveCone p N) := by
  have h (k : Fin (N+1)) : IsOpen {a : (Fin n → ℝ)×ℝ | 0<(smoothedLineRestriction p N a.2 a.1).coeff k.val} :=
    isOpen_lt continuous_const (smoothedLineRestriction_joint_coefficient_continuous p N k.val)
  simpa only [smoothedCoefficientPositiveCone,Set.ofPred_forall] using isOpen_iInter_of_finite h

theorem spectral_cone_zero_smoothing_mem (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (b : Fin n → ℝ)
    (hb : b∈positiveSpectralCone p N) : (b,(0 : ℝ))∈smoothedCoefficientPositiveCone p N := by
  have hcoeff : b∈coefficientPositiveCone p N := by
    rw [← positiveSpectralCone_eq_coefficientPositiveCone p N hp hs hnorm]
    exact hb
  intro k
  rw [smoothedLineRestriction_zero]
  exact hcoeff k

theorem source_smoothed_coefficients_eventually_positive
    (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (hp : p.IsHomogeneous N)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N) :
    ∀ᶠ a in 𝓝 (b,(0 : ℝ)),∀ k : Fin (N+1),0<(smoothedLineRestriction p N a.2 a.1).coeff k.val :=
  (smoothedCoefficientPositiveCone_isOpen p N).mem_nhds
    (spectral_cone_zero_smoothing_mem p N hp hs hnorm b hb)

end CoefficientStability
