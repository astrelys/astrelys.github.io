import CoefficientStability.SourceCubicSeparationRegion

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 2400000
set_option backward.isDefEq.respectTransparency false

def sourceCubicSeparatorLambda (f : StrongDual ℝ (SourceCubicConstraintSpace × ℝ)) :
    Module.Dual ℝ SourceCubicConstraintSpace where
  toFun q := f (q,0)
  map_add' q r := by simpa using f.map_add (q,0) (r,0)
  map_smul' a q := by simpa using f.map_smul a (q,0)
def sourceCubicSeparatorEta (f : StrongDual ℝ (SourceCubicConstraintSpace × ℝ)) : ℝ := f (0,1)

theorem source_cubic_separator_split (f : StrongDual ℝ (SourceCubicConstraintSpace × ℝ))
    (q : SourceCubicConstraintSpace) (r : ℝ) :
    f (q,r)=sourceCubicSeparatorLambda f q+sourceCubicSeparatorEta f*r := by
  have he : (q,r)=(q,0)+r • (0,1) := by ext <;> simp
  rw [he,map_add,map_smul]
  simp [sourceCubicSeparatorLambda,sourceCubicSeparatorEta,mul_comm]

theorem source_cubic_original_normalized_separator (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (htpos : ∀ i,0 < t i) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A) :
    ∃ ℓ : Module.Dual ℝ SourceCubicConstraintSpace,
      ∀ Y ∈ interior sourceCubicPSDCone,∀ s : ℝ,0 < s →
        sourceCubicGradientDual t A (sourceCubicHermitianBundle A (fun i => (hA.1 i).1))+
          ℓ (sourceCubicConstraintTarget t) < sourceCubicGradientDual t A Y+ℓ (sourceCubicConstraintMap Y)+s := by
  obtain ⟨f,hf⟩ := source_cubic_original_separator_exists t ht A hA hm
  let g := sourceCubicGradientDual t A
  let v := g (sourceCubicHermitianBundle A (fun i => (hA.1 i).1))
  have htarget : sourceCubicConstraintMap (sourceCubicPSDReference t)=sourceCubicConstraintTarget t :=
    source_cubic_psd_reference_constraints t ht
  have hp := hf (sourceCubicPSDReference t) (source_cubic_psd_reference_interior t htpos)
    (1+|g (sourceCubicPSDReference t)-v|) (by positivity)
  rw [htarget,sub_self,source_cubic_separator_split] at hp
  simp only [map_zero,zero_add] at hp
  have hfactor : 0 < g (sourceCubicPSDReference t)-v+(1+|g (sourceCubicPSDReference t)-v|) := by
    linarith [neg_abs_le (g (sourceCubicPSDReference t)-v)]
  have heta : 0 < sourceCubicSeparatorEta f := (mul_pos_iff_of_pos_right hfactor).mp hp
  let ℓ : Module.Dual ℝ SourceCubicConstraintSpace := (sourceCubicSeparatorEta f)⁻¹ • sourceCubicSeparatorLambda f
  refine ⟨ℓ,?_⟩
  intro Y hY s hs
  have hpositive := mul_pos (inv_pos.mpr heta) (hf Y hY s hs)
  have he : g Y+ℓ (sourceCubicConstraintMap Y)+s-(v+ℓ (sourceCubicConstraintTarget t))=
      (sourceCubicSeparatorEta f)⁻¹*f (sourceCubicConstraintMap Y-sourceCubicConstraintTarget t,g Y-v+s) := by
    rw [source_cubic_separator_split,map_sub]
    simp only [ℓ,LinearMap.smul_apply,smul_eq_mul]
    field_simp [ne_of_gt heta] <;> ring
  change 0 < (sourceCubicSeparatorEta f)⁻¹*f (sourceCubicConstraintMap Y-sourceCubicConstraintTarget t,g Y-v+s) at hpositive
  rw [← he] at hpositive
  change v+ℓ (sourceCubicConstraintTarget t) < g Y+ℓ (sourceCubicConstraintMap Y)+s
  linarith

end CoefficientStability
