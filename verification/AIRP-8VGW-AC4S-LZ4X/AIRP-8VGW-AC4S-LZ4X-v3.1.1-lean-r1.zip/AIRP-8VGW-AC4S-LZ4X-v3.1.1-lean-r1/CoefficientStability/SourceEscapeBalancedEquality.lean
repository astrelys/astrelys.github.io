import CoefficientStability.SourceEscapeBalancedApproximation

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

theorem source_escape_three_amgm_equality (x y z : ℝ) (hx : 0 ≤ x) (hy : 0 ≤ y) (hz : 0 ≤ z)
    (hs : 0 < x+y+z) (heq : 27*x*y*z=(x+y+z)^3) : x=y ∧ y=z := by
  have he : (x+y-2*z)^2*(4*(x+y)+z)+27*z*(x-y)^2=0 := by
    linear_combination -4*heq
  have hc : 0 < 4*(x+y)+z := by linarith
  have h1 := mul_nonneg (sq_nonneg (x+y-2*z)) hc.le
  have h2 := mul_nonneg hz (sq_nonneg (x-y))
  have hz1 : (x+y-2*z)^2*(4*(x+y)+z)=0 := by nlinarith
  have hs1 : x+y-2*z=0 := sq_eq_zero_iff.mp ((mul_eq_zero.mp hz1).resolve_right (ne_of_gt hc))
  have hzpos : 0 < z := by by_contra! hn;linarith
  have hz2 : z*(x-y)^2=0 := by nlinarith
  have hs2 : x-y=0 := sq_eq_zero_iff.mp ((mul_eq_zero.mp hz2).resolve_left (ne_of_gt hzpos))
  constructor <;> linarith

theorem source_escape_balanced_crossing_equalities (A : Matrix (Fin 3) (Fin 3) ℝ)
    (hA : A ∈ sourceEscapeTangent) (hq : sourceEscapeQuadratic 1 1 A=sourceEscapeQ 1 1)
    (hF : Matrix.permanent (sourceEscapeCenter 1 1+A)-Matrix.permanent (sourceEscapeCenter 1 1) ≤ sourceEscapeDelta 1 1) :
    Matrix.permanent A=-(1/18) ∧ ∀ i,sourceEscapeRowSq A i=1/6 := by
  have hl := source_escape_actual_crossing_permanent_bound 1 1 (by norm_num) (by norm_num) A hA hq
  have he := source_escape_actual_cubic_expansion 1 1 A hA
  rw [hq] at he
  have hp : Matrix.permanent A=-(1/18) := by
    norm_num [sourceEscapeQ,sourceEscapeDelta] at he hF hl
    linarith
  have hn (i : Fin 3) : 0 ≤ sourceEscapeRowSq A i := Finset.sum_nonneg (fun j _ => sq_nonneg _)
  have hsum : sourceEscapeRowSq A 0+sourceEscapeRowSq A 1+sourceEscapeRowSq A 2=1/2 := by
    have h : 6*sourceEscapeQuadratic 1 1 A=sourceEscapeRowSq A 0+sourceEscapeRowSq A 1+sourceEscapeRowSq A 2 := by
      norm_num [sourceEscapeQuadratic,sourceEscapeWeights,sourceEscapeRowSq,Fin.sum_univ_succ]
      ring
    rw [hq] at h
    norm_num [sourceEscapeQ] at h
    linarith
  have hbound := source_escape_actual_permanent_row_bound A hA
  rw [hp] at hbound
  norm_num [Fin.prod_univ_succ] at hbound
  have hM := source_escape_three_amgm (sourceEscapeRowSq A 0) (sourceEscapeRowSq A 1) (sourceEscapeRowSq A 2) (hn 0) (hn 1) (hn 2)
  rw [hsum] at hM
  have hEq : 27*sourceEscapeRowSq A 0*sourceEscapeRowSq A 1*sourceEscapeRowSq A 2=
      (sourceEscapeRowSq A 0+sourceEscapeRowSq A 1+sourceEscapeRowSq A 2)^3 := by rw [hsum];nlinarith
  have hrows := source_escape_three_amgm_equality _ _ _ (hn 0) (hn 1) (hn 2) (by rw [hsum];norm_num) hEq
  refine ⟨hp,?_⟩
  intro i
  fin_cases i
  · change sourceEscapeRowSq A 0=1/6
    linarith [hrows.1,hrows.2]
  · change sourceEscapeRowSq A 1=1/6
    linarith [hrows.1,hrows.2]
  · change sourceEscapeRowSq A 2=1/6
    linarith [hrows.1,hrows.2]

end CoefficientStability
