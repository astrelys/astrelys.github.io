import CoefficientStability.BalancedLogCoercivity
import CoefficientStability.ConvexRayControl

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem paper_balanced_log_outer_coercivity (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (hcoeff : ∀ g,0≤p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=1)
    (r : ℝ) (hr : 0≤r) (ha : 0<1-(n : ℝ)*r)
    (hUnmixed : ∀ g,0≤(uniformUnmixedPolynomial p n r).coeff g)
    (v : Fin n → ℝ) (hv : ∑ j,v j=0) (hR : 1≤Real.sqrt (∑ j,v j^2)) :
    ((n : ℝ)*r/8)*Real.sqrt (∑ j,v j^2)/2≤Real.log (MvPolynomial.eval (fun j => Real.exp (v j)) p) := by
  let R := Real.sqrt (∑ j,v j^2)
  let a := 1/R
  have hR0 : 0<R := by dsimp [R];linarith
  have hR2 : R^2=(∑ j,v j^2) := Real.sq_sqrt (Finset.sum_nonneg (fun j hj => sq_nonneg (v j)))
  have hunit : (∑ j,(a • v) j^2)=1 := by
    calc
      _ = a^2*(∑ j,v j^2) := by simp only [Pi.smul_apply,smul_eq_mul,mul_pow,Finset.mul_sum]
      _ = a^2*R^2 := by rw [hR2]
      _ = 1 := by dsimp [a];field_simp
  have hzero : (∑ j,(a • v) j)=0 := by
    simp only [Pi.smul_apply,smul_eq_mul,← Finset.mul_sum,hv,mul_zero]
  have hlocal := paper_balanced_log_local_coercivity p hp hcoeff hnorm hgrad r hr ha hUnmixed
    (a • v) (by rw [hunit]) hzero
  rw [hunit,mul_one,← tiltPartition_eval_exp_all] at hlocal
  change ((n : ℝ)*r/8)/2≤logGeneratingRay p v a at hlocal
  have hf0 : logGeneratingRay p v 0=0 := by simp [logGeneratingRay,tiltPartition_eval_exp_all,hnorm]
  have h := convex_outer_linear_lower (logGeneratingRay p v) (logGeneratingRay_convex p v hcoeff hnorm)
    hf0 ((n : ℝ)*r/8) R hR hlocal
  simpa only [R,logGeneratingRay,one_smul,tiltPartition_eval_exp_all] using h

theorem source_small_field_threshold (hn : 3≤n) (r : ℝ) (hr : 0<r) :
    r/(64*(n : ℝ))<((n : ℝ)*r/8)/2 := by
  have hn3 : (3 : ℝ)≤n := by exact_mod_cast hn
  have hn0 : (0 : ℝ)<n := by linarith
  have hN : (1 : ℝ)<4*(n : ℝ)^2 := by nlinarith
  have hm := mul_lt_mul_of_pos_right hN hr
  apply (div_lt_iff₀ (by positivity : 0<64*(n : ℝ))).mpr
  nlinarith only [hm]

theorem paper_balanced_small_field_from_nonnegative_unmixing (p : MvPolynomial (Fin n) ℝ)
    (hn : 3≤n) (hp : p.IsHomogeneous n) (hcoeff : ∀ g,0≤p.coeff g)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=1)
    (r : ℝ) (hr : 0<r) (ha : 0<1-(n : ℝ)*r)
    (hUnmixed : ∀ g,0≤(uniformUnmixedPolynomial p n r).coeff g)
    (u : Fin n → ℝ) (hu : ∑ j,u j=0) (τ : ℝ)
    (hF : Real.log (MvPolynomial.eval (fun j => Real.exp (u j)) p)≤τ)
    (hτ : τ≤r/(64*(n : ℝ))) :
    Real.sqrt (∑ j,u j^2)≤4*Real.sqrt (τ/((n : ℝ)*r)) := by
  have hn0 : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
  have hden : 0<(n : ℝ)*r := mul_pos hn0 hr
  have hS : 0≤∑ j,u j^2 := Finset.sum_nonneg (fun j hj => sq_nonneg (u j))
  have hR2 := Real.sq_sqrt hS
  have hRlt : Real.sqrt (∑ j,u j^2)<1 := by
    by_contra hbad
    have hR : 1≤Real.sqrt (∑ j,u j^2) := le_of_not_gt hbad
    have hout := paper_balanced_log_outer_coercivity p hp hcoeff hnorm hgrad r hr.le ha hUnmixed u hu hR
    have hm := mul_le_mul_of_nonneg_left hR (by positivity : 0≤((n : ℝ)*r/8)/2)
    have hthreshold := source_small_field_threshold hn r hr
    nlinarith only [hout,hm,hF,hτ,hthreshold]
  have hnorm2 : (∑ j,u j^2)≤1 := by nlinarith [Real.sqrt_nonneg (∑ j,u j^2)]
  have hlocal := paper_balanced_log_local_coercivity p hp hcoeff hnorm hgrad r hr.le ha hUnmixed u hnorm2 hu
  have hτ0 : 0≤τ := (show 0≤(((n : ℝ)*r/8)*(∑ j,u j^2))/2 by positivity).trans (hlocal.trans hF)
  have hmul : (n : ℝ)*r*(Real.sqrt (∑ j,u j^2))^2=(n : ℝ)*r*(∑ j,u j^2) :=
    congrArg (fun z : ℝ => (n : ℝ)*r*z) hR2
  have hb : (Real.sqrt (∑ j,u j^2))^2≤(16*τ)/((n : ℝ)*r) := by
    apply (le_div_iff₀ hden).mpr
    nlinarith only [hlocal,hF,hmul]
  have hq : 0≤τ/((n : ℝ)*r) := div_nonneg hτ0 hden.le
  apply (sq_le_sq₀ (Real.sqrt_nonneg _) (mul_nonneg (by norm_num : (0 : ℝ)≤4) (Real.sqrt_nonneg _))).mp
  rw [mul_pow,Real.sq_sqrt hq]
  exact hb.trans_eq (by ring)

end CoefficientStability
