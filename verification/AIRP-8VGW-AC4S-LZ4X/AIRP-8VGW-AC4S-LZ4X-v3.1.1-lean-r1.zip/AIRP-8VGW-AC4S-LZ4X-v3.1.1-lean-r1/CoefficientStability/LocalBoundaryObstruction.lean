import CoefficientStability.ComplexBoundary
import Mathlib.Topology.Order.LocalExtr

noncomputable section
open scoped BigOperators ComplexOrder Topology
namespace CoefficientStability
variable {n : ℕ}

def hermitianFeasibleTuples (t : Fin n → ℝ) : Set (Fin n → Matrix (Fin n) (Fin n) ℂ) :=
  {A | (∀ i,(A i).IsHermitian ∧ (A i).PosSemidef ∧ Matrix.trace (A i)=(t i : ℂ)) ∧ (∑ i,A i)=1}

theorem complexBoundaryTuple_continuous (t : Fin n → ℝ) : Continuous (complexBoundaryTuple t) := by
  apply continuous_pi
  intro i
  apply continuous_pi
  intro r
  apply continuous_pi
  intro l
  simp only [complexBoundaryTuple,Matrix.map_apply,boundaryPerturbedTuple,Matrix.add_apply,Matrix.smul_apply,smul_eq_mul]
  change Continuous (fun s : ℝ => Complex.ofReal (scalarReferenceTuple t i r l+s*boundaryCommutingDirection t i r l))
  fun_prop

theorem complexBoundaryTuple_feasible_near_zero (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) :
    ∃ e : ℝ,0<e ∧ ∀ s : ℝ,|s|<e → complexBoundaryTuple t s∈hermitianFeasibleTuples t := by
  obtain ⟨e,he,hfeas⟩ := paper_boundary_feasible_line t hn ht htpos
  refine ⟨e,he,?_⟩
  intro s hs
  have h := hfeas s hs
  refine ⟨?_,complexBoundaryTuple_sum t (by omega) ht s⟩
  intro i
  exact ⟨complexBoundaryTuple_isHermitian t s i,(complexBoundaryTuple_posDef t s i (h.1 i)).posSemidef,
    complexBoundaryTuple_trace t (by omega) s i⟩

theorem not_localMin_of_complexCurve_descent (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i)
    (hdesc : ∃ e : ℝ,0<e ∧ ∀ s : ℝ,0<s → s<e →
      hermitianMixedObjective (complexBoundaryTuple t s)<hermitianMixedObjective (complexReferenceTuple t)) :
    ¬IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (complexReferenceTuple t) := by
  intro hf
  obtain ⟨ef,hef,hfeas⟩ := complexBoundaryTuple_feasible_near_zero t hn ht htpos
  let J : Set ℝ := Set.Ioo (-ef) ef
  have hmem : J⊆(complexBoundaryTuple t) ⁻¹' hermitianFeasibleTuples t := by
    intro s hs
    exact hfeas s (abs_lt.mpr hs)
  have hz : (0 : ℝ)∈J := by constructor <;> linarith
  have hstart : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (complexBoundaryTuple t 0) := by
    simpa only [complexBoundaryTuple_zero] using hf
  have hcomp := hstart.comp_continuousOn hmem (complexBoundaryTuple_continuous t).continuousOn hz
  have hloc := hcomp.isLocalMin (isOpen_Ioo.mem_nhds hz)
  change ∀ᶠ s in 𝓝 (0 : ℝ),hermitianMixedObjective (complexBoundaryTuple t 0)≤
    hermitianMixedObjective (complexBoundaryTuple t s) at hloc
  obtain ⟨r,hr,hnear⟩ := Metric.eventually_nhds_iff.mp hloc
  obtain ⟨ed,hed,hdes⟩ := hdesc
  let s := min r ed/2
  have hs : 0<s := by dsimp [s];exact div_pos (lt_min hr hed) (by norm_num)
  have hsr : s<r := by have h := min_le_left r ed;dsimp [s];nlinarith [lt_min hr hed]
  have hsd : s<ed := by have h := min_le_right r ed;dsimp [s];nlinarith [lt_min hr hed]
  have hle := hnear (y := s) (by simpa [Real.dist_eq,abs_of_pos hs] using hsr)
  rw [complexBoundaryTuple_zero] at hle
  have hlt := hdes s hs hsd
  linarith

theorem paper_boundary_not_local_min (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : scalarHessianLambda t=0) :
    ¬IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (complexReferenceTuple t) := by
  have hn3 : 3≤n := by
    by_contra h
    have hn2 : n=2 := by omega
    subst n
    have hp := scalarHessian_dimension_two_positive t ht htpos
    rw [hl] at hp
    exact (lt_irrefl (0 : ℝ)) hp
  obtain ⟨e,he,hdesc⟩ := paper_complex_boundary_actual_descent t hn3 ht htpos hl
  apply not_localMin_of_complexCurve_descent t hn ht htpos
  exact ⟨e,he,fun s hs hse => (hdesc s hs hse).2.2.2⟩

end CoefficientStability
