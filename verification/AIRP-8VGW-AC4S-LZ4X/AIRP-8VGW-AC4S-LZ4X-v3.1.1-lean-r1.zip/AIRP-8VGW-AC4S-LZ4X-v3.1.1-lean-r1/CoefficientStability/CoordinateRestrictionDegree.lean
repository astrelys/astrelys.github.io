import CoefficientStability.CapacityGMonotonicity

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem realCoordinateRestriction_monomial (g : Fin n →₀ ℕ) (c : ℝ)
    (x : Fin n → ℝ) (i : Fin n) :
    realCoordinateRestriction x i (monomial g c)=
      Polynomial.C c*∏ j,(if j=i then Polynomial.X else Polynomial.C (x j))^g j := by
  unfold realCoordinateRestriction
  rw [MvPolynomial.eval₂Hom_monomial]
  congr 1
  exact g.prod_fintype _ (by simp)

theorem realCoordinateRestriction_monomial_degree_le (g : Fin n →₀ ℕ) (c : ℝ)
    (x : Fin n → ℝ) (i : Fin n) :
    (realCoordinateRestriction x i (monomial g c)).natDegree≤g i := by
  classical
  rw [realCoordinateRestriction_monomial]
  apply (Polynomial.natDegree_C_mul_le _ _).trans
  apply (Polynomial.natDegree_prod_le Finset.univ
    (fun j : Fin n => (if j=i then Polynomial.X else Polynomial.C (x j))^g j)).trans
  have h : (∑ j,((if j=i then Polynomial.X else Polynomial.C (x j))^g j).natDegree)≤
      ∑ j,if j=i then g j else 0 := by
    apply Finset.sum_le_sum
    intro j hj
    by_cases hji : j=i <;> simp [hji]
  simpa using h

theorem realCoordinateRestriction_degree_le (p : MvPolynomial (Fin n) ℝ)
    (x : Fin n → ℝ) (i : Fin n) : (realCoordinateRestriction x i p).natDegree≤p.degreeOf i := by
  classical
  conv_lhs => rw [p.as_sum]
  rw [map_sum]
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro g hg
  exact (realCoordinateRestriction_monomial_degree_le g (p.coeff g) x i).trans
    (MvPolynomial.le_degreeOf_of_mem_support i hg)

theorem homogeneous_realCoordinateRestriction_degree_le (p : MvPolynomial (Fin n) ℝ)
    (N : ℕ) (hp : p.IsHomogeneous N) (x : Fin n → ℝ) (i : Fin n) :
    (realCoordinateRestriction x i p).natDegree≤N := by
  classical
  conv_lhs => rw [p.as_sum]
  rw [map_sum]
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro g hg
  apply (realCoordinateRestriction_monomial_degree_le g (p.coeff g) x i).trans
  rw [← homogeneous_mass p N hp g hg]
  exact Finset.single_le_sum (fun j hj => Nat.zero_le _) (Finset.mem_univ i)

theorem positive_stable_coordinate_capacity_cutoff (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (hc : ∀ g,0≤p.coeff g)
    (x : Fin n → ℝ) (hx : ∀ j,0<x j) (i : Fin n) (K : ℕ)
    (hK : (realCoordinateRestriction x i p).natDegree≤K) :
    let P := realCoordinateRestriction x i p
    capacityG K*positiveDomainCapacity P≤P.derivative.eval 0 := by
  have h := positive_stable_coordinate_capacity_derivative_lower p hp hc x hx i
  have hpos := (positive_stable_realCoordinateRestriction p hp hc x hx i).2.2
  have hnonneg := positive_ray_capacity_nonneg _ (fun t ht => (hpos t ht).le)
  exact (mul_le_mul_of_nonneg_right (capacityG_antitone hK) hnonneg).trans h

end CoefficientStability
