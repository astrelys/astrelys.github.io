import CoefficientStability.CapacityLogEstimate

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem simplex_projection_identity (a : Fin n → ℝ) (c : ℝ) (hn : 0<n)
    (ha : ∑ i,a i=1) :
    (∑ i,(a i-c)^2)=(∑ i,(a i-1/(n : ℝ))^2)+(n : ℝ)*(c-1/(n : ℝ))^2 := by
  have hn0 : (n : ℝ)≠0 := by exact_mod_cast (by omega : n≠0)
  have he (c : ℝ) : (∑ i,(a i-c)^2)=(∑ i,a i^2)-2*c+(n : ℝ)*c^2 := by
    simp only [sub_sq,Finset.sum_add_distrib,Finset.sum_sub_distrib,Finset.sum_const,
      Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
    have hsum : (∑ i,2*a i*c)=2*c := by
      calc
        _ = 2*c*(∑ i,a i) := by rw [Finset.mul_sum];apply Finset.sum_congr rfl;intro i hi;ring
        _ = _ := by rw [ha,mul_one]
    rw [hsum]
  rw [he,he]
  field_simp
  ring

theorem simplex_projection_minimizes (a : Fin n → ℝ) (c : ℝ) (hn : 0<n)
    (ha : ∑ i,a i=1) : (∑ i,(a i-1/(n : ℝ))^2)≤∑ i,(a i-c)^2 := by
  rw [simplex_projection_identity a c hn ha]
  have h : 0≤(n : ℝ)*(c-1/(n : ℝ))^2 := mul_nonneg (Nat.cast_nonneg _) (sq_nonneg _)
  linarith

theorem capacity_fraction_variance_bound (v : Fin n → ℝ) (S : ℝ) (hn : 2≤n)
    (hv : ∀ i,0<v i) (hvs : ∑ i,v i=1) (hS : 0<S)
    (ha : ∑ i,S*v i/(1+S*v i)=1) :
    (∑ i,(S*v i/(1+S*v i)-1/(n : ℝ))^2)≤16*(∑ i,(v i-1/(n : ℝ))^2) := by
  have hn' : (2 : ℝ)≤n := by exact_mod_cast hn
  have hn0 : (n : ℝ)≠0 := by positivity
  have hrec : 0<1/(n : ℝ) ∧ 1/(n : ℝ)≤1/2 := by
    constructor
    · positivity
    · apply (div_le_iff₀ (by positivity : (0 : ℝ)<n)).mpr
      nlinarith
  have hden (i : Fin n) : 0<1+S*v i := by nlinarith [hv i]
  by_cases hw : (∑ i,(v i-1/(n : ℝ))^2)≤1/16
  · have hvbound (i : Fin n) : v i≤3/4 := by
      have hterm := Finset.single_le_sum (fun j (_ : j∈(Finset.univ : Finset (Fin n))) =>
        sq_nonneg (v j-1/(n : ℝ))) (Finset.mem_univ i)
      nlinarith [sq_nonneg (v i-1/(n : ℝ)+1/4),hrec.2]
    have hSbound : S≤4 := by
      have hd : 0<1+3*S/4 := by linarith
      have hsum := Finset.sum_le_sum (s := Finset.univ) (fun i hi =>
        (div_le_div_iff₀ hd (hden i)).mpr (by
          apply mul_le_mul_of_nonneg_left _ (mul_nonneg hS.le (hv i).le)
          have hmul := mul_le_mul_of_nonneg_left (hvbound i) hS.le
          nlinarith : S*v i*(1+S*v i)≤S*v i*(1+3*S/4)))
      rw [ha,← Finset.sum_div,← Finset.mul_sum,hvs,mul_one] at hsum
      have h := (div_le_iff₀ hd).mp hsum
      nlinarith
    have hpoint (i : Fin n) :
        (S*v i/(1+S*v i)-S/((n : ℝ)+S))^2≤16*(v i-1/(n : ℝ))^2 := by
      have hd : 1≤(1+S*v i)*(1+S/(n : ℝ)) := by
        have h1 : 1≤1+S*v i := by nlinarith [hv i]
        have h2 : 1≤1+S/(n : ℝ) := by
          have hh := div_nonneg hS.le (Nat.cast_nonneg n)
          linarith
        simpa only [one_mul] using mul_le_mul h1 h2 (by norm_num) (by linarith)
      have hdpos : 0<(1+S*v i)*(1+S/(n : ℝ)) := by linarith
      have he : S*v i/(1+S*v i)-S/((n : ℝ)+S)=
          (S*(v i-1/(n : ℝ)))/((1+S*v i)*(1+S/(n : ℝ))) := by
        have hns : (n : ℝ)+S≠0 := by positivity
        have hd2 : 1+S/(n : ℝ)≠0 := by positivity
        field_simp [ne_of_gt (hden i),hns,hd2] <;> ring
      have habs : |S*v i/(1+S*v i)-S/((n : ℝ)+S)|≤4*|v i-1/(n : ℝ)| := by
        rw [he,abs_div,abs_mul,abs_of_pos hS,abs_of_pos hdpos]
        apply (div_le_iff₀ hdpos).mpr
        nlinarith [abs_nonneg (v i-1/(n : ℝ))]
      have hsq := mul_self_le_mul_self (abs_nonneg (S*v i/(1+S*v i)-S/((n : ℝ)+S))) habs
      nlinarith [sq_abs (S*v i/(1+S*v i)-S/((n : ℝ)+S)),sq_abs (v i-1/(n : ℝ))]
    apply le_trans (simplex_projection_minimizes (fun i => S*v i/(1+S*v i))
      (S/((n : ℝ)+S)) (by omega) ha)
    have h := Finset.sum_le_sum (s := Finset.univ) (fun i hi => hpoint i)
    simpa only [← Finset.mul_sum] using h
  · have hvar := simplex_projection_minimizes (fun i => S*v i/(1+S*v i)) 0 (by omega) ha
    simp only [sub_zero] at hvar
    have hsquares : (∑ i,(S*v i/(1+S*v i))^2)≤1 := by
      calc
        _ ≤ ∑ i,S*v i/(1+S*v i) := by
          apply Finset.sum_le_sum
          intro i hi
          have hp : 0<S*v i/(1+S*v i) := div_pos (mul_pos hS (hv i)) (hden i)
          have hlt : S*v i/(1+S*v i)<1 := (div_lt_one (hden i)).mpr (by linarith)
          nlinarith
        _ = 1 := ha
    linarith

end CoefficientStability
