import CoefficientStability.CenteredLogCapacity
import CoefficientStability.TiltLogPartitionDerivatives
import Mathlib.Analysis.Calculus.LocalExtr.Basic

noncomputable section
open scoped BigOperators Topology
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def logCapacityRatio (p : MvPolynomial (Fin n) ℝ) (u : Fin n → ℝ) : ℝ :=
  Real.log (tiltPartition p u)-∑ i,u i

theorem logCapacityRatio_eq_log_ratio (p : MvPolynomial (Fin n) ℝ) (hp : p≠0)
    (hc : ∀ g,0≤p.coeff g) (u : Fin n → ℝ) :
    logCapacityRatio p u=Real.log (MvPolynomial.eval (fun i => Real.exp (u i)) p/(∏ i,Real.exp (u i))) := by
  have hpos := nonnegative_coeff_eval_pos p hp hc (fun i => Real.exp (u i)) (fun i => Real.exp_pos _)
  rw [Real.log_div (ne_of_gt hpos) (Finset.prod_ne_zero_iff.mpr (fun i hi => Real.exp_ne_zero _)),
    Real.log_prod (fun i hi => Real.exp_ne_zero _)]
  simp only [Real.log_exp,logCapacityRatio,tiltPartition_eval_exp_all]

theorem logCapacityRatio_path_hasDerivAt (p : MvPolynomial (Fin n) ℝ)
    (u v : Fin n → ℝ) (hZ : tiltPartition p u≠0) :
    HasDerivAt (fun s : ℝ => logCapacityRatio p (u+s • v))
      (∑ i,(tiltedMoment p u i-1)*v i) 0 := by
  have hlog := tiltLogPartition_path_hasDerivAt p u v 0 (by simpa only [zero_smul,add_zero] using hZ)
  have hsum : HasDerivAt (fun s : ℝ => ∑ i,(u+s • v) i) (∑ i,v i) 0 := by
    have h := HasDerivAt.fun_sum (u := (Finset.univ : Finset (Fin n)))
      (fun i hi => ((hasDerivAt_id (0 : ℝ)).mul_const (v i)).const_add (u i))
    convert! h using 1 <;> simp only [Pi.add_apply,Pi.smul_apply,smul_eq_mul,one_mul,id_eq]
  have h := hlog.sub hsum
  convert! h using 1 <;> simp only [zero_smul,add_zero,sub_mul,one_mul,Finset.sum_sub_distrib]

theorem capacity_attainment_tiltedMoment_one (p : MvPolynomial (Fin n) ℝ)
    (hp : p≠0) (hc : ∀ g,0≤p.coeff g) (u : Fin n → ℝ)
    (hcap : multivariatePositiveCapacity p=
      MvPolynomial.eval (fun i => Real.exp (u i)) p/(∏ i,Real.exp (u i))) :
    ∀ i,tiltedMoment p u i=1 := by
  have hpos (w : Fin n → ℝ) := nonnegative_coeff_eval_pos p hp hc
    (fun i => Real.exp (w i)) (fun i => Real.exp_pos _)
  have hZ : tiltPartition p u≠0 := by rw [tiltPartition_eval_exp_all];exact ne_of_gt (hpos u)
  intro i
  have hmin : IsMinOn (fun s : ℝ => logCapacityRatio p (u+s • Pi.single i 1)) Set.univ 0 := by
    intro s hs
    change logCapacityRatio p (u+(0 : ℝ) • Pi.single i 1)≤logCapacityRatio p (u+s • Pi.single i 1)
    simp only [zero_smul,add_zero]
    rw [logCapacityRatio_eq_log_ratio p hp hc,logCapacityRatio_eq_log_ratio p hp hc]
    apply (Real.log_le_log_iff (div_pos (hpos u) (Finset.prod_pos (fun j hj => Real.exp_pos _)))
      (div_pos (hpos _) (Finset.prod_pos (fun j hj => Real.exp_pos _)))).mpr
    rw [← hcap]
    exact csInf_le (multivariate_capacity_bddBelow p hc) ⟨⟨_,fun j => Real.exp_pos _⟩,rfl⟩
  have hz := (hmin.isLocalMin (by simp)).hasDerivAt_eq_zero
    (logCapacityRatio_path_hasDerivAt p u (Pi.single i 1) hZ)
  have he : (∑ j,(tiltedMoment p u j-1)*(Pi.single i (1 : ℝ) : Fin n → ℝ) j)=tiltedMoment p u i-1 := by
    simp [Pi.single_apply]
  rw [he] at hz
  linarith

end CoefficientStability
