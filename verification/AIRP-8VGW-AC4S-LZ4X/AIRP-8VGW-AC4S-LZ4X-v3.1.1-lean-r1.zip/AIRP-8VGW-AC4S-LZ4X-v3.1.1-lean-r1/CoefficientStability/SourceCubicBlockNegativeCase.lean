import CoefficientStability.SourceCubicBlockProjectionCurve
import CoefficientStability.SourceCubicBlockNonnegativeCase

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 3200000
set_option backward.isDefEq.respectTransparency false

theorem source_cubic_block_tuple_scalar_nonnegative (t a b : Fin 3 → ℝ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (hA : sourceCubicBlockTuple a b V ∈ hermitianFeasibleTuples t) : ∀ i,0 ≤ a i := by
  intro i
  exact (source_one_two_block_psd_components (a i) (sourceTwoCentered (b i) (V i)) (hA.1 i).2.1).1

theorem source_three_probability_large_complement (a : Fin 3 → ℝ) (ha : ∀ i,0 ≤ a i)
    (hs : (∑ i,a i)=1) (k : Fin 3) (hk : 1/2 < a k) : ∀ i,i ≠ k → 0 < 1-2*a i := by
  intro i hik
  have hp : a k+a i ≤ 1 := by
    have h := Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ ({k,i} : Finset (Fin 3)))
      (fun j _ _ => ha j)
    simpa [Finset.sum_pair (Ne.symm hik),hs] using h
  linarith

theorem source_cubic_block_negative_case_commutes (t a b : Fin 3 → ℝ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hV : ∀ i,(V i).IsHermitian)
    (ht : ∀ i,Matrix.trace (V i)=0) (hs : (∑ i,V i)=0)
    (hA : sourceCubicBlockTuple a b V ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (sourceCubicBlockTuple a b V))
    (k : Fin 3) (hk : 1/2 < a k) :
    ∀ i j,sourceCubicBlockTuple a b V i*sourceCubicBlockTuple a b V j=
      sourceCubicBlockTuple a b V j*sourceCubicBlockTuple a b V i := by
  by_cases hVk : V k=0
  · have hcomm := source_three_zero_sum_one_zero_commute V hs ⟨k,hVk⟩
    intro i j
    exact source_one_two_block_commute _ _ _ _ (source_two_centered_commute _ _ _ _ (hcomm i j))
  · have hq : sourceTwoTraceQuadratic (V k) ≠ 0 :=
      ne_of_gt (source_two_trace_quadratic_positive (V k) (hV k) hVk)
    have hpos := source_three_probability_large_complement a
      (source_cubic_block_tuple_scalar_nonnegative t a b V hA) (source_cubic_block_tuple_scalar_sum a b V hA.2) k hk
    have he := source_cubic_block_local_minimum_perpendicular_energy_nonpositive t a b (V k) V
      (hV k) (ht k) hq hV ht hs hA hm
    have hn : ∀ i ∈ Finset.univ,0 ≤ (1-2*a i)*sourceTwoTraceQuadratic (sourceTwoPerpendicular (V k) (V i)) := by
      intro i hi
      by_cases hik : i=k
      · subst i
        simp [source_two_perpendicular_self (V k) hq]
      · exact mul_nonneg (le_of_lt (hpos i hik))
          (source_two_trace_quadratic_nonnegative _ (source_two_perpendicular_hermitian _ _ (hV k) (hV i)))
    have hz : (∑ i,(1-2*a i)*sourceTwoTraceQuadratic (sourceTwoPerpendicular (V k) (V i)))=0 :=
      le_antisymm he (Finset.sum_nonneg hn)
    have heach := (Finset.sum_eq_zero_iff_of_nonneg hn).mp hz
    have hp : ∀ i,sourceTwoPerpendicular (V k) (V i)=0 := by
      intro i
      by_cases hik : i=k
      · subst i
        exact source_two_perpendicular_self _ hq
      · have hzero := (mul_eq_zero.mp (heach i (Finset.mem_univ i))).resolve_left (ne_of_gt (hpos i hik))
        exact (source_two_trace_quadratic_zero_iff _ (source_two_perpendicular_hermitian _ _ (hV k) (hV i))).mp hzero
    have hvp : ∀ i,V i=sourceTwoParallel (V k) (V i) := by
      intro i
      have h := source_two_parallel_add_perpendicular (V k) (V i)
      rw [hp i,add_zero] at h
      exact h.symm
    have hcomm : ∀ i j,V i*V j=V j*V i := by
      intro i j
      rw [hvp i,hvp j]
      simp only [sourceTwoParallel,smul_mul_assoc,mul_smul_comm,smul_smul]
      rw [mul_comm]
    intro i j
    exact source_one_two_block_commute _ _ _ _ (source_two_centered_commute _ _ _ _ (hcomm i j))

theorem source_cubic_block_local_minimum_commutes (t a b : Fin 3 → ℝ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hV : ∀ i,(V i).IsHermitian)
    (ht : ∀ i,Matrix.trace (V i)=0) (hs : (∑ i,V i)=0)
    (hA : sourceCubicBlockTuple a b V ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) (sourceCubicBlockTuple a b V)) :
    ∀ i j,sourceCubicBlockTuple a b V i*sourceCubicBlockTuple a b V j=
      sourceCubicBlockTuple a b V j*sourceCubicBlockTuple a b V i := by
  by_cases ha : ∀ i,a i ≤ 1/2
  · exact source_cubic_block_nonnegative_case_commutes t a b V hV ht hs hA hm ha
  · push_neg at ha
    obtain ⟨k,hk⟩ := ha
    exact source_cubic_block_negative_case_commutes t a b V hV ht hs hA hm k hk

end CoefficientStability
