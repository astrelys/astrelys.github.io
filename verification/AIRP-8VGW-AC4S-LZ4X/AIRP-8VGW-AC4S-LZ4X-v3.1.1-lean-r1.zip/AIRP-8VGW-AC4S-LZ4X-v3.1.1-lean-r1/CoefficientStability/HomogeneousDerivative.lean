import CoefficientStability.StablePartialDerivative
import CoefficientStability.HomogeneousLine

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem homogeneous_partial (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous (N+1)) (i : Fin n) : (pderiv i p).IsHomogeneous N := by
  classical
  intro m hm
  have hpc : p.coeff (m+Finsupp.single i 1)≠0 := by
    intro hz
    apply hm
    simp only [coeff_pderiv,hz,zero_mul]
  have hd := hp hpc
  change Finsupp.weight (1 : Fin n → ℕ) m=N
  change Finsupp.weight (1 : Fin n → ℕ) (m+Finsupp.single i 1)=N+1 at hd
  simp only [map_add,Finsupp.weight_single,Pi.one_apply,smul_eq_mul,mul_one] at hd
  omega

theorem homogeneous_eval_complex_scale (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (a : ℂ) (x : Fin n → ℂ) :
    MvPolynomial.eval₂ Complex.ofRealHom (fun i => a*x i) p=
      a^N*MvPolynomial.eval₂ Complex.ofRealHom x p := by
  classical
  simp only [MvPolynomial.eval₂_eq',Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro g hg
  simp only [mul_pow,Finset.prod_mul_distrib]
  rw [Finset.prod_pow_eq_pow_sum,homogeneous_mass p N hp g hg]
  ring

theorem stable_homogeneous_partial_at_one_nonneg (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous (N+1)) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) (i : Fin n) :
    0≤MvPolynomial.eval (fun _ => 1) (pderiv i p) := by
  have hq := homogeneous_partial p N hp i
  have h := stable_partial_logderiv_im_nonpos p hs (fun _ => Complex.I) (by intro j; simp) i
  have hc (q : MvPolynomial (Fin n) ℝ) :
      MvPolynomial.eval₂ Complex.ofRealHom (fun _ : Fin n => (1 : ℂ)) q=
        ((MvPolynomial.eval (fun _ => (1 : ℝ)) q : ℝ) : ℂ) := by
    simpa using (MvPolynomial.hom_eval₂ q (RingHom.id ℝ) Complex.ofRealHom (fun _ : Fin n => (1 : ℝ))).symm
  have hpI := homogeneous_eval_complex_scale p (N+1) hp Complex.I (fun _ => 1)
  have hqI := homogeneous_eval_complex_scale (pderiv i p) N hq Complex.I (fun _ => 1)
  simp only [mul_one,hc,hnorm,Complex.ofReal_one,mul_one] at hpI hqI
  rw [hpI,hqI] at h
  have he (c : ℝ) : (Complex.I^N*(c : ℂ)/(Complex.I^(N+1))).im= -c := by
    rw [pow_succ]
    have hpow : Complex.I^N≠0 := pow_ne_zero _ Complex.I_ne_zero
    have hi : Complex.I⁻¹= -Complex.I := by simp
    field_simp
    simp [hi]
  rw [he] at h
  linarith

end CoefficientStability
