import CoefficientStability.StableReference

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability

theorem quadraticPolynomial_squarefree_two (Q : Matrix (Fin 2) (Fin 2) ℝ) :
    (quadraticPolynomial Q).coeff (squarefreeExponent 2)=Q 0 1+Q 1 0 := by
  have hterm (i j : Fin 2) :
      ((MvPolynomial.X i : MvPolynomial (Fin 2) ℝ)*MvPolynomial.X j).coeff (squarefreeExponent 2)=
        if i=j then 0 else 1 := by
    simpa [sourceHessianFactor] using scalarLinear_power_two_variables_coefficient
      (fun _ : Fin 2 => 1) (by decide) (fun _ => one_ne_zero) i j
  simp only [quadraticPolynomial,mul_assoc,MvPolynomial.coeff_sum,MvPolynomial.coeff_C_mul,hterm]
  simp [Fin.sum_univ_two]

theorem paper_stable_dimension_two_gap (p : MvPolynomial (Fin 2) ℝ) (t : Fin 2 → ℝ)
    (hp : p.IsHomogeneous 2) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p) (ht : ∑ i,t i=2)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    (p-scalarPower t 2).coeff (squarefreeExponent 2)=referenceDeficit p t 2 := by
  have hex := paper_difference_polynomial_expansion p t 2 (by decide) hp hnorm hstable hgrad
  have he : p-scalarPower t 2= -quadraticPolynomial (deficitMatrix p t 2) := by
    simpa using hex
  rw [he]
  have hc := quadraticPolynomial_squarefree_two (deficitMatrix p t 2)
  have hnull := deficitMatrix_mulVec_one p t 2 (by decide) hp ht hgrad
  have h0 := congrArg (fun z : Fin 2 → ℝ => z 0) hnull
  have h1 := congrArg (fun z : Fin 2 → ℝ => z 1) hnull
  simp only [Matrix.mulVec,dotProduct,mul_one,Pi.zero_apply,Fin.sum_univ_two] at h0 h1
  rw [← trace_deficitMatrix]
  simp only [AddMonoidAlgebra.coeff_neg,Finsupp.neg_apply,hc,Matrix.trace,Matrix.diag,Fin.sum_univ_two]
  linarith

theorem paper_stable_dimension_two_global (p : MvPolynomial (Fin 2) ℝ) (t : Fin 2 → ℝ)
    (hp : p.IsHomogeneous 2) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p) (ht : ∑ i,t i=2)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    (scalarPower t 2).coeff (squarefreeExponent 2)≤p.coeff (squarefreeExponent 2) ∧
    ((scalarPower t 2).coeff (squarefreeExponent 2)=p.coeff (squarefreeExponent 2) ↔ p=scalarPower t 2) := by
  have he := paper_stable_dimension_two_gap p t hp hnorm hstable ht hgrad
  have hd := referenceDeficit_nonneg p t 2 (by decide) hp hnorm hstable hgrad
  have hz := referenceDeficit_zero_iff_scalarPower p t 2 (by decide) hp hnorm hstable ht hgrad
  have hdiff : (p-scalarPower t 2).coeff (squarefreeExponent 2)=
      p.coeff (squarefreeExponent 2)-(scalarPower t 2).coeff (squarefreeExponent 2) := by simp
  rw [hdiff] at he
  constructor
  · linarith
  · constructor
    · intro h
      apply hz.mp
      linarith
    · intro h
      simp [h]

end CoefficientStability
