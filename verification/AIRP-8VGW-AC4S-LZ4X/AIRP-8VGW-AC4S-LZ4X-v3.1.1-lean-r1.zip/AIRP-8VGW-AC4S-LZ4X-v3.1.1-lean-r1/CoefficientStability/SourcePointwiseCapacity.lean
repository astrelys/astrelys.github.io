import CoefficientStability.SourceCumulativeCapacity
import CoefficientStability.PositiveInputIncrements

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem source_monotone_pointwise_capacity_lower (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (x : Fin n → ℝ)
    (hx : ∀ i,0<x i) (hm : Monotone x)
    (hδ : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)<2) :
    (1-(∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)/2)^n*
      (∏ i,x i)≤MvPolynomial.eval x p := by
  have h := source_cumulative_pointwise_capacity_lower p hn hp hs hnorm (tupleInputIncrement x)
    (tupleInputIncrement_nonneg x hx hm) (tupleInputIncrement_initial_pos hn x hx) hδ
  rwa [cumulativeInput_tupleInputIncrement] at h

theorem source_gradient_rename_equiv (p : MvPolynomial (Fin n) ℝ) (e : Equiv.Perm (Fin n)) (i : Fin n) :
    MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i (MvPolynomial.rename e p))=
      MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv (e.symm i) p) := by
  conv_lhs => rw [← e.apply_symm_apply i,MvPolynomial.pderiv_rename e.injective,MvPolynomial.eval_rename]
  rfl

theorem source_gradient_deviation_rename_equiv (p : MvPolynomial (Fin n) ℝ) (e : Equiv.Perm (Fin n)) :
    (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i (MvPolynomial.rename e p))-1|)=
      ∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1| := by
  simp_rw [source_gradient_rename_equiv]
  exact Equiv.sum_comp e.symm (fun i : Fin n => |MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)

theorem source_all_positive_pointwise_capacity_lower (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (x : Fin n → ℝ) (hx : ∀ i,0<x i)
    (hδ : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)<2) :
    (1-(∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)/2)^n*
      (∏ i,x i)≤MvPolynomial.eval x p := by
  classical
  let e := Tuple.sort x
  let y := x ∘ e
  have hqnorm : MvPolynomial.eval (fun _ => 1) (MvPolynomial.rename e.symm p)=1 := by
    simpa only [MvPolynomial.eval_rename,Function.comp_def] using hnorm
  have hqδ : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i (MvPolynomial.rename e.symm p))-1|)<2 := by
    rwa [source_gradient_deviation_rename_equiv]
  have h := source_monotone_pointwise_capacity_lower (MvPolynomial.rename e.symm p) hn
    hp.rename_isHomogeneous (stable_rename_polynomial p hs e.symm) hqnorm y
    (fun i => hx (e i)) (Tuple.monotone_sort x) hqδ
  rw [source_gradient_deviation_rename_equiv,MvPolynomial.eval_rename] at h
  have hcomp : y ∘ e.symm=x := by funext i;simp [y]
  rw [hcomp] at h
  have hprod : (∏ i,y i)=∏ i,x i := Equiv.prod_comp e x
  rwa [hprod] at h

end CoefficientStability
