import CoefficientStability.SourceTernaryFaceCharts

noncomputable section
namespace CoefficientStability
set_option maxHeartbeats 1200000

def sourceTernaryRealZeroPattern (B : Matrix (Fin 3) (Fin 3) ℝ) : Prop :=
  (∀ i j,0 < B i j) ∨
  (B 0 0=0 ∧ ∀ q ∈ sourceOneZeroEntrySet,0 < B q.1 q.2) ∨
  (B 0 0=0 ∧ B 1 1=0 ∧ ∀ q ∈ sourceSeparatedEntrySet,0 < B q.1 q.2) ∨
  (∀ i,B i i=0) ∨ (B 0 0=0 ∧ B 0 1=0) ∨ (B 0 0=0 ∧ B 1 0=0)

theorem source_ternary_real_zero_pattern_exhaustion (B : Matrix (Fin 3) (Fin 3) ℝ)
    (hB : ∀ i j,0 ≤ B i j) : ∃ r c : Equiv.Perm (Fin 3),sourceTernaryRealZeroPattern (sourcePermutedMatrix B r c) := by
  classical
  let Z : Fin 3 → Fin 3 → Bool := fun i j => decide (B i j=0)
  obtain ⟨r,c,hcase⟩ := source_ternary_zero_pattern_exhaustion Z
  let D := sourcePermutedMatrix B r c
  have hn (i j : Fin 3) : 0 ≤ D i j := hB (r i) (c j)
  change sourceTernaryCanonicalZeroPattern (fun i j => decide (D i j=0)) at hcase
  refine ⟨r,c,?_⟩
  change sourceTernaryRealZeroPattern D
  unfold sourceTernaryCanonicalZeroPattern at hcase
  unfold sourceTernaryRealZeroPattern
  rcases hcase with h0 | h1 | h2 | h3 | h4 | h5
  · left
    intro i j
    have hne : D i j≠0 := by simpa using h0 i j
    exact lt_of_le_of_ne (hn i j) (Ne.symm hne)
  · right;left
    refine ⟨by simpa using h1 0 0,?_⟩
    intro q hq
    change q ∈ Finset.univ.erase (0,0) at hq
    have hneq := (Finset.mem_erase.mp hq).1
    have hidx : ¬(q.1=0 ∧ q.2=0) := by
      rintro ⟨ha,hb⟩
      exact hneq (Prod.ext ha hb)
    have hne : D q.1 q.2≠0 := by simpa [hidx] using h1 q.1 q.2
    exact lt_of_le_of_ne (hn q.1 q.2) (Ne.symm hne)
  · right;right;left
    refine ⟨by simpa using h2 0 0,by simpa using h2 1 1,?_⟩
    intro q hq
    change q ∈ (Finset.univ.erase (0,0)).erase (1,1) at hq
    have hneq1 := (Finset.mem_erase.mp hq).1
    have hneq0 := (Finset.mem_erase.mp (Finset.mem_erase.mp hq).2).1
    have hidx : ¬((q.1=0 ∧ q.2=0) ∨ (q.1=1 ∧ q.2=1)) := by
      rintro (⟨ha,hb⟩ | ⟨ha,hb⟩)
      · exact hneq0 (Prod.ext ha hb)
      · exact hneq1 (Prod.ext ha hb)
    have hne : D q.1 q.2≠0 := by simpa [hidx] using h2 q.1 q.2
    exact lt_of_le_of_ne (hn q.1 q.2) (Ne.symm hne)
  · right;right;right;left
    intro i
    simpa using h3 i i
  · right;right;right;right;left
    exact ⟨by simpa using h4.1,by simpa using h4.2⟩
  · right;right;right;right;right
    exact ⟨by simpa using h5.1,by simpa using h5.2⟩

end CoefficientStability
