import CoefficientStability.StationarySliceDeficitLoss

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem balanced_last_optimizing_field_deficit (hn : 3≤n+1)
    (p : MvPolynomial (Fin (n+1)) ℝ) (hp : p.IsHomogeneous (n+1))
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=1)
    (hL : p.coeff (squarefreeExponent (n+1))≤sourceVn (n+1)*(1+capacityEta (n+1)/2)) :
    ∃ u : Fin (n+1) → ℝ,(∑ j,u j=0) ∧
      1≤MvPolynomial.eval (fun j => Real.exp (u j)) p ∧
      MvPolynomial.eval (fun j => Real.exp (u j)) p≤p.coeff (squarefreeExponent (n+1))/sourceVn (n+1) ∧
      tiltedMoment p u (Fin.last n)=1 ∧
      deficitMatrix (tiltedPolynomial p u) (tiltedMoment p u) (n+1) (Fin.last n) (Fin.last n)≤
        64*(p.coeff (squarefreeExponent (n+1))/sourceVn (n+1)-1) := by
  have hc := normalized_homogeneous_stable_coeff_nonneg p (n+1) hp hs hnorm
  have hpp := balanced_nearminimal_pure_coeff_pos (n+1) hn p hp hs hnorm hgrad hL
  obtain ⟨y,hy,hyprod,hycap,hybound⟩ := balanced_last_elimination_capacity_minimizer hn p hp hs hnorm hgrad hL
  have hxy : ∀ k : Fin (n+1),(0 : ℝ)<Fin.lastCases 1 y k := by
    intro k
    refine Fin.lastCases ?_ (fun j => ?_) k
    · simp
    · simpa only [Fin.lastCases_castSucc] using hy j
  let j : Fin n := ⟨0,by omega⟩
  obtain ⟨z,hz,hmin,hcap⟩ := stable_positive_pure_slice_capacity_attained p (n+1) (by omega)
    hp hs hc (Fin.lastCases 1 y) hxy (Fin.last n) j.castSucc (Fin.castSucc_ne_last j) (hpp _) (hpp _)
  let x : Fin (n+1) → ℝ := Fin.lastCases z y
  have hx : ∀ k,0<x k := by
    intro k
    refine Fin.lastCases ?_ (fun l => ?_) k
    · simpa only [x,Fin.lastCases_last] using hz
    · simpa only [x,Fin.lastCases_castSucc] using hy l
  have hprod : (∏ k,x k)=z := by
    dsimp [x]
    rw [Fin.prod_univ_castSucc]
    simp only [Fin.lastCases_castSucc,Fin.lastCases_last,hyprod,one_mul]
  have hfreeze : realCoordinateRestriction x (Fin.last n) p=
      realCoordinateRestriction (Fin.lastCases 1 y) (Fin.last n) p := realCoordinateRestriction_lastCases p y z
  have hm : ∀ t : ℝ,0<t → (realCoordinateRestriction x (Fin.last n) p).eval (x (Fin.last n))/x (Fin.last n)≤
      (realCoordinateRestriction x (Fin.last n) p).eval t/t := by
    intro t ht
    rw [hfreeze]
    simpa only [x,Fin.lastCases_last] using hmin t ht
  have hlower := multivariate_capacity_slice_lower p hc y hy
  rw [paper_balanced_capacity_one p hc hnorm hgrad,hyprod,mul_one] at hlower
  let τ : ℝ := p.coeff (squarefreeExponent (n+1))/sourceVn (n+1)-1
  have hV := sourceVn_pos (by omega : 0<n)
  have hg := capacityG_pos (by omega : 2≤n+1)
  have hratio : p.coeff (squarefreeExponent (n+1))/sourceVn n=capacityG (n+1)*(1+τ) := by
    dsimp [τ]
    rw [sourceVn_capacityG_recurrence]
    field_simp [ne_of_gt hV,ne_of_gt hg] <;> ring
  have hderiv : (realCoordinateRestriction (Fin.lastCases 1 y) (Fin.last n) p).derivative.eval 0≤
      capacityG (n+1)*(1+τ) := by
    rw [← last_elimination_restriction_derivative,← hratio]
    exact hybound
  have hG := positive_stable_coordinate_capacity_cutoff p hs hc (Fin.lastCases 1 y) hxy
    (Fin.last n) (n+1) (homogeneous_realCoordinateRestriction_degree_le p (n+1) hp _ _)
  dsimp only at hG
  have hupper : positiveDomainCapacity (realCoordinateRestriction (Fin.lastCases 1 y) (Fin.last n) p)≤1+τ := by
    nlinarith
  have hstatQ := actual_centered_slice_deficit_loss (by omega) p hp hs hc x hx
    (Fin.last n) j.castSucc (Fin.castSucc_ne_last j) (hpp _) (hpp _) hm
    (hfreeze.symm ▸ hlower) τ (hfreeze.symm ▸ hderiv)
  let u := centeredLogVector x
  have heval : MvPolynomial.eval (fun k => Real.exp (u k)) p=
      positiveDomainCapacity (realCoordinateRestriction (Fin.lastCases 1 y) (Fin.last n) p) := by
    rw [centeredLogVector_capacity_eval (by omega) p hp x hx,hprod]
    dsimp [x]
    rw [← last_real_restriction_eval,← hcap]
  refine ⟨u,centeredLogVector_sum (by omega) x,heval.symm ▸ hlower,?_,hstatQ.1,hstatQ.2⟩
  rw [heval]
  dsimp [τ] at hupper
  linarith only [hupper]

end CoefficientStability
