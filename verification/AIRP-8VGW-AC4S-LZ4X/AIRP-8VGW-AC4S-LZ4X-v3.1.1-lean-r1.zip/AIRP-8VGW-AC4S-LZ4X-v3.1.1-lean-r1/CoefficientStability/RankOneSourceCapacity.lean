import CoefficientStability.NormalizedRankOneSource
import CoefficientStability.PositiveCapacityScaling
import CoefficientStability.SourceCapacityBernoulli

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem rankOne_source_capacity_product_lower (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (j : Fin n) (r : ℝ)
    (hr0 : 0≤r) (hrhalf : r≤1/2)
    (hboundary : (fun i => (if i=j then 1 else 0)-r)∈closure (positiveSpectralCone p n))
    (hsmall : 2*(∑ k,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv k p)-1|)+4*(n : ℝ)*r<1) :
    (1-r)^n*(1-(∑ k,|MvPolynomial.eval (fun _ => 1)
      (MvPolynomial.pderiv k (normalizedRankOnePolynomial p n j r))-1|))^n≤
      multivariatePositiveCapacity (matrixSubstitution (rankOneUnmixingMatrix n j r) p) := by
  have hr1 : r<1 := by linarith
  have ha : 0<(1-r)^n := pow_pos (by linarith) _
  have hprops := normalizedRankOne_source_properties p hn hp hs hnorm j r hr1 hboundary
  have hdist := normalizedRankOne_source_gradient_distance p hn hp hnorm j r hr0 hrhalf
  have hd1 : (∑ k,|MvPolynomial.eval (fun _ => 1)
      (MvPolynomial.pderiv k (normalizedRankOnePolynomial p n j r))-1|)<1 := lt_of_le_of_lt hdist hsmall
  have hcap := source_nearbalanced_capacity_manuscript_bound (normalizedRankOnePolynomial p n j r)
    hn hprops.1 hprops.2.1 hprops.2.2 hd1
  have hcoef := rankOne_source_substitution_coeff_nonneg p hn hn hp hs hnorm j r hr1 hboundary
  have hscale : multivariatePositiveCapacity (normalizedRankOnePolynomial p n j r)=
      ((1-r)^n)⁻¹*multivariatePositiveCapacity (matrixSubstitution (rankOneUnmixingMatrix n j r) p) :=
    multivariatePositiveCapacity_positive_C_mul _ hcoef _ (inv_pos.mpr ha)
  rw [hscale] at hcap
  have h := mul_le_mul_of_nonneg_left hcap ha.le
  have heq : (1-r)^n*(((1-r)^n)⁻¹*
      multivariatePositiveCapacity (matrixSubstitution (rankOneUnmixingMatrix n j r) p))=
      multivariatePositiveCapacity (matrixSubstitution (rankOneUnmixingMatrix n j r) p) := by
    rw [← mul_assoc,mul_inv_cancel₀ (ne_of_gt ha),one_mul]
  rwa [heq] at h

theorem rankOne_source_capacity_linear_lower (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (j : Fin n) (r : ℝ)
    (hr0 : 0≤r) (hrhalf : r≤1/2)
    (hboundary : (fun i => (if i=j then 1 else 0)-r)∈closure (positiveSpectralCone p n))
    (hsmall : 2*(∑ k,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv k p)-1|)+4*(n : ℝ)*r<1) :
    1-2*(n : ℝ)*(∑ k,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv k p)-1|)-5*(n : ℝ)^2*r≤
      multivariatePositiveCapacity (matrixSubstitution (rankOneUnmixingMatrix n j r) p) := by
  let d : ℝ := ∑ k,|MvPolynomial.eval (fun _ => 1)
    (MvPolynomial.pderiv k (normalizedRankOnePolynomial p n j r))-1|
  have hd0 : 0≤d := Finset.sum_nonneg (fun k hk => abs_nonneg _)
  have hdist := normalizedRankOne_source_gradient_distance p hn hp hnorm j r hr0 hrhalf
  have hd1 : d<1 := lt_of_le_of_lt hdist hsmall
  have herror := rankOne_linear_capacity_error n (by omega)
    (∑ k,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv k p)-1|) r d hr0 hdist
  have hbern := rankOne_two_factor_capacity_bernoulli n r d hr0 (by linarith) hd0 hd1.le
  exact herror.trans (hbern.trans (rankOne_source_capacity_product_lower p hn hp hs hnorm j r hr0 hrhalf hboundary hsmall))

end CoefficientStability
