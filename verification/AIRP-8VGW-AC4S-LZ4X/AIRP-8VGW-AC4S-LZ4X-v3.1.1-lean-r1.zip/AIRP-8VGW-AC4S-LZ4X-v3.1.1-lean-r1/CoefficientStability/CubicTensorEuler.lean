import CoefficientStability.CubicTensorCoordinates

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem factorialMonomialCubic_diagonal (g : Fin n →₀ ℕ) (x : Fin n → ℝ) :
    factorialMonomialCubic g (fun _ => x)=
      (∑ i,(g i : ℝ)*x i)^3-3*(∑ i,(g i : ℝ)*x i)*(∑ i,(g i : ℝ)*x i^2)+
        2*(∑ i,(g i : ℝ)*x i^3) := by
  rw [factorialMonomialCubic_apply]
  simp only [exponentLinear_apply]
  have h2 : (∑ i,(g i : ℝ)*(x i*x i*(∑ j,(g j : ℝ)*x j)+
      x i*(∑ j,(g j : ℝ)*x j)*x i+(∑ j,(g j : ℝ)*x j)*x i*x i))=
      3*(∑ j,(g j : ℝ)*x j)*(∑ i,(g i : ℝ)*x i^2) := by
    calc
      _ = ∑ i,3*(∑ j,(g j : ℝ)*x j)*((g i : ℝ)*x i^2) := by
        apply Finset.sum_congr rfl
        intro i hi
        ring
      _ = _ := (Finset.mul_sum _ _ _).symm
  have h3 : (∑ i,(g i : ℝ)*(x i*x i*x i))=(∑ i,(g i : ℝ)*x i^3) := by
    apply Finset.sum_congr rfl
    intro i hi
    ring
  rw [h2,h3]
  ring

theorem rawCubicTensor_as_sum (p : MvPolynomial (Fin n) ℝ) :
    rawCubicTensor p=∑ g∈p.support,p.coeff g • factorialMonomialCubic g := by
  apply symmetric_cubic_diagonal_unique
  · exact symmetrizedMultilinear_permutation _
  · intro v s
    simp only [MultilinearMap.sum_apply,MultilinearMap.smul_apply,
      factorialMonomialCubic_permutation]
  · intro x
    simp only [rawCubicTensor_diagonal,MultilinearMap.sum_apply,MultilinearMap.smul_apply,
      smul_eq_mul,factorialMonomialCubic_diagonal]

theorem exponentLinear_one (g : Fin n →₀ ℕ) (N : ℕ) (hg : ∑ i,g i=N) :
    exponentLinear g (fun _ => 1)=(N : ℝ) := by
  simp only [exponentLinear_apply,mul_one]
  exact_mod_cast hg

theorem factorialMonomialCubic_one (g : Fin n →₀ ℕ) (N : ℕ) (hg : ∑ i,g i=N)
    (x y : Fin n → ℝ) :
    factorialMonomialCubic g ![(fun _ => 1),x,y]=
      ((N : ℝ)-2)*(exponentLinear g x*exponentLinear g y-∑ i,(g i : ℝ)*x i*y i) := by
  rw [factorialMonomialCubic_apply]
  simp only [Matrix.cons_val,Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.cons_val_fin_one,Fin.reduceFinMk,one_mul]
  change exponentLinear g (fun _ => 1)*exponentLinear g x*exponentLinear g y-
    (∑ i,(g i : ℝ)*(x i*exponentLinear g y+exponentLinear g x*y i+
      exponentLinear g (fun _ => 1)*x i*y i))+2*(∑ i,(g i : ℝ)*(x i*y i))=_
  rw [exponentLinear_one g N hg]
  have hxy : (∑ i,(g i : ℝ)*(x i*exponentLinear g y))=exponentLinear g x*exponentLinear g y := by
    rw [exponentLinear_apply g x,Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro i hi
    ring
  have hyx : (∑ i,(g i : ℝ)*(exponentLinear g x*y i))=exponentLinear g x*exponentLinear g y := by
    rw [exponentLinear_apply g y,Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i hi
    ring
  have hNxy : (∑ i,(g i : ℝ)*((N : ℝ)*x i*y i))=(N : ℝ)*(∑ i,(g i : ℝ)*x i*y i) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i hi
    ring
  have he : (∑ i,(g i : ℝ)*(x i*y i))=(∑ i,(g i : ℝ)*x i*y i) := by
    apply Finset.sum_congr rfl
    intro i hi
    ring
  simp only [mul_add,Finset.sum_add_distrib,hxy,hyx,hNxy,he]
  ring

theorem exponentLinear_single (g : Fin n →₀ ℕ) (i : Fin n) :
    exponentLinear g (Pi.single i (1 : ℝ))=(g i : ℝ) := by
  classical
  simp [exponentLinear_apply,Pi.single_apply,Finset.sum_ite_eq']

theorem factorialMonomialCubic_repeated (g : Fin n →₀ ℕ) (i : Fin n) (v : Fin n → ℝ) :
    factorialMonomialCubic g ![Pi.single i (1 : ℝ),Pi.single i (1 : ℝ),v]=
      ((g i : ℝ)^2-(g i : ℝ))*(exponentLinear g v-2*v i) := by
  classical
  rw [factorialMonomialCubic_apply]
  change exponentLinear g (Pi.single i (1 : ℝ))*exponentLinear g (Pi.single i (1 : ℝ))*exponentLinear g v-
    (∑ j,(g j : ℝ)*(((Pi.single i (1 : ℝ) : Fin n → ℝ) j)*((Pi.single i (1 : ℝ) : Fin n → ℝ) j)*exponentLinear g v+
      ((Pi.single i (1 : ℝ) : Fin n → ℝ) j)*exponentLinear g (Pi.single i (1 : ℝ))*v j+
      exponentLinear g (Pi.single i (1 : ℝ))*((Pi.single i (1 : ℝ) : Fin n → ℝ) j)*v j))+
    2*(∑ j,(g j : ℝ)*(((Pi.single i (1 : ℝ) : Fin n → ℝ) j)*((Pi.single i (1 : ℝ) : Fin n → ℝ) j)*v j))=_
  simp only [exponentLinear_single]
  have hs : (∑ j,(g j : ℝ)*(((Pi.single i (1 : ℝ) : Fin n → ℝ) j)*((Pi.single i (1 : ℝ) : Fin n → ℝ) j)*exponentLinear g v+
      ((Pi.single i (1 : ℝ) : Fin n → ℝ) j)*(g i : ℝ)*v j+(g i : ℝ)*((Pi.single i (1 : ℝ) : Fin n → ℝ) j)*v j))=
      (g i : ℝ)*exponentLinear g v+2*(g i : ℝ)^2*v i := by
    rw [Finset.sum_eq_single i]
    · simp
      ring
    · intro j hj hji
      simp [Pi.single_eq_of_ne hji]
    · simp
  have hc : (∑ j,(g j : ℝ)*(((Pi.single i (1 : ℝ) : Fin n → ℝ) j)*((Pi.single i (1 : ℝ) : Fin n → ℝ) j)*v j))=(g i : ℝ)*v i := by
    simp [Pi.single_apply,Finset.sum_ite_eq']
  rw [hs,hc]
  ring

end CoefficientStability
