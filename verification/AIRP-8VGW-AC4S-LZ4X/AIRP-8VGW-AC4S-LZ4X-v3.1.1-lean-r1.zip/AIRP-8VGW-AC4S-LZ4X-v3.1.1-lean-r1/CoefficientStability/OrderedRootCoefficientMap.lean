import CoefficientStability.ProperRootCoefficientMap

noncomputable section
namespace CoefficientStability
variable {N : ℕ}

def monotoneRootVectors (N : ℕ) : Set (Fin N → ℝ) := {r | Monotone r}

theorem monotoneRootVectors_isClosed (N : ℕ) : IsClosed (monotoneRootVectors N) := by
  have h (i j : Fin N) : IsClosed {r : Fin N → ℝ | i≤j → r i≤r j} := by
    by_cases hij : i≤j
    · simpa only [hij,true_implies] using isClosed_le (continuous_apply i) (continuous_apply j)
    · simp only [hij,false_implies,Set.setOf_true,isClosed_univ]
  simpa only [monotoneRootVectors,Monotone,Set.ofPred_forall] using
    isClosed_iInter (fun i => isClosed_iInter (fun j => h i j))

theorem monotone_rootCoefficientVector_injective (r s : Fin N → ℝ)
    (hr : Monotone r) (hs : Monotone s) (hc : rootCoefficientVector r=rootCoefficientVector s) : r=s := by
  have hpoly := rootCoefficientVector_eq_polynomial r s hc
  have hroots := congrArg Polynomial.roots hpoly
  rw [realRootProduct_roots,realRootProduct_roots] at hroots
  have hperm := Multiset.coe_eq_coe.mp hroots
  have hpr : (List.ofFn r).Pairwise (·≤·) := List.pairwise_ofFn.mpr (fun _ _ hij => hr hij.le)
  have hps : (List.ofFn s).Pairwise (·≤·) := List.pairwise_ofFn.mpr (fun _ _ hij => hs hij.le)
  exact List.ofFn_inj.mp (List.Perm.eq_of_pairwise' hpr hps hperm)

def orderedRootCoefficientMap (r : monotoneRootVectors N) : Fin N → ℝ := rootCoefficientVector r.val

theorem orderedRootCoefficientMap_isClosedEmbedding :
    Topology.IsClosedEmbedding (orderedRootCoefficientMap : monotoneRootVectors N → Fin N → ℝ) := by
  have hproper : IsProperMap (orderedRootCoefficientMap : monotoneRootVectors N → Fin N → ℝ) :=
    rootCoefficientVector_isProperMap.restrict (monotoneRootVectors_isClosed N)
  refine Topology.IsClosedEmbedding.of_continuous_injective_isClosedMap hproper.continuous ?_ hproper.isClosedMap
  intro r s h
  apply Subtype.ext
  exact monotone_rootCoefficientVector_injective r.val s.val r.prop s.prop h

theorem ordered_root_vector_continuous {α : Type*} [TopologicalSpace α]
    (r : α → Fin N → ℝ) (hr : ∀ a,Monotone (r a))
    (hc : Continuous (fun a => rootCoefficientVector (r a))) : Continuous r := by
  let g : α → monotoneRootVectors N := fun a => ⟨r a,hr a⟩
  have hg : Continuous g := orderedRootCoefficientMap_isClosedEmbedding.isEmbedding.continuous_iff.mpr hc
  exact continuous_subtype_val.comp hg

end CoefficientStability
