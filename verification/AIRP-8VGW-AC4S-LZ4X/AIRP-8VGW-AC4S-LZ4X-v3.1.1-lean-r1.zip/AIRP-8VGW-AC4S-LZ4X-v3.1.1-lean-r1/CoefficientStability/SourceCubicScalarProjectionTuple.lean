import CoefficientStability.SourceCubicSpectralRankOne

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 2400000
set_option backward.isDefEq.respectTransparency false

def sourceUnitProjection (v : Fin 3 → ℂ) : Matrix (Fin 3) (Fin 3) ℂ := Matrix.vecMulVec v (star v)

theorem source_unit_projection_properties (v : Fin 3 → ℂ) (hv : star v ⬝ᵥ v=1) :
    (sourceUnitProjection v).PosSemidef ∧ sourceUnitProjection v*sourceUnitProjection v=sourceUnitProjection v ∧
      Matrix.trace (sourceUnitProjection v)=1 := by
  refine ⟨Matrix.posSemidef_vecMulVec_self_star v,?_,?_⟩
  · simp [sourceUnitProjection,Matrix.vecMulVec_mul_vecMulVec,hv]
  · rw [sourceUnitProjection,Matrix.trace_vecMulVec,dotProduct_comm]
    exact hv

theorem source_cubic_scalar_multiplier_projection_tuple (t : Fin 3 → ℝ) (h : ℝ)
    (μ : Fin 3 → ℝ) (A S : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t)
    (hc : ∀ i,sourceCubicMatrixGradient (t i) (A i)=(h : ℂ) • 1+(μ i : ℂ) • 1+S i)
    (hSX : ∀ i,S i*A i=0) :
    ∃ (a b : Fin 3 → ℝ) (v : Fin 3 → Fin 3 → ℂ) (c : ℝ),
      (∀ i,star (v i) ⬝ᵥ v i=1) ∧
      (∀ i,A i=(a i : ℂ) • 1+(b i : ℂ) • sourceUnitProjection (v i)) ∧
      c=1-∑ i,a i ∧ (∑ i,(b i : ℂ) • sourceUnitProjection (v i))=(c : ℂ) • 1 := by
  classical
  have hrep (i : Fin 3) : ∃ (a b : ℝ) (v : Fin 3 → ℂ),star v ⬝ᵥ v=1 ∧
      A i=(a : ℂ) • 1+(b : ℂ) • sourceUnitProjection v := by
    have hcert : sourceCubicMatrixGradient (t i) (A i)=((h+μ i : ℝ) : ℂ) • 1+S i := by
      rw [Complex.ofReal_add,add_smul]
      exact hc i
    exact source_cubic_scalar_certificate_rank_one (t i) (h+μ i) (A i) (S i) (hA.1 i).2.1
      (hA.1 i).2.2 hcert (hSX i)
  choose a b v hv he using hrep
  let c := 1-∑ i,a i
  have hfun : A=(fun i => (a i : ℂ) • (1 : Matrix (Fin 3) (Fin 3) ℂ)+(b i : ℂ) • sourceUnitProjection (v i)) := funext he
  have hs := hA.2
  rw [hfun,Finset.sum_add_distrib,← Finset.sum_smul] at hs
  have hcast : (∑ i,(a i : ℂ))=((∑ i,a i : ℝ) : ℂ) := by simp
  rw [hcast] at hs
  have hproj : (∑ i,(b i : ℂ) • sourceUnitProjection (v i))=1-((∑ i,a i : ℝ) : ℂ) • 1 := eq_sub_of_add_eq' hs
  refine ⟨a,b,v,c,hv,he,rfl,?_⟩
  simpa only [c,Complex.ofReal_sub,Complex.ofReal_one,sub_smul,one_smul] using hproj

end CoefficientStability
