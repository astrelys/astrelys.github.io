import CoefficientStability.SourceStableCubicWhitening

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceCubicCongruenceTuple (V : Matrix (Fin 3) (Fin 3) ℂ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ :=
  fun i => V*A i*V.conjTranspose

theorem source_cubic_congruence_tuple_hermitian (V : Matrix (Fin 3) (Fin 3) ℂ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : ∀ i,(A i).IsHermitian) :
    ∀ i,(sourceCubicCongruenceTuple V A i).IsHermitian :=
  fun i => source_cubic_actual_congruence_hermitian V (A i) (hA i)

theorem source_cubic_actual_congruence_pencil (V : Matrix (Fin 3) (Fin 3) ℂ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (x : Fin 3 → ℝ) :
    (∑ i,(x i : ℂ) • sourceCubicCongruenceTuple V A i)=
      V*(∑ i,(x i : ℂ) • A i)*V.conjTranspose := by
  simp only [sourceCubicCongruenceTuple,Matrix.mul_sum,Matrix.sum_mul,mul_smul_comm,smul_mul_assoc]

theorem source_cubic_actual_congruence_polynomial (V : Matrix (Fin 3) (Fin 3) ℂ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : ∀ i,(A i).IsHermitian) :
    realDeterminantPolynomial (sourceCubicCongruenceTuple V A)=
      Complex.normSq (Matrix.det V) • realDeterminantPolynomial A := by
  have hB := source_cubic_congruence_tuple_hermitian V A hA
  have hf : Matrix.det V*Matrix.det V.conjTranspose=(Complex.normSq (Matrix.det V) : ℂ) := by
    rw [Matrix.det_conjTranspose,Complex.star_def,Complex.mul_conj]
  apply MvPolynomial.funext
  intro x
  apply Complex.ofReal_injective
  rw [realDeterminantPolynomial_evaluation _ hB,source_cubic_actual_congruence_pencil,Matrix.det_mul,Matrix.det_mul]
  have he : MvPolynomial.eval x (Complex.normSq (Matrix.det V) • realDeterminantPolynomial A)=
      Complex.normSq (Matrix.det V)*MvPolynomial.eval x (realDeterminantPolynomial A) := by
    simp [MvPolynomial.smul_eq_C_mul]
  rw [he,Complex.ofReal_mul,realDeterminantPolynomial_evaluation A hA,← hf]
  ring

end CoefficientStability
