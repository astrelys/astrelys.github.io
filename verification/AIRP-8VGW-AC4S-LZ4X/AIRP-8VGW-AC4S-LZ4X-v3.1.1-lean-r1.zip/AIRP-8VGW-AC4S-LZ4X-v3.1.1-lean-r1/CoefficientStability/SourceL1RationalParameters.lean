import CoefficientStability.SourceL1Sharpness

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 5000000

def sourceL1EtaStar : ℝ := Real.sqrt (8+Real.sqrt 37)
def sourceL1RationalD (η : ℝ) : ℝ := 1/(η^2-3)
def sourceL1RationalS (η : ℝ) : ℝ := η/(η^2-3)

theorem source_l1_eta_star_bounds : 3<sourceL1EtaStar := by
  have hr := source_sqrt37_exact_bounds.2.1
  have he : (sourceL1EtaStar)^2=8+Real.sqrt 37 := Real.sq_sqrt (by positivity)
  have hn : 0≤sourceL1EtaStar := Real.sqrt_nonneg _
  nlinarith

theorem source_l1_eta_star_d_exact : sourceL1RationalD sourceL1EtaStar=sourceCubicDStar := by
  have he : (sourceL1EtaStar)^2=8+Real.sqrt 37 := Real.sq_sqrt (by positivity)
  have hr2 : (Real.sqrt 37)^2=37 := Real.sq_sqrt (by norm_num)
  have hr : 0<5+Real.sqrt 37 := by positivity
  unfold sourceL1RationalD sourceCubicDStar
  rw [he]
  have hn : 8+Real.sqrt 37-3≠0 := by linarith
  field_simp [hn]
  nlinarith only [hr2]

theorem source_l1_rational_parameter_actual_sqrt (η : ℝ) (hη : 3<η) :
    sourceL1BoundaryS (sourceL1RationalD η)=sourceL1RationalS η := by
  have hden : 0<η^2-3 := by nlinarith
  have hn : 0≤sourceL1RationalS η := div_nonneg (by linarith) hden.le
  have he : (sourceL1RationalS η)^2=sourceL1RationalD η+3*(sourceL1RationalD η)^2 := by
    unfold sourceL1RationalS sourceL1RationalD
    field_simp [ne_of_gt hden] <;> ring
  unfold sourceL1BoundaryS
  rw [← he,Real.sqrt_sq hn]

theorem source_l1_rational_parameter_gap_polynomial (η : ℝ) (hη : η^2-3≠0) :
    1-10*sourceL1RationalD η-12*(sourceL1RationalD η)^2=
      (η^4-16*η^2+27)/(η^2-3)^2 := by
  unfold sourceL1RationalD
  field_simp [hη] <;> ring

theorem source_l1_rational_parameter_d_above_star (η : ℝ) (hη : 3<η)
    (hstar : η<sourceL1EtaStar) : sourceCubicDStar<sourceL1RationalD η := by
  rw [← source_l1_eta_star_d_exact]
  have hden : 0<η^2-3 := by nlinarith
  have hlt : η^2-3<sourceL1EtaStar^2-3 := by
    nlinarith [source_l1_eta_star_bounds]
  exact one_div_lt_one_div_of_lt hden hlt

end CoefficientStability
