import CoefficientStability.MixedRealVariation
import Mathlib.Analysis.Calculus.IteratedDeriv.Defs
import Mathlib.Analysis.Analytic.Constructions

set_option backward.isDefEq.respectTransparency false
noncomputable section
open scoped BigOperators Matrix.Norms.Elementwise Topology
namespace CoefficientStability
variable {n : ℕ}

def actualMixedSeries (A : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    FormalMultilinearSeries ℂ (Fin n → Matrix (Fin n) (Fin n) ℂ) ℂ :=
  (actualMixedContinuous (n := n)).toFormalMultilinearSeries.changeOrigin A

theorem actualMixedSeries_onBall (A : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    HasFPowerSeriesOnBall complexMixedDiscriminant (actualMixedSeries A) A ⊤ := by
  have h := ((actualMixedContinuous (n := n)).hasFiniteFPowerSeriesOnBall.toHasFPowerSeriesOnBall).changeOrigin
    (y := A) (by exact ENNReal.coe_lt_top)
  have he : (actualMixedContinuous : (Fin n → Matrix (Fin n) (Fin n) ℂ) → ℂ)=complexMixedDiscriminant :=
    funext actualMixedContinuous_eq
  have h0 : HasFPowerSeriesOnBall (actualMixedContinuous (n := n)) (actualMixedSeries A) A ⊤ := by
    simpa only [zero_add,ENNReal.top_sub_coe,actualMixedSeries] using h
  exact h0.congr (fun X hX => actualMixedContinuous_eq X)

theorem actualMixedSeries_shift (A : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    HasFPowerSeriesOnBall (fun X => complexMixedDiscriminant (A+X)) (actualMixedSeries A) 0 ⊤ := by
  have h := (actualMixedSeries_onBall A).comp_sub (-A)
  simpa only [add_neg_cancel,sub_neg_eq_add,add_comm] using h

theorem actualMixedSeries_zero (A H : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    (actualMixedSeries A) 0 (fun _ => H)=complexMixedDiscriminant A :=
  (actualMixedSeries_onBall A).coeff_zero _

theorem actualMixedSeries_ray_coefficient (A H : Fin n → Matrix (Fin n) (Fin n) ℂ) (k : ℕ) :
    k.factorial • (actualMixedSeries A) k (fun _ => H)=
      iteratedDeriv k (fun z : ℂ => complexMixedDiscriminant (A+z • H)) 0 := by
  let L : ℂ →L[ℂ] (Fin n → Matrix (Fin n) (Fin n) ℂ) :=
    (1 : ℂ →L[ℂ] ℂ).smulRight H
  have h : HasFPowerSeriesOnBall (fun X => complexMixedDiscriminant (A+X)) (actualMixedSeries A) (L 0) ⊤ := by
    simpa using actualMixedSeries_shift A
  have hc := h.compContinuousLinearMap
  have hd := hc.factorial_smul (1 : ℂ) k
  rw [← iteratedDeriv_eq_iteratedFDeriv] at hd
  simpa only [FormalMultilinearSeries.compContinuousLinearMap,ContinuousMultilinearMap.compContinuousLinearMap_apply,
    Function.comp_def,L,ContinuousLinearMap.smulRight_apply,ContinuousLinearMap.one_apply,one_smul] using hd

theorem actualMixedSeries_one (A H : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    (actualMixedSeries A) 1 (fun _ => H)=
      deriv (fun z : ℂ => complexMixedDiscriminant (A+z • H)) 0 := by
  simpa only [Nat.factorial_one,one_smul,iteratedDeriv_one] using actualMixedSeries_ray_coefficient A H 1

theorem actualMixedSeries_two (A H : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    (2 : ℂ)*(actualMixedSeries A) 2 (fun _ => H)=
      deriv (fun s : ℂ => deriv (fun z : ℂ => complexMixedDiscriminant (A+z • H)) s) 0 := by
  simpa only [Nat.factorial_two,iteratedDeriv_succ,iteratedDeriv_one,iteratedDeriv_zero,nsmul_eq_mul,Nat.cast_ofNat] using
    actualMixedSeries_ray_coefficient A H 2

theorem actualMixedSeries_cubic_remainder (A : Fin n → Matrix (Fin n) (Fin n) ℂ) :
    (fun H => complexMixedDiscriminant (A+H)-(actualMixedSeries A).partialSum 3 H)
      =O[𝓝 0] (fun H => ‖H‖^3) :=
  (actualMixedSeries_onBall A).hasFPowerSeriesAt.isBigO_sub_partialSum_pow 3

end CoefficientStability
