import CoefficientStability.BoundaryDescent

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem boundaryNormalizingFactor_source (t : Fin n → ℝ) :
    boundaryNormalizingFactor t=(n.factorial : ℝ)/(n : ℝ)^n*(∏ i,t i) := by
  unfold boundaryNormalizingFactor
  rw [Finset.prod_div_distrib,Finset.prod_const,Finset.card_univ,Fintype.card_fin]
  ring

theorem factorial_three_factors (n : ℕ) (hn : 3≤n) :
    n.factorial=n*(n-1)*(n-2)*(n-3).factorial := by
  have h0 := Nat.mul_factorial_pred (by omega : n≠0)
  have h1 := Nat.mul_factorial_pred (by omega : n-1≠0)
  have h2 := Nat.mul_factorial_pred (by omega : n-2≠0)
  rw [show n-1-1=n-2 by omega] at h1
  rw [show n-2-1=n-3 by omega] at h2
  rw [← h0,← h1,← h2]
  ring

theorem paper_boundary_cubic_coefficient (t : Fin n → ℝ) (hn : 3≤n) :
    (boundaryMixedPolynomial t).coeff 3=
      (2*((n-3).factorial : ℝ)/(n : ℝ)^(n-3)*(∏ i,t i))*
        centralCoefficient (projectedOnes t) 3*Matrix.trace (boundaryModelMatrix n ^ 3) := by
  have hn0 : (n : ℝ)≠0 := by exact_mod_cast (by omega : n≠0)
  have hf : (n.factorial : ℝ)=(n : ℝ)*((n : ℝ)-1)*((n : ℝ)-2)*((n-3).factorial : ℝ) := by
    have h := congrArg (fun a : ℕ => (a : ℝ)) (factorial_three_factors n hn)
    push_cast at h
    simpa only [Nat.cast_sub (by omega : 1≤n),Nat.cast_sub (by omega : 2≤n),Nat.cast_one,Nat.cast_ofNat] using h
  have hpow : (n : ℝ)^n=(n : ℝ)^3*(n : ℝ)^(n-3) := by
    rw [← pow_add,show 3+(n-3)=n by omega]
  rw [boundaryMixedPolynomial_coeff t (by omega) 3,boundaryNormalizingFactor_source,
    boundaryModelMatrix_trace_cube n (by omega),hf,hpow]
  norm_num
  field_simp

end CoefficientStability
