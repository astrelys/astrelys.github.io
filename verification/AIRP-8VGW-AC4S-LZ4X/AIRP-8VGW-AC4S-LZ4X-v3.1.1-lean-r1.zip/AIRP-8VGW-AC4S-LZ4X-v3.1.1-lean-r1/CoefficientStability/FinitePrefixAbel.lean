import CoefficientStability.SourceSpectralBoundCone

noncomputable section
open scoped BigOperators
namespace CoefficientStability

theorem finite_prefix_weighted_sum_nonneg (N : ℕ) (d w : ℕ → ℝ)
    (hprefix : ∀ k,k≤N → 0≤∑ i∈Finset.range k,d i)
    (hw : ∀ i,i<N → 0≤w i)
    (hanti : ∀ i j,i≤j → j<N → w j≤w i) :
    0≤∑ i∈Finset.range N,w i*d i := by
  induction N generalizing w with
  | zero => simp
  | succ N ih =>
    have hsmall : 0≤∑ i∈Finset.range N,(w i-w N)*d i := by
      apply ih (fun i => w i-w N)
      · intro k hk
        exact hprefix k (by omega)
      · intro i hi
        exact sub_nonneg.mpr (hanti i N (by omega) (by omega))
      · intro i j hij hj
        exact sub_le_sub_right (hanti i j hij (by omega)) _
    have htotal : 0≤w N*(∑ i∈Finset.range (N+1),d i) :=
      mul_nonneg (hw N (by omega)) (hprefix (N+1) le_rfl)
    have heq : (∑ i∈Finset.range (N+1),w i*d i)=
        w N*(∑ i∈Finset.range (N+1),d i)+∑ i∈Finset.range N,(w i-w N)*d i := by
      rw [Finset.sum_range_succ,Finset.sum_range_succ]
      simp_rw [sub_mul,Finset.sum_sub_distrib,← Finset.mul_sum]
      ring
    rw [heq]
    exact add_nonneg htotal hsmall

end CoefficientStability
