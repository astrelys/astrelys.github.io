import CoefficientStability.MatrixEuclideanBounds
import Mathlib.Analysis.Calculus.MeanValue

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem actual_tiltedMoment_euclidean_lipschitz (p : MvPolynomial (Fin n) ℝ)
    (u v : Fin n → ℝ) (hn : 3 ≤ n) (hp : p.IsHomogeneous n)
    (hc : ∀ g,0 ≤ p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) :
    Real.sqrt (∑ i,(tiltedMoment p (u+v) i-tiltedMoment p u i)^2) ≤ (n : ℝ)*Real.sqrt (∑ i,v i^2) := by
  let w : Fin n → ℝ := fun i => tiltedMoment p (u+v) i-tiltedMoment p u i
  let f : ℝ → ℝ := fun s => ∑ i,tiltedMoment p (u+s • v) i*w i
  let d : ℝ → ℝ := fun s => (coefficientCovariance (tiltedPolynomial p (u+s • v))
    (tiltedMoment p (u+s • v))).toBilin' w v
  have hZ (s : ℝ) := ne_of_gt (tiltPartition_pos p (u+s • v) hc hnorm)
  have hd (s : ℝ) : HasDerivAt f (d s) s := by
    have hh := HasDerivAt.fun_sum (u := (Finset.univ : Finset (Fin n)))
      (fun i hi => (tiltedMoment_path_hasDerivAt p u v s (hZ s) i).mul_const (w i))
    convert! hh using 1
    simp only [d,Matrix.toBilin'_apply',dotProduct]
    exact Finset.sum_congr rfl (fun i hi => mul_comm _ _)
  have hb (s : ℝ) : |d s| ≤ (n : ℝ)*Real.sqrt (∑ i,w i^2)*Real.sqrt (∑ i,v i^2) := by
    apply psd_bilinear_euclidean_bound _ (coefficientCovariance_posSemidef _ _
      (tiltedPolynomial_coefficient_nonnegative p (u+s • v) hc hnorm)) (n : ℝ) (by positivity)
    intro x
    exact actual_tilt_covariance_euclidean_upper p (u+s • v) x hn hp hc hnorm hs
  have h := norm_image_sub_le_of_norm_deriv_le_segment_01'
    (fun s hs => (hd s).hasDerivWithinAt) (fun s hs => by simpa only [Real.norm_eq_abs] using hb s)
  have he : f 1-f 0=∑ i,w i^2 := by
    simp only [f,one_smul,zero_smul,add_zero,← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro i hi
    dsimp [w]
    ring
  rw [he,Real.norm_eq_abs,abs_of_nonneg (Finset.sum_nonneg (fun i hi => sq_nonneg _))] at h
  have hw : (Real.sqrt (∑ i,w i^2))^2=∑ i,w i^2 :=
    Real.sq_sqrt (Finset.sum_nonneg (fun i hi => sq_nonneg _))
  change Real.sqrt (∑ i,w i^2) ≤ _
  by_cases hz : Real.sqrt (∑ i,w i^2)=0
  · rw [hz];positivity
  · have hwpos : 0 < Real.sqrt (∑ i,w i^2) := lt_of_le_of_ne (Real.sqrt_nonneg _) (Ne.symm hz)
    by_contra hh
    have hgt : (n : ℝ)*Real.sqrt (∑ i,v i^2) < Real.sqrt (∑ i,w i^2) := lt_of_not_ge hh
    nlinarith [mul_pos hwpos (sub_pos.mpr hgt)]

theorem actual_balancing_path_moment_bound (p : MvPolynomial (Fin n) ℝ)
    (u : Fin n → ℝ) (hn : 3 ≤ n) (hp : p.IsHomogeneous n)
    (hc : ∀ g,0 ≤ p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) (hbal : ∀ i,tiltedMoment p u i=1)
    (s : ℝ) (hseg : s ∈ Set.Icc (0 : ℝ) 1) :
    Real.sqrt (∑ i,(tiltedMoment p (s • u) i-1)^2) ≤ (n : ℝ)*(1-s)*Real.sqrt (∑ i,u i^2) := by
  have h := actual_tiltedMoment_euclidean_lipschitz p (s • u) ((1-s) • u) hn hp hc hnorm hs
  have he : s • u+(1-s) • u=u := by rw [← add_smul];simp
  rw [he] at h
  simp_rw [hbal] at h
  have hleft : (∑ i,(1-tiltedMoment p (s • u) i)^2)=∑ i,(tiltedMoment p (s • u) i-1)^2 := by
    apply Finset.sum_congr rfl
    intro i hi
    ring
  have hright : (∑ i,((1-s) • u) i^2)=(1-s)^2*(∑ i,u i^2) := by
    simp only [Pi.smul_apply,smul_eq_mul,mul_pow,Finset.mul_sum]
  rw [hleft,hright,Real.sqrt_mul (sq_nonneg _),Real.sqrt_sq_eq_abs,
    abs_of_nonneg (sub_nonneg.mpr hseg.2)] at h
  nlinarith only [h]

end CoefficientStability
