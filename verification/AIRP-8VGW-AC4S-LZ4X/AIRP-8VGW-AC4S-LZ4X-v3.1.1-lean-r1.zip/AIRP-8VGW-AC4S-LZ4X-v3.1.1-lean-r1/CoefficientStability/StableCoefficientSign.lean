import CoefficientStability.HomogeneousDerivative

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem stable_scalar_mul (p : MvPolynomial (Fin n) ℝ) (hp : UpperHalfPlaneZeroFree p)
    (c : ℝ) (hc : c≠0) : UpperHalfPlaneZeroFree (C c*p) := by
  intro z hz
  simp only [MvPolynomial.eval₂_mul,MvPolynomial.eval₂_C]
  exact mul_ne_zero (Complex.ofReal_ne_zero.mpr hc) (hp z hz)

theorem homogeneous_stable_eval_one_ne_zero (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p) :
    MvPolynomial.eval (fun _ => 1) p≠0 := by
  intro hz
  have h := hs (fun _ => Complex.I) (by intro i; simp)
  have he := homogeneous_eval_complex_scale p N hp Complex.I (fun _ => 1)
  have hc : MvPolynomial.eval₂ Complex.ofRealHom (fun _ : Fin n => (1 : ℂ)) p=0 := by
    have hh := MvPolynomial.hom_eval₂ p (RingHom.id ℝ) Complex.ofRealHom (fun _ : Fin n => (1 : ℝ))
    simpa [hz] using hh.symm
  apply h
  simpa only [mul_one,hc,mul_zero] using he

theorem positive_homogeneous_partial_at_one_nonneg (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous (N+1)) (hpos : 0<MvPolynomial.eval (fun _ => 1) p)
    (hs : UpperHalfPlaneZeroFree p) (i : Fin n) :
    0≤MvPolynomial.eval (fun _ => 1) (pderiv i p) := by
  let a := MvPolynomial.eval (fun _ => 1) p
  let q := C a⁻¹*p
  have ha : 0<a := hpos
  have hq : q.IsHomogeneous (N+1) := by
    simpa only [zero_add] using (isHomogeneous_C (Fin n) a⁻¹).mul hp
  have hnorm : MvPolynomial.eval (fun _ => 1) q=1 := by simp [q,a,ne_of_gt hpos]
  have hqs : UpperHalfPlaneZeroFree q := stable_scalar_mul p hs a⁻¹ (inv_ne_zero (ne_of_gt ha))
  have h := stable_homogeneous_partial_at_one_nonneg q N hq hnorm hqs i
  have hh : 0≤a⁻¹*MvPolynomial.eval (fun _ => 1) (pderiv i p) := by
    simpa only [q,pderiv_C_mul,MvPolynomial.eval_mul,MvPolynomial.eval_C] using h
  exact (mul_nonneg_iff_of_pos_left (inv_pos.mpr ha)).mp hh

theorem homogeneous_stable_coeff_nonneg (N : ℕ) (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hpos : 0<MvPolynomial.eval (fun _ => 1) p) : ∀ g,0≤p.coeff g := by
  classical
  induction N generalizing p with
  | zero =>
    have he : p=C (p.coeff 0) := MvPolynomial.totalDegree_eq_zero_iff_eq_C.mp
      ((MvPolynomial.totalDegree_zero_iff_isHomogeneous (Fin n)).mpr hp)
    have hval := congrArg (MvPolynomial.eval (fun _ : Fin n => (1 : ℝ))) he
    simp only [MvPolynomial.eval_C] at hval
    have hc : 0<p.coeff 0 := by rwa [hval] at hpos
    intro g
    rw [he,MvPolynomial.coeff_C]
    split_ifs <;> positivity
  | succ N ih =>
    intro g
    by_cases hcg : p.coeff g=0
    · simp [hcg]
    have hg : g≠0 := by
      intro hz
      subst g
      have h := hp hcg
      simpa using h
    obtain ⟨i,hi⟩ : ∃ i,g i≠0 := by
      by_contra h
      push_neg at h
      exact hg (Finsupp.ext h)
    have hqhom := homogeneous_partial p N hp i
    have hqone := positive_homogeneous_partial_at_one_nonneg p N hp hpos hs i
    have hqcoeff : 0≤(pderiv i p).coeff (g-Finsupp.single i 1) := by
      rcases stable_partial_zero_or_stable p hs i with hz | hqstable
      · simp [hz]
      · have hqne := homogeneous_stable_eval_one_ne_zero (pderiv i p) N hqhom hqstable
        exact ih (pderiv i p) hqhom hqstable (lt_of_le_of_ne hqone (Ne.symm hqne)) _
    rw [coeff_pderiv,Finsupp.sub_add_single_one_cancel hi] at hqcoeff
    have hfactor : 0<(((g-Finsupp.single i 1 : Fin n →₀ ℕ) i : ℕ) : ℝ)+1 := by positivity
    exact (mul_nonneg_iff_of_pos_right hfactor).mp hqcoeff

theorem normalized_homogeneous_stable_coeff_nonneg (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) : ∀ g,0≤p.coeff g :=
  homogeneous_stable_coeff_nonneg N p hp hs (by rw [hnorm]; norm_num)

end CoefficientStability
