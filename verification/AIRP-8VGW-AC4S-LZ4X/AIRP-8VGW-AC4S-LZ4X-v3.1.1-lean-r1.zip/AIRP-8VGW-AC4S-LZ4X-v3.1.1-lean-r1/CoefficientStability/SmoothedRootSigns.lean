import CoefficientStability.SmoothedAsymptoticCoefficients

noncomputable section
open scoped Topology
open Filter
namespace CoefficientStability
variable {n : ℕ}

theorem smoothedLineRestriction_monic_splits_degree (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (ε : ℝ) (x : Fin n → ℝ) :
    (smoothedLineRestriction p N ε x).Monic ∧ (smoothedLineRestriction p N ε x).Splits ∧
      (smoothedLineRestriction p N ε x).natDegree=N := by
  have h := nuij_univariate_iterate_properties (lineRestriction p x)
    (normalized_lineRestriction_monic p x N hp hnorm) (lineRestriction_splits p hs x) ε N
  rw [normalized_lineRestriction_natDegree p x N hp hnorm] at h
  exact h

theorem smoothed_affine_root_sign_of_normalized_coefficients
    (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (hp : p.IsHomogeneous N)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (x b : Fin n → ℝ) (ε t r : ℝ) (ht : t≠0)
    (hc : ∀ k : Fin (N+1),0<(smoothedLineRestriction p N (ε/t) (b+(1/t) • x)).coeff k.val)
    (hr : (smoothedLineRestriction p N ε (x+t • b)).IsRoot r) :
    (0<t → r<0) ∧ (t<0 → 0<r) := by
  have hroot := smoothed_affine_root_normalized p N hp x b ε t r ht hr
  have hdegree := (smoothedLineRestriction_monic_splits_degree p N hp hs hnorm (ε/t) (b+(1/t) • x)).2.2
  have hnegative := positive_finite_coefficients_root_neg _ N hdegree.le hc _ hroot
  constructor
  · intro htpos
    by_contra hh
    have hnonneg := mul_nonneg (one_div_pos.mpr htpos).le (le_of_not_gt hh)
    exact not_lt_of_ge hnonneg hnegative
  · intro htneg
    by_contra hh
    have hnonneg := mul_nonneg_of_nonpos_of_nonpos (one_div_neg.mpr htneg).le (le_of_not_gt hh)
    exact not_lt_of_ge hnonneg hnegative

theorem source_smoothed_roots_negative_atTop
    (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (hp : p.IsHomogeneous N)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N) (x : Fin n → ℝ) (ε : ℝ) :
    ∀ᶠ t : ℝ in atTop,∀ r : ℝ,(smoothedLineRestriction p N ε (x+t • b)).IsRoot r → r<0 := by
  have hcoef := normalized_smoothed_coefficients_eventually_positive p N hp hs hnorm b hb x ε atTop
    tendsto_inv_atTop_zero
  filter_upwards [hcoef,eventually_gt_atTop (0 : ℝ)] with t htcoef htpos
  intro r hr
  exact (smoothed_affine_root_sign_of_normalized_coefficients p N hp hs hnorm x b ε t r
    (ne_of_gt htpos) htcoef hr).1 htpos

theorem source_smoothed_roots_positive_atBot
    (p : MvPolynomial (Fin n) ℝ) (N : ℕ) (hp : p.IsHomogeneous N)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N) (x : Fin n → ℝ) (ε : ℝ) :
    ∀ᶠ t : ℝ in atBot,∀ r : ℝ,(smoothedLineRestriction p N ε (x+t • b)).IsRoot r → 0<r := by
  have hcoef := normalized_smoothed_coefficients_eventually_positive p N hp hs hnorm b hb x ε atBot
    tendsto_inv_atBot_zero
  filter_upwards [hcoef,eventually_lt_atBot (0 : ℝ)] with t htcoef htneg
  intro r hr
  exact (smoothed_affine_root_sign_of_normalized_coefficients p N hp hs hnorm x b ε t r
    (ne_of_lt htneg) htcoef hr).2 htneg

end CoefficientStability
