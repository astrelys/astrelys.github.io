import CoefficientStability.SourceCubicConstraintRange
import CoefficientStability.MatrixFrobeniusQuadratic
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas

noncomputable section
open scoped BigOperators Matrix
namespace CoefficientStability
set_option maxHeartbeats 2200000
set_option backward.isDefEq.respectTransparency false

def sourceHermitianTracePairing (n : ℕ) :
    selfAdjoint (ComplexSquare n) →ₗ[ℝ] Module.Dual ℝ (selfAdjoint (ComplexSquare n)) where
  toFun A :=
    { toFun := fun B => (Matrix.trace (A.val*B.val)).re
      map_add' B C := by simp [mul_add,Matrix.trace_add]
      map_smul' a B := by simp [mul_smul_comm,Matrix.trace_smul] }
  map_add' A B := by
    ext C
    simp [add_mul,Matrix.trace_add]
  map_smul' a A := by
    ext C
    simp [smul_mul_assoc,Matrix.trace_smul]

theorem source_hermitian_trace_pairing_nondegenerate {n : ℕ}
    (A : selfAdjoint (ComplexSquare n)) (hA : sourceHermitianTracePairing n A=0) : A=0 := by
  have he := congrArg (fun f : Module.Dual ℝ (selfAdjoint (ComplexSquare n)) => f A) hA
  change (Matrix.trace (A.val*A.val)).re=0 at he
  rw [hermitian_trace_square_frobenius A.val A.property] at he
  by_contra hn
  have hv : A.val≠0 := by
    intro hz
    apply hn
    exact Subtype.ext hz
  have hp := complexFrobeniusSq_pos A.val hv
  linarith

theorem source_hermitian_trace_pairing_injective (n : ℕ) : Function.Injective (sourceHermitianTracePairing n) := by
  intro A B he
  have hz : sourceHermitianTracePairing n (A-B)=0 := by rw [map_sub,he,sub_self]
  exact sub_eq_zero.mp (source_hermitian_trace_pairing_nondegenerate (A-B) hz)

theorem source_hermitian_trace_functional_representation (n : ℕ)
    (f : Module.Dual ℝ (selfAdjoint (ComplexSquare n))) :
    ∃ H : selfAdjoint (ComplexSquare n),∀ X,f X=(Matrix.trace (H.val*X.val)).re := by
  have hdim : Module.finrank ℝ (selfAdjoint (ComplexSquare n))=
      Module.finrank ℝ (Module.Dual ℝ (selfAdjoint (ComplexSquare n))) := (Subspace.dual_finrank_eq).symm
  have hs : Function.Surjective (sourceHermitianTracePairing n) :=
    (LinearMap.injective_iff_surjective_of_finrank_eq_finrank hdim).mp (source_hermitian_trace_pairing_injective n)
  obtain ⟨H,hH⟩ := hs f
  refine ⟨H,?_⟩
  intro X
  exact (congrArg (fun g : Module.Dual ℝ (selfAdjoint (ComplexSquare n)) => g X) hH).symm

end CoefficientStability
