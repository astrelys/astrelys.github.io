import CoefficientStability.BalancedAllOptimizingFields
import CoefficientStability.BalancedThresholdConstants
import CoefficientStability.BalancedRigidityAbsorption

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem real_pi_norm_le_square_sum_sqrt (u : Fin n → ℝ) :
    ‖u‖≤Real.sqrt (∑ j,u j^2) := by
  apply (pi_norm_le_iff_of_nonneg (Real.sqrt_nonneg _)).mpr
  intro i
  rw [Real.norm_eq_abs]
  have hs := Finset.single_le_sum (fun j hj => sq_nonneg (u j)) (Finset.mem_univ i)
  have hroot : (Real.sqrt (∑ j,u j^2))^2=(∑ j,u j^2) :=
    Real.sq_sqrt (Finset.sum_nonneg (fun j hj => sq_nonneg (u j)))
  exact (sq_le_sq₀ (abs_nonneg _) (Real.sqrt_nonneg _)).mp (by simpa only [sq_abs] using hs.trans_eq hroot.symm)

theorem source_mixing_radius_subcritical (hn : 3≤n) : 0<1-(n : ℝ)*sourceMixingRadius n := by
  have hn3 : (3 : ℝ)≤n := by exact_mod_cast hn
  have hn0 : (0 : ℝ)<n := by linarith
  have h := sourceMixingRadius_upper n hn
  have hh := (le_div_iff₀ (by positivity : 0<64*(n : ℝ)^2)).mp h
  have hr := sourceMixingRadius_pos n hn
  nlinarith [mul_nonneg (sub_nonneg.mpr hn3) (mul_nonneg hn0.le hr.le)]

theorem actual_balanced_small_rigidity_from_nonnegative_unmixing (n : ℕ) (hn : 3≤n)
    (p : MvPolynomial (Fin n) ℝ) (hp : p.IsHomogeneous n)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=1)
    (hUnmixed : ∀ g,0≤(uniformUnmixedPolynomial p n (sourceMixingRadius n)).coeff g)
    (hsmall : p.coeff (squarefreeExponent n)/sourceVn n-1≤sourceSmallExcessThreshold n) :
    actualTiltDeficit p 0≤128*(n : ℝ)*(p.coeff (squarefreeExponent n)/sourceVn n-1) := by
  let τ : ℝ := p.coeff (squarefreeExponent n)/sourceVn n-1
  have hτ0 : 0≤τ := normalized_balanced_excess_nonneg n (by omega) p hp hs hnorm hgrad
  have hV := sourceVn_pos (by omega : 0<n)
  have hc := normalized_homogeneous_stable_coeff_nonneg p n hp hs hnorm
  have hb := sourceSmallExcessThreshold_bounds hn
  have hL : p.coeff (squarefreeExponent n)≤sourceVn n*(1+capacityEta n/2) := by
    have h := (hsmall.trans hb.1)
    change p.coeff (squarefreeExponent n)/sourceVn n-1≤capacityEta n/2 at h
    have hh := (div_le_iff₀ hV).mp (show p.coeff (squarefreeExponent n)/sourceVn n≤1+capacityEta n/2 by linarith)
    nlinarith
  have hex := balanced_all_optimizing_fields_deficit n hn p hp hs hnorm hgrad hL
  choose fields hzero hevalpos hevalupper hstat hdiag using hex
  have hfield (i : Fin n) : ‖fields i‖≤1/(100*(n : ℝ)^2) := by
    have hF : Real.log (MvPolynomial.eval (fun j => Real.exp (fields i j)) p)≤τ := by
      have hlog := Real.log_le_sub_one_of_pos (lt_of_lt_of_le (by norm_num) (hevalpos i))
      dsimp [τ]
      linarith [hevalupper i]
    have hr := paper_balanced_small_field_from_nonnegative_unmixing p hn hp hc hnorm hgrad
      (sourceMixingRadius n) (sourceMixingRadius_pos n hn) (source_mixing_radius_subcritical hn)
      hUnmixed (fields i) (hzero i) τ hF (hsmall.trans hb.2)
    exact (real_pi_norm_le_square_sum_sqrt (fields i)).trans
      (hr.trans (source_small_excess_radius_bound hn τ hτ0 hsmall))
  exact paper_balanced_rigidity_field_absorption p hn hp hc hnorm hs τ hτ0 fields hfield hdiag

end CoefficientStability
