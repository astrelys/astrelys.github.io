import CoefficientStability.RootRigidity

noncomputable section
open scoped BigOperators
open Polynomial MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem multiset_abs_sum_bound (s : Multiset ℝ) : |s.sum| ≤ (s.map abs).sum := by
  induction s using Multiset.induction_on with
  | empty => simp
  | @cons a s ih =>
    simp only [Multiset.sum_cons, Multiset.map_cons]
    exact (abs_add_le _ _).trans (add_le_add (le_refl _) ih)

theorem multiset_abs_prod_bound (s : Multiset ℝ) (B : ℝ) (hB : 0 ≤ B)
    (h : ∀ r ∈ s, |r| ≤ B) : |s.prod| ≤ B^s.card := by
  induction s using Multiset.induction_on with
  | empty => simp
  | @cons r s ih =>
    have hr := h r (Multiset.mem_cons_self _ _)
    have hs := ih (fun a ha => h a (Multiset.mem_cons_of_mem ha))
    simpa [Multiset.prod_cons, Multiset.card_cons, abs_mul, pow_succ, mul_comm] using
      mul_le_mul hr hs (abs_nonneg s.prod) hB

theorem multiset_root_abs_bound (s : Multiset ℝ) (r : ℝ) (hr : r ∈ s) :
    |r| ≤ Real.sqrt ((s.map (fun a => a^2)).sum) := by
  have hnonneg : ∀ a ∈ s.map (fun a => a^2), (0 : ℝ) ≤ a := by
    intro a ha
    obtain ⟨b,hb,rfl⟩ := Multiset.mem_map.mp ha
    exact sq_nonneg b
  have hs := Multiset.single_le_sum hnonneg (r^2) (Multiset.mem_map.mpr ⟨r,hr,rfl⟩)
  apply Real.le_sqrt_of_sq_le
  simpa only [sq_abs] using hs

theorem multiset_esymm_abs_bound (s : Multiset ℝ) (k : ℕ) :
    |s.esymm k| ≤ (s.card.choose k : ℝ) * Real.sqrt ((s.map (fun a => a^2)).sum)^k := by
  let B := Real.sqrt ((s.map (fun a => a^2)).sum)
  have hB : 0 ≤ B := Real.sqrt_nonneg _
  have hb : ∀ r ∈ (s.powersetCard k).map (fun t => |t.prod|), r ≤ B^k := by
    intro r hr
    obtain ⟨t,ht,rfl⟩ := Multiset.mem_map.mp hr
    obtain ⟨hsub,hcard⟩ := Multiset.mem_powersetCard.mp ht
    have hp := multiset_abs_prod_bound t B hB (fun a ha => multiset_root_abs_bound s a (Multiset.mem_of_le hsub ha))
    simpa [hcard] using hp
  have hsum := Multiset.sum_le_card_nsmul ((s.powersetCard k).map (fun t => |t.prod|)) (B^k) hb
  have habs := multiset_abs_sum_bound ((s.powersetCard k).map Multiset.prod)
  unfold Multiset.esymm
  calc
    |((s.powersetCard k).map Multiset.prod).sum| ≤
        ((s.powersetCard k).map (fun t => |t.prod|)).sum := by
      simpa only [Multiset.map_map, Function.comp_apply] using habs
    _ ≤ _ := by simpa [Multiset.card_powersetCard, nsmul_eq_mul, B] using hsum

theorem realFactorPolynomial_comp_center (roots : Multiset ℝ) (a : ℝ) :
    (realFactorPolynomial roots).comp (Polynomial.X-Polynomial.C a) =
      realFactorPolynomial (roots.map (fun r => r-a)) := by
  unfold realFactorPolynomial
  rw [Polynomial.multiset_prod_comp]
  simp only [Multiset.map_map, Function.comp_apply, Polynomial.add_comp,
    Polynomial.X_comp, Polynomial.C_comp]
  congr 1
  apply Multiset.map_congr rfl
  intro r hr
  simp only [Polynomial.C_sub]
  ring

def centralLineCoefficient (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (N : ℕ) (x : Fin n → ℝ) (k : ℕ) : ℝ :=
  ((lineRestriction p x).comp
    (Polynomial.X-Polynomial.C ((∑ i, t i*x i)/N))).coeff (N-k)

theorem paper_central_coefficient_bound
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) (x : Fin n → ℝ) (k : ℕ)
    (hN : 2 ≤ N) (hk : k ≤ N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p) = t i) :
    |centralLineCoefficient p t N x k| ≤ (N.choose k : ℝ) *
      Real.sqrt (2*matrixQuadratic (deficitMatrix p t N) x)^k := by
  obtain ⟨roots,hcard,hr,hv⟩ := deficitMatrix_quadratic_is_rootVariance p t N x hN hp hnorm hstable hgrad
  have hsum := factorization_root_sum p x N (by omega) hp hnorm roots hr
  simp only [hgrad] at hsum
  have hc : (∑ i, t i*x i)/N = roots.sum/roots.card := by rw [hcard, hsum]
  have hfactor : (lineRestriction p x).comp (Polynomial.X-Polynomial.C ((∑ i, t i*x i)/N)) =
      realFactorPolynomial (centeredRoots roots) := by
    change lineRestriction p x = realFactorPolynomial roots at hr
    rw [hr, realFactorPolynomial_comp_center, hc]
    rfl
  have hcc := Multiset.prod_X_add_C_coeff (centeredRoots roots) (k := N-k) (by rw [centeredRoots_card, hcard]; omega)
  have hnn : N-(N-k)=k := by omega
  rw [centeredRoots_card, hcard, hnn] at hcc
  change (realFactorPolynomial (centeredRoots roots)).coeff (N-k) = _ at hcc
  have hsq : ((centeredRoots roots).map (fun r => r^2)).sum =
      2*matrixQuadratic (deficitMatrix p t N) x := by
    unfold centeredVariance at hv
    linarith
  unfold centralLineCoefficient
  rw [hfactor, hcc]
  have hb := multiset_esymm_abs_bound (centeredRoots roots) k
  simpa only [centeredRoots_card, hcard, hsq] using hb

theorem paper_central_coefficient_rpow_bound
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) (x : Fin n → ℝ) (k : ℕ)
    (hN : 2 ≤ N) (hk : k ≤ N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p) = t i) :
    |centralLineCoefficient p t N x k| ≤ (N.choose k : ℝ) *
      (2*matrixQuadratic (deficitMatrix p t N) x)^((k : ℝ)/2) := by
  have h0 : 0 ≤ 2*matrixQuadratic (deficitMatrix p t N) x :=
    mul_nonneg (by norm_num) (deficitMatrix_quadratic_nonneg p t N x hN hp hnorm hstable hgrad)
  have he : Real.sqrt (2*matrixQuadratic (deficitMatrix p t N) x)^k =
      (2*matrixQuadratic (deficitMatrix p t N) x)^((k : ℝ)/2) := by
    rw [Real.sqrt_eq_rpow, ← Real.rpow_natCast, ← Real.rpow_mul h0]
    congr 1
    ring
  simpa only [he] using paper_central_coefficient_bound p t N x k hN hk hp hnorm hstable hgrad

theorem centralLineCoefficient_eq_centered_esymm
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) (x : Fin n → ℝ)
    (hN : 2 ≤ N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p) = t i) :
    ∃ roots : Multiset ℝ, roots.card = N ∧
      centeredVariance roots = matrixQuadratic (deficitMatrix p t N) x ∧
      ∀ k ≤ N, centralLineCoefficient p t N x k = (centeredRoots roots).esymm k := by
  obtain ⟨roots,hcard,hr,hv⟩ := deficitMatrix_quadratic_is_rootVariance p t N x hN hp hnorm hstable hgrad
  have hsum := factorization_root_sum p x N (by omega) hp hnorm roots hr
  simp only [hgrad] at hsum
  have hc : (∑ i, t i*x i)/N = roots.sum/roots.card := by rw [hcard, hsum]
  refine ⟨roots,hcard,hv,?_⟩
  intro k hk
  unfold centralLineCoefficient
  change lineRestriction p x = realFactorPolynomial roots at hr
  rw [hr, realFactorPolynomial_comp_center, hc]
  change (realFactorPolynomial (centeredRoots roots)).coeff (N-k) = _
  have hcc := Multiset.prod_X_add_C_coeff (centeredRoots roots) (k := N-k)
    (by rw [centeredRoots_card,hcard]; omega)
  simpa only [realFactorPolynomial,centeredRoots_card,hcard,show N-(N-k)=k by omega] using hcc

theorem paper_first_second_central_coefficients
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) (x : Fin n → ℝ)
    (hN : 2 ≤ N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p) = t i) :
    centralLineCoefficient p t N x 1 = 0 ∧
    centralLineCoefficient p t N x 2 = -matrixQuadratic (deficitMatrix p t N) x := by
  obtain ⟨roots,hcard,hv,hcoeff⟩ := centralLineCoefficient_eq_centered_esymm p t N x hN hp hnorm hstable hgrad
  have hz := centeredRoots_sum roots (by omega)
  constructor
  · rw [hcoeff 1 (by omega),esymm_one,hz]
  · rw [hcoeff 2 hN]
    have hh := esymm_two_identity (centeredRoots roots)
    rw [hz] at hh
    unfold centeredVariance at hv
    linarith

end CoefficientStability
