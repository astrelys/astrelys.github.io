import CoefficientStability.StableLocalVarianceGrowth
import Mathlib.Topology.Order.LocalExtr
import Mathlib.Data.Finsupp.Weight

noncomputable section
open scoped BigOperators Topology
open MvPolynomial Filter
namespace CoefficientStability

abbrev FixedDegreePolynomials (n : ℕ) := MvPolynomial.homogeneousSubmodule (Fin n) ℝ n

instance fixedDegreeCoefficientTopology (n : ℕ) : TopologicalSpace (FixedDegreePolynomials n) :=
  TopologicalSpace.induced (fun (p : FixedDegreePolynomials n) (d : Fin n →₀ ℕ) => p.val.coeff d) inferInstance

theorem fixedDegree_coefficient_continuous (n : ℕ) (d : Fin n →₀ ℕ) :
    Continuous (fun p : FixedDegreePolynomials n => p.val.coeff d) :=
  (continuous_apply d).comp continuous_induced_dom

def degreeExponentSupport (n : ℕ) : Finset (Fin n →₀ ℕ) := (Finsupp.finite_of_degree_eq n).toFinset

theorem homogeneous_support_subset (p : MvPolynomial (Fin n) ℝ) (hp : p.IsHomogeneous n) :
    p.support⊆degreeExponentSupport n := by
  classical
  intro d hd
  change d∈(Finsupp.finite_of_degree_eq n).toFinset
  simp only [Set.Finite.mem_toFinset,Set.mem_setOf_eq]
  by_contra hdeg
  exact (MvPolynomial.mem_support_iff.mp hd) (hp.coeff_eq_zero hdeg)

theorem fixedDegree_coefficientL1_continuous (n : ℕ) (q : FixedDegreePolynomials n) :
    Continuous (fun p : FixedDegreePolynomials n => coefficientL1 (p.val-q.val)) := by
  classical
  have he : (fun p : FixedDegreePolynomials n => coefficientL1 (p.val-q.val))=
      (fun p => ∑ d∈degreeExponentSupport n,|p.val.coeff d-q.val.coeff d|) := by
    funext p
    rw [coefficientL1_eq_sum_on _ _ (homogeneous_support_subset _ (p.property.sub q.property))]
    simp
  rw [he]
  apply continuous_finset_sum
  intro d hd
  exact ((fixedDegree_coefficient_continuous n d).sub continuous_const).abs

def fixedDegreeReference (t : Fin n → ℝ) : FixedDegreePolynomials n :=
  ⟨scalarPower t n,scalarPower_homogeneous t n⟩

def stableCoefficientClass (t : Fin n → ℝ) : Set (FixedDegreePolynomials n) :=
  {p | MvPolynomial.eval (fun _ => 1) p.val=1 ∧ UpperHalfPlaneZeroFree p.val ∧
    (∀ d,0≤p.val.coeff d) ∧ ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p.val)=t i}

def fixedDegreeObjective (p : FixedDegreePolynomials n) : ℝ := p.val.coeff (squarefreeExponent n)

theorem paper_stable_topological_local_minimum (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i)
    (hradius : (∑ i,(t i-1)^2)<(n : ℝ)/((n : ℝ)-1)) :
    IsLocalMinOn fixedDegreeObjective (stableCoefficientClass t) (fixedDegreeReference t) := by
  obtain ⟨a,e,ha,he,hgrowth⟩ := paper_stable_local_coefficient_growth t hn ht htpos
    ((scalarHessianLambda_pos_iff_radius t hn ht).mpr hradius)
  have hopen : IsOpen {p : FixedDegreePolynomials n | coefficientL1 (p.val-(fixedDegreeReference t).val)<e} :=
    isOpen_lt (fixedDegree_coefficientL1_continuous n _) continuous_const
  have hnear : ∀ᶠ p in 𝓝 (fixedDegreeReference t),coefficientL1 (p.val-(fixedDegreeReference t).val)<e :=
    hopen.mem_nhds (by simpa only [sub_self,coefficientL1_zero,Set.mem_setOf_eq] using he)
  change ∀ᶠ p in 𝓝[stableCoefficientClass t] (fixedDegreeReference t),
    fixedDegreeObjective (fixedDegreeReference t)≤fixedDegreeObjective p
  filter_upwards [self_mem_nhdsWithin,hnear.filter_mono nhdsWithin_le_nhds] with p hp hclose
  have hg := (hgrowth p.val p.property hp.1 hp.2.1 hp.2.2.2 hclose).1
  have hd := referenceDeficit_nonneg p.val t n hn p.property hp.1 hp.2.1 hp.2.2.2
  have hnonneg := le_trans (mul_nonneg ha.le hd) hg
  change (scalarPower t n).coeff (squarefreeExponent n)≤p.val.coeff (squarefreeExponent n)
  simpa [sub_nonneg] using hnonneg

end CoefficientStability
