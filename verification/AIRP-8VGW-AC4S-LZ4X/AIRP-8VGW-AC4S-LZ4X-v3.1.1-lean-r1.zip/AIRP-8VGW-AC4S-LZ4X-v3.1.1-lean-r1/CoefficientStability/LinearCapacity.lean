import CoefficientStability.UnivariateCapacityBound

noncomputable section
namespace CoefficientStability

theorem affine_positive_domain_capacity (a b : ℝ) (ha : 0≤a) :
    positiveDomainCapacity (Polynomial.C a+Polynomial.C b*Polynomial.X)=b := by
  let f : Polynomial ℝ := Polynomial.C a+Polynomial.C b*Polynomial.X
  let S := Set.range (fun z : {z : ℝ // 0<z} => f.eval (z : ℝ)/(z : ℝ))
  change sInf S=b
  by_cases ha0 : a=0
  · have he : S={b} := by
      ext y
      constructor
      · rintro ⟨z,rfl⟩
        have hz : (z : ℝ)≠0 := ne_of_gt z.prop
        simp [f,ha0,hz]
      · intro hy
        have hyb : y=b := Set.mem_singleton_iff.mp hy
        subst y
        refine ⟨⟨1,by norm_num⟩,?_⟩
        simp [f,ha0]
    rw [he,csInf_singleton]
  · have hap : 0<a := lt_of_le_of_ne ha (Ne.symm ha0)
    have he : S=Set.Ioi b := by
      ext y
      constructor
      · rintro ⟨z,rfl⟩
        change b<f.eval (z : ℝ)/(z : ℝ)
        rw [Polynomial.eval_add,Polynomial.eval_C,Polynomial.eval_mul,Polynomial.eval_C,Polynomial.eval_X]
        apply (lt_div_iff₀ z.prop).mpr
        linarith
      · intro hy
        have hgap : 0<y-b := sub_pos.mpr hy
        have hz : 0<a/(y-b) := div_pos hap hgap
        refine ⟨⟨a/(y-b),hz⟩,?_⟩
        change f.eval (a/(y-b))/(a/(y-b))=y
        simp only [f,Polynomial.eval_add,Polynomial.eval_C,Polynomial.eval_mul,Polynomial.eval_X]
        field_simp
        ring
    rw [he,csInf_Ioi]

theorem affine_capacity_derivative_identity (a b : ℝ) (ha : 0≤a) :
    positiveDomainCapacity (Polynomial.C a+Polynomial.C b*Polynomial.X)=
      (Polynomial.C a+Polynomial.C b*Polynomial.X).derivative.eval 0 := by
  rw [affine_positive_domain_capacity a b ha]
  simp

theorem constant_positive_domain_capacity (a : ℝ) (ha : 0≤a) :
    positiveDomainCapacity (Polynomial.C a)=0 := by
  simpa using affine_positive_domain_capacity a 0 ha

end CoefficientStability
