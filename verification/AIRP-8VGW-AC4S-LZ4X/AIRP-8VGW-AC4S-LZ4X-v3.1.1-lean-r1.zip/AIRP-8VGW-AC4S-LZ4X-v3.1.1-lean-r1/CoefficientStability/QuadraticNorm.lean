import CoefficientStability.CoefficientNorm
import CoefficientStability.CovarianceBridge

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def quadraticPolynomial (A : Matrix (Fin n) (Fin n) ℝ) : MvPolynomial (Fin n) ℝ :=
  ∑ i,∑ j,C (A i j)*MvPolynomial.X i*MvPolynomial.X j

theorem eval_quadraticPolynomial (A : Matrix (Fin n) (Fin n) ℝ) (x : Fin n → ℝ) :
    MvPolynomial.eval x (quadraticPolynomial A)=matrixQuadratic A x := by
  simp [quadraticPolynomial,matrixQuadratic]

theorem coefficientL1_quadratic_monomial (c : ℝ) (i j : Fin n) :
    coefficientL1 (C c*MvPolynomial.X i*MvPolynomial.X j)=|c| := by
  rw [C_mul_X_eq_monomial]
  change coefficientL1 (monomial (Finsupp.single i 1) c *
    monomial (Finsupp.single j 1) 1)=_
  rw [monomial_mul_monomial,mul_one,coefficientL1_monomial]

theorem coefficientL1_quadratic_le (A : Matrix (Fin n) (Fin n) ℝ) :
    coefficientL1 (quadraticPolynomial A) ≤ ∑ i,∑ j,|A i j| := by
  unfold quadraticPolynomial
  calc
    _ ≤ ∑ i,coefficientL1 (∑ j,C (A i j)*MvPolynomial.X i*MvPolynomial.X j) := coefficientL1_sum_le _ _
    _ ≤ ∑ i,∑ j,coefficientL1 (C (A i j)*MvPolynomial.X i*MvPolynomial.X j) := by
      apply Finset.sum_le_sum
      intro i hi
      exact coefficientL1_sum_le _ _
    _ = _ := by simp only [coefficientL1_quadratic_monomial]

theorem psd_entry_abs_sum_le_trace (A : Matrix (Fin n) (Fin n) ℝ) (hA : A.PosSemidef) :
    (∑ i,∑ j,|A i j|) ≤ (n : ℝ)*Matrix.trace A := by
  have h1 : (∑ i,∑ j,|A i j|) ≤ (∑ i,Real.sqrt (A i i))^2 := by
    rw [pow_two,Finset.sum_mul_sum]
    apply Finset.sum_le_sum
    intro i hi
    apply Finset.sum_le_sum
    intro j hj
    exact psd_entry_abs_le_sqrt A hA i j
  have h2 := Finset.sum_mul_sq_le_sq_mul_sq (Finset.univ : Finset (Fin n))
    (fun _ => (1 : ℝ)) (fun i => Real.sqrt (A i i))
  simp only [one_mul,one_pow,Finset.sum_const,Finset.card_univ,Fintype.card_fin,
    nsmul_eq_mul,mul_one,Real.sq_sqrt (hA.diag_nonneg)] at h2
  exact h1.trans h2

theorem psd_quadratic_coefficientL1_le_trace (A : Matrix (Fin n) (Fin n) ℝ)
    (hA : A.PosSemidef) : coefficientL1 (quadraticPolynomial A) ≤ (n : ℝ)*Matrix.trace A :=
  (coefficientL1_quadratic_le A).trans (psd_entry_abs_sum_le_trace A hA)

theorem paper_difference_polynomial_expansion
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) (hN : 2≤N)
    (hp : p.IsHomogeneous N) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    p-scalarPower t N = -((scalarLinear t N)^(N-2)*quadraticPolynomial (deficitMatrix p t N)) +
      ∑ j ∈ Finset.range (N-2),(scalarLinear t N)^(N-(j+3))*centralCoefficientPolynomial p t N (j+3) := by
  apply MvPolynomial.funext
  intro x
  have he := paper_central_expansion p t N x hN hp hnorm hstable hgrad
  have hlin : MvPolynomial.eval x (scalarLinear t N)=(∑ i,t i*x i)/N := by
    simp only [scalarLinear,map_sum,map_mul,MvPolynomial.eval_C,MvPolynomial.eval_X]
    rw [Finset.sum_div]
    apply Finset.sum_congr rfl
    intro i hi
    ring
  simp only [map_sub,map_add,map_neg,map_mul,map_pow,map_sum,scalarPower,
    hlin,eval_quadraticPolynomial]
  linarith

theorem paper_coefficient_distance_upper_reduction
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ) (hN : 2≤N)
    (hp : p.IsHomogeneous N) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hstable : UpperHalfPlaneZeroFree p) (ht : ∑ i,t i=N) (ht0 : ∀ i,0≤t i)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) :
    coefficientL1 (p-scalarPower t N) ≤ (n : ℝ)*referenceDeficit p t N +
      ∑ j ∈ Finset.range (N-2),coefficientL1 (centralCoefficientPolynomial p t N (j+3)) := by
  rw [paper_difference_polynomial_expansion p t N hN hp hnorm hstable hgrad]
  have hquad : coefficientL1 (-((scalarLinear t N)^(N-2)*quadraticPolynomial (deficitMatrix p t N))) ≤
      (n : ℝ)*referenceDeficit p t N := by
    rw [coefficientL1_neg]
    have h := coefficientL1_mul_le ((scalarLinear t N)^(N-2)) (quadraticPolynomial (deficitMatrix p t N))
    rw [scalarLinear_power_coefficientL1 t N (N-2) (by omega) ht ht0,one_mul] at h
    have hq := psd_quadratic_coefficientL1_le_trace (deficitMatrix p t N)
      (deficitMatrix_posSemidef p t N hN hp hnorm hstable hgrad)
    rw [trace_deficitMatrix] at hq
    exact h.trans hq
  have htail : coefficientL1 (∑ j ∈ Finset.range (N-2),(scalarLinear t N)^(N-(j+3))*
      centralCoefficientPolynomial p t N (j+3)) ≤
      ∑ j ∈ Finset.range (N-2),coefficientL1 (centralCoefficientPolynomial p t N (j+3)) := by
    apply (coefficientL1_sum_le _ _).trans
    apply Finset.sum_le_sum
    intro j hj
    have h := coefficientL1_mul_le ((scalarLinear t N)^(N-(j+3))) (centralCoefficientPolynomial p t N (j+3))
    simpa only [scalarLinear_power_coefficientL1 t N (N-(j+3)) (by omega) ht ht0,one_mul] using h
  exact (coefficientL1_add_le _ _).trans (add_le_add hquad htail)

end CoefficientStability
