import CoefficientStability.BoundaryDirection
import Mathlib.Topology.MetricSpace.Pseudo.Defs

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
variable {n : ℕ}

theorem finite_affine_positive_near_zero {ι : Type*} [Fintype ι]
    (a b : ι → ℝ) (ha : ∀ i,0<a i) :
    ∃ e : ℝ,0<e ∧ ∀ s : ℝ,|s|<e → ∀ i,0<a i+s*b i := by
  have h (i : ι) : ∀ᶠ s in 𝓝 (0 : ℝ),0<a i+s*b i := by
    have hc : ContinuousAt (fun s : ℝ => a i+s*b i) 0 := by fun_prop
    exact hc.eventually (eventually_gt_nhds (by simpa using ha i))
  have hall : ∀ᶠ s in 𝓝 (0 : ℝ),∀ i,0<a i+s*b i := Filter.eventually_all.mpr h
  obtain ⟨e,he,hnear⟩ := Metric.eventually_nhds_iff.mp hall
  refine ⟨e,he,?_⟩
  intro s hs
  exact hnear (by simpa [Real.dist_eq] using hs)

def scalarReferenceTuple (t : Fin n → ℝ) (i : Fin n) : Matrix (Fin n) (Fin n) ℝ :=
  (t i/(n : ℝ)) • (1 : Matrix (Fin n) (Fin n) ℝ)

def boundaryPerturbedTuple (t : Fin n → ℝ) (s : ℝ) (i : Fin n) : Matrix (Fin n) (Fin n) ℝ :=
  scalarReferenceTuple t i+s • boundaryCommutingDirection t i

theorem scalarReferenceTuple_sum (t : Fin n → ℝ) (hn : 0<n) (ht : ∑ i,t i=n) :
    (∑ i,scalarReferenceTuple t i)=1 := by
  have hn' : (n : ℝ)≠0 := by exact_mod_cast Nat.ne_zero_of_lt hn
  simp only [scalarReferenceTuple,← Finset.sum_smul,← Finset.sum_div,ht,div_self hn',one_smul]

theorem scalarReferenceTuple_trace (t : Fin n → ℝ) (hn : 0<n) (i : Fin n) :
    Matrix.trace (scalarReferenceTuple t i)=t i := by
  have hn' : (n : ℝ)≠0 := by exact_mod_cast Nat.ne_zero_of_lt hn
  simp [scalarReferenceTuple]
  field_simp

theorem boundaryPerturbedTuple_diagonal (t : Fin n → ℝ) (s : ℝ) (i : Fin n) :
    boundaryPerturbedTuple t s i=Matrix.diagonal (fun j => t i/(n : ℝ)+
      s*(t i*projectedOnes t i)*boundaryModelDiagonal n j) := by
  ext j l
  by_cases h : j=l <;> simp [boundaryPerturbedTuple,scalarReferenceTuple,boundaryCommutingDirection,
    boundaryModelMatrix,Matrix.diagonal_apply,Matrix.one_apply,h,mul_assoc]

theorem boundaryPerturbedTuple_sum (t : Fin n → ℝ) (hn : 0<n) (ht : ∑ i,t i=n) (s : ℝ) :
    (∑ i,boundaryPerturbedTuple t s i)=1 := by
  simp only [boundaryPerturbedTuple,Finset.sum_add_distrib,← Finset.smul_sum,
    scalarReferenceTuple_sum t hn ht,boundaryCommutingDirection_sum t hn ht,smul_zero,add_zero]

theorem boundaryPerturbedTuple_trace (t : Fin n → ℝ) (hn : 0<n) (s : ℝ) (i : Fin n) :
    Matrix.trace (boundaryPerturbedTuple t s i)=t i := by
  simp [boundaryPerturbedTuple,scalarReferenceTuple_trace t hn,boundaryCommutingDirection_traceless t hn]

theorem boundaryPerturbedTuple_isHermitian (t : Fin n → ℝ) (s : ℝ) (i : Fin n) :
    (boundaryPerturbedTuple t s i).IsHermitian := by
  rw [boundaryPerturbedTuple_diagonal]
  exact Matrix.isHermitian_diagonal _

theorem paper_boundary_feasible_line (t : Fin n → ℝ) (hn : 2≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) :
    ∃ e : ℝ,0<e ∧ ∀ s : ℝ,|s|<e →
      (∀ i,(boundaryPerturbedTuple t s i).PosDef) ∧
      (∑ i,boundaryPerturbedTuple t s i)=1 ∧
      (∀ i,Matrix.trace (boundaryPerturbedTuple t s i)=t i) := by
  have hn' : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
  obtain ⟨e,he,hnear⟩ := finite_affine_positive_near_zero
    (fun q : Fin n × Fin n => t q.1/(n : ℝ))
    (fun q => (t q.1*projectedOnes t q.1)*boundaryModelDiagonal n q.2)
    (fun q => div_pos (htpos q.1) hn')
  refine ⟨e,he,?_⟩
  intro s hs
  refine ⟨?_,boundaryPerturbedTuple_sum t (by omega) ht s,?_⟩
  · intro i
    rw [boundaryPerturbedTuple_diagonal,Matrix.posDef_diagonal_iff]
    intro j
    simpa only [mul_assoc] using hnear s hs (i,j)
  · intro i
    exact boundaryPerturbedTuple_trace t (by omega) s i

end CoefficientStability
