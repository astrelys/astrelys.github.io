import CoefficientStability.StableGlobalGrowth

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {m N : ℕ}

def rectangularLinearPolynomial (B : Matrix (Fin m) (Fin N) ℝ) (i : Fin m) : MvPolynomial (Fin N) ℝ :=
  ∑ j,MvPolynomial.C (B i j)*MvPolynomial.X j

def rectangularSubstitution (B : Matrix (Fin m) (Fin N) ℝ) :
    MvPolynomial (Fin m) ℝ →+* MvPolynomial (Fin N) ℝ :=
  MvPolynomial.eval₂Hom MvPolynomial.C (rectangularLinearPolynomial B)

@[simp] theorem rectangularSubstitution_C (B : Matrix (Fin m) (Fin N) ℝ) (c : ℝ) :
    rectangularSubstitution B (MvPolynomial.C c)=MvPolynomial.C c := by simp [rectangularSubstitution]

@[simp] theorem rectangularSubstitution_X (B : Matrix (Fin m) (Fin N) ℝ) (i : Fin m) :
    rectangularSubstitution B (MvPolynomial.X i)=rectangularLinearPolynomial B i := by simp [rectangularSubstitution]

theorem rectangularSubstitution_eval (B : Matrix (Fin m) (Fin N) ℝ)
    (p : MvPolynomial (Fin m) ℝ) (x : Fin N → ℝ) :
    MvPolynomial.eval x (rectangularSubstitution B p)=MvPolynomial.eval (B.mulVec x) p := by
  change (MvPolynomial.eval x) (MvPolynomial.eval₂ MvPolynomial.C _ p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c
    simp
  · funext i
    simp [rectangularLinearPolynomial,Matrix.mulVec,dotProduct]

theorem rectangularSubstitution_complex_eval (B : Matrix (Fin m) (Fin N) ℝ)
    (p : MvPolynomial (Fin m) ℝ) (z : Fin N → ℂ) :
    MvPolynomial.eval₂ Complex.ofRealHom z (rectangularSubstitution B p)=
      MvPolynomial.eval₂ Complex.ofRealHom (fun i => ∑ j,(B i j : ℂ)*z j) p := by
  change (MvPolynomial.eval₂Hom Complex.ofRealHom z) (MvPolynomial.eval₂ MvPolynomial.C (rectangularLinearPolynomial B) p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c
    simp
  · funext i
    simp [rectangularLinearPolynomial]

theorem rectangularLinearPolynomial_homogeneous (B : Matrix (Fin m) (Fin N) ℝ) (i : Fin m) :
    (rectangularLinearPolynomial B i).IsHomogeneous 1 := by
  apply MvPolynomial.IsHomogeneous.sum
  intro j hj
  exact (MvPolynomial.isHomogeneous_X ℝ j).C_mul _

theorem rectangularSubstitution_homogeneous (B : Matrix (Fin m) (Fin N) ℝ)
    (p : MvPolynomial (Fin m) ℝ) (d : ℕ) (hp : p.IsHomogeneous d) :
    (rectangularSubstitution B p).IsHomogeneous d := by
  have h := hp.eval₂ MvPolynomial.C (rectangularLinearPolynomial B)
    (fun c => MvPolynomial.isHomogeneous_C (Fin N) c) (fun i => rectangularLinearPolynomial_homogeneous B i)
  change (MvPolynomial.eval₂ MvPolynomial.C (rectangularLinearPolynomial B) p).IsHomogeneous d
  simpa only [one_mul] using h

theorem rectangularSubstitution_normalized (B : Matrix (Fin m) (Fin N) ℝ)
    (p : MvPolynomial (Fin m) ℝ) (hrow : ∀ i,∑ j,B i j=1)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) :
    MvPolynomial.eval (fun _ => 1) (rectangularSubstitution B p)=1 := by
  rw [rectangularSubstitution_eval]
  have he : B.mulVec (fun _ => 1)=(fun _ => 1) := by
    funext i
    simpa only [Matrix.mulVec,dotProduct,mul_one] using hrow i
  rw [he,hnorm]

theorem rectangularSubstitution_stable (B : Matrix (Fin m) (Fin N) ℝ)
    (p : MvPolynomial (Fin m) ℝ) (hs : UpperHalfPlaneZeroFree p)
    (hB : ∀ i j,0 ≤ B i j) (hrow : ∀ i,∑ j,B i j=1) :
    UpperHalfPlaneZeroFree (rectangularSubstitution B p) := by
  intro z hz
  rw [rectangularSubstitution_complex_eval]
  apply hs
  intro i
  have he : (∑ j,(B i j : ℂ)*z j).im=∑ j,B i j*(z j).im := by
    simp [Complex.mul_im]
  rw [he]
  have hex : ∃ j,0 < B i j := by
    by_contra! hh
    have hall : ∀ j,B i j=0 := fun j => le_antisymm (hh j) (hB i j)
    have h := hrow i
    simp [hall] at h
  apply Finset.sum_pos'
  · intro j hj
    exact mul_nonneg (hB i j) (hz j).le
  · obtain ⟨j,hj⟩ := hex
    exact ⟨j,Finset.mem_univ j,mul_pos hj (hz j)⟩

theorem rectangularSubstitution_coeff_nonnegative (B : Matrix (Fin m) (Fin N) ℝ)
    (p : MvPolynomial (Fin m) ℝ) (d : ℕ) (hp : p.IsHomogeneous d)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hB : ∀ i j,0 ≤ B i j) (hrow : ∀ i,∑ j,B i j=1) :
    ∀ g,0 ≤ (rectangularSubstitution B p).coeff g :=
  normalized_homogeneous_stable_coeff_nonneg _ d
    (rectangularSubstitution_homogeneous B p d hp) (rectangularSubstitution_stable B p hs hB hrow)
    (rectangularSubstitution_normalized B p hrow hnorm)

end CoefficientStability
