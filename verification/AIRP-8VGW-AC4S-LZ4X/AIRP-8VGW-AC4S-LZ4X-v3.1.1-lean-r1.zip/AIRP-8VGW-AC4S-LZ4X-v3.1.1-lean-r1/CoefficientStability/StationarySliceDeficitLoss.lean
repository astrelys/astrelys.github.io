import CoefficientStability.CenteredCoordinateFactors

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem actual_centered_slice_deficit_loss (hn : 2≤n)
    (p : MvPolynomial (Fin n) ℝ) (hp : p.IsHomogeneous n)
    (hs : UpperHalfPlaneZeroFree p) (hc : ∀ g,0≤p.coeff g)
    (x : Fin n → ℝ) (hx : ∀ j,0<x j) (i j : Fin n) (hji : j≠i)
    (hpi : 0<p.coeff (Finsupp.single i n)) (hpj : 0<p.coeff (Finsupp.single j n))
    (hmin : ∀ z : ℝ,0<z → (realCoordinateRestriction x i p).eval (x i)/x i≤
      (realCoordinateRestriction x i p).eval z/z)
    (hcap : 1≤positiveDomainCapacity (realCoordinateRestriction x i p))
    (τ : ℝ) (hderiv : (realCoordinateRestriction x i p).derivative.eval 0≤capacityG n*(1+τ)) :
    tiltedMoment p (centeredLogVector x) i=1 ∧
      deficitMatrix (tiltedPolynomial p (centeredLogVector x))
        (tiltedMoment p (centeredLogVector x)) n i i≤64*τ := by
  let P := realCoordinateRestriction x i p
  have hpos := positive_stable_realCoordinateRestriction p hs hc x hx i
  have hzero : 0<P.eval 0 := by
    rw [realCoordinateRestriction_eval]
    exact paper_capacity_section_constant_pos p x n i j hji hc hx hpj
  have htop := homogeneous_realCoordinateRestriction_top_coeff p n hp x i
  have hdegree : P.natDegree=n := Polynomial.natDegree_eq_of_le_of_coeff_ne_zero
    (homogeneous_realCoordinateRestriction_degree_le p n hp x i)
    (by rw [htop];exact ne_of_gt hpi)
  obtain ⟨k,hk,b,hb,hfactor⟩ := positive_split_positive_factor_form P hpos.2.1 hpos.2.2 hzero
  have hkn : k=n := hk.trans hdegree
  clear hk
  subst k
  have hZ : tiltPartition p (centeredLogVector x)≠0 := by
    rw [tiltPartition_eval_exp_all]
    exact ne_of_gt (nonnegative_coeff_eval_pos p (stable_polynomial_ne_zero p hs) hc
      (fun k => Real.exp (centeredLogVector x k)) (fun k => Real.exp_pos _))
  have hlogmin := centered_slice_coordinate_log_minimum (by omega) p hp
    (stable_polynomial_ne_zero p hs) hc x hx i hmin
  have hstat := coordinate_log_minimum_moment_one p (centeredLogVector x) i hZ hlogmin
  have hQ := centered_stationary_deficit_factor_identity (by omega) p hp x hx i hzero b hb hfactor hstat
  have hloss := positive_prefactor_univariate_loss_general P b (x i) hn hzero hb (hx i) hfactor hmin
  have hD : 0≤(∑ k,(b k*x i/(1+b k*x i))^2)-1/(n : ℝ) := by
    rw [← simplex_centered_variance _ (by omega) hloss.1]
    exact Finset.sum_nonneg (fun k hk => sq_nonneg _)
  have hCapPos : 0<positiveDomainCapacity P := lt_of_lt_of_le (by norm_num) hcap
  have hL := (le_div_iff₀ hCapPos).mp hloss.2
  have hunit : 0≤1+((∑ k,(b k*x i/(1+b k*x i))^2)-1/(n : ℝ))/128 := by linarith
  have hprod := le_mul_of_one_le_right hunit hcap
  have hg := capacityG_pos hn
  have hmul := mul_le_mul_of_nonneg_left hprod hg.le
  have hcompare : capacityG n*(1+((∑ k,(b k*x i/(1+b k*x i))^2)-1/(n : ℝ))/128)≤capacityG n*(1+τ) := by
    calc
      _≤capacityG n*((1+((∑ k,(b k*x i/(1+b k*x i))^2)-1/(n : ℝ))/128)*positiveDomainCapacity P) := hmul
      _≤P.derivative.eval 0 := by simpa only [mul_assoc] using hL
      _≤_ := hderiv
  have hfrac : ((∑ k,(b k*x i/(1+b k*x i))^2)-1/(n : ℝ))/128≤τ := by nlinarith
  refine ⟨hstat,?_⟩
  rw [hQ]
  linarith only [hfrac]

end CoefficientStability
