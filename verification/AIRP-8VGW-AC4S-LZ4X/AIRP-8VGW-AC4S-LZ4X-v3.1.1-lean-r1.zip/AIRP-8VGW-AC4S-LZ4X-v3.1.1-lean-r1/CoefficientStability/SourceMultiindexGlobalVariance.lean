import CoefficientStability.SourceWeightedCoefficientTopology

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {m : ℕ}

def sourceSquarefreeVarianceCertificate (N : ℕ) (ε κ : ℝ) : Prop :=
  ∀ (t : Fin N → ℝ) (p : MvPolynomial (Fin N) ℝ),p.IsHomogeneous N →
    UpperHalfPlaneZeroFree p → MvPolynomial.eval (fun _ => 1) p=1 →
    (∑ i,t i)=N → (∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) →
    (∑ i,|t i-1|) < ε →
    κ*referenceDeficit p t N ≤ p.coeff (squarefreeExponent N)-sourceVn N*(∏ i,t i)

theorem sourceSquarefreeVarianceCertificate_exists (N : ℕ) (hN : 2 ≤ N) :
    ∃ ε κ : ℝ,0 < ε ∧ 0 < κ ∧ sourceSquarefreeVarianceCertificate N ε κ :=
  source_stable_global_growth_exists hN

theorem source_multiindex_variance_transfer (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (ε κ : ℝ) (hsource : sourceSquarefreeVarianceCertificate (sourceCloneCount α) ε κ)
    (p : MvPolynomial (Fin m) ℝ) (hp : p.IsHomogeneous (sourceCloneCount α))
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (t : Fin m → ℝ) (ht : (∑ i,t i)=sourceCloneCount α)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hnear : (∑ i,|t i-(α i : ℝ)|) < ε) :
    κ/sourceCloneCoefficientWeight α*sourceWeightedDeficit α p t ≤
      p.coeff (sourceMultiExponent α)-sourceMultiIndexBaseline α t := by
  obtain ⟨hph,hps,hpn,hpc,hpg⟩ := sourceClonePolynomial_source_hypotheses α hα p hp hs hnorm t hgrad
  have htotal := (sourceClonedGradient_sum α hα t).trans ht
  have hclone : (∑ j,|sourceClonedGradient α t j-1|) < ε := by
    simpa only [sourceClonedGradient,sourceCloneGradient_l1 α hα t] using hnear
  have hg := hsource (sourceClonedGradient α t) (sourceClonePolynomial α p) hph hps hpn htotal hpg hclone
  rw [sourceClonePolynomial_weighted_variance α hα p t hgrad,sourceClonePolynomial_squarefree_coefficient] at hg
  have href : sourceVn (sourceCloneCount α)*(∏ j,sourceClonedGradient α t j)=
      sourceCloneCoefficientWeight α*sourceMultiIndexBaseline α t := by
    rw [← sourceCloneReference_coefficient_identity,sourceScalarPower_multiindex_baseline]
    rfl
  rw [href,← mul_sub] at hg
  have hK := sourceCloneCoefficientWeight_pos α hα
  calc
    _ = (κ*sourceWeightedDeficit α p t)/sourceCloneCoefficientWeight α := by ring
    _ ≤ _ := (div_le_iff₀ hK).mpr (by simpa only [mul_comm] using hg)

theorem source_multiindex_variance_growth_uniform (N : ℕ) (hN : 2 ≤ N) :
    ∃ ε κ : ℝ,0 < ε ∧ 0 < κ ∧ sourceSquarefreeVarianceCertificate N ε κ ∧
      ∀ (m : ℕ) (α : Fin m → ℕ),(∀ i,0 < α i) → sourceCloneCount α=N →
        ∀ (p : MvPolynomial (Fin m) ℝ),p.IsHomogeneous N → UpperHalfPlaneZeroFree p →
          MvPolynomial.eval (fun _ => 1) p=1 → ∀ t : Fin m → ℝ,(∑ i,t i)=N →
          (∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) →
          (∑ i,|t i-(α i : ℝ)|) < ε →
          κ/sourceCloneCoefficientWeight α*sourceWeightedDeficit α p t ≤
            p.coeff (sourceMultiExponent α)-sourceMultiIndexBaseline α t := by
  obtain ⟨ε,κ,hε,hκ,hsource⟩ := sourceSquarefreeVarianceCertificate_exists N hN
  refine ⟨ε,κ,hε,hκ,hsource,?_⟩
  intro m α hα hcount p hp hs hnorm t ht hgrad hnear
  subst N
  exact source_multiindex_variance_transfer α hα ε κ hsource p hp hs hnorm t ht hgrad hnear

theorem source_multiindex_variance_geometry (α : Fin m → ℕ) (hN : 2 ≤ sourceCloneCount α)
    (p : MvPolynomial (Fin m) ℝ) (hp : p.IsHomogeneous (sourceCloneCount α))
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (t : Fin m → ℝ) (ht : (∑ i,t i)=sourceCloneCount α)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) :
    (deficitMatrix p t (sourceCloneCount α)).PosSemidef ∧
      (deficitMatrix p t (sourceCloneCount α)).mulVec (fun _ => 1)=0 ∧
      (deficitMatrix p t (sourceCloneCount α)=0 ↔ p=scalarPower t (sourceCloneCount α)) := by
  have hQ := deficitMatrix_posSemidef p t (sourceCloneCount α) hN hp hnorm hs hgrad
  have hnull := deficitMatrix_mulVec_one p t (sourceCloneCount α) (by omega) hp ht hgrad
  have hz := referenceDeficit_zero_iff_scalarPower p t (sourceCloneCount α) hN hp hnorm hs ht hgrad
  refine ⟨hQ,hnull,?_⟩
  constructor
  · intro he
    apply hz.mp
    rw [← trace_deficitMatrix,he]
    simp
  · intro he
    apply hQ.trace_eq_zero_iff.mp
    rw [trace_deficitMatrix]
    exact hz.mpr he

theorem source_multiindex_singleton (α : Fin 1 → ℕ) (hN : 2 ≤ sourceCloneCount α)
    (p : MvPolynomial (Fin 1) ℝ) (hp : p.IsHomogeneous (sourceCloneCount α))
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (t : Fin 1 → ℝ) (ht : (∑ i,t i)=sourceCloneCount α)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) :
    p=scalarPower t (sourceCloneCount α) ∧
      (∑ i,(t i-(α i : ℝ))^2/(α i : ℝ))=0 ∧
      (∑ i,(t i-(α i : ℝ))^2/(α i : ℝ)) < (sourceCloneCount α : ℝ)/((sourceCloneCount α : ℝ)-1) := by
  have hnull := deficitMatrix_mulVec_one p t (sourceCloneCount α) (by omega) hp ht hgrad
  have he := congrArg (fun v : Fin 1 → ℝ => v 0) hnull
  have he0 : deficitMatrix p t (sourceCloneCount α) 0 0=0 := by
    simpa only [Matrix.mulVec,dotProduct,mul_one,Fin.sum_univ_one,Pi.zero_apply] using he
  have hδ : referenceDeficit p t (sourceCloneCount α)=0 := by
    rw [← trace_deficitMatrix]
    simpa only [Matrix.trace,Matrix.diag,Fin.sum_univ_one] using he0
  have hpref := (referenceDeficit_zero_iff_scalarPower p t (sourceCloneCount α) hN hp hnorm hs ht hgrad).mp hδ
  have ht0 : t 0=(α 0 : ℝ) := by simpa [sourceCloneCount] using ht
  have hzero : (∑ i,(t i-(α i : ℝ))^2/(α i : ℝ))=0 := by simp only [Fin.sum_univ_one,ht0,sub_self,zero_pow (by norm_num : (2 : ℕ)≠0),zero_div]
  refine ⟨hpref,hzero,?_⟩
  rw [hzero]
  have hn2 : (2 : ℝ) ≤ sourceCloneCount α := by exact_mod_cast hN
  exact div_pos (by linarith) (by linarith)

end CoefficientStability
