import CoefficientStability.SquarefreeMatrixContribution

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem rankOneRemixingMatrix_diagonal_product (j : Fin n) (r : ℝ) (hr : 1-r≠0) :
    (∏ i,rankOneRemixingMatrix n j r i i)=1/(1-r) := by
  classical
  have hprod : (∏ i,rankOneRemixingMatrix n j r i i)=1+r/(1-r) := by
    rw [Finset.prod_eq_single j]
    · simp [rankOneRemixingMatrix]
    · intro i hi hij
      simp [rankOneRemixingMatrix,hij]
    · simp
  rw [hprod]
  field_simp
  <;> ring

theorem rankOne_source_squarefree_coefficient_comparison (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (j : Fin n) (r : ℝ)
    (hr0 : 0≤r) (hr1 : r<1)
    (hboundary : (fun i => (if i=j then 1 else 0)-r)∈closure (positiveSpectralCone p n)) :
    (matrixSubstitution (rankOneUnmixingMatrix n j r) p).coeff (squarefreeExponent n)/(1-r)≤
      p.coeff (squarefreeExponent n) := by
  have hr : 1-r≠0 := ne_of_gt (by linarith)
  have h := homogeneous_matrixSubstitution_squarefree_contribution
    (matrixSubstitution (rankOneUnmixingMatrix n j r) p) (matrixSubstitution_homogeneous _ p n hp)
    (rankOne_source_substitution_coeff_nonneg p hn hn hp hs hnorm j r hr1 hboundary)
    (rankOneRemixingMatrix n j r) (rankOneRemixingMatrix_nonnegative j r hr0 hr1)
  rw [rankOne_inverse_polynomial_recovery p j r hr,rankOneRemixingMatrix_diagonal_product j r hr] at h
  simpa only [div_eq_mul_inv,one_div,one_mul] using h

end CoefficientStability
