import CoefficientStability.SourceSuffixSpectrum

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem actual_source_cumulative_spectral_prefix_bound (p : MvPolynomial (Fin n) ℝ) (hn : 0<n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (c : Fin n → ℝ) (hc : ∀ j,0≤c j)
    (k : ℕ) (hk0 : 0<k) (hk : k ≤ n) (finalRoots : Fin n → ℝ)
    (hf : lineRestriction p (cumulativeInput c)=∏ j : Fin n,(Polynomial.X+Polynomial.C (finalRoots j))) :
    ∀ T∈Finset.univ.powersetCard k,
      (1-(∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)/2)*
        finiteInputPrefix (cumulativeInput c) k≤∑ j∈T,finalRoots j := by
  classical
  let ε : ℝ := (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)/2
  have hε : 0≤ε := by dsimp [ε];positivity
  have hex := fun j : Fin n => actual_source_suffix_spectrum p hn hp hs hnorm k hk j
  choose roots hfactor hbound using hex
  have hfinal : lineRestriction p (∑ j,c j • suffixIndicator j)=
      ∏ j : Fin n,(Polynomial.X+Polynomial.C (finalRoots j)) := by
    rw [← cumulativeInput_indicator_decomposition c]
    exact hf
  have hcombo := actual_source_subset_bound_finite_combination p n k hp hs hnorm hk0 hk
    Finset.univ suffixIndicator c (fun j => suffixSpectralLower k j ε) (fun j hj => hc j) roots
    (fun j hj => hfactor j) (fun j hj => hbound j) finalRoots hfinal
  intro T hT
  calc
    _≤∑ j,c j*suffixSpectralLower k j ε := suffixSpectralLower_weighted_prefix c hc k hk ε hε
    _≤_ := hcombo T hT

end CoefficientStability
