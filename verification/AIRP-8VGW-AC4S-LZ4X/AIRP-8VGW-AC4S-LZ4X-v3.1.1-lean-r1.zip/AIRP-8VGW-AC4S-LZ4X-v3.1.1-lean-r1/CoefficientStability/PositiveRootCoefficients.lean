import CoefficientStability.PositiveDirectionFactors

noncomputable section
open scoped BigOperators
namespace CoefficientStability

theorem positive_root_product_coefficients (roots : Multiset ℝ) (hr : ∀ r∈roots,0<r) :
    (∀ k,0≤((roots.map (fun r => Polynomial.X+Polynomial.C r)).prod).coeff k) ∧
      (∀ k,k≤roots.card → 0<((roots.map (fun r => Polynomial.X+Polynomial.C r)).prod).coeff k) := by
  induction roots using Multiset.induction_on with
  | empty =>
    constructor
    · intro k;simp only [Multiset.map_zero,Multiset.prod_zero];simp only [Polynomial.coeff_one];split_ifs <;> norm_num
    · intro k hk
      have hk0 : k=0 := by simpa using hk
      subst k
      norm_num
  | cons r roots ih =>
    have hr0 : 0<r := hr r (by simp)
    have hroots : ∀ s∈roots,0<s := fun s hs => hr s (by simp [hs])
    obtain ⟨hnonneg,hpos⟩ := ih hroots
    have he : ((r ::ₘ roots).map (fun r => Polynomial.X+Polynomial.C r)).prod=
        Polynomial.X*(roots.map (fun r => Polynomial.X+Polynomial.C r)).prod+
          Polynomial.C r*(roots.map (fun r => Polynomial.X+Polynomial.C r)).prod := by
      simp only [Multiset.map_cons,Multiset.prod_cons,add_mul]
    constructor
    · intro k
      rw [he,Polynomial.coeff_add,Polynomial.coeff_C_mul]
      cases k with
      | zero => simpa only [Polynomial.coeff_X_mul_zero,zero_add] using mul_nonneg hr0.le (hnonneg 0)
      | succ k => rw [Polynomial.coeff_X_mul];exact add_nonneg (hnonneg k) (mul_nonneg hr0.le (hnonneg (k+1)))
    · intro k hk
      rw [he,Polynomial.coeff_add,Polynomial.coeff_C_mul]
      cases k with
      | zero => simpa only [Polynomial.coeff_X_mul_zero,zero_add] using mul_pos hr0 (hpos 0 (Nat.zero_le _))
      | succ k =>
        rw [Polynomial.coeff_X_mul]
        have hkk : k≤roots.card := by simp only [Multiset.card_cons] at hk;omega
        exact add_pos_of_pos_of_nonneg (hpos k hkk) (mul_nonneg hr0.le (hnonneg (k+1)))

end CoefficientStability
