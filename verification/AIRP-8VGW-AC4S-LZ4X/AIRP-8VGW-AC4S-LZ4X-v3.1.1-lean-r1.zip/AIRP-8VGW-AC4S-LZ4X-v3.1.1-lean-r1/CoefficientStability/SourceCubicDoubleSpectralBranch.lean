import CoefficientStability.SourceCubicBlockRecovery
import CoefficientStability.SourceCubicScalarSpectralBranch
import CoefficientStability.SourceCubicCommonMultiplier

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 3500000
set_option backward.isDefEq.respectTransparency false

theorem source_three_noninjective_profile_repeated (x : Fin 3 → ℝ) (hn : ¬ Function.Injective x) :
    x 0=x 1 ∨ x 0=x 2 ∨ x 1=x 2 := by
  by_contra! h
  apply hn
  intro i j hij
  fin_cases i <;> fin_cases j <;> simp_all

theorem source_cubic_double_spectrum_local_minimum_commutes (t : Fin 3 → ℝ)
    (H : Matrix (Fin 3) (Fin 3) ℂ) (hH : H.IsHermitian)
    (hn : ¬ Function.Injective hH.eigenvalues) (hconst : ¬ ∀ i,hH.eigenvalues i=hH.eigenvalues 0)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hA : A ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A)
    (hc : ∀ i,H*A i=A i*H) : ∀ i j,A i*A j=A j*A i := by
  obtain ⟨k,a,b,heig⟩ := source_three_repeated_profile_one_exception hH.eigenvalues
    (source_three_noninjective_profile_repeated _ hn)
  have hb : b ≠ 0 := by
    intro hb
    apply hconst
    intro i
    rw [heig i,heig 0,hb]
    ring
  let U := star hH.eigenvectorUnitary
  let P := sourceThreeSwapUnitary k
  let φ := Unitary.conjStarAlgAut ℂ (Matrix (Fin 3) (Fin 3) ℂ) U
  let ψ := Unitary.conjStarAlgAut ℂ (Matrix (Fin 3) (Fin 3) ℂ) P
  let A' := sourceCubicUnitaryAction U A
  let A'' := sourceCubicUnitaryAction P A'
  have hA' : A' ∈ hermitianFeasibleTuples t := source_cubic_unitary_feasible t U A hA
  have hm' : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A' :=
    source_cubic_unitary_local_minimum t U A hA hm
  have hA'' : A'' ∈ hermitianFeasibleTuples t := source_cubic_unitary_feasible t P A' hA'
  have hm'' : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A'' :=
    source_cubic_unitary_local_minimum t P A' hA' hm'
  have hφ : φ H=Matrix.diagonal (fun i => ((a+b*(if i=k then 1 else 0) : ℝ) : ℂ)) := by
    change Unitary.conjStarAlgAut ℂ (Matrix (Fin 3) (Fin 3) ℂ) (star hH.eigenvectorUnitary) H=_
    rw [hH.conjStarAlgAut_star_eigenvectorUnitary]
    congr 1
    funext i
    change (hH.eigenvalues i : ℂ)=_
    rw [heig i]
  have hψ : ψ (φ H)=Matrix.diagonal (fun i : Fin 3 => ((a+b*(if i=0 then 1 else 0) : ℝ) : ℂ)) := by
    rw [hφ]
    exact source_three_swap_diagonal k a b
  have hcc : ∀ j,Matrix.diagonal (fun i : Fin 3 => ((a+b*(if i=0 then 1 else 0) : ℝ) : ℂ))*A'' j=
      A'' j*Matrix.diagonal (fun i : Fin 3 => ((a+b*(if i=0 then 1 else 0) : ℝ) : ℂ)) := by
    intro j
    have h := congrArg ψ (congrArg φ (hc j))
    have hh := h
    simp only [map_mul,hψ] at hh
    simpa only [A'',A',source_cubic_unitary_action_apply,φ,ψ] using hh
  have hcomm := source_cubic_double_diagonal_local_minimum_commutes t a b hb A'' hA'' hm'' hcc
  intro i j
  apply (EquivLike.injective φ)
  apply (EquivLike.injective ψ)
  simpa only [A'',A',source_cubic_unitary_action_apply,φ,ψ,map_mul] using hcomm i j

end CoefficientStability
