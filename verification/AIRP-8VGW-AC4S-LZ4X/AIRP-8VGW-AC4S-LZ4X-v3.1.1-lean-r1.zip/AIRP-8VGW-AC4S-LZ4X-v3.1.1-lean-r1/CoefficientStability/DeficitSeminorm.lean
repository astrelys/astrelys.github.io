import CoefficientStability.StableLeadingMatrix
import Mathlib.LinearAlgebra.Matrix.BilinearForm

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def deficitSeminorm (Q : Matrix (Fin n) (Fin n) ℝ) (x : Fin n → ℝ) : ℝ :=
  Real.sqrt (matrixQuadratic Q x)

theorem matrixBilinear_symmetric (Q : Matrix (Fin n) (Fin n) ℝ) (hQ : Q.IsHermitian)
    (x y : Fin n → ℝ) : Q.toBilin' x y=Q.toBilin' y x := by
  simpa only [Matrix.toBilin'_apply',star_trivial] using hQ.star_dotProduct_mulVec_comm x y

theorem matrixBilinear_diagonal (Q : Matrix (Fin n) (Fin n) ℝ) (x : Fin n → ℝ) :
    Q.toBilin' x x=matrixQuadratic Q x := by
  rw [Matrix.toBilin'_apply',matrixQuadratic_dot]

theorem matrixQuadratic_add (Q : Matrix (Fin n) (Fin n) ℝ) (hQ : Q.IsHermitian)
    (x y : Fin n → ℝ) : matrixQuadratic Q (x+y)=
      matrixQuadratic Q x+matrixQuadratic Q y+2*Q.toBilin' x y := by
  rw [← matrixBilinear_diagonal,← matrixBilinear_diagonal,← matrixBilinear_diagonal]
  simp only [map_add,LinearMap.add_apply]
  rw [matrixBilinear_symmetric Q hQ y x]
  ring

theorem matrixQuadratic_smul (Q : Matrix (Fin n) (Fin n) ℝ) (a : ℝ) (x : Fin n → ℝ) :
    matrixQuadratic Q (a • x)=a^2*matrixQuadratic Q x := by
  rw [← matrixBilinear_diagonal,← matrixBilinear_diagonal]
  simp only [map_smul,LinearMap.smul_apply,smul_eq_mul]
  ring

theorem psd_bilinear_square_bound (Q : Matrix (Fin n) (Fin n) ℝ) (hQ : Q.PosSemidef)
    (x y : Fin n → ℝ) : (Q.toBilin' x y)^2≤matrixQuadratic Q x*matrixQuadratic Q y := by
  have hpoly : ∀ s : ℝ,0≤matrixQuadratic Q x*(s*s)+(2*Q.toBilin' x y)*s+matrixQuadratic Q y := by
    intro s
    have h := psd_matrixQuadratic_nonneg Q hQ (s • x+y)
    rw [matrixQuadratic_add Q hQ.isHermitian,matrixQuadratic_smul] at h
    simp only [map_smul,LinearMap.smul_apply,smul_eq_mul] at h
    nlinarith
  have h := discrim_le_zero hpoly
  simp only [discrim] at h
  nlinarith

theorem psd_bilinear_abs_bound (Q : Matrix (Fin n) (Fin n) ℝ) (hQ : Q.PosSemidef)
    (x y : Fin n → ℝ) : |Q.toBilin' x y|≤deficitSeminorm Q x*deficitSeminorm Q y := by
  have h := psd_bilinear_square_bound Q hQ x y
  have hx := Real.sq_sqrt (psd_matrixQuadratic_nonneg Q hQ x)
  have hy := Real.sq_sqrt (psd_matrixQuadratic_nonneg Q hQ y)
  unfold deficitSeminorm
  have he : (Real.sqrt (matrixQuadratic Q x)*Real.sqrt (matrixQuadratic Q y))^2=
      matrixQuadratic Q x*matrixQuadratic Q y := by rw [mul_pow,hx,hy]
  nlinarith [sq_abs (Q.toBilin' x y),Real.sqrt_nonneg (matrixQuadratic Q x),Real.sqrt_nonneg (matrixQuadratic Q y),
    mul_nonneg (Real.sqrt_nonneg (matrixQuadratic Q x)) (Real.sqrt_nonneg (matrixQuadratic Q y))]

theorem deficitSeminorm_triangle (Q : Matrix (Fin n) (Fin n) ℝ) (hQ : Q.PosSemidef)
    (x y : Fin n → ℝ) : deficitSeminorm Q (x+y)≤deficitSeminorm Q x+deficitSeminorm Q y := by
  have h := le_trans (le_abs_self (Q.toBilin' x y)) (psd_bilinear_abs_bound Q hQ x y)
  have hx := Real.sq_sqrt (psd_matrixQuadratic_nonneg Q hQ x)
  have hy := Real.sq_sqrt (psd_matrixQuadratic_nonneg Q hQ y)
  have hz := Real.sq_sqrt (psd_matrixQuadratic_nonneg Q hQ (x+y))
  have he := matrixQuadratic_add Q hQ.isHermitian x y
  unfold deficitSeminorm at *
  nlinarith [Real.sqrt_nonneg (matrixQuadratic Q x),Real.sqrt_nonneg (matrixQuadratic Q y),
    Real.sqrt_nonneg (matrixQuadratic Q (x+y))]

theorem deficitSeminorm_smul (Q : Matrix (Fin n) (Fin n) ℝ) (hQ : Q.PosSemidef)
    (a : ℝ) (x : Fin n → ℝ) : deficitSeminorm Q (a • x)=|a| * deficitSeminorm Q x := by
  unfold deficitSeminorm
  rw [matrixQuadratic_smul,Real.sqrt_mul (sq_nonneg a),Real.sqrt_sq_eq_abs]

end CoefficientStability
