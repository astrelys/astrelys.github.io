import CoefficientStability.SourceRadiusConstants

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem source_euclidean_gradient_peeling (hn : 3 ≤ n) (v : Fin n → ℝ)
    (hv : (∑ i,v i^2) ≤ 1/(10000000000000000*(n : ℝ)^15)) :
    (∑ i,|v i|) ≤ capacityEta n/(64*(n : ℝ)) ∧ (∑ i,|v i|) ≤ 1/2 := by
  let s := ∑ i,|v i|
  have hs0 : 0 ≤ s := Finset.sum_nonneg (fun i hi => abs_nonneg _)
  have hn1 : (1 : ℝ) ≤ n := by exact_mod_cast (show 1 ≤ n by omega)
  have hn0 : (0 : ℝ)<n := by linarith
  have hs := (finite_l1_l2_square v).trans (mul_le_mul_of_nonneg_left hv hn0.le)
  have hpow : (n : ℝ)^7 ≤ (n : ℝ)^15 := pow_le_pow_right₀ hn1 (by norm_num : 7 ≤ 15)
  have hcmp : (n : ℝ)/(10000000000000000*(n : ℝ)^15) ≤ 1/(16384*(n : ℝ)^6) := by
    apply (div_le_div_iff₀ (by positivity) (by positivity)).mpr
    nlinarith [pow_pos hn0 15]
  have hs2 : s^2 ≤ 1/(16384*(n : ℝ)^6) := hs.trans (by simpa only [mul_one_div] using hcmp)
  have he : (1/(128*(n : ℝ)^3))^2=1/(16384*(n : ℝ)^6) := by field_simp;ring
  have hsb : s ≤ 1/(128*(n : ℝ)^3) := by
    rw [← he] at hs2
    exact (sq_le_sq₀ hs0 (by positivity)).mp hs2
  have hp := div_le_div_of_nonneg_right (capacityEta_lower n hn) (by positivity : 0 ≤ 64*(n : ℝ))
  have he2 : (1/(2*(n : ℝ)^2))/(64*(n : ℝ))=1/(128*(n : ℝ)^3) := by field_simp;ring
  rw [he2] at hp
  refine ⟨hsb.trans hp,hsb.trans ?_⟩
  apply (div_le_iff₀ (by positivity : 0 < 128*(n : ℝ)^3)).mpr
  have hn3 : (1 : ℝ) ≤ (n : ℝ)^3 := one_le_pow₀ hn1
  nlinarith

theorem source_l1_radius_implies_euclidean (hn : 3 ≤ n) (v : Fin n → ℝ)
    (hv : (∑ i,|v i|) ≤ 1/(1000000000*(n : ℝ)^8)) :
    (∑ i,v i^2) ≤ 1/(10000000000000000*(n : ℝ)^15) := by
  have hn1 : (1 : ℝ) ≤ n := by exact_mod_cast (show 1 ≤ n by omega)
  have hn0 : (0 : ℝ)<n := by linarith
  have hs : (∑ i,v i^2) ≤ (∑ i,|v i|)^2 := by
    simpa only [sq_abs] using Finset.sum_sq_le_sq_sum_of_nonneg
      (s := Finset.univ) (f := fun i => |v i|) (fun i hi => abs_nonneg _)
  have hsq := pow_le_pow_left₀ (Finset.sum_nonneg (fun i hi => abs_nonneg (v i))) hv 2
  have he : (1/(1000000000*(n : ℝ)^8))^2=1/(1000000000000000000*(n : ℝ)^16) := by field_simp;ring
  rw [he] at hsq
  apply hs.trans (hsq.trans ?_)
  apply (div_le_div_iff₀ (by positivity) (by positivity)).mpr
  have hpow : (n : ℝ)^15 ≤ (n : ℝ)^16 := pow_le_pow_right₀ hn1 (by norm_num : 15 ≤ 16)
  nlinarith [pow_pos hn0 16]

end CoefficientStability
