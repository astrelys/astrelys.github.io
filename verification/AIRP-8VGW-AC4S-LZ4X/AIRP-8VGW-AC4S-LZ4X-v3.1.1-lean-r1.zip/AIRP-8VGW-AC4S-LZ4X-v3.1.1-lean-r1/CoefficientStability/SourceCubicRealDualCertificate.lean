import CoefficientStability.SourceCubicSeparatorNormalization
import CoefficientStability.SourceCubicConeLowerBound

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 2300000
set_option backward.isDefEq.respectTransparency false

def sourceCubicDualSlack (g : Module.Dual ℝ SourceCubicHermitianTuples)
    (ℓ : Module.Dual ℝ SourceCubicConstraintSpace) : Module.Dual ℝ SourceCubicHermitianTuples :=
  g+ℓ.comp sourceCubicConstraintMap

theorem source_cubic_original_real_dual_certificate (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (htpos : ∀ i,0 < t i) (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t)
    (hm : IsLocalMinOn hermitianMixedObjective (hermitianFeasibleTuples t) A) :
    ∃ ℓ : Module.Dual ℝ SourceCubicConstraintSpace,
      (∀ Y ∈ sourceCubicPSDCone,0 ≤ sourceCubicDualSlack (sourceCubicGradientDual t A) ℓ Y) ∧
      sourceCubicDualSlack (sourceCubicGradientDual t A) ℓ
        (sourceCubicHermitianBundle A (fun i => (hA.1 i).1))=0 := by
  obtain ⟨ℓ,hℓ⟩ := source_cubic_original_normalized_separator t ht htpos A hA hm
  let S := sourceCubicDualSlack (sourceCubicGradientDual t A) ℓ
  let X := sourceCubicHermitianBundle A (fun i => (hA.1 i).1)
  let C := sourceCubicGradientDual t A X+ℓ (sourceCubicConstraintTarget t)
  have hint : ∀ Y ∈ interior sourceCubicPSDCone,C ≤ S Y := by
    intro Y hY
    by_contra hn
    have hp : 0 < (C-S Y)/2 := by linarith
    have h := hℓ Y hY ((C-S Y)/2) hp
    change C < S Y+(C-S Y)/2 at h
    linarith
  obtain ⟨hC,hS⟩ := source_cubic_cone_linear_lower_bound S C hint
  have hX : X ∈ sourceCubicPSDCone := fun i => (hA.1 i).2.1
  have he : S X=C := by
    change sourceCubicGradientDual t A X+ℓ (sourceCubicConstraintMap X)=_
    rw [source_cubic_feasible_bundle_constraints t A hA]
  refine ⟨ℓ,hS,?_⟩
  exact le_antisymm (he.le.trans hC) (hS X hX)

end CoefficientStability
