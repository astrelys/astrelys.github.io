import CoefficientStability.SignOrthogonality
import Mathlib.Data.Fintype.Perm

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {k : ℕ} {E : Type*} [AddCommGroup E] [Module ℝ E]

theorem sum_bijective_functions (f : (Fin k → Fin k) → ℝ) :
    (∑ u : Fin k → Fin k,if Function.Bijective u then f u else 0) =
      ∑ s : Equiv.Perm (Fin k),f s := by
  classical
  rw [← Finset.sum_filter]
  rw [Finset.sum_subtype (p := fun u : Fin k → Fin k => Function.Bijective u) _
    (by intro u; simp only [Finset.mem_filter,Finset.mem_univ,true_and])]
  exact Fintype.sum_equiv Equiv.bijectiveEquiv _ _ (fun u => rfl)

theorem multilinear_signed_polarization
    (T : MultilinearMap ℝ (fun _ : Fin k => E) ℝ) (v : Fin k → E) :
    (∑ eps : Fin k → Bool,(∏ j,realSign (eps j))*
      T (fun _ => ∑ j,realSign (eps j) • v j)) =
      (2 : ℝ)^k*∑ s : Equiv.Perm (Fin k),T (fun r => v (s r)) := by
  classical
  have he (eps : Fin k → Bool) : T (fun _ => ∑ j,realSign (eps j) • v j) =
      ∑ u : Fin k → Fin k,(∏ r,realSign (eps (u r)))*T (fun r => v (u r)) := by
    rw [T.map_sum]
    apply Finset.sum_congr rfl
    intro u hu
    exact T.map_smul_univ _ _
  calc
    _ = ∑ eps : Fin k → Bool,∑ u : Fin k → Fin k,
        ((∏ j,realSign (eps j))*(∏ r,realSign (eps (u r))))*T (fun r => v (u r)) := by
      simp_rw [he,Finset.mul_sum,mul_assoc]
    _ = ∑ u : Fin k → Fin k,signMoment u*T (fun r => v (u r)) := by
      rw [Finset.sum_comm]
      simp only [signMoment,Finset.sum_mul]
    _ = (2 : ℝ)^k*∑ u : Fin k → Fin k,
        if Function.Bijective u then T (fun r => v (u r)) else 0 := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro u hu
      rw [signMoment_eq]
      split_ifs <;> simp
    _ = _ := by rw [sum_bijective_functions]

def symmetrizedMultilinear (T : MultilinearMap ℝ (fun _ : Fin k => E) ℝ) :
    MultilinearMap ℝ (fun _ : Fin k => E) ℝ :=
  ((k.factorial : ℝ)⁻¹) • ∑ s : Equiv.Perm (Fin k),T.domDomCongr s

theorem symmetrizedMultilinear_diagonal
    (T : MultilinearMap ℝ (fun _ : Fin k => E) ℝ) (x : E) :
    symmetrizedMultilinear T (fun _ => x)=T (fun _ => x) := by
  have hf : (k.factorial : ℝ)≠0 := by exact_mod_cast Nat.factorial_ne_zero k
  simp [symmetrizedMultilinear,MultilinearMap.domDomCongr_apply,Fintype.card_perm,hf]

theorem symmetrizedMultilinear_polarization
    (T : MultilinearMap ℝ (fun _ : Fin k => E) ℝ) (v : Fin k → E) :
    symmetrizedMultilinear T v =
      (∑ eps : Fin k → Bool,(∏ j,realSign (eps j))*
        T (fun _ => ∑ j,realSign (eps j) • v j))/((2 : ℝ)^k*(k.factorial : ℝ)) := by
  rw [multilinear_signed_polarization]
  have hf : (k.factorial : ℝ)≠0 := by exact_mod_cast Nat.factorial_ne_zero k
  have h2 : (2 : ℝ)^k≠0 := pow_ne_zero _ (by norm_num)
  simp only [symmetrizedMultilinear,MultilinearMap.smul_apply,MultilinearMap.sum_apply,
    smul_eq_mul,MultilinearMap.domDomCongr_apply]
  field_simp

end CoefficientStability
