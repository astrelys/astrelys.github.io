import CoefficientStability.UniversalSourceLine

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def degreeScaledPolynomial (p : MvPolynomial (Fin n) ℝ) (c : ℝ) : MvPolynomial (Fin n) ℝ :=
  ∑ g∈p.support,MvPolynomial.monomial g (c^(∑ i,g i)*p.coeff g)

theorem degreeScaledPolynomial_coeff (p : MvPolynomial (Fin n) ℝ) (c : ℝ) (g : Fin n →₀ ℕ) :
    (degreeScaledPolynomial p c).coeff g=c^(∑ i,g i)*p.coeff g := by
  classical
  by_cases hg : g∈p.support
  · simp [degreeScaledPolynomial,MvPolynomial.coeff_monomial,hg]
  · have hz : p.coeff g=0 := by simpa only [MvPolynomial.mem_support_iff,not_not] using hg
    simp [degreeScaledPolynomial,MvPolynomial.coeff_monomial,hg,hz]

theorem degreeScaledPolynomial_eval (p : MvPolynomial (Fin n) ℝ) (c : ℝ) (x : Fin n → ℝ) :
    MvPolynomial.eval x (degreeScaledPolynomial p c)=MvPolynomial.eval (fun i => c*x i) p := by
  classical
  rw [degreeScaledPolynomial,map_sum]
  change (∑ g∈p.support,MvPolynomial.eval x (MvPolynomial.monomial g (c^(∑ i,g i)*p.coeff g)))=
    MvPolynomial.eval₂ (RingHom.id ℝ) (fun i => c*x i) p
  rw [MvPolynomial.eval₂_eq']
  apply Finset.sum_congr rfl
  intro g hg
  rw [MvPolynomial.eval_monomial]
  simp only [RingHom.id_apply,← Finsupp.prod_pow,mul_pow,Finset.prod_mul_distrib,
    Finset.prod_pow_eq_pow_sum]
  ring

theorem homogeneous_of_actual_double_scaling (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hscale : ∀ x : Fin n → ℝ,MvPolynomial.eval (fun i => 2*x i) p=2^N*MvPolynomial.eval x p) :
    p.IsHomogeneous N := by
  have heq : degreeScaledPolynomial p 2=MvPolynomial.C (2^N)*p := by
    apply MvPolynomial.funext
    intro x
    rw [degreeScaledPolynomial_eval,hscale,map_mul,MvPolynomial.eval_C]
  intro g hg
  have h := congrArg (fun q : MvPolynomial (Fin n) ℝ => q.coeff g) heq
  rw [degreeScaledPolynomial_coeff,MvPolynomial.coeff_C_mul] at h
  have hpowers : (2 : ℝ)^(∑ i,g i)=2^N := mul_right_cancel₀ hg h
  have hdegree : (∑ i,g i)=N := (pow_right_strictMono₀ (by norm_num : 1<(2 : ℝ))).injective hpowers
  simpa only [Finsupp.weight_eq_sum,Pi.one_apply,smul_eq_mul,mul_one] using hdegree

end CoefficientStability
