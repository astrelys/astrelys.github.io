import CoefficientStability.DegreeSensitiveGurvits

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem stable_rename_polynomial {m : ℕ} (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (f : Fin n → Fin m) : UpperHalfPlaneZeroFree (MvPolynomial.rename f p) := by
  intro z hz
  rw [MvPolynomial.eval₂_rename]
  exact hp (z∘f) (fun i => hz (f i))

theorem rename_equiv_coeff_nonneg (p : MvPolynomial (Fin n) ℝ) (e : Equiv.Perm (Fin n))
    (hc : ∀ g,0≤p.coeff g) : ∀ g,0≤(MvPolynomial.rename e p).coeff g := by
  intro g
  have hmap : (g.mapDomain e.symm).mapDomain e=g := by
    rw [← Finsupp.mapDomain_comp]
    have he : (e : Fin n → Fin n)∘e.symm=id := by funext j; simp
    rw [he,Finsupp.mapDomain_id]
  have h := MvPolynomial.coeff_rename_mapDomain e e.injective p (g.mapDomain e.symm)
  rw [hmap] at h
  rw [h]
  exact hc _

theorem squarefreeExponent_map_equiv (e : Equiv.Perm (Fin n)) :
    (squarefreeExponent n).mapDomain e=squarefreeExponent n := by
  ext j
  rw [← e.apply_symm_apply j,Finsupp.mapDomain_apply_of_injective e.injective]
  simp only [squarefreeExponent_value]

theorem rename_equiv_squarefree_coeff (p : MvPolynomial (Fin n) ℝ) (e : Equiv.Perm (Fin n)) :
    (MvPolynomial.rename e p).coeff (squarefreeExponent n)=p.coeff (squarefreeExponent n) := by
  have h := MvPolynomial.coeff_rename_mapDomain e e.injective p (squarefreeExponent n)
  simpa only [squarefreeExponent_map_equiv] using h

theorem multivariatePositiveCapacity_rename_equiv (p : MvPolynomial (Fin n) ℝ) (e : Equiv.Perm (Fin n)) :
    multivariatePositiveCapacity (MvPolynomial.rename e p)=multivariatePositiveCapacity p := by
  have heq :
      Set.range (fun x : {x : Fin n → ℝ // ∀ i,0<x i} => MvPolynomial.eval x.val (MvPolynomial.rename e p)/(∏ i,x.val i))=
      Set.range (fun x : {x : Fin n → ℝ // ∀ i,0<x i} => MvPolynomial.eval x.val p/(∏ i,x.val i)) := by
    ext y
    constructor
    · rintro ⟨x,rfl⟩
      refine ⟨⟨x.val∘e,fun j => x.prop (e j)⟩,?_⟩
      change MvPolynomial.eval (x.val∘e) p/(∏ j,x.val (e j))=
        MvPolynomial.eval x.val (MvPolynomial.rename e p)/(∏ j,x.val j)
      rw [Equiv.prod_comp e x.val,MvPolynomial.eval_rename]
    · rintro ⟨x,rfl⟩
      refine ⟨⟨x.val∘e.symm,fun j => x.prop (e.symm j)⟩,?_⟩
      change MvPolynomial.eval (x.val∘e.symm) (MvPolynomial.rename e p)/(∏ j,x.val (e.symm j))=
        MvPolynomial.eval x.val p/(∏ j,x.val j)
      rw [Equiv.prod_comp e.symm x.val,MvPolynomial.eval_rename]
      have hcomp : (x.val∘e.symm)∘e=x.val := by funext j; simp
      rw [hcomp]
  unfold multivariatePositiveCapacity
  rw [heq]

theorem paper_reduced_variable_degree_capacity_lower (p : MvPolynomial (Fin (n+1)) ℝ)
    (hp : p.IsHomogeneous (n+1)) (hs : UpperHalfPlaneZeroFree p) (hc : ∀ g,0≤p.coeff g)
    (i : Fin (n+1)) (hdegree : p.degreeOf i≤n) :
    (sourceVn (n+1)*capacityG n/capacityG (n+1))*multivariatePositiveCapacity p≤
      p.coeff (squarefreeExponent (n+1)) := by
  let e : Equiv.Perm (Fin (n+1)) := Equiv.swap i (Fin.last n)
  have hei : e i=Fin.last n := Equiv.swap_apply_left i (Fin.last n)
  have hqhom : (MvPolynomial.rename e p).IsHomogeneous (n+1) := hp.rename_isHomogeneous
  have hqs := stable_rename_polynomial p hs e
  have hqcoeff := rename_equiv_coeff_nonneg p e hc
  have hqdegree : (MvPolynomial.rename e p).degreeOf (Fin.last n)≤n := by
    rw [← hei,MvPolynomial.degreeOf_rename_of_injective e.injective i]
    exact hdegree
  have h := reduced_last_degree_gurvits_capacity_lower _ hqhom hqs hqcoeff hqdegree
  rw [multivariatePositiveCapacity_rename_equiv,rename_equiv_squarefree_coeff] at h
  exact h

end CoefficientStability
