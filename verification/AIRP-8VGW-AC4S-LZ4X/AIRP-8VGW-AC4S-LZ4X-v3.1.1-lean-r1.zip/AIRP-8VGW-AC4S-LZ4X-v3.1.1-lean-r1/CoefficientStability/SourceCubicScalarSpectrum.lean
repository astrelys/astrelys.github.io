import CoefficientStability.SourceCubicScalarEigenvalues
import CoefficientStability.SourceCubicCommonMultiplier

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 2600000
set_option backward.isDefEq.respectTransparency false

theorem source_cubic_scalar_certificate_eigenvalue_equation (t c : ℝ)
    (X S : Matrix (Fin 3) (Fin 3) ℂ) (hX : X.IsHermitian)
    (hc : sourceCubicMatrixGradient t X=(c : ℂ) • 1+S) (hSX : S*X=0) :
    ∀ i,0 < hX.eigenvalues i →
      2*(hX.eigenvalues i)^2+(1-2*t)*hX.eigenvalues i=c := by
  let φ := Unitary.conjStarAlgAut ℂ (Matrix (Fin 3) (Fin 3) ℂ) (star hX.eigenvectorUnitary)
  let d : Fin 3 → ℂ := fun i => (hX.eigenvalues i : ℂ)
  have hφ : φ X=Matrix.diagonal d := hX.conjStarAlgAut_star_eigenvectorUnitary
  have hm := congrArg (fun M => M*X) hc
  simp only [sourceCubicMatrixGradient,add_mul,smul_mul_assoc,one_mul,hSX,add_zero] at hm
  have hp := congrArg φ hm
  simp only [map_add,map_smul,map_mul,map_pow,hφ,RingHom.id_apply,pow_two,Matrix.diagonal_mul_diagonal] at hp
  intro i hi
  have h := congrFun (congrFun hp i) i
  norm_num [Matrix.add_apply,Matrix.smul_apply,Matrix.diagonal_apply,d,smul_eq_mul] at h
  have hr : 2*(hX.eigenvalues i*hX.eigenvalues i*hX.eigenvalues i)+(1-2*t)*(hX.eigenvalues i*hX.eigenvalues i)=c*hX.eigenvalues i := by
    exact_mod_cast h
  have he : hX.eigenvalues i*(2*(hX.eigenvalues i)^2+(1-2*t)*hX.eigenvalues i-c)=0 := by nlinarith [hr]
  have hz := (mul_eq_zero.mp he).resolve_left (ne_of_gt hi)
  linarith

theorem source_cubic_scalar_certificate_repeated_eigenvalue (t c : ℝ)
    (X S : Matrix (Fin 3) (Fin 3) ℂ) (hX : X.PosSemidef)
    (ht : Matrix.trace X=(t : ℂ))
    (hc : sourceCubicMatrixGradient t X=(c : ℂ) • 1+S) (hSX : S*X=0) :
    hX.isHermitian.eigenvalues 0=hX.isHermitian.eigenvalues 1 ∨
      hX.isHermitian.eigenvalues 0=hX.isHermitian.eigenvalues 2 ∨
      hX.isHermitian.eigenvalues 1=hX.isHermitian.eigenvalues 2 := by
  have hsum : (∑ i,hX.isHermitian.eigenvalues i)=t := by
    have h := hX.isHermitian.trace_eq_sum_eigenvalues
    rw [ht] at h
    apply Complex.ofReal_injective
    push_cast
    exact h.symm
  exact source_cubic_scalar_quadratic_repeated_eigenvalue t c hX.isHermitian.eigenvalues
    hX.eigenvalues_nonneg hsum (source_cubic_scalar_certificate_eigenvalue_equation t c X S hX.isHermitian hc hSX)

end CoefficientStability
