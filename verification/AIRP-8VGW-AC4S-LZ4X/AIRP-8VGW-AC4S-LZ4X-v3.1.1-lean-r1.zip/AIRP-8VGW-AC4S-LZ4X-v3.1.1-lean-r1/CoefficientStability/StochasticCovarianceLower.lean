import CoefficientStability.PolynomialCovarianceQuadratic
import CoefficientStability.CoefficientComparison

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem stochastic_composition_covariance_lower (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hcoeff : ∀ g,0≤p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (M : Matrix (Fin n) (Fin n) ℝ) (hrow : ∀ i,∑ j,M i j=1)
    (ε : ℝ) (hε : 0≤ε) (hmin : ∀ i j,ε≤M i j) (v : Fin n → ℝ) (hv : ∑ j,v j=0) :
    let q := matrixSubstitution M p
    let s := fun j => MvPolynomial.eval (fun _ => 1) (pderiv j q)
    ((N : ℝ)*ε)*(∑ j,v j^2)≤matrixQuadratic (coefficientCovariance q s) v := by
  dsimp only
  let t : Fin n → ℝ := fun i => MvPolynomial.eval (fun _ => 1) (pderiv i p)
  have ht0 : ∀ i,0≤t i := actual_gradient_nonneg p t hcoeff (fun i => rfl)
  have ht : (∑ i,t i)=(N : ℝ) := homogeneous_gradient_total p N hp hnorm
  have hb := psd_matrixQuadratic_nonneg (coefficientCovariance p t)
    (coefficientCovariance_posSemidef p t hcoeff) (M.mulVec v)
  have hs := Finset.sum_le_sum (s := (Finset.univ : Finset (Fin n)))
    (fun i hi => mul_le_mul_of_nonneg_left
      (categoricalVariance_uniform_lower (fun j => M i j) v ε hε (hrow i) (hmin i) hv) (ht0 i))
  rw [← Finset.sum_mul,ht] at hs
  rw [matrixSubstitution_covariance_quadratic M p hrow hnorm v]
  change ((N : ℝ)*ε)*(∑ j,v j^2)≤matrixQuadratic (coefficientCovariance p t) (M.mulVec v)+
    ∑ i,t i*categoricalVariance (fun j => M i j) v
  nlinarith only [hb,hs]

end CoefficientStability
