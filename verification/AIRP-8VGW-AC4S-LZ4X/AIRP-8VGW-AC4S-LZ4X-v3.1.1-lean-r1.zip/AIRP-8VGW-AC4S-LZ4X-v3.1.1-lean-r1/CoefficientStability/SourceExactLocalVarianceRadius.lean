import CoefficientStability.SourceExactLocalRemainder

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000

def sourceTraceMaximum {n : ℕ} (t : Fin n → ℝ) (hn : 0<n) : ℝ :=
  Finset.univ.sup' (show (Finset.univ : Finset (Fin n)).Nonempty from ⟨⟨0,hn⟩,Finset.mem_univ _⟩) t

theorem source_trace_le_actual_maximum {n : ℕ} (t : Fin n → ℝ) (hn : 0<n) (i : Fin n) :
    t i≤sourceTraceMaximum t hn := by
  exact Finset.le_sup' t (Finset.mem_univ i)

theorem source_exact_remainder_n2_zero : sourceExactRemainderConstant 2=0 := by
  norm_num [sourceExactRemainderConstant]

theorem source_exact_remainder_positive (n : ℕ) (hn : 3≤n) : 0<sourceExactRemainderConstant n := by
  unfold sourceExactRemainderConstant
  apply mul_pos (by positivity)
  apply Finset.sum_pos'
  · intro j hj
    positivity
  · refine ⟨0,by simp only [Finset.mem_range];omega,?_⟩
    have hc : 0<(n.choose 3 : ℝ) := by exact_mod_cast (Nat.choose_pos (by omega : 3≤n))
    have hnR : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
    have hs : 0<Real.sqrt (2*(n : ℝ)) := Real.sqrt_pos.mpr (mul_pos (by norm_num) hnR)
    simpa only [zero_add] using mul_pos hc (pow_pos hs 3)

theorem source_stable_exact_small_variance_growth {n : ℕ}
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hn : 3≤n) (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) (ht : (∑ i,t i)=n) (htpos : ∀ i,0<t i)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (M : ℝ) (hM : ∀ i,t i≤M) (hl : 0<scalarHessianLambda t)
    (hsmall : referenceDeficit p t n≤min 1
      (((sourceHessianFactor t*(scalarHessianLambda t/M^2))/(2*sourceExactRemainderConstant n))^2)) :
    (sourceHessianFactor t*(scalarHessianLambda t/M^2))*referenceDeficit p t n/2≤
      (p-scalarPower t n).coeff (squarefreeExponent n) := by
  let d := referenceDeficit p t n
  let a := sourceHessianFactor t*(scalarHessianLambda t/M^2)
  let B := sourceExactRemainderConstant n
  have hd : 0≤d := referenceDeficit_nonneg p t n (by omega) hp hnorm hs hg
  have hB : 0<B := source_exact_remainder_positive n hn
  have hM0 : 0<M := (htpos ⟨0,by omega⟩).trans_le (hM ⟨0,by omega⟩)
  have ha : 0<a := mul_pos (sourceHessianFactor_pos t (by omega) htpos) (div_pos hl (sq_pos_of_pos hM0))
  have hd1 : d≤1 := (le_min_iff.mp hsmall).1
  have hdsq : d≤(a/(2*B))^2 := (le_min_iff.mp hsmall).2
  have hroot : Real.sqrt d≤a/(2*B) := Real.sqrt_le_iff.mpr ⟨by positivity,hdsq⟩
  have hm := (le_div_iff₀ (show 0<2*B by positivity)).mp hroot
  have hmm := mul_le_mul_of_nonneg_right hm hd
  have hhalf : a*d/2≤a*d-B*(d*Real.sqrt d) := by nlinarith only [hmm]
  exact hhalf.trans (source_stable_effective_gap_exact_remainder p t (by omega) hp hnorm hs ht htpos hg M hM hl hd1)

theorem source_stable_literal_local_variance_radius {n : ℕ}
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hn : 3≤n) (hp : p.IsHomogeneous n) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) (ht : (∑ i,t i)=n) (htpos : ∀ i,0<t i)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (hl : 0<scalarHessianLambda t)
    (hsmall : referenceDeficit p t n≤min 1
      (((sourceHessianFactor t*(scalarHessianLambda t/(sourceTraceMaximum t (by omega))^2))/
        (2*sourceExactRemainderConstant n))^2)) :
    (sourceHessianFactor t*(scalarHessianLambda t/(sourceTraceMaximum t (by omega))^2))*
      referenceDeficit p t n/2≤(p-scalarPower t n).coeff (squarefreeExponent n) :=
  source_stable_exact_small_variance_growth p t hn hp hnorm hs ht htpos hg _
    (source_trace_le_actual_maximum t (by omega)) hl hsmall

end CoefficientStability
