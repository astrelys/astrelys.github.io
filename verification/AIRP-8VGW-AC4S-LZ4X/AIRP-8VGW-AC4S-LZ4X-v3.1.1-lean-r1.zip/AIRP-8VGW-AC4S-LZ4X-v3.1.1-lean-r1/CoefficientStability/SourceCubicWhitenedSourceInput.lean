import CoefficientStability.SourceBinaryQuadraticMatrices
import CoefficientStability.SourceCubicConicCoordinateMatrices
import CoefficientStability.SourceCubicLinearRepresentationPullback

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceCubicDepressedPolynomial (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ) :=
  matrixSubstitution (sourceDepressedCoordinateMatrix t) p

def sourceCubicWhitenedPolynomial (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ) :=
  matrixSubstitution (sourceBinaryWhiteningMatrix (deficitMatrix p t 3 0 0)
    (deficitMatrix p t 3 0 1) (deficitMatrix p t 3 1 1)) (sourceCubicDepressedPolynomial p t)

def sourceCubicWhitenedRemainder (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ) (u v : ℝ) :=
  MvPolynomial.eval
    (![sourceBinaryWhiteningInverse (deficitMatrix p t 3 0 0) (deficitMatrix p t 3 0 1)
        (deficitMatrix p t 3 1 1) u v 0,
      sourceBinaryWhiteningInverse (deficitMatrix p t 3 0 0) (deficitMatrix p t 3 0 1)
        (deficitMatrix p t 3 1 1) u v 1,0] : Fin 3 → ℝ)
    (centralCoefficientPolynomial p t 3 3)

theorem source_cubic_whitened_polynomial_homogeneous
    (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ) (hp : p.IsHomogeneous 3) :
    (sourceCubicWhitenedPolynomial p t).IsHomogeneous 3 :=
  matrixSubstitution_homogeneous _ _ _ (matrixSubstitution_homogeneous _ _ _ hp)

theorem source_stable_cubic_actual_whitened_normal_form
    (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ)
    (hp : p.IsHomogeneous 3) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p) (ht : ∑ i,t i=3)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (ha : 0<deficitMatrix p t 3 0 0)
    (hd : 0<deficitMatrix p t 3 0 0*deficitMatrix p t 3 1 1-(deficitMatrix p t 3 0 1)^2)
    (s u v : ℝ) :
    MvPolynomial.eval (![s,u,v] : Fin 3 → ℝ) (sourceCubicWhitenedPolynomial p t)=
      s^3-s*(u^2+v^2)+sourceCubicWhitenedRemainder p t u v := by
  unfold sourceCubicWhitenedPolynomial sourceCubicDepressedPolynomial
  rw [matrixSubstitution_eval,source_binary_whitening_matrix_actual,matrixSubstitution_eval,
    source_depressed_coordinate_matrix_actual,
    source_stable_cubic_actual_depressed_normal_form p t hp hn hs ht hg]
  change s^3-s*matrixQuadratic (deficitMatrix p t 3)
      (![sourceBinaryWhiteningInverse (deficitMatrix p t 3 0 0) (deficitMatrix p t 3 0 1)
          (deficitMatrix p t 3 1 1) u v 0,
        sourceBinaryWhiteningInverse (deficitMatrix p t 3 0 0) (deficitMatrix p t 3 0 1)
          (deficitMatrix p t 3 1 1) u v 1,0] : Fin 3 → ℝ)+sourceCubicWhitenedRemainder p t u v=
      s^3-s*(u^2+v^2)+sourceCubicWhitenedRemainder p t u v
  rw [source_binary_restricted_quadratic_exact _ (deficitMatrix_isHermitian p t 3),
    source_binary_whitening_actual_quadratic _ _ _ u v ha hd]

theorem source_stable_cubic_actual_whitened_discriminant
    (p : MvPolynomial (Fin 3) ℝ) (t : Fin 3 → ℝ)
    (hp : p.IsHomogeneous 3) (hn : MvPolynomial.eval (fun _ => 1) p=1)
    (hs : UpperHalfPlaneZeroFree p)
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i)
    (ha : 0<deficitMatrix p t 3 0 0)
    (hd : 0<deficitMatrix p t 3 0 0*deficitMatrix p t 3 1 1-(deficitMatrix p t 3 0 1)^2)
    (u v : ℝ) :
    0≤4*(u^2+v^2)^3-27*(sourceCubicWhitenedRemainder p t u v)^2 := by
  have h := source_stable_cubic_actual_central_discriminant p t hp hn hs hg
    (![sourceBinaryWhiteningInverse (deficitMatrix p t 3 0 0) (deficitMatrix p t 3 0 1)
        (deficitMatrix p t 3 1 1) u v 0,
      sourceBinaryWhiteningInverse (deficitMatrix p t 3 0 0) (deficitMatrix p t 3 0 1)
        (deficitMatrix p t 3 1 1) u v 1,0] : Fin 3 → ℝ)
  rw [source_binary_restricted_quadratic_exact _ (deficitMatrix_isHermitian p t 3),
    source_binary_whitening_actual_quadratic _ _ _ u v ha hd] at h
  exact h

end CoefficientStability
