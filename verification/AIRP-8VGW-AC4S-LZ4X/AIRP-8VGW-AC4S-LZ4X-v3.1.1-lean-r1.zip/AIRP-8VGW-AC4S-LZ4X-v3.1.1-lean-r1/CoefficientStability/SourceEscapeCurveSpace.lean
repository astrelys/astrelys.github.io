import CoefficientStability.SourceEscapeQuadraticBound

noncomputable section
open scoped BigOperators Topology unitInterval
namespace CoefficientStability
set_option maxHeartbeats 3500000
set_option backward.isDefEq.respectTransparency false

abbrev SourceEscapeCurve := C(unitInterval,Matrix (Fin 3) (Fin 3) ℝ)

def sourceEscapeExcess (a b : ℝ) (X : Matrix (Fin 3) (Fin 3) ℝ) : ℝ :=
  Matrix.permanent X-Matrix.permanent (sourceEscapeCenter a b)

def sourceEscapeAdmissible (a b : ℝ) (γ : SourceEscapeCurve) : Prop :=
  γ 0=sourceEscapeCenter a b ∧
    (∀ u,γ u ∈ sourceTransportationPolytope (sourceEscapeTraces a b)) ∧
    sourceEscapeQ a b < sourceEscapeQuadratic a b (γ 1-sourceEscapeCenter a b)

def sourceEscapeCurveHeight (a b : ℝ) (γ : SourceEscapeCurve) : ℝ :=
  sSup (Set.range (fun u => sourceEscapeExcess a b (γ u)))

def sourceEscapeBarrier (a b : ℝ) : ℝ :=
  sInf (sourceEscapeCurveHeight a b '' {γ : SourceEscapeCurve | sourceEscapeAdmissible a b γ})

theorem source_escape_excess_continuous (a b : ℝ) : Continuous (sourceEscapeExcess a b) :=
  source_permanent_continuous.sub continuous_const

theorem source_escape_curve_height_bounded (a b : ℝ) (γ : SourceEscapeCurve) :
    BddAbove (Set.range (fun u => sourceEscapeExcess a b (γ u))) :=
  (isCompact_range ((source_escape_excess_continuous a b).comp γ.continuous)).bddAbove

theorem source_escape_curve_height_attained (a b : ℝ) (γ : SourceEscapeCurve) :
    ∃ u,sourceEscapeExcess a b (γ u)=sourceEscapeCurveHeight a b γ := by
  have hc := isCompact_range ((source_escape_excess_continuous a b).comp γ.continuous)
  exact hc.sSup_mem (Set.range_nonempty _)

theorem source_escape_curve_excess_le_height (a b : ℝ) (γ : SourceEscapeCurve) (u : unitInterval) :
    sourceEscapeExcess a b (γ u) ≤ sourceEscapeCurveHeight a b γ :=
  le_csSup (source_escape_curve_height_bounded a b γ) (Set.mem_range_self u)

theorem source_escape_curve_height_le (a b : ℝ) (γ : SourceEscapeCurve) (h : ℝ)
    (hb : ∀ u,sourceEscapeExcess a b (γ u) ≤ h) : sourceEscapeCurveHeight a b γ ≤ h :=
  csSup_le (Set.range_nonempty _) (by rintro _ ⟨u,rfl⟩;exact hb u)

theorem source_escape_every_curve_crosses (a b : ℝ) (ha : 0 < a) (hb : 0 < b)
    (γ : SourceEscapeCurve) (hγ : sourceEscapeAdmissible a b γ) :
    ∃ u : unitInterval,sourceEscapeQuadratic a b (γ u-sourceEscapeCenter a b)=sourceEscapeQ a b := by
  let g : unitInterval → ℝ := fun u => sourceEscapeQuadratic a b (γ u-sourceEscapeCenter a b)
  have hc : Continuous g := (source_escape_quadratic_continuous a b).comp (γ.continuous.sub continuous_const)
  have hz : g 0=0 := by simp [g,hγ.1]
  have hQ : 0 < sourceEscapeQ a b := by unfold sourceEscapeQ;positivity
  have hI := intermediate_value_Icc (show (0 : unitInterval) ≤ 1 by exact zero_le_one) hc.continuousOn
  have hmem : sourceEscapeQ a b ∈ Set.Icc (g 0) (g 1) := by
    rw [hz]
    exact ⟨hQ.le,hγ.2.2.le⟩
  obtain ⟨u,hu,he⟩ := hI hmem
  exact ⟨u,he⟩

theorem source_escape_every_curve_height_lower (a b : ℝ) (ha : 0 < a) (hb : 0 < b) (hs : a+2*b=3)
    (γ : SourceEscapeCurve) (hγ : sourceEscapeAdmissible a b γ) :
    sourceEscapeDelta a b ≤ sourceEscapeCurveHeight a b γ := by
  obtain ⟨u,hu⟩ := source_escape_every_curve_crosses a b ha hb γ hγ
  have ht := source_escape_feasible_displacement_tangent a b ha hb hs (γ u) (hγ.2.1 u)
  have hl := source_escape_actual_crossing_height_bound a b ha hb (γ u-sourceEscapeCenter a b) ht hu
  have he : sourceEscapeCenter a b+(γ u-sourceEscapeCenter a b)=γ u := by abel
  rw [he] at hl
  exact hl.trans (source_escape_curve_excess_le_height a b γ u)

theorem source_escape_barrier_lower (a b : ℝ) (ha : 0 < a) (hb : 0 < b) (hs : a+2*b=3)
    (hne : ∃ γ : SourceEscapeCurve,sourceEscapeAdmissible a b γ) : sourceEscapeDelta a b ≤ sourceEscapeBarrier a b := by
  apply le_csInf
  · obtain ⟨γ,hγ⟩ := hne
    exact ⟨sourceEscapeCurveHeight a b γ,γ,hγ,rfl⟩
  · rintro _ ⟨γ,hγ,rfl⟩
    exact source_escape_every_curve_height_lower a b ha hb hs γ hγ

theorem source_escape_barrier_le_curve (a b : ℝ) (ha : 0 < a) (hb : 0 < b) (hs : a+2*b=3)
    (γ : SourceEscapeCurve) (hγ : sourceEscapeAdmissible a b γ) :
    sourceEscapeBarrier a b ≤ sourceEscapeCurveHeight a b γ := by
  apply csInf_le
  · refine ⟨sourceEscapeDelta a b,?_⟩
    rintro _ ⟨η,hη,rfl⟩
    exact source_escape_every_curve_height_lower a b ha hb hs η hη
  · exact ⟨γ,hγ,rfl⟩

end CoefficientStability
