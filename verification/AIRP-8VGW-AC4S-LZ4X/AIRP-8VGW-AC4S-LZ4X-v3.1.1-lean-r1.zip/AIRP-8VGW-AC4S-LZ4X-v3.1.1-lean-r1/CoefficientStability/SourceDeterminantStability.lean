import CoefficientStability.DeterminantalGram
import CoefficientStability.SourceMultiindexLocalClosure
import Mathlib.Analysis.Complex.Order
import Mathlib.LinearAlgebra.Matrix.ToLinearEquiv

noncomputable section
open scoped BigOperators ComplexOrder
namespace CoefficientStability
variable {n : ℕ}

theorem source_psd_pencil_det_ne_zero (A : Fin n → ComplexSquare n)
    (hPSD : ∀ i,(A i).PosSemidef) (hA : ∑ i,A i=1)
    (z : Fin n → ℂ) (hz : ∀ i,0 < (z i).im) :
    Matrix.det (∑ i,z i • A i)≠0 := by
  classical
  intro hdet
  obtain ⟨v,hv,hker⟩ := Matrix.exists_mulVec_eq_zero_iff.mpr hdet
  let q : Fin n → ℂ := fun i => dotProduct (star v) ((A i).mulVec v)
  have hq (i : Fin n) : 0 ≤ (q i).re ∧ 0=(q i).im :=
    Complex.nonneg_iff.mp ((hPSD i).dotProduct_mulVec_nonneg v)
  have hsum : (∑ i,q i)=dotProduct (star v) v := by
    simp only [q,← dotProduct_sum,← Matrix.sum_mulVec,hA,Matrix.one_mulVec]
  have hnorm : 0 < (dotProduct (star v) v).re := by
    obtain ⟨i,hi⟩ := Function.ne_iff.mp hv
    have hip : 0 < Complex.normSq (v i) := Complex.normSq_pos.mpr hi
    have hs : 0 < ∑ j,Complex.normSq (v j) :=
      Finset.sum_pos' (fun j _ => Complex.normSq_nonneg _) ⟨i,Finset.mem_univ i,hip⟩
    simpa only [dotProduct,Pi.star_apply,Complex.star_def,Complex.re_sum,Complex.mul_re,
      Complex.conj_re,Complex.conj_im,Complex.normSq_apply,neg_mul,sub_neg_eq_add] using hs
  have hqsum : 0 < ∑ i,(q i).re := by
    rw [← Complex.re_sum,hsum]
    exact hnorm
  obtain ⟨i,hi,hip⟩ := (Finset.sum_pos_iff_of_nonneg (fun i _ => (hq i).1)).mp hqsum
  have hweighted : 0 < ∑ j,(z j).im*(q j).re :=
    Finset.sum_pos' (fun j _ => mul_nonneg (hz j).le (hq j).1) ⟨i,hi,mul_pos (hz i) hip⟩
  have hzero : (∑ i,z i*q i)=0 := by
    have he := congrArg (fun w : Fin n → ℂ => dotProduct (star v) w) hker
    simpa only [Matrix.sum_mulVec,Matrix.smul_mulVec,dotProduct_sum,dotProduct_smul,q,dotProduct_zero,smul_eq_mul] using he
  have him := congrArg Complex.im hzero
  simp only [Complex.im_sum,Complex.mul_im,← (hq _).2,mul_zero,zero_add,Complex.zero_im] at him
  linarith

theorem source_realDeterminant_stable (A : Fin n → ComplexSquare n)
    (hPSD : ∀ i,(A i).PosSemidef) (hA : ∑ i,A i=1) :
    UpperHalfPlaneZeroFree (realDeterminantPolynomial A) := by
  intro z hz
  have he : MvPolynomial.eval₂ Complex.ofRealHom z (realDeterminantPolynomial A)=
      Matrix.det (∑ i,z i • A i) := by
    rw [← MvPolynomial.eval_map,realDeterminantPolynomial_complexification A (fun i => (hPSD i).isHermitian),
      determinantPolynomial_eval]
  rw [he]
  exact source_psd_pencil_det_ne_zero A hPSD hA z hz

end CoefficientStability
