import CoefficientStability.DirectionalFamilyContinuity

noncomputable section
namespace CoefficientStability
variable {n N : ℕ}

theorem source_cone_forward_eval_pos (p : MvPolynomial (Fin n) ℝ)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N) (s : ℝ) (hs : 0≤s) :
    0<MvPolynomial.eval (fun i => s+b i) p := by
  obtain ⟨roots,hcard,hr,hfactor⟩ := hb
  rw [← eval_lineRestriction_real,hfactor,Polynomial.eval_multiset_prod]
  apply Multiset.prod_pos
  intro v hv
  obtain ⟨q,hq,rfl⟩ := Multiset.mem_map.mp hv
  obtain ⟨r,hrr,rfl⟩ := Multiset.mem_map.mp hq
  simpa using add_pos_of_nonneg_of_pos hs (hr r hrr)

theorem source_cone_segment_eval_pos (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous N) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (y : Fin n → ℝ) (hy : y∈positiveSpectralCone p N)
    (a : ℝ) (ha : 0≤a) (ha1 : a≤1) :
    0<MvPolynomial.eval (fun i => a*y i+(1-a)) p := by
  by_cases hz : a=0
  · subst a
    simpa using (show 0<MvPolynomial.eval (fun _ => 1) p by rw [hnorm];norm_num)
  · have hapos : 0<a := lt_of_le_of_ne ha (Ne.symm hz)
    have hshift := source_cone_forward_eval_pos p y hy ((1-a)/a) (div_nonneg (by linarith) ha)
    have heq : (fun i => a*(((1-a)/a)+y i))=(fun i => a*y i+(1-a)) := by
      funext i
      field_simp
      <;> ring
    have h := homogeneous_eval_real_scale p N hp a (fun i => ((1-a)/a)+y i)
    rw [heq] at h
    rw [h]
    exact mul_pos (pow_pos hapos _) hshift

theorem source_cone_reciprocal_ray_eval_pos (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous N) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (b : Fin n → ℝ) (hb : b∈positiveSpectralCone p N) (t : ℝ) (ht : 0≤t) :
    0<MvPolynomial.eval (fun i => 1+t*b i) p := by
  by_cases hz : t=0
  · subst t
    simpa using (show 0<MvPolynomial.eval (fun _ => 1) p by rw [hnorm];norm_num)
  · have htpos : 0<t := lt_of_le_of_ne ht (Ne.symm hz)
    have hshift := source_cone_forward_eval_pos p b hb (1/t) (by positivity)
    have heq : (fun i => t*((1/t)+b i))=(fun i => 1+t*b i) := by
      funext i
      field_simp
      <;> ring
    have h := homogeneous_eval_real_scale p N hp t (fun i => (1/t)+b i)
    rw [heq] at h
    rw [h]
    exact mul_pos (pow_pos htpos _) hshift

end CoefficientStability
