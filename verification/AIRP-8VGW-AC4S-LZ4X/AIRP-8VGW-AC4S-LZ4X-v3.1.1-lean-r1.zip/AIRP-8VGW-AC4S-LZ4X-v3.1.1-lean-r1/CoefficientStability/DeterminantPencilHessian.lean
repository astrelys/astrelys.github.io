import CoefficientStability.DeterminantPencil

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ} {R : Type*} [CommRing R]

theorem determinantPencil_replaced_partial (A : Fin n → Matrix (Fin n) (Fin n) R)
    (i j c : Fin n) :
    pderiv j (Matrix.det (Matrix.updateCol (determinantPencil A) c (fun r => C (A i r c))))=
      ∑ k,if k=c then 0 else Matrix.det
        (Matrix.updateCol (Matrix.updateCol (determinantPencil A) c (fun r => C (A i r c)))
          k (fun r => C (A j r k))) := by
  classical
  rw [partial_determinant_columns]
  apply Finset.sum_congr rfl
  intro k hk
  by_cases h : k=c
  · subst k
    simp only [ite_true]
    apply Matrix.det_eq_zero_of_column_eq_zero c
    intro r
    simp [pderiv_C]
  · simp only [h,ite_false]
    congr 1
    apply Matrix.ext
    intro r u
    by_cases hu : u=k
    · subst u
      simp [h,determinantPencil_partial]
    · simp [hu]

theorem determinantPolynomial_second_partial (A : Fin n → Matrix (Fin n) (Fin n) R)
    (i j : Fin n) :
    pderiv j (pderiv i (determinantPolynomial A))=
      ∑ c,∑ k,if k=c then 0 else Matrix.det
        (Matrix.updateCol (Matrix.updateCol (determinantPencil A) c (fun r => C (A i r c)))
          k (fun r => C (A j r k))) := by
  rw [determinantPolynomial_partial,map_sum]
  simp only [determinantPencil_replaced_partial]

theorem determinantPolynomial_hessian_one (A : Fin n → Matrix (Fin n) (Fin n) R)
    (hA : ∑ i,A i=1) (i j : Fin n) :
    MvPolynomial.eval (fun _ => 1) (pderiv j (pderiv i (determinantPolynomial A)))=
      Matrix.trace (A i)*Matrix.trace (A j)-Matrix.trace (A i*A j) := by
  classical
  rw [determinantPolynomial_second_partial]
  simp only [map_sum]
  rw [← matrix_pair_trace_sum]
  apply Finset.sum_congr rfl
  intro c hc
  apply Finset.sum_congr rfl
  intro k hk
  by_cases h : k=c
  · simp [h]
  · simp only [h,ite_false,RingHom.map_det,RingHom.mapMatrix_apply,
      matrix_eval_updateCol,determinantPencil_eval,one_smul,hA,eval_C]
    rw [det_identity_two_columns _ _ c k (Ne.symm h)]

end CoefficientStability
