import CoefficientStability.StableLine
import CoefficientStability.CoefficientDeficit

noncomputable section
open scoped BigOperators
open Polynomial MvPolynomial Finsupp
namespace CoefficientStability
variable {n : ℕ}

def monomialLine (g : Fin n →₀ ℕ) (x : Fin n → ℝ) : ℝ[X] :=
  ∏ i, (Polynomial.X + Polynomial.C (x i)) ^ g i

theorem monomialLine_monic (g : Fin n →₀ ℕ) (x : Fin n → ℝ) :
    (monomialLine g x).Monic := by
  apply Polynomial.monic_prod_of_monic
  intro i hi
  exact (Polynomial.monic_X_add_C (x i)).pow _

theorem monomialLine_natDegree (g : Fin n →₀ ℕ) (x : Fin n → ℝ) :
    (monomialLine g x).natDegree = ∑ i, g i := by
  unfold monomialLine
  rw [Polynomial.natDegree_prod_of_monic _ _ (fun i _ => (Polynomial.monic_X_add_C (x i)).pow _)]
  simp

theorem lineRestriction_monomial (g : Fin n →₀ ℕ) (c : ℝ) (x : Fin n → ℝ) :
    lineRestriction (MvPolynomial.monomial g c) x = Polynomial.C c * monomialLine g x := by
  unfold lineRestriction
  rw [MvPolynomial.eval₂_monomial]
  congr 1
  exact g.prod_fintype _ (by simp)

theorem lineRestriction_as_sum (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ) :
    lineRestriction p x = ∑ g ∈ p.support, Polynomial.C (p.coeff g) * monomialLine g x := by
  conv_lhs => rw [p.as_sum]
  simp only [lineRestriction, MvPolynomial.eval₂_sum]
  apply Finset.sum_congr rfl
  intro g hg
  exact lineRestriction_monomial g (p.coeff g) x

theorem lineRestriction_natDegree_le (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ)
    (N : ℕ) (hp : p.IsHomogeneous N) : (lineRestriction p x).natDegree ≤ N := by
  rw [lineRestriction_as_sum]
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro g hg
  apply (Polynomial.natDegree_C_mul_le _ _).trans
  rw [monomialLine_natDegree, homogeneous_mass p N hp g hg]

theorem lineRestriction_top_coefficient (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ)
    (N : ℕ) (hp : p.IsHomogeneous N) :
    (lineRestriction p x).coeff N = MvPolynomial.eval (fun _ => 1) p := by
  rw [lineRestriction_as_sum, Polynomial.finsetSum_coeff, ← coefficient_sum_eq_eval_one]
  apply Finset.sum_congr rfl
  intro g hg
  rw [Polynomial.coeff_C_mul]
  have hdeg : (monomialLine g x).natDegree = N := by
    rw [monomialLine_natDegree, homogeneous_mass p N hp g hg]
  have hcoeff := (monomialLine_monic g x).coeff_natDegree
  rw [hdeg] at hcoeff
  rw [hcoeff, mul_one]

theorem normalized_lineRestriction_monic (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ)
    (N : ℕ) (hp : p.IsHomogeneous N) (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) :
    (lineRestriction p x).Monic := by
  apply Polynomial.monic_of_degree_le N
  · exact Polynomial.degree_le_of_natDegree_le (lineRestriction_natDegree_le p x N hp)
  · rw [lineRestriction_top_coefficient p x N hp, hnorm]

theorem normalized_lineRestriction_natDegree (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ)
    (N : ℕ) (hp : p.IsHomogeneous N) (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) :
    (lineRestriction p x).natDegree = N := by
  apply Polynomial.natDegree_eq_of_le_of_coeff_ne_zero (lineRestriction_natDegree_le p x N hp)
  rw [lineRestriction_top_coefficient p x N hp, hnorm]
  exact one_ne_zero

theorem real_linear_product_natDegree (roots : Multiset ℝ) :
    (roots.map (fun r => Polynomial.X + Polynomial.C r)).prod.natDegree = roots.card := by
  have hm : ∀ f ∈ roots.map (fun r => Polynomial.X + Polynomial.C r), f.Monic := by
    intro f hf
    obtain ⟨r, hr, rfl⟩ := Multiset.mem_map.mp hf
    exact Polynomial.monic_X_add_C r
  rw [Polynomial.natDegree_multiset_prod_of_monic _ hm]
  simp

theorem normalized_stable_line_real_factors
    (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) (hnorm : MvPolynomial.eval (fun _ => 1) p = 1)
    (hstable : UpperHalfPlaneZeroFree p) :
    ∃ roots : Multiset ℝ, roots.card = N ∧
      lineRestriction p x = (roots.map (fun r => Polynomial.X + Polynomial.C r)).prod := by
  obtain ⟨roots, hr⟩ := lineRestriction_real_factorization p hstable x
  have hm := normalized_lineRestriction_monic p x N hp hnorm
  have he : lineRestriction p x = (roots.map (fun r => Polynomial.X + Polynomial.C r)).prod := by
    simpa [hm] using hr
  refine ⟨roots, ?_, he⟩
  have hd := normalized_lineRestriction_natDegree p x N hp hnorm
  rw [he, real_linear_product_natDegree] at hd
  exact hd

theorem monomialLine_nextCoeff (g : Fin n →₀ ℕ) (x : Fin n → ℝ) :
    (monomialLine g x).nextCoeff = ∑ i, (g i : ℝ)*x i := by
  unfold monomialLine
  rw [Polynomial.Monic.nextCoeff_prod _ _ (fun i _ => (Polynomial.monic_X_add_C (x i)).pow _)]
  apply Finset.sum_congr rfl
  intro i hi
  rw [(Polynomial.monic_X_add_C (x i)).nextCoeff_pow]
  simp [Polynomial.nextCoeff_X_add_C, nsmul_eq_mul]

theorem eval_one_first_monomial (g : Fin n →₀ ℕ) (c : ℝ) (i : Fin n) :
    MvPolynomial.eval (fun _ => 1) (pderiv i (MvPolynomial.monomial g c)) = c * (g i : ℝ) := by
  simp [pderiv_monomial, MvPolynomial.eval_monomial, Finsupp.prod]

theorem eval_one_first_as_sum (p : MvPolynomial (Fin n) ℝ) (i : Fin n) :
    MvPolynomial.eval (fun _ => 1) (pderiv i p) = ∑ g ∈ p.support, p.coeff g * (g i : ℝ) := by
  conv_lhs => rw [p.as_sum]
  simp only [map_sum, eval_one_first_monomial]

theorem lineRestriction_next_coefficient (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ)
    (N : ℕ) (hN : 0 < N) (hp : p.IsHomogeneous N) :
    (lineRestriction p x).coeff (N-1) =
      ∑ i, MvPolynomial.eval (fun _ => 1) (pderiv i p) * x i := by
  rw [lineRestriction_as_sum, Polynomial.finsetSum_coeff]
  simp only [Polynomial.coeff_C_mul]
  have hc (g : Fin n →₀ ℕ) (hg : g ∈ p.support) :
      (monomialLine g x).coeff (N-1) = ∑ i, (g i : ℝ)*x i := by
    have hd : (monomialLine g x).natDegree = N := by
      rw [monomialLine_natDegree, homogeneous_mass p N hp g hg]
    rw [← hd, ← Polynomial.nextCoeff_of_natDegree_pos (by omega), monomialLine_nextCoeff]
  calc
    (∑ g ∈ p.support, p.coeff g * (monomialLine g x).coeff (N-1)) =
        ∑ g ∈ p.support, p.coeff g * (∑ i, (g i : ℝ)*x i) := by
      apply Finset.sum_congr rfl
      intro g hg
      rw [hc g hg]
    _ = ∑ i, (∑ g ∈ p.support, p.coeff g * (g i : ℝ)) * x i := by
      simp_rw [Finset.mul_sum]
      rw [Finset.sum_comm]
      simp_rw [Finset.sum_mul, mul_assoc]
    _ = ∑ i, MvPolynomial.eval (fun _ => 1) (pderiv i p) * x i := by
      simp only [eval_one_first_as_sum]

theorem normalized_stable_line_real_factors_sum
    (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ) (N : ℕ) (hN : 0 < N)
    (hp : p.IsHomogeneous N) (hnorm : MvPolynomial.eval (fun _ => 1) p = 1)
    (hstable : UpperHalfPlaneZeroFree p) :
    ∃ roots : Multiset ℝ, roots.card = N ∧
      lineRestriction p x = (roots.map (fun r => Polynomial.X + Polynomial.C r)).prod ∧
      roots.sum = ∑ i, MvPolynomial.eval (fun _ => 1) (pderiv i p) * x i := by
  obtain ⟨roots,hcard,hr⟩ := normalized_stable_line_real_factors p x N hp hnorm hstable
  refine ⟨roots,hcard,hr,?_⟩
  have he : (lineRestriction p x).nextCoeff = roots.sum := by
    rw [hr, Polynomial.Monic.nextCoeff_multiset_prod _ _ (fun r _ => Polynomial.monic_X_add_C r)]
    simp [Polynomial.nextCoeff_X_add_C]
  have hd := normalized_lineRestriction_natDegree p x N hp hnorm
  have hpos : 0 < (lineRestriction p x).natDegree := by omega
  rw [← he, Polynomial.nextCoeff_of_natDegree_pos hpos, hd,
    lineRestriction_next_coefficient p x N hN hp]

def centeredRoots (roots : Multiset ℝ) : Multiset ℝ :=
  roots.map (fun r => r - roots.sum / roots.card)

theorem centeredRoots_card (roots : Multiset ℝ) : (centeredRoots roots).card = roots.card := by
  simp [centeredRoots]

theorem sum_map_sub_constant (s : Multiset ℝ) (a : ℝ) :
    (s.map (fun r => r-a)).sum = s.sum - s.card*a := by
  induction s using Multiset.induction_on with
  | empty => simp
  | @cons r s ih =>
    simp only [Multiset.map_cons, Multiset.sum_cons, Multiset.card_cons, Nat.cast_add,
      Nat.cast_one, ih]
    ring

theorem centeredRoots_sum (roots : Multiset ℝ) (h : 0 < roots.card) :
    (centeredRoots roots).sum = 0 := by
  rw [centeredRoots, sum_map_sub_constant]
  have hn : (roots.card : ℝ) ≠ 0 := by exact_mod_cast Nat.ne_zero_of_lt h
  field_simp
  ring

end CoefficientStability
