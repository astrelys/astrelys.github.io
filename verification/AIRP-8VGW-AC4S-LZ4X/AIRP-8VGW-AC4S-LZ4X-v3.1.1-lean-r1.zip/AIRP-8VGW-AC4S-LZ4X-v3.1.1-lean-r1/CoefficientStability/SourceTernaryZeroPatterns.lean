import CoefficientStability.SourceOneZeroMinimum

noncomputable section
namespace CoefficientStability
set_option maxHeartbeats 4000000
set_option maxRecDepth 20000

def sourceTernaryCanonicalZeroPattern (Z : Fin 3 → Fin 3 → Bool) : Prop :=
  (∀ i j,Z i j=false) ∨
  (∀ i j,Z i j=decide (i=0 ∧ j=0)) ∨
  (∀ i j,Z i j=decide ((i=0 ∧ j=0) ∨ (i=1 ∧ j=1))) ∨
  (∀ i j,Z i j=decide (i=j)) ∨
  (Z 0 0=true ∧ Z 0 1=true) ∨ (Z 0 0=true ∧ Z 1 0=true)

instance sourceTernaryCanonicalZeroPatternDecidable (Z : Fin 3 → Fin 3 → Bool) :
    Decidable (sourceTernaryCanonicalZeroPattern Z) := by
  unfold sourceTernaryCanonicalZeroPattern
  infer_instance

theorem source_ternary_zero_pattern_exhaustion :
    ∀ Z : Fin 3 → Fin 3 → Bool,∃ r c : Equiv.Perm (Fin 3),
      sourceTernaryCanonicalZeroPattern (fun i j => Z (r i) (c j)) := by decide

end CoefficientStability
