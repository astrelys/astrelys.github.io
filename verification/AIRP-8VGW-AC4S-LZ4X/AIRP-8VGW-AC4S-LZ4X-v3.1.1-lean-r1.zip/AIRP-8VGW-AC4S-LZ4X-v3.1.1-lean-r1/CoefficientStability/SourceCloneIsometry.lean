import CoefficientStability.RectangularCoefficientNorm

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {m : ℕ}

def sourceCloneRecoveryMatrix (α : Fin m → ℕ) : Matrix (Fin (sourceCloneCount α)) (Fin m) ℝ :=
  fun j i => if sourceCloneBlock α j=i then 1 else 0

theorem sourceCloneRecoveryMatrix_nonnegative (α : Fin m → ℕ) :
    ∀ j i,0 ≤ sourceCloneRecoveryMatrix α j i := by
  intro j i
  unfold sourceCloneRecoveryMatrix
  split_ifs <;> norm_num

theorem sourceCloneRecoveryMatrix_row (α : Fin m → ℕ) (j : Fin (sourceCloneCount α)) :
    (∑ i,sourceCloneRecoveryMatrix α j i)=1 := by
  simp [sourceCloneRecoveryMatrix]

theorem sourceCloneRecoveryMatrix_mulVec (α : Fin m → ℕ) (x : Fin m → ℝ) :
    (sourceCloneRecoveryMatrix α).mulVec x=(fun j => x (sourceCloneBlock α j)) := by
  funext j
  simp [sourceCloneRecoveryMatrix,Matrix.mulVec,dotProduct,ite_mul]

theorem sourceClonePolynomial_ring_recovery (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (p : MvPolynomial (Fin m) ℝ) :
    rectangularSubstitution (sourceCloneRecoveryMatrix α) (sourceClonePolynomial α p)=p := by
  apply MvPolynomial.funext
  intro x
  rw [rectangularSubstitution_eval,sourceCloneRecoveryMatrix_mulVec,sourceClonePolynomial_eval_recovery α hα]

theorem sourceClonePolynomial_coefficient_isometry (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (p : MvPolynomial (Fin m) ℝ) :
    coefficientL1 (sourceClonePolynomial α p)=coefficientL1 p := by
  have hf := rectangularSubstitution_coefficientL1_le (sourceCloneAveragingMatrix α)
    (sourceCloneAveragingMatrix_nonnegative α) (sourceCloneAveragingMatrix_row α hα) p
  have hb := rectangularSubstitution_coefficientL1_le (sourceCloneRecoveryMatrix α)
    (sourceCloneRecoveryMatrix_nonnegative α) (sourceCloneRecoveryMatrix_row α) (sourceClonePolynomial α p)
  rw [sourceClonePolynomial_ring_recovery α hα p] at hb
  exact le_antisymm hf hb

theorem sourceClonePolynomial_distance_isometry (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (p q : MvPolynomial (Fin m) ℝ) :
    coefficientL1 (sourceClonePolynomial α p-sourceClonePolynomial α q)=coefficientL1 (p-q) := by
  have he : sourceClonePolynomial α p-sourceClonePolynomial α q=sourceClonePolynomial α (p-q) := by
    simp only [sourceClonePolynomial,map_sub]
  rw [he,sourceClonePolynomial_coefficient_isometry α hα]

theorem sourceClonePolynomial_total_variation_isometry (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (p q : MvPolynomial (Fin m) ℝ) :
    finiteExponentTotalVariation (sourceClonePolynomial α p) (sourceClonePolynomial α q)=finiteExponentTotalVariation p q := by
  simp only [finiteExponentTotalVariation_eq_half_coefficientL1,sourceClonePolynomial_distance_isometry α hα]

end CoefficientStability
