import CoefficientStability.SourceMultiindexLinearStability

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {m : ℕ}

theorem sourceClonedGradient_sum (α : Fin m → ℕ) (hα : ∀ i,0 < α i) (t : Fin m → ℝ) :
    (∑ j,sourceClonedGradient α t j)=∑ i,t i := by
  rw [← Equiv.sum_comp (sourceCloneEquiv α) (sourceClonedGradient α t)]
  simp only [Fintype.sum_sigma,sourceClonedGradient,sourceCloneBlock_equiv,Finset.sum_const,
    Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
  apply Finset.sum_congr rfl
  intro i hi
  have hne : (α i : ℝ)≠0 := by exact_mod_cast (ne_of_gt (hα i))
  field_simp

theorem sourceClonedGradient_pos (α : Fin m → ℕ) (hα : ∀ i,0 < α i) (t : Fin m → ℝ)
    (htpos : ∀ i,0 < t i) (j : Fin (sourceCloneCount α)) : 0 < sourceClonedGradient α t j :=
  div_pos (htpos _) (by exact_mod_cast hα _)

theorem sourceWeightedDeficit_nonnegative (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (hN : 2 ≤ sourceCloneCount α) (p : MvPolynomial (Fin m) ℝ)
    (hp : p.IsHomogeneous (sourceCloneCount α)) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (t : Fin m → ℝ)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) :
    0 ≤ sourceWeightedDeficit α p t := by
  obtain ⟨hph,hps,hpn,hpc,hpg⟩ := sourceClonePolynomial_source_hypotheses α hα p hp hs hnorm t hgrad
  have h := referenceDeficit_nonneg (sourceClonePolynomial α p) (sourceClonedGradient α t)
    (sourceCloneCount α) hN hph hpn hps hpg
  rwa [sourceClonePolynomial_weighted_variance α hα p t hgrad] at h

theorem sourceWeightedDeficit_zero_iff (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (hN : 2 ≤ sourceCloneCount α) (p : MvPolynomial (Fin m) ℝ)
    (hp : p.IsHomogeneous (sourceCloneCount α)) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) (t : Fin m → ℝ)
    (ht : (∑ i,t i)=sourceCloneCount α)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) :
    sourceWeightedDeficit α p t=0 ↔ p=scalarPower t (sourceCloneCount α) := by
  obtain ⟨hph,hps,hpn,hpc,hpg⟩ := sourceClonePolynomial_source_hypotheses α hα p hp hs hnorm t hgrad
  have htotal : (∑ j,sourceClonedGradient α t j)=sourceCloneCount α := (sourceClonedGradient_sum α hα t).trans ht
  have h := referenceDeficit_zero_iff_scalarPower (sourceClonePolynomial α p) (sourceClonedGradient α t)
    (sourceCloneCount α) hN hph hpn hps htotal hpg
  rw [sourceClonePolynomial_weighted_variance α hα p t hgrad] at h
  constructor
  · intro hz
    have he := h.mp hz
    rw [← sourceClonePolynomial_scalarPower] at he
    exact sourceClonePolynomial_injective α hα he
  · intro he
    apply h.mpr
    rw [he,sourceClonePolynomial_scalarPower]

theorem source_weighted_local_variance_growth (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (hN : 2 ≤ sourceCloneCount α) (t : Fin m → ℝ)
    (ht : (∑ i,t i)=sourceCloneCount α) (htpos : ∀ i,0 < t i)
    (hradius : (∑ i,(t i-(α i : ℝ))^2/(α i : ℝ)) <
      (sourceCloneCount α : ℝ)/((sourceCloneCount α : ℝ)-1)) :
    ∃ κ e : ℝ,0 < κ ∧ 0 < e ∧ ∀ p : MvPolynomial (Fin m) ℝ,
      p.IsHomogeneous (sourceCloneCount α) → MvPolynomial.eval (fun _ => 1) p=1 → UpperHalfPlaneZeroFree p →
      (∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=t i) →
      coefficientL1 (p-scalarPower t (sourceCloneCount α)) < e →
      κ*sourceWeightedDeficit α p t ≤ p.coeff (sourceMultiExponent α)-sourceMultiIndexBaseline α t ∧
      (p≠scalarPower t (sourceCloneCount α) → sourceMultiIndexBaseline α t < p.coeff (sourceMultiExponent α)) := by
  have htotal := (sourceClonedGradient_sum α hα t).trans ht
  have hpos := sourceClonedGradient_pos α hα t htpos
  have hrad : (∑ j,(sourceClonedGradient α t j-1)^2) <
      (sourceCloneCount α : ℝ)/((sourceCloneCount α : ℝ)-1) := by
    simpa only [sourceClonedGradient,sourceCloneGradient_square_sum α hα t] using hradius
  obtain ⟨a,e,ha,he,hgrowth⟩ := paper_stable_local_variance_growth (sourceClonedGradient α t) hN htotal hpos hrad
  have hK := sourceCloneCoefficientWeight_pos α hα
  refine ⟨a/sourceCloneCoefficientWeight α,e,div_pos ha hK,he,?_⟩
  intro p hp hnorm hs hgrad hnear
  obtain ⟨hph,hps,hpn,hpc,hpg⟩ := sourceClonePolynomial_source_hypotheses α hα p hp hs hnorm t hgrad
  have hcnear : coefficientL1 (sourceClonePolynomial α p-scalarPower (sourceClonedGradient α t) (sourceCloneCount α)) < e := by
    rw [← sourceClonePolynomial_scalarPower,sourceClonePolynomial_distance_isometry α hα]
    exact hnear
  have hg := hgrowth (sourceClonePolynomial α p) hph hpn hps hpg hcnear
  have href : ((sourceCloneCount α).factorial : ℝ)/(sourceCloneCount α : ℝ)^(sourceCloneCount α)*
      (∏ j,sourceClonedGradient α t j)=sourceCloneCoefficientWeight α*sourceMultiIndexBaseline α t := by
    change sourceVn (sourceCloneCount α)*(∏ j,sourceClonedGradient α t j)=_
    rw [← sourceCloneReference_coefficient_identity,sourceScalarPower_multiindex_baseline]
    rfl
  rw [sourceClonePolynomial_weighted_variance α hα p t hgrad,sourceClonePolynomial_squarefree_coefficient,href] at hg
  refine ⟨?_,?_⟩
  · have h := hg.1
    rw [← mul_sub] at h
    calc
      _ = (a*sourceWeightedDeficit α p t)/sourceCloneCoefficientWeight α := by ring
      _ ≤ _ := (div_le_iff₀ hK).mpr (by simpa only [mul_comm] using h)
  · intro hne
    have hcloneNe : sourceClonePolynomial α p≠scalarPower (sourceClonedGradient α t) (sourceCloneCount α) := by
      intro hh
      rw [← sourceClonePolynomial_scalarPower] at hh
      exact hne (sourceClonePolynomial_injective α hα hh)
    have hlt := hg.2 hcloneNe
    by_contra hh
    have hle := mul_le_mul_of_nonneg_left (le_of_not_gt hh) hK.le
    linarith

end CoefficientStability
