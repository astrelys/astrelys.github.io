import CoefficientStability.PositiveCapacityLoss

noncomputable section
open scoped BigOperators
open Polynomial
namespace CoefficientStability
variable {n : ℕ}

def positiveCapacityPolynomial (c : ℝ) (b : Fin n → ℝ) : ℝ[X] :=
  Polynomial.C c*∏ i,(1+Polynomial.C (b i)*Polynomial.X)

def positiveDomainCapacity (f : ℝ[X]) : ℝ :=
  sInf (Set.range (fun z : {z : ℝ // 0<z} => f.eval (z : ℝ)/(z : ℝ)))

theorem positiveCapacityPolynomial_eval (c : ℝ) (b : Fin n → ℝ) (z : ℝ) :
    (positiveCapacityPolynomial c b).eval z=c*∏ i,(1+b i*z) := by
  simp [positiveCapacityPolynomial,Polynomial.eval_prod]

theorem positiveCapacityPolynomial_derivative_zero (c : ℝ) (b : Fin n → ℝ) :
    (positiveCapacityPolynomial c b).derivative.eval 0=c*(∑ i,b i) := by
  have hf (i : Fin n) : HasDerivAt (fun z : ℝ => 1+b i*z) (b i) 0 := by
    simpa only [mul_one,id_eq] using ((hasDerivAt_id (0 : ℝ)).const_mul (b i)).const_add 1
  have h := (HasDerivAt.fun_finsetProd (u := Finset.univ) (fun i hi => hf i)).const_mul c
  have h' : HasDerivAt (fun z : ℝ => (positiveCapacityPolynomial c b).eval z) (c*∑ i,b i) 0 := by
    simpa only [positiveCapacityPolynomial_eval,mul_zero,add_zero,Finset.prod_const_one,one_mul,one_smul] using h
  exact ((positiveCapacityPolynomial c b).hasDerivAt 0).unique h'

theorem positiveDomainCapacity_at_minimum (f : ℝ[X]) (zstar : ℝ) (hz : 0<zstar)
    (hmin : ∀ z : ℝ,0<z → f.eval zstar/zstar≤f.eval (z : ℝ)/(z : ℝ)) :
    positiveDomainCapacity f=f.eval zstar/zstar := by
  let S := Set.range (fun z : {z : ℝ // 0<z} => f.eval (z : ℝ)/(z : ℝ))
  have hne : S.Nonempty := ⟨f.eval zstar/zstar,⟨⟨zstar,hz⟩,rfl⟩⟩
  have hlower : ∀ x∈S,f.eval zstar/zstar≤x := by
    intro x hx
    obtain ⟨z,rfl⟩ := hx
    exact hmin z z.property
  have hbb : BddBelow S := ⟨f.eval zstar/zstar,hlower⟩
  exact le_antisymm (csInf_le hbb ⟨⟨zstar,hz⟩,rfl⟩) (le_csInf hne hlower)

theorem positive_prefactor_univariate_loss (c : ℝ) (b : Fin n → ℝ) (zstar : ℝ)
    (hn : 2≤n) (hc : 0<c) (hb : ∀ i,0<b i) (hz : 0<zstar)
    (hmin : ∀ z : ℝ,0<z → (positiveCapacityPolynomial c b).eval zstar/zstar≤
      (positiveCapacityPolynomial c b).eval z/z) :
    (∑ i,b i*zstar/(1+b i*zstar))=1 ∧
      (positiveCapacityPolynomial c b).derivative.eval 0/positiveDomainCapacity (positiveCapacityPolynomial c b)≥
      capacityG n*(1+((∑ i,(b i*zstar/(1+b i*zstar))^2)-1/(n : ℝ))/128) := by
  have hmin' : ∀ z : ℝ,0<z → (c*∏ i,(1+b i*zstar))/zstar≤(c*∏ i,(1+b i*z))/z := by
    simpa only [positiveCapacityPolynomial_eval] using hmin
  refine ⟨positive_capacity_minimizer_stationarity c b zstar hc hb hz hmin',?_⟩
  rw [positiveCapacityPolynomial_derivative_zero,positiveDomainCapacity_at_minimum _ zstar hz hmin,
    positiveCapacityPolynomial_eval]
  exact positive_capacity_loss c b zstar hn hc hb hz hmin'

theorem positive_prefactor_univariate_loss_general (f : ℝ[X]) (b : Fin n → ℝ) (zstar : ℝ)
    (hn : 2≤n) (hc : 0<f.eval 0) (hb : ∀ i,0<b i) (hz : 0<zstar)
    (hfactor : ∀ z : ℝ,f.eval z=f.eval 0*∏ i,(1+b i*z))
    (hmin : ∀ z : ℝ,0<z → f.eval zstar/zstar≤f.eval z/z) :
    (∑ i,b i*zstar/(1+b i*zstar))=1 ∧
      f.derivative.eval 0/positiveDomainCapacity f≥
        capacityG n*(1+((∑ i,(b i*zstar/(1+b i*zstar))^2)-1/(n : ℝ))/128) := by
  have he : f=positiveCapacityPolynomial (f.eval 0) b := by
    apply Polynomial.funext
    intro z
    rw [positiveCapacityPolynomial_eval]
    exact hfactor z
  have hmin' : ∀ z : ℝ,0<z → (positiveCapacityPolynomial (f.eval 0) b).eval zstar/zstar≤
      (positiveCapacityPolynomial (f.eval 0) b).eval z/z := by rw [← he];exact hmin
  have h := positive_prefactor_univariate_loss (f.eval 0) b zstar hn hc hb hz hmin'
  rw [← he] at h
  exact h

end CoefficientStability
