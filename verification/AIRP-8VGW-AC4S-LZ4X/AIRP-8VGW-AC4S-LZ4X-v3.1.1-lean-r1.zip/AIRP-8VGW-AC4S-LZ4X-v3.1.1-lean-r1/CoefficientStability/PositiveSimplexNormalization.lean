import CoefficientStability.SimplexSublevelBox
import CoefficientStability.PolynomialLinearSubstitution

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem homogeneous_capacity_ratio_scale (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (a : ℝ) (ha : 0<a) (x : Fin n → ℝ) :
    MvPolynomial.eval (fun i => a*x i) p/(∏ i,a*x i)=MvPolynomial.eval x p/(∏ i,x i) := by
  rw [homogeneous_eval_real_scale p n hp,Finset.prod_mul_distrib]
  simp only [Finset.prod_const,Finset.card_univ,Fintype.card_fin]
  exact mul_div_mul_left _ _ (ne_of_gt (pow_pos ha n))

theorem exists_positive_simplex_normalization (hn : 0<n) (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (y : Fin n → ℝ) (hy : ∀ i,0<y i) :
    ∃ x : Fin n → ℝ,(∀ i,0<x i) ∧ (∑ i,x i=(n : ℝ)) ∧
      MvPolynomial.eval x p/(∏ i,x i)=MvPolynomial.eval y p/(∏ i,y i) := by
  have hs : 0<∑ i,y i := by
    apply Finset.sum_pos
    · intro i hi; exact hy i
    · exact ⟨⟨0,hn⟩,Finset.mem_univ _⟩
  have hnr : (0 : ℝ)<n := by exact_mod_cast hn
  let a : ℝ :=(n : ℝ)/(∑ i,y i)
  have ha : 0<a := div_pos hnr hs
  refine ⟨fun i => a*y i,fun i => mul_pos ha (hy i),?_,homogeneous_capacity_ratio_scale p hp a ha y⟩
  rw [← Finset.mul_sum]
  exact div_mul_cancel₀ _ (ne_of_gt hs)

end CoefficientStability
