import CoefficientStability.SourceMultiindexGlobalVariance

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {m : ℕ}

theorem sourceCloneRecovery_block_gradient (α : Fin m → ℕ) (w : Fin m → ℝ) (i : Fin m) :
    rectangularSourceGradient (sourceCloneRecoveryMatrix α) (fun j => w (sourceCloneBlock α j)) i=
      (α i : ℝ)*w i := by
  classical
  unfold rectangularSourceGradient
  rw [← Equiv.sum_comp (sourceCloneEquiv α) (fun j => sourceCloneRecoveryMatrix α j i*w (sourceCloneBlock α j))]
  simp only [Fintype.sum_sigma,sourceCloneRecoveryMatrix,sourceCloneBlock_equiv,ite_mul,one_mul,zero_mul]
  simp

theorem sourceCloneRecovery_original_gradient (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (t : Fin m → ℝ) (i : Fin m) :
    rectangularSourceGradient (sourceCloneRecoveryMatrix α) (sourceClonedGradient α t) i=t i := by
  change rectangularSourceGradient (sourceCloneRecoveryMatrix α)
    (fun j => (fun i => t i/(α i : ℝ)) (sourceCloneBlock α j)) i=t i
  rw [sourceCloneRecovery_block_gradient α (fun i => t i/(α i : ℝ)) i]
  have hne : (α i : ℝ)≠0 := by exact_mod_cast (ne_of_gt (hα i))
  field_simp

theorem sourceClone_block_projection (α : Fin m → ℕ) (hα : ∀ i,0 < α i) (w : Fin m → ℝ) :
    rectangularSourceGradient (sourceCloneAveragingMatrix α)
      (rectangularSourceGradient (sourceCloneRecoveryMatrix α) (fun j => w (sourceCloneBlock α j)))=
      (fun j => w (sourceCloneBlock α j)) := by
  have he : rectangularSourceGradient (sourceCloneRecoveryMatrix α) (fun j => w (sourceCloneBlock α j))=
      (fun i => (α i : ℝ)*w i) := funext (sourceCloneRecovery_block_gradient α w)
  rw [he]
  funext j
  change (∑ i,sourceCloneAveragingMatrix α i j*((α i : ℝ)*w i))=w (sourceCloneBlock α j)
  rw [sourceCloneAveragingMatrix_gradient_column]
  have hne : (α (sourceCloneBlock α j) : ℝ)≠0 := by exact_mod_cast (ne_of_gt (hα _))
  field_simp

theorem sourceClone_fixed_block_linear (α : Fin m → ℕ) (hα : ∀ i,0 < α i) (w : Fin m → ℝ) :
    sourceClonePolynomial α (rectangularSubstitution (sourceCloneRecoveryMatrix α)
      (scalarLinear (fun j => w (sourceCloneBlock α j)) 1))=
      scalarLinear (fun j => w (sourceCloneBlock α j)) 1 := by
  rw [sourceClonePolynomial,rectangularSubstitution_scalarLinear,rectangularSubstitution_scalarLinear,
    sourceClone_block_projection α hα w]

theorem sourceClone_fixed_block_diagonal (α : Fin m → ℕ) (hα : ∀ i,0 < α i)
    (M : Fin (sourceCloneCount α) → Fin (sourceCloneCount α) → ℝ)
    (w : Fin (sourceCloneCount α) → Fin m → ℝ)
    (hM : ∀ r j,M r j=w r (sourceCloneBlock α j)) :
    sourceClonePolynomial α (rectangularSubstitution (sourceCloneRecoveryMatrix α) (diagonalPencilPolynomial M))=
      diagonalPencilPolynomial M := by
  change rectangularSubstitution (sourceCloneAveragingMatrix α)
    (rectangularSubstitution (sourceCloneRecoveryMatrix α) (diagonalPencilPolynomial M))=diagonalPencilPolynomial M
  rw [diagonalPencilPolynomial_eq_product,map_prod,map_prod]
  apply Finset.prod_congr rfl
  intro r hr
  have he : rowLinearPolynomial M r=scalarLinear (fun j => w r (sourceCloneBlock α j)) 1 := by
    simp only [rowLinearPolynomial,scalarLinear,Nat.cast_one,div_one,hM]
  simpa only [sourceClonePolynomial,scalarLinear,Nat.cast_one,div_one,hM] using
    sourceClone_fixed_block_linear α hα (w r)

def sourceBoundaryBlockWeight (α : Fin m → ℕ) (t : Fin m → ℝ) (s : ℝ)
    (r : Fin (sourceCloneCount α)) (i : Fin m) : ℝ :=
  (t i/(α i : ℝ))/(sourceCloneCount α : ℝ)+
    s*((t i/(α i : ℝ))*(1-((sourceCloneCount α : ℝ)/marginalNormSq (sourceClonedGradient α t))*(t i/(α i : ℝ))))*
      boundaryModelDiagonal (sourceCloneCount α) r

theorem sourceBoundaryMatrix_block_constant (α : Fin m → ℕ) (t : Fin m → ℝ) (s : ℝ)
    (r j : Fin (sourceCloneCount α)) :
    boundaryCoefficientMatrix (sourceClonedGradient α t) s r j=
      sourceBoundaryBlockWeight α t s r (sourceCloneBlock α j) := rfl

end CoefficientStability
