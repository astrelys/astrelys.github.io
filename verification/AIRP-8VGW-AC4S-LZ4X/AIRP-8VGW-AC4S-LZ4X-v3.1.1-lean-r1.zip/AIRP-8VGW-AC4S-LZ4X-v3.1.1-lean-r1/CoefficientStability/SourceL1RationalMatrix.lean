import CoefficientStability.SourceL1RationalParameters

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000

def sourceL1RationalMatrixRat (η : ℚ) : Matrix (Fin 3) (Fin 3) ℚ :=
  let d : ℚ := 1/(η^2-3)
  let s : ℚ := η/(η^2-3)
  ![![0,(1+s+d)/2,(1-d)*(1+2*s)/2],
    ![(1-s+d)/2,0,(1-d)*(1-2*s)/2],
    ![(1+s-d)/2,(1-s-d)/2,d]]

def sourceL1RationalTracesRat (η : ℚ) : Fin 3 → ℚ := fun i => ∑ j,sourceL1RationalMatrixRat η i j

theorem source_l1_rational_matrix_actual_original (η : ℚ) (hη : 3<(η : ℝ)) :
    (fun i j => (sourceL1RationalMatrixRat η i j : ℝ))=
      sourceL1BoundaryMatrix (sourceL1RationalD (η : ℝ)) := by
  unfold sourceL1BoundaryMatrix
  rw [source_l1_rational_parameter_actual_sqrt (η : ℝ) hη]
  apply Matrix.ext
  intro i j
  fin_cases i <;> fin_cases j
  · change ((0 : ℚ) : ℝ)=0
    norm_num
  · change (((1+(η/(η^2-3) : ℚ)+(1/(η^2-3) : ℚ))/2 : ℚ) : ℝ)=(1+sourceL1RationalS (η : ℝ)+sourceL1RationalD (η : ℝ))/2
    simp only [sourceL1RationalD,sourceL1RationalS]
    push_cast <;> rfl
  · change (((1-(1/(η^2-3) : ℚ))*(1+2*(η/(η^2-3) : ℚ))/2 : ℚ) : ℝ)=(1-sourceL1RationalD (η : ℝ))*(1+2*sourceL1RationalS (η : ℝ))/2
    simp only [sourceL1RationalD,sourceL1RationalS]
    push_cast <;> rfl
  · change (((1-(η/(η^2-3) : ℚ)+(1/(η^2-3) : ℚ))/2 : ℚ) : ℝ)=(1-sourceL1RationalS (η : ℝ)+sourceL1RationalD (η : ℝ))/2
    simp only [sourceL1RationalD,sourceL1RationalS]
    push_cast <;> rfl
  · change ((0 : ℚ) : ℝ)=0
    norm_num
  · change (((1-(1/(η^2-3) : ℚ))*(1-2*(η/(η^2-3) : ℚ))/2 : ℚ) : ℝ)=(1-sourceL1RationalD (η : ℝ))*(1-2*sourceL1RationalS (η : ℝ))/2
    simp only [sourceL1RationalD,sourceL1RationalS]
    push_cast <;> rfl
  · change (((1+(η/(η^2-3) : ℚ)-(1/(η^2-3) : ℚ))/2 : ℚ) : ℝ)=(1+sourceL1RationalS (η : ℝ)-sourceL1RationalD (η : ℝ))/2
    simp only [sourceL1RationalD,sourceL1RationalS]
    push_cast <;> rfl
  · change (((1-(η/(η^2-3) : ℚ)-(1/(η^2-3) : ℚ))/2 : ℚ) : ℝ)=(1-sourceL1RationalS (η : ℝ)-sourceL1RationalD (η : ℝ))/2
    simp only [sourceL1RationalD,sourceL1RationalS]
    push_cast <;> rfl
  · change (((1/(η^2-3) : ℚ) : ℚ) : ℝ)=sourceL1RationalD (η : ℝ)
    simp only [sourceL1RationalD,sourceL1RationalS]
    push_cast <;> rfl

theorem source_l1_rational_trace_actual_original (η : ℚ) (hη : 3<(η : ℝ))
    (hd8 : sourceL1RationalD (η : ℝ)<1/8) :
    (fun i => (sourceL1RationalTracesRat η i : ℝ))=sourceL1BoundaryTraces (sourceL1RationalD (η : ℝ)) := by
  have hd : 0<sourceL1RationalD (η : ℝ) := by
    unfold sourceL1RationalD
    apply one_div_pos.mpr
    nlinarith
  have hf := (source_l1_boundary_family_feasible _ hd hd8).1
  funext i
  rw [← hf.2.1 i]
  change ((∑ j,sourceL1RationalMatrixRat η i j : ℚ) : ℝ)=_
  push_cast
  have he := source_l1_rational_matrix_actual_original η hη
  exact Finset.sum_congr rfl (fun j hj => congrFun (congrFun he i) j)

end CoefficientStability
