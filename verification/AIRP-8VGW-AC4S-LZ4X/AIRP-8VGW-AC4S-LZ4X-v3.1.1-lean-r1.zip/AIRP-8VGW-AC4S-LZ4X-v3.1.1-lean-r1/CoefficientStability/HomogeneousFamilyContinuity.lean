import CoefficientStability.TernaryHomogeneousPlane
import CoefficientStability.RootPolynomialMap
import Mathlib.Data.Finsupp.Weight

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem mv_polynomial_family_mul_coeff_continuous {α : Type*} [TopologicalSpace α]
    (P Q : α → MvPolynomial (Fin n) ℝ)
    (hP : ∀ g,Continuous (fun a => (P a).coeff g)) (hQ : ∀ g,Continuous (fun a => (Q a).coeff g))
    (g : Fin n →₀ ℕ) : Continuous (fun a => (P a*Q a).coeff g) := by
  classical
  simp only [MvPolynomial.coeff_mul]
  apply continuous_finsetSum
  intro ij hij
  convert! (hP ij.1).mul (hQ ij.2) using 1

theorem mv_polynomial_family_C_coeff_continuous {α : Type*} [TopologicalSpace α]
    (c : α → ℝ) (hc : Continuous c) (g : Fin n →₀ ℕ) :
    Continuous (fun a => (MvPolynomial.C (c a) : MvPolynomial (Fin n) ℝ).coeff g) := by
  classical
  by_cases hg : g=0
  · subst g
    simpa [MvPolynomial.coeff_C] using hc
  · simpa [MvPolynomial.coeff_C,Ne.symm hg] using
      (continuous_const : Continuous (fun _ : α => (0 : ℝ)))

theorem mv_polynomial_family_partial_coeff_continuous {α : Type*} [TopologicalSpace α]
    (P : α → MvPolynomial (Fin n) ℝ) (hP : ∀ g,Continuous (fun a => (P a).coeff g))
    (i : Fin n) (g : Fin n →₀ ℕ) : Continuous (fun a => (pderiv i (P a)).coeff g) := by
  simp only [MvPolynomial.coeff_pderiv]
  convert! (hP (g+Finsupp.single i 1)).mul_const ((g i : ℝ)+1) using 1

theorem homogeneousNuij_iterate_coefficient_continuous (q : MvPolynomial (Fin 3) ℝ) (k : ℕ) :
    ∀ g,Continuous (fun ε : ℝ => ((homogeneousNuijStep ε)^[k] q).coeff g) := by
  induction k with
  | zero =>
    intro g
    change Continuous (fun _ : ℝ => q.coeff g)
    exact continuous_const
  | succ k ih =>
    let P : ℝ → MvPolynomial (Fin 3) ℝ := fun ε => (homogeneousNuijStep ε)^[k] q
    have hD := mv_polynomial_family_partial_coeff_continuous (α := ℝ) P ih (0 : Fin 3)
    have hDX := mv_polynomial_family_mul_coeff_continuous (fun ε => pderiv (0 : Fin 3) (P ε))
      (fun _ : ℝ => MvPolynomial.X (2 : Fin 3)) hD (fun g => continuous_const)
    have hC := mv_polynomial_family_C_coeff_continuous (n := 3) (fun ε : ℝ => ε) continuous_id
    have hterm := mv_polynomial_family_mul_coeff_continuous
      (fun ε : ℝ => MvPolynomial.C ε) (fun ε => pderiv (0 : Fin 3) (P ε)*MvPolynomial.X (2 : Fin 3)) hC hDX
    intro g
    have heq : (fun ε : ℝ => ((homogeneousNuijStep ε)^[k+1] q).coeff g)=
        (fun ε => (P ε).coeff g+(MvPolynomial.C ε*(pderiv (0 : Fin 3) (P ε)*MvPolynomial.X (2 : Fin 3))).coeff g) := by
      funext ε
      simp only [Function.iterate_succ_apply',homogeneousNuijStep,MvPolynomial.coeff_add,P]
    rw [heq]
    convert! (ih g).add (hterm g) using 1

def homogeneousExponentSupport (n N : ℕ) : Finset (Fin n →₀ ℕ) := (Finsupp.finite_of_degree_eq N).toFinset

theorem general_homogeneous_support_subset (p : MvPolynomial (Fin n) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) : p.support⊆homogeneousExponentSupport n N := by
  classical
  intro g hg
  change g∈(Finsupp.finite_of_degree_eq N).toFinset
  simp only [Set.Finite.mem_toFinset,Set.mem_setOf_eq]
  by_contra hdeg
  exact (MvPolynomial.mem_support_iff.mp hg) (hp.coeff_eq_zero hdeg)

theorem homogeneous_family_restriction_coeff_continuous {α : Type*} [TopologicalSpace α]
    (P : α → MvPolynomial (Fin n) ℝ) (N : ℕ) (hhom : ∀ a,(P a).IsHomogeneous N)
    (hcoeff : ∀ g,Continuous (fun a => (P a).coeff g))
    (R : MvPolynomial (Fin n) ℝ →+* Polynomial ℝ)
    (hR : ∀ c : ℝ,R (MvPolynomial.C c)=Polynomial.C c) (k : ℕ) :
    Continuous (fun a => (R (P a)).coeff k) := by
  classical
  let S := homogeneousExponentSupport n N
  have hexpand (a : α) : P a=∑ g∈S,MvPolynomial.monomial g ((P a).coeff g) := by
    calc
      P a=∑ g∈(P a).support,MvPolynomial.monomial g ((P a).coeff g) := (P a).as_sum
      _=∑ g∈S,MvPolynomial.monomial g ((P a).coeff g) := by
        apply Finset.sum_subset (general_homogeneous_support_subset (P a) N (hhom a))
        intro g hg hnot
        have hz : (P a).coeff g=0 := by simpa only [MvPolynomial.mem_support_iff,not_not] using hnot
        simp only [hz,MvPolynomial.monomial_zero]
  have hmono (g : Fin n →₀ ℕ) (c : ℝ) :
      (R (MvPolynomial.monomial g c)).coeff k=c*(R (MvPolynomial.monomial g 1)).coeff k := by
    have heq : MvPolynomial.monomial g c=MvPolynomial.C c*MvPolynomial.monomial g 1 := by
      rw [MvPolynomial.C_mul_monomial,mul_one]
    rw [heq,map_mul,hR,Polynomial.coeff_C_mul]
  have heq : (fun a => (R (P a)).coeff k)=
      (fun a => ∑ g∈S,(P a).coeff g*(R (MvPolynomial.monomial g 1)).coeff k) := by
    funext a
    conv_lhs => rw [hexpand a]
    rw [map_sum,Polynomial.finsetSum_coeff]
    exact Finset.sum_congr rfl (fun g hg => hmono g ((P a).coeff g))
  rw [heq]
  apply continuous_finsetSum
  intro g hg
  convert! (hcoeff g).mul_const ((R (MvPolynomial.monomial g 1)).coeff k) using 1

end CoefficientStability
