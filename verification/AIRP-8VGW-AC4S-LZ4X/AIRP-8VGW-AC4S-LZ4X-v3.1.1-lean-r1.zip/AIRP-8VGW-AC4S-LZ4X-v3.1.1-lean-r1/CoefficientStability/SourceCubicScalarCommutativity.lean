import CoefficientStability.SourceRankOneScalarResolution
import CoefficientStability.SourceZeroProjectionResolution

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 2800000
set_option backward.isDefEq.respectTransparency false

theorem source_rank_one_nonzero_resolution_projectors_commute (b : Fin 3 → ℝ) (v : Fin 3 → Fin 3 → ℂ)
    (hv : ∀ i,star (v i) ⬝ᵥ v i=1) (c : ℝ) (hc : c≠0)
    (hres : (∑ i,(b i : ℂ) • sourceUnitProjection (v i))=(c : ℂ) • 1) :
    ∀ i j,sourceUnitProjection (v i)*sourceUnitProjection (v j)=sourceUnitProjection (v j)*sourceUnitProjection (v i) := by
  have hG := (source_rank_one_nonzero_scalar_resolution b v hv c hc hres).2
  have hdot (i j : Fin 3) (hij : i≠j) : star (v i) ⬝ᵥ v j=0 := by
    have h := congrFun (congrFun hG i) j
    simpa [sourceVectorColumnMatrix,Matrix.mul_apply,Matrix.star_eq_conjTranspose,Matrix.conjTranspose_apply,Matrix.one_apply,hij,dotProduct] using h
  intro i j
  by_cases hij : i=j
  · subst j
    rfl
  · simp [sourceUnitProjection,Matrix.vecMulVec_mul_vecMulVec,hdot i j hij,hdot j i (Ne.symm hij)]

theorem source_scalar_identity_commutes (a : ℂ) (X : Matrix (Fin 3) (Fin 3) ℂ) :
    (a • (1 : Matrix (Fin 3) (Fin 3) ℂ))*X=X*(a • 1) := by
  simp [smul_mul_assoc,mul_smul_comm]

theorem source_scalar_plus_commuting_matrices (a b c d : ℂ) (P Q : Matrix (Fin 3) (Fin 3) ℂ)
    (hPQ : P*Q=Q*P) :
    (a • 1+b • P)*(c • 1+d • Q)=(c • 1+d • Q)*(a • 1+b • P) := by
  simp only [add_mul,mul_add,smul_mul_assoc,mul_smul_comm,smul_smul,one_mul,mul_one]
  rw [hPQ]
  module

theorem source_cubic_scalar_multiplier_pairwise_commutation (t : Fin 3 → ℝ) (h : ℝ)
    (μ : Fin 3 → ℝ) (A S : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : A ∈ hermitianFeasibleTuples t)
    (hc : ∀ i,sourceCubicMatrixGradient (t i) (A i)=(h : ℂ) • 1+(μ i : ℂ) • 1+S i)
    (hSX : ∀ i,S i*A i=0) : ∀ i j,A i*A j=A j*A i := by
  obtain ⟨a,b,v,c,hv,he,hcval,hres⟩ := source_cubic_scalar_multiplier_projection_tuple t h μ A S hA hc hSX
  by_cases hczero : c=0
  · rw [hczero,Complex.ofReal_zero,zero_smul] at hres
    have hP (i : Fin 3) := source_unit_projection_properties (v i) (hv i)
    have hactive := source_zero_projection_resolution_participating_equal (fun i => sourceUnitProjection (v i)) b
      (fun i => (hP i).1) (fun i => (hP i).2.1) (fun i => (hP i).2.2) hres
    intro i j
    by_cases hbi : b i=0
    · have hAi : A i=(a i : ℂ) • (1 : Matrix (Fin 3) (Fin 3) ℂ) := by simpa [hbi] using he i
      rw [hAi]
      exact source_scalar_identity_commutes _ _
    by_cases hbj : b j=0
    · have hAj : A j=(a j : ℂ) • (1 : Matrix (Fin 3) (Fin 3) ℂ) := by simpa [hbj] using he j
      rw [hAj]
      exact (source_scalar_identity_commutes _ _).symm
    · rw [he i,he j]
      apply source_scalar_plus_commuting_matrices
      rw [hactive i j hbi hbj]
  · have hp := source_rank_one_nonzero_resolution_projectors_commute b v hv c hczero hres
    intro i j
    rw [he i,he j]
    exact source_scalar_plus_commuting_matrices _ _ _ _ _ _ (hp i j)

end CoefficientStability
