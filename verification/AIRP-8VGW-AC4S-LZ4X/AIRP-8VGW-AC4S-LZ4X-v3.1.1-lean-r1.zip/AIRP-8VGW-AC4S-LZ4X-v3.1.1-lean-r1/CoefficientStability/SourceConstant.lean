import CoefficientStability.CoefficientComparison
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.BigOperators.Intervals

noncomputable section
open scoped BigOperators
namespace CoefficientStability

theorem central_exponent_eq_natCeil (k : ℕ) (hk : 3≤k) :
    (k-1)/2=Nat.ceil (((k-2 : ℕ) : ℝ)/2) := by
  symm
  apply (Nat.ceil_eq_iff (by omega : (k-1)/2≠0)).mpr
  constructor
  · rw [lt_div_iff₀ (by norm_num : (0 : ℝ)<2)]
    exact_mod_cast (by omega : (((k-1)/2)-1)*2<k-2)
  · rw [div_le_iff₀ (by norm_num : (0 : ℝ)<2)]
    exact_mod_cast (by omega : k-2≤((k-1)/2)*2)

theorem paperCoefficientConstant_source_formula (n : ℕ) (hn : 2≤n) :
    paperCoefficientConstant n=(n : ℝ)+2*∑ k ∈ Finset.Icc 3 n,
      (n.choose k : ℝ)*((k : ℝ)*n)^k/(k.factorial : ℝ)*
        ((n : ℝ)-1)^(Nat.ceil (((k-2 : ℕ) : ℝ)/2)) := by
  have he : Finset.Icc 3 n=Finset.Ico 3 (n+1) := by
    ext k
    simp only [Finset.mem_Icc,Finset.mem_Ico]
    omega
  rw [he,Finset.sum_Ico_eq_sum_range]
  rw [show n+1-3=n-2 by omega]
  unfold paperCoefficientConstant
  congr 2
  apply Finset.sum_congr rfl
  intro j hj
  rw [← central_exponent_eq_natCeil (3+j) (by omega)]
  simp only [Nat.add_comm 3 j,show j+3-1=j+2 by omega]

end CoefficientStability
