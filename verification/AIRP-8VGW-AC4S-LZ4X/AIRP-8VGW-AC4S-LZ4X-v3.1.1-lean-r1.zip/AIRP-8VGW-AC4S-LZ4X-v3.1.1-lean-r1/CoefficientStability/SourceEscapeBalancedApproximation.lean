import CoefficientStability.SourceEscapeBalancedGeometry
import CoefficientStability.SourceEscapeNonbalancedPath

noncomputable section
open scoped BigOperators Topology unitInterval
namespace CoefficientStability
set_option maxHeartbeats 4000000
set_option backward.isDefEq.respectTransparency false

def sourceEscapeBalancedCurve (z : ℝ) : SourceEscapeCurve :=
  sourceEscapePolyline (sourceEscapeCenter 1 1) sourceBalancedEscapeGate
    (sourceBalancedEscapeGate+z • sourceBalancedEscapeDirection)

theorem source_escape_balanced_curve_admissible (z : ℝ) (hz : 0 < z) (hz2 : z ≤ 1/2) :
    sourceEscapeAdmissible 1 1 (sourceEscapeBalancedCurve z) := by
  have hE := source_escape_balanced_flat_feasible z (by rw [abs_of_pos hz];exact hz2)
  refine ⟨by simp [sourceEscapeBalancedCurve],?_,?_⟩
  · apply source_escape_polyline_property
    · exact source_transportation_actual_segment_feasible _ _ _
        (source_escape_center_feasible 1 1 (by norm_num) (by norm_num) (by norm_num)) source_escape_balanced_gate_feasible
    · exact source_transportation_actual_segment_feasible _ _ _ source_escape_balanced_gate_feasible hE
  · simp only [sourceEscapeBalancedCurve,source_escape_polyline_one,source_escape_balanced_flat_quadratic]
    norm_num [sourceEscapeQ]
    exact sq_pos_of_pos hz

theorem source_escape_balanced_curve_endpoint_excess (z : ℝ) :
    sourceEscapeExcess 1 1 (sourceEscapeBalancedCurve z 1)=sourceEscapeDelta 1 1+3*z^2 := by
  simp only [sourceEscapeBalancedCurve,source_escape_polyline_one]
  unfold sourceEscapeExcess
  rw [source_escape_balanced_flat_permanent]
  norm_num [sourceEscapeCenter,sourceEscapeTraces,sourcePermanentReference,source_permanent_three,sourceEscapeDelta]
  ring

theorem source_escape_balanced_curve_height (z : ℝ) :
    sourceEscapeCurveHeight 1 1 (sourceEscapeBalancedCurve z)=sourceEscapeDelta 1 1+3*z^2 := by
  apply le_antisymm
  · apply source_escape_curve_height_le
    unfold sourceEscapeBalancedCurve
    refine source_escape_polyline_property _ _ _ (fun X => sourceEscapeExcess 1 1 X ≤ sourceEscapeDelta 1 1+3*z^2) ?_ ?_
    · intro u
      have h := source_escape_balanced_gate_actual_segment_bound u
      linarith [sq_nonneg z]
    · exact source_escape_balanced_actual_flat_segment_bound z
  · have h := source_escape_curve_excess_le_height 1 1 (sourceEscapeBalancedCurve z) 1
    rwa [source_escape_balanced_curve_endpoint_excess] at h

theorem source_escape_balanced_arbitrary_approximation (ε : ℝ) (hε : 0 < ε) :
    ∃ γ : SourceEscapeCurve,sourceEscapeAdmissible 1 1 γ ∧
      sourceEscapeCurveHeight 1 1 γ < sourceEscapeDelta 1 1+ε := by
  let z := min (1/4 : ℝ) (ε/6)
  have hz : 0 < z := lt_min (by norm_num) (div_pos hε (by norm_num))
  have hz4 : z ≤ 1/4 := min_le_left _ _
  have hzε : z ≤ ε/6 := min_le_right _ _
  have hsq := mul_nonneg hz.le (sub_nonneg.mpr hz4)
  have hsmall : 3*z^2 < ε := by nlinarith
  refine ⟨sourceEscapeBalancedCurve z,source_escape_balanced_curve_admissible z hz (by linarith),?_⟩
  rw [source_escape_balanced_curve_height]
  linarith

theorem source_escape_balanced_actual_barrier : sourceEscapeBarrier 1 1=sourceEscapeDelta 1 1 := by
  have hγ := source_escape_balanced_curve_admissible (1/4) (by norm_num) (by norm_num)
  have hlow := source_escape_barrier_lower 1 1 (by norm_num) (by norm_num) (by norm_num) ⟨_,hγ⟩
  apply le_antisymm _ hlow
  by_contra hnot
  have hgap : 0 < sourceEscapeBarrier 1 1-sourceEscapeDelta 1 1 := by linarith
  obtain ⟨γ,hγ,hheight⟩ := source_escape_balanced_arbitrary_approximation
    ((sourceEscapeBarrier 1 1-sourceEscapeDelta 1 1)/2) (div_pos hgap (by norm_num))
  have h := source_escape_barrier_le_curve 1 1 (by norm_num) (by norm_num) (by norm_num) γ hγ
  linarith

theorem source_escape_full_actual_barrier (a b : ℝ) (ha : 0 < a) (hb : 0 < b)
    (hs : a+2*b=3) (hab : b/4 ≤ a) : sourceEscapeBarrier a b=sourceEscapeDelta a b := by
  by_cases he : a=b
  · have hb1 : b=1 := by linarith
    have ha1 : a=1 := he.trans hb1
    rw [ha1,hb1]
    exact source_escape_balanced_actual_barrier
  · exact (source_escape_nonbalanced_actual_attainment a b ha hb hs hab he).2.2

def sourceEscapeParameterDomain : Set (ℝ × ℝ) :=
  {p | 0 < p.1 ∧ 0 < p.2 ∧ p.1+2*p.2=3 ∧ p.2/4 ≤ p.1}

theorem source_escape_barrier_continuous_on_family :
    ContinuousOn (fun p : ℝ × ℝ => sourceEscapeBarrier p.1 p.2) sourceEscapeParameterDomain := by
  have hc : Continuous (fun p : ℝ × ℝ => sourceEscapeDelta p.1 p.2) := by unfold sourceEscapeDelta;fun_prop
  apply hc.continuousOn.congr
  intro p hp
  exact source_escape_full_actual_barrier p.1 p.2 hp.1 hp.2.1 hp.2.2.1 hp.2.2.2

end CoefficientStability
