import CoefficientStability.StableRealSpecialization
import CoefficientStability.StableCoefficientSign

noncomputable section
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def dropLastPolynomial : MvPolynomial (Fin (n+1)) ℝ →+* MvPolynomial (Fin n) ℝ :=
  MvPolynomial.eval₂Hom MvPolynomial.C (Fin.lastCases 0 MvPolynomial.X)

def lastDerivativeElimination (p : MvPolynomial (Fin (n+1)) ℝ) : MvPolynomial (Fin n) ℝ :=
  dropLastPolynomial (pderiv (Fin.last n) p)

theorem rename_dropLastPolynomial (p : MvPolynomial (Fin (n+1)) ℝ) :
    MvPolynomial.rename Fin.castSucc (dropLastPolynomial p)=coordinateSpecialization (Fin.last n) 0 p := by
  classical
  induction p using MvPolynomial.induction_on with
  | C c => simp [dropLastPolynomial,coordinateSpecialization]
  | add p q hp hq => simp only [map_add,hp,hq]
  | mul_X p j hp =>
    simp only [map_mul,hp]
    congr 1
    refine Fin.lastCases ?_ (fun k => ?_) j
    · simp [dropLastPolynomial,coordinateSpecialization]
    · simp [dropLastPolynomial,coordinateSpecialization,Fin.castSucc_ne_last]

theorem dropLastPolynomial_complex_eval (p : MvPolynomial (Fin (n+1)) ℝ) (z : Fin n → ℂ) :
    MvPolynomial.eval₂ Complex.ofRealHom z (dropLastPolynomial p)=
      MvPolynomial.eval₂ Complex.ofRealHom (Fin.lastCases 0 z) p := by
  classical
  change (MvPolynomial.eval₂Hom Complex.ofRealHom z) (MvPolynomial.eval₂ _ _ p)=_
  rw [MvPolynomial.hom_eval₂]
  congr 1
  · ext c
    simp
  · funext j
    refine Fin.lastCases ?_ (fun k => ?_) j <;> simp

theorem dropLastPolynomial_homogeneous (p : MvPolynomial (Fin (n+1)) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous N) : (dropLastPolynomial p).IsHomogeneous N := by
  let f : ℝ →+* MvPolynomial (Fin n) ℝ := MvPolynomial.C
  let g : Fin (n+1) → MvPolynomial (Fin n) ℝ := Fin.lastCases 0 MvPolynomial.X
  have hf : ∀ r : ℝ,(f r).IsHomogeneous 0 := fun r => isHomogeneous_C (Fin n) r
  have hg : ∀ j : Fin (n+1),(g j).IsHomogeneous 1 := by
    intro j
    refine Fin.lastCases ?_ (fun k => ?_) j
    · simpa only [g,Fin.lastCases_last] using (isHomogeneous_zero (Fin n) ℝ 1)
    · simpa only [g,Fin.lastCases_castSucc] using (isHomogeneous_X ℝ k)
  have h : (MvPolynomial.eval₂ f g p).IsHomogeneous (1*N) := hp.eval₂ f g hf hg
  change (MvPolynomial.eval₂ f g p).IsHomogeneous N
  simpa only [one_mul] using h

theorem stable_dropLast_zero_or_stable (p : MvPolynomial (Fin (n+1)) ℝ)
    (hp : UpperHalfPlaneZeroFree p) : dropLastPolynomial p=0 ∨ UpperHalfPlaneZeroFree (dropLastPolynomial p) := by
  classical
  rcases stable_zero_specialization_zero_or_stable p hp (Fin.last n) with hz | hs
  · left
    apply (MvPolynomial.rename_injective Fin.castSucc (Fin.castSucc_injective n))
    simpa only [rename_dropLastPolynomial,map_zero] using hz
  · right
    intro z hz
    let w : Fin (n+1) → ℂ := Fin.lastCases Complex.I z
    have hw : ∀ j,0<(w j).im := by
      intro j
      refine Fin.lastCases ?_ (fun k => ?_) j
      · simp [w]
      · simpa only [w,Fin.lastCases_castSucc] using hz k
    have h := hs w hw
    rw [← rename_dropLastPolynomial,MvPolynomial.eval₂_rename] at h
    simpa only [Function.comp_def,w,Fin.lastCases_castSucc] using h

theorem stable_last_derivative_elimination_zero_or_stable (p : MvPolynomial (Fin (n+1)) ℝ)
    (hp : UpperHalfPlaneZeroFree p) :
    lastDerivativeElimination p=0 ∨ UpperHalfPlaneZeroFree (lastDerivativeElimination p) := by
  rcases stable_partial_zero_or_stable p hp (Fin.last n) with hz | hs
  · left
    simp [lastDerivativeElimination,hz]
  · exact stable_dropLast_zero_or_stable _ hs

theorem lastDerivativeElimination_homogeneous (p : MvPolynomial (Fin (n+1)) ℝ) (N : ℕ)
    (hp : p.IsHomogeneous (N+1)) : (lastDerivativeElimination p).IsHomogeneous N :=
  dropLastPolynomial_homogeneous _ N (homogeneous_partial p N hp (Fin.last n))

end CoefficientStability
