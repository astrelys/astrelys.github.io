import CoefficientStability.SimpleRealRootEnumeration

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {N : ℕ}

def realRootProduct (r : Fin N → ℝ) : Polynomial ℝ := ∏ i,(Polynomial.X-Polynomial.C (r i))

def rootCoefficientVector (r : Fin N → ℝ) : Fin N → ℝ := fun k => (realRootProduct r).coeff k.val

theorem realRootProduct_monic (r : Fin N → ℝ) : (realRootProduct r).Monic :=
  Polynomial.monic_prod_of_monic _ _ (fun i hi => Polynomial.monic_X_sub_C (r i))

theorem realRootProduct_natDegree (r : Fin N → ℝ) : (realRootProduct r).natDegree=N := by
  rw [realRootProduct,Polynomial.natDegree_prod_of_monic _ _ (fun i hi => Polynomial.monic_X_sub_C (r i))]
  simp

theorem realRootProduct_roots (r : Fin N → ℝ) :
    (realRootProduct r).roots=(List.ofFn r : Multiset ℝ) := by
  have heq : realRootProduct r=((List.ofFn r : Multiset ℝ).map (fun a => Polynomial.X-Polynomial.C a)).prod := by
    simp only [Multiset.map_coe,List.map_ofFn,Multiset.prod_coe,List.prod_ofFn,Function.comp_def,realRootProduct]
  rw [heq,Polynomial.roots_multiset_prod_X_sub_C]

theorem realRootProduct_splits (r : Fin N → ℝ) : (realRootProduct r).Splits :=
  Polynomial.Splits.prod (fun i hi => Polynomial.Splits.X_sub_C (r i))

theorem monic_degree_eq_of_low_coefficients (P Q : Polynomial ℝ) (hp : P.Monic) (hq : Q.Monic)
    (hpN : P.natDegree=N) (hqN : Q.natDegree=N)
    (hc : ∀ k : Fin N,P.coeff k.val=Q.coeff k.val) : P=Q := by
  apply Polynomial.ext
  intro k
  by_cases hk : k<N
  · exact hc ⟨k,hk⟩
  by_cases hkeq : k=N
  · subst k
    rw [← hpN,hp.coeff_natDegree]
    rw [hpN,← hqN,hq.coeff_natDegree]
  · rw [Polynomial.coeff_eq_zero_of_natDegree_lt (by omega),
      Polynomial.coeff_eq_zero_of_natDegree_lt (by omega)]

theorem rootCoefficientVector_eq_polynomial (r s : Fin N → ℝ)
    (h : rootCoefficientVector r=rootCoefficientVector s) : realRootProduct r=realRootProduct s := by
  apply monic_degree_eq_of_low_coefficients _ _ (realRootProduct_monic r) (realRootProduct_monic s)
    (realRootProduct_natDegree r) (realRootProduct_natDegree s)
  intro k
  exact congrArg (fun v : Fin N → ℝ => v k) h

theorem polynomial_family_mul_coeff_continuous {α : Type*} [TopologicalSpace α]
    (P Q : α → Polynomial ℝ) (hP : ∀ k,Continuous (fun a => (P a).coeff k))
    (hQ : ∀ k,Continuous (fun a => (Q a).coeff k)) (k : ℕ) :
    Continuous (fun a => (P a*Q a).coeff k) := by
  simp only [Polynomial.coeff_mul]
  apply continuous_finsetSum
  intro ij hij
  convert! (hP ij.1).mul (hQ ij.2) using 1

theorem polynomial_family_finset_prod_coeff_continuous {α ι : Type*} [TopologicalSpace α]
    (s : Finset ι) (f : ι → α → Polynomial ℝ)
    (hf : ∀ i∈s,∀ k,Continuous (fun a => (f i a).coeff k)) :
    ∀ k,Continuous (fun a => (∏ i∈s,f i a).coeff k) := by
  classical
  induction s using Finset.induction_on with
  | empty => intro k;simpa only [Finset.prod_empty] using continuous_const
  | @insert i s hi ih =>
    have hfi := hf i (Finset.mem_insert_self i s)
    have hfs : ∀ j∈s,∀ k,Continuous (fun a => (f j a).coeff k) :=
      fun j hj => hf j (Finset.mem_insert_of_mem hj)
    intro k
    simp only [Finset.prod_insert hi]
    exact polynomial_family_mul_coeff_continuous _ _ hfi (ih hfs) k

theorem realRootProduct_coefficient_continuous (k : ℕ) :
    Continuous (fun r : Fin N → ℝ => (realRootProduct r).coeff k) := by
  apply polynomial_family_finset_prod_coeff_continuous Finset.univ
    (fun i (r : Fin N → ℝ) => Polynomial.X-Polynomial.C (r i))
  intro i hi j
  simp only [Polynomial.coeff_sub,Polynomial.coeff_X,Polynomial.coeff_C]
  split_ifs <;> fun_prop

theorem rootCoefficientVector_continuous : Continuous (rootCoefficientVector : (Fin N → ℝ) → Fin N → ℝ) :=
  continuous_pi (fun k => realRootProduct_coefficient_continuous k.val)

end CoefficientStability
