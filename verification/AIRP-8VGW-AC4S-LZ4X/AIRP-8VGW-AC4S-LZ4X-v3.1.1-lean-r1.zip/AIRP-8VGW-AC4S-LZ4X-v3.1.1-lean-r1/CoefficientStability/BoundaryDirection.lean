import CoefficientStability.BoundaryCubic

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def boundaryModelDiagonal (n : ℕ) (i : Fin n) : ℝ := if i.val=0 then (n : ℝ)-1 else -1

def boundaryModelMatrix (n : ℕ) : Matrix (Fin n) (Fin n) ℝ := Matrix.diagonal (boundaryModelDiagonal n)

theorem boundaryModelMatrix_trace (n : ℕ) (hn : 0<n) : Matrix.trace (boundaryModelMatrix n)=0 := by
  letI : NeZero n := ⟨Nat.ne_zero_of_lt hn⟩
  have he (i : Fin n) : boundaryModelDiagonal n i=(-1 : ℝ)+(if i=0 then (n : ℝ) else 0) := by
    unfold boundaryModelDiagonal
    by_cases h : i=0
    · simp [h] <;> ring
    · have hv : i.val≠0 := by simpa using h
      simp [h,hv]
  simp only [boundaryModelMatrix,Matrix.trace_diagonal,he,Finset.sum_add_distrib]
  simp

theorem boundaryModelMatrix_trace_cube (n : ℕ) (hn : 0<n) :
    Matrix.trace (boundaryModelMatrix n ^ 3)=(n : ℝ)*((n : ℝ)-1)*((n : ℝ)-2) := by
  letI : NeZero n := ⟨Nat.ne_zero_of_lt hn⟩
  have he (i : Fin n) : (boundaryModelDiagonal n i)^3=(-1 : ℝ)+
      (if i=0 then ((n : ℝ)-1)^3+1 else 0) := by
    unfold boundaryModelDiagonal
    by_cases h : i=0
    · simp [h]
    · have hv : i.val≠0 := by simpa using h
      norm_num [h,hv]
  simp only [boundaryModelMatrix,Matrix.diagonal_pow,Matrix.trace_diagonal,Pi.pow_apply,he,Finset.sum_add_distrib]
  simp
  ring

theorem boundaryModelMatrix_trace_cube_pos (n : ℕ) (hn : 3≤n) :
    0<Matrix.trace (boundaryModelMatrix n ^ 3) := by
  rw [boundaryModelMatrix_trace_cube n (by omega)]
  have hn' : (3 : ℝ)≤n := by exact_mod_cast hn
  exact mul_pos (mul_pos (by linarith) (by linarith)) (by linarith)

theorem boundaryModelMatrix_isHermitian (n : ℕ) : (boundaryModelMatrix n).IsHermitian := by
  ext i j
  by_cases h : i=j <;> simp [boundaryModelMatrix,Matrix.conjTranspose_apply,Matrix.diagonal_apply,h,Ne.symm]

def boundaryCommutingDirection (t : Fin n → ℝ) (i : Fin n) : Matrix (Fin n) (Fin n) ℝ :=
  (t i*projectedOnes t i) • boundaryModelMatrix n

theorem boundaryCommutingDirection_sum (t : Fin n → ℝ) (hn : 0<n) (ht : ∑ i,t i=n) :
    (∑ i,boundaryCommutingDirection t i)=0 := by
  simp only [boundaryCommutingDirection,← Finset.sum_smul,projectedOnes_dot_t t hn ht,zero_smul]

theorem boundaryCommutingDirection_traceless (t : Fin n → ℝ) (hn : 0<n) (i : Fin n) :
    Matrix.trace (boundaryCommutingDirection t i)=0 := by
  simp [boundaryCommutingDirection,boundaryModelMatrix_trace n hn]

theorem boundaryCommutingDirection_commute (t : Fin n → ℝ) (i j : Fin n) :
    boundaryCommutingDirection t i * boundaryCommutingDirection t j =
      boundaryCommutingDirection t j * boundaryCommutingDirection t i := by
  simp only [boundaryCommutingDirection,smul_mul_smul_comm]
  congr 1
  ring

theorem paper_boundary_cubic_scalar_factor_negative (t : Fin n → ℝ) (hn : 3≤n)
    (ht : ∑ i,t i=n) (htpos : ∀ i,0<t i) (hl : scalarHessianLambda t=0) :
    (2*((n-3).factorial : ℝ)/(n : ℝ)^(n-3)*(∏ i,t i))*
      centralCoefficient (projectedOnes t) 3*Matrix.trace (boundaryModelMatrix n ^ 3)<0 := by
  have he := (paper_boundary_third_coefficient t (by omega) ht htpos hl).2.2
  have hh := boundaryModelMatrix_trace_cube_pos n hn
  have hprod : 0<∏ i,t i := Finset.prod_pos (fun i hi => htpos i)
  have hf : (0 : ℝ)<((n-3).factorial : ℝ) := by exact_mod_cast Nat.factorial_pos (n-3)
  have hn' : (0 : ℝ)<n := by exact_mod_cast (by omega : 0<n)
  exact mul_neg_of_neg_of_pos (mul_neg_of_pos_of_neg (by positivity) he) hh

end CoefficientStability
