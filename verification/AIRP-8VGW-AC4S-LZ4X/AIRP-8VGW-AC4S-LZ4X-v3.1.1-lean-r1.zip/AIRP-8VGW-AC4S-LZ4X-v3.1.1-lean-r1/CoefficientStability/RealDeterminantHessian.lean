import CoefficientStability.RealDeterminantPolynomial

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem complexification_eval_one (p : MvPolynomial (Fin n) ℝ) :
    Complex.ofReal (MvPolynomial.eval (fun _ => 1) p)=
      MvPolynomial.eval (fun _ => 1) (MvPolynomial.map Complex.ofRealHom p) := by
  change Complex.ofRealHom (MvPolynomial.eval (fun _ => 1) p)=_
  simpa only [Function.comp_def,map_one] using
    MvPolynomial.map_eval Complex.ofRealHom (fun _ => 1) p

theorem realDeterminant_gradient (A : Fin n → ComplexSquare n) (hHerm : ∀ i,(A i).IsHermitian)
    (hA : ∑ i,A i=1) (i : Fin n) :
    MvPolynomial.eval (fun _ => 1) (pderiv i (realDeterminantPolynomial A))=(Matrix.trace (A i)).re := by
  have he : Complex.ofReal (MvPolynomial.eval (fun _ => 1) (pderiv i (realDeterminantPolynomial A)))=
      Matrix.trace (A i) := by
    rw [complexification_eval_one,← pderiv_map,realDeterminantPolynomial_complexification A hHerm,
      determinantPolynomial_gradient_one A hA i]
  exact congrArg Complex.re he

theorem realDeterminant_hessian (A : Fin n → ComplexSquare n) (hHerm : ∀ i,(A i).IsHermitian)
    (hA : ∑ i,A i=1) (i j : Fin n) :
    MvPolynomial.eval (fun _ => 1) (pderiv j (pderiv i (realDeterminantPolynomial A)))=
      (Matrix.trace (A i)).re*(Matrix.trace (A j)).re-(Matrix.trace (A i*A j)).re := by
  have htrace (k : Fin n) : (Matrix.trace (A k)).im=0 := by
    have h := congrArg Complex.im (Matrix.trace_conjTranspose (A k))
    rw [hHerm k] at h
    change (Matrix.trace (A k)).im= -(Matrix.trace (A k)).im at h
    linarith
  have he : Complex.ofReal (MvPolynomial.eval (fun _ => 1)
      (pderiv j (pderiv i (realDeterminantPolynomial A))))=
      Matrix.trace (A i)*Matrix.trace (A j)-Matrix.trace (A i*A j) := by
    rw [complexification_eval_one,← pderiv_map,← pderiv_map,
      realDeterminantPolynomial_complexification A hHerm,determinantPolynomial_hessian_one A hA i j]
  have h := congrArg Complex.re he
  simpa only [Complex.ofReal_re,Complex.sub_re,Complex.mul_re,htrace,mul_zero,sub_zero] using h

end CoefficientStability
