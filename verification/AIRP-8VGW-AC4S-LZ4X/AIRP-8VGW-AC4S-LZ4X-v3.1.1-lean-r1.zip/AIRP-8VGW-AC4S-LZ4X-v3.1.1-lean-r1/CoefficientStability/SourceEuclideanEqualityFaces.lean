import CoefficientStability.SourceTernaryInteriorMinimum

noncomputable section
open scoped BigOperators Topology
namespace CoefficientStability
set_option maxHeartbeats 1200000

def sourceEuclideanExceptionalTraces : Fin 3 → ℝ := ![3/2,3/4,3/4]
def sourceEuclideanBoundaryFamily (c : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  ![![0,3/4,3/4],![1/2,c,1/4-c],![1/2,1/4-c,c]]

theorem source_euclidean_boundary_family_feasible_equal (c : ℝ) (hc : 0 ≤ c) (hc4 : c ≤ 1/4) :
    sourceEuclideanBoundaryFamily c ∈ sourceTransportationPolytope sourceEuclideanExceptionalTraces ∧
      Matrix.permanent (sourceEuclideanBoundaryFamily c)=sourceTernaryBaseline sourceEuclideanExceptionalTraces := by
  refine ⟨⟨?_,?_,?_⟩,?_⟩
  · intro i j
    fin_cases i <;> fin_cases j <;> norm_num [sourceEuclideanBoundaryFamily] <;> linarith
  · intro i
    fin_cases i <;> norm_num [sourceEuclideanBoundaryFamily,sourceEuclideanExceptionalTraces,Fin.sum_univ_succ] <;> ring
  · intro j
    fin_cases j <;> norm_num [sourceEuclideanBoundaryFamily,Fin.sum_univ_succ] <;> ring
  · rw [source_permanent_three]
    norm_num [sourceEuclideanBoundaryFamily,sourceEuclideanExceptionalTraces,sourceTernaryBaseline]
    ring

theorem source_one_zero_equality_classification (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b c : ℝ)
    (hpos : ∀ q ∈ sourceOneZeroEntrySet,0 < sourceTernaryOneZero t a b c q.1 q.2)
    (hmin : IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) (sourceTernaryOneZero t a b c))
    (hobj : Matrix.permanent (sourceTernaryOneZero t a b c)=sourceTernaryBaseline t) :
    t=sourceEuclideanExceptionalTraces ∧ a=3/4 ∧ b=1/2 ∧ 0 < c ∧ c < 1/4 ∧
      sourceTernaryOneZero t a b c=sourceEuclideanBoundaryFamily c := by
  obtain ⟨ha,hb,ht12⟩ := source_one_zero_minimum_parameters t ht a b c hpos hmin
  have hap : 0 < a := by simpa [sourceTernaryOneZero] using hpos (0,1) (by decide)
  have ht0pos : 0 < t 0 := by linarith
  have hg := source_ternary_one_zero_stationary_gap t ht ht12 c
  rw [ha,hb] at hobj
  rw [hobj,sub_self] at hg
  have hz : t 0^2*(3-2*t 0)=0 := by linarith
  have hfac := (mul_eq_zero.mp hz).resolve_left (pow_ne_zero 2 (ne_of_gt ht0pos))
  have h0 : t 0=3/2 := by linarith
  have hs := ht
  norm_num [Fin.sum_univ_succ] at hs
  have h1 : t 1=3/4 := by linarith
  have h2 : t 2=3/4 := by linarith
  have htfun : t=sourceEuclideanExceptionalTraces := by
    funext i
    fin_cases i
    · exact h0
    · exact h1
    · exact h2
  have hc : 0 < c := by simpa [sourceTernaryOneZero] using hpos (1,1) (by decide)
  have hc4 : c < 1/4 := by
    have h := hpos (1,2) (by decide)
    norm_num [sourceTernaryOneZero] at h
    rw [hb,h1] at h
    linarith
  refine ⟨htfun,by linarith,hb,hc,hc4,?_⟩
  rw [ha,hb,htfun]
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [sourceTernaryOneZero,sourceEuclideanExceptionalTraces,sourceEuclideanBoundaryFamily] <;> ring

theorem source_one_zero_minimum_strict (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b c : ℝ)
    (hpos : ∀ q ∈ sourceOneZeroEntrySet,0 < sourceTernaryOneZero t a b c q.1 q.2)
    (hmin : IsLocalMinOn Matrix.permanent (sourceTransportationPolytope t) (sourceTernaryOneZero t a b c))
    (hbox : t 0 < 3/2) : sourceTernaryBaseline t < Matrix.permanent (sourceTernaryOneZero t a b c) := by
  obtain ⟨ha,hb,ht12⟩ := source_one_zero_minimum_parameters t ht a b c hpos hmin
  have hap : 0 < a := by simpa [sourceTernaryOneZero] using hpos (0,1) (by decide)
  have ht0pos : 0 < t 0 := by linarith
  have hg := (source_one_zero_minimum_gap t ht a b c hpos hmin hbox.le).2
  have hp : 0 < t 0^2*(3-2*t 0)/36 :=
    div_pos (mul_pos (sq_pos_of_pos ht0pos) (by linarith)) (by norm_num)
  linarith

theorem source_matching_zero_strict (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hbox : ∀ i,t i < 3/2) (x : ℝ) :
    sourceTernaryBaseline t < Matrix.permanent (sourceTernaryMatchingZeros t x) := by
  have hp : 0 < ∏ i,(3-2*t i) := Finset.prod_pos (fun i _ => by linarith [hbox i])
  have hg := source_ternary_matching_gap t ht x
  nlinarith [sq_nonneg (x-(1/2+(t 0-t 2)/3))]

theorem source_matching_zero_equality_conditions (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hbox : ∀ i,t i ≤ 3/2) (x : ℝ)
    (hobj : Matrix.permanent (sourceTernaryMatchingZeros t x)=sourceTernaryBaseline t) :
    x=1/2+(t 0-t 2)/3 ∧ ∃ i,t i=3/2 := by
  have hp : 0 ≤ ∏ i,(3-2*t i) := Finset.prod_nonneg (fun i _ => by linarith [hbox i])
  have hg := source_ternary_matching_gap t ht x
  rw [hobj,sub_self] at hg
  have hs : (x-(1/2+(t 0-t 2)/3))^2=0 := by nlinarith [sq_nonneg (x-(1/2+(t 0-t 2)/3))]
  have hz : ∏ i,(3-2*t i)=0 := by nlinarith
  obtain ⟨i,hi,he⟩ := Finset.prod_eq_zero_iff.mp hz
  exact ⟨sub_eq_zero.mp (sq_eq_zero_iff.mp hs),i,by linarith⟩

end CoefficientStability
