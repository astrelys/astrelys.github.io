import CoefficientStability.SourceSharpEuclideanClassification

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1200000

def sourceL1ChartD (u v : ℝ) := u*v/(1+v-u)
def sourceL1ChartHeight (u v : ℝ) := sourceL1ChartD u v+(u-v)/2
def sourceL1ChartTraces (u v : ℝ) : Fin 3 → ℝ :=
  sourceTernaryStationaryTraces ((1+v)/2) ((1-u)/2) (sourceL1ChartD u v)
def sourceL1ChartMatrix (u v : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  sourceTernarySeparatedZeros (sourceL1ChartTraces u v) ((1+v)/2) ((1-u)/2)
def sourceCubicDistance (d h : ℝ) := (3-2*d)*Real.sqrt (sourceCubicS d h)+|h|

theorem source_l1_chart_denominator (u v : ℝ) (hu : 0 < u) (hv : 0 < v) (huv : u+v < 1) :
    0 < 1+v-u ∧ u < 1 ∧ v < 1 := by exact ⟨by linarith,by linarith,by linarith⟩

theorem source_l1_chart_relation (u v : ℝ) (hu : 0 < u) (hv : 0 < v) (huv : u+v < 1) :
    sourceL1ChartD u v*(1+v-u)=u*v := by
  have hn := (source_l1_chart_denominator u v hu hv huv).1
  unfold sourceL1ChartD
  exact div_mul_cancel₀ _ (ne_of_gt hn)

theorem source_l1_chart_d_bounds (u v : ℝ) (hu : 0 < u) (hv : 0 < v) (huv : u+v < 1) :
    0 < sourceL1ChartD u v ∧ sourceL1ChartD u v < u/2 ∧ sourceL1ChartD u v < 1/2 := by
  obtain ⟨hn,hu1,hv1⟩ := source_l1_chart_denominator u v hu hv huv
  have hd : 0 < sourceL1ChartD u v := div_pos (mul_pos hu hv) hn
  have hdu : sourceL1ChartD u v < u/2 := by
    apply (div_lt_iff₀ hn).mpr
    nlinarith [mul_pos (by linarith : 0 < u/2) (by linarith : 0 < 1-u-v)]
  exact ⟨hd,hdu,by linarith⟩

theorem source_l1_chart_positive_factor (u v : ℝ) (hu : 0 < u) (hv : 0 < v) (huv : u+v < 1) :
    0 < 1-v-2*sourceL1ChartD u v := by
  have hrel := source_l1_chart_relation u v hu hv huv
  have hn := (source_l1_chart_denominator u v hu hv huv).1
  have he : (1-v-2*sourceL1ChartD u v)*(1+v-u)=(1+v)*(1-u-v) := by linear_combination -2*hrel
  have hp : 0 < (1+v)*(1-u-v) := mul_pos (by linarith) (by linarith)
  by_contra hh
  have hm := mul_nonpos_of_nonpos_of_nonneg (le_of_not_gt hh) hn.le
  rw [he] at hm
  linarith

theorem source_l1_chart_stationary_relation (u v : ℝ) (hu : 0 < u) (hv : 0 < v) (huv : u+v < 1) :
    4*((1+v)/2)*((1-u)/2)=(1-sourceL1ChartD u v)*(2*((1+v)/2+(1-u)/2)-1) := by
  have hrel := source_l1_chart_relation u v hu hv huv
  linear_combination hrel

theorem source_l1_chart_square_identity (u v : ℝ) (hu : 0 < u) (hv : 0 < v) (huv : u+v < 1) :
    sourceCubicS (sourceL1ChartD u v) (sourceL1ChartHeight u v)=((u+v)/2)^2 := by
  have hrel := source_l1_chart_relation u v hu hv huv
  unfold sourceCubicS sourceL1ChartHeight
  linear_combination hrel

theorem source_l1_chart_sqrt_identity (u v : ℝ) (hu : 0 < u) (hv : 0 < v) (huv : u+v < 1) :
    Real.sqrt (sourceCubicS (sourceL1ChartD u v) (sourceL1ChartHeight u v))=(u+v)/2 := by
  rw [source_l1_chart_square_identity u v hu hv huv,Real.sqrt_sq_eq_abs,abs_of_pos (by linarith)]

theorem source_l1_chart_marginal_signs (u v : ℝ) (hu : 0 < u) (hv : 0 < v) (huv : u+v < 1) :
    1 < sourceL1ChartTraces u v 0 ∧ sourceL1ChartTraces u v 1 < 1 ∧
      sourceL1ChartTraces u v 2-1=sourceL1ChartHeight u v := by
  obtain ⟨hd,hdu,hd2⟩ := source_l1_chart_d_bounds u v hu hv huv
  obtain ⟨hn,hu1,hv1⟩ := source_l1_chart_denominator u v hu hv huv
  have hp0 := mul_pos (by linarith : 0 < 1+v) (by linarith : 0 < (u-2*sourceL1ChartD u v)/2)
  have hp1 := mul_pos (by linarith : 0 < 1-u) (by linarith : 0 < sourceL1ChartD u v+v/2)
  norm_num [sourceL1ChartTraces,sourceTernaryStationaryTraces,sourceL1ChartHeight]
  constructor
  · nlinarith [hp0]
  · constructor
    · nlinarith [hp1]
    · ring

theorem source_l1_chart_actual_distance (u v : ℝ) (hu : 0 < u) (hv : 0 < v) (huv : u+v < 1) :
    (∑ i,|sourceL1ChartTraces u v i-1|)=
      sourceCubicDistance (sourceL1ChartD u v) (sourceL1ChartHeight u v) := by
  obtain ⟨h0,h1,h2⟩ := source_l1_chart_marginal_signs u v hu hv huv
  have hdiff : sourceL1ChartTraces u v 0-sourceL1ChartTraces u v 1=(3-2*sourceL1ChartD u v)*(u+v)/2 := by
    norm_num [sourceL1ChartTraces,sourceTernaryStationaryTraces]
    ring
  norm_num only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero,Fin.reduceFinMk]
  change |sourceL1ChartTraces u v 0-1|+ (|sourceL1ChartTraces u v 1-1|+|sourceL1ChartTraces u v 2-1|)=_
  rw [abs_of_pos (by linarith : 0 < sourceL1ChartTraces u v 0-1),
    abs_of_neg (by linarith : sourceL1ChartTraces u v 1-1 < 0),h2]
  unfold sourceCubicDistance
  rw [source_l1_chart_sqrt_identity u v hu hv huv]
  linarith [hdiff]

theorem source_euclidean_H_equals_l1_H (d z : ℝ) :
    sourceCubicEuclideanH d z=sourceCubicH d (d+z/2) := by
  unfold sourceCubicEuclideanH sourceCubicH
  ring

theorem source_l1_chart_actual_gap (u v : ℝ) (hu : 0 < u) (hv : 0 < v) (huv : u+v < 1) :
    Matrix.permanent (sourceL1ChartMatrix u v)-sourceTernaryBaseline (sourceL1ChartTraces u v)=
      (((1+v)/2)*((1-u)/2)/9)*sourceCubicH (sourceL1ChartD u v) (sourceL1ChartHeight u v) := by
  have hg := source_ternary_stationary_chart_gap ((1+v)/2) ((1-u)/2) (sourceL1ChartD u v)
    (source_l1_chart_stationary_relation u v hu hv huv)
  have hz : 2-2*((1+v)/2+(1-u)/2)=u-v := by ring
  rw [hz,source_euclidean_H_equals_l1_H] at hg
  exact hg

end CoefficientStability
