import CoefficientStability.OrderedRootCoefficientMap
import CoefficientStability.SmoothedCoefficientCone

set_option maxHeartbeats 1600000

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {N n : ℕ}

theorem simple_real_polynomial_family_ordered_roots_continuous
    {α : Type*} [TopologicalSpace α] (P : α → Polynomial ℝ)
    (hmonic : ∀ a,(P a).Monic) (hsplit : ∀ a,(P a).Splits)
    (hdegree : ∀ a,(P a).natDegree=N) (hsimple : ∀ a,(P a).roots.Nodup)
    (hcoeff : ∀ k : Fin N,Continuous (fun a => (P a).coeff k.val)) :
    ∃ roots : α → Fin N → ℝ,Continuous roots ∧
      ∀ a,StrictMono (roots a) ∧ P a=realRootProduct (roots a) := by
  have hcard (a : α) : (P a).roots.toFinset.card=N :=
    simple_real_roots_card (P a) (hsplit a) (hsimple a) N (hdegree a)
  let roots : α → Fin N → ℝ := fun a => orderedSimpleRoots (P a) N (hcard a)
  have hfactor (a : α) : P a=realRootProduct (roots a) := by
    simpa only [roots,realRootProduct] using
      orderedSimpleRoots_factorization (P a) (hmonic a) (hsplit a) N (hcard a) (hsimple a)
  have heq : (fun a => rootCoefficientVector (roots a))=(fun a => (fun k : Fin N => (P a).coeff k.val)) := by
    funext a k
    exact congrArg (fun Q : Polynomial ℝ => Q.coeff k.val) (hfactor a).symm
  have hcont : Continuous roots := by
    apply ordered_root_vector_continuous roots
      (fun a => (orderedSimpleRoots (P a) N (hcard a)).monotone)
    rw [heq]
    exact continuous_pi hcoeff
  exact ⟨roots,hcont,fun a => ⟨(orderedSimpleRoots (P a) N (hcard a)).strictMono,hfactor a⟩⟩

theorem actual_smoothed_line_continuous_ordered_roots
    (p : MvPolynomial (Fin n) ℝ) (hp : p.IsHomogeneous N)
    (hs : UpperHalfPlaneZeroFree p) (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (ε : ℝ) (hε : ε≠0) (x b : Fin n → ℝ) :
    ∃ roots : ℝ → Fin N → ℝ,Continuous roots ∧
      ∀ t : ℝ,StrictMono (roots t) ∧
        smoothedLineRestriction p N ε (x+t • b)=realRootProduct (roots t) := by
  let P : ℝ → Polynomial ℝ := fun t => smoothedLineRestriction p N ε (x+t • b)
  have hprop (t : ℝ) := smoothed_source_line_simple_real_roots p N hp hs hnorm ε hε (x+t • b)
  have hpath : Continuous (fun t : ℝ => x+t • b) := by
    apply continuous_pi
    intro j
    change Continuous (fun t : ℝ => x j+t*b j)
    fun_prop
  have hpair : Continuous (fun t : ℝ => (x+t • b,ε)) := hpath.prodMk continuous_const
  have hcoeff (k : Fin N) : Continuous (fun t : ℝ => (P t).coeff k.val) := by
    have h := (smoothedLineRestriction_joint_coefficient_continuous p N k.val).comp hpair
    change Continuous (fun t : ℝ => (smoothedLineRestriction p N ε (x+t • b)).coeff k.val)
    convert! h using 1
  exact simple_real_polynomial_family_ordered_roots_continuous (N := N) P
    (fun t => (hprop t).1) (fun t => (hprop t).2.1)
    (fun t => (hprop t).2.2.1) (fun t => (hprop t).2.2.2) hcoeff

end CoefficientStability
