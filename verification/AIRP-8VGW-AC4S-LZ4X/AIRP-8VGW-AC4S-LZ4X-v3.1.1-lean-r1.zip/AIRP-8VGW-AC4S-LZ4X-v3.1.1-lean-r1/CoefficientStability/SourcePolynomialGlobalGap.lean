import CoefficientStability.SourceGradientRadius

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem source_euclidean_global_coefficient_gap (p : MvPolynomial (Fin n) ℝ) (hn : 3 ≤ n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hnear : (∑ i,(MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1)^2) ≤
      1/(10000000000000000*(n : ℝ)^15)) :
    sourceVn n/(2000000000*(n : ℝ)^8)*
      referenceDeficit p (fun i => MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)) n ≤
      p.coeff (squarefreeExponent n)-sourceVn n*(∏ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)) := by
  have hpeel := source_euclidean_gradient_peeling hn
    (fun i => MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1) hnear
  have hr2 : (Real.sqrt (∑ i,(MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1)^2))^2=
      ∑ i,(MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1)^2 :=
    Real.sq_sqrt (Finset.sum_nonneg (fun i hi => sq_nonneg _))
  have hsq := source_euclidean_squared_short_field hn
    (Real.sqrt (∑ i,(MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1)^2)) (by rwa [hr2])
  have hshort := source_squared_condition_short hn _ (Real.sqrt_nonneg _) hsq
  have hg := source_unbalanced_global_gap_criterion p hn hp hs hnorm hpeel.1 hpeel.2 hshort.1 hshort.2 hsq
  simpa only [actualTiltDeficit_zero p hnorm,tiltedMoment_zero p hnorm] using hg

theorem source_polynomial_global_coefficient_gap (p : MvPolynomial (Fin n) ℝ) (hn : 3 ≤ n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hnear : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|) ≤
      1/(1000000000*(n : ℝ)^8)) :
    sourceVn n/(2000000000*(n : ℝ)^8)*
      referenceDeficit p (fun i => MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)) n ≤
      p.coeff (squarefreeExponent n)-sourceVn n*(∏ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)) := by
  apply source_euclidean_global_coefficient_gap p hn hp hs hnorm
  exact source_l1_radius_implies_euclidean hn _ hnear

end CoefficientStability
