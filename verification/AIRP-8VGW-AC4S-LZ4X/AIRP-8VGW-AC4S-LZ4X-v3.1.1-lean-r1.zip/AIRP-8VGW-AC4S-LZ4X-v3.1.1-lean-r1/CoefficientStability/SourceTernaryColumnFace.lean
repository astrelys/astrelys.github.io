import CoefficientStability.SourceTernaryFaceBounds

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 1200000

def sourceTernaryDoubleColumnZero (t : Fin 3 → ℝ) (a b : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  ![![1,a,t 0-1-a],![0,b,t 1-b],![0,1-a-b,t 2-1+a+b]]

theorem source_ternary_double_column_formula (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) (a b : ℝ) :
    Matrix.permanent (sourceTernaryDoubleColumnZero t a b)=
      2*(b+(t 2-t 1-2+2*a)/4)^2+(2-t 0)/2-(t 1-t 2)^2/8+a*(t 0-1-a)/2 := by
  have hs := ht
  simp only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero] at hs
  change t 0+(t 1+t 2)=3 at hs
  have ht2 : t 2=3-t 0-t 1 := by linarith
  rw [source_permanent_three]
  norm_num [sourceTernaryDoubleColumnZero]
  rw [ht2]
  ring

theorem source_ternary_double_column_strict_bound (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3)
    (hbox : ∀ i,1/2 ≤ t i ∧ t i ≤ 3/2) (a b : ℝ)
    (hB : ∀ i j,0 ≤ sourceTernaryDoubleColumnZero t a b i j) :
    1/32 ≤ Matrix.permanent (sourceTernaryDoubleColumnZero t a b)-sourceTernaryBaseline t := by
  have hs := ht
  simp only [Fin.sum_univ_succ,Fin.sum_univ_zero,add_zero] at hs
  change t 0+(t 1+t 2)=3 at hs
  have ha : 0 ≤ a := by simpa [sourceTernaryDoubleColumnZero] using hB 0 1
  have haU : a ≤ t 0-1 := by have h := hB 0 2;norm_num [sourceTernaryDoubleColumnZero] at h;linarith
  let u := 2-t 0
  let w := t 1-t 2
  have huL : 1/2 ≤ u := by dsimp [u];linarith [(hbox 0).2]
  have huU : u ≤ 1 := by dsimp [u];linarith
  have htu : t 0=2-u := by dsimp [u];ring
  have hsum : t 1+t 2=1+u := by dsimp [u];linarith
  have hwL : -u ≤ w := by dsimp [w];linarith [(hbox 1).1]
  have hwU : w ≤ u := by dsimp [w];linarith [(hbox 2).1]
  have hw2 : w^2 ≤ u^2 := by nlinarith [mul_nonneg (sub_nonneg.mpr hwU) (by linarith : 0 ≤ u+w)]
  have hbase : sourceTernaryBaseline t ≤ (2-u)*(1+u)^2/18 := by
    have hsq := mul_nonneg (by linarith : 0 ≤ t 0) (sq_nonneg (t 1-t 2))
    unfold sourceTernaryBaseline
    rw [← htu,← hsum]
    nlinarith [hsq]
  have hf := source_ternary_double_column_formula t ht a b
  have hra := mul_nonneg ha (by linarith : 0 ≤ t 0-1-a)
  have hsq := sq_nonneg (b+(t 2-t 1-2+2*a)/4)
  have hper : u/2-w^2/8 ≤ Matrix.permanent (sourceTernaryDoubleColumnZero t a b) := by
    change Matrix.permanent (sourceTernaryDoubleColumnZero t a b)=
      2*(b+(t 2-t 1-2+2*a)/4)^2+u/2-w^2/8+a*(t 0-1-a)/2 at hf
    nlinarith [hra,hsq]
  have hquad : 0 ≤ 4*u^2-7*u+41/2 := by nlinarith [sq_nonneg u]
  have hp := mul_nonneg (by linarith : 0 ≤ u-1/2) hquad
  have hpoly : 9/4 ≤ 4*u^3-9*u^2+24*u-8 := by nlinarith [hp]
  nlinarith [hpoly,hbase,hper,hw2]

end CoefficientStability
