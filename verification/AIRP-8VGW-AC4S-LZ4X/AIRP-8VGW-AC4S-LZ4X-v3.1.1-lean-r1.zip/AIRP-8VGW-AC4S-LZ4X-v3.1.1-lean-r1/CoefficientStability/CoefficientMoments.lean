import CoefficientStability.RootVarianceTheorem

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

def coefficientSecondMoment (p : MvPolynomial (Fin n) ℝ) (i j : Fin n) : ℝ :=
  ∑ g ∈ p.support, p.coeff g * (g i : ℝ) * (g j : ℝ)

def coefficientCovariance (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) :
    Matrix (Fin n) (Fin n) ℝ := fun i j =>
  ∑ g ∈ p.support, p.coeff g * ((g i : ℝ)-t i) * ((g j : ℝ)-t j)

theorem normalized_coefficient_mass (p : MvPolynomial (Fin n) ℝ)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1) :
    ∑ g ∈ p.support, p.coeff g = 1 := by
  rw [coefficient_sum_eq_eval_one,hnorm]

theorem actual_coefficient_first_moment (p : MvPolynomial (Fin n) ℝ) (i : Fin n) :
    ∑ g ∈ p.support, p.coeff g * (g i : ℝ) =
      MvPolynomial.eval (fun _ => 1) (pderiv i p) := by
  rw [eval_one_first_as_sum]

theorem actual_coefficient_second_moment (p : MvPolynomial (Fin n) ℝ) (i j : Fin n) :
    coefficientSecondMoment p i j =
      MvPolynomial.eval (fun _ => 1) (pderiv i (pderiv j p)) +
        if i=j then MvPolynomial.eval (fun _ => 1) (pderiv i p) else 0 := by
  conv_rhs => rw [p.as_sum]
  simp only [map_sum,eval_one_mixed_second_monomial,eval_one_first_monomial]
  by_cases hij : i=j
  · subst j
    simp only [ite_true]
    rw [← Finset.sum_add_distrib]
    unfold coefficientSecondMoment
    apply Finset.sum_congr rfl
    intro g hg
    ring
  · simp only [hij,ite_false,sub_zero,add_zero]
    unfold coefficientSecondMoment
    apply Finset.sum_congr rfl
    intro g hg
    ring

theorem actual_coefficient_covariance (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p)=t i) (i j : Fin n) :
    coefficientCovariance p t i j =
      MvPolynomial.eval (fun _ => 1) (pderiv i (pderiv j p)) +
        (if i=j then t i else 0) - t i*t j := by
  have he : coefficientCovariance p t i j = coefficientSecondMoment p i j -
      t j*(∑ g ∈ p.support,p.coeff g*(g i : ℝ)) -
      t i*(∑ g ∈ p.support,p.coeff g*(g j : ℝ)) +
      t i*t j*(∑ g ∈ p.support,p.coeff g) := by
    unfold coefficientCovariance coefficientSecondMoment
    simp only [Finset.mul_sum,← Finset.sum_sub_distrib,← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro g hg
    ring
  rw [he,actual_coefficient_second_moment,actual_coefficient_first_moment,
    actual_coefficient_first_moment,normalized_coefficient_mass p hnorm,hgrad i,hgrad j]
  ring

theorem actual_coefficient_second_moment_lower
    (p : MvPolynomial (Fin n) ℝ) (i : Fin n)
    (hcoeff : ∀ g, 0 ≤ p.coeff g) (hnorm : MvPolynomial.eval (fun _ => 1) p=1) :
    (MvPolynomial.eval (fun _ => 1) (pderiv i p))^2 ≤ coefficientSecondMoment p i i := by
  have h := Finset.sum_sq_le_sum_mul_sum_of_sq_le_mul p.support
    (r := fun g => p.coeff g*(g i : ℝ))
    (f := fun g => p.coeff g*(g i : ℝ)^2) (g := fun g => p.coeff g)
    (fun g hg => mul_nonneg (hcoeff g) (sq_nonneg _)) (fun g hg => hcoeff g)
    (fun g hg => by ring_nf; rfl)
  rw [normalized_coefficient_mass p hnorm,actual_coefficient_first_moment,mul_one] at h
  simpa only [coefficientSecondMoment,← mul_assoc,pow_two] using h

end CoefficientStability
