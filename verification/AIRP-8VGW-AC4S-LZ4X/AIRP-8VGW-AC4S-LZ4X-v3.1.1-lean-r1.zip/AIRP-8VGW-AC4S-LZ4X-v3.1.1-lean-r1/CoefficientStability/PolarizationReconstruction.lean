import CoefficientStability.HomogeneousMultilinear

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n k : ℕ}

def multilinearPolynomial (T : MultilinearMap ℝ (fun _ : Fin k => Fin n → ℝ) ℝ) :
    MvPolynomial (Fin n) ℝ :=
  ∑ f : Fin k → Fin n,C (T (fun j => Pi.single (f j) 1))*∏ j,MvPolynomial.X (f j)

theorem eval_multilinearPolynomial
    (T : MultilinearMap ℝ (fun _ : Fin k => Fin n → ℝ) ℝ) (x : Fin n → ℝ) :
    MvPolynomial.eval x (multilinearPolynomial T)=T (fun _ => x) := by
  have hx : (∑ i : Fin n,x i • (Pi.single i 1 : Fin n → ℝ))=x := by
    funext j
    simp [Finset.sum_apply,Pi.smul_apply,Pi.single_apply]
  have he := T.map_sum (fun _ (i : Fin n) => x i • (Pi.single i 1 : Fin n → ℝ))
  rw [hx] at he
  simp only [T.map_smul_univ,smul_eq_mul] at he
  unfold multilinearPolynomial
  simp only [map_sum,map_mul,MvPolynomial.eval_C,map_prod,MvPolynomial.eval_X]
  rw [he]
  apply Finset.sum_congr rfl
  intro f hf
  ring

theorem coefficientL1_X (i : Fin n) : coefficientL1 (MvPolynomial.X i : MvPolynomial (Fin n) ℝ)=1 := by
  change coefficientL1 (monomial (Finsupp.single i 1) (1 : ℝ))=1
  simp

theorem coefficientL1_C (c : ℝ) : coefficientL1 (C c : MvPolynomial (Fin n) ℝ)=|c| := by
  rw [MvPolynomial.C_apply,coefficientL1_monomial]

theorem coordinate_product_coefficientL1_le_one (f : Fin k → Fin n) (s : Finset (Fin k)) :
    coefficientL1 (∏ j ∈ s,MvPolynomial.X (f j)) ≤ 1 := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert j s hj ih =>
    rw [Finset.prod_insert hj]
    have h := coefficientL1_mul_le (MvPolynomial.X (f j)) (∏ r ∈ s,MvPolynomial.X (f r))
    rw [coefficientL1_X,one_mul] at h
    exact h.trans ih

theorem multilinearPolynomial_coefficientL1_le_sum
    (T : MultilinearMap ℝ (fun _ : Fin k => Fin n → ℝ) ℝ) :
    coefficientL1 (multilinearPolynomial T) ≤ ∑ f : Fin k → Fin n,|T (fun j => Pi.single (f j) 1)| := by
  unfold multilinearPolynomial
  apply (coefficientL1_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro f hf
  have h := coefficientL1_mul_le (C (T (fun j => Pi.single (f j) 1))) (∏ j,MvPolynomial.X (f j))
  rw [coefficientL1_C] at h
  have hp := mul_le_mul_of_nonneg_left (coordinate_product_coefficientL1_le_one f Finset.univ)
    (abs_nonneg (T (fun j => Pi.single (f j) 1)))
  exact h.trans (by simpa only [mul_one] using hp)

theorem signed_coordinate_sum_eq (f : Fin k → Fin n) (eps : Fin k → Bool) :
    (∑ j,realSign (eps j) • (Pi.single (f j) 1 : Fin n → ℝ))=polarizationPoint f eps := by
  funext i
  simp [polarizationPoint,Finset.sum_apply,Pi.smul_apply,Pi.single_apply,eq_comm]

theorem symmetrized_coordinate_eq_signedPolarization
    (h : MvPolynomial (Fin n) ℝ) (T : MultilinearMap ℝ (fun _ : Fin k => Fin n → ℝ) ℝ)
    (hT : ∀ x,T (fun _ => x)=MvPolynomial.eval x h) (f : Fin k → Fin n) :
    symmetrizedMultilinear T (fun j => Pi.single (f j) 1)=signedPolarizationCoefficient h f := by
  rw [symmetrizedMultilinear_polarization]
  simp only [signed_coordinate_sum_eq,hT,signedPolarizationCoefficient]

theorem homogeneous_polarization_reconstruction (h : MvPolynomial (Fin n) ℝ)
    (k : ℕ) (hh : h.IsHomogeneous k) :
    h=∑ f : Fin k → Fin n,C (signedPolarizationCoefficient h f)*∏ j,MvPolynomial.X (f j) := by
  obtain ⟨T,hT⟩ := homogeneous_exists_multilinear h k hh
  have he : h=multilinearPolynomial (symmetrizedMultilinear T) := by
    apply MvPolynomial.funext
    intro x
    rw [eval_multilinearPolynomial,symmetrizedMultilinear_diagonal,hT]
  apply he.trans
  unfold multilinearPolynomial
  apply Finset.sum_congr rfl
  intro f hf
  rw [symmetrized_coordinate_eq_signedPolarization h T hT]

theorem homogeneous_coefficientL1_le_signedPolarization
    (h : MvPolynomial (Fin n) ℝ) (k : ℕ) (hh : h.IsHomogeneous k) :
    coefficientL1 h ≤ ∑ f : Fin k → Fin n,|signedPolarizationCoefficient h f| := by
  obtain ⟨T,hT⟩ := homogeneous_exists_multilinear h k hh
  have he : h=multilinearPolynomial (symmetrizedMultilinear T) := by
    apply MvPolynomial.funext
    intro x
    rw [eval_multilinearPolynomial,symmetrizedMultilinear_diagonal,hT]
  have hb := multilinearPolynomial_coefficientL1_le_sum (symmetrizedMultilinear T)
  rw [← he] at hb
  simpa only [symmetrized_coordinate_eq_signedPolarization h T hT] using hb

theorem homogeneous_coefficientL1_bound_of_signedPolarization
    (h : MvPolynomial (Fin n) ℝ) (k : ℕ) (hh : h.IsHomogeneous k) (B : ℝ)
    (hB : ∀ f : Fin k → Fin n,|signedPolarizationCoefficient h f|≤B) :
    coefficientL1 h ≤ (n : ℝ)^k*B := by
  apply (homogeneous_coefficientL1_le_signedPolarization h k hh).trans
  calc
    _ ≤ ∑ _f : Fin k → Fin n,B := Finset.sum_le_sum (fun f hf => hB f)
    _ = _ := by simp [Fintype.card_fun]

end CoefficientStability
