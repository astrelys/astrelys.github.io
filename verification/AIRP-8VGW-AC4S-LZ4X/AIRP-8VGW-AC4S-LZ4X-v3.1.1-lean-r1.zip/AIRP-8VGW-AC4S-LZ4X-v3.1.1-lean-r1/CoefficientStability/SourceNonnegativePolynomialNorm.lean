import CoefficientStability.SourceNonnegativeQuadraticFactor

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

theorem source_nonnegative_real_polynomial_norm_factor (p : Polynomial ℝ)
    (hp : ∀ x : ℝ,0 ≤ p.eval x) :
    ∃ G : Polynomial ℂ,(∀ x : ℝ,p.eval x=Complex.normSq (G.eval (x : ℂ))) ∧
      2*G.natDegree ≤ p.natDegree := by
  have H : ∀ n : ℕ,∀ p : Polynomial ℝ,p.natDegree=n → (∀ x : ℝ,0 ≤ p.eval x) →
      ∃ G : Polynomial ℂ,(∀ x : ℝ,p.eval x=Complex.normSq (G.eval (x : ℂ))) ∧
        2*G.natDegree ≤ p.natDegree := by
    intro n
    induction n using Nat.strong_induction_on with
    | h n ih =>
      intro p hn hp
      by_cases hn0 : n=0
      · have hdeg : p.natDegree=0 := hn.trans hn0
        have he : p=Polynomial.C (p.coeff 0) := Polynomial.eq_C_of_natDegree_eq_zero hdeg
        have hc : 0 ≤ p.coeff 0 := by rw [Polynomial.coeff_zero_eq_eval_zero];exact hp 0
        refine ⟨Polynomial.C (Real.sqrt (p.coeff 0) : ℂ),?_,by simp⟩
        intro x
        rw [Polynomial.eval_C,Complex.normSq_ofReal]
        calc
          p.eval x=p.coeff 0 := by
            have h := congrArg (fun q : Polynomial ℝ => q.eval x) he
            simpa only [Polynomial.eval_C] using h
          _=Real.sqrt (p.coeff 0)*Real.sqrt (p.coeff 0) := (Real.mul_self_sqrt hc).symm
      · have hp0 : p≠0 := by
          intro hzero
          rw [hzero,Polynomial.natDegree_zero] at hn
          exact hn0 hn.symm
        have hdegree : p.degree≠0 := ne_of_gt ((Polynomial.natDegree_pos_iff_degree_pos).mp (by omega))
        obtain ⟨z,hz⟩ := IsAlgClosed.exists_aeval_eq_zero ℂ p hdegree
        obtain ⟨q,hqnonneg,he⟩ := source_nonnegative_polynomial_norm_quadratic_factor p hp z hz
        have hd := source_nonnegative_polynomial_norm_factor_degree p q hp0 z he
        obtain ⟨G,hG,hGdeg⟩ := ih q.natDegree (by omega) q rfl hqnonneg
        refine ⟨(Polynomial.X-Polynomial.C z)*G,?_,?_⟩
        · intro x
          rw [he,Polynomial.eval_mul,source_complex_root_norm_quadratic_norm,hG,
            Polynomial.eval_mul,Polynomial.eval_sub,Polynomial.eval_X,Polynomial.eval_C,map_mul]
        · have hg : ((Polynomial.X-Polynomial.C z)*G).natDegree ≤ 1+G.natDegree :=
            Polynomial.natDegree_mul_le.trans (by simp)
          omega
  exact H p.natDegree p rfl hp

end CoefficientStability
