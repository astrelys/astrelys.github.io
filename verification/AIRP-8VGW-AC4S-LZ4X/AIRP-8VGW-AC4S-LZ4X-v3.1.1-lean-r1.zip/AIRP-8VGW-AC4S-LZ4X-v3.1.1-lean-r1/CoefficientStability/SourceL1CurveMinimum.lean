import CoefficientStability.SourceL1CurveCalculus

noncomputable section
open scoped Topology
open Filter
namespace CoefficientStability
set_option maxHeartbeats 1600000

theorem source_square_bound_two_sided (x y : ℝ) (hy : 0 < y) (hs : x^2 < y^2) : -y < x ∧ x < y := by
  constructor
  · by_contra hh
    have hm := mul_nonneg (by linarith : 0 ≤ -x-y) (by linarith : 0 ≤ -x+y)
    nlinarith
  · by_contra hh
    have hm := mul_nonneg (by linarith : 0 ≤ x-y) (by linarith : 0 ≤ x+y)
    nlinarith

theorem source_cubic_curve_numerator_bounds (d : ℝ) (hd : 0 < d) (hd3 : d < 1/3) :
    sourceCubicN d (sourceCubicLowerRoot d)+2*Real.sqrt (sourceCubicS d (sourceCubicLowerRoot d))*sourceCubicHd d (sourceCubicLowerRoot d) < 0 ∧
      0 < sourceCubicN d (sourceCubicLowerRoot d)-2*Real.sqrt (sourceCubicS d (sourceCubicLowerRoot d))*sourceCubicHd d (sourceCubicLowerRoot d) := by
  let h := sourceCubicLowerRoot d
  let s := Real.sqrt (sourceCubicS d h)
  let L := -2*s*sourceCubicHd d h
  have hl := source_cubic_lower_root_lower_bound d hd.le hd3.le
  have hu := source_cubic_lower_root_upper_bound d hd.le hd3.le
  have hHd := source_cubic_Hd_strip_bound d h hd.le hd3.le hl hu
  have hSpos := source_cubic_S_positive d h hd (by linarith)
  have hspos : 0 < s := Real.sqrt_pos.mpr hSpos
  have hs : s^2=sourceCubicS d h := Real.sq_sqrt hSpos.le
  have hL : 0 < L := by
    have hp := mul_pos (mul_pos (by norm_num : (0 : ℝ)<2) hspos) (by linarith : 0 < -sourceCubicHd d h)
    dsimp [L]
    nlinarith
  have hW := source_cubic_certificate_W_positive d h hd hd3 hl (by linarith) (source_cubic_lower_root_zero d hd.le hd3.le)
  have hLid : L^2=4*sourceCubicS d h*(sourceCubicHd d h)^2 := by
    calc
      _ = 4*s^2*(sourceCubicHd d h)^2 := by dsimp [L];ring
      _ = _ := by rw [hs]
  have hsq : (sourceCubicN d h)^2 < L^2 := by
    rw [hLid]
    exact sub_pos.mp hW
  obtain ⟨hnlow,hnup⟩ := source_square_bound_two_sided (sourceCubicN d h) L hL hsq
  dsimp [L] at hnlow hnup
  change sourceCubicN d h+2*s*sourceCubicHd d h < 0 ∧ 0 < sourceCubicN d h-2*s*sourceCubicHd d h
  constructor <;> linarith

theorem source_cubic_curve_distance_derivative_negative (d : ℝ) (hd : 0 < d) (hd3 : d < 1/3)
    (hneg : sourceCubicLowerRoot d < 0) : deriv sourceCubicCurveDistance d < 0 := by
  have hJ := (source_cubic_curve_base_hasDerivAt d hd hd3).differentiableAt.hasDerivAt
  have hR := (source_cubic_lower_root_differentiableAt d hd hd3).hasDerivAt
  have hnear : ∀ᶠ x in 𝓝 d,sourceCubicLowerRoot x < 0 :=
    (source_cubic_lower_root_continuousAt d hd.le hd3.le).eventually (gt_mem_nhds hneg)
  have he : sourceCubicCurveDistance=ᶠ[𝓝 d] (fun x => sourceCubicCurveBase x-sourceCubicLowerRoot x) := by
    filter_upwards [hnear] with x hx
    simp only [sourceCubicCurveDistance,sourceCubicDistance,sourceCubicCurveBase,abs_of_neg hx,sub_eq_add_neg]
  have hv := ((hJ.sub hR).congr_of_eventuallyEq he).deriv
  have hJscale := source_cubic_curve_base_derivative_scaled d hd hd3
  have hRscale := source_cubic_lower_root_derivative_identity d hd hd3
  have hscale : (2*Real.sqrt (sourceCubicS d (sourceCubicLowerRoot d))*sourceCubicHh d (sourceCubicLowerRoot d))*
      deriv sourceCubicCurveDistance d=sourceCubicN d (sourceCubicLowerRoot d)+
        2*Real.sqrt (sourceCubicS d (sourceCubicLowerRoot d))*sourceCubicHd d (sourceCubicLowerRoot d) := by
    rw [hv]
    linear_combination hJscale-(2*Real.sqrt (sourceCubicS d (sourceCubicLowerRoot d)))*hRscale
  have hspos := Real.sqrt_pos.mpr (source_cubic_S_positive d (sourceCubicLowerRoot d) hd (by linarith))
  have hHh : 0 < sourceCubicHh d (sourceCubicLowerRoot d) := by
    rw [source_cubic_lower_root_Hh d hd.le hd3.le]
    exact Real.sqrt_pos.mpr (source_cubic_H_discriminant_positive d hd.le hd3.le)
  have hA : 0 < 2*Real.sqrt (sourceCubicS d (sourceCubicLowerRoot d))*sourceCubicHh d (sourceCubicLowerRoot d) := by positivity
  have hn := (source_cubic_curve_numerator_bounds d hd hd3).1
  by_contra hh
  have hm := mul_nonneg hA.le (le_of_not_gt hh)
  linarith

theorem source_cubic_curve_distance_derivative_positive (d : ℝ) (hd : 0 < d) (hd3 : d < 1/3)
    (hpos : 0 < sourceCubicLowerRoot d) : 0 < deriv sourceCubicCurveDistance d := by
  have hJ := (source_cubic_curve_base_hasDerivAt d hd hd3).differentiableAt.hasDerivAt
  have hR := (source_cubic_lower_root_differentiableAt d hd hd3).hasDerivAt
  have hnear : ∀ᶠ x in 𝓝 d,0 < sourceCubicLowerRoot x :=
    (source_cubic_lower_root_continuousAt d hd.le hd3.le).eventually (lt_mem_nhds hpos)
  have he : sourceCubicCurveDistance=ᶠ[𝓝 d] (fun x => sourceCubicCurveBase x+sourceCubicLowerRoot x) := by
    filter_upwards [hnear] with x hx
    simp only [sourceCubicCurveDistance,sourceCubicDistance,sourceCubicCurveBase,abs_of_pos hx]
  have hv := ((hJ.add hR).congr_of_eventuallyEq he).deriv
  have hJscale := source_cubic_curve_base_derivative_scaled d hd hd3
  have hRscale := source_cubic_lower_root_derivative_identity d hd hd3
  have hscale : (2*Real.sqrt (sourceCubicS d (sourceCubicLowerRoot d))*sourceCubicHh d (sourceCubicLowerRoot d))*
      deriv sourceCubicCurveDistance d=sourceCubicN d (sourceCubicLowerRoot d)-
        2*Real.sqrt (sourceCubicS d (sourceCubicLowerRoot d))*sourceCubicHd d (sourceCubicLowerRoot d) := by
    rw [hv]
    linear_combination hJscale+(2*Real.sqrt (sourceCubicS d (sourceCubicLowerRoot d)))*hRscale
  have hspos := Real.sqrt_pos.mpr (source_cubic_S_positive d (sourceCubicLowerRoot d) hd (by linarith))
  have hHh : 0 < sourceCubicHh d (sourceCubicLowerRoot d) := by
    rw [source_cubic_lower_root_Hh d hd.le hd3.le]
    exact Real.sqrt_pos.mpr (source_cubic_H_discriminant_positive d hd.le hd3.le)
  have hA : 0 < 2*Real.sqrt (sourceCubicS d (sourceCubicLowerRoot d))*sourceCubicHh d (sourceCubicLowerRoot d) := by positivity
  have hn := (source_cubic_curve_numerator_bounds d hd hd3).2
  by_contra hh
  have hm := mul_nonpos_of_nonneg_of_nonpos hA.le (le_of_not_gt hh)
  linarith

theorem source_cubic_curve_distance_strictAntiBefore :
    StrictAntiOn sourceCubicCurveDistance (Set.Icc (0 : ℝ) sourceCubicDStar) := by
  obtain ⟨hs,hs3⟩ := source_cubic_dstar_bounds
  apply strictAntiOn_of_deriv_neg (convex_Icc 0 sourceCubicDStar)
    (source_cubic_curve_distance_continuousOn.mono (fun x hx => ⟨hx.1,hx.2.trans hs3.le⟩))
  intro d hd
  have hi : d ∈ Set.Ioo (0 : ℝ) sourceCubicDStar := by simpa only [interior_Icc] using hd
  have hd3 : d < 1/3 := hi.2.trans hs3
  have hneg := source_cubic_lower_root_strictMonoOn ⟨hi.1.le,hd3.le⟩ ⟨hs.le,hs3.le⟩ hi.2
  rw [source_cubic_lower_root_dstar] at hneg
  exact source_cubic_curve_distance_derivative_negative d hi.1 hd3 hneg

theorem source_cubic_curve_distance_strictMonoAfter :
    StrictMonoOn sourceCubicCurveDistance (Set.Icc sourceCubicDStar (1/3 : ℝ)) := by
  obtain ⟨hs,hs3⟩ := source_cubic_dstar_bounds
  apply strictMonoOn_of_deriv_pos (convex_Icc sourceCubicDStar (1/3))
    (source_cubic_curve_distance_continuousOn.mono (fun x hx => ⟨hs.le.trans hx.1,hx.2⟩))
  intro d hd
  have hi : d ∈ Set.Ioo sourceCubicDStar (1/3 : ℝ) := by simpa only [interior_Icc] using hd
  have hd0 : 0 < d := hs.trans hi.1
  have hpos := source_cubic_lower_root_strictMonoOn ⟨hs.le,hs3.le⟩ ⟨hd0.le,hi.2.le⟩ hi.1
  rw [source_cubic_lower_root_dstar] at hpos
  exact source_cubic_curve_distance_derivative_positive d hd0 hi.2 hpos

theorem source_cubic_zero_curve_distance_minimum (d : ℝ) (hd : 0 ≤ d) (hd3 : d ≤ 1/3) :
    sourceCubicEpsilon0 ≤ sourceCubicCurveDistance d ∧
      (sourceCubicCurveDistance d=sourceCubicEpsilon0 ↔ d=sourceCubicDStar) := by
  obtain ⟨hs,hs3⟩ := source_cubic_dstar_bounds
  have hstar : sourceCubicCurveDistance sourceCubicDStar=sourceCubicEpsilon0 := by
    unfold sourceCubicCurveDistance
    rw [source_cubic_lower_root_dstar]
    exact source_cubic_dstar_distance_exact
  have hstrict : d≠sourceCubicDStar → sourceCubicEpsilon0 < sourceCubicCurveDistance d := by
    intro hne
    rcases lt_or_gt_of_ne hne with hlt | hgt
    · have h := source_cubic_curve_distance_strictAntiBefore ⟨hd,hlt.le⟩ ⟨hs.le,le_rfl⟩ hlt
      rwa [hstar] at h
    · have h := source_cubic_curve_distance_strictMonoAfter ⟨le_rfl,hs3.le⟩ ⟨hgt.le,hd3⟩ hgt
      rwa [hstar] at h
  refine ⟨?_,?_⟩
  · by_cases he : d=sourceCubicDStar
    · rw [he,hstar]
    · exact (hstrict he).le
  · constructor
    · intro he
      by_contra hne
      have hh := hstrict hne
      linarith
    · intro he
      simpa only [he] using hstar

end CoefficientStability
