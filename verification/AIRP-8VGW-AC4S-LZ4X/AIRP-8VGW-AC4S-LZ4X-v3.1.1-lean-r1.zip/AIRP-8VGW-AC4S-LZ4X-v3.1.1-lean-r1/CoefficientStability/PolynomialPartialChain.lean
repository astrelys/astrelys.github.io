import CoefficientStability.CoordinatePolynomial

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem polynomial_eval₂_partial (i : Fin n) (P : Polynomial (MvPolynomial (Fin n) ℝ))
    (hc : ∀ k,pderiv i (P.coeff k)=0) (f : MvPolynomial (Fin n) ℝ) :
    pderiv i (P.eval₂ (RingHom.id _) f)=
      P.derivative.eval₂ (RingHom.id _) f*pderiv i f := by
  classical
  conv_lhs => rw [Polynomial.eval₂_eq_sum]
  simp only [Polynomial.sum,RingHom.id_apply,map_sum,pderiv_mul,pderiv_pow,hc,zero_mul,zero_add]
  rw [Polynomial.derivative_apply,Polynomial.eval₂_sum,Polynomial.sum,Finset.sum_mul]
  simp only [Polynomial.eval₂_mul,Polynomial.eval₂_C,Polynomial.eval₂_pow,Polynomial.eval₂_X,RingHom.id_apply]
  apply Finset.sum_congr rfl
  intro k hk
  ring

theorem polynomial_derivative_coeff_partial_zero (i : Fin n)
    (P : Polynomial (MvPolynomial (Fin n) ℝ)) (hc : ∀ k,pderiv i (P.coeff k)=0) :
    ∀ k,pderiv i (P.derivative.coeff k)=0 := by
  intro k
  simp [Polynomial.coeff_derivative,pderiv_mul,hc]

theorem polynomial_iterate_derivative_coeff_partial_zero (i : Fin n)
    (P : Polynomial (MvPolynomial (Fin n) ℝ)) (hc : ∀ k,pderiv i (P.coeff k)=0) (k : ℕ) :
    ∀ j,pderiv i ((Polynomial.derivative^[k] P).coeff j)=0 := by
  induction k with
  | zero => exact hc
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    exact polynomial_derivative_coeff_partial_zero i _ ih

theorem polynomial_iterate_derivative_at_bound {A : Type*} [CommRing A]
    (P : Polynomial A) (d : ℕ) (hd : P.natDegree≤d) :
    Polynomial.derivative^[d] P=Polynomial.C ((d.factorial : A)*P.coeff d) := by
  classical
  ext k
  by_cases hk : k=0
  · subst k
    simp [Polynomial.coeff_iterate_derivative,Nat.descFactorial_self,nsmul_eq_mul]
  · rw [Polynomial.coeff_iterate_derivative,Polynomial.coeff_eq_zero_of_natDegree_lt]
    · simp [Polynomial.coeff_C,hk]
    · omega

theorem signed_polynomial_eval_iterate_partial (i : Fin n)
    (P : Polynomial (MvPolynomial (Fin n) ℝ)) (hc : ∀ j,pderiv i (P.coeff j)=0) (k : ℕ) :
    (pderiv i)^[k] (P.eval₂ (RingHom.id _) (-MvPolynomial.X i))=
      (-1 : MvPolynomial (Fin n) ℝ)^k*
        (Polynomial.derivative^[k] P).eval₂ (RingHom.id _) (-MvPolynomial.X i) := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [Function.iterate_succ_apply',ih,pderiv_mul]
    have hcoef := polynomial_iterate_derivative_coeff_partial_zero i P hc k
    rw [polynomial_eval₂_partial i _ hcoef]
    simp only [pderiv_pow,map_neg,pderiv_one,neg_zero,mul_zero,zero_mul,zero_add,pderiv_X_self]
    rw [Function.iterate_succ_apply']
    ring

theorem stable_iterate_partial_zero_or_stable (p : MvPolynomial (Fin n) ℝ)
    (hp : UpperHalfPlaneZeroFree p) (i : Fin n) (k : ℕ) :
    (pderiv i)^[k] p=0 ∨ UpperHalfPlaneZeroFree ((pderiv i)^[k] p) := by
  induction k with
  | zero => exact Or.inr hp
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    rcases ih with hz | hs
    · left
      simp [hz]
    · exact stable_partial_zero_or_stable _ hs i

end CoefficientStability
