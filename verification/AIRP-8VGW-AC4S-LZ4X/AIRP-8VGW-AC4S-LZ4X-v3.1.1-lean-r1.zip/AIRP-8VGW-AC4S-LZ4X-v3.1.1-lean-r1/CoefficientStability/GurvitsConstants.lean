import CoefficientStability.CapacityGMonotonicity
import CoefficientStability.PaperRatioGradient

noncomputable section
namespace CoefficientStability

theorem capacityG_strict_pos (n : ℕ) : 0<capacityG n := by
  by_cases hn : 2≤n
  · exact capacityG_pos hn
  · interval_cases n <;> norm_num [capacityG]

theorem sourceVn_nonneg (n : ℕ) : 0≤sourceVn n := by
  exact div_nonneg (by positivity) (pow_nonneg (Nat.cast_nonneg n) _)

theorem sourceVn_zero : sourceVn 0=1 := by norm_num [sourceVn]

theorem sourceVn_capacityG_recurrence (n : ℕ) : sourceVn (n+1)=sourceVn n*capacityG (n+1) := by
  by_cases hn : n=0
  · subst n
    norm_num [sourceVn,capacityG]
  · have hnr : (n : ℝ)≠0 := by exact_mod_cast hn
    have hn1 : (n : ℝ)+1≠0 := by positivity
    simp only [sourceVn,capacityG,Nat.add_sub_cancel,Nat.factorial_succ,Nat.cast_mul,
      Nat.cast_add,Nat.cast_one,add_sub_cancel_right,div_pow,pow_succ]
    field_simp

end CoefficientStability
