import CoefficientStability.TwoFactorSourceCurve

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem coefficientL1_C_mul (c : ℝ) (p : MvPolynomial (Fin n) ℝ) :
    coefficientL1 (MvPolynomial.C c*p)=|c| *coefficientL1 p := by
  classical
  have hs : (MvPolynomial.C c*p).support ⊆ p.support := by
    intro g hg
    by_contra hnot
    have hp0 := MvPolynomial.notMem_support_iff.mp hnot
    have hz : (MvPolynomial.C c*p).coeff g=0 := by rw [MvPolynomial.coeff_C_mul,hp0,mul_zero]
    exact MvPolynomial.mem_support_iff.mp hg hz
  rw [coefficientL1_eq_sum_on _ _ hs]
  simp only [MvPolynomial.coeff_C_mul,abs_mul,coefficientL1,Finset.mul_sum]

theorem twoFactorSourcePolynomial_coefficient_distance (t v : Fin (n+2) → ℝ) (s : ℝ) :
    coefficientL1 (twoFactorSourcePolynomial t v s-scalarPower t (n+2))=
      s^2*coefficientL1 ((scalarLinear t (n+2))^n*(scalarLinear v 1)^2) := by
  rw [twoFactorSourcePolynomial_exact_deviation,neg_mul,coefficientL1_neg,coefficientL1_C_mul,
    abs_of_nonneg (sq_nonneg s)]

theorem twoFactorSourcePolynomial_coefficient_gap (t v : Fin (n+2) → ℝ) (s : ℝ) :
    (twoFactorSourcePolynomial t v s).coeff (squarefreeExponent (n+2))-
      (scalarPower t (n+2)).coeff (squarefreeExponent (n+2))=
      -s^2*((scalarLinear t (n+2))^n*(scalarLinear v 1)^2).coeff (squarefreeExponent (n+2)) := by
  have h := congrArg (fun p : MvPolynomial (Fin (n+2)) ℝ => p.coeff (squarefreeExponent (n+2)))
    (twoFactorSourcePolynomial_exact_deviation t v s)
  rw [neg_mul] at h
  simpa only [AddMonoidAlgebra.coeff_neg,Finsupp.neg_apply,MvPolynomial.coeff_C_mul,
    AddMonoidAlgebra.coeff_sub,Finsupp.sub_apply,neg_mul] using h

theorem scalarLinear_one_ne_zero (v : Fin n → ℝ) (hv : v≠0) : scalarLinear v 1≠0 := by
  intro hz
  apply hv
  funext i
  have h := congrArg (MvPolynomial.eval (fun _ => (1 : ℝ))) (congrArg (MvPolynomial.pderiv i) hz)
  simpa only [pderiv_scalarLinear,Nat.cast_one,div_one,map_zero,MvPolynomial.eval_C,Pi.zero_apply] using h

theorem source_quadratic_defect_norm_pos (t v : Fin (n+2) → ℝ)
    (ht : (∑ i,t i)=(n+2 : ℝ)) (hv : v≠0) :
    0 < coefficientL1 ((scalarLinear t (n+2))^n*(scalarLinear v 1)^2) := by
  have ht0 : scalarLinear t (n+2)≠0 := by
    intro hz
    have he := eval_one_scalarLinear t (n+2) (by omega) (by simpa only [Nat.cast_add,Nat.cast_ofNat] using ht)
    rw [hz,map_zero] at he
    norm_num at he
  have hv0 := scalarLinear_one_ne_zero v hv
  have hq : (scalarLinear t (n+2))^n*(scalarLinear v 1)^2≠0 := mul_ne_zero (pow_ne_zero _ ht0) (pow_ne_zero _ hv0)
  by_contra hh
  exact hq (coefficientL1_nonpos_zero _ (le_of_not_gt hh))

end CoefficientStability
