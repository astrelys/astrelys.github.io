import CoefficientStability.SourceCubicComplementarity

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 1800000
set_option backward.isDefEq.respectTransparency false

theorem source_cubic_multiplier_commutes (t μ : ℝ) (X H S : Matrix (Fin 3) (Fin 3) ℂ)
    (hcert : sourceCubicMatrixGradient t X=H+(μ : ℂ) • 1+S)
    (hSX : S*X=0) (hXS : X*S=0) : H*X=X*H := by
  have hl := congrArg (fun M => M*X) hcert
  have hr := congrArg (fun M => X*M) hcert
  simp only [sourceCubicMatrixGradient,add_mul,mul_add,smul_mul_assoc,mul_smul_comm,one_mul,mul_one,hSX,hXS,add_zero] at hl hr
  have hp : X^2*X=X*X^2 := by noncomm_ring
  rw [hp] at hl
  exact add_right_cancel (hl.symm.trans hr)

theorem source_diagonal_simple_multiplier_forces_diagonal {n : ℕ} (d : Fin n → ℂ)
    (hd : Function.Injective d) (X : Matrix (Fin n) (Fin n) ℂ)
    (hcomm : Matrix.diagonal d*X=X*Matrix.diagonal d) : X=Matrix.diagonal (Matrix.diag X) := by
  ext i j
  by_cases hij : i=j
  · subst j
    simp
  · have h := congrFun (congrFun hcomm i) j
    simp only [Matrix.diagonal_mul,Matrix.mul_diagonal] at h
    have hn : d i-d j≠0 := sub_ne_zero.mpr (fun he => hij (hd he))
    have hz : (d i-d j)*X i j=0 := by linear_combination h
    have he := (mul_eq_zero.mp hz).resolve_left hn
    simp [Matrix.diagonal_apply,hij,he]

theorem source_simple_multiplier_pairwise_commutation {n : ℕ} (d : Fin n → ℂ)
    (hd : Function.Injective d) (A : Fin 3 → Matrix (Fin n) (Fin n) ℂ)
    (hcomm : ∀ i,Matrix.diagonal d*A i=A i*Matrix.diagonal d) :
    ∀ i j,A i*A j=A j*A i := by
  intro i j
  rw [source_diagonal_simple_multiplier_forces_diagonal d hd (A i) (hcomm i),
    source_diagonal_simple_multiplier_forces_diagonal d hd (A j) (hcomm j)]
  rw [Matrix.diagonal_mul_diagonal,Matrix.diagonal_mul_diagonal]
  congr 1
  funext k
  exact mul_comm _ _

end CoefficientStability
