import CoefficientStability.FactoredCoordinateCovariance

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n m : ℕ}

theorem centeredLogVector_coordinate_exp_path (x : Fin n → ℝ) (hx : ∀ j,0<x j)
    (i : Fin n) (s : ℝ) :
    (fun j => Real.exp ((centeredLogVector x+s • (Pi.single i (1 : ℝ) : Fin n → ℝ) : Fin n → ℝ) j))=
      (fun j => Real.exp (-(∑ k,Real.log (x k))/(n : ℝ))*(Function.update x i (x i*Real.exp s)) j) := by
  classical
  funext j
  by_cases hji : j=i
  · subst j
    simp only [Pi.add_apply,Pi.smul_apply,smul_eq_mul,Pi.single_eq_same,mul_one,Real.exp_add,
      centeredLogVector_exp x hx,Function.update_self]
    ring
  · simp only [Pi.add_apply,Pi.smul_apply,smul_eq_mul,Pi.single_eq_of_ne hji,mul_zero,add_zero,
      Function.update_of_ne hji,centeredLogVector_exp x hx]

theorem centered_coordinate_partition (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (x : Fin n → ℝ) (hx : ∀ j,0<x j) (i : Fin n) (s : ℝ) :
    tiltPartition p (centeredLogVector x+s • Pi.single i 1)=
      (Real.exp (-(∑ k,Real.log (x k))/(n : ℝ)))^n*
        (realCoordinateRestriction x i p).eval (x i*Real.exp s) := by
  rw [tiltPartition_eval_exp_all,centeredLogVector_coordinate_exp_path x hx i s,
    homogeneous_eval_real_scale p n hp,realCoordinateRestriction_eval]

theorem centered_positive_factor_partition (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (x : Fin n → ℝ) (hx : ∀ j,0<x j) (i : Fin n)
    (b : Fin m → ℝ)
    (hf : ∀ t : ℝ,(realCoordinateRestriction x i p).eval t=
      (realCoordinateRestriction x i p).eval 0*∏ j,(1+b j*t)) :
    ∀ s : ℝ,tiltPartition p (centeredLogVector x+s • Pi.single i 1)=
      ((Real.exp (-(∑ k,Real.log (x k))/(n : ℝ)))^n*(realCoordinateRestriction x i p).eval 0)*
        ∏ j,(1+b j*x i*Real.exp s) := by
  intro s
  rw [centered_coordinate_partition p hp x hx i s,hf]
  simp only [mul_assoc]

theorem centered_positive_factor_covariance (p : MvPolynomial (Fin n) ℝ)
    (hp : p.IsHomogeneous n) (x : Fin n → ℝ) (hx : ∀ j,0<x j) (i : Fin n)
    (hzero : 0<(realCoordinateRestriction x i p).eval 0)
    (b : Fin m → ℝ) (hb : ∀ j,0<b j)
    (hf : ∀ t : ℝ,(realCoordinateRestriction x i p).eval t=
      (realCoordinateRestriction x i p).eval 0*∏ j,(1+b j*t)) :
    coefficientCovariance (tiltedPolynomial p (centeredLogVector x))
      (tiltedMoment p (centeredLogVector x)) i i=
      ∑ j,(b j*x i/(1+b j*x i)-(b j*x i/(1+b j*x i))^2) := by
  exact factored_coordinate_covariance p (centeredLogVector x) i _ (x i)
    (mul_pos (pow_pos (Real.exp_pos _) _) hzero) (hx i) b hb
    (centered_positive_factor_partition p hp x hx i b hf)

theorem centered_stationary_deficit_factor_identity (hn : 0<n)
    (p : MvPolynomial (Fin n) ℝ) (hp : p.IsHomogeneous n) (x : Fin n → ℝ)
    (hx : ∀ j,0<x j) (i : Fin n) (hzero : 0<(realCoordinateRestriction x i p).eval 0)
    (b : Fin m → ℝ) (hb : ∀ j,0<b j)
    (hf : ∀ t : ℝ,(realCoordinateRestriction x i p).eval t=
      (realCoordinateRestriction x i p).eval 0*∏ j,(1+b j*t))
    (hstat : tiltedMoment p (centeredLogVector x) i=1) :
    deficitMatrix (tiltedPolynomial p (centeredLogVector x))
      (tiltedMoment p (centeredLogVector x)) n i i=
      ((∑ j,(b j*x i/(1+b j*x i))^2)-1/(n : ℝ))/2 := by
  have hfactor := centered_positive_factor_partition p hp x hx i b hf
  have hC : 0<(Real.exp (-(∑ k,Real.log (x k))/(n : ℝ)))^n*(realCoordinateRestriction x i p).eval 0 :=
    mul_pos (pow_pos (Real.exp_pos _) _) hzero
  have hZ : tiltPartition p (centeredLogVector x)≠0 := by
    have h := hfactor 0
    simp only [zero_smul,add_zero,Real.exp_zero,mul_one] at h
    rw [h]
    exact ne_of_gt (mul_pos hC (Finset.prod_pos (fun j hj => by
      have hbj := hb j
      have hxi := hx i
      positivity)))
  have hsum := factored_coordinate_tiltedMoment p (centeredLogVector x) i _ (x i) hC (hx i) b hb hfactor 0
  simp only [zero_smul,add_zero,Real.exp_zero,mul_one,hstat] at hsum
  have hcov := centered_positive_factor_covariance p hp x hx i hzero b hb hf
  rw [Finset.sum_sub_distrib,← hsum] at hcov
  have hQ := actual_tilt_covariance_deficit p (centeredLogVector x) hn hZ i i
  rw [hstat] at hQ
  simp only [ite_true,mul_one] at hQ
  rw [hcov] at hQ
  linarith only [hQ]

end CoefficientStability
