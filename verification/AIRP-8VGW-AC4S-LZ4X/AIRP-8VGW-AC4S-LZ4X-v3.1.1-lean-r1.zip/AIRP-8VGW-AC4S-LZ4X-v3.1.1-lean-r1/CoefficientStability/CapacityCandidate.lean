import CoefficientStability.CapacityVarianceProjection

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def capacityG (n : ℕ) : ℝ := (((n : ℝ)-1)/(n : ℝ))^(n-1)

theorem capacityG_pos (hn : 2≤n) : 0<capacityG n := by
  have hn' : (2 : ℝ)≤n := by exact_mod_cast hn
  apply pow_pos
  exact div_pos (by linarith) (by linarith)

theorem positive_vector_sum_pos (b : Fin n → ℝ) (hn : 0<n) (hb : ∀ i,0<b i) : 0<∑ i,b i := by
  let i : Fin n := ⟨0,hn⟩
  exact lt_of_lt_of_le (hb i) (Finset.single_le_sum (fun j hj => (hb j).le) (Finset.mem_univ i))

theorem normalized_positive_vector_sum (b : Fin n → ℝ) (hS : (∑ i,b i)≠0) :
    (∑ i,b i/(∑ j,b j))=1 := by rw [← Finset.sum_div];exact div_self hS

theorem capacity_candidate_identity (c : ℝ) (b : Fin n → ℝ) (hn : 2≤n)
    (hb : ∀ i,0<b i) :
    let S0 := ∑ i,b i
    let z0 := (n : ℝ)/(((n : ℝ)-1)*S0)
    capacityG n*((c*∏ i,(1+b i*z0))/z0)=
      c*S0*(∏ i,(1+b i/S0-1/(n : ℝ))) := by
  dsimp only
  let S0 := ∑ i,b i
  let a := (n : ℝ)/((n : ℝ)-1)
  have hn' : (2 : ℝ)≤n := by exact_mod_cast hn
  have hn0 : (n : ℝ)≠0 := by linarith
  have hn1 : (n : ℝ)-1≠0 := by linarith
  have hS0 : S0≠0 := ne_of_gt (positive_vector_sum_pos b (by omega) hb)
  have ha : a≠0 := div_ne_zero hn0 hn1
  have hz : (n : ℝ)/(((n : ℝ)-1)*(∑ i,b i))=a/S0 := by change (n : ℝ)/(((n : ℝ)-1)*S0)=((n : ℝ)/((n : ℝ)-1))/S0;rw [div_div]
  have hfactor (i : Fin n) : 1+b i*(a/S0)=a*(1+b i/S0-1/(n : ℝ)) := by
    dsimp [a]
    field_simp
    ring
  have hpow : capacityG n*a^(n-1)=1 := by
    rw [capacityG,← mul_pow]
    have he : (((n : ℝ)-1)/(n : ℝ))*a=1 := by dsimp [a];field_simp
    rw [he,one_pow]
  have hpowN : a^n=a^(n-1)*a := by
    rw [← pow_succ]
    congr 1
    omega
  rw [hz]
  simp only [hfactor,Finset.prod_mul_distrib,Finset.prod_const,Finset.card_univ,Fintype.card_fin,hpowN]
  change capacityG n*(c*(a^(n-1)*a*(∏ i,(1+b i/S0-1/(n : ℝ))))/(a/S0))=_
  have hcalc (G P : ℝ) : G*(c*(a^(n-1)*a*P)/(a/S0))=(G*a^(n-1))*(c*S0*P) := by
    field_simp [ha,hS0] <;> ring
  calc
    _ = (capacityG n*a^(n-1))*(c*S0*(∏ i,(1+b i/S0-1/(n : ℝ)))) := hcalc _ _
    _ = _ := by rw [hpow,one_mul]

end CoefficientStability
