import Mathlib.Analysis.Convex.Deriv
import Mathlib.Analysis.Calculus.Deriv.Pow

noncomputable section
open scoped Topology
namespace CoefficientStability

theorem scalar_strong_coercivity_segment (f d dd : ℝ → ℝ) (A : ℝ)
    (hf : ∀ s,HasDerivAt f (d s) s) (hd : ∀ s,HasDerivAt d (dd s) s)
    (hA : ∀ s∈Set.Icc (0 : ℝ) 1,A≤dd s) (hf0 : f 0=0) (hd0 : d 0=0) :
    A/2≤f 1 := by
  have hg (s : ℝ) : HasDerivAt (fun z : ℝ => d z-A*z) (dd s-A) s := by
    have hlinear : HasDerivAt (fun z : ℝ => A*z) A s := by
      simpa only [id_eq,mul_one] using (hasDerivAt_id s).const_mul A
    change HasDerivAt (d-(fun z : ℝ => A*z)) (dd s-A) s
    exact (hd s).sub hlinear
  have hgC : Continuous (fun z : ℝ => d z-A*z) :=
    continuous_iff_continuousAt.mpr (fun s => (hg s).continuousAt)
  have hgM : MonotoneOn (fun z : ℝ => d z-A*z) (Set.Icc (0 : ℝ) 1) :=
    monotoneOn_of_hasDerivWithinAt_nonneg (convex_Icc 0 1) hgC.continuousOn
      (fun s hs => (hg s).hasDerivWithinAt)
      (fun s hs => sub_nonneg.mpr (hA s (interior_subset hs)))
  have hfirst (s : ℝ) (hs : s∈Set.Icc (0 : ℝ) 1) : A*s≤d s := by
    have h := hgM (by constructor <;> norm_num) hs hs.1
    simp only [hd0,mul_zero,sub_self] at h
    linarith
  have hH (s : ℝ) : HasDerivAt (fun z : ℝ => f z-(A/2)*z^2) (d s-A*s) s := by
    have hpower : HasDerivAt (fun z : ℝ => (A/2)*z^2) ((A/2)*(2*s)) s := by
      simpa only [Nat.cast_ofNat,Nat.reduceSub,pow_one] using (hasDerivAt_pow 2 s).const_mul (A/2)
    have he : (A/2)*(2*s)=A*s := by ring
    rw [he] at hpower
    change HasDerivAt (f-(fun z : ℝ => (A/2)*z^2)) (d s-A*s) s
    exact (hf s).sub hpower
  have hHC : Continuous (fun z : ℝ => f z-(A/2)*z^2) :=
    continuous_iff_continuousAt.mpr (fun s => (hH s).continuousAt)
  have hHM : MonotoneOn (fun z : ℝ => f z-(A/2)*z^2) (Set.Icc (0 : ℝ) 1) :=
    monotoneOn_of_hasDerivWithinAt_nonneg (convex_Icc 0 1) hHC.continuousOn
      (fun s hs => (hH s).hasDerivWithinAt)
      (fun s hs => sub_nonneg.mpr (hfirst s (interior_subset hs)))
  have h := hHM (by constructor <;> norm_num) (by constructor <;> norm_num) (by norm_num : (0 : ℝ)≤1)
  norm_num only [hf0,zero_pow (by norm_num : (2 : ℕ)≠0),mul_zero,sub_self,one_pow,mul_one] at h
  linarith

end CoefficientStability
