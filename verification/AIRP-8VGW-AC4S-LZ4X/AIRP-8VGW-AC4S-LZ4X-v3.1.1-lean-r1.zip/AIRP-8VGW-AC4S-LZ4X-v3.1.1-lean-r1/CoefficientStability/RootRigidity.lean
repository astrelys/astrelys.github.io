import CoefficientStability.MatrixVariance
import Mathlib.Analysis.Matrix.PosDef
import Mathlib.Algebra.MvPolynomial.Funext

noncomputable section
open scoped BigOperators
open Polynomial MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem centeredVariance_zero_roots_equal (roots : Multiset ℝ)
    (h : centeredVariance roots = 0) : ∀ r ∈ roots, r = roots.sum / roots.card := by
  have hs : ((centeredRoots roots).map (fun r => r^2)).sum = 0 := by
    unfold centeredVariance at h
    linarith
  have hnonneg : ∀ r ∈ (centeredRoots roots).map (fun r => r^2), (0 : ℝ) ≤ r := by
    intro r hr
    obtain ⟨a,ha,rfl⟩ := Multiset.mem_map.mp hr
    exact sq_nonneg a
  have hall := Multiset.all_zero_of_le_zero_le_of_sum_eq_zero hnonneg hs
  intro r hr
  have hm : r-roots.sum/roots.card ∈ centeredRoots roots :=
    Multiset.mem_map.mpr ⟨r,hr,rfl⟩
  have hz := hall ((r-roots.sum/roots.card)^2) (Multiset.mem_map.mpr ⟨_,hm,rfl⟩)
  nlinarith

theorem realFactorPolynomial_eq_power (roots : Multiset ℝ) (a : ℝ)
    (h : ∀ r ∈ roots, r=a) : realFactorPolynomial roots = (Polynomial.X+Polynomial.C a)^roots.card := by
  unfold realFactorPolynomial
  have he : roots.map (fun r => Polynomial.X+Polynomial.C r) =
      roots.map (fun _ => Polynomial.X+Polynomial.C a) := by
    apply Multiset.map_congr rfl
    intro r hr
    rw [h r hr]
  rw [he]
  simp

theorem eval_lineRestriction_real (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ) (s : ℝ) :
    Polynomial.eval s (lineRestriction p x) = MvPolynomial.eval (fun i => s+x i) p := by
  change (Polynomial.eval₂RingHom (RingHom.id ℝ) s)
      (MvPolynomial.eval₂ Polynomial.C (fun i => Polynomial.X+Polynomial.C (x i)) p) = _
  rw [MvPolynomial.hom_eval₂]
  simp

theorem factorization_root_sum (p : MvPolynomial (Fin n) ℝ) (x : Fin n → ℝ)
    (N : ℕ) (hN : 0 < N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) (roots : Multiset ℝ)
    (hr : lineRestriction p x = realFactorPolynomial roots) :
    roots.sum = ∑ i, MvPolynomial.eval (fun _ => 1) (pderiv i p)*x i := by
  have he : (lineRestriction p x).nextCoeff = roots.sum := by
    rw [hr, realFactorPolynomial,
      Polynomial.Monic.nextCoeff_multiset_prod _ _ (fun r _ => Polynomial.monic_X_add_C r)]
    simp [Polynomial.nextCoeff_X_add_C]
  have hd := normalized_lineRestriction_natDegree p x N hp hnorm
  have hpos : 0 < (lineRestriction p x).natDegree := by omega
  rw [← he, Polynomial.nextCoeff_of_natDegree_pos hpos, hd,
    lineRestriction_next_coefficient p x N hN hp]

theorem deficitMatrix_zero_implies_scalarPower
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ)
    (hN : 2 ≤ N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p) = t i)
    (hQ : deficitMatrix p t N = 0) : p = scalarPower t N := by
  apply MvPolynomial.funext
  intro x
  obtain ⟨roots,hcard,hr,hv⟩ := deficitMatrix_quadratic_is_rootVariance p t N x hN hp hnorm hstable hgrad
  have hzero : centeredVariance roots = 0 := by simpa [hQ, matrixQuadratic] using hv
  have halleq := centeredVariance_zero_roots_equal roots hzero
  have hsum := factorization_root_sum p x N (by omega) hp hnorm roots hr
  simp only [hgrad] at hsum
  have hpoly := realFactorPolynomial_eq_power roots (roots.sum/roots.card) halleq
  have hpval : MvPolynomial.eval x p = (roots.sum/roots.card)^roots.card := by
    have he := congrArg (Polynomial.eval 0) (hr.trans hpoly)
    simpa [eval_lineRestriction_real] using he
  rw [hpval, hcard, hsum]
  simp only [scalarPower, map_pow, scalarLinear, map_sum, map_mul, MvPolynomial.eval_C, MvPolynomial.eval_X]
  congr 1
  rw [div_eq_mul_inv, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro i hi
  ring

theorem referenceDeficit_zero_iff_scalarPower
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ)
    (hN : 2 ≤ N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) (hstable : UpperHalfPlaneZeroFree p)
    (ht : ∑ i, t i=N) (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p) = t i) :
    referenceDeficit p t N = 0 ↔ p=scalarPower t N := by
  constructor
  · intro hz
    have hpsd := deficitMatrix_posSemidef p t N hN hp hnorm hstable hgrad
    have htrace : Matrix.trace (deficitMatrix p t N) = 0 := by rw [trace_deficitMatrix, hz]
    exact deficitMatrix_zero_implies_scalarPower p t N hN hp hnorm hstable hgrad
      (hpsd.trace_eq_zero_iff.mp htrace)
  · intro hpure
    rw [referenceDeficit_eq_centered_coefficientDeficit p t N hN ht, hpure, sub_self]
    simp [coefficientDeficit]

theorem referenceDeficit_nonneg
    (p : MvPolynomial (Fin n) ℝ) (t : Fin n → ℝ) (N : ℕ)
    (hN : 2 ≤ N) (hp : p.IsHomogeneous N)
    (hnorm : MvPolynomial.eval (fun _ => 1) p = 1) (hstable : UpperHalfPlaneZeroFree p)
    (hgrad : ∀ i, MvPolynomial.eval (fun _ => 1) (pderiv i p) = t i) :
    0 ≤ referenceDeficit p t N := by
  rw [← trace_deficitMatrix]
  exact (deficitMatrix_posSemidef p t N hN hp hnorm hstable hgrad).trace_nonneg

end CoefficientStability
