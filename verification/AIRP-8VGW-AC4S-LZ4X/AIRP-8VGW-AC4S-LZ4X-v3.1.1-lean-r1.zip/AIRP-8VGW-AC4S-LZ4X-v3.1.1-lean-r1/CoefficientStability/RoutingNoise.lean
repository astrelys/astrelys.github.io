import CoefficientStability.CategoricalVariance
import Mathlib.Analysis.Complex.ExponentialBounds

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

def routingDenominator (M : Matrix (Fin n) (Fin n) ℝ) (u : Fin n → ℝ) (i : Fin n) : ℝ :=
  ∑ j,M i j*Real.exp (u j)

def routingProbability (M : Matrix (Fin n) (Fin n) ℝ) (u : Fin n → ℝ) (i j : Fin n) : ℝ :=
  M i j*Real.exp (u j)/routingDenominator M u i

theorem routingDenominator_bounds (M : Matrix (Fin n) (Fin n) ℝ) (u : Fin n → ℝ)
    (i : Fin n) (hM : ∀ j,0≤M i j) (hrow : ∑ j,M i j=1) (hu : ∀ j,|u j|≤1) :
    Real.exp (-1)≤routingDenominator M u i ∧ routingDenominator M u i≤Real.exp 1 := by
  have hlo (j : Fin n) : Real.exp (-1)≤Real.exp (u j) :=
    Real.exp_le_exp.mpr ((abs_le.mp (hu j)).1)
  have hhi (j : Fin n) : Real.exp (u j)≤Real.exp 1 :=
    Real.exp_le_exp.mpr ((abs_le.mp (hu j)).2)
  constructor
  · calc
      _ = ∑ j,M i j*Real.exp (-1) := by rw [← Finset.sum_mul,hrow,one_mul]
      _ ≤ _ := Finset.sum_le_sum (fun j hj => mul_le_mul_of_nonneg_left (hlo j) (hM j))
  · calc
      _ ≤ ∑ j,M i j*Real.exp 1 := Finset.sum_le_sum (fun j hj => mul_le_mul_of_nonneg_left (hhi j) (hM j))
      _ = _ := by rw [← Finset.sum_mul,hrow,one_mul]

theorem routingProbability_uniform_exp_lower (M : Matrix (Fin n) (Fin n) ℝ) (u : Fin n → ℝ)
    (i j : Fin n) (r : ℝ) (hr : 0≤r) (hmin : ∀ j,r≤M i j)
    (hrow : ∑ j,M i j=1) (hu : ∀ j,|u j|≤1) :
    r*Real.exp (-2)≤routingProbability M u i j := by
  have hM (k : Fin n) : 0≤M i k := hr.trans (hmin k)
  have hden := routingDenominator_bounds M u i hM hrow hu
  have hpos : 0<routingDenominator M u i := (Real.exp_pos _).trans_le hden.1
  unfold routingProbability
  apply (le_div_iff₀ hpos).mpr
  calc
    _ ≤ r*Real.exp (-2)*Real.exp 1 :=
      mul_le_mul_of_nonneg_left hden.2 (mul_nonneg hr (Real.exp_pos _).le)
    _ = r*Real.exp (-1) := by rw [mul_assoc,← Real.exp_add];norm_num
    _ ≤ M i j*Real.exp (u j) := mul_le_mul (hmin j)
      (Real.exp_le_exp.mpr (abs_le.mp (hu j)).1) (Real.exp_pos _).le (hM j)

theorem exp_neg_two_ge_eighth : (1/8 : ℝ)≤Real.exp (-2) := by
  have h := Real.exp_one_lt_d9
  have he : Real.exp (2 : ℝ)=Real.exp 1^2 := by
    rw [show (2 : ℝ)=1+1 by norm_num,Real.exp_add,pow_two]
  have h8 : Real.exp (2 : ℝ)≤8 := by rw [he];nlinarith [Real.exp_pos (1 : ℝ)]
  have hm := mul_le_mul_of_nonneg_left h8 (Real.exp_pos (-2 : ℝ)).le
  rw [← Real.exp_add] at hm
  norm_num at hm
  linarith

theorem routingProbability_uniform_lower (M : Matrix (Fin n) (Fin n) ℝ) (u : Fin n → ℝ)
    (i j : Fin n) (r : ℝ) (hr : 0≤r) (hmin : ∀ j,r≤M i j)
    (hrow : ∑ j,M i j=1) (hu : ∀ j,|u j|≤1) :
    r/8≤routingProbability M u i j := by
  have h := mul_le_mul_of_nonneg_left exp_neg_two_ge_eighth hr
  have hh : r/8≤r*Real.exp (-2) := by simpa only [div_eq_mul_inv,one_mul] using h
  exact hh.trans (routingProbability_uniform_exp_lower M u i j r hr hmin hrow hu)

theorem routingProbability_total (M : Matrix (Fin n) (Fin n) ℝ) (u : Fin n → ℝ)
    (i : Fin n) (hden : routingDenominator M u i≠0) :
    (∑ j,routingProbability M u i j)=1 := by
  simp only [routingProbability,← Finset.sum_div]
  exact div_self hden

end CoefficientStability
