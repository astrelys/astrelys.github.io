import CoefficientStability.MinimalSpectralBoundary

noncomputable section
namespace CoefficientStability

theorem multiset_mapped_sum_im_neg (s : Multiset ℂ) (hne : s≠0) (f : ℂ → ℂ)
    (hf : ∀ r∈s,(f r).im<0) : ((s.map f).sum).im<0 := by
  cases s using Multiset.induction_on with
  | empty => exact False.elim (hne rfl)
  | cons r s =>
    have hr := hf r (Multiset.mem_cons_self _ _)
    have hs := multiset_mapped_sum_im_nonpos s f (fun a ha => (hf a (Multiset.mem_cons_of_mem ha)).le)
    simp only [Multiset.map_cons,Multiset.sum_cons,Complex.add_im]
    linarith

theorem upper_zero_free_logderiv_im_neg (P : Polynomial ℂ)
    (hP : complexPolynomialUpperZeroFree P) (hd : 0<P.natDegree)
    (z : ℂ) (hz : 0<z.im) : (P.derivative.eval z/P.eval z).im<0 := by
  rw [(IsAlgClosed.splits P).eval_derivative_div_eval_of_ne_zero (hP z hz)]
  have hrne : P.roots≠0 := by
    intro hh
    have hc := (IsAlgClosed.splits P).natDegree_eq_card_roots
    rw [hh,Multiset.card_zero] at hc
    omega
  apply multiset_mapped_sum_im_neg P.roots hrne
  intro r hr
  have hroot : P.eval r=0 := Polynomial.isRoot_of_mem_roots hr
  have hrim : r.im≤0 := by
    by_contra h
    exact hP r (lt_of_not_ge h) hroot
  have hpos : 0<(z-r).im := by rw [Complex.sub_im];linarith
  have hne : z-r≠0 := by
    intro hh
    have h := congrArg Complex.im hh
    simp only [Complex.zero_im] at h
    linarith
  rw [one_div,Complex.inv_im]
  exact div_neg_of_neg_of_pos (neg_neg_of_pos hpos) (Complex.normSq_pos.mpr hne)

theorem upper_zero_free_add_real_derivative (P : Polynomial ℂ)
    (hP : complexPolynomialUpperZeroFree P) (c : ℝ) :
    complexPolynomialUpperZeroFree (P+Polynomial.C (c : ℂ)*P.derivative) := by
  intro z hz
  by_cases hc : c=0
  · subst c;simpa using hP z hz
  by_cases hd : P.natDegree=0
  · have hD : P.derivative=0 := Polynomial.derivative_eq_zero.mpr hd
    simpa only [hD,mul_zero,add_zero] using hP z hz
  have hneg := upper_zero_free_logderiv_im_neg P hP (by omega) z hz
  intro hzero
  have heq : P.eval z+(c : ℂ)*P.derivative.eval z=0 := by
    simpa only [Polynomial.eval_add,Polynomial.eval_mul,Polynomial.eval_C] using hzero
  have hh := congrArg (fun w : ℂ => w/P.eval z) heq
  simp only [add_div,mul_div_assoc,div_self (hP z hz),zero_div] at hh
  have him := congrArg Complex.im hh
  simp only [Complex.add_im,Complex.one_im,Complex.zero_im,Complex.mul_im,
    Complex.ofReal_im,mul_zero,zero_mul,zero_add,add_zero,Complex.ofReal_re] at him
  exact hc ((mul_eq_zero.mp him).resolve_right (ne_of_lt hneg))

end CoefficientStability
