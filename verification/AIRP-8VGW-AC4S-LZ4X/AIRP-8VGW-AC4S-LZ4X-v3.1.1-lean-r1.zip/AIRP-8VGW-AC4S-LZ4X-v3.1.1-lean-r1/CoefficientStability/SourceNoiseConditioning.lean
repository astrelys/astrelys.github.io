import CoefficientStability.SourceInteriorMargin
import CoefficientStability.BalancedRigidityWithUnmixing

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ}

theorem source_uniform_unmixed_coeff_nonnegative (p : MvPolynomial (Fin n) ℝ) (hn : 3≤n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)≤capacityEta n/(64*(n : ℝ)))
    (hcoef : p.coeff (squarefreeExponent n)≤sourceVn n*(1+capacityEta n/2)) :
    ∀ g,0≤(uniformUnmixedPolynomial p n (sourceMixingRadius n)).coeff g := by
  have hmargin := source_polynomial_cone_margin p hn hp hs hnorm hgrad hcoef
  exact (uniformUnmixedPolynomial_nonneg_from_spectral_margin p (by omega) (by omega) hp hs hnorm
    (sourceMixingRadius n) (source_mixing_radius_subcritical hn) hmargin).2.2

theorem source_noise_literal_hessian (p : MvPolynomial (Fin n) ℝ) (hn : 3≤n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)≤capacityEta n/(64*(n : ℝ)))
    (hcoef : p.coeff (squarefreeExponent n)≤sourceVn n*(1+capacityEta n/2))
    (u v : Fin n → ℝ) (hu : (∑ j,u j^2)≤1) (hv : ∑ j,v j=0) :
    sourceNoiseStrength n*(∑ j,v j^2)≤matrixQuadratic
      (fun i j => (fderiv ℝ (fun w : Fin n → ℝ =>
        (fderiv ℝ (fun z : Fin n → ℝ => Real.log (MvPolynomial.eval (fun k => Real.exp (z k)) p)) w)
          (Pi.single i (1 : ℝ))) u) (Pi.single j (1 : ℝ))) v := by
  simpa only [sourceNoiseStrength] using paper_noise_literal_hessian_from_nonnegative_unmixing p hp hnorm
    (sourceMixingRadius n) (sourceMixingRadius_pos n hn).le (source_mixing_radius_subcritical hn)
    (source_uniform_unmixed_coeff_nonnegative p hn hp hs hnorm hgrad hcoef) u v hu hv

theorem source_balanced_small_field (p : MvPolynomial (Fin n) ℝ) (hn : 3≤n)
    (hp : p.IsHomogeneous n) (hs : UpperHalfPlaneZeroFree p)
    (hnorm : MvPolynomial.eval (fun _ => 1) p=1)
    (hgrad : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)=1)
    (hcoef : p.coeff (squarefreeExponent n)≤sourceVn n*(1+capacityEta n/2))
    (u : Fin n → ℝ) (hu : ∑ j,u j=0) (τ : ℝ)
    (hF : Real.log (MvPolynomial.eval (fun j => Real.exp (u j)) p)≤τ)
    (hτ : τ≤sourceMixingRadius n/(64*(n : ℝ))) :
    Real.sqrt (∑ j,u j^2)≤4*Real.sqrt (τ/((n : ℝ)*sourceMixingRadius n)) := by
  have hn0 : 0<(n : ℝ) := by exact_mod_cast (show 0<n by omega)
  have hsmallgrad : (∑ i,|MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i p)-1|)≤capacityEta n/(64*(n : ℝ)) := by
    simp_rw [hgrad]
    simp only [sub_self,abs_zero,Finset.sum_const_zero]
    exact (div_pos (capacityEta_pos n hn) (by positivity)).le
  exact paper_balanced_small_field_from_nonnegative_unmixing p hn hp
    (normalized_homogeneous_stable_coeff_nonneg p n hp hs hnorm) hnorm hgrad
    (sourceMixingRadius n) (sourceMixingRadius_pos n hn) (source_mixing_radius_subcritical hn)
    (source_uniform_unmixed_coeff_nonnegative p hn hp hs hnorm hsmallgrad hcoef) u hu τ hF hτ

end CoefficientStability
