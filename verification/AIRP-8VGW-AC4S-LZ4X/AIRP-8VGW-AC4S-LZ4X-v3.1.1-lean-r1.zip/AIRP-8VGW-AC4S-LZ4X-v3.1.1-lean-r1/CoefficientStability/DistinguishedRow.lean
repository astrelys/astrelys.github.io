import CoefficientStability.OnePlusProduct

noncomputable section
open scoped BigOperators
namespace CoefficientStability
variable {n : ℕ} {R : Type*} [CommRing R] [IsDomain R] [CharZero R]

theorem permutation_prod_erase (s : Equiv.Perm (Fin n)) (r : Fin n) (f : Fin n → R) :
    (∏ q ∈ Finset.univ.erase r,f (s q))=∏ i ∈ Finset.univ.erase (s r),f i := by
  classical
  apply Finset.prod_bij (fun q _ => s q)
  · intro q hq
    simpa only [Finset.mem_erase,Finset.mem_univ,and_true,s.injective.ne_iff] using hq
  · intro a ha b hb hab
    exact s.injective hab
  · intro i hi
    refine ⟨s.symm i,?_,by simp⟩
    simpa only [Finset.mem_erase,Finset.mem_univ,and_true,ne_eq,s.symm_apply_eq] using hi
  · intro q hq
    rfl

def distinguishedRowEntry (b : Fin n → R) (d r i : Fin n) : R :=
  if r=d then 1+((n : R)-1)*b i else 1-b i

theorem distinguished_row_product (b : Fin n → R) (d : Fin n) (s : Equiv.Perm (Fin n)) :
    (∏ r,distinguishedRowEntry b d r (s r))=
      (∏ i,(1-b i))+(n : R)*b (s d)*(∏ i ∈ Finset.univ.erase (s d),(1-b i)) := by
  classical
  have he : (∏ r ∈ Finset.univ.erase d,distinguishedRowEntry b d r (s r))=
      ∏ i ∈ Finset.univ.erase (s d),(1-b i) := by
    calc
      _ = ∏ r ∈ Finset.univ.erase d,(1-b (s r)) := by
        apply Finset.prod_congr rfl
        intro r hr
        simp only [distinguishedRowEntry,if_neg (Finset.mem_erase.mp hr).1]
      _ = _ := permutation_prod_erase s d (fun i => 1-b i)
  conv_lhs => rw [← Finset.mul_prod_erase Finset.univ _ (Finset.mem_univ d)]
  rw [he]
  have hF : (∏ i,(1-b i))=(1-b (s d))*(∏ i ∈ Finset.univ.erase (s d),(1-b i)) :=
    (Finset.mul_prod_erase Finset.univ _ (Finset.mem_univ (s d))).symm
  rw [hF]
  simp only [distinguishedRowEntry,ite_true]
  ring

theorem distinguished_row_permanent (b : Fin n → R) (d : Fin n) (hn : 0<n) :
    (∑ s : Equiv.Perm (Fin n),∏ r,distinguishedRowEntry b d r (s r))=
      (n.factorial : R)*((∏ i,(1-b i))+
        ∑ i,b i*(∏ j ∈ Finset.univ.erase i,(1-b j))) := by
  simp only [distinguished_row_product,Finset.sum_add_distrib,Finset.sum_const,
    Finset.card_univ,Fintype.card_perm,Fintype.card_fin,nsmul_eq_mul]
  have he : (∑ s : Equiv.Perm (Fin n),(n : R)*b (s d)*(∏ i ∈ Finset.univ.erase (s d),(1-b i))) =
      (n : R)*∑ s : Equiv.Perm (Fin n),b (s d)*(∏ i ∈ Finset.univ.erase (s d),(1-b i)) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro s hs
    ring
  rw [he,permutation_coordinate_sum (fun i => b i*(∏ j ∈ Finset.univ.erase i,(1-b j))) hn d]
  have hf : (n : R)*((n-1).factorial : R)=(n.factorial : R) := by
    exact_mod_cast Nat.mul_factorial_pred (Nat.ne_zero_of_lt hn)
  rw [← mul_assoc,hf]
  ring

end CoefficientStability
