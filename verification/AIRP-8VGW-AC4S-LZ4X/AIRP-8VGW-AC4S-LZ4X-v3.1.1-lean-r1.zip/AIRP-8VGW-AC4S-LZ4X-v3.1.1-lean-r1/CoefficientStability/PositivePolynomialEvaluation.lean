import CoefficientStability.StableCoefficientSign
import CoefficientStability.CoordinateElimination

noncomputable section
open scoped BigOperators
open MvPolynomial
namespace CoefficientStability
variable {n : ℕ}

theorem nonnegative_coeff_eval_nonneg (p : MvPolynomial (Fin n) ℝ)
    (hc : ∀ g,0≤p.coeff g) (x : Fin n → ℝ) (hx : ∀ i,0≤x i) : 0≤MvPolynomial.eval x p := by
  classical
  rw [MvPolynomial.eval_eq]
  apply Finset.sum_nonneg
  intro g hg
  apply mul_nonneg (hc g)
  exact Finset.prod_nonneg (fun i hi => pow_nonneg (hx i) _)

theorem nonnegative_coeff_eval_pos (p : MvPolynomial (Fin n) ℝ) (hp : p≠0)
    (hc : ∀ g,0≤p.coeff g) (x : Fin n → ℝ) (hx : ∀ i,0<x i) : 0<MvPolynomial.eval x p := by
  classical
  rw [MvPolynomial.eval_eq]
  apply Finset.sum_pos'
  · intro g hg
    exact mul_nonneg (hc g) (Finset.prod_nonneg (fun i hi => pow_nonneg (hx i).le _))
  · obtain ⟨g,hg⟩ := MvPolynomial.exists_coeff_ne_zero hp
    refine ⟨g,MvPolynomial.mem_support_iff.mpr hg,?_⟩
    exact mul_pos (lt_of_le_of_ne (hc g) (Ne.symm hg))
      (Finset.prod_pos (fun i hi => pow_pos (hx i) _))

theorem nonnegative_coeff_partial (p : MvPolynomial (Fin n) ℝ)
    (hc : ∀ g,0≤p.coeff g) (i : Fin n) : ∀ g,0≤(pderiv i p).coeff g := by
  intro g
  rw [coeff_pderiv]
  exact mul_nonneg (hc _) (by positivity)

theorem nonnegative_coeff_dropLast_eval_one (p : MvPolynomial (Fin (n+1)) ℝ)
    (hc : ∀ g,0≤p.coeff g) : 0≤MvPolynomial.eval (fun _ => 1) (dropLastPolynomial p) := by
  have he : MvPolynomial.eval (fun _ => (1 : ℝ)) (dropLastPolynomial p)=
      MvPolynomial.eval (Fin.lastCases 0 (fun _ : Fin n => (1 : ℝ))) p := by
    change (MvPolynomial.eval (fun _ : Fin n => (1 : ℝ))) (MvPolynomial.eval₂ _ _ p)=_
    rw [MvPolynomial.hom_eval₂]
    congr 1
    · ext c
      simp
    · funext j
      refine Fin.lastCases ?_ (fun k => ?_) j <;> simp
  rw [he]
  apply nonnegative_coeff_eval_nonneg p hc
  intro j
  refine Fin.lastCases ?_ (fun k => ?_) j <;> norm_num

theorem nonnegative_stable_derivative_elimination_coeff (p : MvPolynomial (Fin (n+1)) ℝ)
    (N : ℕ) (hp : p.IsHomogeneous (N+1)) (hs : UpperHalfPlaneZeroFree p)
    (hc : ∀ g,0≤p.coeff g) : ∀ g,0≤(lastDerivativeElimination p).coeff g := by
  rcases stable_last_derivative_elimination_zero_or_stable p hs with hz | hqs
  · simp [hz]
  · have hqhom := lastDerivativeElimination_homogeneous p N hp
    have hnonneg : 0≤MvPolynomial.eval (fun _ => 1) (lastDerivativeElimination p) :=
      nonnegative_coeff_dropLast_eval_one (pderiv (Fin.last n) p) (nonnegative_coeff_partial p hc _)
    have hne := homogeneous_stable_eval_one_ne_zero (lastDerivativeElimination p) N hqhom hqs
    exact homogeneous_stable_coeff_nonneg N _ hqhom hqs (lt_of_le_of_ne hnonneg (Ne.symm hne))

end CoefficientStability
