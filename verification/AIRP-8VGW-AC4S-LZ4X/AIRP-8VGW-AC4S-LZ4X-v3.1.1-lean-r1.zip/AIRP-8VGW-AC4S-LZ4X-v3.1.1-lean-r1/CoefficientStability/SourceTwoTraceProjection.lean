import CoefficientStability.SourceTwoTraceGeometry

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 3000000
set_option backward.isDefEq.respectTransparency false

def sourceTwoParallel (K V : Matrix (Fin 2) (Fin 2) ℂ) : Matrix (Fin 2) (Fin 2) ℂ :=
  (sourceTwoTracePair V K/sourceTwoTraceQuadratic K) • K

def sourceTwoPerpendicular (K V : Matrix (Fin 2) (Fin 2) ℂ) : Matrix (Fin 2) (Fin 2) ℂ :=
  V-sourceTwoParallel K V

def sourceTwoProjectionCurve (K V : Matrix (Fin 2) (Fin 2) ℂ) (r : ℝ) : Matrix (Fin 2) (Fin 2) ℂ :=
  sourceTwoParallel K V+(1-r) • sourceTwoPerpendicular K V

theorem source_two_parallel_hermitian (K V : Matrix (Fin 2) (Fin 2) ℂ) (hK : K.IsHermitian) :
    (sourceTwoParallel K V).IsHermitian := hK.smul (by simp [IsSelfAdjoint])

theorem source_two_perpendicular_hermitian (K V : Matrix (Fin 2) (Fin 2) ℂ)
    (hK : K.IsHermitian) (hV : V.IsHermitian) : (sourceTwoPerpendicular K V).IsHermitian :=
  hV.sub (source_two_parallel_hermitian K V hK)

theorem source_two_parallel_trace (K V : Matrix (Fin 2) (Fin 2) ℂ) (ht : Matrix.trace K=0) :
    Matrix.trace (sourceTwoParallel K V)=0 := by simp [sourceTwoParallel,Matrix.trace_smul,ht]

theorem source_two_perpendicular_trace (K V : Matrix (Fin 2) (Fin 2) ℂ)
    (hK : Matrix.trace K=0) (hV : Matrix.trace V=0) : Matrix.trace (sourceTwoPerpendicular K V)=0 := by
  rw [sourceTwoPerpendicular,Matrix.trace_sub,source_two_parallel_trace K V hK,hV,sub_self]

theorem source_two_parallel_add_perpendicular (K V : Matrix (Fin 2) (Fin 2) ℂ) :
    sourceTwoParallel K V+sourceTwoPerpendicular K V=V := by unfold sourceTwoPerpendicular;abel

theorem source_two_parallel_self (K : Matrix (Fin 2) (Fin 2) ℂ) (hq : sourceTwoTraceQuadratic K ≠ 0) :
    sourceTwoParallel K K=K := by simp [sourceTwoParallel,source_two_trace_pair_self,div_self hq]

theorem source_two_perpendicular_self (K : Matrix (Fin 2) (Fin 2) ℂ) (hq : sourceTwoTraceQuadratic K ≠ 0) :
    sourceTwoPerpendicular K K=0 := by rw [sourceTwoPerpendicular,source_two_parallel_self K hq,sub_self]

theorem source_two_perpendicular_orthogonal (K V : Matrix (Fin 2) (Fin 2) ℂ)
    (hq : sourceTwoTraceQuadratic K ≠ 0) : sourceTwoTracePair (sourceTwoPerpendicular K V) K=0 := by
  rw [sourceTwoPerpendicular,source_two_trace_pair_sub_left,sourceTwoParallel,source_two_trace_pair_smul_left,
    source_two_trace_pair_self,div_mul_cancel₀ _ hq,sub_self]

theorem source_two_projection_orthogonal (K V : Matrix (Fin 2) (Fin 2) ℂ)
    (hq : sourceTwoTraceQuadratic K ≠ 0) :
    sourceTwoTracePair (sourceTwoParallel K V) (sourceTwoPerpendicular K V)=0 := by
  rw [sourceTwoParallel,source_two_trace_pair_smul_left,source_two_trace_pair_symmetric K (sourceTwoPerpendicular K V),
    source_two_perpendicular_orthogonal K V hq,mul_zero]

theorem source_two_projection_pythagoras (K V : Matrix (Fin 2) (Fin 2) ℂ)
    (hq : sourceTwoTraceQuadratic K ≠ 0) :
    sourceTwoTraceQuadratic V=sourceTwoTraceQuadratic (sourceTwoParallel K V)+sourceTwoTraceQuadratic (sourceTwoPerpendicular K V) := by
  have h := source_two_trace_quadratic_orthogonal_affine _ _ (source_two_projection_orthogonal K V hq) 1
  simpa only [one_smul,one_pow,one_mul,source_two_parallel_add_perpendicular] using h

theorem source_two_projection_curve_quadratic (K V : Matrix (Fin 2) (Fin 2) ℂ)
    (hq : sourceTwoTraceQuadratic K ≠ 0) (r : ℝ) :
    sourceTwoTraceQuadratic (sourceTwoProjectionCurve K V r)=sourceTwoTraceQuadratic (sourceTwoParallel K V)+
      (1-r)^2*sourceTwoTraceQuadratic (sourceTwoPerpendicular K V) :=
  source_two_trace_quadratic_orthogonal_affine _ _ (source_two_projection_orthogonal K V hq) (1-r)

theorem source_two_projection_curve_quadratic_decrease (K V : Matrix (Fin 2) (Fin 2) ℂ)
    (hK : K.IsHermitian) (hV : V.IsHermitian) (hq : sourceTwoTraceQuadratic K ≠ 0)
    (r : ℝ) (hr : r ∈ Set.Icc 0 1) :
    sourceTwoTraceQuadratic (sourceTwoProjectionCurve K V r) ≤ sourceTwoTraceQuadratic V := by
  rw [source_two_projection_curve_quadratic K V hq r,source_two_projection_pythagoras K V hq]
  have hn := source_two_trace_quadratic_nonnegative _ (source_two_perpendicular_hermitian K V hK hV)
  have hsq : (1-r)^2 ≤ 1 := by nlinarith [hr.1,hr.2]
  have hm := mul_nonneg (sub_nonneg.mpr hsq) hn
  nlinarith

theorem source_two_parallel_sum (K : Matrix (Fin 2) (Fin 2) ℂ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hs : (∑ i,V i)=0) : (∑ i,sourceTwoParallel K (V i))=0 := by
  simp only [sourceTwoParallel,← Finset.sum_smul,← Finset.sum_div,← source_two_trace_pair_sum_left,hs,
    source_two_trace_pair_zero_left,zero_div,zero_smul]

theorem source_two_perpendicular_sum (K : Matrix (Fin 2) (Fin 2) ℂ)
    (V : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hs : (∑ i,V i)=0) : (∑ i,sourceTwoPerpendicular K (V i))=0 := by
  simp only [sourceTwoPerpendicular,Finset.sum_sub_distrib,hs,source_two_parallel_sum K V hs,sub_self]

@[simp] theorem source_two_projection_curve_zero (K V : Matrix (Fin 2) (Fin 2) ℂ) :
    sourceTwoProjectionCurve K V 0=V := by simp [sourceTwoProjectionCurve,source_two_parallel_add_perpendicular]

theorem source_two_projection_curve_continuous (K V : Matrix (Fin 2) (Fin 2) ℂ) :
    Continuous (sourceTwoProjectionCurve K V) := by unfold sourceTwoProjectionCurve;fun_prop

end CoefficientStability
