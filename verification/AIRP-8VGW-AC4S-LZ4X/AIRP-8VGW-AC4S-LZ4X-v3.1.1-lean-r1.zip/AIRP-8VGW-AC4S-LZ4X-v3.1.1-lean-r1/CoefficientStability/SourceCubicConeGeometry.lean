import CoefficientStability.SourcePSDInterior

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 2200000
set_option backward.isDefEq.respectTransparency false

def sourceCubicPSDCone : Set SourceCubicHermitianTuples := {Y | ∀ i,(Y i).val.PosSemidef}
def sourceCubicPSDReference (t : Fin 3 → ℝ) : SourceCubicHermitianTuples :=
  fun i => (t i/3) • sourceCubicHermitianOne

theorem source_cubic_psd_cone_convex : Convex ℝ sourceCubicPSDCone := by
  intro Y hY Z hZ a b ha hb hab i
  exact ((hY i).smul ha).add ((hZ i).smul hb)

theorem source_cubic_psd_cone_add (Y Z : SourceCubicHermitianTuples)
    (hY : Y ∈ sourceCubicPSDCone) (hZ : Z ∈ sourceCubicPSDCone) : Y+Z ∈ sourceCubicPSDCone := by
  intro i
  exact (hY i).add (hZ i)

theorem source_cubic_psd_cone_smul (Y : SourceCubicHermitianTuples)
    (hY : Y ∈ sourceCubicPSDCone) (a : ℝ) (ha : 0 ≤ a) : a • Y ∈ sourceCubicPSDCone := by
  intro i
  exact (hY i).smul ha

theorem source_cubic_psd_reference_interior (t : Fin 3 → ℝ) (ht : ∀ i,0 < t i) :
    sourceCubicPSDReference t ∈ interior sourceCubicPSDCone := by
  let e := min (t 0/3) (min (t 1/3) (t 2/3))
  have hep : 0 < e := lt_min (by linarith [ht 0]) (lt_min (by linarith [ht 1]) (by linarith [ht 2]))
  have heb (i : Fin 3) : e ≤ t i/3 := by
    fin_cases i
    · exact min_le_left _ _
    · exact (min_le_right _ _).trans (min_le_left _ _)
    · exact (min_le_right _ _).trans (min_le_right _ _)
  apply mem_interior_iff_mem_nhds.mpr
  apply Metric.mem_nhds_iff.mpr
  refine ⟨e,hep,?_⟩
  intro Y hY i
  have hdist : ‖Y-sourceCubicPSDReference t‖ < e := by simpa only [Metric.mem_ball,dist_eq_norm] using hY
  have hcoord : ‖(Y i).val-(t i/3) • (1 : Matrix (Fin 3) (Fin 3) ℂ)‖ ≤ ‖Y-sourceCubicPSDReference t‖ := by
    simpa [sourceCubicPSDReference,sourceCubicHermitianOne] using norm_le_pi_norm (Y-sourceCubicPSDReference t) i
  exact source_psd_near_positive_identity (t i/3) (by linarith [ht i]) (Y i).val (Y i).property
    (lt_of_le_of_lt hcoord (lt_of_lt_of_le hdist (heb i)))

theorem source_cubic_psd_reference_constraints (t : Fin 3 → ℝ) (ht : (∑ i,t i)=3) :
    sourceCubicConstraintMap (sourceCubicPSDReference t)=(sourceCubicHermitianOne,![t 0,t 1]) := by
  apply Prod.ext
  · change (∑ i,(t i/3) • sourceCubicHermitianOne)=sourceCubicHermitianOne
    rw [← Finset.sum_smul,← Finset.sum_div,ht]
    norm_num
  · funext j
    fin_cases j <;> norm_num [sourceCubicConstraintMap,sourceCubicPSDReference,sourceCubicHermitianOne,hermitianTrace,Matrix.trace_smul,Matrix.trace_one]

end CoefficientStability
