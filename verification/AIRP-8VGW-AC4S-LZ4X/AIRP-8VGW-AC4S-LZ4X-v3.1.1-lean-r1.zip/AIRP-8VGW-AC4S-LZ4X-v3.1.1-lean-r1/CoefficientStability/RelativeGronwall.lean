import Mathlib.Analysis.ODE.Gronwall

noncomputable section
namespace CoefficientStability

theorem nonnegative_relative_gronwall_upper (f d : ℝ → ℝ) (K : ℝ)
    (hf : ∀ s,0≤f s) (hd : ∀ s,HasDerivAt f (d s) s)
    (hb : ∀ s,|d s|≤K*f s) : f 1≤f 0*Real.exp K := by
  have hc : Continuous f := continuous_iff_continuousAt.mpr (fun s => (hd s).continuousAt)
  have h := norm_le_gronwallBound_of_norm_deriv_right_le
    (f := f) (f' := d) (δ := f 0) (K := K) (ε := 0) (a := 0) (b := 1)
    hc.continuousOn (fun s hs => (hd s).hasDerivWithinAt)
    (by simp only [Real.norm_eq_abs,abs_of_nonneg (hf 0)];exact le_rfl)
    (by intro s hs; simpa only [Real.norm_eq_abs,abs_of_nonneg (hf s),add_zero] using hb s)
    1 (by constructor <;> norm_num)
  simpa only [Real.norm_eq_abs,abs_of_nonneg (hf 1),gronwallBound_ε0,sub_zero,mul_one] using h

theorem nonnegative_relative_gronwall_endpoints (f d : ℝ → ℝ) (K : ℝ)
    (hf : ∀ s,0≤f s) (hd : ∀ s,HasDerivAt f (d s) s)
    (hb : ∀ s,|d s|≤K*f s) :
    Real.exp (-K)*f 0≤f 1 ∧ f 1≤Real.exp K*f 0 := by
  have hu := nonnegative_relative_gronwall_upper f d K hf hd hb
  have hdr (s : ℝ) : HasDerivAt (fun z : ℝ => f (1-z)) (-d (1-s)) s := by
    convert (hd (1-s)).comp s ((hasDerivAt_const s (1 : ℝ)).sub (hasDerivAt_id s)) using 1 <;> first | rfl | simp
  have hr := nonnegative_relative_gronwall_upper (fun z => f (1-z)) (fun z => -d (1-z)) K
    (fun s => hf (1-s)) hdr (by intro s;simpa only [abs_neg] using hb (1-s))
  norm_num only [sub_self,sub_zero] at hr
  have hl := mul_le_mul_of_nonneg_left hr (Real.exp_pos (-K)).le
  have he : Real.exp (-K)*(f 1*Real.exp K)=f 1 := by
    calc
      _ = f 1*(Real.exp (-K)*Real.exp K) := by ring
      _ = _ := by rw [← Real.exp_add];simp
  rw [he] at hl
  exact ⟨hl,by simpa only [mul_comm] using hu⟩

end CoefficientStability
