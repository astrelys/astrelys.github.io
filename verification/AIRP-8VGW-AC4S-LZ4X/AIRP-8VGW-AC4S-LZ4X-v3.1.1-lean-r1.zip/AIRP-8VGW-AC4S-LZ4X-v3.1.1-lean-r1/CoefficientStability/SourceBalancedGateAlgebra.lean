import CoefficientStability.SourceEscapeBalancedEquality

noncomputable section
open scoped BigOperators
namespace CoefficientStability
set_option maxHeartbeats 6000000
set_option backward.isDefEq.respectTransparency false

theorem source_balanced_gate_polynomial_identity (x y z w : ℝ) :
    sourceEscapeRowSq (sourceZeroMarginalChart x y z w) 0*
      (Matrix.permanent (sourceZeroMarginalChart x y z w)+6*x*y*(x+y))=
    (sourceEscapeRowSq (sourceZeroMarginalChart x y z w) 1-sourceEscapeRowSq (sourceZeroMarginalChart x y z w) 0)*
      (-6*x^2*y-2*x^2*w-6*x*y^2-4*x*y*z-4*x*y*w-4*x*z*w-2*x*w^2-2*y^2*z-2*y*z*w-4*y*w^2-2*z^2*w-2*z*w^2-2*w^3)+
    (sourceEscapeRowSq (sourceZeroMarginalChart x y z w) 2-sourceEscapeRowSq (sourceZeroMarginalChart x y z w) 0)*
      (4*x*y*z+2*x*y*w+2*y^2*z-2*y^2*w+2*z^2*w+2*z*w^2+2*w^3) := by
  norm_num [sourceEscapeRowSq,sourceZeroMarginalChart,source_permanent_three,Fin.sum_univ_succ]
  ring

theorem source_balanced_gate_chart_first_entry (x y z w : ℝ)
    (hR : ∀ i,sourceEscapeRowSq (sourceZeroMarginalChart x y z w) i=1/6)
    (hp : Matrix.permanent (sourceZeroMarginalChart x y z w)=-(1/18)) :
    x=-(1/3) ∨ x=1/6 := by
  have hid := source_balanced_gate_polynomial_identity x y z w
  rw [hR 0,hR 1,hR 2,hp] at hid
  have hprod : 6*x*y*(x+y)=1/18 := by nlinarith
  have h0 := hR 0
  norm_num [sourceEscapeRowSq,sourceZeroMarginalChart,Fin.sum_univ_succ] at h0
  have hrow : x^2+x*y+y^2=1/12 := by nlinarith
  have hfac : (3*x+1)*(6*x-1)^2=0 := by linear_combination 108*x*hrow-18*hprod
  rcases mul_eq_zero.mp hfac with h | h
  · left
    linarith
  · right
    have hh : 6*x-1=0 := sq_eq_zero_iff.mp h
    linarith

theorem source_balanced_gate_actual_first_entry (A : Matrix (Fin 3) (Fin 3) ℝ)
    (hA : A ∈ sourceEscapeTangent) (hR : ∀ i,sourceEscapeRowSq A i=1/6)
    (hp : Matrix.permanent A=-(1/18)) : A 0 0=-(1/3) ∨ A 0 0=1/6 := by
  have he := source_zero_marginal_chart_recovery A hA
  apply source_balanced_gate_chart_first_entry (A 0 0) (A 0 1) (A 1 0) (A 1 1)
  · rw [← he]
    exact hR
  · rw [← he]
    exact hp

end CoefficientStability
