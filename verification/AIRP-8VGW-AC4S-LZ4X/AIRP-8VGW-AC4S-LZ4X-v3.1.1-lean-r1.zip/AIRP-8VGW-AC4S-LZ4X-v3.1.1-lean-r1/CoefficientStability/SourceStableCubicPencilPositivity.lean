import CoefficientStability.SourceStableCubicHyperbolicInput

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator
namespace CoefficientStability
set_option maxHeartbeats 5000000
set_option backward.isDefEq.respectTransparency false

def sourceCubicRayPoint (i : Fin 3) (s : ℝ) : Fin 3 → ℝ := fun k => 1+s*(if k=i then 1 else 0)

theorem source_cubic_ray_point_positive (i : Fin 3) (s : ℝ) (hs : 0 < s) :
    ∀ k,0 < sourceCubicRayPoint i s k := by
  intro k
  by_cases hki : k=i <;> simp [sourceCubicRayPoint,hki] <;> linarith

theorem source_cubic_actual_normalized_ray_pencil (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hA : (∑ i,A i)=1) (i : Fin 3) (s : ℝ) :
    (∑ k,(sourceCubicRayPoint i s k : ℂ) • A k)=1+(s : ℂ) • A i := by
  have he : (∑ k,(sourceCubicRayPoint i s k : ℂ) • A k)=
      ∑ k,(A k+(if k=i then (s : ℂ) • A k else 0)) := by
    apply Finset.sum_congr rfl
    intro k hk
    by_cases hki : k=i <;> simp [sourceCubicRayPoint,hki,add_smul]
  rw [he,Finset.sum_add_distrib,hA]
  simp

theorem source_cubic_negative_eigenvalue_singular_ray (X : Matrix (Fin 3) (Fin 3) ℂ)
    (hX : X.IsHermitian) (j : Fin 3) (hj : hX.eigenvalues j < 0) :
    ∃ s : ℝ,0 < s ∧ Matrix.det (1+(s : ℂ) • X)=0 := by
  let s : ℝ := -(hX.eigenvalues j)⁻¹
  have hs : 0 < s := by dsimp [s];exact neg_pos.mpr (inv_neg''.mpr hj)
  have he : 1+s*hX.eigenvalues j=0 := by
    dsimp [s]
    rw [neg_mul,inv_mul_cancel₀ (ne_of_lt hj)]
    ring
  have heC : 1+(s : ℂ)*(hX.eigenvalues j : ℂ)=0 := by
    have h := congrArg Complex.ofReal he
    push_cast at h
    exact h
  let v : Fin 3 → ℂ := fun k => hX.eigenvectorBasis j k
  have hv : v ≠ 0 := by
    intro hz
    apply hX.eigenvectorBasis.orthonormal.ne_zero j
    apply PiLp.ext
    intro k
    exact congrFun hz k
  have hEigen : X *ᵥ v=(hX.eigenvalues j : ℂ) • v := by
    funext k
    have h := congrFun (hX.mulVec_eigenvectorBasis j) k
    simpa [v,Pi.smul_apply,Complex.real_smul,smul_eq_mul] using h
  have hker : (1+(s : ℂ) • X) *ᵥ v=0 := by
    calc
      (1+(s : ℂ) • X) *ᵥ v=v+(s : ℂ) • ((hX.eigenvalues j : ℂ) • v) := by
        rw [Matrix.add_mulVec,Matrix.one_mulVec,Matrix.smul_mulVec,hEigen]
      _=(1+(s : ℂ)*(hX.eigenvalues j : ℂ)) • v := by module
      _=0 := by rw [heC,zero_smul]
  exact ⟨s,hs,Matrix.exists_mulVec_eq_zero_iff.mp ⟨v,hv,hker⟩⟩

theorem source_stable_cubic_normalized_pencil_psd (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ)
    (hHerm : ∀ i,(A i).IsHermitian) (hA : (∑ i,A i)=1)
    (hs : UpperHalfPlaneZeroFree (realDeterminantPolynomial A)) : ∀ i,(A i).PosSemidef := by
  have hp := source_realDeterminant_homogeneous A hHerm
  have hn := source_realDeterminant_normalized A hHerm hA
  intro i
  apply (hHerm i).posSemidef_iff_eigenvalues_nonneg.mpr
  intro j
  by_contra! hj
  obtain ⟨s,hsp,hdet⟩ := source_cubic_negative_eigenvalue_singular_ray (A i) (hHerm i) j hj
  have hpos := source_stable_cubic_positive_orthant (realDeterminantPolynomial A) hp hs hn
    (sourceCubicRayPoint i s) (source_cubic_ray_point_positive i s hsp)
  have hzero : Complex.ofReal (MvPolynomial.eval (sourceCubicRayPoint i s) (realDeterminantPolynomial A))=0 := by
    rw [realDeterminantPolynomial_evaluation A hHerm,source_cubic_actual_normalized_ray_pencil A hA,hdet]
  exact (ne_of_gt hpos) (Complex.ofReal_eq_zero.mp hzero)

theorem source_stable_cubic_normalized_pencil_feasible (t : Fin 3 → ℝ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (hHerm : ∀ i,(A i).IsHermitian)
    (hA : (∑ i,A i)=1) (hs : UpperHalfPlaneZeroFree (realDeterminantPolynomial A))
    (hg : ∀ i,MvPolynomial.eval (fun _ => 1) (MvPolynomial.pderiv i (realDeterminantPolynomial A))=t i) :
    A ∈ hermitianFeasibleTuples t := by
  have hPSD := source_stable_cubic_normalized_pencil_psd A hHerm hA hs
  refine ⟨?_,hA⟩
  intro i
  refine ⟨hHerm i,hPSD i,?_⟩
  have hR : (Matrix.trace (A i)).re=t i := (realDeterminant_gradient A hHerm hA i).symm.trans (hg i)
  apply Complex.ext
  · simpa only [Complex.ofReal_re] using hR
  · simpa only [Complex.ofReal_im] using hermitian_trace_im_zero (A i) (hHerm i)

end CoefficientStability
