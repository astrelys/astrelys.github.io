import CoefficientStability.SourceCubicRealDualCertificate

noncomputable section
open scoped BigOperators ComplexOrder Matrix MatrixOrder Matrix.Norms.L2Operator Topology
namespace CoefficientStability
set_option maxHeartbeats 2500000
set_option backward.isDefEq.respectTransparency false

def sourceCubicCommonDual (ℓ : Module.Dual ℝ SourceCubicConstraintSpace) : Module.Dual ℝ SourceCubicHermitianSpace where
  toFun H := ℓ (H,0)
  map_add' H K := by simpa using ℓ.map_add (H,0) (K,0)
  map_smul' a H := by simpa using ℓ.map_smul a (H,0)
def sourceCubicTraceWeights (ℓ : Module.Dual ℝ SourceCubicConstraintSpace) : Fin 3 → ℝ :=
  ![ℓ (0,![1,0]),ℓ (0,![0,1]),0]

theorem source_cubic_constraint_dual_split (ℓ : Module.Dual ℝ SourceCubicConstraintSpace)
    (H : SourceCubicHermitianSpace) (u : Fin 2 → ℝ) :
    ℓ (H,u)=sourceCubicCommonDual ℓ H+u 0*sourceCubicTraceWeights ℓ 0+u 1*sourceCubicTraceWeights ℓ 1 := by
  have he : (H,u)=(H,0)+u 0 • (0,![1,0])+u 1 • (0,![0,1]) := by
    apply Prod.ext
    · simp
    · funext i
      fin_cases i <;> simp
  rw [he,map_add,map_add,map_smul,map_smul]
  simp [sourceCubicCommonDual,sourceCubicTraceWeights]

theorem source_cubic_constraint_dual_trace_representative (ℓ : Module.Dual ℝ SourceCubicConstraintSpace) :
    ∃ H : SourceCubicHermitianSpace,∀ Y : SourceCubicHermitianTuples,
      ℓ (sourceCubicConstraintMap Y)=(∑ i,(Matrix.trace (H.val*(Y i).val)).re)+
        ∑ i,sourceCubicTraceWeights ℓ i*(Matrix.trace (Y i).val).re := by
  obtain ⟨H,hH⟩ := source_hermitian_trace_functional_representation 3 (sourceCubicCommonDual ℓ)
  refine ⟨H,?_⟩
  intro Y
  change ℓ (∑ i,Y i,![hermitianTrace 3 (Y 0),hermitianTrace 3 (Y 1)])=_
  rw [source_cubic_constraint_dual_split,hH]
  norm_num [Fin.sum_univ_succ,sourceCubicTraceWeights,hermitianTrace,Matrix.mul_add,Matrix.trace_add,Complex.add_re]
  ring

theorem source_cubic_dual_slack_matrix_representation (t : Fin 3 → ℝ)
    (A : Fin 3 → Matrix (Fin 3) (Fin 3) ℂ) (ℓ : Module.Dual ℝ SourceCubicConstraintSpace) :
    ∃ H : SourceCubicHermitianSpace,∀ Y : SourceCubicHermitianTuples,
      sourceCubicDualSlack (sourceCubicGradientDual t A) ℓ Y=
        ∑ i,(Matrix.trace ((sourceCubicMatrixGradient (t i) (A i)+H.val+
          (sourceCubicTraceWeights ℓ i : ℂ) • 1)*(Y i).val)).re := by
  obtain ⟨H,hH⟩ := source_cubic_constraint_dual_trace_representative ℓ
  refine ⟨H,?_⟩
  intro Y
  change (∑ i,(Matrix.trace (sourceCubicMatrixGradient (t i) (A i)*(Y i).val)).re)+ℓ (sourceCubicConstraintMap Y)=_
  rw [hH]
  simp only [add_mul,smul_mul_assoc,one_mul,Matrix.trace_add,Matrix.trace_smul,Complex.add_re,
    smul_eq_mul,Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero,Finset.sum_add_distrib]
  ring

end CoefficientStability
