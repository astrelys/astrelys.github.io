"""Exact polynomial certificates for the two sharp cubic trace balls.
Python standard library only; no finite grid is used.
"""

from fractions import Fraction as F
from math import comb

class P:
    def __init__(self, x=0):
        data = {(0, 0): F(x)} if not isinstance(x, dict) else x
        self.d = {a: F(c) for a, c in data.items() if c}

    @staticmethod
    def C(x):
        return x if isinstance(x, P) else P(x)

    def __add__(self, x):
        x = P.C(x)
        out = self.d.copy()
        for a, c in x.d.items():
            out[a] = out.get(a, F(0)) + c
        return P(out)
    __radd__ = __add__

    def __neg__(self):
        return P({a: -c for a, c in self.d.items()})

    def __sub__(self, x):
        return self + -P.C(x)

    def __rsub__(self, x):
        return P.C(x) + -self

    def __mul__(self, x):
        x = P.C(x)
        out = {}
        for a, c in self.d.items():
            for b, e in x.d.items():
                k = (a[0]+b[0], a[1]+b[1])
                out[k] = out.get(k, F(0)) + c*e
        return P(out)
    __rmul__ = __mul__

    def __pow__(self, n):
        out = P(1)
        for _ in range(n):
            out = out*self
        return out

    def D(self, i):
        out = {}
        for a, c in self.d.items():
            if a[i]:
                b = list(a)
                b[i] -= 1
                out[tuple(b)] = c*a[i]
        return P(out)

    def at(self, x, y):
        return sum(c*x**a[0]*y**a[1] for a, c in self.d.items())

def same(x, y):
    return not (x-y).d

d, h = P({(1, 0): 1}), P({(0, 1): 1})
S = h*h-4*d*h+3*d*d+d
K = 3-2*d
H = 1-10*d-12*d*d+(2+30*d-12*d*d)*h-4*(2-d)*h*h
Hd, Hh = H.D(0), H.D(1)
N = K*(S.D(0)*Hh-S.D(1)*Hd)-4*S*Hh
W = 4*S*Hd*Hd-N*N

AA = [1570,-13777,68559,-290171,821303,-1536384,
      1879620,-1471392,704448,-186624,20736]
BB = [-34,-1771,29751,-110731,225671,-286998,
      230640,-112896,30528,-3456,0]
A = P({(i, 0): c for i, c in enumerate(AA)})
B = P({(i, 0): c for i, c in enumerate(BB)})

# Explicit quotient:
# (2-d)^3 W - 4d(A+2hB) = H * sum_j Q_j(d) h^j.
QQ = [
    [-288,-4952,14396,-78496,284428,-413920,282944,-92160,11520],
    [1728,2752,19664,-199344,334240,-229792,71808,-8448],
    [-4096,4096,73088,-137856,95584,-29248,3328],
    [-256,-16256,30400,-20896,6304,-704],
    [1536,-2816,1920,-576,64]
]
Q = sum(P({(i, j): c for i, c in enumerate(row)})
        for j, row in enumerate(QQ))
assert same((2-d)**3*W-4*d*(A+2*h*B), H*Q)

beta0 = [F(1587),F(69131,60),F(44833,54),F(26551,45),
         F(3510302,8505),F(3888835,13608),F(20377997,102060),
         F(1425187,9720),F(3935542,32805),
         F(138394,1215),F(10000,81)]
beta1 = [F(1536),F(15266,15),F(100198,135),F(316271,540),
         F(4133324,8505),F(26000,63),F(1280093,3645),
         F(1430671,4860),F(7829188,32805),
         F(221212,1215),F(10000,81)]
for poly, beta in ((A+(9*d-1)*B*F(1,2), beta0), (A+B, beta1)):
    expansion = sum(beta[k]*comb(10,k)*(3*d)**k*(1-3*d)**(10-k)
                    for k in range(11))
    assert same(poly, expansion)
    assert min(beta) > 0

ell = (9*d-1)*F(1,4)
assert same(H.at(d,ell), -F(3,4)*d*(3*d-1)*(3*d-5))
assert same(H.at(d,3*d*F(1,2)), (1-d)*(1-3*d)**2)
assert same(H.at(d,F(-1,4)), -F(69,4)*d-9*d*d)
assert same(H.at(d,F(1,2)), 6*d*(1-3*d))
assert same(Hd.at(d,3*d*F(1,2)), -10+21*d-27*d*d)
T = K*S.D(0)-4*S
assert same(T, 3+12*d-24*d*d-12*h+24*d*h-4*h*h)
assert same(T.at(d,3*d*F(1,2)), 3*(1-d)**2)

# Stationary-chart identities with denominators cleared.
u, v = d, h
den = 1+v-u
dn = u*v
hn = dn+(u-v)*den*F(1,2)
a, b = (1+v)*F(1,2), (1-u)*F(1,2)
t1n = a*(3*den-2*dn-2*b*den)
t2n = b*(3*den-2*dn-2*a*den)
t3n = den+hn
assert same(t1n+t2n+t3n, 3*den)
Sn = hn*hn-4*dn*hn+3*dn*dn+dn*den
assert same(Sn, (u+v)**2*den*den*F(1,4))
Hn = (den**3-10*dn*den*den-12*dn*dn*den
      +(2*den*den+30*dn*den-12*dn*dn)*hn
      -4*(2*den-dn)*hn*hn)
Pn = a*b*((1+u-v)*den-2*dn)
assert same(Pn*den*den-F(2,9)*t1n*t2n*t3n, a*b*Hn*F(1,9))
assert 224**2 < 37**3 < 236**2
print("All exact certificate identities: PASS")

# Euclidean certificate: exact polynomial identities.
d,z = P({(1,0):1}), P({(0,1):1})
R=((3-3*d+d*d)*z*z+(-6*d+12*d*d-4*d**3)*z+9*d-9*d*d+4*d**3)*F(1,2)
H2=1-8*d+10*d*d-8*d**3+(1+7*d-2*d*d)*z-(2-d)*z*z
alpha=1+d-2*d*d+d**3
beta=1+d+4*d*d+8*d**3-4*d**4
gamma=(1+d+40*d*d-52*d**3+16*d**4)*F(1,4)
assert same(H2,(2+2*d)*(F(3,8)-R)+alpha*z*z+beta*z+gamma)
psi=-30+37*d+139*d*d-104*d**3+116*d**4-80*d**5+16*d**6
assert same(beta*beta-4*alpha*gamma,d*d*psi)
bound=-30+37*F(1,4)+139*F(1,4)**2+116*F(1,4)**4+16*F(1,4)**6
assert bound==-F(2971,256)
Q2=18-36*d+45*d*d-24*d**3+4*d**4
assert same((-6*d+12*d*d-4*d**3)**2-4*(3-3*d+d*d)*(6*d-9*d*d+4*d**3),4*d*(d-1)*Q2)
u=z
assert same(18-36*(1-u)+45*(1-u)**2-24*(1-u)**3+4*(1-u)**4,7+2*u-3*u*u+8*u**3+4*u**4)
print("Both sharp-radius certificate families: PASS")
