"""Exact Gaussian-rational checks of cubic Hermitian identities.
Finite checks support normalization and complex-domain formula verification;
the manuscript proofs, not these fixtures, establish all quantifiers.
"""
from fractions import Fraction as F
from itertools import combinations, permutations
import json
class G:
    def __init__(self,r=0,i=0):
        if isinstance(r,G): self.r,self.i=r.r,r.i
        else: self.r,self.i=F(r),F(i)
    def __add__(self,b):
        b=G(b); return G(self.r+b.r,self.i+b.i)
    __radd__=__add__
    def __neg__(self): return G(-self.r,-self.i)
    def __sub__(self,b): return self+-G(b)
    def __rsub__(self,b): return G(b)+-self
    def __mul__(self,b):
        b=G(b); return G(self.r*b.r-self.i*b.i,self.r*b.i+self.i*b.r)
    __rmul__=__mul__
    def __eq__(self,b):
        b=G(b); return self.r==b.r and self.i==b.i
    def conj(self): return G(self.r,-self.i)
def add(A,B): return [[x+y for x,y in zip(a,b)] for a,b in zip(A,B)]
def scale(A,c): return [[x*c for x in a] for a in A]
def mul(A,B): return [[sum(A[i][k]*B[k][j] for k in range(len(A))) for j in range(len(A))] for i in range(len(A))]
def tr(A): return sum(A[i][i] for i in range(len(A)))
def eye(n): return [[G(i==j) for j in range(n)] for i in range(n)]
def det(A):
    n=len(A); out=G()
    for p in permutations(range(n)):
        sign=(-1)**sum(p[i]>p[j] for i in range(n) for j in range(i+1,n))
        val=G(sign)
        for i in range(n): val=val*A[i][p[i]]
        out=out+val
    return out
def D(X):
    out=G()
    for k in range(1,4):
        for ids in combinations(range(3),k):
            A=[[G() for _ in range(3)] for _ in range(3)]
            for i in ids:A=add(A,X[i])
            out=out+(-1)**(3-k)*det(A)
    return out
def positive(A):
    for k in range(1,4):
        z=det([row[:k] for row in A[:k]])
        if z.i or z.r<=0:return False
    return True
I=eye(3)
A=[[G(1),G(1,2),G(-1,1)],[G(1,-2),G(-1),G(0,1)],[G(-1,-1),G(0,-1),G(0)]]
B=[[G(-1),G(0,1),G(1,-1)],[G(0,-1),G(2),G(2,1)],[G(1,1),G(2,-1),G(-1)]]
C=scale(add(A,B),-1)
fixtures=0
for j in range(1,10):
    t=[F(1)+F(j,50),F(1)-F(j,80),F(1)-F(3*j,400)]
    assert sum(t)==3
    X=[add(scale(I,t[i]/3),scale(M,F(1,300+j))) for i,M in enumerate([A,B,C])]
    assert add(add(X[0],X[1]),X[2])==I
    assert all(positive(M) and tr(M)==ti for M,ti in zip(X,t))
    value=G(1-sum(x*x for x in t)/2+sum(x*x*x for x in t)/3)
    for i,M in enumerate(X):
        M2=mul(M,M); value=value+F(2,3)*tr(mul(M2,M))+(F(1,2)-t[i])*tr(M2)
    assert D(X)==value
    assert mul(X[0],X[1])!=mul(X[1],X[0])
    fixtures+=1
# A non-collinear complex-Hermitian 1+2 configuration, one negative weight.
a=[F(3,5),F(1,5),F(1,5)]; b=[1-x for x in a]
v=[(F(0),F(0),F(1,20)),(F(1,25),F(1,30),F(-1,40)),(F(-1,25),F(-1,30),F(-1,40))]
def block(s):
    X=[]; norms=[]
    for ai,bi,(x,y,z) in zip(a,b,v):
        x,y=s*x,s*y; norms.append(x*x+y*y+z*z)
        X.append([[G(ai),G(),G()],[G(),G(bi/2+z),G(x,y)],[G(),G(x,-y),G(bi/2-z)]])
    assert all(positive(M) for M in X)
    assert add(add(X[0],X[1]),X[2])==I
    formula=sum(a[i]*b[(i+1)%3]*b[(i+2)%3]/2+(1-2*a[i])*norms[i] for i in range(3))
    assert D(X)==formula
    return formula
before=block(F(1)); after=block(F(9,10));assert after<before
out={'status':'PASS','arithmetic':'exact Gaussian rationals','noncommuting_full_Hermitian_fixtures':fixtures,'complex_block_formula_and_feasible_strict_contraction':True,'strict_drop':str(before-after),'scope':'finite identity checks; not a proof of global minimization or novelty'}
print(json.dumps(out,indent=2))
