"""Exact finite checks for quantitative coefficient stability; requires Python>=3.10."""
from pathlib import Path
"""Standard-library polynomial arithmetic for finite consistency tests."""
from fractions import Fraction as F
from math import factorial,comb,log10
from itertools import permutations
import random,json
rng=random.Random(2026110208)
def add(p,q):
 r=p.copy()
 for a,c in q.items():r[a]=r.get(a,F(0))+c
 return {a:c for a,c in r.items() if c}
def scale(p,c):return {a:v*c for a,v in p.items() if v*c}
def mul(p,q):
 r={}
 for a,c in p.items():
  for b,d in q.items():
   k=tuple(x+y for x,y in zip(a,b));r[k]=r.get(k,F(0))+c*d
 return {a:c for a,c in r.items() if c}
def one(n):return {(0,)*n:F(1)}
def linear(row):
 n=len(row);return {tuple(int(i==j) for j in range(n)):F(c) for i,c in enumerate(row) if c}
def power(p,k):
 r=one(len(next(iter(p))))
 for _ in range(k):r=mul(r,p)
 return r
def product(rows):
 r=one(len(rows[0]))
 for row in rows:r=mul(r,linear(row))
 return r
def elementary(forms,d):
 n=len(next(iter(forms[0])));dp=[one(n)]+[{} for _ in range(d)]
 for f in forms:
  for k in range(d,0,-1):dp[k]=add(dp[k],mul(f,dp[k-1]))
 return dp[d]
def substitute(p,M):
 n=len(M);r={};cache={}
 for a,c in p.items():
  term=one(n)
  for j,k in enumerate(a):
   if (j,k) not in cache:cache[j,k]=power(linear(M[j]),k)
   term=mul(term,cache[j,k])
  r=add(r,scale(term,c))
 return r
def norm(p):return sum(map(abs,p.values()),F(0))
def diff(p,q):return add(p,scale(q,-1))
def stats(p):
 n=len(next(iter(p)));assert sum(p.values())==1
 t=[sum(c*a[i] for a,c in p.items()) for i in range(n)]
 H=[[sum(c*a[i]*(a[j]-int(i==j)) for a,c in p.items()) for j in range(n)]for i in range(n)]
 Q=[[F(n-1,2*n)*t[i]*t[j]-H[i][j]/2 for j in range(n)]for i in range(n)]
 return t,Q,sum(Q[i][i] for i in range(n))
def V(n):return F(factorial(n),n**n)
def g(n):return F(1) if n==1 else F(n-1,n)**(n-1)

from functools import reduce
records=[];tiny=[]
for n in (3,4,5):
 for family in ('product','elementary_symmetric'):
  sig=F(1,3);rows=[[sig/n+(1-sig)*int(i==j) for j in range(n)]for i in range(n)]
  p=product(rows) if family=='product' else scale(elementary([linear(r)for r in rows for _ in range(2)],n),F(1,comb(2*n,n)))
  # Positive inverse peeling at a known exact boundary, including nonproduct stable examples.
  r=sig/n;A=[[F(int(i==j))-r*int(j==0) for j in range(n)]for i in range(n)]
  B=[[F(int(i==j))+r/(1-r)*int(j==0)for j in range(n)]for i in range(n)]
  q=substitute(p,A);assert min(q.values())>=0 and max(a[0]for a in q)<=n-1
  assert substitute(q,B)==p
  assert p.get((1,)*n,F(0))>=q.get((1,)*n,F(0))/(1-r)
  for case in range(12):
   field=[F(rng.randrange(90,111),100)for _ in range(n)]
   pp={a:c*reduce(lambda x,y:x*y,(field[i]**a[i]for i in range(n)),F(1))for a,c in p.items()};pp=scale(pp,1/sum(pp.values()))
   t,Q,d=stats(pp);u=[F(rng.randrange(-10,11),10)for _ in range(n)];U=max(map(abs,u));m=sum(t[i]*u[i]for i in range(n))
   Qu=[sum(Q[i][j]*u[j]for j in range(n))for i in range(n)]
   cov=[[sum(c*a[i]*a[j]for a,c in pp.items())-t[i]*t[j]for j in range(n)]for i in range(n)]
   C_u=[sum(cov[i][j]*u[j]for j in range(n))for i in range(n)]
   deriv=[]
   for i in range(n):
    Hii=sum(c*a[i]*(a[i]-1)for a,c in pp.items())
    Hprime=sum(c*a[i]*(a[i]-1)*sum(a[j]*u[j]for j in range(n))for a,c in pp.items())-Hii*m
    direct=F(n-1,n)*t[i]*C_u[i]-Hprime/2
    D3=sum(c*a[i]*(a[i]-1)*sum((a[j]-2*int(j==i))*u[j]for j in range(n))for a,c in pp.items())
    T3=D3+F(n-2,n)*(4*t[i]*Qu[i]+2*m*Q[i][i])-F((n-1)*(n-2),n*n)*t[i]**2*m
    formula=2*(u[i]-m/n)*Q[i][i]-F(2,n)*t[i]*Qu[i]-T3/2
    assert direct==formula
    assert abs(direct)<=12*n*U*d
    deriv.append(direct)
   assert abs(sum(deriv))<=12*n*U*d
   # Exact gradient of the normalized squarefree ratio.
   lhs=[1-t[i]-sum(cov[i][j]/t[j]for j in range(n))for i in range(n)]
   rhs=[2*sum(Q[i][j]*(1/t[j]-1)for j in range(n))for i in range(n)]
   assert lhs==rhs
  e=F(1,10**9*n**8)/4;field=[1+e]+[F(1)]*(n-1)
  pp={a:c*reduce(lambda x,y:x*y,(field[i]**a[i]for i in range(n)),F(1))for a,c in p.items()};pp=scale(pp,1/sum(pp.values()));t,Q,d=stats(pp)
  assert sum(abs(x-1)for x in t)<=F(1,10**9*n**8)
  gap=pp.get((1,)*n,F(0))-V(n)*reduce(lambda x,y:x*y,t,F(1))
  assert gap>=V(n)*d/(2*10**9*n**8)
  records.append({'n':n,'family':family,'rational_tilt_directions':12,'inverse_identity':True,'relative_diagonal_and_trace_derivatives':True,'ratio_gradient_identity':True,'tiny_in_radius_gap':True})
constants=[]
for n in range(3,101):
 eta=g(n-1)/g(n)-1;r0=eta/(64*n*n);m=n*r0/8;T=r0/(160000*n**3)
 beta=min(F(1,128*n),2*T/(n-1));bb=F(1,10**8*n**8);E=F(1,10**9*n**8)
 assert eta>=F(1,2*n*n) and beta>=bb
 assert E<=eta/(64*n) and E<=m/(24*n) and E**2<=m*m*bb/(64*n)
 assert min(bb/16,eta/n)>=F(1,2*10**9*n**8)
 r2=F(1,10**16*n**15)
 assert n*r2<=(eta/(64*n))**2
 assert r2<=m*m/(24*n)**2 and r2<=m*m*bb/(64*n)
 constants.append(n)
print(json.dumps({'scope':'finite exact consistency checks, not proof/novelty/independent-review certification','fixtures':records,'tilt_direction_cases':72,'constant_dimensions':constants,'status':'ALL_QUANTITATIVE_EXACT_CHECKS_PASS'},indent=2))
