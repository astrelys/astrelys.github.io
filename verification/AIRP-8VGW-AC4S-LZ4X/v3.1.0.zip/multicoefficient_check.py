"""Finite rational normalization and descent checks; analytic proofs establish universal claims."""
from fractions import Fraction as F
from math import factorial
from itertools import combinations
import json

def coeff(alpha,t,h,d):
 m=len(alpha);N=sum(alpha)
 # map (exponent tuple, degree in perturbation s) -> exact coefficient
 poly={(tuple([0]*m),0):F(1)}
 for hk in h:
  nxt={}
  for (beta,k),v in poly.items():
   for i in range(m):
    if beta[i]>=alpha[i]:continue
    b=list(beta);b[i]+=1;b=tuple(b)
    for j,w in [(0,t[i]/N),(1,hk*d[i])]:
     nxt[(b,k+j)]=nxt.get((b,k+j),F(0))+v*w
  poly=nxt
 return [poly.get((tuple(alpha),k),F(0)) for k in range(N+1)]
def e(v,k):
 return sum((prod(c) for c in combinations(v,k)),F(0))
def prod(x):
 out=F(1)
 for v in x:out*=v
 return out
rows=[]
for alpha,t,boundary in [([1,2],[F(2),F(1)],True),([1,3],[F(2),F(2)],True),([1,4],[F(2),F(3)],True),([1,2],[F(5,2),F(1,2)],False),([1,3],[F(3),F(1)],False),([2,1,1],[F(1,2),F(3),F(1,2)],False)]:
 N=sum(alpha);T=sum(ti*ti/ai for ti,ai in zip(t,alpha));h=[F(N-1)]+[F(-1)]*(N-1)
 z=[1-F(N)*ti/(ai*T) for ti,ai in zip(t,alpha)];d=[ti*zi for ti,zi in zip(t,z)]
 zs=[zi for ai,zi in zip(alpha,z) for _ in range(ai)]
 assert sum(t)==N and sum(d)==0 and sum(h)==0
 actual=coeff(alpha,t,h,d);base=F(factorial(N),prod(factorial(ai) for ai in alpha))*prod((ti/N)**ai for ti,ai in zip(t,alpha))
 expected=[base*e(h,k)*F(N**k, factorial(N)//factorial(k)//factorial(N-k))*e(zs,k) for k in range(N+1)]
 assert actual==expected
 assert actual[0]==base and actual[1]==0
 if boundary:
  assert T==F(N*N,N-1) and actual[2]==0 and actual[3]<0
 else:
  assert T>F(N*N,N-1) and actual[2]<0
 # Exact small positive perturbation has positive factor coefficients and lower coefficient.
 s=F(1,100000)
 assert all(ti/N+s*hk*di>0 for hk in h for ti,di in zip(t,d))
 assert sum(v*s**k for k,v in enumerate(actual))<base
 rows.append({'alpha':alpha,'t':list(map(str,t)),'boundary':boundary,'first_decrease':str(actual[3 if boundary else 2])})
print(json.dumps({'status':'ALL_MULTICOEFFICIENT_EXACT_CHECKS_PASS','cases':rows},indent=2))
