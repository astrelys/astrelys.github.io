"""Exact finite checks of coefficient stability and covariance identities.
Standard library only. The analytic proof supplies all universal claims.
Stable examples are products and elementary symmetric polynomials of
positive linear forms; no nonrepresentability claim is made.
"""
from fractions import Fraction as F
from itertools import permutations, combinations
from math import comb, factorial
import json

def add(p,q):
    r=p.copy()
    for a,c in q.items():r[a]=r.get(a,F(0))+c
    return {a:c for a,c in r.items() if c}
def scale(p,s):return {a:c*s for a,c in p.items() if c*s}
def mul(p,q):
    r={}
    for a,c in p.items():
        for b,d in q.items():
            ab=tuple(x+y for x,y in zip(a,b));r[ab]=r.get(ab,F(0))+c*d
    return {a:c for a,c in r.items() if c}
def one(n):return {(0,)*n:F(1)}
def power(p,k,n):
    r=one(n)
    for _ in range(k):r=mul(r,p)
    return r
def form(v):
    n=len(v);return {tuple(int(i==j) for i in range(n)):c for j,c in enumerate(v) if c}
def product(forms):
    p=one(len(forms[0]))
    for v in forms:p=mul(p,form(v))
    return p
def elementary(forms,k):
    n=len(forms[0]);e=[one(n)]+[{} for _ in range(k)]
    for v in forms:
        for j in range(k,0,-1):e[j]=add(e[j],mul(e[j-1],form(v)))
    return scale(e[k],F(1,comb(len(forms),k)))
def moment_data(p,n):
    t=[sum(c*a[i] for a,c in p.items()) for i in range(n)]
    H=[[sum(c*a[i]*(a[j]-(i==j)) for a,c in p.items()) for j in range(n)] for i in range(n)]
    return t,H
def det(A):
    n=len(A);s=F(0)
    for p in permutations(range(n)):
        v=F((-1)**sum(p[i]>p[j] for i in range(n) for j in range(i+1,n)))
        for i in range(n):v*=A[i][p[i]]
        s+=v
    return s
def norm(p):return sum(abs(x) for x in p.values())
def uni_centered(p,y,n):
    out=[F(0)]*(n+1)
    for a,c in p.items():
        r=[c]
        for ai,yi in zip(a,y):
            f=[F(comb(ai,j))*yi**(ai-j) for j in range(ai+1)]
            z=[F(0)]*(len(r)+len(f)-1)
            for i,u in enumerate(r):
                for j,v in enumerate(f):z[i+j]+=u*v
            r=z
        out=[x+v for x,v in zip(out,r)]
    return out

def check(p,n,label,forms=None):
    assert all(c>=0 for c in p.values()) and sum(p.values())==1
    assert all(sum(a)==n for a in p)
    t,H=moment_data(p,n);ell=form([x/n for x in t]);p0=power(ell,n,n);f=add(p,scale(p0,-1))
    Q=[[((F(n-1,n)*t[i]*t[j])-H[i][j])/2 for j in range(n)] for i in range(n)]
    delta=sum(Q[i][i] for i in range(n));distance=norm(f)
    assert all(sum(row)==0 for row in Q)
    for k in range(1,n+1):
        for ids in combinations(range(n),k):assert det([[Q[i][j] for j in ids] for i in ids])>=0
    cov=[[H[i][j]+(t[i] if i==j else 0)-t[i]*t[j] for j in range(n)] for i in range(n)]
    cm=[[ (t[i] if i==j else 0)-t[i]*t[j]/n for j in range(n)] for i in range(n)]
    assert all(2*Q[i][j]==cm[i][j]-cov[i][j] for i in range(n) for j in range(n))
    assert delta==(n-sum(x*x for x in t)/n-sum(cov[i][i] for i in range(n)))/2
    assert 0<=delta<=F(n-1,2)
    assert delta<=F(n*(n-1),4)*distance
    K=F(n)+2*sum(F(comb(n,k)*(k*n)**k*(n-1)**((k-1)//2),factorial(k)) for k in range(3,n+1))
    assert distance<=K*delta
    q={}
    for i in range(n):
        for j in range(n):
            alpha=tuple(int(h==i)+int(h==j) for h in range(n));q[alpha]=q.get(alpha,F(0))+Q[i][j]
    leading=scale(mul(power(ell,n-2,n),q),-1).get((1,)*n,F(0))
    C=F(factorial(n-2),n**(n-2));prod=F(1)
    for ti in t:prod*=ti
    formula=C*prod*(sum(Q[i][i]/t[i]**2 for i in range(n))-sum(Q[i][j]/(t[i]*t[j]) for i in range(n) for j in range(n)))
    assert leading==formula
    for x in [[F(i+1,7) for i in range(n)],[F((-1)**i,3) for i in range(n)]]:
        ellx=sum(a*b for a,b in zip(t,x))/n;y=[xi-ellx for xi in x]
        u=uni_centered(p,y,n);qq=sum(x[i]*Q[i][j]*x[j] for i in range(n) for j in range(n))
        assert u[n]==1 and u[n-1]==0 and u[n-2]==-qq
        if forms:
            roots=[-sum(v[i]*y[i] for i in range(n)) for v in forms]
            assert sum(roots)==0 and sum(r*r for r in roots)/2==qq
    if forms:
        Y=[[v[i]-t[i]/n for v in forms] for i in range(n)]
        assert all(Q[i][j]==sum(Y[i][k]*Y[j][k] for k in range(n))/2 for i in range(n) for j in range(n))
        assert delta==sum(x*x for row in Y for x in row)/2
    return {'name':label,'n':n,'delta':str(delta),'coefficient_l1':str(distance),'TV':str(distance/2),'K_n':str(K),'gap':str(p.get((1,)*n,F(0))-p0.get((1,)*n,F(0)))}

out=[]
for n,base in [(3,[F(1,2),F(1,3),F(1,6)]),(4,[F(1,2),F(1,4),F(1,8),F(1,8)])]:
    forms=[base[i:]+base[:i] for i in range(n)]
    out.append(check(product(forms),n,'cyclic-positive-product',forms))
    ef=forms+[[F(1,n)]*n]
    out.append(check(elementary(ef,n),n,'normalized-elementary-of-positive-forms'))
    v=[F(1),F(-1)]+[F(0)]*(n-2);ratios=[]
    for s in [F(1,16),F(1,32),F(1,64)]:
        fs=[[F(1,n)+s*x for x in v],[F(1,n)-s*x for x in v]]+[[F(1,n)]*n for _ in range(n-2)]
        p=product(fs);r=check(p,n,'sharp-linear-exponent-'+str(s),fs)
        ratios.append((F(r['delta'])/s**2,F(r['coefficient_l1'])/s**2,F(r['gap'])/s**2))
        out.append(r)
    assert ratios[0]==ratios[1]==ratios[2]
    assert ratios[0][0]==2 and ratios[0][2]==F(2*factorial(n-2),n**(n-2))
    mon={(1,)*n:F(1)};r=check(mon,n,'sharp-universal-delta-bound');assert F(r['delta'])==F(n-1,2);out.append(r)
# Positive unbalanced marginal product.
forms=[[F(1,2),F(1,3),F(1,6)],[F(1,3)]*3,[F(1,2),F(1,3),F(1,6)]]
out.append(check(product(forms),3,'unbalanced-positive-product',forms))
print(json.dumps({'status':'ALL_COEFFICIENT_STABILITY_CHECKS_PASS','fixtures':out,'scope':'exact finite normalization and identity checks; analytic proofs supply universal stability and exponent optimality'},indent=2))
