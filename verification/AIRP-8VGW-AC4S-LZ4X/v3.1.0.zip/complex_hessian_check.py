"""Exact checks on genuinely complex noncommuting Hermitian directions.
Finite normalization checks only; continuum and all-n claims use the proof.
Python standard library only.
"""
from fractions import Fraction as F
from dataclasses import dataclass
from itertools import combinations
from math import factorial, prod
import json, random
@dataclass(frozen=True)
class Q:
    a:F=F(0)
    b:F=F(0)
    def __add__(self,o):
        o=o if isinstance(o,Q) else Q(F(o));return Q(self.a+o.a,self.b+o.b)
    __radd__=__add__
    def __neg__(self):return Q(-self.a,-self.b)
    def __sub__(self,o):return self+-o if isinstance(o,Q) else self+Q(-F(o))
    def __rsub__(self,o):return -self+o
    def __mul__(self,o):
        o=o if isinstance(o,Q) else Q(F(o));return Q(self.a*o.a-self.b*o.b,self.a*o.b+self.b*o.a)
    __rmul__=__mul__
    def __truediv__(self,o):
        o=o if isinstance(o,Q) else Q(F(o));d=o.a*o.a+o.b*o.b
        return self*Q(o.a/d,-o.b/d)
    def __bool__(self):return bool(self.a or self.b)
    def conj(self):return Q(self.a,-self.b)

def det(a):
    n=len(a);b=[row[:] for row in a];v=Q(F(1))
    for i in range(n):
        k=next((k for k in range(i,n) if b[k][i]),None)
        if k is None:return Q()
        if k!=i:b[k],b[i]=b[i],b[k];v=-v
        pivot=b[i][i];v*=pivot
        for k in range(i+1,n):
            q=b[k][i]/pivot
            for j in range(i+1,n):b[k][j]-=q*b[i][j]
    return v

def D(X):
    n=len(X);v=Q()
    for mask in range(1<<n):
        M=[[sum((X[k][i][j] for k in range(n) if mask>>k&1),Q()) for j in range(n)] for i in range(n)]
        v+=(-1)**(n-bin(mask).count('1'))*det(M)
    assert v.b==0
    return v.a

def norm2(A):return sum(x.a*x.a+x.b*x.b for row in A for x in row)
def matmul(A,B):
    n=len(A);return [[sum((A[i][k]*B[k][j] for k in range(n)),Q()) for j in range(n)] for i in range(n)]
def noncommute(A,B):
    AB=matmul(A,B);BA=matmul(B,A)
    return any(AB[i][j]!=BA[i][j] for i in range(len(A)) for j in range(len(A)))
rng=random.Random(20261102);out=[]
for n in range(3,6):
    for case in range(2):
        raw=[rng.randint(1,8) for _ in range(n)];t=[F(n*v,sum(raw)) for v in raw]
        A=[]
        for _ in range(n-1):
            M=[[Q() for j in range(n)] for i in range(n)]
            for i in range(n):
                M[i][i]=Q(F(rng.randint(-2,2)))
                for j in range(i+1,n):
                    M[i][j]=Q(F(rng.randint(-2,2)),F(rng.randint(-2,2)));M[j][i]=M[i][j].conj()
            M[-1][-1]=-sum((M[i][i] for i in range(n-1)),Q());A.append(M)
        A.append([[-sum((M[i][j] for M in A),Q()) for j in range(n)] for i in range(n)])
        assert any(x.b for M in A for row in M for x in row)
        assert noncommute(A[0],A[1])
        X=[[[Q(t[k]/n) if i==j else Q() for j in range(n)] for i in range(n)] for k in range(n)]
        S=[[sum((A[k][i][j]/t[k] for k in range(n)),Q()) for j in range(n)] for i in range(n)]
        pred=F(factorial(n-2),n**(n-2))*prod(t)*(sum(norm2(A[k])/t[k]**2 for k in range(n))-norm2(S))
        actual=F(0)
        for i,j in combinations(range(n),2):
            Y=list(X);Y[i]=A[i];Y[j]=A[j];actual+=2*D(Y)
        assert pred==actual
        linear=sum(D(X[:i]+[A[i]]+X[i+1:]) for i in range(n));assert linear==0
        assert D(X)==F(factorial(n),n**n)*prod(t)
        out.append({'n':n,'case':case,'t':[str(x) for x in t],'hessian':str(actual),'genuinely_complex':True,'noncommuting':True})
print(json.dumps({'status':'PASS','checks':out,'scope':'six exact complex-Hermitian normalization tests; no continuum or priority claim'},indent=2))
