#!/usr/bin/env python3
"""Exact algebraic identities supporting the symmetric-marginal escape theorem.
Finite examples test implementation; the continuum proof is in the manuscript.
No numerical optimization or sampled eigenvalue claim is used.
"""
from fractions import Fraction as F
from itertools import permutations
import json
P=list(permutations(range(3)))
def poly_mul(x,y):
 z=[F(0)]*(len(x)+len(y)-1)
 for i,a in enumerate(x):
  for j,b in enumerate(y):z[i+j]+=a*b
 return z
def per_coeff(S,K):
 out=[F(0)]*4
 for p in P:
  r=[F(1)]
  for i in range(3):r=poly_mul(r,[S[i][p[i]],K[i][p[i]]])
  out=[a+b for a,b in zip(out,r)]
 return out
def qcoeff(A,K,c):
 return [sum(c[i]*A[i][j]**2/6 for i in range(3) for j in range(3)),
         sum(c[i]*A[i][j]*K[i][j]/3 for i in range(3) for j in range(3)),
         sum(c[i]*K[i][j]**2/6 for i in range(3) for j in range(3))]
def minus(X,Y):return [[X[i][j]-Y[i][j] for j in range(3)] for i in range(3)]
K=[[F(0)]*3,[F(0),F(1),F(-1)],[F(0),F(-1),F(1)]]
Z=[[F(0)]*3 for _ in range(3)]
results=[]
for s in map(F,[0,F(1,4),F(1,2),1,2,5]):
 # Rational parametrization of every a>=b/4: s>=0,
 # b=4/(3+s²), a=(1+3s²)/(3+s²), v=s/(3+s²).
 b=4/(3+s*s);a=(1+3*s*s)/(3+s*s);v=s/(3+s*s);d=(2*a+b)/12
 c=[a,b,b];t=[b,(a+b)/2,(a+b)/2];C=[[x/3]*3 for x in t]
 S=[[F(0),b/2,b/2],[F(1,2),d+v,d-v],[F(1,2),d-v,d+v]]
 A=minus(S,C);p=a*b*b;Q=p/12;Delta=p/36
 assert all(sum(S[i])==t[i] for i in range(3))
 assert all(sum(S[i][j] for i in range(3))==1 for j in range(3))
 assert min(map(min,S))==0
 assert d*d-v*v==(a-b)**2/36
 assert per_coeff(S,K)==[b*d,F(0),F(0),F(0)]
 assert qcoeff(A,K,c)==[Q,4*b*v/3,2*b/3]
 assert per_coeff(A,Z)[0]==-2*Q/3
 assert per_coeff(S,Z)[0]-per_coeff(C,Z)[0]==Delta
 assert per_coeff(C,A)==[per_coeff(C,Z)[0],F(0),Q,-2*Q/3]
 if s!=1:
  z=(d-v)/2
  E=[[S[i][j]+z*K[i][j] for j in range(3)] for i in range(3)]
  assert z>0 and min(map(min,E))>=0
  assert qcoeff(minus(E,C),Z,c)[0]>Q
  assert per_coeff(E,Z)[0]==per_coeff(S,Z)[0]
 results.append({'s':str(s),'a':str(a),'b':str(b),'v':str(v),'Q':str(Q),'Delta':str(Delta),'flat_attainment':s!=1})
S0=[[F(int(i!=j),2) for j in range(3)] for i in range(3)]
C=[[F(1,3)]*3 for _ in range(3)]
L=[[F(0),F(1),F(-1)],[F(-1),F(0),F(1)],[F(1),F(-1),F(0)]]
assert per_coeff(S0,L)==[F(1,4),F(0),F(3),F(0)]
assert qcoeff(minus(S0,C),L,[F(1)]*3)==[F(1,12),F(0),F(1)]
# All permanent cofactors are1/4, giving full affine stationarity.
for i in range(3):
 for j in range(3):
  rr=[r for r in range(3) if r!=i];cc=[k for k in range(3) if k!=j]
  assert S0[rr[0]][cc[0]]*S0[rr[1]][cc[1]]+S0[rr[0]][cc[1]]*S0[rr[1]][cc[0]]==F(1,4)
# Four independent zero-marginal directions check the linear q coefficient.
for i in [0,1]:
 for j in [0,1]:
  H=[[F(0)]*3 for _ in range(3)]
  H[i][j]=1;H[i][2]=-1;H[2][j]=-1;H[2][2]=1
  assert qcoeff(minus(S0,C),H,[F(1)]*3)[1]==-sum(H[k][k] for k in range(3))/6
  assert per_coeff(S0,H)[1]==0
print(json.dumps({'status':'ALL_EXACT_ESCAPE_CHECKS_PASS','profiles':results,'balanced_nonattainment':'analytic tangent-cone argument, not inferred from finite checks'},indent=2))
