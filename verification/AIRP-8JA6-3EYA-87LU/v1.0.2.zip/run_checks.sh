#!/bin/sh
# Exact reproduction, version 1.0.0. No network or non-standard Ruby gems.
set -eu

MODE=${1:-all}
RESULT_DIR=${2:-results}
case "$MODE" in all|jacobian|geometry) ;; *) echo 'usage: sh run_checks.sh [all|jacobian|geometry] [empty-output-directory]' >&2; exit 64 ;; esac
if [ -e "$RESULT_DIR" ]; then
  echo 'Output path already exists; choose a new output directory.' >&2
  exit 64
fi
mkdir -p "$RESULT_DIR"
RESULT_DIR=$(CDPATH= cd -- "$RESULT_DIR" && pwd)
SCRIPT_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$SCRIPT_ROOT"

if [ "$MODE" != jacobian ]; then
  ruby --disable-gems scripts/verify_degree.rb data/map.txt data/map.json > "$RESULT_DIR/degree.txt"
  ruby --disable-gems scripts/verify_collision.rb > "$RESULT_DIR/collision.json"
  # The fiber checker itself executes the hash-bound geometry checker once.
  ruby --disable-gems scripts/verify_component_fiber.rb \
    scripts/verify_component_geometry.rb data/map.txt data/map.json \
    data/computational-scope.txt > "$RESULT_DIR/component.txt"
  echo 'GEOMETRY_AND_COLLISION_CHECKS=PASS'
fi

if [ "$MODE" != geometry ]; then
  CXX=${CXX:-c++}
  "$CXX" -std=c++17 -O3 -Wall -Wextra -Werror -pedantic \
    scripts/jacobian_modular.cpp -o "$RESULT_DIR/jacobian_modular"
  PRIMES='536870849 536870819 536870779 536870909 536870879 536870869'
  ruby --disable-gems scripts/coefficient_bound.rb data/map.txt $PRIMES > "$RESULT_DIR/coefficient-bound.txt"
  grep -Fqx 'crt_product_exceeds_twice_height=true' "$RESULT_DIR/coefficient-bound.txt"
  for PRIME in $PRIMES; do
    "$RESULT_DIR/jacobian_modular" data/map.txt "$PRIME" \
      --samples 32 --symbolic --op-cap 250000000 --term-cap 4000000 --seconds 55 \
      > "$RESULT_DIR/jacobian-$PRIME.txt"
    grep -Fqx 'sha256_in_memory_same_buffer_gate=PASS' "$RESULT_DIR/jacobian-$PRIME.txt"
    grep -Fqx 'symbolic_status=PASS_ALL_COEFFICIENTS_MOD_P' "$RESULT_DIR/jacobian-$PRIME.txt"
  done
  echo 'GLOBAL_JACOBIAN_FULL_COEFFICIENT_CRT=PASS'
fi
echo 'Requested exact checks completed. Geometric deductions are proved in the paper, not by this success marker.'
