# Exact computational supplement

Astrée Iriart. Manuscript edition 1.0.2, 21 September 2026.
Paper identifier: AIRP-8JA6-3EYA-87LU. Verification attachment v1.0.2,
matched to that manuscript version. This distribution-only revision updates
the version label and instructions.
The checker implementation versions
remain 1.0.0; their bytes and the exact data are unchanged.

This supplement accompanies the paper on a five-dimensional polynomial map
and its singular nonproperness profile. It contains the complete expanded
map and small exact checkers for the computational steps in that paper.
The companion all-degree sweep classification is proved in the text and
does not depend on finite computational tests.

## Reproduction

Requirements: a POSIX shell, Ruby with its standard library, and a C++17
compiler. No CAS, Python package, Ruby gem, network service, or numeric root
finder is used. Run from this directory:

```sh
shasum -a 256 -c SHA256SUMS
sh run_checks.sh all results
```

On systems providing `sha256sum` instead, use `sha256sum -c SHA256SUMS`.

The output directory must not already exist. Choose another name for each
run. To select a compiler, use `CXX=clang++ sh run_checks.sh all results`.
The terminal must print both

```text
GEOMETRY_AND_COLLISION_CHECKS=PASS
GLOBAL_JACOBIAN_FULL_COEFFICIENT_CRT=PASS
```

The `geometry` mode omits the determinant calculation. The `jacobian` mode
performs only the global determinant calculation. Each modular determinant
run has a 55-second limit and explicit operation/term caps; exceeding a cap
fails the run rather than supplying partial evidence. On a slower machine
the limits may be raised in the runner without changing the checked
coefficient identity. Point samples printed by the determinant program are
diagnostics only and are not the certificate.

## Exact object and format

`data/map.txt` defines all five coordinates over
`K = Q[eta]/(eta^2+2)` in variables `(rho,Y1,Y2,Y3,Y4)`.
It has 34,436 bytes and 1,197 terms, with coordinate term counts
`(2,207,273,343,372)` and total degrees `(3,27,29,31,31)`.
Its SHA-256 is

```text
ace8f69bc55d219d4c25901f866a310997a128726d4e0dbdce9a533687855ee0
```

Each numerical line is `e0,e1,e2,e3,e4|n0,n1,d`, representing
`((n0+n1*eta)/d)*rho^e0*Y1^e1*Y2^e2*Y3^e3*Y4^e4`.
Denominators are positive and each coefficient triple is primitive.
Terms occur in descending lexicographic exponent order. The ASCII/LF
headers and per-coordinate metadata are part of the hashed serialization.
`data/map.json` records the field, variable order, coordinate hashes,
counts and degrees. Every verifier reads the map as data, not executable
code, and checks its expected hash before arithmetic.

The sweep background and original constructions are credited in the paper.
The supplied exact arithmetic implementations and specialization data are
part of this research manuscript, not third-party coefficient tables.

## What the checkers establish

1. `scripts/verify_degree.rb` reconstructs the displayed sweep, all
   birational coordinate layers and both directions of their inverses. It
   checks `F0=C` and `S_j=C^w_j F_j` for `w=(1,2,3,3)` against every term of
   the expanded map. Since every `F_j` is explicitly a polynomial, these
   identities also certify the four polynomial divisions. It checks the
   degree-four fiber polynomial, its leading coefficient, the relevant
   resultants, and the unique rational lifting identities. Irreducibility
   and the resulting geometric degree use the Gauss-lemma argument in the
   paper, not a special-fiber count. The output ends with `PASS ALL`.

2. `scripts/coefficient_bound.rb` clears the coordinate denominators by
   `L_i=(1,139968,559872,2239488,22674816)`. For
   `R=det J(L_i F_i)-Q`, where
   `Q=3979330554973200442195968`, it computes an integer coefficient bound
   using the submultiplicative height `h(a+b*eta)=|a|+2|b|`:

   ```text
   H  = 1093293066175706352533820647015248919976984669978624
   2H = 2186586132351412705067641294030497839953969339957248
   ```

   `scripts/jacobian_modular.cpp` computes the complete sparse determinant
   residual coefficientwise in `F_p[eta]/(eta^2+2)` at each of
   `p=536870849,536870819,536870779,536870909,536870879,536870869`.
   Both components of every residual coefficient must vanish, whether the
   quadratic quotient is split or inert. The product
   `M=23945226412685291268550674540667421478511298085472591` exceeds `2H`.
   Hence the Chinese remainder theorem proves the characteristic-zero
   global polynomial identity `det JF=1`. Each of the six output files
   must contain `symbolic_status=PASS_ALL_COEFFICIENTS_MOD_P`.

3. `scripts/verify_collision.rb` works in the finite reduced algebra
   `K[q]/(p(q))` for the displayed squarefree quartic. It checks denominator
   inverses, evaluates all 1,197 canonical terms at the supplied source
   representatives, and checks the exact recovery formula for `q`.
   The resulting `collision.json` must have `status: PASS`, all five target
   coordinates exactly `(1,1,0,0,0)`, and the verified recovery identity.
   This supplies at least four distinct geometric points of that fiber;
   it does not by itself compute every point of the fiber or prove generic
   degree four.

4. `scripts/verify_component_geometry.rb` checks the compact quartic and
   gamma resultant, the transported hypersurface equation, the reduced
   singular-locus inputs, the Laurent chart and the nonsingular boundary.
   `scripts/verify_component_fiber.rb` checks the triple/simple root
   factorization, denominator exclusions, inverse layers, and one exact
   nonempty-open witness, including evaluation against the expanded map.
   It runs the hash-bound geometry checker as a subprocess once. The
   output ends with `COMPONENT_FIBER_CHECK=PASS`.

The component scripts deliberately distinguish exact assertions from lines
beginning `PROOF_DEDUCTION`. The irreducibility, dense-open argument,
finite-etale fiber argument, identification of a nonproperness component,
Hodge--Deligne calculation and stable dimension obstruction are mathematical
proofs in the manuscript. They are not additional computational assertions.
In particular, the component computation alone does not prove the global
Jacobian identity, the degree theorem, or any generated stable-inequivalence
claim. The paper supplies those dependencies separately.

The polynomial identity
`(t-1)*t^2 + (t-1)*t - (t-1) = t^3-2*t+1`
is the inclusion-exclusion calculation for the two singular components and
their intersection, once the geometric identifications in the paper are
proved. Its constant term is one. No numerical Hodge calculation is used.

## Reproduction record and limitations

The degree/construction binding, collision, component identities and all
six full-coefficient modular determinant checks were rerun successfully
on the supplied serialization while preparing this verification-only
attachment. Data and checker bytes are unchanged. The complete suite uses
exact rational/integer arithmetic; this statement is not formal
verification or external peer review. Source, data and executable success
markers support only the stated mathematical inputs, not novelty, priority,
publication acceptance, or correctness of prose arguments by themselves.

Generated logs and compiled executables belong in the chosen output
directory and are not needed as inputs to reproduction. No private
conversation, internal research logs or account information is included.
