#!/usr/bin/env ruby
# frozen_string_literal: true

# the component theorem non-SymPy Part 2 exact certificate.
#
# Computational scope:
# - exact Integer/Rational arithmetic in Q(eta), eta^2=-2;
# - no Python, SymPy, CAS, gems, network, or imported generator logic;
# - the hash-locked Part 1 executable supplies only its actually executed
#   global same-object bridge and H0/target-boundary premises;
# - this file independently checks the H0-shell root factorization,
#   denominator exclusions, final/sweep inverse formulas, and one simultaneous
#   nonempty-open witness against the frozen canonical bytes.
#
# Proof-only scope is emitted with PROOF_DEDUCTION, never PASS.

require "digest"
require "json"
require "open3"
require "rbconfig"

unless ARGV.length == 4
  warn "usage: verify_component_fiber.rb PART1_V2_RB CANONICAL_MAP MANIFEST_JSON CLAIM_SCOPE"
  exit 64
end

PART1_PATH = File.expand_path(ARGV.fetch(0))
CANONICAL_PATH = File.expand_path(ARGV.fetch(1))
MANIFEST_PATH = File.expand_path(ARGV.fetch(2))
CLAIM_SCOPE_PATH = File.expand_path(ARGV.fetch(3))

PART1_SHA256 = "ae9a5fa0a96c350a42a59d766d23cc67be383936dcfb9998879a1722f20e6866"
CANONICAL_SHA256 = "ace8f69bc55d219d4c25901f866a310997a128726d4e0dbdce9a533687855ee0"
MANIFEST_SHA256 = "b8efd5fa4de03c7c6edf28ac0606044098dda2e3e4366672717540c15e3c94d7"
CLAIM_SCOPE_SHA256 = "f7927d191989290d474c6899db3fd6e046e713a3f29194324b7539af3377c998"
CLAIM_SCOPE_LINES = [
  "COMPONENT-COMPUTATIONAL-SCOPE-V1",
  "ALLOW=DIRECT_DIMENSION_MATCHING_IDENTITY_STABILIZATION_ONLY",
  "DENY=GENERATED_STABLE_INEQUIVALENCE_FROM_THIS_COMPUTATION_ALONE",
  "DENY=COMPUTATION_ALONE_PROVES_COMPONENT_THEOREM",
  "DENY=GEOMETRY_CHECK_ALONE_PROVES_JELONEK_COMPONENT"
].freeze

SCOPE_PROVED = "DIRECT_DIMENSION_MATCHING_IDENTITY_STABILIZATION_ONLY"
SCOPE_NOT_PROVED = "GENERATED_STABLE_INEQUIVALENCE_FROM_THIS_COMPUTATION_ALONE"
FULL_COMPONENT_BOUNDARY = "REQUIRES_PROSE_PROOF_GLOBAL_JACOBIAN_AND_GEOMETRIC_DEGREE"

class CertificateFailure < StandardError; end

def assert(label, condition)
  raise CertificateFailure, label unless condition
  puts "PASS #{label}"
end

# Exact Q(eta), eta^2=-2.
class QE
  attr_reader :a, :b

  def initialize(a = 0, b = 0)
    @a = a.is_a?(Rational) ? a : Rational(a, 1)
    @b = b.is_a?(Rational) ? b : Rational(b, 1)
  end

  def self.wrap(value)
    value.is_a?(QE) ? value : QE.new(value, 0)
  end

  def +(other)
    return other + self if defined?(Poly) && other.is_a?(Poly)
    return other + self if defined?(Rat) && other.is_a?(Rat)
    other = QE.wrap(other)
    QE.new(@a + other.a, @b + other.b)
  end

  def -(other)
    return -(other - self) if defined?(Poly) && other.is_a?(Poly)
    return -(other - self) if defined?(Rat) && other.is_a?(Rat)
    other = QE.wrap(other)
    QE.new(@a - other.a, @b - other.b)
  end

  def -@
    QE.new(-@a, -@b)
  end

  def *(other)
    return other * self if defined?(Poly) && other.is_a?(Poly)
    return other * self if defined?(Rat) && other.is_a?(Rat)
    other = QE.wrap(other)
    QE.new(@a * other.a - 2 * @b * other.b,
           @a * other.b + @b * other.a)
  end

  def inverse
    norm = @a * @a + 2 * @b * @b
    raise ZeroDivisionError, "zero in Q(eta)" if norm.zero?
    QE.new(@a / norm, -@b / norm)
  end

  def /(other)
    self * QE.wrap(other).inverse
  end

  def **(power)
    raise ArgumentError, "negative power" if power.negative?
    result = QE.new(1)
    base = self
    exponent = power
    while exponent.positive?
      result *= base if exponent.odd?
      exponent >>= 1
      base *= base if exponent.positive?
    end
    result
  end

  def ==(other)
    other = QE.wrap(other)
    @a == other.a && @b == other.b
  rescue TypeError
    false
  end

  def zero?
    @a.zero? && @b.zero?
  end

  def coerce(other)
    [QE.wrap(other), self]
  end

  def canonical_triple
    denominator = @a.denominator.lcm(@b.denominator)
    n0 = @a.numerator * (denominator / @a.denominator)
    n1 = @b.numerator * (denominator / @b.denominator)
    gcd = n0.abs.gcd(n1.abs).gcd(denominator)
    [n0 / gcd, n1 / gcd, denominator / gcd]
  end

  def to_s
    n0, n1, denominator = canonical_triple
    "(#{n0}+#{n1}*eta)/#{denominator}"
  end
end

# Sparse multivariate polynomials over QE.
class Poly
  attr_reader :nvars, :terms

  def initialize(nvars, raw_terms = {})
    @nvars = nvars
    @terms = {}
    raw_terms.each do |exponents, coefficient|
      raise ArgumentError, "wrong exponent length" unless exponents.length == nvars
      key = exponents.map(&:to_i).freeze
      raise ArgumentError, "negative exponent" if key.any?(&:negative?)
      value = QE.wrap(coefficient)
      next if value.zero?
      sum = (@terms[key] || QE.new) + value
      sum.zero? ? @terms.delete(key) : @terms[key] = sum
    end
  end

  def self.zero(nvars)
    Poly.new(nvars)
  end

  def self.one(nvars)
    constant(nvars, 1)
  end

  def self.constant(nvars, coefficient)
    value = QE.wrap(coefficient)
    return zero(nvars) if value.zero?
    Poly.new(nvars, { Array.new(nvars, 0) => value })
  end

  def self.variable(nvars, index)
    exponents = Array.new(nvars, 0)
    exponents[index] = 1
    Poly.new(nvars, { exponents => QE.new(1) })
  end

  def wrap(other)
    other.is_a?(Poly) ? other : Poly.constant(@nvars, other)
  end

  def check_ring(other)
    raise ArgumentError, "polynomial ring mismatch" unless @nvars == other.nvars
  end

  def +(other)
    other = wrap(other)
    check_ring(other)
    data = @terms.dup
    other.terms.each do |exponents, coefficient|
      value = (data[exponents] || QE.new) + coefficient
      value.zero? ? data.delete(exponents) : data[exponents] = value
    end
    Poly.new(@nvars, data)
  end

  def -(other)
    self + (-wrap(other))
  end

  def -@
    Poly.new(@nvars, @terms.transform_values { |coefficient| -coefficient })
  end

  def *(other)
    other = wrap(other)
    check_ring(other)
    return Poly.zero(@nvars) if zero? || other.zero?
    data = {}
    @terms.each do |left_exp, left_coefficient|
      other.terms.each do |right_exp, right_coefficient|
        exponents = Array.new(@nvars) { |i| left_exp[i] + right_exp[i] }.freeze
        value = (data[exponents] || QE.new) + left_coefficient * right_coefficient
        value.zero? ? data.delete(exponents) : data[exponents] = value
      end
    end
    Poly.new(@nvars, data)
  end

  def /(scalar)
    scalar = QE.wrap(scalar)
    Poly.new(@nvars, @terms.transform_values { |coefficient| coefficient / scalar })
  end

  def **(power)
    raise ArgumentError, "negative power" if power.negative?
    result = Poly.one(@nvars)
    base = self
    exponent = power
    while exponent.positive?
      result *= base if exponent.odd?
      exponent >>= 1
      base *= base if exponent.positive?
    end
    result
  end

  def split_variable(index)
    result = Hash.new { |hash, degree| hash[degree] = Poly.zero(@nvars - 1) }
    @terms.each do |exponents, coefficient|
      degree = exponents[index]
      reduced = exponents.dup
      reduced.delete_at(index)
      result[degree] = result[degree] + Poly.new(@nvars - 1, { reduced => coefficient })
    end
    result
  end

  def degree_in(index)
    return -1 if zero?
    @terms.keys.map { |exponents| exponents[index] }.max
  end

  def total_degree
    return -1 if zero?
    @terms.keys.map(&:sum).max
  end

  def zero?
    @terms.empty?
  end

  def ==(other)
    other = wrap(other)
    @nvars == other.nvars && @terms == other.terms
  rescue TypeError
    false
  end

  def coerce(other)
    [Poly.constant(@nvars, other), self]
  end

  def fingerprint
    records = @terms.sort { |(left, _), (right, _)| right <=> left }.map do |exponents, coefficient|
      n0, n1, denominator = coefficient.canonical_triple
      "#{exponents.join(',')}|#{n0},#{n1},#{denominator}\n"
    end.join
    Digest::SHA256.hexdigest(records)
  end
end

# Exact rational functions; equality is exact cross multiplication.
class Rat
  attr_reader :num, :den, :nvars

  def initialize(num, den = nil)
    raise ArgumentError, "numerator must be polynomial" unless num.is_a?(Poly)
    den ||= Poly.one(num.nvars)
    raise ArgumentError, "denominator ring mismatch" unless den.is_a?(Poly) && den.nvars == num.nvars
    raise ZeroDivisionError, "zero polynomial denominator" if den.zero?
    @num = num
    @den = den
    @nvars = num.nvars
  end

  def self.wrap(value, nvars)
    return value if value.is_a?(Rat)
    return Rat.new(value) if value.is_a?(Poly)
    Rat.new(Poly.constant(nvars, value))
  end

  def +(other)
    other = Rat.wrap(other, @nvars)
    Rat.new(@num * other.den + other.num * @den, @den * other.den)
  end

  def -(other)
    self + (-Rat.wrap(other, @nvars))
  end

  def -@
    Rat.new(-@num, @den)
  end

  def *(other)
    other = Rat.wrap(other, @nvars)
    Rat.new(@num * other.num, @den * other.den)
  end

  def /(other)
    other = Rat.wrap(other, @nvars)
    raise ZeroDivisionError, "zero rational function" if other.num.zero?
    Rat.new(@num * other.den, @den * other.num)
  end

  def **(power)
    raise ArgumentError, "negative power" if power.negative?
    Rat.new(@num**power, @den**power)
  end

  def ==(other)
    other = Rat.wrap(other, @nvars)
    @num * other.den == other.num * @den
  end

  def zero?
    @num.zero?
  end

  def coerce(other)
    [Rat.wrap(other, @nvars), self]
  end

  def fingerprint
    "#{@num.fingerprint}/#{@den.fingerprint}"
  end
end

MU = QE.new(Rational(2, 9), Rational(4, 9))
BETA = 3 * MU + 2
K = QE.new(Rational(-7, 12), Rational(1, 3))

A0 = (3 * MU - 2) / 2
A1 = 2 * (MU + 2) / 3
A2 = -4 * (5 * MU - 2) / 3
S0 = (63 * MU - 46) / 256
S1C = -(45 * MU - 2) / 64
S2C = (9 * MU + 2) / 16
KAPPA = -3 * MU / 2

L21 = -(9 * MU + 26) / 16
L31 = -2 * (11 * MU - 14) / 3
L32 = 2 * (19 * MU - 16) / 3
L41 = (9 * MU + 2) / 16
L42 = -(9 * MU + 14) / 32
Q3 = (53 * MU - 26) / 24
Q4 = -(45 * MU - 17) / 32

def polynomial_determinant(matrix)
  size = matrix.length
  raise ArgumentError, "empty/non-square matrix" if size.zero? || matrix.any? { |row| row.length != size }
  return matrix[0][0] if size == 1
  total = Poly.zero(matrix[0][0].nvars)
  matrix[0].each_with_index do |entry, column|
    next if entry.zero?
    minor = matrix[1..-1].map do |row|
      row.each_with_index.reject { |_value, index| index == column }.map(&:first)
    end
    term = entry * polynomial_determinant(minor)
    total += column.even? ? term : -term
  end
  total
end

def sylvester_resultant(first, second)
  m = first.length - 1
  n = second.length - 1
  raise ArgumentError, "zero leading coefficient" if first[-1].zero? || second[-1].zero?
  zero = Poly.zero(first[-1].nvars)
  rows = []
  n.times do |shift|
    row = Array.new(m + n) { zero }
    first.reverse.each_with_index { |coefficient, index| row[shift + index] = coefficient }
    rows << row
  end
  m.times do |shift|
    row = Array.new(m + n) { zero }
    second.reverse.each_with_index { |coefficient, index| row[shift + index] = coefficient }
    rows << row
  end
  polynomial_determinant(rows)
end

def verify_inputs_and_scope
  part1_bytes = File.binread(PART1_PATH)
  canonical_bytes = File.binread(CANONICAL_PATH)
  manifest_bytes = File.binread(MANIFEST_PATH)
  scope_bytes = File.binread(CLAIM_SCOPE_PATH)
  assert("geometry-check source SHA-256", Digest::SHA256.hexdigest(part1_bytes) == PART1_SHA256)
  assert("frozen canonical SHA-256", Digest::SHA256.hexdigest(canonical_bytes) == CANONICAL_SHA256)
  assert("frozen manifest SHA-256", Digest::SHA256.hexdigest(manifest_bytes) == MANIFEST_SHA256)
  assert("hardened claim-scope SHA-256", Digest::SHA256.hexdigest(scope_bytes) == CLAIM_SCOPE_SHA256)
  assert("hardened claim-scope byte count 256", scope_bytes.bytesize == 256)
  assert("hardened claim-scope ASCII/LF format",
         scope_bytes.ascii_only? && !scope_bytes.include?("\r") && scope_bytes.end_with?("\n"))
  assert("hardened claim-scope exact ordered lines", scope_bytes.lines.map(&:chomp) == CLAIM_SCOPE_LINES)
  manifest = JSON.parse(manifest_bytes)
  assert("manifest binds canonical SHA-256",
         manifest.dig("canonical_serialization", "bundle_sha256") == CANONICAL_SHA256)
  assert("manifest field is Q[eta]/(eta^2+2)",
         manifest.dig("coefficient_field", "presentation") == "Q[eta]/(eta^2+2)")
  assert("manifest source variable order", manifest["input_variable_order"] == %w[rho Y1 Y2 Y3 Y4])
  assert("manifest target coordinate order", manifest["output_coordinate_order"] == %w[F0 F1 F2 F3 F4])

  expected_proved = %w[DIRECT DIMENSION MATCHING IDENTITY STABILIZATION ONLY].join("_")
  expected_not_proved = %w[GENERATED STABLE INEQUIVALENCE FROM THIS COMPUTATION ALONE].join("_")
  assert("computational scope is direct dimension-matching identity stabilization",
         SCOPE_PROVED == expected_proved)
  assert("generated stable inequivalence is not proved by this computation alone",
         SCOPE_NOT_PROVED == expected_not_proved)
end

def verify_field_constants
  assert("eta^2=-2", QE.new(0, 1)**2 + 2 == 0)
  assert("mu relation 9mu^2-4mu+4=0", 9 * MU**2 - 4 * MU + 4 == 0)
  assert("mu is nonzero", !MU.zero?)
  assert("beta is nonzero", !BETA.zero?)
  assert("K is nonzero", !K.zero?)
  assert("K=-24*mu*(mu+2)^2/beta^4", K == -24 * MU * (MU + 2)**2 / BETA**4)
end

def verify_target_affine_change
  aa, bb, dd, ll = 4.times.map { |index| Poly.variable(4, index) }
  target_s1 = S2C - aa
  target_s2 = (bb - S1C) / 2
  target_s3 = S0 - dd
  target_s4 = A2 * dd - A1 * bb / 2 + A0 * aa + KAPPA - ll
  recovered = [
    S2C - target_s1,
    S1C + 2 * target_s2,
    S0 - target_s3,
    A2 * (S0 - target_s3) - A1 * (S1C + 2 * target_s2) / 2 +
      A0 * (S2C - target_s1) + KAPPA - target_s4
  ]
  assert("affine target change S<->(A,B,D,L) is invertible", recovered == [aa, bb, dd, ll])

  s1, s2, s3, s4 = 4.times.map { |index| Poly.variable(4, index) }
  a_back = S2C - s1
  b_back = S1C + 2 * s2
  d_back = S0 - s3
  l_back = A2 * d_back - A1 * b_back / 2 + A0 * a_back + KAPPA - s4
  forward_again = [S2C - a_back, (b_back - S1C) / 2, S0 - d_back,
                   A2 * d_back - A1 * b_back / 2 + A0 * a_back + KAPPA - l_back]
  assert("affine target change forward-after-inverse is identity", forward_again == [s1, s2, s3, s4])
end

def verify_res_p_t
  aa, bb, dd, ll, xx = 5.times.map { |index| Poly.variable(5, index) }
  delta = bb**2 - 4 * aa * dd
  tt = aa * xx**2 + bb * xx + dd
  nn = aa * xx + bb / 2
  pp = ll * tt**2 + MU * nn**3 - aa * tt * nn
  gamma_num = -2 * aa * tt + BETA * nn**2
  assert("N^2-A*T=Delta/4", nn**2 - aa * tt == delta / 4)
  assert("P has x-degree four", pp.degree_in(4) == 4)
  p_split = pp.split_variable(4)
  t_split = tt.split_variable(4)
  assert("P leading coefficient is A^2*L",
         p_split[4] == Poly.variable(4, 0)**2 * Poly.variable(4, 3))
  res = sylvester_resultant(0.upto(4).map { |degree| p_split[degree] },
                            0.upto(2).map { |degree| t_split[degree] })
  a4, b4, d4, _l4 = 4.times.map { |index| Poly.variable(4, index) }
  delta4 = b4**2 - 4 * a4 * d4
  expected = -(a4**4) * MU**2 * delta4**3 / 64
  assert("Res_x(P,T)=-A^4*mu^2*Delta^3/64", res == expected)
  assert("Gamma leading coefficient is 3*mu*A^2",
         gamma_num.split_variable(4)[2] == 3 * MU * Poly.variable(4, 0)**2)
  puts "INFO Res(P,T)-fingerprint=#{res.fingerprint}"
end

def shell_constants
  c0 = 2 * (MU + 2) / BETA**2
  c1 = -(MU - 1) - 3 * c0
  t0 = c0**2 - K / 4
  t1 = c1**2 - K / 4
  g0 = -2 * t0 + BETA * c0**2
  g1 = -2 * t1 + BETA * c1**2
  [c0, c1, t0, t1, g0, g1]
end

def verify_h0_shell
  aa, ll, nn = 3.times.map { |index| Poly.variable(3, index) }
  delta_shell = Rat.new(K * aa**4, ll**2)
  tt = (Rat.new(nn**2) - delta_shell / 4) / aa
  pp = Rat.new(ll) * tt**2 + MU * nn**3 - Rat.new(aa) * tt * nn
  c0, c1, t0c, t1c, g0c, g1c = shell_constants
  n0 = Rat.new(c0 * aa**2, ll)
  n1 = Rat.new(c1 * aa**2, ll)
  factor = Rat.new(ll) * (Rat.new(nn) - n0)**3 * (Rat.new(nn) - n1)
  assert("H0 shell factorization A^2*P=L*(N-N0)^3*(N-N1)", Rat.new(aa**2) * pp == factor)

  tn0 = (n0**2 - delta_shell / 4) / aa
  tn1 = (n1**2 - delta_shell / 4) / aa
  gn0 = Rat.new(-2 * aa) * tn0 + BETA * n0**2
  gn1 = Rat.new(-2 * aa) * tn1 + BETA * n1**2
  assert("T(N0)=t0*A^3/L^2 exact", tn0 == Rat.new(t0c * aa**3, ll**2))
  assert("T(N0) is a nonzero rational function", !tn0.zero? && !t0c.zero?)
  assert("Gamma(N0)=0 exact", gn0.zero? && g0c.zero?)
  assert("T(N1)=t1*A^3/L^2 exact", tn1 == Rat.new(t1c * aa**3, ll**2))
  assert("T(N1) is a nonzero rational function", !tn1.zero? && !t1c.zero?)
  assert("Gamma(N1)=g1*A^4/L^2 exact", gn1 == Rat.new(g1c * aa**4, ll**2))
  assert("Gamma(N1) is a nonzero rational function", !gn1.zero? && !g1c.zero?)
  assert("N1-N0 is a nonzero rational function", !(n1 - n0).zero? && c1 != c0)

  res_shell = Rat.new(-MU**2 * K**3 * aa**16, 64 * ll**6)
  assert("Res(P,T)|H0 is a nonzero rational function", !res_shell.zero?)
  puts "INFO c0=#{c0} c1=#{c1}"
  puts "INFO t0=#{t0c} t1=#{t1c} g0=#{g0c} g1=#{g1c}"
  puts "INFO T(N0)-fingerprint=#{tn0.fingerprint}"
  puts "INFO Gamma(N1)-fingerprint=#{gn1.fingerprint}"
  puts "INFO shell-Res(P,T)-fingerprint=#{res_shell.fingerprint}"
end

def verify_final_sweep_inverse_formulas
  c, gamma, x, y, theta = 5.times.map { |index| Poly.variable(5, index) }
  rho = Rat.new(c, gamma)
  u1 = Rat.new(x, gamma)
  u2 = Rat.new(y, gamma**2)
  u3 = Rat.new(theta, gamma**3)
  v1 = Rat.new(gamma - 1)
  v2 = u1 - 1 - L21 * v1
  v3 = u2 - L31 * v1 - L32 * v2 - Q3 * v1**2
  v4 = u3 - L41 * v1 - L42 * v2 - Q4 * v1**2
  ys = [v1 / rho, v2 / rho**2, v3 / rho**3, v4 / rho**3]

  fv1 = rho * ys[0]
  fv2 = rho**2 * ys[1]
  fv3 = rho**3 * ys[2]
  fv4 = rho**3 * ys[3]
  fgamma = 1 + fv1
  fu1 = 1 + L21 * fv1 + fv2
  fu2 = L31 * fv1 + L32 * fv2 + fv3 + Q3 * fv1**2
  fu3 = L41 * fv1 + L42 * fv2 + fv4 + Q4 * fv1**2
  assert("inverse lift recovers C=rho*gamma", rho * fgamma == c)
  assert("inverse lift recovers gamma", fgamma == gamma)
  assert("inverse lift recovers x=gamma*u1", fgamma * fu1 == x)
  assert("inverse lift recovers y=gamma^2*u2", fgamma**2 * fu2 == y)
  assert("inverse lift recovers theta=gamma^3*u3", fgamma**3 * fu3 == theta)

  target = 5.times.map { |index| Poly.variable(5, index) }
  tc, z1, z2, z3, z4 = target
  weights = [1, 2, 3, 3]
  assert("target weights are exactly (1,2,3,3)", weights == [1, 2, 3, 3])
  ss = [z1, z2, z3, z4].each_with_index.map { |coordinate, index| tc**weights[index] * coordinate }
  recovered_z = ss.each_with_index.map { |coordinate, index| Rat.new(coordinate, tc**weights[index]) }
  assert("C!=0 target dehomogenization is invertible", recovered_z == [z1, z2, z3, z4].map { |p| Rat.new(p) })
end

def parse_canonical_terms
  bytes = File.binread(CANONICAL_PATH)
  lines = bytes.lines
  index = 0
  raise CertificateFailure, "canonical magic" unless lines[index]&.chomp == "EXACT-D1-KELLER-BUNDLE-V1"
  index += 1
  coordinates = []
  names = []
  while index < lines.length
    expected_header = [
      "EXACT-D1-KELLER-COORDINATE-V1",
      "field=Q[eta]/(eta^2+2)",
      "eta-generator=formal-class-of-t-mod-(t^2+2);mu=(2+4*eta)/9",
      "variables=rho,Y1,Y2,Y3,Y4",
      "monomial-order=descending-lexicographic-exponent-tuples"
    ]
    expected_header.each do |expected|
      raise CertificateFailure, "canonical header #{expected}" unless lines[index]&.chomp == expected
      index += 1
    end
    name_line = lines[index]&.chomp
    count_line = lines[index + 1]&.chomp
    raise CertificateFailure, "canonical metadata" unless name_line&.start_with?("coordinate=") && count_line&.start_with?("term-count=")
    names << name_line.split("=", 2)[1]
    count = Integer(count_line.split("=", 2)[1], 10)
    index += 2
    terms = []
    count.times do
      exponent_text, coefficient_text = lines[index]&.chomp&.split("|", 2)
      raise CertificateFailure, "canonical term syntax" unless exponent_text && coefficient_text
      exponents = exponent_text.split(",").map { |part| Integer(part, 10) }
      n0, n1, denominator = coefficient_text.split(",").map { |part| Integer(part, 10) }
      raise CertificateFailure, "canonical term arity" unless exponents.length == 5
      terms << [exponents, QE.new(Rational(n0, denominator), Rational(n1, denominator))]
      index += 1
    end
    coordinates << terms
  end
  assert("canonical scalar parser coordinate names", names == %w[F0 F1 F2 F3 F4])
  assert("canonical scalar parser term counts", coordinates.map(&:length) == [2, 207, 273, 343, 372])
  coordinates
end

def evaluate_terms(terms, values)
  terms.reduce(QE.new) do |sum, (exponents, coefficient)|
    product = coefficient
    exponents.each_with_index { |power, index| product *= values[index]**power }
    sum + product
  end
end

def polynomial_a(x)
  A0 + A1 * x + A2 * x**2
end

def polynomial_s(x)
  S0 + S1C * x + S2C * x**2
end

def sweep_at(gamma, x, y, theta)
  aval = polynomial_a(x)
  sval = polynomial_s(x)
  ap = A1 + 2 * A2 * x
  app = 2 * A2
  sp = S1C + 2 * S2C * x
  spp = 2 * S2C
  tau = theta + sval
  z = y + aval
  f = tau * z - sp / 2
  g = MU * tau * z**3 - (ap * tau + spp / 2) * z + app * tau / 2 + spp * aval / 2 + KAPPA
  fx = sp * z + tau * ap - spp / 2
  lf_f = fx + 2 * f * z
  gy = 3 * MU * tau * z**2 - (ap * tau + spp / 2)
  x1 = -(gy + lf_f) / 2
  s1 = x1 + gamma
  s2 = f + x * s1
  s3 = 2 * x * f - theta + x**2 * s1
  s4 = g + y * s1
  [s1, s2, s3, s4]
end

def verify_explicit_dense_open_witness(canonical_terms)
  c0, c1, t0, t1, g0, g1 = shell_constants
  aa = QE.new(1)
  bb = QE.new(0)
  ll = QE.new(1)
  cc = QE.new(1)
  dd = -K / 4
  delta = bb**2 - 4 * aa * dd
  h0 = delta * ll**2 - K * aa**4
  n0 = c0 * aa**2 / ll
  n1 = c1 * aa**2 / ll
  tn0 = t0 * aa**3 / ll**2
  tn1 = t1 * aa**3 / ll**2
  gn0 = g0 * aa**4 / ll**2
  gn1 = g1 * aa**4 / ll**2
  respt = -(aa**4) * MU**2 * delta**3 / 64

  open_values = {
    "A" => aa, "L" => ll, "Delta" => delta, "C" => cc,
    "T(N0)" => tn0, "T(N1)" => tn1, "N1-N0" => n1 - n0,
    "Gamma(N1)" => gn1, "Res(P,T)" => respt, "A^2*L" => aa**2 * ll,
    "beta" => BETA, "mu" => MU, "K" => K
  }
  assert("witness lies on H0", h0.zero?)
  assert("witness Gamma(N0)=0", gn0.zero?)

  target_s1 = S2C - aa
  target_s2 = (bb - S1C) / 2
  target_s3 = S0 - dd
  target_s4 = A2 * dd - A1 * bb / 2 + A0 * aa + KAPPA - ll
  target_s = [target_s1, target_s2, target_s3, target_s4]
  target_z = target_s # C=1 and weights are (1,2,3,3).

  roots = [[n0, tn0, gn0], [n1, tn1, gn1]]
  central = roots.map do |nn, tt, gamma_num|
    xx = (nn - bb / 2) / aa
    theta = 2 * xx * target_s2 - xx**2 * target_s1 - target_s3
    z = nn / tt
    y = z - polynomial_a(xx)
    gamma = gamma_num / (2 * tt)
    [gamma, xx, y, theta]
  end
  assert("triple root has gamma=0 at witness", central[0][0].zero?)
  assert("simple root has gamma!=0 at witness", !central[1][0].zero?)
  assert("triple-root sweep lift reaches target", sweep_at(*central[0]) == target_s)
  assert("simple-root sweep lift reaches target", sweep_at(*central[1]) == target_s)

  gamma, x, y, theta = central[1]
  rho = cc / gamma
  open_values["gamma(N1)"] = gamma
  open_values["rho=C/gamma(N1)"] = rho
  open_values["target-change-Jacobian"] = -2 * cc**9
  assert("explicit witness satisfies every open/saturation condition",
         open_values.values.none?(&:zero?))
  u1 = x / gamma
  u2 = y / gamma**2
  u3 = theta / gamma**3
  v1 = gamma - 1
  v2 = u1 - 1 - L21 * v1
  v3 = u2 - L31 * v1 - L32 * v2 - Q3 * v1**2
  v4 = u3 - L41 * v1 - L42 * v2 - Q4 * v1**2
  source_y = [v1 / rho, v2 / rho**2, v3 / rho**3, v4 / rho**3]
  source = [rho] + source_y

  canonical_value = canonical_terms.map { |terms| evaluate_terms(terms, source) }
  assert("canonical frozen map evaluates simple-lift witness to final target",
         canonical_value == [cc] + target_z)

  puts "WITNESS shell A=#{aa} B=#{bb} D=#{dd} L=#{ll} C=#{cc}"
  puts "WITNESS N0=#{n0} N1=#{n1} T0=#{tn0} T1=#{tn1} Gamma1=#{gn1}"
  puts "WITNESS target Z=#{target_z.map(&:to_s).join(';')}"
  puts "WITNESS canonical-source=#{source.map(&:to_s).join(';')}"
  puts "WITNESS open-nonzero=#{open_values.keys.join(',')}"
end

def run_hash_locked_part1_bridge
  command = [RbConfig.ruby, "--disable-gems", PART1_PATH,
             CANONICAL_PATH, MANIFEST_PATH, CLAIM_SCOPE_PATH]
  stdout, stderr, status = Open3.capture3(*command)
  raise CertificateFailure, "Part 1 subprocess failed: #{stderr.lines.first}" unless status.success?
  markers = [
    "PASS weighted-source inverse after forward",
    "PASS weighted-parameter inverse after forward",
    "PASS radial recovery rho=C/gamma",
    "PASS target-dehomogenization inverse after forward",
    "PASS composite source-layer forward after rational inverse",
    "PASS central field change (rho,gamma)<->(C,gamma)",
    "PASS canonical F0 equals C=rho*gamma",
    "PASS same-object bridge S1=C^1*F1",
    "PASS same-object bridge S2=C^2*F2",
    "PASS same-object bridge S3=C^3*F3",
    "PASS same-object bridge S4=C^3*F4",
    "PASS same-sweep compact lift coordinate 1",
    "PASS same-sweep compact lift coordinate 2",
    "PASS same-sweep compact lift coordinate 3",
    "PASS same-sweep compact fourth residual=P/T^2",
    "PASS Htarget=C^3*h exact",
    "PASS claim-scope SHA-256 fixed",
    "PASS claim-scope byte count 256",
    "PASS claim-scope exact ordered lines",
    "SCOPE ALLOW=DIRECT_DIMENSION_MATCHING_IDENTITY_STABILIZATION_ONLY",
    "SCOPE DENY=GENERATED_STABLE_INEQUIVALENCE_FROM_THIS_COMPUTATION_ALONE",
    "SCOPE DENY=COMPUTATION_ALONE_PROVES_COMPONENT_THEOREM",
    "SCOPE DENY=GEOMETRY_CHECK_ALONE_PROVES_JELONEK_COMPONENT",
    "UPSTREAM_CONTRACT GLOBAL_JACOBIAN_AND_GEOMETRIC_DEGREE_NOT_REPROVED",
    "BOUNDARY PART1_DOES_NOT_PROVE_DENSE_E1_OR_JELONEK_COMPONENT_OR_FULL_COMPONENT"
  ]
  markers.each do |marker|
    assert("Part 1 executed marker: #{marker.sub('PASS ', '')}", stdout.lines.count { |line| line.chomp == marker } == 1)
  end
  assert("Part 1 terminal PASS", stdout.lines.any? { |line| line.start_with?("PASS ALL elapsed_seconds=") })
  assert("Part 1 emitted no FAIL", !stdout.include?("FAIL") && !stderr.include?("FAIL"))
  puts "BINDING global same-object bridge accepted from hash-locked geometry check"
  puts "BOUNDARY the geometry check alone does not prove the full component theorem"
end

def emit_proof_boundaries
  prefix = "PROOF_DEDUCTION"
  puts "#{prefix} FOUR_ROOT_SCHEME: on the certified open, the factorization and N1!=N0 give one length-three point and one reduced point; A!=0 transfers multiplicities from N to x"
  puts "#{prefix} UNIQUE_SWEEP_LIFT: nonzero Res(P,T), the affine target inverse, and the executed rational sweep identities give one unique sweep lift per quartic root"
  puts "#{prefix} FINAL_SWEEP_BIJECTION: for C!=0, finite final preimages correspond exactly to sweep preimages with gamma!=0 via rho=C/gamma and the four displayed inverse layers"
  puts "#{prefix} DENSE_E1: the witness proves the saturated open is nonempty; irreducibility of H0 makes it dense, and Laurent target transport carries it to a dense open of V(h)"
  puts "#{prefix} FINITE_ETALE: using upstream det(JF)=1 and geometric degree four, finiteness at a point gives a connected finite-etale neighborhood of constant rank four and four reduced geometric points"
  puts "#{prefix} JELONEK_COMPONENT: E1 is contained in the nonproperness set; Jelonek closedness plus the dense E1 subset and hypersurface dimension make V(h) a reduced irreducible component"
  puts "#{prefix} NON_CYLINDER: the two reduced singular components and their G_m intersection imply V(h) is not an A1-cylinder"
  puts "#{prefix} FUNCTORIALITY: polynomial left-right automorphisms transport Jelonek sets and J_(G*id^r)=J_G*A^r, so every stabilized component is an A1-cylinder"
  puts "UPSTREAM_NOT_RECOMPUTED det(JF)=1 and geometric_degree=4"
  puts "SCOPE_PROVED=#{SCOPE_PROVED}"
  puts "SCOPE_NOT_PROVED=#{SCOPE_NOT_PROVED}"
  puts "FULL_COMPONENT_BOUNDARY=#{FULL_COMPONENT_BOUNDARY}"
end

begin
  started = Process.clock_gettime(Process::CLOCK_MONOTONIC)
  puts "COMPONENT-FIBER-CHECK 1.0.0"
  puts "INFO ruby=#{RUBY_VERSION} platform=#{RUBY_PLATFORM}"
  verify_inputs_and_scope
  verify_field_constants
  verify_target_affine_change
  verify_res_p_t
  verify_h0_shell
  verify_final_sweep_inverse_formulas
  canonical_terms = parse_canonical_terms
  verify_explicit_dense_open_witness(canonical_terms)
  run_hash_locked_part1_bridge
  emit_proof_boundaries
  elapsed = Process.clock_gettime(Process::CLOCK_MONOTONIC) - started
  puts format("COMPONENT_FIBER_CHECK=PASS elapsed_seconds=%.3f", elapsed)
rescue StandardError => error
  warn "FAIL #{error.class}: #{error.message}"
  warn error.backtrace.join("\n")
  exit 1
end
