#!/usr/bin/env ruby
# frozen_string_literal: true

# Portable exact collision certificate for the five-dimensional map.
# Runtime dependencies: Ruby standard library only.

require "digest"
require "json"

class CertificateFailure < StandardError; end

def certify(condition, message)
  raise CertificateFailure, message unless condition
end

class KElement
  attr_reader :a, :b

  def initialize(a = 0, b = 0)
    @a = Rational(a)
    @b = Rational(b)
    freeze
  end

  def self.from(value)
    return value if value.is_a?(KElement)
    KElement.new(value, 0)
  end

  def +(other)
    if (defined?(Polynomial) && other.is_a?(Polynomial)) ||
       (defined?(Residue) && other.is_a?(Residue))
      return other + self
    end
    other = KElement.from(other)
    KElement.new(a + other.a, b + other.b)
  end

  def -(other)
    if defined?(Polynomial) && other.is_a?(Polynomial)
      return Polynomial.constant(self) - other
    end
    if defined?(Residue) && other.is_a?(Residue)
      return other.ring.element(self) - other
    end
    other = KElement.from(other)
    KElement.new(a - other.a, b - other.b)
  end

  def -@
    KElement.new(-a, -b)
  end

  def *(other)
    if (defined?(Polynomial) && other.is_a?(Polynomial)) ||
       (defined?(Residue) && other.is_a?(Residue))
      return other * self
    end
    other = KElement.from(other)
    # eta^2 = -2
    KElement.new(a * other.a - 2 * b * other.b,
                 a * other.b + b * other.a)
  end

  def inverse
    norm = a * a + 2 * b * b
    raise ZeroDivisionError, "zero in Q[eta]/(eta^2+2)" if norm.zero?
    KElement.new(a / norm, -b / norm)
  end

  def /(other)
    self * KElement.from(other).inverse
  end

  def **(exponent)
    raise ArgumentError, "negative exponent" if exponent.negative?
    result = KElement.new(1)
    base = self
    power = exponent
    while power.positive?
      result *= base if power.odd?
      base *= base
      power >>= 1
    end
    result
  end

  def zero?
    a.zero? && b.zero?
  end

  def ==(other)
    other = KElement.from(other)
    a == other.a && b == other.b
  rescue TypeError, ArgumentError
    false
  end

  alias eql? ==

  def hash
    [a, b].hash
  end

  def coerce(other)
    [KElement.from(other), self]
  end

  def to_s
    return a.to_s if b.zero?
    return "#{b}*eta" if a.zero?
    sign = b.negative? ? "-" : "+"
    "#{a}#{sign}#{b.abs}*eta"
  end

  def as_json
    {
      "eta0" => [a.numerator, a.denominator],
      "eta1" => [b.numerator, b.denominator]
    }
  end
end

class Polynomial
  attr_reader :coefficients

  def initialize(coefficients)
    @coefficients = coefficients.map { |coefficient| KElement.from(coefficient) }
    @coefficients.pop while @coefficients.length > 1 && @coefficients.last.zero?
    @coefficients = [KElement.new(0)] if @coefficients.empty?
    freeze
  end

  def self.zero
    Polynomial.new([0])
  end

  def self.one
    Polynomial.new([1])
  end

  def self.constant(value)
    Polynomial.new([value])
  end

  def self.x
    Polynomial.new([0, 1])
  end

  def self.from(value)
    value.is_a?(Polynomial) ? value : Polynomial.constant(value)
  end

  def degree
    zero? ? -1 : coefficients.length - 1
  end

  def [](index)
    return KElement.new(0) if index.negative? || index >= coefficients.length
    coefficients[index]
  end

  def leading
    coefficients.last
  end

  def zero?
    coefficients.length == 1 && coefficients[0].zero?
  end

  def +(other)
    other = Polynomial.from(other)
    length = [coefficients.length, other.coefficients.length].max
    Polynomial.new(Array.new(length) { |index| self[index] + other[index] })
  end

  def -(other)
    other = Polynomial.from(other)
    length = [coefficients.length, other.coefficients.length].max
    Polynomial.new(Array.new(length) { |index| self[index] - other[index] })
  end

  def -@
    Polynomial.new(coefficients.map { |coefficient| -coefficient })
  end

  def *(other)
    other = Polynomial.from(other)
    return Polynomial.zero if zero? || other.zero?
    result = Array.new(degree + other.degree + 1) { KElement.new(0) }
    coefficients.each_with_index do |left, i|
      other.coefficients.each_with_index do |right, j|
        result[i + j] = result[i + j] + left * right
      end
    end
    Polynomial.new(result)
  end

  def /(scalar)
    inverse = KElement.from(scalar).inverse
    Polynomial.new(coefficients.map { |coefficient| coefficient * inverse })
  end

  def **(exponent)
    raise ArgumentError, "negative exponent" if exponent.negative?
    result = Polynomial.one
    base = self
    power = exponent
    while power.positive?
      result *= base if power.odd?
      base *= base
      power >>= 1
    end
    result
  end

  def divmod(divisor)
    divisor = Polynomial.from(divisor)
    raise ZeroDivisionError, "polynomial division by zero" if divisor.zero?
    quotient = Array.new([degree - divisor.degree + 1, 1].max) { KElement.new(0) }
    remainder = self
    until remainder.zero? || remainder.degree < divisor.degree
      shift = remainder.degree - divisor.degree
      factor = remainder.leading / divisor.leading
      quotient[shift] = quotient[shift] + factor
      subtraction = Polynomial.new(Array.new(shift) { KElement.new(0) } +
                                   divisor.coefficients.map { |c| c * factor })
      remainder -= subtraction
    end
    [Polynomial.new(quotient), remainder]
  end

  def %(divisor)
    divmod(divisor)[1]
  end

  def derivative
    return Polynomial.zero if degree <= 0
    Polynomial.new((1..degree).map { |index| self[index] * index })
  end

  def monic
    return self if zero?
    self / leading
  end

  def gcd(other)
    left = self
    right = Polynomial.from(other)
    until right.zero?
      left, right = right, left % right
    end
    left.monic
  end

  # Returns [g,s,t] with s*self + t*other = g.
  def xgcd(other)
    r0 = self
    r1 = Polynomial.from(other)
    s0 = Polynomial.one
    s1 = Polynomial.zero
    t0 = Polynomial.zero
    t1 = Polynomial.one
    until r1.zero?
      quotient, remainder = r0.divmod(r1)
      r0, r1 = r1, remainder
      s0, s1 = s1, s0 - quotient * s1
      t0, t1 = t1, t0 - quotient * t1
    end
    [r0, s0, t0]
  end

  def ==(other)
    other = Polynomial.from(other)
    coefficients == other.coefficients
  rescue TypeError, ArgumentError
    false
  end

  def coerce(other)
    [Polynomial.from(other), self]
  end

  def as_json
    terms = []
    coefficients.each_with_index do |coefficient, exponent|
      next if coefficient.zero?
      terms << { "q_exponent" => exponent, "coefficient" => coefficient.as_json }
    end
    { "degree" => degree, "terms_low_to_high" => terms }
  end

  def to_s(variable = "q")
    return "0" if zero?
    pieces = []
    coefficients.each_with_index do |coefficient, exponent|
      next if coefficient.zero?
      monomial = case exponent
                 when 0 then ""
                 when 1 then "*#{variable}"
                 else "*#{variable}^#{exponent}"
                 end
      pieces << "(#{coefficient})#{monomial}"
    end
    pieces.join(" + ")
  end
end

class QuotientRing
  attr_reader :modulus

  def initialize(modulus)
    @modulus = modulus
    certify(modulus.degree.positive?, "quotient modulus must have positive degree")
  end

  def element(value)
    return value if value.is_a?(Residue) && value.ring.equal?(self)
    Residue.new(self, Polynomial.from(value) % modulus)
  end

  def zero
    element(0)
  end

  def one
    element(1)
  end

  def inverse_certificate(value, label)
    value = element(value)
    gcd, bezout_value, bezout_modulus = value.polynomial.xgcd(modulus)
    certify(gcd.degree == 0 && !gcd.zero?,
            "denominator #{label} is not invertible modulo p (gcd degree #{gcd.degree})")
    scale = gcd[0].inverse
    inverse_polynomial = (bezout_value * scale) % modulus
    inverse = element(inverse_polynomial)
    certify(value * inverse == one, "inverse roundtrip failed for #{label}")
    normalized_identity = (bezout_value * scale) * value.polynomial +
                          (bezout_modulus * scale) * modulus
    certify(normalized_identity == Polynomial.one,
            "Bezout identity failed for denominator #{label}")
    record = {
      "label" => label,
      "gcd_degree" => 0,
      "denominator_representative" => value.polynomial.as_json,
      "inverse_representative" => inverse_polynomial.as_json,
      "bezout_identity_verified" => true,
      "multiplication_roundtrip_verified" => true
    }
    [inverse, record]
  end
end

class Residue
  attr_reader :ring, :polynomial

  def initialize(ring, polynomial)
    @ring = ring
    @polynomial = polynomial % ring.modulus
    freeze
  end

  def +(other)
    other = ring.element(other)
    Residue.new(ring, polynomial + other.polynomial)
  end

  def -(other)
    other = ring.element(other)
    Residue.new(ring, polynomial - other.polynomial)
  end

  def -@
    Residue.new(ring, -polynomial)
  end

  def *(other)
    other = ring.element(other)
    Residue.new(ring, polynomial * other.polynomial)
  end

  def **(exponent)
    raise ArgumentError, "negative exponent" if exponent.negative?
    result = ring.one
    base = self
    power = exponent
    while power.positive?
      result *= base if power.odd?
      base *= base
      power >>= 1
    end
    result
  end

  def inverse
    ring.inverse_certificate(self, "unlabelled constant or expression")[0]
  end

  def /(other)
    self * ring.element(other).inverse
  end

  def ==(other)
    other = ring.element(other)
    polynomial == other.polynomial
  rescue TypeError, ArgumentError
    false
  end

  def coerce(other)
    [ring.element(other), self]
  end

  def as_json
    polynomial.as_json
  end
end

class CanonicalBundle
  EXPECTED_BUNDLE_SHA256 = "ace8f69bc55d219d4c25901f866a310997a128726d4e0dbdce9a533687855ee0"
  EXPECTED_MANIFEST_SHA256 = "b8efd5fa4de03c7c6edf28ac0606044098dda2e3e4366672717540c15e3c94d7"
  EXPECTED_BUNDLE_BYTES = 34_436
  EXPECTED_COORDINATES = [
    ["F0", 2, 253, "0f6cc7a1653adfb9be5474bbb74fdb9aa3c576636696f6995e3517166b0827a2"],
    ["F1", 207, 5_570, "547e2a3e0beb2e04023380dece6799753ce8f9c25a146a18e9b51325d890fc6c"],
    ["F2", 273, 7_432, "eb749391264a63d79a35b9285afc279cf1bd83c2b3554391453ea3c0394aab48"],
    ["F3", 343, 9_524, "c17dcf5ee397896f7d1d8e437a0f3ec56400e41123986bee3e8bf11862a35d1a"],
    ["F4", 372, 11_631, "9de82fbde901824b01fcadf768ca15de6372dea1d108a8d0adfa09d09e546e12"]
  ].freeze

  attr_reader :coordinates, :metadata

  def initialize(canonical_path, manifest_path)
    raw = File.binread(canonical_path)
    manifest_raw = File.binread(manifest_path)
    certify(Digest::SHA256.hexdigest(raw) == EXPECTED_BUNDLE_SHA256,
            "canonical SHA-256 mismatch")
    certify(Digest::SHA256.hexdigest(manifest_raw) == EXPECTED_MANIFEST_SHA256,
            "manifest SHA-256 mismatch")
    certify(raw.bytesize == EXPECTED_BUNDLE_BYTES, "canonical byte-count mismatch")
    certify(raw.ascii_only?, "canonical bundle is not ASCII")
    certify(raw.end_with?("\n") && !raw.include?("\r"),
            "canonical bundle must use LF and have a final newline")
    parse_manifest(manifest_raw)
    parse_bundle(raw)
  end

  def parse_manifest(raw)
    parsed = JSON.parse(raw)
    serialization = parsed.fetch("canonical_serialization")
    certify(serialization.fetch("bundle_sha256") == EXPECTED_BUNDLE_SHA256,
            "manifest does not bind expected canonical hash")
    certify(serialization.fetch("bundle_byte_count") == EXPECTED_BUNDLE_BYTES,
            "manifest does not bind expected canonical byte count")
    certify(serialization.fetch("encoding") == "ASCII", "unexpected encoding in manifest")
    certify(parsed.fetch("coefficient_field").fetch("presentation") ==
            "Q[eta]/(eta^2+2)", "unexpected coefficient field")
    manifest_coordinates = parsed.fetch("coordinates")
    certify(manifest_coordinates.length == EXPECTED_COORDINATES.length,
            "manifest coordinate count mismatch")
    EXPECTED_COORDINATES.each_with_index do |expected, index|
      actual = manifest_coordinates[index]
      name, terms, bytes, sha = expected
      certify(actual.fetch("name") == name, "manifest coordinate name mismatch")
      certify(actual.fetch("term_count") == terms, "manifest term count mismatch for #{name}")
      certify(actual.fetch("byte_count") == bytes, "manifest byte count mismatch for #{name}")
      certify(actual.fetch("sha256") == sha, "manifest hash mismatch for #{name}")
    end
    @metadata = {
      "canonical_sha256" => EXPECTED_BUNDLE_SHA256,
      "manifest_sha256" => EXPECTED_MANIFEST_SHA256,
      "canonical_bytes" => EXPECTED_BUNDLE_BYTES,
      "artifact_id_bound_but_not_repeated" => true
    }
  rescue JSON::ParserError => error
    raise CertificateFailure, "manifest JSON parse failure: #{error.message}"
  end

  def parse_bundle(raw)
    lines = raw.lines
    index = 0
    certify(lines[index] == "EXACT-D1-KELLER-BUNDLE-V1\n", "bad bundle marker")
    index += 1
    parsed_coordinates = []
    EXPECTED_COORDINATES.each do |expected|
      start = index
      name, expected_terms, expected_bytes, expected_sha = expected
      required_headers = [
        "EXACT-D1-KELLER-COORDINATE-V1\n",
        "field=Q[eta]/(eta^2+2)\n",
        "eta-generator=formal-class-of-t-mod-(t^2+2);mu=(2+4*eta)/9\n",
        "variables=rho,Y1,Y2,Y3,Y4\n",
        "monomial-order=descending-lexicographic-exponent-tuples\n",
        "coordinate=#{name}\n",
        "term-count=#{expected_terms}\n"
      ]
      required_headers.each do |header|
        certify(lines[index] == header, "bad header for #{name} at line #{index + 1}")
        index += 1
      end
      terms = []
      previous_exponents = nil
      expected_terms.times do
        line = lines[index]
        certify(!line.nil?, "truncated terms for #{name}")
        match = line.match(/\A(\d+),(\d+),(\d+),(\d+),(\d+)\|(-?\d+),(-?\d+),(\d+)\n\z/)
        certify(!match.nil?, "malformed term for #{name} at line #{index + 1}")
        exponents = match.captures[0, 5].map(&:to_i)
        n0, n1, denominator = match.captures[5, 3].map(&:to_i)
        certify(denominator.positive?, "nonpositive coefficient denominator")
        certify(n0.gcd(n1).gcd(denominator) == 1, "unnormalized coefficient record")
        if previous_exponents
          certify((previous_exponents <=> exponents) == 1,
                  "terms not in strict descending lexicographic order for #{name}")
        end
        previous_exponents = exponents
        terms << [exponents, KElement.new(Rational(n0, denominator),
                                         Rational(n1, denominator))]
        index += 1
      end
      section = lines[start...index].join
      certify(section.bytesize == expected_bytes, "coordinate byte count mismatch for #{name}")
      certify(Digest::SHA256.hexdigest(section) == expected_sha,
              "coordinate SHA-256 mismatch for #{name}")
      parsed_coordinates << [name, terms]
    end
    certify(index == lines.length, "trailing data after F4")
    @coordinates = parsed_coordinates.freeze
  end

  def evaluate(point, ring)
    certify(point.length == 5, "expected five source coordinates")
    coordinates.map do |name, terms|
      maxima = Array.new(5, 0)
      terms.each do |exponents, _coefficient|
        5.times { |i| maxima[i] = [maxima[i], exponents[i]].max }
      end
      powers = 5.times.map do |i|
        list = [ring.one]
        maxima[i].times { list << list[-1] * point[i] }
        list
      end
      value = ring.zero
      terms.each do |exponents, coefficient|
        monomial = ring.element(coefficient)
        5.times { |i| monomial *= powers[i][exponents[i]] }
        value += monomial
      end
      [name, value]
    end
  end
end

def parse_arguments(argv)
  options = {
    canonical: File.expand_path("../data/map.txt", __dir__),
    manifest: File.expand_path("../data/map.json", __dir__),
    fault: nil
  }
  index = 0
  while index < argv.length
    case argv[index]
    when "--canonical"
      index += 1
      options[:canonical] = argv.fetch(index)
    when "--manifest"
      index += 1
      options[:manifest] = argv.fetch(index)
    when "--fault"
      index += 1
      options[:fault] = argv.fetch(index)
    when "--help"
      puts "usage: ruby verify_collision.rb [--canonical PATH] [--manifest PATH] [--fault NAME]"
      exit 0
    else
      raise CertificateFailure, "unknown argument #{argv[index].inspect}"
    end
    index += 1
  end
  allowed_faults = [nil, "nonsquarefree-polynomial", "nonunit-denominator",
                    "distinctness-perturbation", "point-perturbation"]
  certify(allowed_faults.include?(options[:fault]), "unknown fault mode")
  options
end

def construct_and_verify(bundle, fault)
  eta = KElement.new(0, 1)
  mu = (KElement.new(2) + KElement.new(4) * eta) / 9
  certify(eta * eta == KElement.new(-2), "eta relation failed")
  certify(KElement.new(9) * mu * mu - KElement.new(4) * mu + KElement.new(4) == 0,
          "mu relation failed")

  polynomial_x = Polynomial.x
  cubic = (KElement.new(219) * mu + 26) * (polynomial_x**3) +
          (KElement.new(301) * mu - 170) * (polynomial_x**2) +
          (KElement.new(45) * mu - 74) * polynomial_x +
          (KElement.new(63) * mu - 46)
  definition_polynomial = KElement.new(9) * polynomial_x * cubic
  integer_record_polynomial = Polynomial.new([
    0,
    KElement.new(-288, 252),
    KElement.new(-576, 180),
    KElement.new(-928, 1204),
    KElement.new(672, 876)
  ])
  certify(definition_polynomial == integer_record_polynomial,
          "expanded witness polynomial does not match defining formula")
  modulus = if fault == "nonsquarefree-polynomial"
              polynomial_x**2 * (polynomial_x**2 + 1)
            else
              definition_polynomial
            end
  certify(modulus.degree == 4, "witness polynomial degree is not four")

  derivative = modulus.derivative
  gcd, squarefree_s, squarefree_t = modulus.xgcd(derivative)
  certify(gcd.degree == 0 && !gcd.zero?,
          "witness polynomial is not squarefree (gcd with derivative has degree #{gcd.degree})")
  squarefree_scale = gcd[0].inverse
  squarefree_identity = (squarefree_s * squarefree_scale) * modulus +
                        (squarefree_t * squarefree_scale) * derivative
  certify(squarefree_identity == Polynomial.one, "squarefree Bezout identity failed")

  ring = QuotientRing.new(modulus)
  q = ring.element(polynomial_x)
  a_polynomial = (KElement.new(3) * mu - 2) / 2 +
                 (KElement.new(2) * (mu + 2) / 3) * polynomial_x -
                 (KElement.new(4) * (KElement.new(5) * mu - 2) / 3) * (polynomial_x**2)
  s_polynomial = (KElement.new(63) * mu - 46) / 256 -
                 ((KElement.new(45) * mu - 2) / 64) * polynomial_x +
                 ((KElement.new(9) * mu + 2) / 16) * (polynomial_x**2)
  s_prime = s_polynomial.derivative
  s_second = s_prime.derivative
  theta = -(q**2)
  tau = theta + ring.element(s_polynomial)
  denominator_records = []
  tau_for_inversion = fault == "nonunit-denominator" ? tau * q : tau
  tau_inverse, tau_record = ring.inverse_certificate(tau_for_inversion, "tau")
  denominator_records << tau_record
  numerator_n = -q + ring.element(s_prime) / 2
  z = numerator_n * tau_inverse
  y = z - ring.element(a_polynomial)
  g2 = tau * z - ring.element(s_prime) / 2
  x1 = -(KElement.new(3) * mu * tau * (z**2) +
         ring.element(s_prime) * z - ring.element(s_second) +
         KElement.new(2) * g2 * z) / 2
  gamma = ring.one - x1
  gamma_inverse, gamma_record = ring.inverse_certificate(gamma, "gamma")
  denominator_records << gamma_record

  l21 = -(KElement.new(9) * mu + 26) / 16
  l31 = -KElement.new(2) * (KElement.new(11) * mu - 14) / 3
  l32 = KElement.new(2) * (KElement.new(19) * mu - 16) / 3
  l41 = (KElement.new(9) * mu + 2) / 16
  l42 = -(KElement.new(9) * mu + 14) / 32
  q3 = (KElement.new(53) * mu - 26) / 24
  q4 = -(KElement.new(45) * mu - 17) / 32

  v1 = gamma - 1
  u1 = q * gamma_inverse
  v2 = u1 - 1 - l21 * v1
  v3 = y * (gamma_inverse**2) - l31 * v1 - l32 * v2 - q3 * (v1**2)
  v4 = theta * (gamma_inverse**3) - l41 * v1 - l42 * v2 - q4 * (v1**2)
  rho = gamma_inverse
  point = [
    rho,
    v1 * gamma,
    v2 * (gamma**2),
    v3 * (gamma**3),
    v4 * (gamma**3)
  ]
  point[1] += ring.one if fault == "distinctness-perturbation"
  # Y3 is absent from the recovery formula, so this fault reaches the full-map
  # evaluation gate instead of being rejected by the earlier distinctness gate.
  point[3] += ring.one if fault == "point-perturbation"

  source_v1 = rho * point[1]
  source_v2 = (rho**2) * point[2]
  recovered_gamma = ring.one + source_v1
  recovered_u1 = ring.one + l21 * source_v1 + source_v2
  recovered_q = recovered_gamma * recovered_u1
  certify(recovered_q == q,
          "source-point distinctness recovery identity failed")

  evaluated = bundle.evaluate(point, ring)
  target = [ring.one, ring.one, ring.zero, ring.zero, ring.zero]
  evaluated.each_with_index do |(name, value), index|
    certify(value == target[index], "canonical target identity failed for #{name}")
  end

  {
    "status" => "PASS",
    "claim" => "four distinct algebraic source points map exactly to (1,1,0,0,0)",
    "coefficient_field" => {
      "presentation" => "Q[eta]/(eta^2+2)",
      "eta_relation_verified" => true,
      "mu" => mu.as_json,
      "mu_relation_verified" => true
    },
    "input_binding" => bundle.metadata,
    "witness_polynomial" => {
      "definition" => "p(q)=9*q*((219*mu+26)q^3+(301*mu-170)q^2+(45*mu-74)q+(63*mu-46))",
      "relation_to_prior_P_star" => "p=-2304*P_star",
      "degree" => modulus.degree,
      "coefficient_record" => modulus.as_json,
      "gcd_with_derivative_degree" => 0,
      "squarefree_bezout_identity_verified" => true,
      "consequence_over_algebraic_closure" => "exactly four distinct roots"
    },
    "rational_function_denominators" => denominator_records,
    "source_coordinate_representatives_mod_p" => {
      "rho" => point[0].as_json,
      "Y1" => point[1].as_json,
      "Y2" => point[2].as_json,
      "Y3" => point[3].as_json,
      "Y4" => point[4].as_json
    },
    "distinctness" => {
      "recovery_formula" => "q=(1+rho*Y1)*(1+l21*rho*Y1+rho^2*Y2)",
      "recovery_identity_mod_p_verified" => true,
      "argument" => "different roots have different recovered q, hence different source tuples"
    },
    "canonical_map_evaluation" => evaluated.map { |name, value|
      { "coordinate" => name, "remainder" => value.as_json }
    },
    "target" => [1, 1, 0, 0, 0],
    "numeric_root_finding_used" => false,
    "external_cas_used" => false,
    "runtime_stack" => "Ruby #{RUBY_VERSION} standard library"
  }
end

begin
  options = parse_arguments(ARGV)
  bundle = CanonicalBundle.new(options[:canonical], options[:manifest])
  result = construct_and_verify(bundle, options[:fault])
  puts JSON.pretty_generate(result)
rescue CertificateFailure, ZeroDivisionError, KeyError, Errno::ENOENT => error
  warn "CERTIFICATE FAILURE: #{error.message}"
  exit 1
end
