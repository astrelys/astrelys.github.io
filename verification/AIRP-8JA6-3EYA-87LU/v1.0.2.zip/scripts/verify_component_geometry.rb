#!/usr/bin/env ruby
# frozen_string_literal: true

# Exact the component theorem Part 1 certificate, publication-interface v2.
#
# Deliberate independence boundary:
# - Ruby Integer/Rational only; no SymPy, Python, CAS, network, or generator.
# - The frozen canonical ASCII map is parsed as data, never as executable code.
# - The sweep and all four birational layers are rebuilt from the displayed
#   formulas, then the H0/h boundary and reduced-singular-locus inputs are
#   checked in the same exact arithmetic kernel.

require "digest"
require "json"

unless ARGV.length == 3
  warn "usage: verify_component_geometry.rb CANONICAL_MAP MANIFEST_JSON CLAIM_SCOPE"
  exit 64
end

CANONICAL_PATH = File.expand_path(ARGV.fetch(0))
MANIFEST_PATH = File.expand_path(ARGV.fetch(1))
CLAIM_SCOPE_PATH = File.expand_path(ARGV.fetch(2))
CANONICAL_SHA256 = "ace8f69bc55d219d4c25901f866a310997a128726d4e0dbdce9a533687855ee0"
MANIFEST_SHA256 = "b8efd5fa4de03c7c6edf28ac0606044098dda2e3e4366672717540c15e3c94d7"
CLAIM_SCOPE_SHA256 = "f7927d191989290d474c6899db3fd6e046e713a3f29194324b7539af3377c998"
CLAIM_SCOPE_LINES = [
  "COMPONENT-COMPUTATIONAL-SCOPE-V1",
  "ALLOW=DIRECT_DIMENSION_MATCHING_IDENTITY_STABILIZATION_ONLY",
  "DENY=GENERATED_STABLE_INEQUIVALENCE_FROM_THIS_COMPUTATION_ALONE",
  "DENY=COMPUTATION_ALONE_PROVES_COMPONENT_THEOREM",
  "DENY=GEOMETRY_CHECK_ALONE_PROVES_JELONEK_COMPONENT"
].freeze

class CertificateFailure < StandardError; end

def assert(label, condition)
  raise CertificateFailure, label unless condition
  puts "PASS #{label}"
end

def rat(value)
  value.is_a?(Rational) ? value : Rational(value, 1)
end

# Exact coefficient field Q[eta]/(eta^2+2), represented by a+b*eta.
class QE
  attr_reader :a, :b

  def initialize(a = 0, b = 0)
    @a = a.is_a?(Rational) ? a : Rational(a, 1)
    @b = b.is_a?(Rational) ? b : Rational(b, 1)
  end

  def self.wrap(value)
    value.is_a?(QE) ? value : QE.new(value, 0)
  end

  def +(other)
    return other + self if defined?(Poly) && other.is_a?(Poly)
    return other + self if defined?(Rat) && other.is_a?(Rat)
    other = QE.wrap(other)
    QE.new(@a + other.a, @b + other.b)
  end

  def -(other)
    return -(other - self) if defined?(Poly) && other.is_a?(Poly)
    return -(other - self) if defined?(Rat) && other.is_a?(Rat)
    other = QE.wrap(other)
    QE.new(@a - other.a, @b - other.b)
  end

  def -@
    QE.new(-@a, -@b)
  end

  def *(other)
    return other * self if defined?(Poly) && other.is_a?(Poly)
    return other * self if defined?(Rat) && other.is_a?(Rat)
    other = QE.wrap(other)
    QE.new(@a * other.a - 2 * @b * other.b,
           @a * other.b + @b * other.a)
  end

  def inverse
    norm = @a * @a + 2 * @b * @b
    raise ZeroDivisionError, "zero in Q(eta)" if norm.zero?
    QE.new(@a / norm, -@b / norm)
  end

  def /(other)
    self * QE.wrap(other).inverse
  end

  def **(power)
    raise ArgumentError, "negative power" if power.negative?
    result = QE.new(1)
    base = self
    exponent = power
    while exponent.positive?
      result *= base if exponent.odd?
      exponent >>= 1
      base *= base if exponent.positive?
    end
    result
  end

  def ==(other)
    other = QE.wrap(other)
    @a == other.a && @b == other.b
  end

  def zero?
    @a.zero? && @b.zero?
  end

  def coerce(other)
    [QE.wrap(other), self]
  end

  def canonical_triple
    d = @a.denominator.lcm(@b.denominator)
    n0 = @a.numerator * (d / @a.denominator)
    n1 = @b.numerator * (d / @b.denominator)
    g = n0.abs.gcd(n1.abs).gcd(d)
    [n0 / g, n1 / g, d / g]
  end

  def to_s
    n0, n1, d = canonical_triple
    "(#{n0}+#{n1}*eta)/#{d}"
  end
end

# Sparse multivariate polynomial over QE. Exponents are immutable arrays.
class Poly
  attr_reader :nvars, :terms

  def initialize(nvars, raw_terms = {})
    @nvars = nvars
    @terms = {}
    raw_terms.each do |exponents, coefficient|
      raise ArgumentError, "wrong exponent length" unless exponents.length == nvars
      key = exponents.map(&:to_i).freeze
      raise ArgumentError, "negative exponent" if key.any?(&:negative?)
      value = QE.wrap(coefficient)
      next if value.zero?
      sum = (@terms[key] || QE.new) + value
      sum.zero? ? @terms.delete(key) : @terms[key] = sum
    end
  end

  def self.zero(nvars)
    Poly.new(nvars)
  end

  def self.one(nvars)
    constant(nvars, 1)
  end

  def self.constant(nvars, coefficient)
    value = QE.wrap(coefficient)
    return zero(nvars) if value.zero?
    Poly.new(nvars, { Array.new(nvars, 0) => value })
  end

  def self.variable(nvars, index)
    exponents = Array.new(nvars, 0)
    exponents[index] = 1
    Poly.new(nvars, { exponents => QE.new(1) })
  end

  def wrap(other)
    other.is_a?(Poly) ? other : Poly.constant(@nvars, other)
  end

  def check_ring(other)
    raise ArgumentError, "polynomial ring mismatch" unless @nvars == other.nvars
  end

  def +(other)
    other = wrap(other)
    check_ring(other)
    data = @terms.dup
    other.terms.each do |exponents, coefficient|
      value = (data[exponents] || QE.new) + coefficient
      value.zero? ? data.delete(exponents) : data[exponents] = value
    end
    Poly.new(@nvars, data)
  end

  def -(other)
    self + (-wrap(other))
  end

  def -@
    Poly.new(@nvars, @terms.transform_values { |coefficient| -coefficient })
  end

  def *(other)
    other = wrap(other)
    check_ring(other)
    return Poly.zero(@nvars) if zero? || other.zero?
    data = {}
    @terms.each do |left_exp, left_coefficient|
      other.terms.each do |right_exp, right_coefficient|
        exponents = Array.new(@nvars) { |i| left_exp[i] + right_exp[i] }.freeze
        value = (data[exponents] || QE.new) + left_coefficient * right_coefficient
        value.zero? ? data.delete(exponents) : data[exponents] = value
      end
    end
    Poly.new(@nvars, data)
  end

  def /(scalar)
    scalar = QE.wrap(scalar)
    Poly.new(@nvars, @terms.transform_values { |coefficient| coefficient / scalar })
  end

  def **(power)
    raise ArgumentError, "negative power" if power.negative?
    result = Poly.one(@nvars)
    base = self
    exponent = power
    while exponent.positive?
      result *= base if exponent.odd?
      exponent >>= 1
      base *= base if exponent.positive?
    end
    result
  end

  def deriv(index)
    data = {}
    @terms.each do |exponents, coefficient|
      next if exponents[index].zero?
      next_exp = exponents.dup
      multiplier = next_exp[index]
      next_exp[index] -= 1
      data[next_exp] = coefficient * multiplier
    end
    Poly.new(@nvars, data)
  end

  def compose(images)
    raise ArgumentError, "wrong image count" unless images.length == @nvars
    target_nvars = images.first.nvars
    raise ArgumentError, "image ring mismatch" unless images.all? { |p| p.nvars == target_nvars }
    maxima = Array.new(@nvars, 0)
    @terms.each_key do |exponents|
      @nvars.times { |i| maxima[i] = [maxima[i], exponents[i]].max }
    end
    powers = images.each_with_index.map do |image, i|
      values = [Poly.one(target_nvars)]
      1.upto(maxima[i]) { values << values[-1] * image }
      values
    end
    total = Poly.zero(target_nvars)
    @terms.each do |exponents, coefficient|
      term = Poly.constant(target_nvars, coefficient)
      @nvars.times { |i| term *= powers[i][exponents[i]] }
      total += term
    end
    total
  end

  def evaluate_rats(images)
    raise ArgumentError, "wrong image count" unless images.length == @nvars
    target_nvars = images.first.nvars
    maxima = Array.new(@nvars, 0)
    @terms.each_key do |exponents|
      @nvars.times { |i| maxima[i] = [maxima[i], exponents[i]].max }
    end
    powers = images.each_with_index.map do |image, i|
      values = [Rat.one(target_nvars)]
      1.upto(maxima[i]) { values << values[-1] * image }
      values
    end
    total = Rat.zero(target_nvars)
    @terms.each do |exponents, coefficient|
      term = Rat.constant(target_nvars, coefficient)
      @nvars.times { |i| term *= powers[i][exponents[i]] }
      total += term
    end
    total
  end

  def split_variable(index)
    result = Hash.new { |hash, degree| hash[degree] = Poly.zero(@nvars - 1) }
    @terms.each do |exponents, coefficient|
      degree = exponents[index]
      reduced = exponents.dup
      reduced.delete_at(index)
      result[degree] = result[degree] + Poly.new(@nvars - 1, { reduced => coefficient })
    end
    result
  end

  def coefficient_in(index, degree)
    split_variable(index)[degree]
  end

  def degree_in(index)
    return -1 if zero?
    @terms.keys.map { |exponents| exponents[index] }.max
  end

  def total_degree
    return -1 if zero?
    @terms.keys.map { |exponents| exponents.sum }.max
  end

  def zero?
    @terms.empty?
  end

  def ==(other)
    other = wrap(other)
    @nvars == other.nvars && @terms == other.terms
  end

  def coerce(other)
    [Poly.constant(@nvars, other), self]
  end

  def fingerprint
    records = @terms.sort { |(a, _), (b, _)| b <=> a }.map do |exponents, coefficient|
      n0, n1, d = coefficient.canonical_triple
      "#{exponents.join(',')}|#{n0},#{n1},#{d}\n"
    end.join
    Digest::SHA256.hexdigest(records)
  end
end

# Rational functions with equality checked by exact cross multiplication.
class Rat
  attr_reader :num, :den, :nvars

  def initialize(num, den = nil)
    raise ArgumentError, "numerator must be polynomial" unless num.is_a?(Poly)
    den ||= Poly.one(num.nvars)
    raise ArgumentError, "denominator ring mismatch" unless den.is_a?(Poly) && den.nvars == num.nvars
    raise ZeroDivisionError, "zero polynomial denominator" if den.zero?
    @num = num
    @den = den
    @nvars = num.nvars
  end

  def self.zero(nvars)
    Rat.new(Poly.zero(nvars))
  end

  def self.one(nvars)
    Rat.new(Poly.one(nvars))
  end

  def self.constant(nvars, coefficient)
    Rat.new(Poly.constant(nvars, coefficient))
  end

  def self.wrap(value, nvars)
    return value if value.is_a?(Rat)
    return Rat.new(value) if value.is_a?(Poly)
    Rat.constant(nvars, value)
  end

  def +(other)
    other = Rat.wrap(other, @nvars)
    Rat.new(@num * other.den + other.num * @den, @den * other.den)
  end

  def -(other)
    self + (-Rat.wrap(other, @nvars))
  end

  def -@
    Rat.new(-@num, @den)
  end

  def *(other)
    other = Rat.wrap(other, @nvars)
    Rat.new(@num * other.num, @den * other.den)
  end

  def /(other)
    other = Rat.wrap(other, @nvars)
    raise ZeroDivisionError, "zero rational function" if other.num.zero?
    Rat.new(@num * other.den, @den * other.num)
  end

  def **(power)
    raise ArgumentError, "negative power" if power.negative?
    Rat.new(@num**power, @den**power)
  end

  def ==(other)
    other = Rat.wrap(other, @nvars)
    @num * other.den == other.num * @den
  end

  def zero?
    @num.zero?
  end

  def coerce(other)
    [Rat.wrap(other, @nvars), self]
  end
end

def polynomial_determinant(matrix)
  size = matrix.length
  raise ArgumentError, "empty/non-square matrix" if size.zero? || matrix.any? { |row| row.length != size }
  return matrix[0][0] if size == 1
  nvars = matrix[0][0].nvars
  total = Poly.zero(nvars)
  matrix[0].each_with_index do |entry, column|
    next if entry.zero?
    minor = matrix[1..-1].map { |row| row.each_with_index.reject { |_, j| j == column }.map(&:first) }
    term = entry * polynomial_determinant(minor)
    total += column.even? ? term : -term
  end
  total
end

def sylvester_resultant(first, second)
  # Coefficient arrays are low degree to high degree, with Poly coefficients.
  m = first.length - 1
  n = second.length - 1
  raise ArgumentError, "zero leading coefficient" if first[-1].zero? || second[-1].zero?
  ring_nvars = first[-1].nvars
  zero = Poly.zero(ring_nvars)
  rows = []
  n.times do |shift|
    row = Array.new(m + n) { zero }
    first.reverse.each_with_index { |coefficient, j| row[shift + j] = coefficient }
    rows << row
  end
  m.times do |shift|
    row = Array.new(m + n) { zero }
    second.reverse.each_with_index { |coefficient, j| row[shift + j] = coefficient }
    rows << row
  end
  polynomial_determinant(rows)
end

def parse_frozen_bundle
  canonical_bytes = File.binread(CANONICAL_PATH)
  manifest_bytes = File.binread(MANIFEST_PATH)
  assert("canonical SHA-256 fixed", Digest::SHA256.hexdigest(canonical_bytes) == CANONICAL_SHA256)
  assert("manifest SHA-256 fixed", Digest::SHA256.hexdigest(manifest_bytes) == MANIFEST_SHA256)
  assert("canonical byte count 34436", canonical_bytes.bytesize == 34_436)
  assert("manifest byte count 2034", manifest_bytes.bytesize == 2034)
  assert("canonical is ASCII", canonical_bytes.ascii_only?)
  assert("canonical LF-only with final newline", !canonical_bytes.include?("\r") && canonical_bytes.end_with?("\n"))

  manifest = JSON.parse(manifest_bytes)
  assert("manifest declares canonical hash", manifest.dig("canonical_serialization", "bundle_sha256") == CANONICAL_SHA256)
  assert("manifest field presentation", manifest.dig("coefficient_field", "presentation") == "Q[eta]/(eta^2+2)")
  assert("manifest input order", manifest["input_variable_order"] == %w[rho Y1 Y2 Y3 Y4])

  lines = canonical_bytes.lines
  index = 0
  assert("bundle magic", lines[index]&.chomp == "EXACT-D1-KELLER-BUNDLE-V1")
  index += 1
  coordinates = []
  sections = []
  while index < lines.length
    start = index
    expected_header = [
      "EXACT-D1-KELLER-COORDINATE-V1",
      "field=Q[eta]/(eta^2+2)",
      "eta-generator=formal-class-of-t-mod-(t^2+2);mu=(2+4*eta)/9",
      "variables=rho,Y1,Y2,Y3,Y4",
      "monomial-order=descending-lexicographic-exponent-tuples"
    ]
    expected_header.each do |expected|
      assert("canonical section header #{expected}", lines[index]&.chomp == expected)
      index += 1
    end
    name_line = lines[index]&.chomp
    count_line = lines[index + 1]&.chomp
    raise CertificateFailure, "missing coordinate metadata" unless name_line&.start_with?("coordinate=") && count_line&.start_with?("term-count=")
    name = name_line.split("=", 2)[1]
    count = Integer(count_line.split("=", 2)[1], 10)
    index += 2
    terms = {}
    previous = nil
    count.times do
      line = lines[index]&.chomp
      raise CertificateFailure, "truncated coordinate #{name}" unless line
      exponent_text, coefficient_text = line.split("|", 2)
      raise CertificateFailure, "bad term line #{line}" unless exponent_text && coefficient_text
      exponents = exponent_text.split(",").map { |part| Integer(part, 10) }
      coefficient_parts = coefficient_text.split(",").map { |part| Integer(part, 10) }
      raise CertificateFailure, "bad exponent arity" unless exponents.length == 5
      raise CertificateFailure, "bad coefficient arity" unless coefficient_parts.length == 3
      n0, n1, denominator = coefficient_parts
      raise CertificateFailure, "nonpositive denominator" unless denominator.positive?
      raise CertificateFailure, "nonprimitive coefficient record" unless n0.abs.gcd(n1.abs).gcd(denominator) == 1
      raise CertificateFailure, "zero coefficient record" if n0.zero? && n1.zero?
      if previous
        raise CertificateFailure, "monomial order violation" unless (previous <=> exponents) == 1
      end
      previous = exponents
      raise CertificateFailure, "duplicate exponent" if terms.key?(exponents)
      terms[exponents] = QE.new(Rational(n0, denominator), Rational(n1, denominator))
      index += 1
    end
    coordinates << Poly.new(5, terms)
    sections << lines[start...index].join
    assert("parsed #{name} term count", coordinates[-1].terms.length == count)
  end

  assert("five canonical coordinates", coordinates.length == 5)
  assert("canonical term counts", coordinates.map { |p| p.terms.length } == [2, 207, 273, 343, 372])
  assert("canonical total degrees", coordinates.map(&:total_degree) == [3, 27, 29, 31, 31])
  manifest["coordinates"].each_with_index do |record, i|
    assert("coordinate #{record['name']} byte count", sections[i].bytesize == record["byte_count"])
    assert("coordinate #{record['name']} SHA-256", Digest::SHA256.hexdigest(sections[i]) == record["sha256"])
  end
  coordinates
end

MU = QE.new(Rational(2, 9), Rational(4, 9))
A0 = (3 * MU - 2) / 2
A1 = 2 * (MU + 2) / 3
A2 = -4 * (5 * MU - 2) / 3
S0 = (63 * MU - 46) / 256
S1C = -(45 * MU - 2) / 64
S2C = (9 * MU + 2) / 16
KAPPA = -3 * MU / 2

L21 = -(9 * MU + 26) / 16
L31 = -2 * (11 * MU - 14) / 3
L32 = 2 * (19 * MU - 16) / 3
L41 = (9 * MU + 2) / 16
L42 = -(9 * MU + 14) / 32
Q3 = (53 * MU - 26) / 24
Q4 = -(45 * MU - 17) / 32
BETA = 3 * MU + 2
K_COMPONENT = QE.new(Rational(-7, 12), Rational(1, 3))

def build_sweep
  # First build in (x,y,theta), where the Hamiltonian derivatives are taken.
  x3 = Poly.variable(3, 0)
  y3 = Poly.variable(3, 1)
  theta3 = Poly.variable(3, 2)
  a = A0 + A1 * x3 + A2 * x3**2
  s = S0 + S1C * x3 + S2C * x3**2
  ap = a.deriv(0)
  app = ap.deriv(0)
  sp = s.deriv(0)
  spp = sp.deriv(0)
  tau = theta3 + s
  z = y3 + a
  f = tau * z - sp / 2
  g = MU * tau * z**3 - (ap * tau + spp / 2) * z + app * tau / 2 + spp * a / 2 + KAPPA
  lf_f = f.deriv(0) + 2 * f * f.deriv(2)
  gy = g.deriv(1)
  x1 = -(gy + lf_f) / 2

  gamma4 = Poly.variable(4, 0)
  x4 = Poly.variable(4, 1)
  y4 = Poly.variable(4, 2)
  theta4 = Poly.variable(4, 3)
  lift = [x4, y4, theta4]
  f4 = f.compose(lift)
  g4 = g.compose(lift)
  x14 = x1.compose(lift)
  sweep1 = x14 + gamma4
  sweep2 = f4 + x4 * sweep1
  sweep3 = 2 * x4 * f4 - theta4 + x4**2 * sweep1
  sweep4 = g4 + y4 * sweep1
  [sweep1, sweep2, sweep3, sweep4]
end

# The sweep determinant and generic degree are imported only through the frozen
# upstream Jacobian/degree contracts.  This Part 1 executable deliberately contains no
# dormant duplicate verifier for either contract.

def verify_stage_inverse
  # v -> (gamma,u) -> v
  v = 4.times.map { |i| Poly.variable(4, i) }
  v1, v2, v3, v4 = v
  gamma = 1 + v1
  u1 = 1 + L21 * v1 + v2
  u2 = L31 * v1 + L32 * v2 + v3 + Q3 * v1**2
  u3 = L41 * v1 + L42 * v2 + v4 + Q4 * v1**2
  recovered_v1 = gamma - 1
  recovered_v2 = u1 - 1 - L21 * recovered_v1
  recovered_v3 = u2 - L31 * recovered_v1 - L32 * recovered_v2 - Q3 * recovered_v1**2
  recovered_v4 = u3 - L41 * recovered_v1 - L42 * recovered_v2 - Q4 * recovered_v1**2
  assert("stage inverse after forward", [recovered_v1, recovered_v2, recovered_v3, recovered_v4] == v)

  out = 4.times.map { |i| Poly.variable(4, i) }
  ogamma, ou1, ou2, ou3 = out
  iv1 = ogamma - 1
  iv2 = ou1 - 1 - L21 * iv1
  iv3 = ou2 - L31 * iv1 - L32 * iv2 - Q3 * iv1**2
  iv4 = ou3 - L41 * iv1 - L42 * iv2 - Q4 * iv1**2
  forward_again = [
    1 + iv1,
    1 + L21 * iv1 + iv2,
    L31 * iv1 + L32 * iv2 + iv3 + Q3 * iv1**2,
    L41 * iv1 + L42 * iv2 + iv4 + Q4 * iv1**2
  ]
  assert("stage forward after inverse", forward_again == out)
  stage_jacobian = [gamma, u1, u2, u3].map { |coordinate| 4.times.map { |j| coordinate.deriv(j) } }
  assert("stage Jacobian determinant one", polynomial_determinant(stage_jacobian) == 1)
end

def verify_rational_layer_inverses
  # Weighted source layer on rho != 0.
  src = 5.times.map { |i| Poly.variable(5, i) }
  rho, y1, y2, y3, y4 = src
  v = [rho * y1, rho**2 * y2, rho**3 * y3, rho**3 * y4]
  recovered = [Rat.new(v[0], rho), Rat.new(v[1], rho**2), Rat.new(v[2], rho**3), Rat.new(v[3], rho**3)]
  assert("weighted-source inverse after forward", recovered == [y1, y2, y3, y4].map { |p| Rat.new(p) })

  # Weighted parameter layer on gamma != 0.
  par = 4.times.map { |i| Poly.variable(4, i) }
  gamma, u1, u2, u3 = par
  x = gamma * u1
  y = gamma**2 * u2
  theta = gamma**3 * u3
  recovered_u = [Rat.new(x, gamma), Rat.new(y, gamma**2), Rat.new(theta, gamma**3)]
  assert("weighted-parameter inverse after forward", recovered_u == [u1, u2, u3].map { |p| Rat.new(p) })

  # Radial coordinate and target dehomogenization.
  radial = 2.times.map { |i| Poly.variable(2, i) }
  rrho, rgamma = radial
  cc = rrho * rgamma
  assert("radial recovery rho=C/gamma", Rat.new(cc, rgamma) == rrho)

  target = 5.times.map { |i| Poly.variable(5, i) }
  c, s1, s2, s3, s4 = target
  f = [Rat.new(s1, c), Rat.new(s2, c**2), Rat.new(s3, c**3), Rat.new(s4, c**3)]
  recovered_s = [f[0] * c, f[1] * c**2, f[2] * c**3, f[3] * c**3]
  assert("target-dehomogenization inverse after forward", recovered_s == [s1, s2, s3, s4].map { |p| Rat.new(p) })

  # Composite inverse of the three source-coordinate layers.  This explicitly
  # keeps the central variables (rho,gamma,x,y,theta) separate from the final
  # canonical source variables.
  central = 5.times.map { |i| Poly.variable(5, i) }
  crho, cgamma, cx, cy, ctheta = central
  ru1 = Rat.new(cx, cgamma)
  ru2 = Rat.new(cy, cgamma**2)
  ru3 = Rat.new(ctheta, cgamma**3)
  rv1 = Rat.new(cgamma - 1)
  rv2 = ru1 - 1 - L21 * rv1
  rv3 = ru2 - L31 * rv1 - L32 * rv2 - Q3 * rv1**2
  rv4 = ru3 - L41 * rv1 - L42 * rv2 - Q4 * rv1**2
  original_y = [
    rv1 / Rat.new(crho),
    rv2 / Rat.new(crho**2),
    rv3 / Rat.new(crho**3),
    rv4 / Rat.new(crho**3)
  ]
  forward_v = [
    Rat.new(crho) * original_y[0],
    Rat.new(crho**2) * original_y[1],
    Rat.new(crho**3) * original_y[2],
    Rat.new(crho**3) * original_y[3]
  ]
  fv1, fv2, fv3, fv4 = forward_v
  forward_gamma = 1 + fv1
  forward_u1 = 1 + L21 * fv1 + fv2
  forward_u2 = L31 * fv1 + L32 * fv2 + fv3 + Q3 * fv1**2
  forward_u3 = L41 * fv1 + L42 * fv2 + fv4 + Q4 * fv1**2
  forward_central = [
    Rat.new(crho),
    forward_gamma,
    forward_gamma * forward_u1,
    forward_gamma**2 * forward_u2,
    forward_gamma**3 * forward_u3
  ]
  assert("composite source-layer forward after rational inverse",
         forward_central == central.map { |p| Rat.new(p) })

  # The birational change (rho,gamma)<->(C,gamma) makes C an independent
  # rational coordinate rather than an extra algebraic condition.
  ccentral = crho * cgamma
  assert("central field change (rho,gamma)<->(C,gamma)",
         Rat.new(ccentral, cgamma) == crho)
end

def verify_same_object_bridge(sweep, canonical)
  rho, y1, y2, y3, y4 = 5.times.map { |i| Poly.variable(5, i) }
  v1 = rho * y1
  v2 = rho**2 * y2
  v3 = rho**3 * y3
  v4 = rho**3 * y4
  gamma = 1 + v1
  u1 = 1 + L21 * v1 + v2
  u2 = L31 * v1 + L32 * v2 + v3 + Q3 * v1**2
  u3 = L41 * v1 + L42 * v2 + v4 + Q4 * v1**2
  x = gamma * u1
  y = gamma**2 * u2
  theta = gamma**3 * u3
  c = rho * gamma
  derived_sweep = sweep.map { |coordinate| coordinate.compose([gamma, x, y, theta]) }

  assert("canonical F0 equals C=rho*gamma", canonical[0] == c)
  weights = [1, 2, 3, 3]
  4.times do |i|
    assert("same-object bridge S#{i + 1}=C^#{weights[i]}*F#{i + 1}", derived_sweep[i] == c**weights[i] * canonical[i + 1])
  end
  puts "INFO derived-sweep-after-layers-term-counts=#{derived_sweep.map { |p| p.terms.length }.inspect}"
  puts "INFO canonical-coordinate-fingerprints=#{canonical.map(&:fingerprint).inspect}"
  puts "DEDUCTION exact identities are the diagram beta o F_canonical = (id_C x S) o alpha"
  puts "DEDUCTION k(rho,gamma,x,y,theta)=k(C,gamma,x,y,theta) via rho=C/gamma, so C is an independent factor"
  puts "DEDUCTION the frozen canonical map and the formula-level sweep define isomorphic generic function-field extensions"
  puts "DEPENDENCY geometric degree four is required by the component theorem but is not re-proved by this Part 1 run"
end

def divide_by_variable_power(poly, index, power)
  data = {}
  poly.terms.each do |exponents, coefficient|
    raise CertificateFailure, "polynomial is not divisible by requested variable power" if exponents[index] < power
    reduced = exponents.dup
    reduced[index] -= power
    data[reduced] = coefficient
  end
  Poly.new(poly.nvars, data)
end

def set_variables_zero(poly, indices)
  Poly.new(poly.nvars, poly.terms.reject do |exponents, _coefficient|
    indices.any? { |index| exponents[index].positive? }
  end)
end

def divisible_by_variable?(poly, index)
  !poly.zero? && poly.terms.keys.all? { |exponents| exponents[index].positive? }
end

def verify_compact_h0_link
  assert("COMPONENT field relation eta^2=-2", QE.new(0, 1)**2 + 2 == 0)
  assert("COMPONENT mu relation", 9 * MU**2 - 4 * MU + 4 == 0)
  assert("COMPONENT beta nonzero", !BETA.zero?)
  assert("COMPONENT K nonzero", !K_COMPONENT.zero?)
  assert("COMPONENT K formula", K_COMPONENT + 24 * MU * (MU + 2)**2 / BETA**4 == 0)

  aa, bb, dd, ll, xx = 5.times.map { |i| Poly.variable(5, i) }
  delta = bb**2 - 4 * aa * dd
  tt = aa * xx**2 + bb * xx + dd
  nn = aa * xx + bb / 2
  pp = ll * tt**2 + MU * nn**3 - aa * tt * nn
  gamma_num = -2 * aa * tt + BETA * nn**2
  h0 = delta * ll**2 - K_COMPONENT * aa**4
  hbeta = delta * ll**2 * BETA**4 + 24 * MU * aa**4 * (MU + 2)**2
  assert("COMPONENT Hbeta=beta^4*H0", hbeta == BETA**4 * h0)
  assert("COMPONENT compact quartic degree four", pp.degree_in(4) == 4)
  assert("COMPONENT compact gamma degree two", gamma_num.degree_in(4) == 2)

  p_split = pp.split_variable(4)
  gamma_split = gamma_num.split_variable(4)
  resultant = sylvester_resultant(
    0.upto(4).map { |degree| p_split[degree] },
    0.upto(2).map { |degree| gamma_split[degree] }
  )
  a4, b4, d4, l4 = 4.times.map { |i| Poly.variable(4, i) }
  delta4 = b4**2 - 4 * a4 * d4
  h04 = delta4 * l4**2 - K_COMPONENT * a4**4
  expected_resultant = a4**4 * delta4**3 * BETA**4 * h04 / 256
  assert("COMPONENT Res_x(P,Gamma)=A^4*Delta^3*beta^4*H0/256", resultant == expected_resultant)
  puts "INFO COMPONENT-resultant-P-Gamma-fingerprint=#{resultant.fingerprint}"
  puts "INFO COMPONENT-H0-fingerprint=#{h04.fingerprint}"
end

def verify_compact_is_same_sweep(sweep)
  aa, bb, dd, ll, xx = 5.times.map { |i| Poly.variable(5, i) }
  delta = bb**2 - 4 * aa * dd
  tt = aa * xx**2 + bb * xx + dd
  nn = aa * xx + bb / 2
  pp = ll * tt**2 + MU * nn**3 - aa * tt * nn
  gamma_num = -2 * aa * tt + BETA * nn**2
  target_s1 = S2C - aa
  target_s2 = (bb - S1C) / 2
  target_s3 = S0 - dd
  target_s4 = A2 * dd - A1 * bb / 2 + A0 * aa + KAPPA - ll
  theta = 2 * xx * target_s2 - xx**2 * target_s1 - target_s3
  ax = A0 + A1 * xx + A2 * xx**2
  sx = S0 + S1C * xx + S2C * xx**2
  z = Rat.new(nn, tt)
  y = z - ax
  gamma = Rat.new(gamma_num, 2 * tt)
  assert("same-sweep recovery theta+s=T", theta + sx == tt)
  assert("same-sweep identity N^2-A*T=Delta/4", nn**2 - aa * tt == delta / 4)

  evaluated = sweep.map do |coordinate|
    coordinate.evaluate_rats([gamma, Rat.new(xx), y, Rat.new(theta)])
  end
  targets = [target_s1, target_s2, target_s3, target_s4].map { |coordinate| Rat.new(coordinate) }
  assert("same-sweep compact lift coordinate 1", evaluated[0] == targets[0])
  assert("same-sweep compact lift coordinate 2", evaluated[1] == targets[1])
  assert("same-sweep compact lift coordinate 3", evaluated[2] == targets[2])
  assert("same-sweep compact fourth residual=P/T^2",
         evaluated[3] - targets[3] == Rat.new(pp, tt**2))
  puts "DEDUCTION compact P and Gamma are derived from the same sweep already bridged to the frozen canonical map"
end

def verify_h0_irreducibility_and_singular_contract
  aa, bb, dd, ll = 4.times.map { |i| Poly.variable(4, i) }
  delta = bb**2 - 4 * aa * dd
  h0 = delta * ll**2 - K_COMPONENT * aa**4

  split_d = h0.split_variable(2)
  a3, b3, l3 = 3.times.map { |i| Poly.variable(3, i) }
  coefficient_d = split_d[1]
  constant_d = split_d[0]
  assert("H0 is linear in D", h0.degree_in(2) == 1)
  assert("H0 D-coefficient=-4*A*L^2", coefficient_d == -4 * a3 * l3**2)
  assert("H0 D-constant=B^2*L^2-K*A^4", constant_d == b3**2 * l3**2 - K_COMPONENT * a3**4)
  assert("H0 primitive input: A does not divide D-constant", !divisible_by_variable?(constant_d, 0))
  assert("H0 primitive input: L does not divide D-constant", !divisible_by_variable?(constant_d, 2))

  d_a = h0.deriv(0)
  d_b = h0.deriv(1)
  d_d = h0.deriv(2)
  d_l = h0.deriv(3)
  assert("dH0/dA exact", d_a == -4 * dd * ll**2 - 4 * K_COMPONENT * aa**3)
  assert("dH0/dB exact", d_b == 2 * bb * ll**2)
  assert("dH0/dD exact", d_d == -4 * aa * ll**2)
  assert("dH0/dL exact", d_l == 2 * delta * ll)

  singular_equations = [h0, d_a, d_b, d_d, d_l]
  assert("singular component P={A=L=0} is contained",
         singular_equations.all? { |equation| set_variables_zero(equation, [0, 3]).zero? })
  assert("singular component Q={A=B=D=0} is contained",
         singular_equations.all? { |equation| set_variables_zero(equation, [0, 1, 2]).zero? })
  assert("singular converse L=0 forces via -K*A^4",
         set_variables_zero(h0 + K_COMPONENT * aa**4, [3]).zero?)
  assert("singular converse dD=-4*A*L^2", d_d == -4 * aa * ll**2)
  assert("singular converse dB=2*B*L^2", d_b == 2 * bb * ll**2)
  assert("singular converse at A=0 gives dA=-4*D*L^2",
         set_variables_zero(d_a + 4 * dd * ll**2, [0]).zero?)

  puts "DEDUCTION ABSOLUTE_IRREDUCIBILITY_H0: over every constant extension, the two D-coefficients are coprime; primitive linear Gauss applies"
  puts "DEDUCTION REDUCED_SINGULAR_H0: radical singular locus is V(A,L) union V(A,B,D) by the checked two-case proof"
  puts "PROOF_ONLY radicalization and primality of the two displayed linear ideals"
end

def verify_target_h_boundary_and_laurent_bridge
  c, z1, z2, z3, z4 = 5.times.map { |i| Poly.variable(5, i) }
  at = S2C - c * z1
  bt = S1C + 2 * c**2 * z2
  dt = S0 - c**3 * z3
  lt = A2 * dt - A1 * bt / 2 + A0 * at + KAPPA - c**3 * z4
  deltat = bt**2 - 4 * at * dt
  htarget = deltat * lt**2 - K_COMPONENT * at**4
  minimum_c_power = htarget.terms.keys.map { |exponents| exponents[0] }.min
  assert("Htarget has exact minimum C-power three", minimum_c_power == 3)
  h = divide_by_variable_power(htarget, 0, 3)
  assert("Htarget=C^3*h exact", htarget == c**3 * h)
  assert("h has 50 terms", h.terms.length == 50)
  assert("degree_C(h)=7", h.degree_in(0) == 7)

  boundary = h.coefficient_in(0, 0)
  bz1, bz2, bz3, bz4 = 4.times.map { |i| Poly.variable(4, i) }
  boundary_expected = -bz1**3 / 4 + QE.new(Rational(1, 4), Rational(1, 2)) * bz1 * bz2 +
                      QE.new(Rational(7, 12), Rational(-1, 3)) * bz3 +
                      QE.new(Rational(9, 64), Rational(9, 256)) * bz4
  assert("h boundary at C=0 exact", boundary == boundary_expected)
  boundary_dz4 = boundary.deriv(3)
  expected_dz4 = Poly.constant(4, QE.new(Rational(9, 64), Rational(9, 256)))
  assert("d(h|C=0)/dZ4=9*(4+eta)/256", boundary_dz4 == expected_dz4)
  assert("C=0 contains no singular point of V(h)", !boundary_dz4.zero?)
  assert("C does not divide h", h.terms.keys.any? { |exponents| exponents[0].zero? })

  jacobian = [at, bt, dt, lt].map do |coordinate|
    1.upto(4).map { |index| coordinate.deriv(index) }
  end
  assert("Laurent target-change Jacobian=-2*C^9",
         polynomial_determinant(jacobian) == -2 * c**9)
  inverse_z = [
    Rat.new(S2C - at, c),
    Rat.new(bt - S1C, 2 * c**2),
    Rat.new(S0 - dt, c**3),
    Rat.new(A2 * dt - A1 * bt / 2 + A0 * at + KAPPA - lt, c**3)
  ]
  assert("explicit Laurent inverse recovers all Z coordinates",
         inverse_z == [z1, z2, z3, z4].map { |coordinate| Rat.new(coordinate) })

  puts "INFO COMPONENT-h-fingerprint=#{h.fingerprint}"
  puts "INFO COMPONENT-h-terms=#{h.terms.length} degree_C=#{h.degree_in(0)}"
  puts "INFO COMPONENT-boundary-fingerprint=#{boundary.fingerprint}"
  puts "DEDUCTION ABSOLUTE_IRREDUCIBILITY_h: H0 remains irreducible after constants and Laurent transport; C does not divide h"
  puts "DEDUCTION REDUCED_SINGULAR_h: no C=0 singularity; on C!=0 the two components are Gm*A2 and Gm*A1 with reduced intersection Gm"
  puts "PROOF_ONLY non-cylinder: Sing(W*A1)=Sing(W)*A1 makes a one-dimensional reduced component intersection A1, not Gm"
end

def verify_claim_scope_contract
  bytes = File.binread(CLAIM_SCOPE_PATH)
  assert("claim-scope SHA-256 fixed", Digest::SHA256.hexdigest(bytes) == CLAIM_SCOPE_SHA256)
  assert("claim-scope byte count 256", bytes.bytesize == 256)
  assert("claim-scope is ASCII", bytes.ascii_only?)
  assert("claim-scope LF-only with final newline", !bytes.include?("\r") && bytes.end_with?("\n"))
  lines = bytes.lines(chomp: true)
  assert("claim-scope exact ordered lines", lines == CLAIM_SCOPE_LINES)
  lines.each { |line| puts "SCOPE #{line}" }
  puts "UPSTREAM_CONTRACT GLOBAL_JACOBIAN_AND_GEOMETRIC_DEGREE_NOT_REPROVED"
  puts "PROOF_ONLY Jelonek closedness/component argument and LR/product functoriality"
  puts "BOUNDARY PART1_DOES_NOT_PROVE_DENSE_E1_OR_JELONEK_COMPONENT_OR_FULL_COMPONENT"
end

begin
  started = Process.clock_gettime(Process::CLOCK_MONOTONIC)
  puts "COMPONENT-GEOMETRY-CHECK 1.0.0"
  puts "INFO ruby=#{RUBY_VERSION} platform=#{RUBY_PLATFORM}"
  verify_claim_scope_contract
  canonical = parse_frozen_bundle
  sweep = build_sweep
  verify_stage_inverse
  verify_rational_layer_inverses
  verify_same_object_bridge(sweep, canonical)
  verify_compact_is_same_sweep(sweep)
  verify_compact_h0_link
  verify_h0_irreducibility_and_singular_contract
  verify_target_h_boundary_and_laurent_bridge
  elapsed = Process.clock_gettime(Process::CLOCK_MONOTONIC) - started
  puts format("PASS ALL elapsed_seconds=%.3f", elapsed)
rescue StandardError => error
  warn "FAIL #{error.class}: #{error.message}"
  warn error.backtrace.join("\n")
  exit 1
end
