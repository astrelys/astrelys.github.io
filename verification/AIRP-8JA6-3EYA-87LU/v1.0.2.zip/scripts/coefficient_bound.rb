#!/usr/bin/env ruby
# frozen_string_literal: true

# Exact parser and a priori determinant bound for the frozen map.
# Standard-library Ruby only.  This file intentionally does not import,
# execute, or transcribe any external verifier or generator.

require 'digest'
require 'prime'

EXPECTED_BUNDLE_SHA256 = 'ace8f69bc55d219d4c25901f866a310997a128726d4e0dbdce9a533687855ee0'
EXPECTED_BUNDLE_BYTES = 34_436
EXPECTED_COORDINATES = [
  ['F0', 253,   2,   3, '0f6cc7a1653adfb9be5474bbb74fdb9aa3c576636696f6995e3517166b0827a2'],
  ['F1', 5570,  207, 27, '547e2a3e0beb2e04023380dece6799753ce8f9c25a146a18e9b51325d890fc6c'],
  ['F2', 7432,  273, 29, 'eb749391264a63d79a35b9285afc279cf1bd83c2b3554391453ea3c0394aab48'],
  ['F3', 9524,  343, 31, 'c17dcf5ee397896f7d1d8e437a0f3ec56400e41123986bee3e8bf11862a35d1a'],
  ['F4', 11_631, 372, 31, '9de82fbde901824b01fcadf768ca15de6372dea1d108a8d0adfa09d09e546e12']
].freeze

HEADER = 'EXACT-D1-KELLER-BUNDLE-V1'
BLOCK_HEADER = 'EXACT-D1-KELLER-COORDINATE-V1'
FIELD = 'field=Q[eta]/(eta^2+2)'
ETA = 'eta-generator=formal-class-of-t-mod-(t^2+2);mu=(2+4*eta)/9'
VARIABLES = 'variables=rho,Y1,Y2,Y3,Y4'
ORDER = 'monomial-order=descending-lexicographic-exponent-tuples'

Term = Struct.new(:exp, :n0, :n1, :den)

def fail_closed(message)
  warn "FAIL: #{message}"
  exit 1
end

def canonical_unsigned(token, label)
  fail_closed("noncanonical #{label}: #{token.inspect}") unless token.match?(/\A(?:0|[1-9][0-9]*)\z/)
  Integer(token, 10)
end

def canonical_signed(token, label)
  fail_closed("noncanonical #{label}: #{token.inspect}") unless token.match?(/\A(?:0|-?[1-9][0-9]*)\z/)
  Integer(token, 10)
end

def parse_term(line, coordinate)
  pieces = line.split('|', -1)
  fail_closed("#{coordinate}: term does not have one separator") unless pieces.length == 2
  exponent_tokens = pieces[0].split(',', -1)
  coefficient_tokens = pieces[1].split(',', -1)
  fail_closed("#{coordinate}: exponent arity is not five") unless exponent_tokens.length == 5
  fail_closed("#{coordinate}: coefficient arity is not three") unless coefficient_tokens.length == 3

  exp = exponent_tokens.each_with_index.map { |token, j| canonical_unsigned(token, "exponent #{j}") }
  n0 = canonical_signed(coefficient_tokens[0], 'coefficient n0')
  n1 = canonical_signed(coefficient_tokens[1], 'coefficient n1')
  den = canonical_unsigned(coefficient_tokens[2], 'coefficient denominator')
  fail_closed("#{coordinate}: denominator is zero") if den.zero?
  fail_closed("#{coordinate}: zero coefficient was serialized") if n0.zero? && n1.zero?
  gcd = [n0.abs, n1.abs, den].reduce(0) { |acc, value| acc.gcd(value) }
  fail_closed("#{coordinate}: coefficient record is not primitive") unless gcd == 1
  Term.new(exp.freeze, n0, n1, den)
end

path = ARGV.fetch(0) { fail_closed('usage: coefficient_bound.rb CANONICAL_MAP') }
raw = File.binread(path)

fail_closed("bundle byte count #{raw.bytesize} != #{EXPECTED_BUNDLE_BYTES}") unless raw.bytesize == EXPECTED_BUNDLE_BYTES
actual_bundle_sha = Digest::SHA256.hexdigest(raw)
fail_closed("bundle SHA-256 #{actual_bundle_sha} != expected") unless actual_bundle_sha == EXPECTED_BUNDLE_SHA256
fail_closed('bundle is not seven-bit ASCII') unless raw.bytes.all? { |byte| byte < 128 }
fail_closed('bundle contains CR') if raw.include?("\r")
fail_closed('bundle does not end in exactly a line feed') unless raw.end_with?("\n")

raw_lines = raw.lines
fail_closed('a non-final line lacks LF') unless raw_lines.all? { |line| line.end_with?("\n") }
lines = raw_lines.map { |line| line.delete_suffix("\n") }
cursor = 0
fail_closed('wrong bundle header') unless lines[cursor] == HEADER
cursor += 1

coordinates = []
EXPECTED_COORDINATES.each do |expected_name, expected_bytes, expected_terms, expected_degree, expected_sha|
  block_start = cursor
  fail_closed("#{expected_name}: wrong coordinate-block header") unless lines[cursor] == BLOCK_HEADER
  cursor += 1
  fail_closed("#{expected_name}: wrong field line") unless lines[cursor] == FIELD
  cursor += 1
  fail_closed("#{expected_name}: wrong eta line") unless lines[cursor] == ETA
  cursor += 1
  fail_closed("#{expected_name}: wrong variable line") unless lines[cursor] == VARIABLES
  cursor += 1
  fail_closed("#{expected_name}: wrong monomial-order line") unless lines[cursor] == ORDER
  cursor += 1
  fail_closed("#{expected_name}: wrong name line") unless lines[cursor] == "coordinate=#{expected_name}"
  cursor += 1

  prefix = 'term-count='
  fail_closed("#{expected_name}: missing term count") unless lines[cursor]&.start_with?(prefix)
  stated_terms = canonical_unsigned(lines[cursor].delete_prefix(prefix), 'term count')
  fail_closed("#{expected_name}: stated term count mismatch") unless stated_terms == expected_terms
  cursor += 1

  terms = []
  previous_exp = nil
  stated_terms.times do
    fail_closed("#{expected_name}: unexpected EOF in terms") if cursor >= lines.length
    term = parse_term(lines[cursor], expected_name)
    if previous_exp && (previous_exp <=> term.exp) != 1
      fail_closed("#{expected_name}: exponent tuples are not strictly descending lexicographically")
    end
    previous_exp = term.exp
    terms << term
    cursor += 1
  end

  block_bytes = raw_lines[block_start...cursor].join
  block_sha = Digest::SHA256.hexdigest(block_bytes)
  fail_closed("#{expected_name}: block byte count mismatch") unless block_bytes.bytesize == expected_bytes
  fail_closed("#{expected_name}: block SHA-256 mismatch") unless block_sha == expected_sha
  actual_degree = terms.map { |term| term.exp.sum }.max
  fail_closed("#{expected_name}: total degree mismatch") unless actual_degree == expected_degree
  coordinates << terms.freeze
end

fail_closed("trailing content begins at line #{cursor + 1}") unless cursor == lines.length

# Clear denominators row by row: G_i = L_i F_i in Z[eta][x].
row_lcms = coordinates.map do |terms|
  terms.map(&:den).reduce(1) { |acc, den| acc.lcm(den) }
end

# S[i][j] is the coefficient l1 bound of dG_i/dx_j for
# H(a+b eta)=|a|+2|b|.  This coefficient height is submultiplicative
# because eta^2=-2.  It is not the algebraic field norm.
s = Array.new(5) { Array.new(5, 0) }
coordinates.each_with_index do |terms, i|
  terms.each do |term|
    5.times do |j|
      exponent = term.exp[j]
      next if exponent.zero?
      scale = (row_lcms[i] / term.den) * exponent
      a = term.n0 * scale
      b = term.n1 * scale
      s[i][j] += a.abs + 2 * b.abs
    end
  end
end

permutations = (0...5).to_a.permutation.to_a
determinant_height = permutations.sum do |permutation|
  (0...5).reduce(1) { |product, i| product * s[i][permutation[i]] }
end
denominator_product = row_lcms.reduce(1, :*)
residual_height = determinant_height + denominator_product
crt_threshold = 2 * residual_height

# A rigorous exponent box: maximize, over determinant permutations, the sum of
# entrywise maxima for each source variable.  Nil marks a zero derivative.
entry_max = Array.new(5) { Array.new(5) { Array.new(5) } }
entry_total_degree = Array.new(5) { Array.new(5) }
coordinates.each_with_index do |terms, i|
  5.times do |j|
    derivative_terms = terms.select { |term| term.exp[j].positive? }
    next if derivative_terms.empty?
    derivative_exponents = derivative_terms.map do |term|
      exp = term.exp.dup
      exp[j] -= 1
      exp
    end
    5.times { |k| entry_max[i][j][k] = derivative_exponents.map { |exp| exp[k] }.max }
    entry_total_degree[i][j] = derivative_exponents.map(&:sum).max
  end
end

valid_permutations = permutations.select do |permutation|
  (0...5).all? { |i| !entry_total_degree[i][permutation[i]].nil? }
end
degree_box = 5.times.map do |k|
  valid_permutations.map do |permutation|
    (0...5).sum { |i| entry_max[i][permutation[i]][k] }
  end.max
end
total_degree_bound = valid_permutations.map do |permutation|
  (0...5).sum { |i| entry_total_degree[i][permutation[i]] }
end.max

puts 'PASS: strict clean-room canonical parser and determinant a priori bound'
puts "bundle_bytes=#{raw.bytesize}"
puts "bundle_sha256=#{actual_bundle_sha}"
puts "coordinate_terms=#{coordinates.map(&:length).inspect}"
puts "coordinate_total_degrees=#{coordinates.map { |terms| terms.map { |term| term.exp.sum }.max }.inspect}"
puts "row_denominator_lcms=#{row_lcms.inspect}"
puts "denominator_product=#{denominator_product}"
puts "derivative_l1_matrix=#{s.inspect}"
puts "determinant_component_height_bound=#{determinant_height}"
puts "residual_component_height_bound=#{residual_height}"
puts "crt_product_strictly_greater_than=#{crt_threshold}"
puts "crt_threshold_decimal_digits=#{crt_threshold.to_s.length}"
puts "crt_threshold_bits=#{crt_threshold.bit_length}"
puts "minimum_29_bit_prime_count=#{(crt_threshold.bit_length + 28) / 29}"
puts "determinant_exponent_box=#{degree_box.inspect}"
puts "determinant_total_degree_bound=#{total_degree_bound}"
primes = ARGV.drop(1).map do |token|
  fail_closed("noncanonical CRT prime: #{token.inspect}") unless token.match?(/\A[1-9][0-9]*\z/)
  Integer(token, 10)
end
unless primes.empty?
  fail_closed('CRT primes are not distinct') unless primes.uniq.length == primes.length
  primes.each do |prime|
    fail_closed("CRT modulus #{prime} is not an odd prime") unless prime.odd? && Prime.prime?(prime)
    fail_closed("CRT modulus #{prime} divides 2L") unless (2 * denominator_product).gcd(prime) == 1
  end
  prime_product = primes.reduce(1, :*)
  behaviors = primes.map { |prime| [1, 3].include?(prime % 8) ? 'split' : 'inert' }
  puts "crt_primes=#{primes.inspect}"
  puts "crt_prime_behaviors=#{behaviors.inspect}"
  puts "crt_prime_product=#{prime_product}"
  puts "crt_prime_product_bits=#{prime_product.bit_length}"
  puts "crt_product_exceeds_twice_height=#{prime_product > crt_threshold}"
end
puts 'BOUNDARY: parsing and bounds are proofs about the supplied raw bytes; no determinant coefficient has been computed here.'
