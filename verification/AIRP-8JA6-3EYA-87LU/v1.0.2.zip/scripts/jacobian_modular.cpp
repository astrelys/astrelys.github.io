#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

// Exact finite-ring verifier for the accompanying five-coordinate map.
// No project-side source code is imported, executed, or transcribed.
// The file is opened exactly once; SHA-256 and parsing consume the same
// in-memory byte string, so no external-digest trust or reopen race remains.
//
// The program parses the canonical ASCII map directly and works in
//   F_p[eta]/(eta^2+2)
// with pairs (a,b) representing a+b*eta.  Point evaluations are diagnostics.
// A symbolic PASS means every coefficient of det(J)-1 vanished for this prime;
// one prime alone is not a characteristic-zero proof.

namespace {

constexpr std::size_t N = 5;
constexpr std::size_t EXPECTED_BYTES = 34436;
constexpr std::array<std::size_t, N> EXPECTED_TERMS{2, 207, 273, 343, 372};
constexpr std::array<int, N> EXPECTED_DEGREES{3, 27, 29, 31, 31};
constexpr std::array<std::size_t, N> EXPECTED_BLOCK_BYTES{253, 5570, 7432, 9524, 11631};
const std::string EXPECTED_SHA256 = "ace8f69bc55d219d4c25901f866a310997a128726d4e0dbdce9a533687855ee0";
const std::string IMPLEMENTATION_VERSION = "exact-jacobian-1.0.0";

const std::string BUNDLE_HEADER = "EXACT-D1-KELLER-BUNDLE-V1";
const std::string BLOCK_HEADER = "EXACT-D1-KELLER-COORDINATE-V1";
const std::string FIELD = "field=Q[eta]/(eta^2+2)";
const std::string ETA = "eta-generator=formal-class-of-t-mod-(t^2+2);mu=(2+4*eta)/9";
const std::string VARIABLES = "variables=rho,Y1,Y2,Y3,Y4";
const std::string ORDER = "monomial-order=descending-lexicographic-exponent-tuples";

struct SourceTerm {
  std::array<std::uint8_t, N> exponent{};
  std::int64_t n0 = 0;
  std::int64_t n1 = 0;
  std::int64_t denominator = 1;
};

using Coordinates = std::array<std::vector<SourceTerm>, N>;

[[noreturn]] void fail(const std::string& message) {
  throw std::runtime_error(message);
}

std::uint32_t rotate_right(std::uint32_t value, unsigned count) {
  return (value >> count) | (value << (32U - count));
}

std::string sha256_hex(const std::string& bytes) {
  static constexpr std::array<std::uint32_t, 64> round_constants{
      0x428a2f98U, 0x71374491U, 0xb5c0fbcfU, 0xe9b5dba5U,
      0x3956c25bU, 0x59f111f1U, 0x923f82a4U, 0xab1c5ed5U,
      0xd807aa98U, 0x12835b01U, 0x243185beU, 0x550c7dc3U,
      0x72be5d74U, 0x80deb1feU, 0x9bdc06a7U, 0xc19bf174U,
      0xe49b69c1U, 0xefbe4786U, 0x0fc19dc6U, 0x240ca1ccU,
      0x2de92c6fU, 0x4a7484aaU, 0x5cb0a9dcU, 0x76f988daU,
      0x983e5152U, 0xa831c66dU, 0xb00327c8U, 0xbf597fc7U,
      0xc6e00bf3U, 0xd5a79147U, 0x06ca6351U, 0x14292967U,
      0x27b70a85U, 0x2e1b2138U, 0x4d2c6dfcU, 0x53380d13U,
      0x650a7354U, 0x766a0abbU, 0x81c2c92eU, 0x92722c85U,
      0xa2bfe8a1U, 0xa81a664bU, 0xc24b8b70U, 0xc76c51a3U,
      0xd192e819U, 0xd6990624U, 0xf40e3585U, 0x106aa070U,
      0x19a4c116U, 0x1e376c08U, 0x2748774cU, 0x34b0bcb5U,
      0x391c0cb3U, 0x4ed8aa4aU, 0x5b9cca4fU, 0x682e6ff3U,
      0x748f82eeU, 0x78a5636fU, 0x84c87814U, 0x8cc70208U,
      0x90befffaU, 0xa4506cebU, 0xbef9a3f7U, 0xc67178f2U};

  if (bytes.size() > (UINT64_MAX / 8U)) fail("input is too large for SHA-256 length encoding");
  const auto bit_length = static_cast<std::uint64_t>(bytes.size()) * 8U;
  std::vector<std::uint8_t> message(bytes.begin(), bytes.end());
  message.reserve(bytes.size() + 72);
  message.push_back(0x80U);
  while ((message.size() % 64U) != 56U) message.push_back(0U);
  for (int shift = 56; shift >= 0; shift -= 8) {
    message.push_back(static_cast<std::uint8_t>((bit_length >> shift) & 0xffU));
  }

  std::array<std::uint32_t, 8> state{
      0x6a09e667U, 0xbb67ae85U, 0x3c6ef372U, 0xa54ff53aU,
      0x510e527fU, 0x9b05688cU, 0x1f83d9abU, 0x5be0cd19U};
  for (std::size_t offset = 0; offset < message.size(); offset += 64U) {
    std::array<std::uint32_t, 64> schedule{};
    for (std::size_t word = 0; word < 16U; ++word) {
      const auto at = offset + 4U * word;
      schedule[word] = (static_cast<std::uint32_t>(message[at]) << 24U) |
                       (static_cast<std::uint32_t>(message[at + 1U]) << 16U) |
                       (static_cast<std::uint32_t>(message[at + 2U]) << 8U) |
                       static_cast<std::uint32_t>(message[at + 3U]);
    }
    for (std::size_t word = 16U; word < 64U; ++word) {
      const auto x = schedule[word - 15U];
      const auto y = schedule[word - 2U];
      const auto small_sigma0 = rotate_right(x, 7U) ^ rotate_right(x, 18U) ^ (x >> 3U);
      const auto small_sigma1 = rotate_right(y, 17U) ^ rotate_right(y, 19U) ^ (y >> 10U);
      schedule[word] = schedule[word - 16U] + small_sigma0 +
                       schedule[word - 7U] + small_sigma1;
    }

    auto a = state[0];
    auto b = state[1];
    auto c = state[2];
    auto d = state[3];
    auto e = state[4];
    auto f = state[5];
    auto g = state[6];
    auto h = state[7];
    for (std::size_t round = 0; round < 64U; ++round) {
      const auto big_sigma1 = rotate_right(e, 6U) ^ rotate_right(e, 11U) ^ rotate_right(e, 25U);
      const auto choice = (e & f) ^ ((~e) & g);
      const auto temporary1 = h + big_sigma1 + choice + round_constants[round] + schedule[round];
      const auto big_sigma0 = rotate_right(a, 2U) ^ rotate_right(a, 13U) ^ rotate_right(a, 22U);
      const auto majority = (a & b) ^ (a & c) ^ (b & c);
      const auto temporary2 = big_sigma0 + majority;
      h = g;
      g = f;
      f = e;
      e = d + temporary1;
      d = c;
      c = b;
      b = a;
      a = temporary1 + temporary2;
    }
    state[0] += a;
    state[1] += b;
    state[2] += c;
    state[3] += d;
    state[4] += e;
    state[5] += f;
    state[6] += g;
    state[7] += h;
  }

  std::ostringstream result;
  result << std::hex << std::setfill('0');
  for (const auto word : state) result << std::setw(8) << word;
  return result.str();
}

void sha256_self_tests() {
  const std::array<std::pair<std::string, std::string>, 4> vectors{{
      {"", "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"},
      {"abc", "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"},
      {"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq",
       "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1"},
      {std::string(1'000'000, 'a'),
       "cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0"}}};
  for (const auto& vector : vectors) {
    if (sha256_hex(vector.first) != vector.second) fail("SHA-256 known-answer self-test failed");
  }
}

std::string read_bytes_once(const std::string& path) {
  std::ifstream stream(path, std::ios::binary);
  if (!stream) fail("cannot open canonical map");
  std::string raw((std::istreambuf_iterator<char>(stream)), std::istreambuf_iterator<char>());
  if (stream.bad()) fail("I/O failure while reading canonical map");
  return raw;
}

bool canonical_unsigned(const std::string& text) {
  if (text.empty()) return false;
  if (text == "0") return true;
  if (text.front() == '0') return false;
  return std::all_of(text.begin(), text.end(), [](unsigned char c) { return c >= '0' && c <= '9'; });
}

bool canonical_signed(const std::string& text) {
  if (text.empty()) return false;
  if (text.front() == '-') {
    if (text.size() == 1 || text[1] == '0') return false;
    return std::all_of(text.begin() + 1, text.end(), [](unsigned char c) { return c >= '0' && c <= '9'; });
  }
  return canonical_unsigned(text);
}

std::int64_t parse_u64_as_i64(const std::string& text, const std::string& label) {
  if (!canonical_unsigned(text)) fail("noncanonical unsigned integer in " + label);
  std::size_t used = 0;
  const auto value = std::stoll(text, &used, 10);
  if (used != text.size() || value < 0) fail("out-of-range unsigned integer in " + label);
  return value;
}

std::int64_t parse_i64(const std::string& text, const std::string& label) {
  if (!canonical_signed(text)) fail("noncanonical signed integer in " + label);
  std::size_t used = 0;
  const auto value = std::stoll(text, &used, 10);
  if (used != text.size()) fail("out-of-range signed integer in " + label);
  return value;
}

std::vector<std::string> split(const std::string& text, char delimiter) {
  std::vector<std::string> result;
  std::size_t begin = 0;
  for (;;) {
    const auto at = text.find(delimiter, begin);
    if (at == std::string::npos) {
      result.push_back(text.substr(begin));
      return result;
    }
    result.push_back(text.substr(begin, at - begin));
    begin = at + 1;
  }
}

Coordinates parse_canonical_bytes(const std::string& raw) {
  if (raw.size() != EXPECTED_BYTES) fail("canonical byte-count mismatch");
  if (raw.empty() || raw.back() != '\n') fail("canonical map lacks final LF");
  for (unsigned char byte : raw) {
    if (byte >= 128) fail("canonical map is not seven-bit ASCII");
    if (byte == '\r') fail("canonical map contains CR");
  }

  std::vector<std::string> lines;
  std::size_t begin = 0;
  while (begin < raw.size()) {
    const auto end = raw.find('\n', begin);
    if (end == std::string::npos) fail("internal line split failed");
    lines.push_back(raw.substr(begin, end - begin));
    begin = end + 1;
  }

  std::size_t cursor = 0;
  auto require_line = [&](const std::string& expected, const std::string& label) {
    if (cursor >= lines.size() || lines[cursor] != expected) fail("wrong " + label);
    ++cursor;
  };

  require_line(BUNDLE_HEADER, "bundle header");
  Coordinates coordinates;
  for (std::size_t i = 0; i < N; ++i) {
    const std::size_t block_start = cursor;
    require_line(BLOCK_HEADER, "block header");
    require_line(FIELD, "field");
    require_line(ETA, "eta declaration");
    require_line(VARIABLES, "variable declaration");
    require_line(ORDER, "monomial order");
    require_line("coordinate=F" + std::to_string(i), "coordinate name");
    if (cursor >= lines.size() || lines[cursor].rfind("term-count=", 0) != 0) fail("missing term count");
    const auto stated = parse_u64_as_i64(lines[cursor].substr(11), "term count");
    ++cursor;
    if (stated != static_cast<std::int64_t>(EXPECTED_TERMS[i])) fail("term-count mismatch");

    std::array<std::uint8_t, N> previous{};
    bool have_previous = false;
    for (std::int64_t t = 0; t < stated; ++t) {
      if (cursor >= lines.size()) fail("unexpected EOF in coordinate terms");
      const auto halves = split(lines[cursor++], '|');
      if (halves.size() != 2) fail("term does not contain exactly one vertical separator");
      const auto exponent_tokens = split(halves[0], ',');
      const auto coefficient_tokens = split(halves[1], ',');
      if (exponent_tokens.size() != N || coefficient_tokens.size() != 3) fail("wrong term arity");

      SourceTerm term;
      for (std::size_t j = 0; j < N; ++j) {
        const auto exponent = parse_u64_as_i64(exponent_tokens[j], "exponent");
        if (exponent > 255) fail("exponent does not fit clean-room packing");
        term.exponent[j] = static_cast<std::uint8_t>(exponent);
      }
      term.n0 = parse_i64(coefficient_tokens[0], "coefficient n0");
      term.n1 = parse_i64(coefficient_tokens[1], "coefficient n1");
      term.denominator = parse_u64_as_i64(coefficient_tokens[2], "denominator");
      if (term.denominator <= 0) fail("nonpositive denominator");
      if (term.n0 == 0 && term.n1 == 0) fail("serialized zero coefficient");
      const auto gcd = std::gcd(std::gcd(std::llabs(term.n0), std::llabs(term.n1)), term.denominator);
      if (gcd != 1) fail("nonprimitive coefficient record");
      if (have_previous && !std::lexicographical_compare(
            term.exponent.begin(), term.exponent.end(), previous.begin(), previous.end())) {
        fail("exponents are not strictly descending lexicographically");
      }
      previous = term.exponent;
      have_previous = true;
      coordinates[i].push_back(term);
    }

    std::size_t block_bytes = 0;
    for (std::size_t line = block_start; line < cursor; ++line) block_bytes += lines[line].size() + 1;
    if (block_bytes != EXPECTED_BLOCK_BYTES[i]) fail("coordinate block byte-count mismatch");
    int degree = 0;
    for (const auto& term : coordinates[i]) {
      int current = 0;
      for (auto exponent : term.exponent) current += exponent;
      degree = std::max(degree, current);
    }
    if (degree != EXPECTED_DEGREES[i]) fail("coordinate total-degree mismatch");
  }
  if (cursor != lines.size()) fail("trailing canonical content");
  return coordinates;
}

std::uint32_t MODULUS = 0;

std::uint32_t mod_i64(std::int64_t value) {
  auto result = value % static_cast<std::int64_t>(MODULUS);
  if (result < 0) result += MODULUS;
  return static_cast<std::uint32_t>(result);
}

std::uint32_t scalar_add(std::uint32_t a, std::uint32_t b) {
  const auto sum = a + b;
  return sum >= MODULUS ? sum - MODULUS : sum;
}

std::uint32_t scalar_sub(std::uint32_t a, std::uint32_t b) {
  return a >= b ? a - b : a + MODULUS - b;
}

std::uint32_t scalar_mul(std::uint32_t a, std::uint32_t b) {
  return static_cast<std::uint32_t>((static_cast<std::uint64_t>(a) * b) % MODULUS);
}

std::uint32_t scalar_pow(std::uint32_t base, std::uint64_t exponent) {
  std::uint32_t result = 1;
  while (exponent) {
    if (exponent & 1U) result = scalar_mul(result, base);
    base = scalar_mul(base, base);
    exponent >>= 1U;
  }
  return result;
}

std::uint32_t scalar_inv(std::uint32_t value) {
  if (value == 0) fail("attempted to invert zero denominator modulo p");
  const auto inverse = scalar_pow(value, MODULUS - 2);
  if (scalar_mul(value, inverse) != 1) fail("scalar inverse postcondition failed");
  return inverse;
}

std::uint32_t scalar_sqrt(std::uint32_t value) {
  if (value == 0) return 0;
  if (scalar_pow(value, (MODULUS - 1) / 2) != 1) fail("requested square root of a nonsquare");
  if (MODULUS % 4 == 3) return scalar_pow(value, (MODULUS + 1) / 4);

  std::uint32_t odd_part = MODULUS - 1;
  unsigned two_adic_order = 0;
  while ((odd_part & 1U) == 0) {
    odd_part >>= 1U;
    ++two_adic_order;
  }
  std::uint32_t nonresidue = 2;
  while (scalar_pow(nonresidue, (MODULUS - 1) / 2) != MODULUS - 1) ++nonresidue;
  auto c = scalar_pow(nonresidue, odd_part);
  auto x = scalar_pow(value, (static_cast<std::uint64_t>(odd_part) + 1) / 2);
  auto t = scalar_pow(value, odd_part);
  unsigned m = two_adic_order;
  while (t != 1) {
    unsigned i = 1;
    auto t_power = scalar_mul(t, t);
    while (i < m && t_power != 1) {
      t_power = scalar_mul(t_power, t_power);
      ++i;
    }
    if (i == m) fail("Tonelli-Shanks invariant failure");
    const auto exponent = std::uint64_t{1} << (m - i - 1);
    const auto b = scalar_pow(c, exponent);
    x = scalar_mul(x, b);
    const auto b_squared = scalar_mul(b, b);
    t = scalar_mul(t, b_squared);
    c = b_squared;
    m = i;
  }
  if (scalar_mul(x, x) != value) fail("modular square-root postcondition failed");
  return x;
}

bool is_prime(std::uint32_t value) {
  if (value < 2) return false;
  if (value % 2 == 0) return value == 2;
  for (std::uint32_t divisor = 3; static_cast<std::uint64_t>(divisor) * divisor <= value; divisor += 2) {
    if (value % divisor == 0) return false;
  }
  return true;
}

struct K2 {
  std::uint32_t a = 0;
  std::uint32_t b = 0;
};

bool operator==(const K2& x, const K2& y) { return x.a == y.a && x.b == y.b; }
bool is_zero(const K2& x) { return x.a == 0 && x.b == 0; }

K2 add(const K2& x, const K2& y) {
  return {scalar_add(x.a, y.a), scalar_add(x.b, y.b)};
}

K2 negate(const K2& x) {
  return {x.a == 0 ? 0U : MODULUS - x.a, x.b == 0 ? 0U : MODULUS - x.b};
}

K2 multiply(const K2& x, const K2& y) {
  // (a+b eta)(c+d eta)=(ac-2bd)+(ad+bc)eta, eta^2=-2.
  const auto ac = scalar_mul(x.a, y.a);
  const auto bd2 = scalar_mul(2 % MODULUS, scalar_mul(x.b, y.b));
  const auto ad = scalar_mul(x.a, y.b);
  const auto bc = scalar_mul(x.b, y.a);
  return {scalar_sub(ac, bd2), scalar_add(ad, bc)};
}

K2 multiply_scalar(const K2& x, std::uint32_t scalar) {
  return {scalar_mul(x.a, scalar), scalar_mul(x.b, scalar)};
}

K2 coefficient_mod_p(const SourceTerm& term) {
  const auto denominator = mod_i64(term.denominator);
  const auto inverse = scalar_inv(denominator);
  return {scalar_mul(mod_i64(term.n0), inverse), scalar_mul(mod_i64(term.n1), inverse)};
}

std::uint64_t pack(const std::array<std::uint8_t, N>& exponent) {
  std::uint64_t key = 0;
  for (std::size_t j = 0; j < N; ++j) key |= static_cast<std::uint64_t>(exponent[j]) << (8 * j);
  return key;
}

std::array<unsigned, N> unpack(std::uint64_t key) {
  std::array<unsigned, N> result{};
  for (std::size_t j = 0; j < N; ++j) result[j] = static_cast<unsigned>((key >> (8 * j)) & 0xffU);
  return result;
}

struct ModularTerm {
  std::uint64_t key = 0;
  K2 coefficient{};
};

using DerivativeMatrix = std::array<std::array<std::vector<ModularTerm>, N>, N>;

DerivativeMatrix build_derivatives(const Coordinates& coordinates) {
  DerivativeMatrix derivatives;
  for (std::size_t i = 0; i < N; ++i) {
    for (const auto& source_term : coordinates[i]) {
      const auto source_coefficient = coefficient_mod_p(source_term);
      for (std::size_t j = 0; j < N; ++j) {
        if (source_term.exponent[j] == 0) continue;
        auto exponent = source_term.exponent;
        const auto factor = exponent[j];
        --exponent[j];
        const auto coefficient = multiply_scalar(source_coefficient, factor % MODULUS);
        if (!is_zero(coefficient)) derivatives[i][j].push_back({pack(exponent), coefficient});
      }
    }
  }
  return derivatives;
}

K2 evaluate(const std::vector<ModularTerm>& polynomial, const std::array<K2, N>& point) {
  std::array<std::array<K2, 256>, N> powers{};
  for (std::size_t j = 0; j < N; ++j) {
    powers[j][0] = {1, 0};
    for (std::size_t exponent = 1; exponent < 256; ++exponent) {
      powers[j][exponent] = multiply(powers[j][exponent - 1], point[j]);
    }
  }
  K2 sum{};
  for (const auto& term : polynomial) {
    auto product = term.coefficient;
    const auto exponent = unpack(term.key);
    for (std::size_t j = 0; j < N; ++j) product = multiply(product, powers[j][exponent[j]]);
    sum = add(sum, product);
  }
  return sum;
}

K2 determinant_no_division(const std::array<std::array<K2, N>, N>& matrix) {
  std::array<K2, 1U << N> current{};
  current[0] = {1, 0};
  for (std::size_t row = 0; row < N; ++row) {
    std::array<K2, 1U << N> next{};
    for (unsigned mask = 0; mask < (1U << N); ++mask) {
      if (__builtin_popcount(mask) != static_cast<int>(row)) continue;
      for (std::size_t column = 0; column < N; ++column) {
        if (mask & (1U << column)) continue;
        unsigned larger = 0;
        for (std::size_t selected = column + 1; selected < N; ++selected) {
          if (mask & (1U << selected)) ++larger;
        }
        auto contribution = multiply(current[mask], matrix[row][column]);
        if (larger & 1U) contribution = negate(contribution);
        next[mask | (1U << column)] = add(next[mask | (1U << column)], contribution);
      }
    }
    current = next;
  }
  return current[(1U << N) - 1];
}

std::uint32_t determinant_scalar_no_division(
    const std::array<std::array<std::uint32_t, N>, N>& matrix) {
  std::array<std::uint32_t, 1U << N> current{};
  current[0] = 1;
  for (std::size_t row = 0; row < N; ++row) {
    std::array<std::uint32_t, 1U << N> next{};
    for (unsigned mask = 0; mask < (1U << N); ++mask) {
      if (__builtin_popcount(mask) != static_cast<int>(row)) continue;
      for (std::size_t column = 0; column < N; ++column) {
        if (mask & (1U << column)) continue;
        unsigned larger = 0;
        for (std::size_t selected = column + 1; selected < N; ++selected) {
          if (mask & (1U << selected)) ++larger;
        }
        auto contribution = scalar_mul(current[mask], matrix[row][column]);
        if (larger & 1U) contribution = contribution == 0 ? 0 : MODULUS - contribution;
        next[mask | (1U << column)] = scalar_add(next[mask | (1U << column)], contribution);
      }
    }
    current = next;
  }
  return current[(1U << N) - 1];
}

std::uint64_t xorshift64(std::uint64_t& state) {
  state ^= state << 13U;
  state ^= state >> 7U;
  state ^= state << 17U;
  return state;
}

void algebra_self_tests() {
  const K2 eta{0, 1};
  if (!(multiply(eta, eta) == K2{MODULUS - (2 % MODULUS), 0})) {
    fail("eta^2=-2 self-test failed");
  }

  std::array<std::array<K2, N>, N> identity{};
  for (std::size_t i = 0; i < N; ++i) identity[i][i] = {1, 0};
  if (!(determinant_no_division(identity) == K2{1, 0})) fail("identity determinant self-test failed");
  std::swap(identity[0], identity[1]);
  if (!(determinant_no_division(identity) == K2{MODULUS - 1, 0})) {
    fail("odd-permutation determinant self-test failed");
  }

  std::uint64_t state = 0x2f41d3a765bc098eULL ^ MODULUS;
  for (unsigned test = 0; test < 64; ++test) {
    K2 x{static_cast<std::uint32_t>(xorshift64(state) % MODULUS),
         static_cast<std::uint32_t>(xorshift64(state) % MODULUS)};
    K2 y{static_cast<std::uint32_t>(xorshift64(state) % MODULUS),
         static_cast<std::uint32_t>(xorshift64(state) % MODULUS)};
    K2 z{static_cast<std::uint32_t>(xorshift64(state) % MODULUS),
         static_cast<std::uint32_t>(xorshift64(state) % MODULUS)};
    if (!(multiply(x, add(y, z)) == add(multiply(x, y), multiply(x, z)))) {
      fail("quadratic-ring distributivity self-test failed");
    }
    if (!(multiply(x, y) == multiply(y, x))) fail("quadratic-ring commutativity self-test failed");
  }
}

void evaluation_pilot(const DerivativeMatrix& derivatives, unsigned samples, bool split_prime) {
  std::uint32_t root = 0;
  if (split_prime) {
    root = scalar_sqrt(MODULUS - (2 % MODULUS));
    if (root == 0 || scalar_add(scalar_mul(root, root), 2 % MODULUS) != 0) {
      fail("split classification had no valid eta root");
    }
  }

  std::uint64_t state = 0xd1c1ea4b9f3702a5ULL ^ MODULUS;
  for (unsigned sample = 0; sample < samples; ++sample) {
    std::array<K2, N> point{};
    for (auto& coordinate : point) {
      coordinate.a = static_cast<std::uint32_t>(xorshift64(state) % MODULUS);
      coordinate.b = static_cast<std::uint32_t>(xorshift64(state) % MODULUS);
    }
    if (sample == 0) for (auto& coordinate : point) coordinate = {0, 0};

    std::array<std::array<K2, N>, N> matrix{};
    for (std::size_t i = 0; i < N; ++i) {
      for (std::size_t j = 0; j < N; ++j) matrix[i][j] = evaluate(derivatives[i][j], point);
    }
    const auto determinant = determinant_no_division(matrix);
    if (!(determinant == K2{1, 0})) {
      fail("evaluation determinant mismatch at sample " + std::to_string(sample));
    }

    if (split_prime) {
      for (unsigned embedding_index = 0; embedding_index < 2; ++embedding_index) {
        const auto eta_value = embedding_index == 0 ? root : (root == 0 ? 0 : MODULUS - root);
        std::array<std::array<std::uint32_t, N>, N> embedded{};
        for (std::size_t i = 0; i < N; ++i) {
          for (std::size_t j = 0; j < N; ++j) {
            embedded[i][j] = scalar_add(matrix[i][j].a, scalar_mul(matrix[i][j].b, eta_value));
          }
        }
        if (determinant_scalar_no_division(embedded) != 1) {
          fail("split embedding determinant mismatch at sample " + std::to_string(sample));
        }
      }
    }
  }
  std::cout << "evaluation_samples_passed=" << samples << "\n";
  if (split_prime) std::cout << "split_embeddings_per_sample=2\n";
}

struct KeyHash {
  std::size_t operator()(std::uint64_t value) const noexcept {
    value += 0x9e3779b97f4a7c15ULL;
    value = (value ^ (value >> 30U)) * 0xbf58476d1ce4e5b9ULL;
    value = (value ^ (value >> 27U)) * 0x94d049bb133111ebULL;
    return static_cast<std::size_t>(value ^ (value >> 31U));
  }
};

using SparsePolynomial = std::unordered_map<std::uint64_t, K2, KeyHash>;

struct Limits {
  std::uint64_t operations = 0;
  std::uint64_t operation_cap = 0;
  std::size_t aggregate_term_cap = 0;
  double seconds_cap = 0.0;
  std::chrono::steady_clock::time_point start{};
  std::string abort_reason;
  std::size_t peak_aggregate_terms = 1;
};

std::size_t aggregate_terms(const std::array<SparsePolynomial, 1U << N>& polynomials) {
  std::size_t result = 0;
  for (const auto& polynomial : polynomials) result += polynomial.size();
  return result;
}

bool add_to(SparsePolynomial& polynomial, std::uint64_t key, K2 value) {
  if (is_zero(value)) return false;
  auto found = polynomial.find(key);
  if (found == polynomial.end()) {
    polynomial.emplace(key, value);
    return true;
  }
  const auto sum = add(found->second, value);
  if (is_zero(sum)) {
    polynomial.erase(found);
  } else {
    found->second = sum;
  }
  return true;
}

bool add_product(
    SparsePolynomial& destination,
    const SparsePolynomial& left,
    const std::vector<ModularTerm>& right,
    bool negative,
    Limits& limits) {
  for (const auto& left_term : left) {
    for (const auto& right_term : right) {
      ++limits.operations;
      if (limits.operations > limits.operation_cap) {
        limits.abort_reason = "operation_cap";
        return false;
      }
      if ((limits.operations & ((1U << 20U) - 1U)) == 0) {
        const auto seconds = std::chrono::duration<double>(
            std::chrono::steady_clock::now() - limits.start).count();
        if (seconds > limits.seconds_cap) {
          limits.abort_reason = "wall_time_cap";
          return false;
        }
      }
      auto coefficient = multiply(left_term.second, right_term.coefficient);
      if (negative) coefficient = negate(coefficient);
      // Fail closed before using ordinary integer addition of packed byte lanes.
      // This independently enforces the no-carry premise used by the sparse key.
      for (std::size_t lane = 0; lane < N; ++lane) {
        const auto left_exponent = (left_term.first >> (8 * lane)) & 0xffU;
        const auto right_exponent = (right_term.key >> (8 * lane)) & 0xffU;
        if (left_exponent + right_exponent >= 256) fail("packed exponent lane overflow");
      }
      add_to(destination, left_term.first + right_term.key, coefficient);
    }
  }
  return true;
}

int symbolic_determinant(
    const DerivativeMatrix& derivatives,
    std::uint64_t operation_cap,
    std::size_t term_cap,
    double seconds_cap) {
  Limits limits;
  limits.operation_cap = operation_cap;
  limits.aggregate_term_cap = term_cap;
  limits.seconds_cap = seconds_cap;
  limits.start = std::chrono::steady_clock::now();

  std::array<SparsePolynomial, 1U << N> current;
  current[0].emplace(0, K2{1, 0});
  for (std::size_t row = 0; row < N; ++row) {
    std::array<SparsePolynomial, 1U << N> next;
    for (unsigned mask = 0; mask < (1U << N); ++mask) {
      if (__builtin_popcount(mask) != static_cast<int>(row) || current[mask].empty()) continue;
      for (std::size_t column = 0; column < N; ++column) {
        if ((mask & (1U << column)) || derivatives[row][column].empty()) continue;
        unsigned larger = 0;
        for (std::size_t selected = column + 1; selected < N; ++selected) {
          if (mask & (1U << selected)) ++larger;
        }
        if (!add_product(
              next[mask | (1U << column)],
              current[mask],
              derivatives[row][column],
              (larger & 1U) != 0,
              limits)) {
          std::cout << "symbolic_status=ABORTED\n";
          std::cout << "symbolic_abort_reason=" << limits.abort_reason << "\n";
          std::cout << "symbolic_completed_rows=" << row << "\n";
          std::cout << "symbolic_operations=" << limits.operations << "\n";
          std::cout << "symbolic_partial_terms=" << aggregate_terms(next) << "\n";
          std::cout << "symbolic_peak_aggregate_terms=" << limits.peak_aggregate_terms << "\n";
          return 2;
        }
        const auto current_aggregate = aggregate_terms(next);
        limits.peak_aggregate_terms = std::max(limits.peak_aggregate_terms, current_aggregate);
        if (current_aggregate > limits.aggregate_term_cap) {
          std::cout << "symbolic_status=ABORTED\n";
          std::cout << "symbolic_abort_reason=aggregate_term_cap\n";
          std::cout << "symbolic_completed_rows=" << row << "\n";
          std::cout << "symbolic_operations=" << limits.operations << "\n";
          std::cout << "symbolic_partial_terms=" << current_aggregate << "\n";
          std::cout << "symbolic_peak_aggregate_terms=" << limits.peak_aggregate_terms << "\n";
          return 2;
        }
      }
    }
    current = std::move(next);
    std::cout << "symbolic_row_" << (row + 1) << "_aggregate_terms="
              << aggregate_terms(current) << "\n";
  }

  auto& determinant = current[(1U << N) - 1];
  add_to(determinant, 0, K2{MODULUS - 1, 0});
  const auto seconds = std::chrono::duration<double>(
      std::chrono::steady_clock::now() - limits.start).count();
  std::cout << "symbolic_operations=" << limits.operations << "\n";
  std::cout << "symbolic_seconds=" << seconds << "\n";
  std::cout << "symbolic_peak_aggregate_terms=" << limits.peak_aggregate_terms << "\n";
  std::cout << "symbolic_residual_terms=" << determinant.size() << "\n";
  if (determinant.empty()) {
    std::cout << "symbolic_status=PASS_ALL_COEFFICIENTS_MOD_P\n";
    return 0;
  }
  std::cout << "symbolic_status=FAIL_NONZERO_RESIDUAL\n";
  unsigned shown = 0;
  for (const auto& term : determinant) {
    const auto exponent = unpack(term.first);
    std::cout << "residual_term=";
    for (std::size_t j = 0; j < N; ++j) {
      if (j) std::cout << ',';
      std::cout << exponent[j];
    }
    std::cout << '|' << term.second.a << ',' << term.second.b << "\n";
    if (++shown == 8) break;
  }
  return 3;
}

struct Options {
  std::string path;
  std::uint32_t prime = 0;
  unsigned samples = 64;
  bool symbolic = false;
  std::uint64_t operation_cap = 250000000ULL;
  std::size_t term_cap = 4000000;
  double seconds_cap = 55.0;
};

Options parse_options(int argc, char** argv) {
  if (argc < 3) {
    fail("usage: jacobian_modular MAP PRIME [--symbolic] [--samples N] [--op-cap N] [--term-cap N] [--seconds N]");
  }
  Options options;
  options.path = argv[1];
  const std::string prime_text = argv[2];
  if (!canonical_unsigned(prime_text)) fail("prime must be a canonical unsigned decimal integer");
  std::size_t prime_characters = 0;
  const auto prime_value = std::stoull(prime_text, &prime_characters, 10);
  if (prime_characters != prime_text.size()) fail("prime parser did not consume the complete argument");
  if (prime_value > 0x7fffffffULL) fail("prime exceeds the checked 31-bit arithmetic range");
  options.prime = static_cast<std::uint32_t>(prime_value);
  for (int i = 3; i < argc; ++i) {
    const std::string argument = argv[i];
    if (argument == "--symbolic") {
      options.symbolic = true;
    } else if (argument == "--samples" && i + 1 < argc) {
      options.samples = static_cast<unsigned>(std::stoul(argv[++i]));
    } else if (argument == "--op-cap" && i + 1 < argc) {
      options.operation_cap = std::stoull(argv[++i]);
    } else if (argument == "--term-cap" && i + 1 < argc) {
      options.term_cap = static_cast<std::size_t>(std::stoull(argv[++i]));
    } else if (argument == "--seconds" && i + 1 < argc) {
      options.seconds_cap = std::stod(argv[++i]);
    } else {
      fail("unknown or incomplete option: " + argument);
    }
  }
  return options;
}

}  // namespace

int main(int argc, char** argv) {
  try {
    const auto options = parse_options(argc, argv);
    sha256_self_tests();
    const auto raw = read_bytes_once(options.path);
    const auto actual_sha256 = sha256_hex(raw);
    if (actual_sha256 != EXPECTED_SHA256) fail("in-memory canonical SHA-256 mismatch");
    const auto coordinates = parse_canonical_bytes(raw);
    if (options.prime > 0x7fffffffU) fail("prime exceeds the checked 31-bit arithmetic range");
    if (!is_prime(options.prime) || options.prime == 2) fail("modulus must be an odd prime");
    MODULUS = options.prime;
    const auto minus_two = MODULUS - (2 % MODULUS);
    const auto legendre = scalar_pow(minus_two, (MODULUS - 1) / 2);
    const bool split_prime = legendre == 1;
    const bool inert_prime = legendre == MODULUS - 1;
    if (!split_prime && !inert_prime) fail("unexpected quadratic-character result");
    const bool split_from_mod_eight = MODULUS % 8 == 1 || MODULUS % 8 == 3;
    if (split_prime != split_from_mod_eight) fail("quadratic-character/mod-8 self-test disagreement");
    algebra_self_tests();

    for (const auto& coordinate : coordinates) {
      for (const auto& term : coordinate) {
        if (term.denominator % MODULUS == 0) fail("prime divides a serialized denominator");
      }
    }
    const auto derivatives = build_derivatives(coordinates);

    std::cout << "PASS: independent C++ canonical format parser\n";
    std::cout << "implementation_version=" << IMPLEMENTATION_VERSION << "\n";
    std::cout << "sha256_known_answer_self_tests=PASS\n";
    std::cout << "canonical_sha256=" << actual_sha256 << "\n";
    std::cout << "sha256_in_memory_same_buffer_gate=PASS\n";
    std::cout << "canonical_bytes=" << EXPECTED_BYTES << "\n";
    std::cout << "coordinate_terms=[2,207,273,343,372]\n";
    std::cout << "arithmetic_and_determinant_self_tests=PASS\n";
    std::cout << "prime=" << MODULUS << "\n";
    std::cout << "quadratic_behavior=" << (split_prime ? "split" : "inert") << "\n";
    std::cout << "derivative_term_matrix=[";
    for (std::size_t i = 0; i < N; ++i) {
      if (i) std::cout << ',';
      std::cout << '[';
      for (std::size_t j = 0; j < N; ++j) {
        if (j) std::cout << ',';
        std::cout << derivatives[i][j].size();
      }
      std::cout << ']';
    }
    std::cout << "]\n";
    evaluation_pilot(derivatives, options.samples, split_prime);
    std::cout << "evaluation_status=PASS_DIAGNOSTIC_ONLY\n";
    if (!options.symbolic) {
      std::cout << "BOUNDARY: point evaluations do not prove a polynomial identity.\n";
      return 0;
    }
    return symbolic_determinant(
        derivatives, options.operation_cap, options.term_cap, options.seconds_cap);
  } catch (const std::exception& exception) {
    std::cerr << "FAIL: " << exception.what() << "\n";
    return 1;
  }
}
