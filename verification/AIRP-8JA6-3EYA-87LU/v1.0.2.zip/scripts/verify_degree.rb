#!/usr/bin/env ruby
# frozen_string_literal: true

# Exact generic-degree certificate for the accompanying five-dimensional map.
#
# Deliberate independence boundary:
# - Ruby Integer/Rational only; no SymPy, Python, CAS, network, or generator.
# - The frozen canonical ASCII map is parsed as data, never as executable code.
# - The sweep and all four birational layers are rebuilt from the displayed
#   mathematical formulas in the proof drafts.

require "digest"
require "json"

unless ARGV.length == 2
  warn "usage: verify_degree.rb CANONICAL_MAP MANIFEST_JSON"
  exit 64
end

CANONICAL_PATH = File.expand_path(ARGV.fetch(0))
MANIFEST_PATH = File.expand_path(ARGV.fetch(1))
CANONICAL_SHA256 = "ace8f69bc55d219d4c25901f866a310997a128726d4e0dbdce9a533687855ee0"
MANIFEST_SHA256 = "b8efd5fa4de03c7c6edf28ac0606044098dda2e3e4366672717540c15e3c94d7"

class CertificateFailure < StandardError; end

def assert(label, condition)
  raise CertificateFailure, label unless condition
  puts "PASS #{label}"
end

def rat(value)
  value.is_a?(Rational) ? value : Rational(value, 1)
end

# Exact coefficient field Q[eta]/(eta^2+2), represented by a+b*eta.
class QE
  attr_reader :a, :b

  def initialize(a = 0, b = 0)
    @a = a.is_a?(Rational) ? a : Rational(a, 1)
    @b = b.is_a?(Rational) ? b : Rational(b, 1)
  end

  def self.wrap(value)
    value.is_a?(QE) ? value : QE.new(value, 0)
  end

  def +(other)
    return other + self if defined?(Poly) && other.is_a?(Poly)
    return other + self if defined?(Rat) && other.is_a?(Rat)
    other = QE.wrap(other)
    QE.new(@a + other.a, @b + other.b)
  end

  def -(other)
    return -(other - self) if defined?(Poly) && other.is_a?(Poly)
    return -(other - self) if defined?(Rat) && other.is_a?(Rat)
    other = QE.wrap(other)
    QE.new(@a - other.a, @b - other.b)
  end

  def -@
    QE.new(-@a, -@b)
  end

  def *(other)
    return other * self if defined?(Poly) && other.is_a?(Poly)
    return other * self if defined?(Rat) && other.is_a?(Rat)
    other = QE.wrap(other)
    QE.new(@a * other.a - 2 * @b * other.b,
           @a * other.b + @b * other.a)
  end

  def inverse
    norm = @a * @a + 2 * @b * @b
    raise ZeroDivisionError, "zero in Q(eta)" if norm.zero?
    QE.new(@a / norm, -@b / norm)
  end

  def /(other)
    self * QE.wrap(other).inverse
  end

  def **(power)
    raise ArgumentError, "negative power" if power.negative?
    result = QE.new(1)
    base = self
    exponent = power
    while exponent.positive?
      result *= base if exponent.odd?
      exponent >>= 1
      base *= base if exponent.positive?
    end
    result
  end

  def ==(other)
    other = QE.wrap(other)
    @a == other.a && @b == other.b
  end

  def zero?
    @a.zero? && @b.zero?
  end

  def coerce(other)
    [QE.wrap(other), self]
  end

  def canonical_triple
    d = @a.denominator.lcm(@b.denominator)
    n0 = @a.numerator * (d / @a.denominator)
    n1 = @b.numerator * (d / @b.denominator)
    g = n0.abs.gcd(n1.abs).gcd(d)
    [n0 / g, n1 / g, d / g]
  end

  def to_s
    n0, n1, d = canonical_triple
    "(#{n0}+#{n1}*eta)/#{d}"
  end
end

# Sparse multivariate polynomial over QE. Exponents are immutable arrays.
class Poly
  attr_reader :nvars, :terms

  def initialize(nvars, raw_terms = {})
    @nvars = nvars
    @terms = {}
    raw_terms.each do |exponents, coefficient|
      raise ArgumentError, "wrong exponent length" unless exponents.length == nvars
      key = exponents.map(&:to_i).freeze
      raise ArgumentError, "negative exponent" if key.any?(&:negative?)
      value = QE.wrap(coefficient)
      next if value.zero?
      sum = (@terms[key] || QE.new) + value
      sum.zero? ? @terms.delete(key) : @terms[key] = sum
    end
  end

  def self.zero(nvars)
    Poly.new(nvars)
  end

  def self.one(nvars)
    constant(nvars, 1)
  end

  def self.constant(nvars, coefficient)
    value = QE.wrap(coefficient)
    return zero(nvars) if value.zero?
    Poly.new(nvars, { Array.new(nvars, 0) => value })
  end

  def self.variable(nvars, index)
    exponents = Array.new(nvars, 0)
    exponents[index] = 1
    Poly.new(nvars, { exponents => QE.new(1) })
  end

  def wrap(other)
    other.is_a?(Poly) ? other : Poly.constant(@nvars, other)
  end

  def check_ring(other)
    raise ArgumentError, "polynomial ring mismatch" unless @nvars == other.nvars
  end

  def +(other)
    other = wrap(other)
    check_ring(other)
    data = @terms.dup
    other.terms.each do |exponents, coefficient|
      value = (data[exponents] || QE.new) + coefficient
      value.zero? ? data.delete(exponents) : data[exponents] = value
    end
    Poly.new(@nvars, data)
  end

  def -(other)
    self + (-wrap(other))
  end

  def -@
    Poly.new(@nvars, @terms.transform_values { |coefficient| -coefficient })
  end

  def *(other)
    other = wrap(other)
    check_ring(other)
    return Poly.zero(@nvars) if zero? || other.zero?
    data = {}
    @terms.each do |left_exp, left_coefficient|
      other.terms.each do |right_exp, right_coefficient|
        exponents = Array.new(@nvars) { |i| left_exp[i] + right_exp[i] }.freeze
        value = (data[exponents] || QE.new) + left_coefficient * right_coefficient
        value.zero? ? data.delete(exponents) : data[exponents] = value
      end
    end
    Poly.new(@nvars, data)
  end

  def /(scalar)
    scalar = QE.wrap(scalar)
    Poly.new(@nvars, @terms.transform_values { |coefficient| coefficient / scalar })
  end

  def **(power)
    raise ArgumentError, "negative power" if power.negative?
    result = Poly.one(@nvars)
    base = self
    exponent = power
    while exponent.positive?
      result *= base if exponent.odd?
      exponent >>= 1
      base *= base if exponent.positive?
    end
    result
  end

  def deriv(index)
    data = {}
    @terms.each do |exponents, coefficient|
      next if exponents[index].zero?
      next_exp = exponents.dup
      multiplier = next_exp[index]
      next_exp[index] -= 1
      data[next_exp] = coefficient * multiplier
    end
    Poly.new(@nvars, data)
  end

  def compose(images)
    raise ArgumentError, "wrong image count" unless images.length == @nvars
    target_nvars = images.first.nvars
    raise ArgumentError, "image ring mismatch" unless images.all? { |p| p.nvars == target_nvars }
    maxima = Array.new(@nvars, 0)
    @terms.each_key do |exponents|
      @nvars.times { |i| maxima[i] = [maxima[i], exponents[i]].max }
    end
    powers = images.each_with_index.map do |image, i|
      values = [Poly.one(target_nvars)]
      1.upto(maxima[i]) { values << values[-1] * image }
      values
    end
    total = Poly.zero(target_nvars)
    @terms.each do |exponents, coefficient|
      term = Poly.constant(target_nvars, coefficient)
      @nvars.times { |i| term *= powers[i][exponents[i]] }
      total += term
    end
    total
  end

  def evaluate_rats(images)
    raise ArgumentError, "wrong image count" unless images.length == @nvars
    target_nvars = images.first.nvars
    maxima = Array.new(@nvars, 0)
    @terms.each_key do |exponents|
      @nvars.times { |i| maxima[i] = [maxima[i], exponents[i]].max }
    end
    powers = images.each_with_index.map do |image, i|
      values = [Rat.one(target_nvars)]
      1.upto(maxima[i]) { values << values[-1] * image }
      values
    end
    total = Rat.zero(target_nvars)
    @terms.each do |exponents, coefficient|
      term = Rat.constant(target_nvars, coefficient)
      @nvars.times { |i| term *= powers[i][exponents[i]] }
      total += term
    end
    total
  end

  def split_variable(index)
    result = Hash.new { |hash, degree| hash[degree] = Poly.zero(@nvars - 1) }
    @terms.each do |exponents, coefficient|
      degree = exponents[index]
      reduced = exponents.dup
      reduced.delete_at(index)
      result[degree] = result[degree] + Poly.new(@nvars - 1, { reduced => coefficient })
    end
    result
  end

  def coefficient_in(index, degree)
    split_variable(index)[degree]
  end

  def degree_in(index)
    return -1 if zero?
    @terms.keys.map { |exponents| exponents[index] }.max
  end

  def total_degree
    return -1 if zero?
    @terms.keys.map { |exponents| exponents.sum }.max
  end

  def zero?
    @terms.empty?
  end

  def ==(other)
    other = wrap(other)
    @nvars == other.nvars && @terms == other.terms
  end

  def coerce(other)
    [Poly.constant(@nvars, other), self]
  end

  def fingerprint
    records = @terms.sort { |(a, _), (b, _)| b <=> a }.map do |exponents, coefficient|
      n0, n1, d = coefficient.canonical_triple
      "#{exponents.join(',')}|#{n0},#{n1},#{d}\n"
    end.join
    Digest::SHA256.hexdigest(records)
  end
end

# Rational functions with equality checked by exact cross multiplication.
class Rat
  attr_reader :num, :den, :nvars

  def initialize(num, den = nil)
    raise ArgumentError, "numerator must be polynomial" unless num.is_a?(Poly)
    den ||= Poly.one(num.nvars)
    raise ArgumentError, "denominator ring mismatch" unless den.is_a?(Poly) && den.nvars == num.nvars
    raise ZeroDivisionError, "zero polynomial denominator" if den.zero?
    @num = num
    @den = den
    @nvars = num.nvars
  end

  def self.zero(nvars)
    Rat.new(Poly.zero(nvars))
  end

  def self.one(nvars)
    Rat.new(Poly.one(nvars))
  end

  def self.constant(nvars, coefficient)
    Rat.new(Poly.constant(nvars, coefficient))
  end

  def self.wrap(value, nvars)
    return value if value.is_a?(Rat)
    return Rat.new(value) if value.is_a?(Poly)
    Rat.constant(nvars, value)
  end

  def +(other)
    other = Rat.wrap(other, @nvars)
    Rat.new(@num * other.den + other.num * @den, @den * other.den)
  end

  def -(other)
    self + (-Rat.wrap(other, @nvars))
  end

  def -@
    Rat.new(-@num, @den)
  end

  def *(other)
    other = Rat.wrap(other, @nvars)
    Rat.new(@num * other.num, @den * other.den)
  end

  def /(other)
    other = Rat.wrap(other, @nvars)
    raise ZeroDivisionError, "zero rational function" if other.num.zero?
    Rat.new(@num * other.den, @den * other.num)
  end

  def **(power)
    raise ArgumentError, "negative power" if power.negative?
    Rat.new(@num**power, @den**power)
  end

  def ==(other)
    other = Rat.wrap(other, @nvars)
    @num * other.den == other.num * @den
  end

  def zero?
    @num.zero?
  end

  def coerce(other)
    [Rat.wrap(other, @nvars), self]
  end
end

def polynomial_determinant(matrix)
  size = matrix.length
  raise ArgumentError, "empty/non-square matrix" if size.zero? || matrix.any? { |row| row.length != size }
  return matrix[0][0] if size == 1
  nvars = matrix[0][0].nvars
  total = Poly.zero(nvars)
  matrix[0].each_with_index do |entry, column|
    next if entry.zero?
    minor = matrix[1..-1].map { |row| row.each_with_index.reject { |_, j| j == column }.map(&:first) }
    term = entry * polynomial_determinant(minor)
    total += column.even? ? term : -term
  end
  total
end

def sylvester_resultant(first, second)
  # Coefficient arrays are low degree to high degree, with Poly coefficients.
  m = first.length - 1
  n = second.length - 1
  raise ArgumentError, "zero leading coefficient" if first[-1].zero? || second[-1].zero?
  ring_nvars = first[-1].nvars
  zero = Poly.zero(ring_nvars)
  rows = []
  n.times do |shift|
    row = Array.new(m + n) { zero }
    first.reverse.each_with_index { |coefficient, j| row[shift + j] = coefficient }
    rows << row
  end
  m.times do |shift|
    row = Array.new(m + n) { zero }
    second.reverse.each_with_index { |coefficient, j| row[shift + j] = coefficient }
    rows << row
  end
  polynomial_determinant(rows)
end

def parse_frozen_bundle
  canonical_bytes = File.binread(CANONICAL_PATH)
  manifest_bytes = File.binread(MANIFEST_PATH)
  assert("canonical SHA-256 fixed", Digest::SHA256.hexdigest(canonical_bytes) == CANONICAL_SHA256)
  assert("manifest SHA-256 fixed", Digest::SHA256.hexdigest(manifest_bytes) == MANIFEST_SHA256)
  assert("canonical byte count 34436", canonical_bytes.bytesize == 34_436)
  assert("manifest byte count 2034", manifest_bytes.bytesize == 2034)
  assert("canonical is ASCII", canonical_bytes.ascii_only?)
  assert("canonical LF-only with final newline", !canonical_bytes.include?("\r") && canonical_bytes.end_with?("\n"))

  manifest = JSON.parse(manifest_bytes)
  assert("manifest declares canonical hash", manifest.dig("canonical_serialization", "bundle_sha256") == CANONICAL_SHA256)
  assert("manifest field presentation", manifest.dig("coefficient_field", "presentation") == "Q[eta]/(eta^2+2)")
  assert("manifest input order", manifest["input_variable_order"] == %w[rho Y1 Y2 Y3 Y4])

  lines = canonical_bytes.lines
  index = 0
  assert("bundle magic", lines[index]&.chomp == "EXACT-D1-KELLER-BUNDLE-V1")
  index += 1
  coordinates = []
  sections = []
  while index < lines.length
    start = index
    expected_header = [
      "EXACT-D1-KELLER-COORDINATE-V1",
      "field=Q[eta]/(eta^2+2)",
      "eta-generator=formal-class-of-t-mod-(t^2+2);mu=(2+4*eta)/9",
      "variables=rho,Y1,Y2,Y3,Y4",
      "monomial-order=descending-lexicographic-exponent-tuples"
    ]
    expected_header.each do |expected|
      assert("canonical section header #{expected}", lines[index]&.chomp == expected)
      index += 1
    end
    name_line = lines[index]&.chomp
    count_line = lines[index + 1]&.chomp
    raise CertificateFailure, "missing coordinate metadata" unless name_line&.start_with?("coordinate=") && count_line&.start_with?("term-count=")
    name = name_line.split("=", 2)[1]
    count = Integer(count_line.split("=", 2)[1], 10)
    index += 2
    terms = {}
    previous = nil
    count.times do
      line = lines[index]&.chomp
      raise CertificateFailure, "truncated coordinate #{name}" unless line
      exponent_text, coefficient_text = line.split("|", 2)
      raise CertificateFailure, "bad term line #{line}" unless exponent_text && coefficient_text
      exponents = exponent_text.split(",").map { |part| Integer(part, 10) }
      coefficient_parts = coefficient_text.split(",").map { |part| Integer(part, 10) }
      raise CertificateFailure, "bad exponent arity" unless exponents.length == 5
      raise CertificateFailure, "bad coefficient arity" unless coefficient_parts.length == 3
      n0, n1, denominator = coefficient_parts
      raise CertificateFailure, "nonpositive denominator" unless denominator.positive?
      raise CertificateFailure, "nonprimitive coefficient record" unless n0.abs.gcd(n1.abs).gcd(denominator) == 1
      raise CertificateFailure, "zero coefficient record" if n0.zero? && n1.zero?
      if previous
        raise CertificateFailure, "monomial order violation" unless (previous <=> exponents) == 1
      end
      previous = exponents
      raise CertificateFailure, "duplicate exponent" if terms.key?(exponents)
      terms[exponents] = QE.new(Rational(n0, denominator), Rational(n1, denominator))
      index += 1
    end
    coordinates << Poly.new(5, terms)
    sections << lines[start...index].join
    assert("parsed #{name} term count", coordinates[-1].terms.length == count)
  end

  assert("five canonical coordinates", coordinates.length == 5)
  assert("canonical term counts", coordinates.map { |p| p.terms.length } == [2, 207, 273, 343, 372])
  assert("canonical total degrees", coordinates.map(&:total_degree) == [3, 27, 29, 31, 31])
  manifest["coordinates"].each_with_index do |record, i|
    assert("coordinate #{record['name']} byte count", sections[i].bytesize == record["byte_count"])
    assert("coordinate #{record['name']} SHA-256", Digest::SHA256.hexdigest(sections[i]) == record["sha256"])
  end
  coordinates
end

MU = QE.new(Rational(2, 9), Rational(4, 9))
A0 = (3 * MU - 2) / 2
A1 = 2 * (MU + 2) / 3
A2 = -4 * (5 * MU - 2) / 3
S0 = (63 * MU - 46) / 256
S1C = -(45 * MU - 2) / 64
S2C = (9 * MU + 2) / 16
KAPPA = -3 * MU / 2

L21 = -(9 * MU + 26) / 16
L31 = -2 * (11 * MU - 14) / 3
L32 = 2 * (19 * MU - 16) / 3
L41 = (9 * MU + 2) / 16
L42 = -(9 * MU + 14) / 32
Q3 = (53 * MU - 26) / 24
Q4 = -(45 * MU - 17) / 32

def build_sweep
  # First build in (x,y,theta), where the Hamiltonian derivatives are taken.
  x3 = Poly.variable(3, 0)
  y3 = Poly.variable(3, 1)
  theta3 = Poly.variable(3, 2)
  a = A0 + A1 * x3 + A2 * x3**2
  s = S0 + S1C * x3 + S2C * x3**2
  ap = a.deriv(0)
  app = ap.deriv(0)
  sp = s.deriv(0)
  spp = sp.deriv(0)
  tau = theta3 + s
  z = y3 + a
  f = tau * z - sp / 2
  g = MU * tau * z**3 - (ap * tau + spp / 2) * z + app * tau / 2 + spp * a / 2 + KAPPA
  lf_f = f.deriv(0) + 2 * f * f.deriv(2)
  gy = g.deriv(1)
  x1 = -(gy + lf_f) / 2

  gamma4 = Poly.variable(4, 0)
  x4 = Poly.variable(4, 1)
  y4 = Poly.variable(4, 2)
  theta4 = Poly.variable(4, 3)
  lift = [x4, y4, theta4]
  f4 = f.compose(lift)
  g4 = g.compose(lift)
  x14 = x1.compose(lift)
  sweep1 = x14 + gamma4
  sweep2 = f4 + x4 * sweep1
  sweep3 = 2 * x4 * f4 - theta4 + x4**2 * sweep1
  sweep4 = g4 + y4 * sweep1
  [sweep1, sweep2, sweep3, sweep4]
end

def verify_sweep_dominance(sweep)
  jacobian = sweep.map { |coordinate| 4.times.map { |j| coordinate.deriv(j) } }
  determinant = polynomial_determinant(jacobian)
  gamma = Poly.variable(4, 0)
  assert("direct sweep Jacobian identity det J(S)=gamma^2", determinant == gamma**2)
  puts "INFO sweep-coordinate-term-counts=#{sweep.map { |p| p.terms.length }.inspect}"
  puts "INFO sweep-jacobian-residual-fingerprint=#{(determinant - gamma**2).fingerprint}"
end

def verify_quartic_and_lifting(sweep)
  # Independent affine target coordinates (A,B,D,L) and primitive x.
  aa = Poly.variable(5, 0)
  bb = Poly.variable(5, 1)
  dd = Poly.variable(5, 2)
  ll = Poly.variable(5, 3)
  xx = Poly.variable(5, 4)
  delta = bb**2 - 4 * aa * dd
  tt = aa * xx**2 + bb * xx + dd
  nn = aa * xx + bb / 2
  pp = ll * tt**2 + MU * nn**3 - aa * tt * nn
  gamma_num = -2 * aa * tt + (3 * MU + 2) * nn**2

  assert("N^2-A*T=Delta/4", nn**2 - aa * tt == delta / 4)
  assert("quartic degree in x", pp.degree_in(4) == 4)
  expected_lc = Poly.variable(4, 0)**2 * Poly.variable(4, 3)
  assert("quartic leading coefficient A^2*L", pp.coefficient_in(4, 4) == expected_lc)
  assert("gamma numerator has x-degree 2 < 4", gamma_num.degree_in(4) == 2 && !gamma_num.zero?)
  assert("gamma numerator leading coefficient is 3*mu*A^2",
         gamma_num.coefficient_in(4, 2) == 3 * MU * Poly.variable(4, 0)**2)

  t_coeff = tt.split_variable(4)
  n_coeff = nn.split_variable(4)
  p_coeff = pp.split_variable(4)
  t_array = 0.upto(2).map { |i| t_coeff[i] }
  n_array = 0.upto(1).map { |i| n_coeff[i] }
  p_array = 0.upto(4).map { |i| p_coeff[i] }
  res_t_n = sylvester_resultant(t_array, n_array)
  a4 = Poly.variable(4, 0)
  b4 = Poly.variable(4, 1)
  d4 = Poly.variable(4, 2)
  delta4 = b4**2 - 4 * a4 * d4
  assert("Res_x(T,N)=-A*Delta/4", res_t_n == -a4 * delta4 / 4)
  res_p_t = sylvester_resultant(p_array, t_array)
  assert("Res_x(P,T)=-A^4*mu^2*Delta^3/64", res_p_t == -(a4**4) * (MU**2) * (delta4**3) / 64)

  # Target coordinates S_i are recovered by an invertible affine change.
  target_s1 = S2C - aa
  target_s2 = (bb - S1C) / 2
  target_s3 = S0 - dd
  target_s4 = A2 * dd - A1 * bb / 2 + A0 * aa + KAPPA - ll
  assert("target affine change inverse recovers (A,B,D,L)",
         [S2C - target_s1,
          S1C + 2 * target_s2,
          S0 - target_s3,
          A2 * (S0 - target_s3) - A1 * (S1C + 2 * target_s2) / 2 +
            A0 * (S2C - target_s1) + KAPPA - target_s4] == [aa, bb, dd, ll])

  raw_target = 4.times.map { |i| Poly.variable(4, i) }
  raw_s1, raw_s2, raw_s3, raw_s4 = raw_target
  raw_a = S2C - raw_s1
  raw_b = S1C + 2 * raw_s2
  raw_d = S0 - raw_s3
  raw_l = A2 * raw_d - A1 * raw_b / 2 + A0 * raw_a + KAPPA - raw_s4
  assert("target affine change forward-after-inverse is identity",
         [S2C - raw_a,
          (raw_b - S1C) / 2,
          S0 - raw_d,
          A2 * raw_d - A1 * raw_b / 2 + A0 * raw_a + KAPPA - raw_l] == raw_target)
  theta = 2 * xx * target_s2 - xx**2 * target_s1 - target_s3
  ax = A0 + A1 * xx + A2 * xx**2
  sx = S0 + S1C * xx + S2C * xx**2
  z = Rat.new(nn, tt)
  y = z - ax
  gamma = Rat.new(gamma_num, 2 * tt)
  assert("recovered theta+s(x)=T", theta + sx == tt)

  images = [gamma, Rat.new(xx), y, Rat.new(theta)]
  evaluated = sweep.map { |coordinate| coordinate.evaluate_rats(images) }
  targets = [target_s1, target_s2, target_s3, target_s4].map { |p| Rat.new(p) }
  assert("unique lift satisfies sweep coordinate 1", evaluated[0] == targets[0])
  assert("unique lift satisfies sweep coordinate 2", evaluated[1] == targets[1])
  assert("unique lift satisfies sweep coordinate 3", evaluated[2] == targets[2])
  fourth_residual = evaluated[3] - targets[3]
  assert("source sweep S4 minus target S4 is exactly P/T^2",
         fourth_residual == Rat.new(pp, tt**2))

  # Exact premises for the Gauss-lemma argument.
  q_without_l = pp - ll * tt**2
  assert("P is affine-linear in L with coefficient T^2", pp.coefficient_in(3, 1) == tt.split_variable(3)[0]**2)
  assert("L-free coefficient Q is independent of L", q_without_l.degree_in(3) == 0)
  assert("exact L-free coefficient Q=mu*N^3-A*T*N",
         q_without_l - MU * nn**3 + aa * tt * nn == 0)
  assert("mu is nonzero", !MU.zero?)
  assert("mu relation 9mu^2-4mu+4=0", 9 * MU**2 - 4 * MU + 4 == 0)

  puts "INFO quartic-fingerprint=#{pp.fingerprint}"
  puts "INFO resultant-P-T-fingerprint=#{res_p_t.fingerprint}"
  puts "DEDUCTION dominance gives an injective target-function-field pullback"
  puts "DEDUCTION nonzero resultant excludes T=0 at every generic quartic root"
  puts "DEDUCTION gcd(T^2,Q)=1 makes P primitive and affine-linear in L"
  puts "DEDUCTION Gauss lemma plus localization makes P irreducible over k(A,B,D,L)"
  puts "DEDUCTION the same nonzero-resultant and primitive-linear-in-L proof survives every constant-field extension, so P is absolutely irreducible"
  puts "DEDUCTION irreducible deg(P)=4 and the exact unique lift give sweep function-field degree 4"
  puts "DEDUCTION deg(Gamma)<deg(P), Gamma!=0, and irreducibility make gamma=Gamma/(2T) nonzero in the generic extension"
end

def verify_stage_inverse
  # v -> (gamma,u) -> v
  v = 4.times.map { |i| Poly.variable(4, i) }
  v1, v2, v3, v4 = v
  gamma = 1 + v1
  u1 = 1 + L21 * v1 + v2
  u2 = L31 * v1 + L32 * v2 + v3 + Q3 * v1**2
  u3 = L41 * v1 + L42 * v2 + v4 + Q4 * v1**2
  recovered_v1 = gamma - 1
  recovered_v2 = u1 - 1 - L21 * recovered_v1
  recovered_v3 = u2 - L31 * recovered_v1 - L32 * recovered_v2 - Q3 * recovered_v1**2
  recovered_v4 = u3 - L41 * recovered_v1 - L42 * recovered_v2 - Q4 * recovered_v1**2
  assert("stage inverse after forward", [recovered_v1, recovered_v2, recovered_v3, recovered_v4] == v)

  out = 4.times.map { |i| Poly.variable(4, i) }
  ogamma, ou1, ou2, ou3 = out
  iv1 = ogamma - 1
  iv2 = ou1 - 1 - L21 * iv1
  iv3 = ou2 - L31 * iv1 - L32 * iv2 - Q3 * iv1**2
  iv4 = ou3 - L41 * iv1 - L42 * iv2 - Q4 * iv1**2
  forward_again = [
    1 + iv1,
    1 + L21 * iv1 + iv2,
    L31 * iv1 + L32 * iv2 + iv3 + Q3 * iv1**2,
    L41 * iv1 + L42 * iv2 + iv4 + Q4 * iv1**2
  ]
  assert("stage forward after inverse", forward_again == out)
  stage_jacobian = [gamma, u1, u2, u3].map { |coordinate| 4.times.map { |j| coordinate.deriv(j) } }
  assert("stage Jacobian determinant one", polynomial_determinant(stage_jacobian) == 1)
end

def verify_rational_layer_inverses
  # Weighted source layer on rho != 0.
  src = 5.times.map { |i| Poly.variable(5, i) }
  rho, y1, y2, y3, y4 = src
  v = [rho * y1, rho**2 * y2, rho**3 * y3, rho**3 * y4]
  recovered = [Rat.new(v[0], rho), Rat.new(v[1], rho**2), Rat.new(v[2], rho**3), Rat.new(v[3], rho**3)]
  assert("weighted-source inverse after forward", recovered == [y1, y2, y3, y4].map { |p| Rat.new(p) })

  # Weighted parameter layer on gamma != 0.
  par = 4.times.map { |i| Poly.variable(4, i) }
  gamma, u1, u2, u3 = par
  x = gamma * u1
  y = gamma**2 * u2
  theta = gamma**3 * u3
  recovered_u = [Rat.new(x, gamma), Rat.new(y, gamma**2), Rat.new(theta, gamma**3)]
  assert("weighted-parameter inverse after forward", recovered_u == [u1, u2, u3].map { |p| Rat.new(p) })

  # Radial coordinate and target dehomogenization.
  radial = 2.times.map { |i| Poly.variable(2, i) }
  rrho, rgamma = radial
  cc = rrho * rgamma
  assert("radial recovery rho=C/gamma", Rat.new(cc, rgamma) == rrho)

  target = 5.times.map { |i| Poly.variable(5, i) }
  c, s1, s2, s3, s4 = target
  f = [Rat.new(s1, c), Rat.new(s2, c**2), Rat.new(s3, c**3), Rat.new(s4, c**3)]
  recovered_s = [f[0] * c, f[1] * c**2, f[2] * c**3, f[3] * c**3]
  assert("target-dehomogenization inverse after forward", recovered_s == [s1, s2, s3, s4].map { |p| Rat.new(p) })

  # Composite inverse of the three source-coordinate layers.  This explicitly
  # keeps the central variables (rho,gamma,x,y,theta) separate from the final
  # canonical source variables.
  central = 5.times.map { |i| Poly.variable(5, i) }
  crho, cgamma, cx, cy, ctheta = central
  ru1 = Rat.new(cx, cgamma)
  ru2 = Rat.new(cy, cgamma**2)
  ru3 = Rat.new(ctheta, cgamma**3)
  rv1 = Rat.new(cgamma - 1)
  rv2 = ru1 - 1 - L21 * rv1
  rv3 = ru2 - L31 * rv1 - L32 * rv2 - Q3 * rv1**2
  rv4 = ru3 - L41 * rv1 - L42 * rv2 - Q4 * rv1**2
  original_y = [
    rv1 / Rat.new(crho),
    rv2 / Rat.new(crho**2),
    rv3 / Rat.new(crho**3),
    rv4 / Rat.new(crho**3)
  ]
  forward_v = [
    Rat.new(crho) * original_y[0],
    Rat.new(crho**2) * original_y[1],
    Rat.new(crho**3) * original_y[2],
    Rat.new(crho**3) * original_y[3]
  ]
  fv1, fv2, fv3, fv4 = forward_v
  forward_gamma = 1 + fv1
  forward_u1 = 1 + L21 * fv1 + fv2
  forward_u2 = L31 * fv1 + L32 * fv2 + fv3 + Q3 * fv1**2
  forward_u3 = L41 * fv1 + L42 * fv2 + fv4 + Q4 * fv1**2
  forward_central = [
    Rat.new(crho),
    forward_gamma,
    forward_gamma * forward_u1,
    forward_gamma**2 * forward_u2,
    forward_gamma**3 * forward_u3
  ]
  assert("composite source-layer forward after rational inverse",
         forward_central == central.map { |p| Rat.new(p) })

  # The birational change (rho,gamma)<->(C,gamma) makes C an independent
  # rational coordinate rather than an extra algebraic condition.
  ccentral = crho * cgamma
  assert("central field change (rho,gamma)<->(C,gamma)",
         Rat.new(ccentral, cgamma) == crho)
end

def verify_same_object_bridge(sweep, canonical)
  rho, y1, y2, y3, y4 = 5.times.map { |i| Poly.variable(5, i) }
  v1 = rho * y1
  v2 = rho**2 * y2
  v3 = rho**3 * y3
  v4 = rho**3 * y4
  gamma = 1 + v1
  u1 = 1 + L21 * v1 + v2
  u2 = L31 * v1 + L32 * v2 + v3 + Q3 * v1**2
  u3 = L41 * v1 + L42 * v2 + v4 + Q4 * v1**2
  x = gamma * u1
  y = gamma**2 * u2
  theta = gamma**3 * u3
  c = rho * gamma
  derived_sweep = sweep.map { |coordinate| coordinate.compose([gamma, x, y, theta]) }

  assert("canonical F0 equals C=rho*gamma", canonical[0] == c)
  weights = [1, 2, 3, 3]
  4.times do |i|
    assert("same-object bridge S#{i + 1}=C^#{weights[i]}*F#{i + 1}", derived_sweep[i] == c**weights[i] * canonical[i + 1])
  end
  puts "INFO derived-sweep-after-layers-term-counts=#{derived_sweep.map { |p| p.terms.length }.inspect}"
  puts "INFO canonical-coordinate-fingerprints=#{canonical.map(&:fingerprint).inspect}"
  puts "DEDUCTION exact identities are the diagram beta o F_canonical = (id_C x S) o alpha"
  puts "DEDUCTION k(rho,gamma,x,y,theta)=k(C,gamma,x,y,theta) via rho=C/gamma, so C is an independent factor"
  puts "DEDUCTION the frozen canonical map and the formula-level sweep define isomorphic generic function-field extensions"
  puts "DEDUCTION the frozen canonical map has geometric degree 4 after k->C by the constant-extension-stable Gauss argument"
end

begin
  started = Process.clock_gettime(Process::CLOCK_MONOTONIC)
  puts "DEGREE-CERTIFICATE 1.0.0"
  puts "INFO ruby=#{RUBY_VERSION} platform=#{RUBY_PLATFORM}"
  canonical = parse_frozen_bundle
  sweep = build_sweep
  verify_sweep_dominance(sweep)
  verify_quartic_and_lifting(sweep)
  verify_stage_inverse
  verify_rational_layer_inverses
  verify_same_object_bridge(sweep, canonical)
  elapsed = Process.clock_gettime(Process::CLOCK_MONOTONIC) - started
  puts format("PASS ALL elapsed_seconds=%.3f", elapsed)
rescue StandardError => error
  warn "FAIL #{error.class}: #{error.message}"
  warn error.backtrace.join("\n")
  exit 1
end
