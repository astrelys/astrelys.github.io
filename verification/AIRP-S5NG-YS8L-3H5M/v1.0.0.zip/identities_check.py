from fractions import Fraction as Q

# Sparse exact polynomials in four independent variables.
def C(a):
    return {} if not a else {(0, 0, 0, 0): Q(a)}

def X(i):
    e = [0, 0, 0, 0]
    e[i] = 1
    return {tuple(e): Q(1)}

def add(*polys):
    out = {}
    for p in polys:
        for e, a in p.items():
            out[e] = out.get(e, 0)+a
    return {e: a for e, a in out.items() if a}

def sc(p, a):
    return {e: v*a for e, v in p.items() if v*a}

def pmul(*polys):
    out = C(1)
    for p in polys:
        z = {}
        for e, a in out.items():
            for f, b in p.items():
                g = tuple(i+j for i, j in zip(e, f))
                z[g] = z.get(g, 0)+a*b
        out = {e: a for e, a in z.items() if a}
    return out

def pw(p, n):
    out = C(1)
    for _ in range(n):
        out = pmul(out, p)
    return out

def model(r, u, p, s):
    J0 = sc(pmul(p, r, add(r, C(-1)), add(r, C(1))), Q(1, 6))
    J = add(J0, sc(pmul(s, add(r, C(-1)), u), -1))
    E = add(pmul(p, add(r, C(1))), sc(s, -2))
    B0 = sc(pmul(r, E), Q(1, 2))
    B = add(B0, sc(pmul(s, u), -1))
    A = add(pmul(s, add(r, C(-1))), C(-1))
    d = add(A, C(-1))
    D = add(
        pmul(d, B, B),
        sc(pmul(d, E, J), -1),
        sc(pmul(u, E, A, A), -1),
        sc(pmul(u, s, A, B), 2),
        sc(pmul(u, s, s, J), -1)
    )
    Z0 = add(pmul(B0, B0), sc(pmul(E, J0), -1))
    return J0, J, E, B0, B, A, d, D, Z0

r, u, p, s = (X(i) for i in range(4))
J0, J, E, B0, B, A, d, D, Z0 = model(r, u, p, s)

# 1. Affineness in u.
assert D == add(
    pmul(d, Z0),
    pmul(u, add(
        sc(pmul(s, B0), 2),
        sc(E, -1),
        sc(pmul(s, s, J0), -1)
    ))
)

# 2. Factorization of Z0.
assert sc(Z0, 12) == pmul(
    r, E,
    add(pmul(p, add(r, C(1)), add(r, C(2))),
        sc(pmul(s, r), -6))
)

# 3. Denominator-cleared determinant identity.
T11 = add(sc(pmul(d, J), -1), sc(pmul(u, A, A), -1))
T12 = pmul(u, add(pmul(s, J), sc(pmul(A, B), -1)))
T22 = pmul(u, add(pmul(E, J), sc(pmul(B, B), -1)))
assert add(pmul(T11, T22), sc(pmul(T12, T12), -1)) == pmul(u, J, D)

# Substitute s=1+y, p=(4s-1+w)/3.
x, y, w = X(0), X(2), X(3)
s = add(C(1), y)
p = sc(add(sc(s, 4), C(-1), w), Q(1, 3))
r = add(C(4), x)

rows = {
    (0, 0): (54, 153, 153, 63, 9),
    (0, 1): (540, 648, 318, 72, 6),
    (0, 2): (150, 235, 101, 17, 1),
    (1, 0): (378, 945, 813, 279, 33),
    (1, 1): (1740, 2078, 946, 190, 14),
    (1, 2): (450, 405, 133, 19, 1),
    (2, 0): (780, 1870, 1376, 398, 40),
    (2, 1): (1620, 1734, 692, 122, 8),
    (3, 0): (576, 1212, 748, 184, 16),
}
certificate = {}
for (i, j), row in rows.items():
    f = add(*(sc(pw(x, k), a) for k, a in enumerate(row)))
    certificate = add(certificate, pmul(pw(y, i), pw(w, j), f))

# 4. Large-r endpoint certificate.
assert sc(model(r, r, p, s)[7], 108) == pmul(r, certificate)

# 5. r=3, u=2 endpoint.
D3 = model(C(3), C(2), p, s)[7]
P3 = add(
    sc(w, 24), sc(y, 6), sc(pmul(y, w), 96),
    sc(pmul(y, w, w), 40), sc(pmul(y, y), 24),
    sc(pmul(y, y, w), 128), sc(pw(y, 3), 34)
)
assert sc(D3, 9) == P3

def special(r0, u0, v0):
    J0, J, E, B0, B, A, d, D, Z0 = model(C(r0), C(u0), p, s)
    K = add(J, C(-v0))
    Cc = add(sc(s, r0), C(-1))
    VV = add(K, C(2-Q(1, v0))) if v0 else None
    UU = add(K, sc(A, 2), sc(d, -Q(1, u0))) if u0 else None
    VU = add(K, A, C(1))
    VZ = add(K, B, C(1))
    UZ = add(K, B, Cc)
    ZZ = add(K, sc(B, 2), E)
    return VV, UU, VU, VZ, UZ, ZZ

# 6. Exceptional profile (2,2).
VV, UU, VU, VZ, UZ, ZZ = special(2, 0, 2)
a = add(p, sc(s, -1))
assert add(pmul(VZ, VZ), sc(pmul(VV, ZZ), -1)) == pmul(
    a, add(sc(p, 6), sc(s, -4), C(-1))
)

# 7. Exceptional profile (2,1,1).
VV, UU, VU, VZ, UZ, ZZ = special(3, 2, 1)
det = add(
    pmul(VV, UU, ZZ),
    sc(pmul(VU, VZ, UZ), 2),
    sc(pmul(VV, UZ, UZ), -1),
    sc(pmul(UU, VZ, VZ), -1),
    sc(pmul(ZZ, VU, VU), -1)
)
cert211 = add(
    sc(w, 12), sc(pw(w, 2), 20), sc(y, 3),
    sc(pmul(y, w), 64), sc(pmul(y, w, w), 20),
    sc(pw(y, 2), 17), sc(pmul(y, y, w), 64), sc(pw(y, 3), 17)
)
assert sc(det, 9) == cert211

# 8. Exceptional profile (1,1,1,1).
VV, UU, VU, VZ, UZ, ZZ = special(4, 4, 0)
cert1111 = add(
    C(9), sc(w, 105), sc(pw(w, 2), 200), sc(y, 69),
    sc(pmul(y, w), 355), sc(pw(y, 2), 146)
)
assert sc(add(pmul(UZ, UZ), sc(pmul(UU, ZZ), -1)), 36) == cert1111

# 9. Explicit cubic boundary.
p, s = X(2), X(3)
a = add(p, sc(s, -1))
L = add(sc(p, 2), sc(pmul(p, s), -1), C(-1))
T = add(sc(s, 7), sc(p, -6))
F = add(
    pmul(L, T),
    sc(pmul(a, pw(add(C(3), sc(s, -2)), 2)), -1)
)
explicit = add(
    sc(pmul(p, p, add(s, C(-2))), 6),
    sc(pmul(p, add(sc(pw(s, 2), 11), sc(s, -26), C(3))), -1),
    sc(pw(s, 3), 4), sc(pw(s, 2), -12), sc(s, 2)
)
assert F == explicit
assert all(a > 0 for row in rows.values() for a in row)
print("OCT20_SYMBOLIC_AUDIT_PASS", 9, 45)

