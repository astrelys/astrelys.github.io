from fractions import Fraction as Q
from math import comb
import json, time

def partitions(k, cap=None):
    if not k:
        yield (); return
    for j in range(min(k, k if cap is None else cap), 0, -1):
        for rest in partitions(k-j, j):
            yield (j,)+rest

def inertia(M):
    A=[[Q(v) for v in row] for row in M]; ans=[0,0,0]
    while A:
        n=len(A); pivot=next((i for i in range(n) if A[i][i]),None)
        if pivot is not None:
            order=[pivot]+[i for i in range(n) if i!=pivot]
            A=[[A[i][j] for j in order] for i in order]; a=A[0][0]
            ans[0 if a>0 else 1]+=1
            A=[[A[i][j]-A[i][0]*A[0][j]/a for j in range(1,n)] for i in range(1,n)]
        else:
            edge=next(((i,j) for i in range(n) for j in range(i+1,n) if A[i][j]),None)
            if edge is None:
                ans[2]+=n; break
            order=list(edge)+[i for i in range(n) if i not in edge]
            A=[[A[i][j] for j in order] for i in order]; a=A[0][1]
            ans[0]+=1;ans[1]+=1
            A=[[A[i][j]-(A[i][0]*A[1][j]+A[i][1]*A[0][j])/a for j in range(2,n)] for i in range(2,n)]
    return tuple(ans)

def coeff(g,M):
    r=sum(z>0 for z in g); u=g.count(1);v=g.count(2)
    return Q(M+2,3)*comb(r+1,3)-Q(M+3,4)*(r-1)*u-v

def hessian(b,M):
    return [[coeff(tuple(b[k]+(k==i)+(k==j) for k in range(len(b))),M)
             for j in range(len(b))] for i in range(len(b))]

start=time.monotonic(); profiles=0; polynomial_tests=0; boundary=[]
for M in range(2,9):
    for N in range(6,11):
        for n in range(1,M+3):
            positive=True
            for b in partitions(N-2):
                if len(b)>n: continue
                H=hessian(b+(0,)*(n-len(b)),M)
                profiles+=1
                if inertia(H)[0]>1: positive=False;break
            assert positive==(n<=M),(M,N,n)
            polynomial_tests+=1
for M in (2,3,4,10,57,100,10000):
    for q in sorted(set((1,max(1,M-3),max(1,M-2),M-1,M))):
        A=Q(2-M);B=Q(3-M,2);C=Q(5-M,4)-Q(M-1,4*q)
        det=A*C-B*B
        assert det==Q((M-1)*(M-2-q),4*q)
        assert inertia([[A,B],[B,C]])[0]==(q>M-2)
        boundary.append({'M':M,'q':q,'det':str(det),'inertia':inertia([[A,B],[B,C]])})
print(json.dumps({'status':'PRESCRIBED_CUTOFF_PASS','profiles':profiles,'polynomial_tests':polynomial_tests,
 'boundary':boundary,'seconds':time.monotonic()-start},indent=2))
