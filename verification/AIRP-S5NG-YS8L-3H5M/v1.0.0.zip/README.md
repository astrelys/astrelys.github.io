# Verification materials

A Degree-Independent Lorentzian Classification with Prescribed Variable Cutoffs
Version 1.0.0

Python 3, standard library only. Run the .py files from this folder without -O. The checks supplement the proofs in the manuscript.

Included files:
- classification_check.py
- cutoff_check.py
- identities_check.py
