from fractions import Fraction as Q
from math import comb

def parts(n, top=None):
    if n == 0:
        yield ()
        return
    if top is None:
        top = n
    for a in range(min(n, top), 0, -1):
        for b in parts(n-a, a):
            yield (a,) + b

def inertia(M):
    A = [[Q(x) for x in row] for row in M]
    pos = neg = zero = 0
    while A:
        n = len(A)
        i = next((i for i in range(n) if A[i][i]), None)
        if i is not None:
            order = [i] + [j for j in range(n) if j != i]
            A = [[A[j][k] for k in order] for j in order]
            pivot = A[0][0]
            pos += pivot > 0
            neg += pivot < 0
            A = [
                [A[j][k] - A[j][0]*A[0][k]/pivot
                 for k in range(1, n)]
                for j in range(1, n)
            ]
        else:
            pair = next(
                ((i, j) for i in range(n)
                 for j in range(i+1, n) if A[i][j]),
                None
            )
            if pair is None:
                zero += n
                break
            i, j = pair
            order = [i, j] + [k for k in range(n) if k not in pair]
            A = [[A[j][k] for k in order] for j in order]
            pivot = A[0][1]
            pos += 1
            neg += 1
            A = [
                [A[j][k] -
                 (A[j][0]*A[1][k] + A[j][1]*A[0][k])/pivot
                 for k in range(2, n)]
                for j in range(2, n)
            ]
    return pos, neg, zero

def coeff(g, p, s):
    r = sum(a > 0 for a in g)
    u = g.count(1)
    v = g.count(2)
    return p*comb(r+1, 3) - s*(r-1)*u - v

def data(beta, p, s):
    r = sum(a > 0 for a in beta)
    u = beta.count(1)
    v = beta.count(2)
    h = r-u-v
    K = p*comb(r+1, 3) - s*(r-1)*u - v
    A = s*(r-1)-1
    d = A-1
    E = p*(r+1)-2*s
    B = Q(r, 2)*E-s*u
    C = s*r-1
    delta = B+E-C
    return r, u, v, h, K, A, d, E, B, C, delta

def raw(beta, p, s):
    n = len(beta)
    H = []
    for i in range(n):
        row = []
        for j in range(n):
            g = list(beta)
            g[i] += 1
            g[j] += 1
            row.append(coeff(g, p, s))
        H.append(row)
    return H

def reduced(beta, p, s, qinf=False):
    r, u, v, h, K, A, d, E, B, C, delta = data(beta, p, s)
    q = beta.count(0)
    counts = (h, v, u, q)
    ids = [i for i, k in enumerate(counts) if k]
    M = [
        [K, K+1, K+A, K+B],
        [K+1, K+2-(1/Q(v) if v else 0), K+A+1, K+B+1],
        [K+A, K+A+1, K+2*A-(d/Q(u) if u else 0), K+B+C],
        [K+B, K+B+1, K+B+C,
         K+2*B+E-(delta/Q(q) if q and not qinf else 0)]
    ]
    small = [[M[i][j] for j in ids] for i in ids]
    ip, im, iz = inertia(small)
    for k, eigenvalue in ((h, 0), (v, -1), (u, -d), (q, -delta)):
        if k > 1:
            ip += (k-1)*(eigenvalue > 0)
            im += (k-1)*(eigenvalue < 0)
            iz += (k-1)*(eigenvalue == 0)
    return ip, im, iz

def admissible_uniform(p, s):
    if p == s == 1:
        return True
    if p <= s or s < 1 or 4*s > 3*p+1:
        return False
    L = 2*p-p*s-1
    T = 7*s-6*p
    return L <= 0 and T <= 0 and L*T-(p-s)*(3-2*s)**2 >= 0

params = (
    (Q(1), Q(1)),
    (Q(7, 4), Q(3, 2)),
    (Q(17, 10), Q(29, 20)),
    (Q(9, 5), Q(3, 2)),
    (Q(2), Q(3, 2)),
    (Q(2), Q(5, 3)),
    (Q(3), Q(2)),
    (Q(8), Q(65, 16)),
    (Q(20), Q(43, 5)),
)

entry_tests = inertia_tests = limit_tests = 0
for N in range(6, 17):
    for b0 in parts(N-2):
        for q in range(5):
            beta = b0 + (0,)*q
            n = len(beta)
            for p, s in params:
                assert admissible_uniform(p, s)
                H = raw(beta, p, s)
                r, u, v, h, K, A, d, E, B, C, delta = data(beta, p, s)
                for i in range(n):
                    for j in range(n):
                        x, y = beta[i], beta[j]
                        if x and y:
                            def inc(z):
                                return A if z == 1 else 1 if z == 2 else 0
                            if i == j:
                                e = K + (
                                    A+1 if x == 1 else 1 if x == 2 else 0
                                )
                            else:
                                e = K+inc(x)+inc(y)
                        elif x or y:
                            z = x or y
                            e = K+B+(C if z == 1 else 1 if z == 2 else 0)
                        else:
                            e = K+B+C if i == j else K+2*B+E
                        assert H[i][j] == e
                entry_tests += 1
                observed = inertia(H)
                assert observed == reduced(beta, p, s)
                assert observed[0] <= 1
                inertia_tests += 1
                if q == 1:
                    assert reduced(beta, p, s, True)[0] <= 1
                    limit_tests += 1

assert (entry_tests, inertia_tests, limit_tests) == (22545, 22545, 4509)
print("OCT20_MATRIX_AUDIT_PASS",
      entry_tests, inertia_tests, limit_tests)

p, s = Q(2), Q(17, 10)
for q in (1, 2, 54, 55, 56, 100):
    beta = (3, 1) + (0,)*q
    observed = reduced(beta, p, s)
    expected = (
        (1, q+1, 0) if q < 55 else
        (1, 55, 1) if q == 55 else
        (2, q, 0)
    )
    assert observed == expected
    L = 2*p-p*s-1
    T = 7*s-6*p
    a = p-s
    delta = 6*p-7*s+1
    determinant = L/a*(T-delta/q)-(3-2*s)**2
    assert determinant == Q(2*(55-q), 75*q)
print("DELAYED_OBSTRUCTION_PASS", 6)

points = []
for pn in range(5, 25):
    for sn in range(5, pn):
        p, s = Q(pn, 4), Q(sn, 4)
        if 4*s <= 3*p+1:
            points.append((p, s))

def prediction(n, p, s):
    a = p-s
    L = 2*p-p*s-1
    T = 7*s-6*p
    delta = 6*p-7*s+1
    q = n-2
    return (
        L <= 0 and T-delta/q <= 0 and
        L*(T-delta/q)-a*(3-2*s)**2 >= 0
    )

count = good = bad = 0
for p, s in points:
    for n in range(3, 9):
        predicted = prediction(n, p, s)
        for N in range(6, 13):
            observed = True
            for b0 in parts(N-2):
                if len(b0) > n:
                    continue
                beta = b0 + (0,)*(n-len(b0))
                if reduced(beta, p, s)[0] > 1:
                    observed = False
                    break
            assert observed == predicted, (n, N, p, s)
            count += 1
            good += predicted
            bad += not predicted

assert (len(points), count, good, bad) == (150, 6300, 4417, 1883)
print("FINITE_DIMENSION_CLASSIFICATION_PASS",
      len(points), count, good, bad)

