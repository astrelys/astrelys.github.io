# Planar matching under monotone pairwise angles

Astrée Iriart · AIRP-V3ZR-2MYB-U2ZZ · Manuscript v3.1.0

## Verification data and checks

This archive contains the manuscript's exact-arithmetic supplement: the
Fourier registration implementation, bounded tests, and exact witnesses.
It does not contain the manuscript's LaTeX source or research workspace.
The supplement files are unchanged from the manuscript edition.

Use Python 3.9 or newer, standard library only. See
[the supplement guide](supplements/README.md) for commands, input/output
contracts and the scope of the checks. The reference PDF is available
separately on the manuscript page.

The checks cover the documented finite instances and implementation tests;
they are not a formal verification of the general theorems. No new
redistribution license is introduced by this packaging.
