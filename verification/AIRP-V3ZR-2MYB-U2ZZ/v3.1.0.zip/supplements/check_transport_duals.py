"""Verify supplied strict tree-dual certificates using exact rational arithmetic.

This checker neither generates transport plans nor calls a hull, assignment,
linear-programming, or computer-algebra solver. It ignores descriptive status
fields in the input and derives its verdict from the numerical certificates.
"""
import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def rational(value):
    require(type(value) in (int, str), "exact entries must be integers or rational strings")
    return Fraction(value)


def vector(value, length, name):
    require(isinstance(value, list) and len(value) == length, name + " has wrong length")
    return [rational(x) for x in value]


def matrix(value, height, width, name):
    require(isinstance(value, list) and len(value) == height, name + " has wrong height")
    return [vector(row, width, name + " row") for row in value]


def verify(data):
    require(isinstance(data, dict), "top-level object required")
    rows_raw, cols_raw = data["rows"], data["cols"]
    require(isinstance(rows_raw, list) and isinstance(cols_raw, list), "marginal lists required")
    m, n = len(rows_raw), len(cols_raw)
    require(m > 0 and n > 0, "empty marginals")
    rows, cols = vector(rows_raw, m, "rows"), vector(cols_raw, n, "cols")
    require(all(x > 0 for x in rows + cols), "marginals must be positive")
    require(sum(rows) == sum(cols), "marginals have unequal total mass")
    a, b = matrix(data["A"], m, 2, "A"), matrix(data["B"], n, 2, "B")
    certificates = data["certificates"]
    require(isinstance(certificates, list) and len(certificates) > 0, "certificates required")
    distinct, reports = set(), []
    for index, item in enumerate(certificates):
        dx, dy = vector(item["direction"], 2, "direction")
        require(dx != 0 or dy != 0, "zero direction")
        plan = matrix(item["plan"], m, n, "plan")
        require(all(x >= 0 for row in plan for x in row), "negative flow")
        require([sum(row) for row in plan] == rows, "row marginal mismatch")
        require([sum(plan[i][j] for i in range(m)) for j in range(n)] == cols,
                "column marginal mismatch")
        row_dual = vector(item["row_dual"], m, "row_dual")
        col_dual = vector(item["column_dual"], n, "column_dual")
        supplied_slacks = matrix(item["slacks"], m, n, "slacks")
        weights = [[dx * (ax * bx + ay * by) + dy * (ax * by - ay * bx)
                    for bx, by in b] for ax, ay in a]
        slacks = [[row_dual[i] + col_dual[j] - weights[i][j]
                   for j in range(n)] for i in range(m)]
        require(slacks == supplied_slacks, "supplied slack mismatch")
        support = [(i, j) for i in range(m) for j in range(n) if plan[i][j] > 0]
        for i in range(m):
            for j in range(n):
                require(slacks[i][j] == 0 if plan[i][j] > 0 else slacks[i][j] > 0,
                        "strict complementary-slackness check failed")
        primal = sum(plan[i][j] * weights[i][j] for i in range(m) for j in range(n))
        dual = sum(rows[i] * row_dual[i] for i in range(m))
        dual += sum(cols[j] * col_dual[j] for j in range(n))
        require(primal == dual == rational(item["objective"]), "objective mismatch")

        # A connected acyclic bipartite support has full column rank after one
        # redundant marginal equation is removed. Hence its feasible flow is
        # unique. Strict off-support slacks force every optimum onto this tree.
        parent = list(range(m + n))

        def find(vertex):
            while parent[vertex] != vertex:
                vertex = parent[vertex]
            return vertex

        for i, j in support:
            left, right = find(i), find(m + j)
            require(left != right, "support contains a cycle")
            parent[left] = right
        require(len(support) == m + n - 1, "support is not a spanning tree")
        require(len({find(v) for v in range(m + n)}) == 1, "support is disconnected")
        key = tuple(tuple(row) for row in plan)
        require(key not in distinct, "duplicate plan")
        distinct.add(key)
        off_support = [slacks[i][j] for i in range(m) for j in range(n) if not plan[i][j]]
        reports.append({"index": index, "direction": [str(dx), str(dy)],
                        "objective": str(primal), "support_edges": len(support),
                        "minimum_off_support_slack": str(min(off_support)) if off_support else None,
                        "unique_optimum": True})
    require(m == n == 3 and len(distinct) == 9, "this supplied example must contain nine 3-by-3 plans")
    require(len(distinct) > n * (n - 1), "example does not exceed the equal-weight bound")
    return {"status": "NINE_STRICT_TREE_DUAL_CERTIFICATES_PASS", "distinct_plans": len(distinct),
            "rows": m, "columns": n, "total_mass": str(sum(rows)),
            "equal_weight_comparison_bound": n * (n - 1), "certificates": reports,
            "scope": "supplied rational primal/dual certificates only; no plan generation or envelope enumeration"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificates", nargs="?", default="transport-dual-certificates.json")
    parser.add_argument("--output", help="new JSON report path; an existing file is never overwritten")
    args = parser.parse_args()
    source = Path(args.certificates).read_bytes()
    report = verify(json.loads(source))
    report["input_sha256"] = hashlib.sha256(source).hexdigest()
    if args.output:
        with open(args.output, "x", encoding="utf-8") as stream:
            json.dump(report, stream, indent=2)
            stream.write("\n")
    print(json.dumps({key: report[key] for key in ("status", "distinct_plans", "input_sha256")}))


if __name__ == "__main__":
    main()
