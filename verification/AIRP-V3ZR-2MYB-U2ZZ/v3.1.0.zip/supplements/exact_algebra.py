"""Small exact real-algebraic kernel, standard library only.

Ascending rational polynomials; Sturm isolation; gcd equality; value resultants.
No floating-point arithmetic, numerical tolerance, or symbolic-radical heuristic.
"""
from fractions import Fraction as Q
from functools import lru_cache
from math import ceil

def poly(a):
    a=list(map(Q,a))
    while a and a[-1]==0: a.pop()
    return tuple(a)
def add(a,b): return poly([(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])
def neg(a): return tuple(-x for x in a)
def sub(a,b): return add(a,neg(b))
def scale(a,c): return poly([c*x for x in a])
def mul(a,b):
    c=[Q(0)]*max(0,len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): c[i+j]+=x*y
    return poly(c)
def divrem(a,b):
    if not b: raise ZeroDivisionError('zero polynomial')
    r=list(a);q=[Q(0)]*max(0,len(a)-len(b)+1)
    while r and len(r)>=len(b):
        k=len(r)-len(b);v=r[-1]/b[-1];q[k]=v
        for j,x in enumerate(b): r[k+j]-=v*x
        r=list(poly(r))
    return poly(q),poly(r)
def monic(a): return scale(a,1/a[-1]) if a else ()
def gcd(a,b):
    while b: a,b=b,divrem(a,b)[1]
    return monic(a)
def derivative(a): return poly([i*a[i] for i in range(1,len(a))])
def sqfree(a): return monic(divrem(a,gcd(a,derivative(a)))[0]) if len(a)>1 else monic(a)
def evaluate(a,x):
    v=Q(0)
    for c in reversed(a): v=v*x+c
    return v
@lru_cache(maxsize=None)
def sturm(a):
    seq=[a,derivative(a)]
    while seq[-1]:
        r=neg(divrem(seq[-2],seq[-1])[1])
        if not r: break
        # Only positive normalization preserves Sturm signs.
        seq.append(scale(r,1/abs(r[-1])))
    return tuple(p for p in seq if p)
def variations(a,x):
    signs=[1 if v>0 else -1 for p in sturm(a) if (v:=evaluate(p,x))!=0]
    return sum(a!=b for a,b in zip(signs,signs[1:]))
def count(a,lo,hi):
    if len(a)<=1 or lo>=hi:return 0
    if evaluate(a,lo)==0 or evaluate(a,hi)==0: raise ValueError('root at count boundary')
    return variations(a,lo)-variations(a,hi)

class Real:
    def __init__(self,p,lo,hi):
        self.p=monic(p);self.lo=Q(lo);self.hi=Q(hi)
        if self.lo==self.hi:
            if evaluate(self.p,self.lo)!=0:raise ValueError('incorrect rational root')
        elif count(self.p,self.lo,self.hi)!=1:raise ValueError('interval must isolate one root')
    @classmethod
    def rational(cls,q):
        q=Q(q);return cls((-q,Q(1)),q,q)
    def refine(self):
        if self.lo==self.hi:return
        mid=(self.lo+self.hi)/2
        if evaluate(self.p,mid)==0:self.lo=self.hi=mid
        elif count(self.p,self.lo,mid):self.hi=mid
        else:self.lo=mid
    def certificate(self):
        return {'polynomial_ascending':[str(c) for c in self.p],
                'isolating_interval':[str(self.lo),str(self.hi)]}

def roots(p):
    p=sqfree(poly(p))
    if len(p)<=1:return []
    if len(p)==2:return [Real.rational(-p[0]/p[1])]
    bound=Q(2+ceil(max(abs(c/p[-1]) for c in p[:-1])))
    todo=[(-bound,bound)];out=[]
    while todo:
        lo,hi=todo.pop();n=count(p,lo,hi)
        if not n:continue
        if n==1:out.append(Real(p,lo,hi));continue
        k=1;cut=(lo+hi)/2
        while evaluate(p,cut)==0:
            k+=1;cut=(k*lo+hi)/(k+1)
        todo.extend([(cut,hi),(lo,cut)])
    return sorted(out,key=lambda r:r.lo)

def compare(a,b):
    """Exact trichotomy, including equal values represented by different polys."""
    common=gcd(a.p,b.p)
    while True:
        if a.hi<b.lo:return -1
        if b.hi<a.lo:return 1
        if a.lo==a.hi:
            if b.lo<=a.lo<=b.hi and evaluate(b.p,a.lo)==0:return 0
            b.refine();continue
        if b.lo==b.hi:
            if a.lo<=b.lo<=a.hi and evaluate(a.p,b.lo)==0:return 0
            a.refine();continue
        lo=max(a.lo,b.lo);hi=min(a.hi,b.hi)
        if lo<hi and len(common)>1 and count(common,lo,hi):return 0
        if a.hi-a.lo>=b.hi-b.lo:a.refine()
        else:b.refine()

def determinant(a):
    a=[list(map(Q,row)) for row in a];n=len(a);det=Q(1)
    for i in range(n):
        pivot=next((j for j in range(i,n) if a[j][i]),None)
        if pivot is None:return Q(0)
        if pivot!=i:a[i],a[pivot]=a[pivot],a[i];det=-det
        v=a[i][i];det*=v
        for j in range(i+1,n):
            if a[j][i]:
                c=a[j][i]/v
                for k in range(i,n):a[j][k]-=c*a[i][k]
    return det
def resultant(a,b):
    a=poly(a);b=poly(b)
    if not a or not b:return Q(0)
    m=len(a)-1;n=len(b)-1
    if m==0:return a[0]**n
    if n==0:return b[0]**m
    rows=[]
    for i in range(n):rows.append([Q(0)]*i+list(reversed(a))+[Q(0)]*(n-1-i))
    for i in range(m):rows.append([Q(0)]*i+list(reversed(b))+[Q(0)]*(m-1-i))
    return determinant(rows)
def value_polynomial(p,num,den):
    # p monic: specialization where degree(num-u*den) drops is safe.
    p=monic(p)
    if len(gcd(p,den))>1:raise ValueError('remove denominator factors before resultant')
    out=();d=len(p)-1
    for i in range(d+1):
        value=resultant(p,sub(num,scale(den,Q(i))));basis=(Q(1),);divisor=Q(1)
        for j in range(d+1):
            if i!=j:basis=mul(basis,(-Q(j),Q(1)));divisor*=i-j
        out=add(out,scale(basis,value/divisor))
    if not out:raise ValueError('zero value resultant')
    return sqfree(out)

def imul(a,b):
    vals=[x*y for x in a for y in b];return min(vals),max(vals)
def ieval(p,interval):
    v=(Q(0),Q(0))
    for c in reversed(p):v=imul(v,interval);v=(v[0]+c,v[1]+c)
    return v
def image(root,num,den):
    if root.lo==root.hi:return Real.rational(evaluate(num,root.lo)/evaluate(den,root.lo))
    p=value_polynomial(root.p,num,den);values=roots(p)
    while True:
        if root.lo==root.hi:return Real.rational(evaluate(num,root.lo)/evaluate(den,root.lo))
        n=ieval(num,(root.lo,root.hi));d=ieval(den,(root.lo,root.hi))
        if d[0]>0:
            enclosure=imul(n,(1/d[1],1/d[0]))
            possible=[r for r in values if not(r.hi<enclosure[0] or r.lo>enclosure[1])]
            if len(possible)==1:return possible[0]
            if not possible:raise AssertionError('lost algebraic image')
        root.refine()
        for r in values:r.refine()
