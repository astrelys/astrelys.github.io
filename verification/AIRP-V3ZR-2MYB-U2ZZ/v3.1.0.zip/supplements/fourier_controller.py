"""Exact registration for checked rational Fourier target trajectories.

Reuses the shared algebraic/charge/controller components unchanged; the motion
contract is now checked pairwise angle monotonicity, not convex Hamiltonian flow.
"""
from fractions import Fraction as Q
from math import gcd
import argparse
import json
import controller as BASE
import fourier_geometry as G
from phase_optimizer import minimize_registration

E=BASE.E

def choose_charts(a,data,budget):
    for k in range(2*budget+1):
        z=Q(k);den=1+z*z;seam=((1-z*z)/den,2*z/den)
        tests=G.make_charts(data,[seam,tuple(-x for x in seam)])
        regular=[BASE.L.regularity(a,ch['curves'],ch['den'],Q(0)) for ch in tests]
        if all(r['regular'] for r in regular):
            cp,sp=seam
            return G.make_charts(data,[(-sp,cp),(sp,-cp)]),{
                'direction':[str(x) for x in seam],'circle_parameter':str(z),
                'candidates_tested':k+1,'policies':[list(r['point']) for r in regular]}
    raise AssertionError('regular-seam bound failed')

def effective_thresholds(a,charts):
    n=len(a);degree=(len(charts[0]['den'])-1)//2
    d0=Q(1);speed=Q(1);separations=[]
    for i in range(n):
        for j in range(i+1,n):
            differences=[]
            for ch in charts:
                dx,dy=[E.sub(ch['curves'][j][k],ch['curves'][i][k]) for k in range(2)]
                differences.append({'curves':[(dx,dy)],'den':ch['den'],'center':ch['center']})
                bound=sum(sum(abs(c) for c in E.sub(E.mul(E.derivative(p),ch['den']),
                                                    E.mul(p,E.derivative(ch['den'])))) for p in (dx,dy))
                speed=max(speed,bound)
            value=minimize_registration([(0,0)],differences,[(0,)])['selected']['value']
            if E.compare(value,E.Real.rational(0))<=0:raise ValueError('pair separation is not positive')
            while value.lo<=0:value.refine()
            d0=min(d0,value.lo)
            separations.append({'pair':[i,j],'squared_minimum':value.certificate(),
                                'positive_rational_lower_bound':str(value.lo)})
    eta=d0/(4*speed)
    coefficients=[q for ch in charts for row in BASE.L.coefficient_polynomials(a,ch['curves'])
                  for vector in row for polynomial in vector for q in polynomial]
    denominator=1
    for q in coefficients:denominator=denominator*q.denominator//gcd(denominator,q.denominator)
    height=max([1]+[abs(int(q*denominator)) for q in coefficients])
    h=(2*n*height-1).bit_length();m=4*degree
    b=2*h+(2*degree).bit_length()+1;k=b+2*m+2
    exponent=m*m*(k+2)+2;delta=Q(1,1<<exponent)
    return min(eta,delta),{'eta':str(eta),'separation_lower_bound':str(d0),
        'pair_speed_upper_bound':str(speed),'delta_exponent':exponent,
        'degree':degree,'integer_entry_height':str(height),'common_denominator':str(denominator),
        'pair_separation_certificates':separations}

def exact_json(x):
    if isinstance(x,Q):return str(x)
    if isinstance(x,dict):return {k:exact_json(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [exact_json(v) for v in x]
    return x

def solve(a,data,translation=False,max_nodes=None):
    a=BASE.points(a)
    if not isinstance(translation,bool):raise ValueError('translation must be Boolean')
    if max_nodes is not None and (not isinstance(max_nodes,int) or isinstance(max_nodes,bool) or max_nodes<1):
        raise ValueError('max_nodes must be a positive integer or None')
    base_charts=G.make_charts(data)
    if len(a)!=len(base_charts[0]['curves']):raise ValueError('equal source/target sizes required')
    geometry=G.certify_geometry(base_charts)
    budget=geometry['total_charge']
    charts,seam=choose_charts(a,data,budget)
    threshold,bounds=effective_thresholds(a,charts)
    stats={'charge_queries':0,'regularity_queries':0,'dual_attempts':0,'max_depth':0}
    events=[];cells=[];trees=[]
    for index,ch in enumerate(charts):
        ev,ce,tree=BASE.isolate_chart(a,ch,index,threshold,budget,stats,max_nodes=max_nodes)
        events.extend(ev);cells.extend(ce);trees.append(tree)
    if sum(t['root_charge'] for t in trees)!=budget:raise AssertionError('full-period charge mismatch')
    reps=sorted(set(ce['permutation'] for ce in cells))
    if len(reps)>max(1,budget):raise AssertionError('representative bound failed')
    optimization=minimize_registration(a,charts,reps,translation=translation)
    encoded={'status':'COMPLETE_EXACT_WITH_CHECKED_PAIRWISE_GEOMETRY',
        'input':{'a':exact_json(a),'fourier_targets':exact_json(data)},'geometry':geometry,
        'seam':seam,'bounds':bounds,'statistics':stats,'representatives':[list(p) for p in reps],
        'charts':[{'center':exact_json(ch['center']),'den':exact_json(ch['den']),
                   'curves':exact_json(ch['curves'])} for ch in charts],
        'events':[BASE.encode_event(e) for e in events],
        'cells':[{'chart_index':ce['chart_index'],'lower':ce['lower'].certificate(),
                  'upper':ce['upper'].certificate(),'permutation':list(ce['permutation'])} for ce in cells],
        'charge_trees':trees,'optimization':optimization['json'],
        'scope':'Geometry checked exactly; correctness relies on the local pairwise-angle theorem and shared algebra kernel. No Hamiltonian or convex-domain promise. Original-value representative cover only.'}
    return {'charts':charts,'events':events,'cells':cells,'representatives':reps,
            'optimization':optimization,'statistics':stats,'json':encoded}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input');parser.add_argument('--translation',action='store_true')
    parser.add_argument('--max-nodes',type=int,default=None)
    args=parser.parse_args()
    with open(args.input) as stream:data=json.load(stream)
    result=solve(data['a'],data['fourier_targets'],args.translation,args.max_nodes)
    print(json.dumps(result['json'],indent=2,sort_keys=True))

if __name__=='__main__':main()
