"""Exact bounded tests for hull/general-terminal energy/area path theorems.

Standard library only; no random search.  All simple paths are enumerated.
Lambda lies in (-3/n,3/n), strictly inside (-tan(pi/n),tan(pi/n)).
The output is evidence for these fixtures, not a proof of the general theorem.
"""
from fractions import Fraction as Q
from functools import cmp_to_key
from itertools import combinations, permutations
import json


def sub(a, b):
    return (a[0] - b[0], a[1] - b[1])


def cross(a, b):
    return a[0] * b[1] - a[1] * b[0]


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1]


def orient(a, b, c):
    return cross(sub(b, a), sub(c, a))


def on_segment(p, a, b):
    return orient(a, b, p) == 0 and dot(sub(p, a), sub(p, b)) <= 0


def area2(poly):
    return sum(cross(a, b) for a, b in zip(poly, poly[1:] + poly[:1]))


def inside(p, poly):
    """Return -1 outside, 0 on boundary, 1 inside, with exact ray tests."""
    flag = False
    for a, b in zip(poly, poly[1:] + poly[:1]):
        if on_segment(p, a, b):
            return 0
        if (a[1] > p[1]) != (b[1] > p[1]):
            x = a[0] + Q(p[1] - a[1], b[1] - a[1]) * (b[0] - a[0])
            if x > p[0]:
                flag = not flag
    return 1 if flag else -1


def hull_indices(points):
    order = sorted(range(len(points)), key=points.__getitem__)
    lower, upper = [], []
    for seq, out in ((order, lower), (list(reversed(order)), upper)):
        for i in seq:
            while len(out) >= 2 and orient(points[out[-2]], points[out[-1]], points[i]) <= 0:
                out.pop()
            out.append(i)
    return lower[:-1] + upper[:-1]


def boundary_count(points, hull):
    return sum(any(on_segment(p, points[a], points[b])
                   for a, b in zip(hull, hull[1:] + hull[:1])) for p in points)


def coefficients(points, path):
    e = sum(dot(sub(points[j], points[i]), sub(points[j], points[i]))
            for i, j in zip(path, path[1:]))
    a = sum(cross(points[i], points[j]) for i, j in zip(path, path[1:]))
    return e, a


def all_paths(points, s, t):
    middle = [i for i in range(len(points)) if i not in (s, t)]
    return [(s,) + p + (t,) for k in range(len(middle) + 1)
            for p in permutations(middle, k)]


def exact_envelope(points, s, t, limit):
    paths = all_paths(points, s, t)
    lines = [coefficients(points, p) for p in paths]
    winners = []
    comparisons = 0
    for idx, ((e, a), path) in enumerate(zip(lines, paths)):
        lo, hi = -limit, limit
        viable = True
        for j, (other_e, other_a) in enumerate(lines):
            if j == idx:
                continue
            comparisons += 1
            de, da = e - other_e, a - other_a
            if da > 0:
                lo = max(lo, Q(de, 2 * da))
            elif da < 0:
                hi = min(hi, Q(de, 2 * da))
            elif de >= 0:
                viable = False
                break
            if lo >= hi:
                viable = False
                break
        if not viable:
            continue
        lam = (lo + hi) / 2
        value = e - 2 * lam * a
        gap = min(oe - 2 * lam * oa - value for j, (oe, oa) in enumerate(lines)
                  if j != idx)
        assert gap > 0
        margins = []
        for i, j in zip(path, path[1:]):
            d = sub(points[j], points[i])
            center = ((points[i][0] + points[j][0] + lam * d[1]) / 2,
                      (points[i][1] + points[j][1] - lam * d[0]) / 2)
            radius2 = (1 + lam * lam) * dot(d, d) / 4
            for k in range(len(points)):
                if k in (i, j):
                    continue
                pk = points[k]
                margin = dot(sub(pk, points[i]), sub(pk, points[j])) + lam * cross(d, sub(pk, points[i]))
                assert margin == dot(sub(pk, center), sub(pk, center)) - radius2
                assert margin > 0, (path, lam, i, j, k, margin)
                # Affinity plus a positive interior value certifies strict
                # emptiness throughout this path's entire open winner cell.
                alpha = dot(sub(pk, points[i]), sub(pk, points[j]))
                beta = cross(d, sub(pk, points[i]))
                assert alpha + lo * beta >= 0 and alpha + hi * beta >= 0
                # Insertion difference is exactly twice the shifted-disk margin.
                ei, ai = coefficients(points, (i, k, j))
                ej, aj = coefficients(points, (i, j))
                assert (ei - 2 * lam * ai) - (ej - 2 * lam * aj) == 2 * margin
                margins.append(margin)
        winners.append(dict(path=path, E=e, A=a, interval=(lo, hi), witness=lam,
                            minimum_score_gap=gap, minimum_disk_margin=min(margins)))
    winners.sort(key=lambda z: z['witness'])
    return winners, len(paths), comparisons


def verify_cycles(points, limit):
    """Test every directed simple cycle at both closed subrange endpoints."""
    count = 0
    margin = None
    for k in range(2, len(points) + 1):
        for subset in combinations(range(len(points)), k):
            for rest in permutations(subset[1:]):
                cycle = (subset[0],) + rest + (subset[0],)
                e, a = coefficients(points, cycle)
                v = e - 2 * limit * abs(a)
                assert v > 0, (cycle, e, a, limit)
                count += 1
                margin = v if margin is None else min(margin, v)
    return count, margin


def exterior_arc(points, hull, s, t):
    """Counterclockwise outside-hull t-to-s arc; exact radial expansion."""
    n = len(points)
    center = (sum(p[0] for p in points) / n, sum(p[1] for p in points) / n)
    expanded = {i: (center[0] + 4 * (points[i][0] - center[0]),
                    center[1] + 4 * (points[i][1] - center[1])) for i in hull}
    arc = [points[t], expanded[t]]
    j = hull.index(t)
    while hull[j] != s:
        j = (j + 1) % len(hull)
        arc.append(expanded[hull[j]])
    return arc + [points[s]]


def angle_cmp(a, b):
    ha = 0 if a[1] > 0 or (a[1] == 0 and a[0] > 0) else 1
    hb = 0 if b[1] > 0 or (b[1] == 0 and b[0] > 0) else 1
    if ha != hb:
        return ha - hb
    c = cross(a, b)
    return -1 if c > 0 else 1 if c < 0 else 0


def planar_faces(edges, with_incidence=False):
    neighbors = {}
    for a, b in edges:
        neighbors.setdefault(a, set()).add(b)
        neighbors.setdefault(b, set()).add(a)
    for a in neighbors:
        neighbors[a] = sorted(neighbors[a], key=cmp_to_key(
            lambda b, c: angle_cmp(sub(b, a), sub(c, a))))
    seen, faces, left_face = set(), [], {}
    for start in [(a, b) for a, ns in neighbors.items() for b in ns]:
        if start in seen:
            continue
        edge, poly, boundary = start, [], []
        while edge not in seen:
            seen.add(edge)
            boundary.append(edge)
            a, b = edge
            poly.append(a)
            ns = neighbors[b]
            edge = (b, ns[(ns.index(a) - 1) % len(ns)])
        assert edge == start
        face_index = len(faces) if area2(poly) > 0 else -1
        for edge in boundary:
            left_face[edge] = face_index
        if face_index >= 0:
            faces.append(poly)
    return (faces, left_face) if with_incidence else faces


def face_sample(poly, edges):
    for a, b in zip(poly, poly[1:] + poly[:1]):
        d = sub(b, a)
        mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
        for k in range(4, 100):
            eps = Q(1, 2 ** k)
            p = (mid[0] - eps * d[1], mid[1] + eps * d[0])
            if inside(p, poly) == 1 and not any(on_segment(p, c, e) for c, e in edges):
                return p
    raise AssertionError('No exact face-interior witness found')


def nested_regions(points, hull, s, t, winners):
    if not winners:
        return []
    arc = exterior_arc(points, hull, s, t)
    regions = [[points[i] for i in w['path']] + arc[1:-1] for w in winners]
    assert all(area2(poly) > 0 for poly in regions)
    edges = set()
    for poly in regions:
        for a, b in zip(poly, poly[1:] + poly[:1]):
            edges.add(tuple(sorted((a, b))))
    edges = sorted(edges)
    for (a, b), (c, d) in combinations(edges, 2):
        # Crossing or interior touching would invalidate the fixed planar graph.
        if not set((a, b)) & set((c, d)):
            assert not (orient(a, b, c) * orient(a, b, d) < 0 and
                        orient(c, d, a) * orient(c, d, b) < 0)
            assert not any((on_segment(c, a, b), on_segment(d, a, b),
                            on_segment(a, c, d), on_segment(b, c, d)))
    faces = planar_faces(edges)
    samples = [face_sample(face, edges) for face in faces]
    masks = [{i for i, sample in enumerate(samples) if inside(sample, poly) == 1}
             for poly in regions]
    assert all(old < new for old, new in zip(masks, masks[1:])), (s, t, masks)
    increments = []
    for i, (poly, mask) in enumerate(zip(regions, masks)):
        assert area2(poly) == sum(area2(faces[j]) for j in mask)
        if i:
            increment = Q(area2(poly) - area2(regions[i - 1]), 2)
            assert increment == Q(winners[i]['A'] - winners[i - 1]['A'], 2)
            increments.append(increment)
    return increments


def winding(p, walk):
    """Signed winding of a possibly nonsimple closed polygonal walk."""
    result = 0
    for a, b in zip(walk, walk[1:] + walk[:1]):
        assert not on_segment(p, a, b)
        if a[1] <= p[1] < b[1] and orient(a, b, p) > 0:
            result += 1
        elif b[1] <= p[1] < a[1] and orient(a, b, p) < 0:
            result -= 1
    return result


def check_face_potentials(points, winners, full_face_bound):
    """Reference-relative circulation winding, checked against edge incidence.

    The union of all uniquely optimal paths is a fixed plane subgraph of a
    Delaunay triangulation.  Its face potentials pull back constantly to any
    triangulation refinement, so checking these faces also checks all refined
    face coordinates.  The outer face has potential zero.
    """
    if not winners:
        return dict(face_count=0, potentials=[], transitions=0)
    paths = [[points[i] for i in w['path']] for w in winners]
    reference_index = len(paths) // 2
    reference = paths[reference_index]
    edges = sorted({tuple(sorted((a, b))) for path in paths
                    for a, b in zip(path, path[1:])})
    for (a, b), (c, d) in combinations(edges, 2):
        if not set((a, b)) & set((c, d)):
            assert not (orient(a, b, c) * orient(a, b, d) < 0 and
                        orient(c, d, a) * orient(c, d, b) < 0)
            assert not any((on_segment(c, a, b), on_segment(d, a, b),
                            on_segment(a, c, d), on_segment(b, c, d)))
    faces, left = planar_faces(edges, with_incidence=True)
    samples = [face_sample(face, edges) for face in faces]
    assert len(faces) <= full_face_bound
    potentials = []
    reference_area = winners[reference_index]['A']
    for winner, path in zip(winners, paths):
        # path ends at t; reversed reference starts at t and returns to s.
        closed_walk = path + list(reversed(reference))[1:]
        psi = tuple(winding(sample, closed_walk) for sample in samples)
        assert all(abs(value) <= 2 * full_face_bound for value in psi)
        flow = {edge: 0 for edge in edges}
        for walk, multiplier in ((path, 1), (reference, -1)):
            for a, b in zip(walk, walk[1:]):
                edge = tuple(sorted((a, b)))
                flow[edge] += multiplier * (1 if edge == (a, b) else -1)
        for a, b in edges:
            l, r = left[(a, b)], left[(b, a)]
            potential_difference = (psi[l] if l >= 0 else 0) - (psi[r] if r >= 0 else 0)
            assert flow[(a, b)] == potential_difference
        assert winner['A'] - reference_area == sum(area2(face) * value
                                                   for face, value in zip(faces, psi))
        potentials.append(psi)
    for earlier, later in zip(potentials, potentials[1:]):
        assert all(x <= y for x, y in zip(earlier, later)), potentials
        assert earlier != later, potentials
    return dict(face_count=len(faces), reference_path=winners[reference_index]['path'],
                rational_face_samples=samples,
                face_areas=[Q(area2(face), 2) for face in faces],
                potentials=potentials, transitions=max(0, len(winners) - 1))


FIXTURES = {
    'triangle': [(-2, 0), (2, 0), (0, 3)],
    'convex_diamond': [(-2, 0), (0, -3), (2, 0), (0, 3)],
    'convex_pentagon': [(-4, 0), (-2, -3), (3, -2), (4, 2), (-1, 4)],
    'convex_hexagon': [(-4, 0), (-2, -3), (2, -3), (4, 0), (2, 4), (-2, 3)],
    'triangle_two_inside': [(0, 0), (8, 0), (1, 7), (2, 2), (4, 1)],
    'triangle_three_inside': [(0, 0), (8, 0), (1, 7), (2, 2), (4, 1), (2, 4)],
    'quadrilateral_two_inside': [(-4, 0), (0, -4), (4, 0), (0, 4), (-1, 0), (1, 1)],
}


INTERIOR_FIXTURES = {
    **{name: FIXTURES[name] for name in ('triangle_two_inside',
                                       'triangle_three_inside',
                                       'quadrilateral_two_inside')},
    # Deliberate fixed constructions, not outputs of a random search.
    'interior_triangle_switch': [(-10, -10), (10, -10), (0, 10),
                                 (-2, 0), (2, 0), (0, 3)],
    'interior_diamond_switch': [(-3, 0), (0, -3), (3, 0), (0, 3),
                                (-2, 0), (2, 0)],
}


def interior_checks():
    cases = []
    total_paths = total_comparisons = total_winners = total_transitions = 0
    for name, data in INTERIOR_FIXTURES.items():
        points = [tuple(map(Q, p)) for p in data]
        n = len(points)
        hull = hull_indices(points)
        h = boundary_count(points, hull)
        full_faces = 2 * n - h - 2
        count_bound = 4 * full_faces * full_faces + 1
        limit = Q(3, n)
        cycle_count, cycle_margin = verify_cycles(points, limit)
        interior = [i for i, p in enumerate(points) if inside(p, [points[j] for j in hull]) == 1]
        for s, t in permutations(interior, 2):
            winners, paths, comparisons = exact_envelope(points, s, t, limit)
            assert len(winners) <= count_bound
            potential_certificate = check_face_potentials(points, winners, full_faces)
            total_paths += paths
            total_comparisons += comparisons
            total_winners += len(winners)
            total_transitions += potential_certificate['transitions']
            cases.append(dict(fixture=name, terminals=(s, t), n=n, h=h,
                              full_triangulation_faces=full_faces, count_bound=count_bound,
                              count=len(winners), directed_cycles_checked=cycle_count,
                              minimum_cycle_margin=cycle_margin,
                              potential_certificate=potential_certificate, winners=winners))
    assert total_transitions >= 6  # Ensure the monotonicity check is nonvacuous.
    return dict(case_count=len(cases), path_instances=total_paths,
                dominance_comparisons=total_comparisons,
                unique_witnesses=total_winners, monotone_transitions=total_transitions,
                cases=cases)


def main():
    reports = []
    total_paths = total_comparisons = total_winners = 0
    saturation = None
    for name, data in FIXTURES.items():
        points = [tuple(map(Q, p)) for p in data]
        n = len(points)
        hull = hull_indices(points)
        h = boundary_count(points, hull)
        limit = Q(3, n)
        bound = 2 * n - h - 1
        cycles, cycle_margin = verify_cycles(points, limit)
        cases = []
        for s, t in combinations(hull, 2):
            winners, paths, comparisons = exact_envelope(points, s, t, limit)
            assert len(winners) <= bound, (name, s, t, winners, bound)
            increments = nested_regions(points, hull, s, t, winners)
            total_paths += paths
            total_comparisons += comparisons
            total_winners += len(winners)
            cases.append(dict(terminals=(s, t), count=len(winners),
                              area_increments=increments))
            if name == 'convex_diamond' and (s, t) == (0, 2):
                assert len(winners) == bound == 3
                assert [w['path'] for w in winners] == [(0, 3, 2), (0, 2), (0, 1, 2)]
                saturation = dict(points=data, terminals=(s, t), bound=bound,
                                  lambda_limit=limit, winners=winners)
        reports.append(dict(fixture=name, n=n, h=h, bound=bound,
                            maximum_count=max(c['count'] for c in cases),
                            directed_cycles_checked=cycles,
                            minimum_cycle_margin=cycle_margin, cases=cases))
    assert saturation is not None
    interior = interior_checks()
    print(json.dumps(dict(status='EXACT_HULL_AND_INTERIOR_PATH_CHECK_PASS',
                          path_instances=total_paths,
                          dominance_comparisons=total_comparisons,
                          unique_witnesses=total_winners,
                          fixture_reports=reports,
                          saturation_certificate=saturation,
                          interior_report=interior),
                     indent=2, default=str))


if __name__ == '__main__':
    main()
