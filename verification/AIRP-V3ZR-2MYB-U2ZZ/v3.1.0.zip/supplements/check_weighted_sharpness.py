"""Portable exact checks for the all-size parabolic-fan construction.

No search, randomness, network, or dependency on the prior test suites.
The accompanying proof, not these finite checks, establishes the all-N claim.
"""
from fractions import Fraction as Q
from itertools import combinations, permutations
import json


def cross(a, b):
    return a[0] * b[1] - a[1] * b[0]


def coefficients(points, path):
    energy = area = 0
    for i, j in zip(path, path[1:]):
        a, b = points[i], points[j]
        energy += (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2
        area += cross(a, b)
    return energy, area


def construction(n):
    assert n >= 2
    m = 32 * n * n
    xs = [0] + [m + i for i in range(1, n)]
    points = [(x, x * x) for x in xs]
    limit = 3 * (m + n)
    boundaries = {0: Q(limit), n - 1: Q(-limit)}
    for k in range(1, n - 1):
        x = xs[k]
        boundaries[k] = -Q(2 * x * x + x + 1, x + 1)
    paths = {k: (0,) + tuple(range(k, n)) for k in range(1, n)}
    return points, m, limit, boundaries, paths


def verify(n):
    points, m, limit, boundaries, fan_paths = construction(n)
    xs = [p[0] for p in points]
    assert all(boundaries[k] < boundaries[k - 1] for k in range(1, n))
    for i in range(1, n - 1):
        a, b = xs[i:i + 2]
        for j, x in enumerate(xs):
            if j not in (0, i, i + 1):
                assert x * (x - a) * (x - b) * (x + a + b) > 0
    for a, b, c in combinations(points, 3):
        assert cross((b[0] - a[0], b[1] - a[1]),
                     (c[0] - a[0], c[1] - a[1])) != 0

    paths = [(0,) + middle + (n - 1,)
             for k in range(n - 1)
             for middle in permutations(range(1, n - 1), k)]
    lines = {path: coefficients(points, path) for path in paths}
    strict_comparisons = 0
    certificates = []
    for k, path in fan_paths.items():
        lo, hi = boundaries[k], boundaries[k - 1]
        lam = (lo + hi) / 2
        e, a = lines[path]
        value = e - 2 * lam * a
        gaps = [oe - 2 * lam * oa - value for other, (oe, oa) in lines.items()
                if other != path]
        assert all(g > 0 for g in gaps)
        strict_comparisons += len(gaps)
        disk_margins = []
        for i, j in zip(path, path[1:]):
            pi, pj = points[i], points[j]
            d = (pj[0] - pi[0], pj[1] - pi[1])
            for h, ph in enumerate(points):
                if h in (i, j):
                    continue
                u, v = (ph[0] - pi[0], ph[1] - pi[1]), (ph[0] - pj[0], ph[1] - pj[1])
                margin = u[0] * v[0] + u[1] * v[1] + lam * cross(d, u)
                assert margin > 0
                disk_margins.append(margin)
        certificates.append(dict(k=k, path=path, interval=(lo, hi), witness=lam,
                                 minimum_score_gap=min(gaps) if gaps else None,
                                 minimum_disk_margin=min(disk_margins) if disk_margins else None))

    tie_comparisons = 0
    for k in range(1, n - 1):
        lam = boundaries[k]
        values = {path: e - 2 * lam * a for path, (e, a) in lines.items()}
        minimum = min(values.values())
        assert {path for path, value in values.items() if value == minimum} == {
            fan_paths[k], fan_paths[k + 1]}
        tie_comparisons += len(values)
        ek, ak = lines[fan_paths[k]]
        en, an = lines[fan_paths[k + 1]]
        assert ek - en == 2 * lam * (ak - an)
        assert ak - an == xs[k] * xs[k + 1]

    cycles = 0
    cycle_margin = None
    for k in range(2, n + 1):
        for subset in combinations(range(n), k):
            for rest in permutations(subset[1:]):
                cycle = (subset[0],) + rest + (subset[0],)
                e, a = coefficients(points, cycle)
                cubes = sum((xs[j] - xs[i]) ** 3 for i, j in zip(cycle, cycle[1:]))
                assert 3 * a == -cubes
                margin = e - 2 * limit * abs(a)
                assert margin > 0
                cycle_margin = margin if cycle_margin is None else min(cycle_margin, margin)
                cycles += 1
    return dict(n=n, M=m, L=limit, simple_paths=len(paths),
                distinct_unique_paths=n - 1, switches=n - 2,
                strict_comparisons=strict_comparisons,
                exact_tie_comparisons=tie_comparisons,
                simple_directed_cycles=cycles,
                minimum_closed_interval_cycle_margin=cycle_margin,
                certificates=certificates)


def main():
    reports = [verify(n) for n in range(2, 8)]
    print(json.dumps(dict(status='PARABOLIC_FAN_FORMULA_CHECK_PASS', reports=reports),
                     indent=2, default=str))


if __name__ == '__main__':
    main()
