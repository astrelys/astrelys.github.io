"""Bounded end-to-end Fourier controller tests, with small factorial references.

The reference shares the exact algebra kernel and the phase optimizer, so this
is not an independent CAS check. Open-cell policies/roots are independently
enumerated without Hungarian or charge calls. No point-only tie enumeration.
"""
from contextlib import contextmanager
from fractions import Fraction as Q
from itertools import permutations
import json
import signal
import time
import unittest

import exact_algebra as E
import exhaustive_reference as R
import fourier_controller as F
from phase_optimizer import minimize_registration
from test_fourier_geometry import ORIGIN, target, circle, breathing


@contextmanager
def bounded(seconds=30):
    def expired(signum, frame):
        raise TimeoutError('bounded fixture exceeded %d seconds' % seconds)
    previous = signal.signal(signal.SIGALRM, expired)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous)


def same_real(left, right):
    return E.compare(left, right) == 0


class FourierControllerTests(unittest.TestCase):
    def check_fixture(self, name, a, data, winding, translation=False,
                      expected_value=None, full_policy_reference=True):
        started = time.monotonic()
        with bounded():
            result = F.solve(a, data, translation=translation, max_nodes=128)
            json.dumps(result['json'])
            geometry = result['json']['geometry']
            self.assertEqual(geometry['W'], winding)
            self.assertEqual(sum(event['charge'] for event in result['events']), 2*winding)
            self.assertLessEqual(len(result['representatives']), max(1, 2*winding))
            if full_policy_reference:
                reference = R.inspect(a, result['charts'])
                self.assertEqual(set(result['representatives']), reference['representatives'])
                actual_events, reference_events = result['events'], reference['events']
                self.assertEqual(len(actual_events), len(reference_events))
                for actual, ref in zip(actual_events, reference_events):
                    self.assertEqual(actual['chart_index'], ref['chart_index'])
                    self.assertTrue(same_real(actual['root'], ref['root']))
                    self.assertEqual(actual['left_assignment'], ref['left_assignment'])
                    self.assertEqual(actual['right_assignment'], ref['right_assignment'])
                # Every reference rational sample belongs to one returned open
                # cell, and that cell has exactly the independent policy.
                for chart_reference in reference['charts']:
                    ci = chart_reference['chart_index']
                    for sample in chart_reference['cells']:
                        point = E.Real.rational(sample['sample'])
                        cells = [cell for cell in result['cells']
                                 if cell['chart_index'] == ci
                                 and E.compare(cell['lower'], point) < 0
                                 and E.compare(point, cell['upper']) < 0]
                        self.assertEqual(len(cells), 1)
                        self.assertEqual(cells[0]['permutation'], sample['assignment'])
            # All permutations, not merely the controller's selected policies.
            exhaustive = minimize_registration(a, result['charts'],
                                               permutations(range(len(a))),
                                               translation=translation)
            value = result['optimization']['selected']['value']
            self.assertTrue(same_real(value, exhaustive['selected']['value']))
            if expected_value is not None:
                self.assertTrue(same_real(value, E.Real.rational(expected_value)))
        print('EVIDENCE '+json.dumps({'fixture': name, 'status': 'PASS',
              'n': len(a), 'W': winding, 'events': len(result['events']),
              'representatives': len(result['representatives']),
              'methods': sorted(set(e['method'] for e in result['events'])),
              'statistics': result['statistics'],
              'translation': translation, 'seconds': round(time.monotonic()-started, 3),
              'reference_scope': 'shared-kernel exact all-permutation objective; '
                                 + ('independent factorial open-cell policies/roots' if full_policy_reference
                                    else 'no full policy reference')}, sort_keys=True), flush=True)
        return result

    def test_01_stationary_zero_winding(self):
        self.check_fixture('stationary_w0', [(0, 0), (2, 0)],
                           [target(), target(xc=[2])], 0, expected_value=0)

    def test_02_n1_moving_target(self):
        self.check_fixture('n1_circle', [(1, 0)], [circle()], 0, expected_value=0)

    def test_03_n1_translation(self):
        self.check_fixture('n1_translation', [(5, -3)],
                           [target(xc=[0, 2], ys=[0, -3])], 0,
                           translation=True, expected_value=0)

    def test_04_n2_clockwise(self):
        self.check_fixture('n2_clockwise', [(0, 0), (1, 0)],
                           [ORIGIN, circle()], 1, expected_value=0)

    def test_05_n2_angular_stalls(self):
        self.check_fixture('n2_angular_stalls', [(0, 0), (0, 1)],
                           [ORIGIN, target(xc=[0, 1], ys=[0, Q(-3, 4), 0, Q(1, 4)])],
                           1, expected_value=0)

    def test_06_n2_multiple_turns(self):
        self.check_fixture('n2_three_turns', [(0, 0), (1, 0)],
                           [ORIGIN, circle(3)], 3, expected_value=0)

    def test_07_n3_deforming(self):
        self.check_fixture('n3_deforming', [(0, 0), (1, 0), (2, 1)],
                           [ORIGIN, circle(),
                            target(xc=[0, 2, Q(1, 10)], ys=[0, -3, Q(1, 10)])], 3)

    def test_08_partial_duplicate_sources(self):
        self.check_fixture('partial_duplicate_sources', [(0, 0), (0, 0), (2, 0)],
                           [ORIGIN, circle(), target(xc=[0, 2], ys=[0, -2])], 3,
                           expected_value=1)

    def test_09_all_zero_sources(self):
        result = self.check_fixture('all_zero_sources', [(0, 0)]*3,
                                    [ORIGIN, circle(), target(xc=[0, 2], ys=[0, -2])],
                                    3, expected_value=5)
        self.assertEqual([event['charge'] for event in result['events']], [3, 3])

    def test_10_n2_translation(self):
        self.check_fixture('n2_translation', [(2, 3), (3, 3)],
                           [ORIGIN, circle()], 1, translation=True, expected_value=0)

    def test_11_breathing_nonhamiltonian_n4(self):
        a = [(Q(1), Q(0)), (Q(0), Q(1)), (Q(-1), Q(0)), (Q(0), Q(-1))]
        self.check_fixture('breathing_nonhamiltonian_n4', a, breathing(a), 6,
                           expected_value=0, full_policy_reference=False)

    def test_12_input_and_geometry_rejection(self):
        with bounded():
            for data in ([ORIGIN, ORIGIN], [ORIGIN, circle(clockwise=False)],
                         [ORIGIN, target(xc=[0, 1])]):
                with self.assertRaises(ValueError):
                    F.solve([(0, 0), (1, 0)], data)
            with self.assertRaises(ValueError):
                F.solve([(0, 0)], [ORIGIN, circle()])
            with self.assertRaises(ValueError):
                F.solve([(0, 0)], [ORIGIN], translation=1)
            with self.assertRaises(ValueError):
                F.solve([(0, 0)], [ORIGIN], max_nodes=0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
