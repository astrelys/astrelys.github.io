"""Exact lexicographic endpoint and germ adapter, not a full kinetic solver."""
from fractions import Fraction as Q
from math import gcd, comb
import charge_oracle as C

def lex_assignment(vectors):
    n=len(vectors); k=len(vectors[0][0]); denominator=1
    for row in vectors:
        for v in row:
            assert len(v)==k
            for x in v:
                denominator=denominator*Q(x).denominator//gcd(denominator,Q(x).denominator)
    ints=[[[int(Q(x)*denominator) for x in v] for v in row] for row in vectors]
    bound=max([1]+[abs(x) for row in ints for v in row for x in v])
    base=2*n*bound+2
    weights=[]
    for row in ints:
        out=[]
        for v in row:
            value=0
            for x in v:value=base*value+x
            out.append(value)
        weights.append(out)
    return C.hungarian(weights)

def point_vectors(a,b):
    n=len(a)
    if len(set(b))!=n:raise ValueError('distinct targets required')
    out=[]
    for i,(ax,ay) in enumerate(a):
        row=[]
        for bx,by in b:
            v=[Q(ax)*bx+Q(ay)*by]+[Q(0)]*(2*n)
            v[1+2*i]=bx;v[2+2*i]=by;row.append(v)
        out.append(row)
    return out

def canonical_assignment(a,b):
    return lex_assignment(point_vectors(a,b))

def coefficient_polynomials(a,curves):
    n=len(a);out=[]
    for i,(ax,ay) in enumerate(a):
        row=[]
        for x,y in curves:
            v=[C.add(C.scale(x,Q(ax)),C.scale(y,Q(ay)))]+[()]*(2*n)
            v[1+2*i]=x;v[2+2*i]=y;row.append(v)
        out.append(row)
    return out

def germ_vectors(a,curves,z,side):
    assert side in (-1,1)
    v=coefficient_polynomials(a,curves)
    degree=max(len(p) for row in v for cell in row for p in cell)-1
    def jet(p):
        return [sum(p[j]*comb(j,k)*z**(j-k) for j in range(k,len(p)))*side**k for k in range(degree+1)]
    return [[[x for p in cell for x in jet(p)] for cell in row] for row in v]

def regularity(a,curves,den,z):
    left=lex_assignment(germ_vectors(a,curves,z,-1))
    point=canonical_assignment(a,C.positions(curves,den,z))
    right=lex_assignment(germ_vectors(a,curves,z,1))
    return {'left':left,'point':point,'right':right,'regular':left==point==right}

def charge(a,curves,den,lo,hi):
    return C.interval_charge(a,curves,den,lo,hi,canonical_assignment)
