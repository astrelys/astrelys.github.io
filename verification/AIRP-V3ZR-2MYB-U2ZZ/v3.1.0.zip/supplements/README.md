# Exact-arithmetic supplement

Python 3.9 or newer, standard library only. Run from this directory:

    python3 -B fourier_controller.py example-fourier.json
    python3 -B -m unittest test_fourier_geometry test_fourier_controller -v
    python3 -B check_dimension.py
    python3 -B check_weighted_paths.py
    python3 -B check_weighted_sharpness.py
    python3 -B check_transport_duals.py transport-dual-certificates.json

The first command reproduces example-result.json, a nonlinear three-point
fixture with total clockwise pair winding 3 and charge budget 6. Its complete
algebraic output is provided to make the input/output format inspectable.

The Fourier suite has 18 geometry and 12 controller tests. The separate
factorial reference is deliberately limited to at most three targets and
shares the algebraic kernel. Objective comparisons use the same phase
optimizer applied to all permutations. These are bounded implementation
checks, not formal proof verification or independent CAS verification.
The dimension checker verifies thirteen rational strict witnesses and a
full-dimensional perturbation. The transport file is an exact dual witness
for nine plans and was retained from the preceding edition.
The weighted-path checker enumerates bounded fixtures with hull and interior
terminals, checking tilted disks, exact face potentials and their nesting.
It does not test all multi-defect flows or prove the general count.
The parabolic-fan checker generates the explicit all-size construction and
checks its formulas for sizes two through seven against complete-graph paths
and cycles. The all-size theorem rests on the written proof, not these tests.
The finite-real-amplitude theorem is proved analytically; no exhaustive
real-margin or capacity-binding solver is supplied.

## Solver input

fourier_controller.py INPUT.json [--translation] accepts an object with
a (a nonempty list of rational planar source points) and fourier_targets
(one Fourier target object per source). Each target has x and y objects;
each coordinate may contain cos and sin coefficient arrays indexed from
harmonic zero. Missing arrays are zero. The zeroth sine coefficient must
be zero. Use integers or rational strings such as "1/3", never floats or
Booleans. Coefficients are dense; arbitrarily large sparse harmonic indices
are not a small input for the complexity theorem.

The solver constructs two exact rational charts, checks all pair collisions
and angle signs, computes winding, and then performs canonical-cell
enumeration and global original-energy optimization. The output contains
rational polynomial/root-isolator certificates, open-cell representatives,
and algebraic phase coordinates and energy. The real angle is not asserted
to be algebraic. Repeated sources and persistent original ties are allowed;
colliding targets or positive pairwise angular velocity are rejected.

The optional positive integer --max-nodes is a user safety cap; exceeding
it aborts rather than returns a complete answer. Without it the exact
fallback follows the mathematical construction, whose conservative root
separation depth can be impractical. Sufficient dual and unit-charge early
stops improve the bounded tests. The script controller.py supplies shared
controller components and an older polynomial-shear entry point; use
fourier_controller.py for the checked geometric contract.

The implementation outputs an original-value cover, not all tied
permutations, every original optimal face, or every point-only canonical
policy. Generic real-arithmetic speed and large-degree engineering have not
been benchmarked. Proof validity and priority remain separate from tests.

The specialized rigid support-polygon algorithm and the common-metric
quartic algorithm are proved in the manuscript but have no dedicated
implementation in this package. The Fourier entry point does not accept an
anisotropic residual metric. With --translation, its convention is to shift
the sources: a_i + tau is matched to b_pi(i), with
tau = mean(b) - mean(a) at the selected phase.
