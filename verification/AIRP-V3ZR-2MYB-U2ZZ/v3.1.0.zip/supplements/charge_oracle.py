"""Exact interval-charge prototype; not the full kinetic solver.

Rational dense polynomial shears, finite half-angle intervals. All decisions
use Fraction/Sturm. Convex-flow hypotheses are promises, not inferred from tests.
"""
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
import importlib.util
import hashlib

KERNEL = Path(__file__).with_name('exact_algebra.py')
spec = importlib.util.spec_from_file_location('interval_exact_algebra', KERNEL)
E = importlib.util.module_from_spec(spec)
spec.loader.exec_module(E)
poly,add,sub,mul,scale,ev = E.poly,E.add,E.sub,E.mul,E.scale,E.evaluate

def power(p,k):
    out=poly([1])
    for _ in range(k): out=mul(out,p)
    return out

def trajectories(c,coeff,epsilon):
    coeff=poly(coeff);epsilon=Q(epsilon);d=max(1,len(coeff)-1)
    q=poly([1,0,1]);den=power(q,d);out=[]
    for cx,cy in c:
        cx,cy=Q(cx),Q(cy)
        u=poly([cx,2*cy,-cx]);v=poly([cy,-2*cx,-cy])
        x=mul(u,power(q,d-1));y=mul(v,power(q,d-1))
        for k,pk in enumerate(coeff):
            y=add(y,scale(mul(power(u,k),power(q,d-k)),epsilon*pk))
        out.append((x,y))
    return out,den

def positions(curves,den,t):
    return [(ev(x,t)/ev(den,t),ev(y,t)/ev(den,t)) for x,y in curves]

def hungarian(w):
    n=len(w);u=[Q(0)]*(n+1);v=u.copy();p=[0]*(n+1);way=p.copy()
    for i in range(1,n+1):
        p[0]=i;j0=0;minv=[None]*(n+1);used=[False]*(n+1)
        while True:
            used[j0]=True;i0=p[j0];delta=None;j1=0
            for j in range(1,n+1):
                if used[j]: continue
                cur=-w[i0-1][j-1]-u[i0]-v[j]
                if minv[j] is None or cur<minv[j]: minv[j]=cur;way[j]=j0
                if delta is None or minv[j]<delta: delta=minv[j];j1=j
            for j in range(n+1):
                if used[j]: u[p[j]]+=delta;v[j]-=delta
                elif j and minv[j] is not None: minv[j]-=delta
            j0=j1
            if not p[j0]: break
        while True:
            j1=way[j0];p[j0]=p[j1];j0=j1
            if not j0: break
    ans=[0]*n
    for j in range(1,n+1): ans[p[j]-1]=j-1
    return tuple(ans)

def unique_assignment(a,b):
    n=len(a)
    w=[[Q(x)*xx+Q(y)*yy for xx,yy in b] for x,y in a]
    ans=hungarian(w);best=sum(w[i][j] for i,j in enumerate(ans))
    # Any different matching omits one of ans's edges. A finite sentinel below
    # every genuine assignment total implements edge prohibition exactly.
    bound=max([Q(1)]+[abs(x) for row in w for x in row])
    for i,j in enumerate(ans):
        if n==1: break
        copy=[row[:] for row in w];copy[i][j]=-(2*n+1)*bound
        other=hungarian(copy)
        if sum(copy[k][l] for k,l in enumerate(other))==best:
            raise ValueError('endpoint has no unique optimum')
    return ans

def square_complex(x,y):
    return sub(mul(x,x),mul(y,y)),scale(mul(x,y),2)

def real_sign_at(root,p):
    while True:
        if root.lo==root.hi:
            value=ev(p,root.lo)
            if not value: raise ValueError('curve meets zero / unsuitable ray')
            return 1 if value>0 else -1
        lo,hi=E.ieval(p,(root.lo,root.hi))
        if lo>0:return 1
        if hi<0:return -1
        root.refine()

def ray_crossings(p,q,lo,hi,ray):
    """Signed crossings of positive (1+i*ray) ray, no endpoints on its line."""
    p,q=add(p,scale(q,ray)),sub(q,scale(p,ray))
    if not ev(q,lo) or not ev(q,hi):raise ValueError('endpoint on ray line')
    common=E.gcd(p,q)
    if len(common)>1 and E.count(common,lo,hi):raise ValueError('curve crosses zero')
    total=0;record=[]
    for r in E.roots(q):
        if E.compare(r,E.Real.rational(lo))<=0 or E.compare(r,E.Real.rational(hi))>=0:continue
        while r.lo<=lo or r.hi>=hi:r.refine()
        sign_real=real_sign_at(r,p)
        if r.lo==r.hi:
            k=0;dq=q
            while not ev(dq,r.lo):k+=1;dq=E.derivative(dq)
            direction=(1 if ev(dq,r.lo)>0 else -1) if k%2 else 0
        else:
            left=ev(q,r.lo);right=ev(q,r.hi)
            direction=((1 if right>0 else -1)-(1 if left>0 else -1))//2
        contribution=direction if sign_real>0 else 0
        total+=contribution
        record.append({'root':r.certificate(),'direction':direction,'ray_side':sign_real,'contribution':contribution})
    return total,record

def interval_charge(a,curves,den,left,right,assignment=unique_assignment):
    left,right=Q(left),Q(right)
    if not left<right:raise ValueError('finite increasing chart interval required')
    b0,b1=positions(curves,den,left),positions(curves,den,right)
    p0,p1=assignment(a,b0),assignment(a,b1)
    y0,y1=[b0[j] for j in p0],[b1[j] for j in p1]
    physical=[];chords=[];endvalues=[]
    for i,j in combinations(range(len(a)),2):
        physical.append(square_complex(sub(curves[j][0],curves[i][0]),sub(curves[j][1],curves[i][1])))
        dx0,dy0=y0[j][0]-y0[i][0],y0[j][1]-y0[i][1]
        dx1,dy1=y1[j][0]-y1[i][0],y1[j][1]-y1[i][1]
        chords.append(square_complex(poly([dx0,dx1-dx0]),poly([dy0,dy1-dy0])))
        for p,q in physical[-1:]:endvalues.extend([(ev(p,left),ev(q,left)),(ev(p,right),ev(q,right))])
    ray=next(k for k in range(len(endvalues)+1) if all(y-k*x for x,y in endvalues))
    pc=[];cc=[]
    for p,q in physical:
        value,record=ray_crossings(p,q,left,right,ray);pc.append({'count':value,'crossings':record})
    for p,q in chords:
        value,record=ray_crossings(p,q,Q(0),Q(1),ray);cc.append({'count':value,'crossings':record})
    result=sum(r['count'] for r in cc)-sum(r['count'] for r in pc)
    if result<0:raise ValueError('negative charge: hypotheses or implementation fail')
    return {'charge':result,'left_assignment':p0,'right_assignment':p1,'ray_slope':ray,
            'physical_factors':pc,'chord_factors':cc,'kernel_sha256':hashlib.sha256(KERNEL.read_bytes()).hexdigest()}
