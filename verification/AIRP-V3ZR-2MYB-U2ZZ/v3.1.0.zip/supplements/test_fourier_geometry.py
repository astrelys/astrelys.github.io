"""Small exact tests for Fourier geometry; no assignment enumeration or floats."""
from fractions import Fraction as Q
import copy
import json
import unittest
import fourier_geometry as F


def target(xc=(), xs=(), yc=(), ys=()):
    return {'x': {'cos': list(xc), 'sin': list(xs)},
            'y': {'cos': list(yc), 'sin': list(ys)}}


ORIGIN = target()


def circle(k=1, clockwise=True):
    return target(xc=[0]*k+[1], ys=[0]*k+[-1 if clockwise else 1])


def breathing(data, epsilon=Q(4, 5)):
    # b(t)=(1+epsilon*cos t) R(-t) p; divergence 2*r'/r is not zero.
    return [target(xc=[epsilon*x/2, x, epsilon*x/2], xs=[0, y, epsilon*y/2],
                   yc=[epsilon*y/2, y, epsilon*y/2], ys=[0, -x, -epsilon*x/2])
            for x, y in data]


def direct_position(data, center, z):
    # Independent rational complex recurrence, not the polynomial chart builder.
    cp, sp = map(Q, center)
    q = 1+z*z
    c, s = cp*(1-z*z)/q-sp*2*z/q, sp*(1-z*z)/q+cp*2*z/q
    out = []
    for item in data:
        xy = []
        for key in ('x', 'y'):
            co, si = item[key].get('cos', []), item[key].get('sin', [])
            ck, sk, value = Q(1), Q(0), Q(0)
            for k in range(max(len(co), len(si))):
                value += (Q(co[k]) if k < len(co) else 0)*ck
                value += (Q(si[k]) if k < len(si) else 0)*sk
                ck, sk = ck*c-sk*s, sk*c+ck*s
            xy.append(value)
        out.append(tuple(xy))
    return out


class FourierGeometryTests(unittest.TestCase):
    def certify(self, data, centers=F.DEFAULT_CENTERS):
        charts = F.make_charts(data, centers)
        cert = F.certify_geometry(charts)
        json.dumps(cert)  # certificate must be transportable without custom encoding
        self.assertTrue(cert['seam_first_derivatives_match'])
        return charts, cert

    def test_stationary_zero_winding(self):
        _, cert = self.certify([target(xc=[1], yc=[2]), target(xc=[3], yc=[-1])])
        self.assertEqual((cert['W'], cert['total_charge'], cert['max_representatives']), (0, 0, 1))

    def test_stationary_angle_radial_motion(self):
        _, cert = self.certify([ORIGIN, target(xc=[2, 1])])
        self.assertEqual(cert['W'], 0)

    def test_clockwise_circle(self):
        _, cert = self.certify([ORIGIN, circle()])
        self.assertEqual((cert['W'], cert['total_charge']), (1, 2))

    def test_three_turn_circle(self):
        _, cert = self.certify([ORIGIN, circle(3)])
        self.assertEqual((cert['W'], cert['total_charge']), (3, 6))

    def test_ellipse(self):
        _, cert = self.certify([ORIGIN, target(xc=[0, 2], ys=[0, -3])])
        self.assertEqual(cert['W'], 1)

    def test_monotone_with_stationary_angle_and_multiple_ray_root(self):
        # y=-sin(t)^3: det=-sin(t)^2*(3*cos(t)^2+sin(t)^2).
        # The angular stalls are interior roots, not excluded by strictness.
        _, cert = self.certify([ORIGIN, target(xc=[0, 1],
                                              ys=[0, Q(-3, 4), 0, Q(1, 4)])],
                               ((1, 0), (-1, 0)))
        self.assertEqual(cert['W'], 1)

    def test_deforming_three_targets(self):
        _, cert = self.certify([ORIGIN, circle(),
                               target(xc=[0, 2, Q(1, 10)], ys=[0, -3, Q(1, 10)])])
        self.assertEqual((len(cert['pair_certificates']), cert['W']), (3, 3))

    def test_breathing_nonhamiltonian_four_targets(self):
        data = breathing([(Q(1), Q(0)), (Q(0), Q(1)),
                          (Q(-1), Q(0)), (Q(0), Q(-1))])
        _, cert = self.certify(data)
        self.assertEqual((cert['W'], cert['total_charge']), (6, 12))
        # At cos t=-4/5, sin t=3/5, the vectors J*b'_i violate the
        # cyclic monotonicity necessary for gradients of a convex Hamiltonian.
        charts = F.make_charts(data, ((Q(-4, 5), Q(3, 5)), (Q(4, 5), Q(-3, 5))))
        ch = charts[0]
        p = [F._position(c, ch['den'], Q(0)) for c in ch['curves']]
        v = [F._velocity(c, ch['den'], Q(0)) for c in ch['curves']]
        gradient = [(-y, x) for x, y in v]
        cycle = [0, 3, 2, 1, 0]
        circulation = sum(gradient[i][0]*(p[j][0]-p[i][0])
                          + gradient[i][1]*(p[j][1]-p[i][1])
                          for i, j in zip(cycle, cycle[1:]))
        self.assertGreater(circulation, 0)

    def test_custom_centers_and_fourier_recurrence(self):
        centers = ((Q(3, 5), Q(4, 5)), (Q(-3, 5), Q(-4, 5)))
        data = [target(xc=['2/3', -1, 0, '4/7'], xs=[0, 2, '1/5'],
                       yc=[-2, 1], ys=[0, '1/3', -1, 2])]
        charts = F.make_charts(data, centers)
        self.assertEqual(charts[0]['den'], F.poly([1, 0, 3, 0, 3, 0, 1]))
        for ch in charts:
            for z in (Q(-1), Q(-1, 2), Q(0), Q(2, 3), Q(1)):
                actual = [F._position(c, ch['den'], z) for c in ch['curves']]
                self.assertEqual(actual, direct_position(data, ch['center'], z))
        _, cert = self.certify([ORIGIN, circle(3)], centers)
        self.assertEqual(cert['W'], 3)

    def test_single_target_vacuous_pair_condition(self):
        _, cert = self.certify([circle(clockwise=False)])
        self.assertEqual((cert['W'], cert['pair_certificates']), (0, []))

    def test_counterclockwise_rejected(self):
        with self.assertRaisesRegex(ValueError, 'not nonincreasing'):
            self.certify([ORIGIN, circle(clockwise=False)])

    def test_interior_collision_rejected(self):
        with self.assertRaisesRegex(ValueError, 'collision'):
            self.certify([ORIGIN, target(xc=[0, 1])])

    def test_seam_collision_rejected(self):
        with self.assertRaisesRegex(ValueError, 'collision'):
            self.certify([ORIGIN, target(xc=[1, -1], ys=[0, -1])])

    def test_identical_targets_rejected(self):
        with self.assertRaisesRegex(ValueError, 'colliding'):
            self.certify([ORIGIN, ORIGIN])

    def test_nonmonotonic_winding_one_rejected(self):
        data = [ORIGIN, target(xc=[0, 1, Q(3, 4)], ys=[0, -1, Q(-3, 4)])]
        # Put the angular reversal at the interior of a chart, with negative
        # endpoint determinants: the root-cell test must detect it.
        charts = F.make_charts(data, ((1, 0), (-1, 0)))
        # Independent crossing count shows winding one alone is insufficient.
        ccw = sum(F.C.ray_crossings(ch['curves'][1][0], ch['curves'][1][1],
                                   Q(-1), Q(1), 1)[0] for ch in charts)
        self.assertEqual(ccw, -1)
        with self.assertRaisesRegex(ValueError, 'not nonincreasing'):
            F.certify_geometry(charts)

    def test_denominator_zero_rejected(self):
        charts = F.make_charts([ORIGIN, circle()])
        charts[0]['den'] = F.poly([0, 0, 1])
        with self.assertRaisesRegex(ValueError, 'denominator'):
            F.certify_geometry(charts)

    def test_seam_mismatch_rejected(self):
        charts = copy.deepcopy(F.make_charts([ORIGIN, circle()]))
        curves = list(charts[1]['curves'])
        curves[1] = (F.add(curves[1][0], charts[1]['den']), curves[1][1])
        charts[1]['curves'] = curves
        with self.assertRaisesRegex(ValueError, 'seam positions'):
            F.certify_geometry(charts)

    def test_invalid_input_rejected(self):
        for bad in (target(xc=[0.1]), target(xc=[True]), target(xs=[1])):
            with self.assertRaises(ValueError):
                F.make_charts([bad])
        with self.assertRaisesRegex(ValueError, 'unit'):
            F.make_charts([ORIGIN], ((1, 1), (-1, -1)))
        with self.assertRaisesRegex(ValueError, 'antipodal'):
            F.make_charts([ORIGIN], ((1, 0), (0, 1)))


if __name__ == '__main__':
    unittest.main(verbosity=2)
