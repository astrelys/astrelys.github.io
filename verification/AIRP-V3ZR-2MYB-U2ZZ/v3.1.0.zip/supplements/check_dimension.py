"""Exact 13-matching fixed-axis 3D certificate.

Verification uses only integer/Fraction arithmetic.
"""
from itertools import permutations
from fractions import Fraction
import json


A = [(-3,0,-2),(-1,0,2),(1,0,2),(3,0,0)]
B = [(-20,-6,-5),(40,-8,-1),(-20,-10,-2),(-40,-2,3)]
# One-based permutation, cosine numerator, sine numerator, denominator,
# exact minimum score-gap numerator against the other 23 permutations.
CERTIFICATE = [
    ((4,3,1,2),153,104,185,200),
    ((1,4,3,2),3,-4,5,8),
    ((3,4,1,2),3,4,5,4),
    ((1,3,4,2),21,220,221,892),
    ((3,2,4,1),0,1,1,8),
    ((2,3,4,1),-11,60,61,56),
    ((2,3,1,4),-255,32,257,256),
    ((2,1,3,4),-3,-4,5,6),
    ((2,1,4,3),-7,-24,25,88),
    ((2,4,1,3),-11,-60,61,40),
    ((1,2,4,3),-15,-112,113,160),
    ((1,4,2,3),0,-1,1,6),
    ((4,1,3,2),323,-36,325,288),
]


def triples(a, b):
    result = []
    for perm in permutations(range(len(a))):
        aa = sum(a[i][0]*b[j][0]+a[i][1]*b[j][1] for i,j in enumerate(perm))
        bb = sum(-a[i][1]*b[j][0]+a[i][0]*b[j][1] for i,j in enumerate(perm))
        cc = sum(a[i][2]*b[j][2] for i,j in enumerate(perm))
        result.append((perm, aa, bb, cc))
    return result


def direct_costs(a,b,c,s,den,translation=False):
    rotated=[(Fraction(c*x-s*y,den),Fraction(s*x+c*y,den),Fraction(z))
             for x,y,z in a]
    shift=[Fraction(0)]*3
    if translation:
        shift=[sum(Fraction(p[k]) for p in b)/len(b)
               -sum(p[k] for p in rotated)/len(a) for k in range(3)]
    return {perm:sum((rotated[i][k]+shift[k]-b[j][k])**2
                     for i,j in enumerate(perm) for k in range(3))
            for perm in permutations(range(len(a)))}


def verify():
    data=triples(A,B)
    assert len({row[0] for row in CERTIFICATE})==13
    minimum=None
    for label,c,s,den,expected_gap in CERTIFICATE:
        assert den>0 and c*c+s*s==den*den
        perm=tuple(i-1 for i in label)
        scores={p:aa*c+bb*s+cc*den for p,aa,bb,cc in data}
        gap=scores[perm]-max(v for p,v in scores.items() if p!=perm)
        assert gap==expected_gap and gap>0
        for translated in (False,True):
            costs=direct_costs(A,B,c,s,den,translated)
            cost_gap=min(v for p,v in costs.items() if p!=perm)-costs[perm]
            assert cost_gap==Fraction(2*gap,den)
        score_gap=Fraction(gap,den)
        minimum=score_gap if minimum is None else min(minimum,score_gap)
    assert minimum==Fraction(40,61)
    perturbed=list(A)
    perturbed[0]=(-3,Fraction(1,200),-2)
    for label,c,s,den,_ in CERTIFICATE:
        perm=tuple(i-1 for i in label)
        costs=direct_costs(perturbed,B,c,s,den,True)
        assert all(costs[perm]<v for p,v in costs.items() if p!=perm)
    assert minimum-Fraction(88,200)==Fraction(329,1525)>0
    print(json.dumps({
        'status':'EXACT_CERTIFICATE_PASS', 'n':4,
        'certified_distinct_unique_permutations':13,
        'planar_bound':12, 'integer_score_comparisons':13*23,
        'minimum_score_gap':str(minimum),
        'direct_squared_cost_and_optimal_translation_checked':True,
        'full_dimensional_rational_perturbation_checked':True,
        'perturbation_uniform_score_gap_lower_bound':'329/1525',
        'scope':'At least 13; no complete count, asymptotic lower bound, or novelty claim.'
    },indent=2))



if __name__=='__main__':
    verify()
