"""Small-n exhaustive reference for lexicographic polynomial matching cells.

This intentionally factorial reference does not call a Hungarian solver,
interval-charge oracle, or controller certificate. It shares exact_algebra's
root isolation and comparisons with the implementation under test.
"""
from fractions import Fraction as Q
from functools import cmp_to_key
from itertools import combinations, permutations
import exact_algebra as E


def coefficient_scores(a, curves, permutation):
    """Primary correlation followed by independent source-coordinate scores."""
    primary = ()
    for (ax, ay), j in zip(a, permutation):
        x, y = curves[j]
        primary = E.add(primary, E.add(E.scale(x, Q(ax)), E.scale(y, Q(ay))))
    result = [primary]
    for j in permutation:
        result.extend((curves[j][0], curves[j][1]))
    return tuple(result)


def union_roots(polynomials, lower=Q(-1), upper=Q(1)):
    """All distinct real roots in the open chart, without numeric tolerances."""
    left, right = E.Real.rational(lower), E.Real.rational(upper)
    candidates = []
    for polynomial in polynomials:
        for root in E.roots(polynomial):
            if E.compare(root, left) > 0 and E.compare(root, right) < 0:
                candidates.append(root)
    candidates.sort(key=cmp_to_key(E.compare))
    result = []
    for root in candidates:
        if not result or E.compare(result[-1], root) != 0:
            result.append(root)
    return result


def rational_between(left, right):
    if E.compare(left, right) >= 0:
        raise ValueError("distinct increasing cell boundaries required")
    while left.hi >= right.lo:
        left.refine()
        right.refine()
    return (left.hi + right.lo) / 2


def inspect_chart(a, chart, chart_index=0):
    n = len(a)
    if not 1 <= n <= 3:
        raise ValueError("this bounded exhaustive reference accepts only 1 <= n <= 3")
    curves = tuple(tuple(E.poly(axis) for axis in point) for point in chart["curves"])
    den = E.poly(chart["den"])
    all_permutations = tuple(permutations(range(n)))
    scores = {p: coefficient_scores(a, curves, p) for p in all_permutations}
    polynomials = set()
    nonzero_differences = 0
    for left, right in combinations(all_permutations, 2):
        for p, q in zip(scores[left], scores[right]):
            difference = E.sub(p, q)
            if difference:
                nonzero_differences += 1
                polynomials.add(E.monic(difference))
    roots = union_roots(sorted(polynomials))
    cuts = [E.Real.rational(-1)] + roots + [E.Real.rational(1)]
    cells = []
    for left, right in zip(cuts, cuts[1:]):
        witness = rational_between(left, right)
        if E.evaluate(den, witness) <= 0:
            raise ValueError("reference requires a positive chart denominator")
        values = {p: tuple(E.evaluate(poly, witness) for poly in scores[p])
                  for p in all_permutations}
        best = max(values.values())
        winners = [p for p in all_permutations if values[p] == best]
        if len(winners) != 1:
            raise ValueError("coefficient-vector policy is not unique on an open cell")
        cells.append({"sample": witness, "assignment": winners[0]})
    events = []
    for index, (left, right) in enumerate(zip(cells, cells[1:])):
        if left["assignment"] != right["assignment"]:
            events.append({"chart_index": chart_index, "root": roots[index],
                           "left_assignment": left["assignment"],
                           "right_assignment": right["assignment"]})
    return {"chart_index": chart_index, "events": events, "cells": cells,
            "representatives": set(cell["assignment"] for cell in cells),
            "all_permutations": all_permutations, "all_pair_roots": roots,
            "nonzero_coefficient_differences": nonzero_differences,
            "distinct_difference_polynomials": len(polynomials)}


def inspect(a, charts):
    result = [inspect_chart(a, chart, index) for index, chart in enumerate(charts)]
    return {"charts": result,
            "events": [event for chart in result for event in chart["events"]],
            "representatives": set().union(*(chart["representatives"] for chart in result)),
            "all_permutations": tuple(permutations(range(len(a)))),
            "scope": "factorial open-cell reference; shared exact algebraic kernel; not independent CAS"}
