"""Exact whole-circle controller for polynomial-shear matching.

Contract: rational data, distinct targets, and the common-domain convex
Hamiltonian hypothesis of the shear theorem. A sufficient convexity certificate is required
by default. An explicitly conditional promise mode is also available.
No permutation enumeration, floating-point decision, or numerical tolerance.
"""
from fractions import Fraction as Q
from math import gcd
from functools import cmp_to_key
import argparse
import json
import lex_charge as L
import dual_certificate as DUAL
from phase_optimizer import minimize_registration

C = L.C
E = C.E

def rational(x):
    if isinstance(x, (bool, float)):
        raise ValueError('exact rationals required; floats and Booleans rejected')
    return Q(x)

def points(data):
    out = tuple(tuple(rational(x) for x in p) for p in data)
    if not out or any(len(p) != 2 for p in out):
        raise ValueError('nonempty planar point list required')
    return out

def chart(c, coeff, epsilon, center):
    cp, sp = center
    shifted = [(cp*x+sp*y, -sp*x+cp*y) for x,y in c]
    curves, den = C.trajectories(shifted, coeff, epsilon)
    return {'curves': curves, 'den': den, 'center': tuple(center)}

def convex_certificate(c, coeff, epsilon):
    # H(x,y)=(x^2+(y-epsilon*p(x))^2)/2 has H_yy=1 and
    # det Hess H=1-epsilon*(y-epsilon*p(x))*p''(x).
    radius = Q(1)+max(abs(x)+abs(y) for x,y in c)
    pbound = sum(abs(pk)*radius**k for k,pk in enumerate(coeff))
    second = sum(k*(k-1)*abs(pk)*radius**(k-2)
                 for k,pk in enumerate(coeff) if k >= 2)
    defect = abs(epsilon)*(radius+2*abs(epsilon)*pbound)*second
    return {'certified': defect < 1, 'radius': str(radius),
            'target_y_bound': str(radius+abs(epsilon)*pbound),
            'hessian_determinant_lower_bound': str(1-defect),
            'condition': '|epsilon|*(R+2*|epsilon|*P)*P2 < 1',
            'domain': 'open enlargement of the common convex rectangle'}

def choose_charts(a, c, coeff, epsilon):
    n = len(a); budget = n*(n-1)
    for k in range(2*budget+1):
        z = Q(k); q = 1+z*z
        seam = ((1-z*z)/q, 2*z/q)
        checked = []
        for center in (seam, tuple(-x for x in seam)):
            ch = chart(c, coeff, epsilon, center)
            checked.append(L.regularity(a, ch['curves'], ch['den'], Q(0)))
        if all(test['regular'] for test in checked):
            cp,sp = seam
            charts = [chart(c, coeff, epsilon, (-sp,cp)),
                      chart(c, coeff, epsilon, (sp,-cp))]
            return charts, {'circle_parameter': str(z),
                            'direction': [str(x) for x in seam],
                            'candidates_tested': k+1,
                            'seam_policies': [list(t['point']) for t in checked]}
    raise AssertionError('regular seam bound failed: hypotheses or implementation')

def thresholds(a, c, coeff, epsilon, charts):
    n = len(a); degree = max(1, len(coeff)-1)
    radius = Q(1)+max(abs(x)+abs(y) for x,y in c)
    lipschitz = 2+abs(epsilon)*sum(k*abs(pk)*radius**(k-1)
                                 for k,pk in enumerate(coeff) if k)
    separation = min([Q(1)]+[(x-u)**2+(y-v)**2
                            for i,(x,y) in enumerate(c) for u,v in c[i+1:]])
    eta = separation/(16*lipschitz*lipschitz*radius)
    all_coefficients = [q for ch in charts
                        for row in L.coefficient_polynomials(a,ch['curves'])
                        for vector in row for polynomial in vector for q in polynomial]
    denominator = 1
    for q in all_coefficients:
        denominator = denominator*q.denominator//gcd(denominator,q.denominator)
    height = max([1]+[abs(int(q*denominator)) for q in all_coefficients])
    h = (2*n*height-1).bit_length()
    m = 4*degree
    b = 2*h+(2*degree).bit_length()+1
    k = b+2*m+2
    exponent = m*m*(k+2)+2
    delta = Q(1,1 << exponent)
    return min(eta,delta), {'eta': str(eta), 'delta_exponent': exponent,
                            'delta': '2^(-%d)' % exponent,
                            'degree': degree, 'integer_entry_height': str(height),
                            'common_denominator': str(denominator)}

def first_difference(a, curves, p, q):
    vectors = L.coefficient_polynomials(a, curves)
    for k in range(2*len(a)+1):
        diff = ()
        for i in range(len(a)):
            diff = E.add(diff, E.sub(vectors[i][p[i]][k],vectors[i][q[i]][k]))
        if diff: return k,diff
    raise AssertionError('distinct policies have identical formal scores')

def interior_roots(polynomial, lo, hi):
    lower,upper = E.Real.rational(lo),E.Real.rational(hi)
    return [r for r in E.roots(polynomial)
            if E.compare(r,lower)>0 and E.compare(r,upper)<0]

def balanced_regular(a, ch, lo, hi, budget, stats):
    # Central third, deterministic N+1 distinct candidates, midpoint first.
    fractions = [Q(1,2)]
    fractions.extend(Q(budget+2+j,3*(budget+2)) for j in range(1,budget+2)
                     if Q(budget+2+j,3*(budget+2)) != Q(1,2))
    for f in fractions[:budget+1]:
        cut = lo+(hi-lo)*f
        stats['regularity_queries'] += 1
        if L.regularity(a,ch['curves'],ch['den'],cut)['regular']: return cut
    raise AssertionError('regular split bound failed: hypotheses or implementation')

def isolate_chart(a, ch, index, threshold, budget, stats, use_dual=True,
                  use_unit_charge=True, max_nodes=None):
    events=[]; leaves=[]; queries=[]
    todo=[(Q(-1),Q(1),0)]
    while todo:
        lo,hi,depth=todo.pop()
        if max_nodes is not None and stats['charge_queries'] >= max_nodes:
            raise RuntimeError('INCOMPLETE: explicit node limit reached; no complete result')
        cert=L.charge(a,ch['curves'],ch['den'],lo,hi)
        stats['charge_queries'] += 1
        stats['max_depth']=max(stats['max_depth'],depth)
        charge=cert['charge'];p=tuple(cert['left_assignment']);q=tuple(cert['right_assignment'])
        queries.append({'interval':[str(lo),str(hi)],'charge':charge,'depth':depth})
        if charge==0:
            if p!=q: raise AssertionError('zero charge with distinct endpoint policies')
            leaves.append({'interval':[str(lo),str(hi)],'kind':'constant',
                           'permutation':list(p),'certificate':cert})
            continue
        accepted=None
        if p!=q:
            coefficient,diff=first_difference(a,ch['curves'],p,q)
            roots=interior_roots(diff,lo,hi)
            if use_unit_charge and charge==1 and len(roots)==1:
                accepted=(roots[0],'unit-charge',None)
            elif use_dual:
                for r in roots:
                    stats['dual_attempts'] += 1
                    left=DUAL.certify_side(a,ch['curves'],lo,hi,r,-1,p)
                    if left is None: continue
                    right=DUAL.certify_side(a,ch['curves'],lo,hi,r,1,q)
                    if right is not None:
                        accepted=(r,'two-sided-polynomial-dual',{'left':left,'right':right})
                        break
            if accepted is None and hi-lo<threshold:
                if len(roots)!=1:
                    raise AssertionError('global separation certificate failed')
                accepted=(roots[0],'uniform-separation',None)
        elif hi-lo<threshold:
            raise AssertionError('short positive-charge interval with same policy')
        if accepted:
            r,method,dual=accepted
            while r.lo<=lo or r.hi>=hi:r.refine()
            event={'chart_index':index,'root':r,'left_assignment':p,
                   'right_assignment':q,'charge':charge,'method':method,
                   'coefficient_index':coefficient,'difference_polynomial':diff,
                   'interval':(lo,hi),'charge_certificate':cert,'dual_certificate':dual}
            events.append(event)
            leaves.append({'interval':[str(lo),str(hi)],'kind':'one-event','method':method,
                           'event_index_local':len(events)-1,'charge':charge})
        else:
            cut=balanced_regular(a,ch,lo,hi,budget,stats)
            todo.extend([(cut,hi,depth+1),(lo,cut,depth+1)])
    events.sort(key=cmp_to_key(lambda x,y:E.compare(x['root'],y['root'])))
    start=L.canonical_assignment(a,C.positions(ch['curves'],ch['den'],Q(-1)))
    end=L.canonical_assignment(a,C.positions(ch['curves'],ch['den'],Q(1)))
    policy=start; lower=E.Real.rational(-1);cells=[]
    for event in events:
        if event['left_assignment']!=policy:
            raise AssertionError('unaccounted canonical policy change')
        cells.append({'chart_index':index,'lower':lower,'upper':event['root'],
                      'permutation':policy})
        lower=event['root'];policy=event['right_assignment']
    cells.append({'chart_index':index,'lower':lower,'upper':E.Real.rational(1),
                  'permutation':policy})
    if policy!=end:raise AssertionError('terminal canonical policy mismatch')
    if sum(e['charge'] for e in events)!=queries[0]['charge']:
        raise AssertionError('charge conservation failure')
    return events,cells,{'root_charge':queries[0]['charge'],'queries':queries,'leaves':leaves}

def encode_event(e):
    return {**{k:e[k] for k in ('chart_index','charge','method','coefficient_index',
                               'charge_certificate','dual_certificate')},
            'root':e['root'].certificate(),
            'left_assignment':list(e['left_assignment']),
            'right_assignment':list(e['right_assignment']),
            'difference_polynomial':[str(x) for x in e['difference_polynomial']],
            'interval':[str(x) for x in e['interval']]}

def solve(a,c,coeff,epsilon,translation=False,require_convex_certificate=True,
          use_dual=True,use_unit_charge=True,max_nodes=None):
    a,c=points(a),points(c);coeff=E.poly([rational(x) for x in coeff]);epsilon=rational(epsilon)
    if len(a)!=len(c):raise ValueError('equal source and target sizes required')
    if len(set(c))!=len(c):raise ValueError('distinct targets required')
    if not all(isinstance(x,bool) for x in (translation,require_convex_certificate,use_dual,use_unit_charge)):
        raise ValueError('flags must be Boolean')
    if max_nodes is not None and (not isinstance(max_nodes,int) or isinstance(max_nodes,bool) or max_nodes<1):
        raise ValueError('max_nodes must be a positive integer or None')
    convex=convex_certificate(c,coeff,epsilon)
    if require_convex_certificate and not convex['certified']:
        raise ValueError('sufficient convexity test failed; this does not prove nonconvexity')
    charts,seam=choose_charts(a,c,coeff,epsilon)
    threshold,bounds=thresholds(a,c,coeff,epsilon,charts)
    budget=len(a)*(len(a)-1)
    stats={'charge_queries':0,'regularity_queries':0,'dual_attempts':0,'max_depth':0}
    events=[];cells=[];trees=[]
    for index,ch in enumerate(charts):
        ev,ce,tree=isolate_chart(a,ch,index,threshold,budget,stats,use_dual,use_unit_charge,max_nodes)
        events.extend(ev);cells.extend(ce);trees.append(tree)
    if sum(t['root_charge'] for t in trees)!=budget:
        raise AssertionError('full-period charge must be n(n-1)')
    # Point-only policies at a breakpoint are deliberately not enumerated:
    # continuity makes the adjacent representatives cover the original value.
    representatives=sorted(set(cell['permutation'] for cell in cells))
    if len(representatives)>max(1,budget):raise AssertionError('representative bound failed')
    optimization=minimize_registration(a,charts,representatives,translation=translation)
    encoded={'status':'COMPLETE_EXACT_CONDITIONAL_ON_SHEAR_THEOREM',
             'input':{'a':[[str(x) for x in p] for p in a],
                      'c':[[str(x) for x in p] for p in c],
                      'coeff':[str(x) for x in coeff],'epsilon':str(epsilon)},
             'convexity':convex,'convexity_mode':'certified' if convex['certified'] else 'user-promise',
             'seam':seam,'bounds':bounds,'total_charge':budget,'statistics':stats,
             'charts':[{'center':[str(x) for x in ch['center']],
                        'den':[str(x) for x in ch['den']],
                        'curves':[[[str(x) for x in p] for p in curve] for curve in ch['curves']]}
                       for ch in charts],
             'events':[encode_event(e) for e in events],
             'cells':[{'chart_index':ce['chart_index'],'lower':ce['lower'].certificate(),
                       'upper':ce['upper'].certificate(),'permutation':list(ce['permutation'])}
                      for ce in cells],
             'representatives':[list(p) for p in representatives],
             'charge_trees':trees,'optimization':optimization['json'],
             'scope':'Canonical open-cell representatives and original global value; not all tied permutations, original optimal-face changes, or every breakpoint point-policy.'}
    return {'charts':charts,'events':events,'cells':cells,'representatives':representatives,
            'optimization':optimization,'statistics':stats,'json':encoded}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',help='JSON input with a,c,coeff,epsilon; rationals as strings or integers')
    parser.add_argument('--translation',action='store_true')
    parser.add_argument('--assume-common-convexity',action='store_true',
                        help='explicitly accept the shear convexity promise if the sufficient test fails')
    parser.add_argument('--max-nodes',type=int,default=None,help='optional abort limit; abort never returns a complete result')
    args=parser.parse_args()
    with open(args.input) as stream:data=json.load(stream)
    result=solve(data['a'],data['c'],data['coeff'],data['epsilon'],
                 translation=args.translation,require_convex_certificate=not args.assume_common_convexity,
                 max_nodes=args.max_nodes)
    print(json.dumps(result['json'],indent=2,sort_keys=True))

if __name__=='__main__':main()
