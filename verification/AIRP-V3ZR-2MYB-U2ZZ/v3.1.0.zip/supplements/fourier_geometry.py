"""Exact pairwise geometry certificates for rational Fourier trajectories.

No floating-point decisions. Ascending rational polynomials and Sturm isolation
come from the local exact kernel. A center (c,s) means time
    t = arg(c+i*s) + 2*atan(z), -1 <= z <= 1.
Thus time increases with z; clockwise motion is represented by signed Fourier
coefficients, e.g. x=cos(t), y=-sin(t). Two ordered antipodal centers cover one
period. Arbitrary charts passed to certify_geometry must close continuously;
charts created by make_charts come from a single smooth periodic function.
"""
from fractions import Fraction as Q
from itertools import combinations
import charge_oracle as C

E = C.E
poly, add, sub, mul, scale, ev = E.poly, E.add, E.sub, E.mul, E.scale, E.evaluate
DEFAULT_CENTERS = ((0, 1), (0, -1))


def rational(value):
    if isinstance(value, (bool, float)):
        raise ValueError('exact rational coefficients required; no floats or Booleans')
    return Q(value)


def _power(p, k):
    out = poly([1])
    for _ in range(k):
        out = mul(out, p)
    return out


def _centers(data):
    out = tuple(tuple(rational(x) for x in c) for c in data)
    if len(out) != 2 or any(len(c) != 2 for c in out):
        raise ValueError('exactly two planar antipodal chart centers required')
    if any(c*c+s*s != 1 for c, s in out):
        raise ValueError('chart centers must be rational unit vectors')
    if out[1] != tuple(-x for x in out[0]):
        raise ValueError('chart centers must be antipodal')
    return out


def _fourier(data):
    if not isinstance(data, (list, tuple)) or not data:
        raise ValueError('nonempty list of Fourier targets required')
    targets = []
    degree = 1
    for target in data:
        if not isinstance(target, dict) or set(target) != {'x', 'y'}:
            raise ValueError('each Fourier target needs exactly x and y')
        coordinates = []
        for key in ('x', 'y'):
            series = target[key]
            if not isinstance(series, dict) or set(series) - {'cos', 'sin'}:
                raise ValueError('each coordinate needs cos and/or sin coefficient arrays')
            arrays = []
            for kind in ('cos', 'sin'):
                raw = series.get(kind, [])
                if not isinstance(raw, (list, tuple)):
                    raise ValueError('Fourier coefficient arrays must be lists or tuples')
                coeff = tuple(rational(x) for x in raw)
                degree = max(degree, len(coeff)-1)
                arrays.append(coeff)
            if arrays[1] and arrays[1][0]:
                raise ValueError('sin coefficient at harmonic zero must be zero')
            coordinates.append(tuple(arrays))
        targets.append(tuple(coordinates))
    return targets, degree


def make_charts(data, centers=DEFAULT_CENTERS):
    """Return two {curves,den,center,fourier_degree} exact rational charts.

    data is a nonempty list of {'x': {'cos': [...], 'sin': [...]},
    'y': {...}}. Missing cos/sin arrays mean zero. Entry k is harmonic k;
    sin[0], if present, must be zero. Integers, Fraction, rational strings
    are accepted; floats/Booleans are rejected. The common denominator is
    exactly (1+z*z)**D, D=max(1, largest supplied harmonic index).
    """
    targets, degree = _fourier(data)
    centers = _centers(centers)
    q = poly([1, 0, 1])
    qpowers = [_power(q, k) for k in range(degree+1)]
    base_c, base_s = poly([1, 0, -1]), poly([0, 2])
    half_powers = [(poly([1]), ())]
    for _ in range(degree):
        c, s = half_powers[-1]
        half_powers.append((sub(mul(c, base_c), mul(s, base_s)),
                            add(mul(s, base_c), mul(c, base_s))))
    charts = []
    for center in centers:
        cp, sp = center
        ck, sk = Q(1), Q(0)
        basis = []
        for k, (hc, hs) in enumerate(half_powers):
            basis.append((mul(sub(scale(hc, ck), scale(hs, sk)), qpowers[degree-k]),
                          mul(add(scale(hc, sk), scale(hs, ck)), qpowers[degree-k])))
            ck, sk = ck*cp-sk*sp, sk*cp+ck*sp
        curves = []
        for target in targets:
            xy = []
            for cosine, sine in target:
                p = ()
                for k, coefficient in enumerate(cosine):
                    p = add(p, scale(basis[k][0], coefficient))
                for k, coefficient in enumerate(sine):
                    p = add(p, scale(basis[k][1], coefficient))
                xy.append(p)
            curves.append(tuple(xy))
        charts.append({'curves': tuple(curves), 'den': qpowers[degree],
                       'center': center, 'fourier_degree': degree})
    return charts


def _closed_roots(p):
    lower, upper = E.Real.rational(-1), E.Real.rational(1)
    return [r for r in E.roots(p)
            if E.compare(r, lower) >= 0 and E.compare(r, upper) <= 0]


def _interior_roots(p):
    lower, upper = E.Real.rational(-1), E.Real.rational(1)
    return [r for r in E.roots(p)
            if E.compare(r, lower) > 0 and E.compare(r, upper) < 0]


def _between(left, right):
    if E.compare(left, right) >= 0:
        raise AssertionError('unordered real-root partition')
    while left.hi >= right.lo:
        left.refine()
        right.refine()
    return (left.hi+right.lo)/2


def _nonpositive(p, label):
    """Prove a polynomial is <=0 on the closed chart via exact root cells."""
    endpoint_values = [ev(p, Q(-1)), ev(p, Q(1))]
    if any(v > 0 for v in endpoint_values):
        raise ValueError('%s: relative angle is not nonincreasing' % label)
    if not p:
        return {'identically_zero': True, 'roots': [], 'cells': [],
                'endpoint_values': ['0', '0']}
    roots = _interior_roots(p)
    endpoints = [E.Real.rational(-1), *roots, E.Real.rational(1)]
    cells = []
    for left, right in zip(endpoints, endpoints[1:]):
        witness = _between(left, right)
        value = ev(p, witness)
        if value > 0:
            raise ValueError('%s: relative angle is not nonincreasing' % label)
        if value == 0:
            raise AssertionError('root partition missed a polynomial root')
        cells.append({'sample': str(witness), 'value': str(value), 'sign': -1})
    return {'identically_zero': False, 'roots': [r.certificate() for r in roots],
            'cells': cells, 'endpoint_values': [str(v) for v in endpoint_values]}


def _positive_denominator(den, chart_index):
    if not den or ev(den, -1) <= 0 or ev(den, 1) <= 0 or _closed_roots(den):
        raise ValueError('chart %d: denominator is not strictly positive' % chart_index)
    return {'endpoint_values': [str(ev(den, -1)), str(ev(den, 1))],
            'closed_root_count': 0, 'positive': True}


def _position(curve, den, z):
    return tuple(ev(p, z)/ev(den, z) for p in curve)


def _velocity(curve, den, z):
    # dt/dz = 2/(1+z^2); convert to time derivative.
    d = ev(den, z)
    return tuple((ev(E.derivative(p), z)*d-ev(p, z)*ev(E.derivative(den), z))
                 * (1+z*z)/(2*d*d) for p in curve)


def certify_geometry(charts):
    """Certify closed pairwise noncollision, clockwise monotonicity and winding.

    Raises ValueError on a failed hypothesis. Return value is JSON-serializable:
    W=sum pair clockwise windings, total_charge=2*W, max_representatives=max(1,2W),
    pair_certificates with polynomial sign cells and exact ray crossings,
    denominator_certificates and seam continuity/smoothness indicators.

    The certificate verifies continuous piecewise rational paths. It additionally
    checks first time derivatives at seams and reports the result; generated
    Fourier charts are smooth. It does not assert arbitrary supplied charts have
    matching derivatives of every order. No claim about assignments is checked.
    """
    if not isinstance(charts, (list, tuple)) or len(charts) != 2:
        raise ValueError('two closed half-circle charts required')
    centers = _centers([ch['center'] for ch in charts])
    normalized = []
    n = None
    denominator_certificates = []
    for index, ch in enumerate(charts):
        den = poly(rational(x) for x in ch['den'])
        curves = tuple(tuple(poly(rational(v) for v in p) for p in curve)
                       for curve in ch['curves'])
        if not curves or any(len(curve) != 2 for curve in curves):
            raise ValueError('nonempty planar curves required in each chart')
        if n is None:
            n = len(curves)
        if len(curves) != n:
            raise ValueError('chart target counts differ')
        denominator_certificates.append(_positive_denominator(den, index))
        normalized.append((curves, den))
    seam_derivatives_match = True
    for index in range(2):
        curves, den = normalized[index]
        next_curves, next_den = normalized[1-index]
        for i in range(n):
            if _position(curves[i], den, Q(1)) != _position(next_curves[i], next_den, Q(-1)):
                raise ValueError('chart seam positions do not agree')
            if _velocity(curves[i], den, Q(1)) != _velocity(next_curves[i], next_den, Q(-1)):
                seam_derivatives_match = False
    pairs = []
    endvalues = []
    for i, j in combinations(range(n), 2):
        pair = {'pair': [i, j], 'chart_certificates': [], '_curves': []}
        for index, (curves, den) in enumerate(normalized):
            px, py = (sub(curves[j][k], curves[i][k]) for k in range(2))
            if not px and not py:
                raise ValueError('pair %d,%d has an identically colliding chart' % (i, j))
            common = E.gcd(px, py)
            if _closed_roots(common):
                raise ValueError('pair %d,%d has a collision on closed chart %d' % (i, j, index))
            determinant = sub(mul(px, E.derivative(py)), mul(py, E.derivative(px)))
            monotonicity = _nonpositive(determinant, 'pair %d,%d chart %d' % (i, j, index))
            pair['chart_certificates'].append({
                'chart_index': index,
                'difference_numerators': [[str(x) for x in p] for p in (px, py)],
                'gcd': [str(x) for x in common], 'closed_common_root_count': 0,
                'angular_determinant': [str(x) for x in determinant],
                'nonpositive_certificate': monotonicity})
            pair['_curves'].append((px, py))
            endvalues.extend((ev(px, z), ev(py, z)) for z in (Q(-1), Q(1)))
        pairs.append(pair)
    # At most one integer slope is forbidden per nonzero endpoint. This common
    # ray excludes all seam points and makes summing open-chart crossings exact.
    ray = next(k for k in range(len(endvalues)+1)
               if all(y-k*x for x, y in endvalues))
    total = 0
    for pair in pairs:
        ccw = 0
        for certificate, (px, py) in zip(pair['chart_certificates'], pair.pop('_curves')):
            count, crossings = C.ray_crossings(px, py, Q(-1), Q(1), ray)
            ccw += count
            certificate['signed_ray_crossings'] = count
            certificate['crossings'] = crossings
        winding = -ccw
        if winding < 0:
            raise AssertionError('nonincreasing closed relative angle has negative clockwise winding')
        pair['clockwise_winding'] = winding
        total += winding
    return {'certified': True, 'n': n, 'W': total, 'total_charge': 2*total,
            'max_representatives': max(1, 2*total), 'ray_slope': ray,
            'centers': [[str(x) for x in center] for center in centers],
            'denominator_certificates': denominator_certificates,
            'seam_positions_match': True, 'seam_first_derivatives_match': seam_derivatives_match,
            'pair_certificates': pairs,
            'scope': 'Exact pair geometry and integer winding; no assignment theorem or optimizer validation.'}
