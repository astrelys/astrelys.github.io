"""Polynomial-vector assignment duals and conservative interval certificates.

An optional acceleration, not the termination argument. All comparisons in the
Hungarian construction are lexicographic evaluations at a rational witness.
The returned polynomial identities are checked, not inferred from that witness.
"""
from fractions import Fraction as Q
import lex_charge as L

E = L.C.E

def vadd(a, b): return tuple(E.add(x, y) for x, y in zip(a, b))
def vneg(a): return tuple(E.neg(x) for x in a)
def vsub(a, b): return vadd(a, vneg(b))

def polynomial_dual(a, curves, witness):
    weights = L.coefficient_polynomials(a, curves)
    n = len(a); k = 2*n+1; zero = ((),)*k
    cost = [[vneg(tuple(cell)) for cell in row] for row in weights]
    def key(v): return tuple(E.evaluate(p, witness) for p in v)
    u = [zero]*(n+1); v = [zero]*(n+1)
    match = [0]*(n+1); way = [0]*(n+1)
    for i in range(1, n+1):
        match[0] = i; j0 = 0; best = [None]*(n+1); used = [False]*(n+1)
        while True:
            used[j0] = True; i0 = match[j0]; delta = None; j1 = 0
            for j in range(1, n+1):
                if used[j]: continue
                cur = vsub(vsub(cost[i0-1][j-1], u[i0]), v[j])
                if best[j] is None or key(cur) < key(best[j]):
                    best[j] = cur; way[j] = j0
                if delta is None or key(best[j]) < key(delta):
                    delta = best[j]; j1 = j
            for j in range(n+1):
                if used[j]:
                    u[match[j]] = vadd(u[match[j]], delta)
                    v[j] = vsub(v[j], delta)
                elif j and best[j] is not None:
                    best[j] = vsub(best[j], delta)
            j0 = j1
            if not match[j0]: break
        while True:
            j1 = way[j0]; match[j0] = match[j1]; j0 = j1
            if not j0: break
    perm = [0]*n
    for j in range(1, n+1): perm[match[j]-1] = j-1
    slacks = [[vsub(vsub(cost[i][j], u[i+1]), v[j+1])
               for j in range(n)] for i in range(n)]
    # Tightness must hold as a polynomial-vector identity, not just at witness.
    if any(any(slacks[i][j]) for i, j in enumerate(perm)):
        return None
    if any(key(cell) < (Q(0),)*k for row in slacks for cell in row):
        raise AssertionError('Hungarian witness dual infeasible')
    return {'permutation': tuple(perm), 'slacks': slacks,
            'row_potentials': u[1:], 'column_potentials': v[1:],
            'witness': witness}

def certify_side(a, curves, lo, hi, root, side, expected):
    """Prove one policy throughout (lo,root) or (root,hi).

The earliest nonzero source coefficient in each slack is strictly positive
throughout the relevant open side. Zeros at the candidate root or the outer
endpoint are allowed. Other roots cause a conservative failure.
"""
    while root.lo <= lo or root.hi >= hi: root.refine()
    witness = (lo+root.lo)/2 if side < 0 else (root.hi+hi)/2
    dual = polynomial_dual(a, curves, witness)
    if dual is None or dual['permutation'] != tuple(expected): return None
    lower = E.Real.rational(lo) if side < 0 else root
    upper = root if side < 0 else E.Real.rational(hi)
    checks = []
    for i, row in enumerate(dual['slacks']):
        for j, cell in enumerate(row):
            first = next(((k,p) for k,p in enumerate(cell) if p), None)
            if first is None: continue
            k, p = first
            if E.evaluate(p, witness) <= 0: return None
            for r in E.roots(p):
                if E.compare(r, lower) > 0 and E.compare(r, upper) < 0:
                    return None
            checks.append({'row': i, 'column': j, 'coefficient': k,
                           'polynomial': [str(x) for x in p]})
    def enc(vectors): return [[[str(x) for x in p] for p in v] for v in vectors]
    return {'side': 'left' if side < 0 else 'right',
            'permutation': list(expected), 'witness': str(witness),
            'row_potentials': enc(dual['row_potentials']),
            'column_potentials': enc(dual['column_potentials']),
            'strict_first_coefficients': checks}
