"""Exact global phase minimization for a finite covering set of matchings.

The source is fixed.  Each target chart gives rational coordinate numerators
over one denominator positive on [-1, 1]; z is its local half-angle coordinate.
Completeness of the charts and permutation representatives is the caller's
contract.  No sampling, floating-point decision, or factorial search is used.
"""

from fractions import Fraction as Q
import exact_algebra as E


ONE = E.poly([1])
ZERO = E.poly([])
HALF_ANGLE_DEN = E.poly([1, 0, 1])
LOWER = Q(-1)
UPPER = Q(1)


def _rational(value):
    if isinstance(value, (float, bool)):
        raise ValueError("exact rationals required; floats and Booleans rejected")
    return Q(value)


def _polynomial(coefficients):
    return E.poly([_rational(value) for value in coefficients])


def _quotient(a, b):
    quotient, remainder = E.divrem(a, b)
    if remainder:
        raise ArithmeticError("expected exact polynomial division")
    return quotient


def _reduce_fraction(num, den):
    """Cancel the objective fraction, keeping its denominator positive."""
    if not num:
        return ZERO, ONE
    common = E.gcd(num, den)
    num, den = _quotient(num, common), _quotient(den, common)
    # A monic gcd need not be positive on the chart (e.g. z-2).  image()
    # requires a positive denominator, so preserve that invariant explicitly.
    if E.evaluate(den, Q(0)) < 0:
        num, den = E.scale(num, -1), E.scale(den, -1)
    return num, den


def _stationary(num, den, witness_den=ONE):
    raw = E.sub(E.mul(E.derivative(num), den),
                E.mul(num, E.derivative(den)))
    if not raw:
        return ZERO, ZERO
    clean = raw
    forbidden = E.mul(E.mul(den, witness_den), HALF_ANGLE_DEN)
    # This also removes real denominator roots outside the chart, safely:
    # den has no root on [-1,1].  Repetition removes every multiplicity.
    while True:
        common = E.gcd(clean, forbidden)
        if len(common) <= 1:
            break
        clean = _quotient(clean, common)
    return raw, E.sqfree(clean)


def _prepare(a, charts, permutations, translation):
    if not isinstance(translation, bool):
        raise ValueError("translation must be Boolean")
    a = tuple(tuple(_rational(value) for value in point) for point in a)
    if not a or any(len(point) != 2 for point in a):
        raise ValueError("a must be a nonempty list of planar rational points")
    n = len(a)
    representatives = []
    seen = set()
    for permutation in permutations:
        permutation = tuple(permutation)
        if (len(permutation) != n or
                any(not isinstance(i, int) or isinstance(i, bool)
                    for i in permutation) or
                sorted(permutation) != list(range(n))):
            raise ValueError("each permutation must be a full bijection")
        if permutation not in seen:
            seen.add(permutation)
            representatives.append(permutation)
    if not representatives:
        raise ValueError("at least one covering permutation is required")
    prepared = []
    for chart in charts:
        den = _polynomial(chart["den"])
        if (not den or E.evaluate(den, LOWER) <= 0 or
                E.evaluate(den, UPPER) <= 0 or
                E.count(E.sqfree(den), LOWER, UPPER)):
            raise ValueError("chart denominator must be positive on [-1,1]")
        curves = tuple(tuple(_polynomial(axis) for axis in curve)
                       for curve in chart["curves"])
        if len(curves) != n or any(len(curve) != 2 for curve in curves):
            raise ValueError("each chart needs one planar curve per target")
        center = tuple(_rational(value) for value in chart["center"])
        if len(center) != 2 or sum(value * value for value in center) != 1:
            raise ValueError("chart center must be a rational unit vector")
        prepared.append({"curves": curves, "den": den, "center": center})
    if not prepared:
        raise ValueError("at least one covering phase chart is required")
    return a, prepared, tuple(representatives)


def _chart_data(a, chart, translation):
    n = len(a)
    mean_a = tuple(sum(point[k] for point in a) / n for k in range(2))
    mean_b = tuple(E.scale(_sum_polynomials(curve[k]
                                          for curve in chart["curves"]),
                          Q(1, n)) for k in range(2))
    if translation:
        source = tuple(tuple(point[k] - mean_a[k] for k in range(2))
                       for point in a)
        target = tuple(tuple(E.sub(curve[k], mean_b[k]) for k in range(2))
                       for curve in chart["curves"])
        shift = tuple(E.sub(mean_b[k], E.scale(chart["den"], mean_a[k]))
                      for k in range(2))
        shift_den = chart["den"]
    else:
        source, target = a, chart["curves"]
        shift, shift_den = (ZERO, ZERO), ONE
    return source, target, shift, shift_den


def _sum_polynomials(polynomials):
    result = ZERO
    for polynomial in polynomials:
        result = E.add(result, polynomial)
    return result


def _objective(source, target, den, permutation):
    num = ZERO
    for i, point in enumerate(source):
        for axis in range(2):
            residual = E.sub(E.scale(den, point[axis]),
                             target[permutation[i]][axis])
            num = E.add(num, E.mul(residual, residual))
    # In particular, the target-norm term is retained even when it varies
    # with phase.  Centering above is exact, with no permutation dependence.
    return _reduce_fraction(num, E.mul(den, den))


def _branch_candidates(source, target, chart, permutation, chart_index,
                       shift, shift_den):
    num, den = _objective(source, target, chart["den"], permutation)
    # Also clear chart/phase denominator factors from the defining root
    # polynomial, so the same root is usable for exact witness images.
    raw, stationary = _stationary(num, den, chart["den"])
    common = {
        "chart_index": chart_index,
        "center": chart["center"],
        "permutation": permutation,
        "objective_num": num,
        "objective_den": den,
        "stationary_raw": raw,
        "stationary": stationary,
        "translation_num": shift,
        "translation_den": shift_den,
    }
    if not raw:
        z = E.Real.rational(0)
        return [dict(common, kind="constant", z=z,
                     value=E.image(z, num, den))]
    candidates = []
    for endpoint in (LOWER, UPPER):
        z = E.Real.rational(endpoint)
        candidates.append(dict(common, kind="endpoint", z=z,
                               value=E.image(z, num, den)))
    left, right = E.Real.rational(LOWER), E.Real.rational(UPPER)
    for z in E.roots(stationary):
        # Endpoint stationary roots are represented once by the endpoints.
        if E.compare(z, left) > 0 and E.compare(z, right) < 0:
            candidates.append(dict(common, kind="stationary", z=z,
                                   value=E.image(z, num, den)))
    return candidates


def _encode_poly(polynomial):
    return [str(coefficient) for coefficient in polynomial]


def encode_candidate(candidate):
    """JSON-safe algebraic certificates and rational-function witnesses."""
    cp, sp = candidate["center"]
    cosine = E.poly([cp, -2 * sp, -cp])
    sine = E.poly([sp, 2 * cp, -sp])
    return {
        "kind": candidate["kind"],
        "chart_index": candidate["chart_index"],
        "chart_center": [str(cp), str(sp)],
        "permutation": list(candidate["permutation"]),
        "z": candidate["z"].certificate(),
        "value": candidate["value"].certificate(),
        "objective": {"numerator_ascending": _encode_poly(candidate["objective_num"]),
                      "denominator_ascending": _encode_poly(candidate["objective_den"])},
        "stationary_polynomial_ascending": _encode_poly(candidate["stationary"]),
        "phase": {
            "convention": "theta=phi+2*atan(z), center=(cos(phi),sin(phi))",
            "cosine_numerator_ascending": _encode_poly(cosine),
            "sine_numerator_ascending": _encode_poly(sine),
            "denominator_ascending": ["1", "0", "1"],
        },
        "translation": {
            "convention": "fixed source a_i+t versus moving target b_pi(i)(theta)",
            "numerators_ascending": [_encode_poly(p)
                                     for p in candidate["translation_num"]],
            "denominator_ascending": _encode_poly(candidate["translation_den"]),
        },
    }


def minimize_registration(a, charts, permutations, translation=False):
    """Return internal winners/candidates and JSON-safe exact certificates.

    ``permutations`` must contain every representative needed to cover a
    global optimum; this routine does not establish that controller premise.
    Tied candidates may repeat a phase at overlapping chart boundaries and
    are not an enumeration of all tied permutations or all optimal angles.
    A constant winning branch represents an entire chart interval.
    """
    a, charts, permutations = _prepare(a, charts, permutations, translation)
    candidates = []
    for chart_index, chart in enumerate(charts):
        source, target, shift, shift_den = _chart_data(a, chart, translation)
        for permutation in permutations:
            candidates.extend(_branch_candidates(source, target, chart,
                                                  permutation, chart_index,
                                                  shift, shift_den))
    selected = candidates[0]
    minimizers = [selected]
    for candidate in candidates[1:]:
        ordering = E.compare(candidate["value"], selected["value"])
        if ordering < 0:
            selected, minimizers = candidate, [candidate]
        elif ordering == 0:
            minimizers.append(candidate)
    constant_charts = sorted({c["chart_index"] for c in minimizers
                             if c["kind"] == "constant"})
    encoded = {
        "status": "EXACT_ALGEBRAIC_OPTIMUM",
        "translation_optimized": translation,
        "selected": encode_candidate(selected),
        "minimizing_candidates": [encode_candidate(c) for c in minimizers],
        "constant_minimizing_charts": constant_charts,
        "all_phases_optimal": len(constant_charts) == len(charts),
        "chart_count": len(charts),
        "permutation_count": len(permutations),
        "branch_count": len(charts) * len(permutations),
        "candidate_count": len(candidates),
        "max_stationary_degree": max(len(c["stationary"]) - 1
                                     for c in candidates),
        "scope": "Exact optimum conditional on complete phase charts and covering permutation representatives; ties may repeat phases; full tied-permutation enumeration is not claimed.",
    }
    return {"selected": selected, "minimizers": minimizers,
            "candidates": candidates, "json": encoded}
