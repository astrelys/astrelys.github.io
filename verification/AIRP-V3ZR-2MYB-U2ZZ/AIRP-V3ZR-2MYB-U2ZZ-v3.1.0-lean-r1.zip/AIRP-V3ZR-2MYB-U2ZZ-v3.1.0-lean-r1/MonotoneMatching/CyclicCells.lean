import MonotoneMatching.RotationCells
import MonotoneMatching.CyclicLabels
import MonotoneMatching.PhaseBudget

/-! Exact cyclic phase accounting for realized optimizer cells. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

theorem subdivision_duration_sum {m : ℕ} (cut : Fin (m+1) → ℝ) :
    (∑ i : Fin m, (cut i.succ-cut i.castSucc)) = cut (Fin.last m)-cut 0 := by
  rw [Finset.sum_sub_distrib]
  have h1 := Fin.sum_univ_succ cut
  have h2 := Fin.sum_univ_castSucc cut
  linarith

/-- The cyclic next-cell start is the preceding cell end, including the seam. -/
theorem periodic_subdivision_seam {m : ℕ} (hm : 0 < m)
    (cut : Fin (m+1) → ℝ) {P : ℝ} (hfirst : cut 0=0) (hlast : cut (Fin.last m)=P)
    (f : ℝ → ℝ) (hf : Function.Periodic f P) (i : Fin m) :
    f (cut (finRotate m i).castSucc) = f (cut i.succ) := by
  obtain ⟨k,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hm)
  by_cases hi : i=Fin.last k
  · subst i
    rw [finRotate_last]
    have h0 : (0 : Fin (k+1)).castSucc = (0 : Fin (k+1+1)) := rfl
    have hl : (Fin.last k).succ = Fin.last (k+1) := rfl
    rw [h0,hl,hfirst,hlast]
    simpa using (hf 0).symm
  · have he : (finRotate (k+1) i).castSucc = i.succ := by
      apply Fin.ext
      simpa only [Fin.val_castSucc,Fin.val_succ] using coe_finRotate_of_ne_last hi
    rw [he]

/-- Relabeling a fixed optimal assignment gives the identity cell required
by the phase transport theorem. -/
theorem labelPhase_rotation_transport {n : ℕ} (a b : Fin n → ℂ)
    (ha : Function.Injective a) (hb : Function.Injective b) (σ : Equiv.Perm (Fin n))
    {u v : ℝ} (huv : u ≤ v)
    (hopt : ∀ t ∈ Set.Icc u v, ∀ τ, assignmentScore a (rotateClockwise t ∘ b) τ ≤
      assignmentScore a (rotateClockwise t ∘ b) σ) :
    identityPhase a ((rotateClockwise v ∘ b) ∘ σ) -
      identityPhase a ((rotateClockwise u ∘ b) ∘ σ) = -(n.choose 2 : ℝ)*(v-u) := by
  apply identityPhase_rotation_transport a (b ∘ σ) ha (hb.comp σ.injective)
    isPreconnected_Icc _ (Set.left_mem_Icc.mpr huv) (Set.right_mem_Icc.mpr huv)
  intro t ht τ
  change assignmentScore a ((rotateClockwise t ∘ b) ∘ σ) τ ≤
    assignmentScore a ((rotateClockwise t ∘ b) ∘ σ) (Equiv.refl _)
  rw [assignmentScore_relabel_targets,assignmentScore_relabel_targets]
  change assignmentScore a (rotateClockwise t ∘ b) (σ*τ) ≤
    assignmentScore a (rotateClockwise t ∘ b) (σ*1)
  rw [mul_one]
  exact hopt t ht (σ*τ)

/-- A realized optimal subdivision has total jump budget 2*pi*choose(n,2). -/
theorem realized_rotation_phase_budget {n m : ℕ} (a b : Fin n → ℂ)
    (ha : Function.Injective a) (hb : Function.Injective b)
    (cut : Fin (m+1) → ℝ) (label : Fin m → Equiv.Perm (Fin n))
    (hmono : StrictMono cut) (hfirst : cut 0=0) (hlast : cut (Fin.last m)=2*Real.pi)
    (hopt : ∀ i, ∀ t ∈ Set.Icc (cut i.castSucc) (cut i.succ), ∀ τ,
      assignmentScore a (rotateClockwise t ∘ b) τ ≤
        assignmentScore a (rotateClockwise t ∘ b) (label i)) :
    (∑ i, (identityPhase a ((rotateClockwise (cut (finRotate m i).castSucc) ∘ b) ∘ label (finRotate m i)) -
      identityPhase a ((rotateClockwise (cut i.succ) ∘ b) ∘ label i))) =
        2*Real.pi*(n.choose 2) := by
  apply cyclic_rotation_phase_budget (finRotate m)
    (fun i => identityPhase a ((rotateClockwise (cut i.castSucc) ∘ b) ∘ label i))
    (fun i => identityPhase a ((rotateClockwise (cut i.succ) ∘ b) ∘ label i))
    (fun i => cut i.succ-cut i.castSucc) (n.choose 2)
  · intro i
    exact labelPhase_rotation_transport a b ha hb (label i)
      (hmono i.castSucc_lt_succ).le (hopt i)
  · rw [subdivision_duration_sum,hfirst,hlast,sub_zero]

/-- No label change means no jump even at the chosen time-circle seam. -/
theorem phase_jump_zero_of_same_label {n m : ℕ} (a b : Fin n → ℂ) (hm : 0 < m)
    (cut : Fin (m+1) → ℝ) (label : Fin m → Equiv.Perm (Fin n))
    (hfirst : cut 0=0) (hlast : cut (Fin.last m)=2*Real.pi)
    (i : Fin m) (he : label (finRotate m i)=label i) :
    identityPhase a ((rotateClockwise (cut (finRotate m i).castSucc) ∘ b) ∘ label (finRotate m i)) -
      identityPhase a ((rotateClockwise (cut i.succ) ∘ b) ∘ label i) = 0 := by
  rw [he]
  apply sub_eq_zero.mpr
  apply periodic_subdivision_seam hm cut hfirst hlast
    (fun t => identityPhase a ((rotateClockwise t ∘ b) ∘ label i)) _ i
  intro t
  dsimp only
  rw [rotateClockwise_periodic t]

/-- The global rotational upper bound follows from positive charges at the
actual label changes of a realized subdivision. This is an explicit reduction,
not a proof that the geometric positivity premise holds. -/
theorem rotationCount_le_of_realized_cell_charges {n m : ℕ} (a b : Fin n → ℂ)
    (hn : 2 ≤ n) (hm : 0 < m) (ha : Function.Injective a) (hb : Function.Injective b)
    (cut : Fin (m+1) → ℝ) (label : Fin m → Equiv.Perm (Fin n))
    (hmono : StrictMono cut) (hfirst : cut 0=0) (hlast : cut (Fin.last m)=2*Real.pi)
    (hopt : ∀ i, ∀ t ∈ Set.Icc (cut i.castSucc) (cut i.succ), ∀ τ,
      assignmentScore a (rotateClockwise t ∘ b) τ ≤
        assignmentScore a (rotateClockwise t ∘ b) (label i))
    (hcover : ∀ σ ∈ rotationOptimizers a b, ∃ i, label i=σ)
    (hpositive : ∀ i, label (finRotate m i) ≠ label i → Real.pi ≤
      identityPhase a ((rotateClockwise (cut (finRotate m i).castSucc) ∘ b) ∘ label (finRotate m i)) -
      identityPhase a ((rotateClockwise (cut i.succ) ∘ b) ∘ label i)) :
    rotationCount a b ≤ n*(n-1) := by
  classical
  let charge := fun i =>
    identityPhase a ((rotateClockwise (cut (finRotate m i).castSucc) ∘ b) ∘ label (finRotate m i)) -
      identityPhase a ((rotateClockwise (cut i.succ) ∘ b) ∘ label i)
  have hzero (i : Fin m) (he : label (finRotate m i)=label i) : charge i=0 :=
    phase_jump_zero_of_same_label a b hm cut label hfirst hlast i he
  have hc (i : Fin m) : charge i=0 ∨ Real.pi ≤ charge i := by
    by_cases he : label (finRotate m i)=label i
    · exact Or.inl (hzero i he)
    · exact Or.inr (hpositive i he)
  have hbudget : ∑ i, charge i = 2*Real.pi*(n.choose 2) :=
    realized_rotation_phase_budget a b ha hb cut label hmono hfirst hlast hopt
  have hsome : ∃ i, charge i ≠ 0 := by
    by_contra h
    push Not at h
    have hz : (∑ i, charge i)=0 := Finset.sum_eq_zero (fun i _ => h i)
    have hN : (0 : ℝ) < (n.choose 2 : ℝ) := Nat.cast_pos.mpr (Nat.choose_pos hn)
    have hp := mul_pos (mul_pos (by norm_num : (0:ℝ)<2) Real.pi_pos) hN
    rw [hz] at hbudget
    linarith
  obtain ⟨i,hi⟩ := hsome
  have hli : label (finRotate m i) ≠ label i := by intro h; exact hi (hzero i h)
  have hm2 : 2 ≤ m := by
    have hindices : finRotate m i ≠ i := by intro h; exact hli (congrArg label h)
    by_contra h
    have hm1 : m=1 := by omega
    subst m
    exact hindices (Subsingleton.elim _ _)
  have hlabels := cyclic_label_count_le_changes (finRotate m) label
    (finRotate_reaches_all hm2) ⟨finRotate m i,i,hli⟩
  have hfilter : (Finset.univ.filter (fun i => label (finRotate m i) ≠ label i)) =
      Finset.univ.filter (fun i => charge i ≠ 0) := by
    ext i
    simp only [Finset.mem_filter,Finset.mem_univ,true_and]
    constructor
    · intro h he
      have hp := hpositive i h
      change Real.pi ≤ charge i at hp
      rw [he] at hp
      exact (not_le_of_gt Real.pi_pos) hp
    · intro h he; exact h (hzero i he)
  rw [hfilter] at hlabels
  have hcount := rotational_charge_count_bound charge n hc hbudget
  have hsub : rotationOptimizers a b ⊆ Finset.univ.image label := by
    intro σ hσ
    obtain ⟨j,hj⟩ := hcover σ hσ
    exact Finset.mem_image.mpr ⟨j,Finset.mem_univ _,hj⟩
  exact (Finset.card_le_card hsub).trans (hlabels.trans hcount)

end MonotoneMatching
