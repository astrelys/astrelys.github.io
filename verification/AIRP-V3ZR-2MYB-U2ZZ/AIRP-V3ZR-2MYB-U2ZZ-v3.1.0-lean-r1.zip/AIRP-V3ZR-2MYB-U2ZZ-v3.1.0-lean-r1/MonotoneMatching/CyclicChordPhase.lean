import MonotoneMatching.CycleArgumentBridge
import Mathlib.Algebra.Group.Fin.Basic

/-! Integer-gap chord loops have exactly the corresponding cyclic pair-increment sums. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval BigOperators
open Fin.NatCast

theorem closedCyclePath_nat_edge {m : ℕ} [NeZero m] (v : Fin m → ℂ)
    (k : ℕ) {s : ℝ} (hs : s∈Set.Icc (0:ℝ) 1) :
    periodicPolygonPath (closedCycleVertices v) ((k:ℝ)+s)=
      (1-s) • v (↑k:Fin m)+s • v (finRotate m (↑k:Fin m)) := by
  have hm : 0<m := Nat.pos_of_ne_zero (NeZero.ne m)
  have hp := (periodicPolygonPath_periodic hm (closedCycleVertices v)).nat_mul (k/m)
  have he : (k:ℝ)+s=((↑k:Fin m).val:ℝ)+s+(k/m:ℕ)*(m:ℝ) := by
    have h := congrArg (fun n : ℕ => (n:ℝ)) (Nat.mod_add_div k m)
    simp only [Nat.cast_add,Nat.cast_mul] at h
    simp only [Fin.val_natCast]
    nlinarith
  rw [he,hp,periodicPolygonPath_on_closed_edge hm _ (closedCycleVertices_closed v) _ hs,
    closedCycleVertices_castSucc,closedCycleVertices_succ]

theorem closedCyclePath_add_edge {m : ℕ} [NeZero m] (v : Fin m → ℂ)
    (i d : Fin m) {s : ℝ} (hs : s∈Set.Icc (0:ℝ) 1) :
    periodicPolygonPath (closedCycleVertices v) ((i.val:ℝ)+s+d.val)=
      (1-s) • v (i+d)+s • v (finRotate m i+d) := by
  have he : (i.val:ℝ)+s+d.val=((i.val+d.val:ℕ):ℝ)+s := by push_cast; ring
  rw [he,closedCyclePath_nat_edge v _ hs]
  have hf : (↑(i.val+d.val):Fin m)=i+d := by simp
  rw [hf]
  have hh : finRotate m (i+d)=finRotate m i+d := by simp only [finRotate_apply]; ac_rfl
  rw [hh]

theorem cyclic_chord_phase_increment {m : ℕ} [NeZero m] (v : Fin m → ℂ)
    (hinj : Set.InjOn (periodicPolygonPath (closedCycleVertices v)) (Set.Ico (0:ℝ) m))
    (d : Fin m) (hd : d≠0) (φ : C(I,ℝ))
    (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg
      (periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ)+d.val)-
       periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ))) : Real.Angle)) :
    φ 1-φ 0=∑ i : Fin m, Complex.arg ((v (finRotate m i+d)-v (finRotate m i))/(v (i+d)-v i)) := by
  have hm : 0<m := Nat.pos_of_ne_zero (NeZero.ne m)
  have hd0 : (0:ℝ)<d.val := by exact_mod_cast (Fin.pos_iff_ne_zero.mpr hd)
  have hdm : (d.val:ℝ)<m := by exact_mod_cast d.isLt
  let w := fun i : Fin m => v (i+d)-v i
  let γ := fun s : I => periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ)+d.val)-
    periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ))
  have hn (s : I) : γ s≠0 := polygon_chord_ne_zero hm _ hinj ⟨hd0,hdm⟩ _
  have hedge (i : Fin m) (s : I) : γ (uniformArgumentSubparameter hm i s)=
      (1-(s:ℝ)) • closedCycleVertices w i.castSucc+(s:ℝ) • closedCycleVertices w i.succ := by
    have he : (m:ℝ)*(uniformArgumentSubparameter hm i s:ℝ)=(i.val:ℝ)+(s:ℝ) := by
      dsimp only [uniformArgumentSubparameter]
      field_simp
    dsimp only [γ]
    rw [he,closedCyclePath_add_edge v i d s.property,
      periodicPolygonPath_on_closed_edge hm _ (closedCycleVertices_closed v) i s.property,
      closedCycleVertices_castSucc,closedCycleVertices_succ,closedCycleVertices_castSucc,closedCycleVertices_succ]
    dsimp only [w]
    module
  have h := argument_increment_affine_subdivision hm γ hn (closedCycleVertices w) hedge φ hφ
  simpa only [closedCycleVertices_castSucc,closedCycleVertices_succ,w] using h

end MonotoneMatching
