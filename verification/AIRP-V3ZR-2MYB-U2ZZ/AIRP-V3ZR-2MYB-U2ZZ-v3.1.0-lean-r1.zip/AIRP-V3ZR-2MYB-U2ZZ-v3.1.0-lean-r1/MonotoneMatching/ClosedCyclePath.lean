import MonotoneMatching.PolygonChords
import MonotoneMatching.CyclicLabels
import MonotoneMatching.PolygonIndex

/-! Closed-edge evaluation and the periodic path of a cyclic vertex array. -/
noncomputable section
namespace MonotoneMatching

theorem periodicPolygonPath_on_closed_base {m : ℕ} (hm : 0<m)
    (v : Fin (m+1) → ℂ) (hclosed : v 0=v (Fin.last m)) {t : ℝ}
    (ht : t∈Set.Icc (0:ℝ) m) : periodicPolygonPath v t=polygonInterpolation v t := by
  by_cases hlt : t<(m:ℝ)
  · exact periodicPolygonPath_on_base hm v ⟨ht.1,hlt⟩
  have he : t=(m:ℝ) := le_antisymm ht.2 (le_of_not_gt hlt)
  rw [he]
  have hp := periodicPolygonPath_periodic hm v 0
  rw [zero_add] at hp
  rw [hp,periodicPolygonPath_on_base hm v ⟨le_rfl,Nat.cast_pos.mpr hm⟩,
    polygonInterpolation_zero hm,polygonInterpolation_last hm,hclosed]

theorem periodicPolygonPath_on_closed_edge {m : ℕ} (hm : 0<m)
    (v : Fin (m+1) → ℂ) (hclosed : v 0=v (Fin.last m)) (i : Fin m) {s : ℝ}
    (hs : s∈Set.Icc (0:ℝ) 1) :
    periodicPolygonPath v ((i.val:ℝ)+s)=(1-s) • v i.castSucc+s • v i.succ := by
  have hi : (i.val:ℝ)+1≤m := by exact_mod_cast i.isLt
  rw [periodicPolygonPath_on_closed_base hm v hclosed
    ⟨add_nonneg (Nat.cast_nonneg _) hs.1,by linarith [hs.2]⟩]
  exact polygonInterpolation_on_edge v i hs

def closedCycleVertices {m : ℕ} [NeZero m] (v : Fin m → ℂ) : Fin (m+1) → ℂ :=
  Fin.lastCases (v 0) v

theorem closedCycleVertices_castSucc {m : ℕ} [NeZero m] (v : Fin m → ℂ) (i : Fin m) :
    closedCycleVertices v i.castSucc=v i := by simp [closedCycleVertices]

theorem closedCycleVertices_closed {m : ℕ} [NeZero m] (v : Fin m → ℂ) :
    closedCycleVertices v 0=closedCycleVertices v (Fin.last m) := by
  have he : (0:Fin (m+1))=(0:Fin m).castSucc := by apply Fin.ext; simp
  rw [he,closedCycleVertices_castSucc]
  simp [closedCycleVertices]

theorem closedCycleVertices_succ {m : ℕ} [NeZero m] (v : Fin m → ℂ) (i : Fin m) :
    closedCycleVertices v i.succ=v (finRotate m i) := by
  obtain ⟨k,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (NeZero.ne m)
  by_cases hi : i=Fin.last k
  · subst i
    simp [closedCycleVertices]
  · have he : (finRotate (k+1) i).castSucc=i.succ := by
      apply Fin.ext
      simpa only [Fin.val_castSucc,Fin.val_succ] using coe_finRotate_of_ne_last hi
    rw [← he,closedCycleVertices_castSucc]

theorem closedCyclePath_mem_boundary {m : ℕ} [NeZero m] (v : Fin m → ℂ) (t : ℝ) :
    periodicPolygonPath (closedCycleVertices v) t∈polygonBoundary (finRotate m) v := by
  have hm : 0<m := Nat.pos_of_ne_zero (NeZero.ne m)
  have ht := normalized_polygon_parameter_mem hm t
  obtain ⟨i,s,hs,he⟩ := exists_unit_edge_parameter ht
  rw [← periodicPolygonPath_normalized hm (closedCycleVertices v) t,he,
    periodicPolygonPath_on_edge hm _ i hs,closedCycleVertices_castSucc,closedCycleVertices_succ]
  apply Set.mem_iUnion.mpr
  refine ⟨i,?_⟩
  simpa only [AffineMap.lineMap_apply_module] using lineMap_mem_segment ℝ (v i) (v (finRotate m i)) ⟨hs.1,hs.2.le⟩

theorem closedCyclePath_relative_ne_zero {m : ℕ} [NeZero m] (v : Fin m → ℂ)
    {q : ℂ} (hq : q∉polygonBoundary (finRotate m) v) (t : ℝ) :
    periodicPolygonPath (closedCycleVertices v) t-q≠0 := by
  intro he
  exact hq (sub_eq_zero.mp he ▸ closedCyclePath_mem_boundary v t)

end MonotoneMatching
