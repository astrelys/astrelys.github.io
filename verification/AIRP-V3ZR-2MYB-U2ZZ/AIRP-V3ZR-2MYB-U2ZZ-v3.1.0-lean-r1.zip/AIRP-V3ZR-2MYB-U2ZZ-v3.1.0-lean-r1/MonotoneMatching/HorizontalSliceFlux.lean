import MonotoneMatching.CrossingEdgeEnumeration
import MonotoneMatching.MonotoneSlopeExtension
import MonotoneMatching.OrderedCrossingGaps
import MonotoneMatching.HorizontalJumpValues

/-! A nonpositive polygon index forces nonpositive dual-gradient flux on
every generic horizontal slice, by finite summation by parts. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

theorem horizontal_slice_flux_nonpos {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (h : ℝ) (hh : ∀ i, h≠(v i).im)
    {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ) (e : ι → Fin n) (he : Function.Injective e)
    (hedge : ∀ i, ∀ t∈Set.Ioo (0:ℝ) 1, (1-t) • v i+t • v (next i)∈strictDualCell a r (e i))
    (L R : ℝ) (hgap : L-R=2*Real.pi)
    (hL : ∀ i q, q∈strictDualCell a r (e i) → 0<edgeSide (v i) (v (next i)) q → polygonIndexPhase next v q=L)
    (hR : ∀ i q, q∈strictDualCell a r (e i) → edgeSide (v i) (v (next i)) q<0 → polygonIndexPhase next v q=R)
    (hphase : ∀ q, q∉polygonBoundary next v → polygonIndexPhase next v q≤0) :
    (∑ i, (a (e i)).re*sliceCrossingSign (v i).im (v (next i)).im h)≤0 := by
  classical
  let T := (finite_horizontal_polygon_crossings next v h hh).toFinset
  have hT (t : ℝ) : t∈T ↔ horizontalPoint t h∈polygonBoundary next v := Set.Finite.mem_toFinset _
  by_cases hnon : T.Nonempty
  swap
  · have hz (i : ι) : sliceCrossingSign (v i).im (v (next i)).im h=0 := by
      by_contra hn
      obtain ⟨x,hx⟩ := horizontal_segment_exists_of_crossing_sign (hh i) (hh (next i)) hn
      exact hnon ⟨x,(hT x).mpr (Set.mem_iUnion.mpr ⟨i,hx⟩)⟩
    simp only [hz,mul_zero,Finset.sum_const_zero,le_refl]
  let : NeZero T.card := ⟨Nat.ne_of_gt (Finset.card_pos.mpr hnon)⟩
  obtain ⟨b,hb⟩ := (Set.finite_range (fun i => (v i).re)).bddAbove
  let top := b+1
  have htopv (i : ι) : (v i).re<top := by have hi := hb (Set.mem_range_self i); dsimp [top]; linarith
  have htopT (x : ℝ) (hx : x∈T) : x<top := by
    obtain ⟨i,hi⟩ := Set.mem_iUnion.mp ((hT x).mp hx)
    rw [segment_eq_image] at hi
    obtain ⟨t,ht,heq⟩ := hi
    have hr := congrArg Complex.re heq
    simp only [horizontalPoint,Complex.add_re,Complex.smul_re,smul_eq_mul] at hr
    have hb0 := hb (Set.mem_range_self i)
    have hb1 := hb (Set.mem_range_self (next i))
    have h0 := mul_nonneg (sub_nonneg.mpr ht.2) (sub_nonneg.mpr hb0)
    have h1 := mul_nonneg ht.1 (sub_nonneg.mpr hb1)
    dsimp [top]
    nlinarith
  obtain ⟨x,gap,hx,hcover,htop,hbet,hleft,hright⟩ := ordered_crossing_gap_samples T top htopT
  have hcoverB (t : ℝ) : horizontalPoint t h∈polygonBoundary next v ↔ ∃ k, x k=t :=
    (hT t).symm.trans (hcover t)
  obtain ⟨edge,hedgeinj,hedgemem,hcell,hedgesurj⟩ := horizontal_crossing_edge_enumeration
    next v h hh a r e he hedge x hx.injective hcoverB
  let F : Fin (T.card+1) → ℝ := fun i => polygonIndexPhase next v (horizontalPoint (gap i) h)
  have hFlast : F (Fin.last T.card)=0 := by
    dsimp only [F]
    rw [htop]
    exact polygonIndexPhase_zero_right next v _ htopv
  have hF0 : F 0=0 := by
    obtain ⟨u,hug,hu⟩ := exists_horizontal_exterior_left v (gap 0)
    have hfirst : gap 0<x (0:Fin T.card) := by simpa using (hbet (0:Fin T.card)).1
    have havoid : ∀ t∈Set.Icc u (gap 0), horizontalPoint t h∉polygonBoundary next v := by
      intro t ht hb'
      obtain ⟨k,hk⟩ := (hcoverB t).mp hb'
      have hle := hx.monotone (Fin.zero_le k)
      rw [hk] at hle
      linarith [ht.2]
    have heq := polygonIndexPhase_horizontal_constant next v h
      (convex_Icc (𝕜 := ℝ) u (gap 0)).isPreconnected havoid
      (show u∈Set.Icc u (gap 0) from ⟨le_rfl,hug.le⟩)
      (show gap 0∈Set.Icc u (gap 0) from ⟨hug.le,le_rfl⟩)
    change polygonIndexPhase next v (horizontalPoint (gap 0) h)=0
    rw [← heq]
    exact polygonIndexPhase_zero_left next v _ hu
  have hF (j : Fin (T.card+1)) : F j≤0 := by
    refine Fin.lastCases ?_ (fun i => ?_) j
    · exact hFlast.le
    · apply hphase
      intro hb'
      exact hleft i (gap i.castSucc) ⟨le_rfl,(hbet i).1⟩ ((hT _).mpr hb')
  let g : Fin T.card → ℝ := fun i => (a (e (edge i))).re
  have hg : Monotone g := by
    intro i j hij
    by_cases heq : i=j
    · rw [heq]
    have hxij := hx (lt_of_le_of_ne hij heq)
    have hrow : e (edge j)≠e (edge i) := he.ne (hedgeinj.ne (Ne.symm heq))
    exact horizontal_dual_slopes_monotone a r (e (edge i)) (e (edge j)) hxij
      ((hcell i) _ hrow).le ((hcell j) _ hrow.symm).le
  obtain ⟨M,hM⟩ := (Set.finite_range g).bddAbove
  let G : Fin (T.card+1) → ℝ := Fin.lastCases M g
  have hG : Monotone G := monotone_lastCases_upper g hg M (fun i => hM (Set.mem_range_self i))
  have hGcast (i : Fin T.card) : G i.castSucc=g i := by simp [G]
  have hjump (i : Fin T.card) : F i.castSucc-F i.succ =
      sliceCrossingSign (v (edge i)).im (v (next (edge i))).im h*(2*Real.pi) := by
    have hdy := (horizontal_segment_crossing (hh (edge i)) (hh (next (edge i))) (hedgemem i)).1
    rw [sliceCrossingSign_at_segment (hh (edge i)) (hh (next (edge i))) (hedgemem i)]
    exact horizontal_coherent_jump next v h (isOpen_strictDualCell a r (e (edge i)))
      L R hgap (edge i) (hL (edge i)) (hR (edge i)) (hbet i).1 (hbet i).2
      (hedgemem i) (hcell i) hdy
      (fun t ht hb' => hleft i t ht ((hT t).mpr hb'))
      (fun t ht hb' => hright i t ht ((hT t).mpr hb'))
  have hsum := finite_jump_flux_nonpos G F hG hF hF0 hFlast
  have hfactor : (∑ i : Fin T.card, G i.castSucc*(F i.castSucc-F i.succ)) =
      (∑ i : Fin T.card, g i*sliceCrossingSign (v (edge i)).im (v (next (edge i))).im h)*(2*Real.pi) := by
    simp_rw [hGcast,hjump]
    rw [Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro i _
    ring
  rw [hfactor] at hsum
  have hnonpos : (∑ i : Fin T.card, g i*sliceCrossingSign (v (edge i)).im (v (next (edge i))).im h)≤0 := by
    nlinarith [Real.pi_pos]
  have hreindex := Fintype.sum_of_injective edge hedgeinj
    (fun i => g i*sliceCrossingSign (v (edge i)).im (v (next (edge i))).im h)
    (fun i => (a (e i)).re*sliceCrossingSign (v i).im (v (next i)).im h)
    (by
      intro i hi
      have hz : sliceCrossingSign (v i).im (v (next i)).im h=0 := by
        by_contra hn
        exact hi (hedgesurj i hn)
      rw [hz,mul_zero]) (fun _ => rfl)
  rwa [hreindex] at hnonpos

end MonotoneMatching
