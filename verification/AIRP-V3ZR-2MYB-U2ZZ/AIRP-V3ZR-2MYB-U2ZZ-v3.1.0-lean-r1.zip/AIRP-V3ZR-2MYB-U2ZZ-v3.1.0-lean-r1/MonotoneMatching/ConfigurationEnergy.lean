import MonotoneMatching.RotationScore
import Mathlib.Tactic.Positivity

/-! Equal-energy permutation configurations have no real-collinear triples. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

def configurationEnergy {n : ℕ} (x : Fin n → ℂ) : ℝ :=
  ∑ i, ((x i).re^2 + (x i).im^2)

theorem configurationEnergy_nonneg {n : ℕ} (x : Fin n → ℂ) :
    0 ≤ configurationEnergy x := by
  exact Finset.sum_nonneg (fun i _ => add_nonneg (sq_nonneg _) (sq_nonneg _))

theorem configurationEnergy_pos {n : ℕ} (x : Fin n → ℂ) (hx : x ≠ 0) :
    0 < configurationEnergy x := by
  classical
  obtain ⟨i,hi⟩ : ∃ i, x i ≠ 0 := by
    by_contra h
    push Not at h
    exact hx (funext h)
  have hp : 0 < (x i).re^2 + (x i).im^2 := by
    by_contra h
    have hr : (x i).re = 0 := by nlinarith [sq_nonneg (x i).re, sq_nonneg (x i).im]
    have hm : (x i).im = 0 := by nlinarith [sq_nonneg (x i).re, sq_nonneg (x i).im]
    exact hi (Complex.ext hr hm)
  exact hp.trans_le (Finset.single_le_sum
    (fun j _ => add_nonneg (sq_nonneg (x j).re) (sq_nonneg (x j).im)) (Finset.mem_univ i))

theorem configurationEnergy_permute {n : ℕ} (x : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) : configurationEnergy (x ∘ σ) = configurationEnergy x := by
  exact Equiv.sum_comp σ (fun i => (x i).re^2 + (x i).im^2)

/-- The energy along a real affine line is a quadratic with a strictly positive
quadratic coefficient whenever its endpoints differ. -/
theorem configurationEnergy_line {n : ℕ} (x y : Fin n → ℂ) (r : ℝ) :
    configurationEnergy (x + r • (y-x)) = configurationEnergy x +
      r * (configurationEnergy y - configurationEnergy x) +
      r * (r-1) * configurationEnergy (y-x) := by
  unfold configurationEnergy
  simp only [← Finset.sum_sub_distrib, Finset.mul_sum, ← Finset.sum_add_distrib,
    Pi.add_apply, Pi.sub_apply, Pi.smul_apply, Complex.add_re, Complex.add_im,
    Complex.sub_re, Complex.sub_im, Complex.smul_re, Complex.smul_im]
  apply Finset.sum_congr rfl
  intro i _
  simp only [smul_eq_mul]
  ring

/-- Three distinct configurations of the same energy cannot be real-collinear. -/
theorem equal_energy_not_real_collinear {n : ℕ} (x y z : Fin n → ℂ)
    (hxy : x ≠ y) (hxz : x ≠ z) (hyz : y ≠ z)
    (hy : configurationEnergy y = configurationEnergy x)
    (hz : configurationEnergy z = configurationEnergy x) :
    ¬∃ r : ℝ, z-x = r • (y-x) := by
  rintro ⟨r,hr⟩
  have he : z = x + r • (y-x) := by rw [← hr]; abel
  have hp : 0 < configurationEnergy (y-x) :=
    configurationEnergy_pos _ (sub_ne_zero.mpr hxy.symm)
  have hid := configurationEnergy_line x y r
  rw [← he, hy, hz] at hid
  have hzero : r * (r-1) * configurationEnergy (y-x) = 0 := by linarith
  have hr01 : r = 0 ∨ r = 1 := by
    have h := (mul_eq_zero.mp hzero).resolve_right (ne_of_gt hp)
    rcases mul_eq_zero.mp h with h | h
    · exact Or.inl h
    · exact Or.inr (by linarith)
  rcases hr01 with h | h
  · apply hxz
    simpa [h] using he.symm
  · apply hyz
    simpa [h] using he.symm

end MonotoneMatching
