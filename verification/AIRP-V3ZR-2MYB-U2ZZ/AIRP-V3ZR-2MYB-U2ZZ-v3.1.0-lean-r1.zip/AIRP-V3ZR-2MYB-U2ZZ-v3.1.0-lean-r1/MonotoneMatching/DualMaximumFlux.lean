import MonotoneMatching.DualMaximumSmoothing
import MonotoneMatching.SmoothConvexFlux
noncomputable section
namespace MonotoneMatching
open MeasureTheory ContinuousLinearMap Set Filter
open scoped BigOperators InnerProductSpace Topology
set_option backward.isDefEq.respectTransparency.types false

/-- The integral of a fixed row against the derivative of a velocity field is
the actual difference of that field at the edge endpoints. -/
theorem affine_row_velocity_integral (A : ℂ →L[ℝ] ℝ) (v : ℂ → ℂ)
    (V : ℂ → ℂ →L[ℝ] ℂ) (hV : Continuous V) (hv : ∀ p,HasFDerivAt v (V p) p) (z w : ℂ) :
    (∫ t in (0:ℝ)..1,A (V ((1-t) • z+t • w) (w-z)))=A (v w-v z) := by
  have hc : Continuous (fun t : ℝ => (1-t) • z+t • w) := by fun_prop
  have hd (t : ℝ) : HasDerivAt (fun t : ℝ => A (v ((1-t) • z+t • w)))
      (A (V ((1-t) • z+t • w) (w-z))) t := by
    have hp : HasDerivAt (fun t : ℝ => (1-t) • z+t • w) (w-z) t := by
      simpa only [Pi.add_def,Pi.sub_def,Pi.neg_apply,id_eq,one_smul,zero_sub,zero_add,neg_smul,
        sub_eq_add_neg,add_comm] using!
        (((hasDerivAt_const t (1:ℝ)).sub (hasDerivAt_id t)).smul_const z).add
          ((hasDerivAt_id t).smul_const w)
    exact A.hasFDerivAt.comp_hasDerivAt t ((hv _).comp_hasDerivAt t hp)
  have hi : Continuous (fun t : ℝ => A (V ((1-t) • z+t • w) (w-z))) := A.continuous.comp ((hV.comp hc).clm_apply continuous_const)
  have hh := intervalIntegral.integral_eq_sub_of_hasDerivAt (a := 0) (b := 1)
    (fun t _ => hd t) (hi.intervalIntegrable _ _)
  simpa [map_sub] using hh

/-- Convex flux for the actual finite affine maximum, proved by smooth
approximation and dominated convergence along its strict-cell edges. -/
theorem smooth_velocity_dual_polygon_flux_nonpos {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (y : ι → ℂ)
    {n : ℕ} [Nonempty (Fin n)] (a : Fin n → ℂ) (r : Fin n → ℝ)
    (e : ι → Fin n) (he : Function.Injective e)
    (hedge : ∀ i, ∀ t∈Ioo (0:ℝ) 1, (1-t) • y i+t • y (next i)∈strictDualCell a r (e i))
    (L R : ℝ) (hgap : L-R=2*Real.pi)
    (hL : ∀ i q, q∈strictDualCell a r (e i) → 0<edgeSide (y i) (y (next i)) q → polygonIndexPhase next y q=L)
    (hR : ∀ i q, q∈strictDualCell a r (e i) → edgeSide (y i) (y (next i)) q<0 → polygonIndexPhase next y q=R)
    (hphase : ∀ q, q∉polygonBoundary next y → polygonIndexPhase next y q≤0)
    (v : ℂ → ℂ) (hv : ContDiff ℝ (⊤:ℕ∞) v)
    (hmono : ∀ p z,0 ≤ inner ℝ z (Complex.I*fderiv ℝ v p z)) :
    (∑ i,inner ℝ (a (e i)) (v (y (next i))-v (y i))) ≤ 0 := by
  obtain ⟨K,g,hg,hconv,hbound,hlim⟩ := exists_smooth_dualMaximum_sequence a r
  let V := fderiv ℝ v
  have hVs : ContDiff ℝ (⊤:ℕ∞) V := hv.fderiv_right (by simp)
  have hv' (p : ℂ) : HasFDerivAt v (V p) p := (hv.differentiable (by simp) p).hasFDerivAt
  have hV' (p : ℂ) : HasFDerivAt V (fderiv ℝ V p) p := (hVs.differentiable (by simp) p).hasFDerivAt
  have hboundFlux (k : ℕ) : (∑ i,∫ t in (0:ℝ)..1,
      fderiv ℝ (g k) ((1-t) • y i+t • y (next i))
        (V ((1-t) • y i+t • y (next i)) (y (next i)-y i))) ≤ 0 := by
    have hgs : ContDiff ℝ (⊤:ℕ∞) (fderiv ℝ (g k)) := (hg k).fderiv_right (by simp)
    exact smooth_convex_velocity_polygon_flux_nonpos next y a r e he hedge L R hgap hL hR hphase
      (g k) (fderiv ℝ (g k)) (fderiv ℝ (fderiv ℝ (g k))) v V (fderiv ℝ V)
      (hconv k) hgs.continuous (hgs.continuous_fderiv (by simp))
      hVs.continuous (hVs.continuous_fderiv (by simp))
      (fun p => ((hg k).differentiable (by simp) p).hasFDerivAt)
      (fun p => (hgs.differentiable (by simp) p).hasFDerivAt) hv' hV' hmono
  have ht (i : ι) := affine_edge_gradient_integral_limit g hg K hbound (innerSL ℝ (a (e i)))
    (y i) (y (next i)) V hVs.continuous (fun t ht => hlim (e i) _ (hedge i t ht))
  have heq (i : ι) : (∫ t in (0:ℝ)..1,(innerSL ℝ (a (e i)))
      (V ((1-t) • y i+t • y (next i)) (y (next i)-y i)))=
      inner ℝ (a (e i)) (v (y (next i))-v (y i)) :=
    affine_row_velocity_integral (innerSL ℝ (a (e i))) v V hVs.continuous hv' _ _
  simp_rw [heq] at ht
  exact le_of_tendsto (tendsto_finsetSum Finset.univ (fun i _ => ht i))
    (Eventually.of_forall hboundFlux)

end MonotoneMatching
