import MonotoneMatching.CompactParametricIntegral
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.MeasureTheory.Integral.Bochner.Set
noncomputable section
namespace MonotoneMatching
open MeasureTheory Set
open scoped Topology Interval
set_option backward.isDefEq.respectTransparency.types false

/-- Continuous planar parameters commute with integration over the fixed unit interval. -/
theorem continuous_unit_interval_integral (F : ℂ → ℝ → ℝ)
    (hF : Continuous (Function.uncurry F)) :
    Continuous (fun p => ∫ t in (0:ℝ)..1,F p t) := by
  simp_rw [intervalIntegral.integral_of_le (by norm_num : (0:ℝ) ≤ 1),← integral_Icc_eq_integral_Ioc]
  exact continuous_parametric_integral_of_continuous hF isCompact_Icc

/-- The vertical coefficient of a horizontal primitive is continuous. -/
theorem continuous_horizontal_primitive_vertical (DP : ℂ → ℂ →L[ℝ] ℝ) (hDP : Continuous DP) :
    Continuous (fun p : ℂ => ∫ x in (0:ℝ)..p.re,DP ((x:ℂ)+(p.im:ℂ)*Complex.I) Complex.I) := by
  simp_rw [← horizontal_primitive_vertical_coefficient DP]
  apply continuous_unit_interval_integral
  have hc : Continuous (fun z : ℂ × ℝ => horizontalScaling z.2 z.1) :=
    (continuous_horizontalScaling.comp continuous_snd).clm_apply continuous_fst
  exact (Complex.continuous_re.comp continuous_fst).mul
    ((hDP.comp hc).clm_apply continuous_const)

/-- Removing a horizontal primitive turns nonnegative curl into horizontal monotonicity. -/
theorem nonnegative_curl_reduced_weight_monotone
    (Q : ℂ → ℝ) (DP DQ : ℂ → ℂ →L[ℝ] ℝ) (hDP : Continuous DP)
    (hdQ : ∀ p,HasFDerivAt Q (DQ p) p)
    (hcurl : ∀ p,0 ≤ DQ p 1-DP p Complex.I) (y : ℝ) :
    Monotone (fun x : ℝ => Q ((x:ℂ)+(y:ℂ)*Complex.I)-
      ∫ t in (0:ℝ)..x,DP ((t:ℂ)+(y:ℂ)*Complex.I) Complex.I) := by
  have hc : Continuous (fun t : ℝ => DP ((t:ℂ)+(y:ℂ)*Complex.I) Complex.I) :=
    (hDP.comp (Complex.continuous_ofReal.add continuous_const)).clm_apply continuous_const
  have hd (x : ℝ) : HasDerivAt (fun x : ℝ => Q ((x:ℂ)+(y:ℂ)*Complex.I)-
      ∫ t in (0:ℝ)..x,DP ((t:ℂ)+(y:ℂ)*Complex.I) Complex.I)
      (DQ ((x:ℂ)+(y:ℂ)*Complex.I) 1-DP ((x:ℂ)+(y:ℂ)*Complex.I) Complex.I) x := by
    have hz : HasDerivAt (fun x : ℝ => (x:ℂ)+(y:ℂ)*Complex.I) 1 x := by
      simpa using Complex.ofRealCLM.hasFDerivAt.hasDerivAt.add_const ((y:ℂ)*Complex.I)
    exact ((hdQ _).comp_hasDerivAt x hz).sub (hc.integral_hasStrictDerivAt 0 x).hasDerivAt
  apply monotone_of_deriv_nonneg (fun x => (hd x).differentiableAt)
  intro x
  rw [(hd x).deriv]
  exact hcurl _

end MonotoneMatching
