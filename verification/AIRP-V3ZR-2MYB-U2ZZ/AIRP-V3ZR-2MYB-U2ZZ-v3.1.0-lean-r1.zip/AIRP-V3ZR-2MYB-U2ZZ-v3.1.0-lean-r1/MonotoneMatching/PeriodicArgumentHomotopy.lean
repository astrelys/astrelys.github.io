import MonotoneMatching.PolygonChords

/-! Exact loop increments under degree-one time changes and ordered-pair
homotopies inside the noncolliding chord strip. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval

theorem periodic_argument_increment_reparam (γ : ℝ → ℂ) (hc : Continuous γ)
    (P : ℝ) (hp : Function.Periodic γ P) (hn : ∀ t, γ t≠0)
    (a : I → ℝ) (ha : Continuous a) (hend : a 1=a 0+P)
    (φ ψ : C(I,ℝ))
    (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg (γ (P*(s:ℝ))) : Real.Angle))
    (hψ : ∀ s, (ψ s : Real.Angle)=(Complex.arg (γ (a s)) : Real.Angle)) :
    φ 1-φ 0=ψ 1-ψ 0 := by
  let H := fun p : I×I => γ ((1-(p.1:ℝ))*P*(p.2:ℝ)+(p.1:ℝ)*a p.2)
  have hcont : Continuous H := by apply hc.comp; fun_prop
  have hnon (p : I×I) : H p≠0 := hn _
  have hloop (r : I) : H (r,1)=H (r,0) := by
    dsimp [H]
    rw [hend]
    convert hp ((r:ℝ)*a 0) using 1 <;> congr 1 <;> ring
  apply argument_loop_increment_homotopy H hcont hnon hloop φ ψ
  · intro s; simpa [H] using hφ s
  · intro s; simpa [H] using hψ s

/-- Any degree-one ordered-pair path inside 0 < second-first < period has
the same chord increment as a standard constant-offset chord loop. -/
theorem polygon_chord_strip_increment {m : ℕ} (hm : 0<m)
    (v : Fin (m+1) → ℂ) (hclosed : v 0=v (Fin.last m))
    (hinj : Set.InjOn (periodicPolygonPath v) (Set.Ico (0:ℝ) m))
    {d : ℝ} (hd : d∈Set.Ioo (0:ℝ) m)
    (a b : I → ℝ) (ha : Continuous a) (hb : Continuous b)
    (hproper : ∀ s, b s-a s∈Set.Ioo (0:ℝ) m)
    (haend : a 1=a 0+m) (hbend : b 1=b 0+m)
    (φ ψ : C(I,ℝ))
    (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg
      (periodicPolygonPath v ((m:ℝ)*(s:ℝ)+d)-periodicPolygonPath v ((m:ℝ)*(s:ℝ))) : Real.Angle))
    (hψ : ∀ s, (ψ s : Real.Angle)=(Complex.arg
      (periodicPolygonPath v (b s)-periodicPolygonPath v (a s)) : Real.Angle)) :
    φ 1-φ 0=ψ 1-ψ 0 := by
  let A := fun p : I×I => (1-(p.1:ℝ))*(m:ℝ)*(p.2:ℝ)+(p.1:ℝ)*a p.2
  let B := fun p : I×I => (1-(p.1:ℝ))*((m:ℝ)*(p.2:ℝ)+d)+(p.1:ℝ)*b p.2
  let H := fun p : I×I => periodicPolygonPath v (B p)-periodicPolygonPath v (A p)
  have hoff (p : I×I) : B p-A p∈Set.Ioo (0:ℝ) m := by
    have he : B p-A p=(1-(p.1:ℝ))*d+(p.1:ℝ)*(b p.2-a p.2) := by dsimp [A,B]; ring
    rw [he]
    simpa only [smul_eq_mul] using (convex_Ioo (𝕜 := ℝ) (0:ℝ) (m:ℝ)) hd (hproper p.2)
      (sub_nonneg.mpr p.1.property.2) p.1.property.1 (show (1-(p.1:ℝ))+(p.1:ℝ)=1 by ring)
  have hcont : Continuous H := by
    apply Continuous.sub
    · apply (continuous_periodicPolygonPath hm v hclosed).comp
      dsimp [B]; fun_prop
    · apply (continuous_periodicPolygonPath hm v hclosed).comp
      dsimp [A]; fun_prop
  have hnon (p : I×I) : H p≠0 := by
    have h := polygon_chord_ne_zero hm v hinj (hoff p) (A p)
    simpa only [add_sub_cancel] using h
  have hloop (r : I) : H (r,1)=H (r,0) := by
    have hA : A (r,1)=A (r,0)+m := by dsimp [A]; rw [haend]; ring
    have hB : B (r,1)=B (r,0)+m := by dsimp [B]; rw [hbend]; ring
    dsimp only [H]
    rw [hA,hB,periodicPolygonPath_periodic hm v,periodicPolygonPath_periodic hm v]
  apply argument_loop_increment_homotopy H hcont hnon hloop φ ψ
  · intro s; simpa [H,A,B] using hφ s
  · intro s; simpa [H,A,B] using hψ s

end MonotoneMatching
