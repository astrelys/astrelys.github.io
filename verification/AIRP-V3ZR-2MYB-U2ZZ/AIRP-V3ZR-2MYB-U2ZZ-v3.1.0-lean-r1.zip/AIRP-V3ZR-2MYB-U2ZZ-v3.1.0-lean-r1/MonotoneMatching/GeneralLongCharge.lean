import MonotoneMatching.GeneralOrientation
import MonotoneMatching.ExactLongCycleCharge
noncomputable section
namespace MonotoneMatching
open scoped BigOperators InnerProductSpace
set_option backward.isDefEq.respectTransparency.types false

/-- The positive-index witness follows from actual clockwise velocities and a
positive transverse score derivative. -/
theorem general_long_cycle_positive_witness {n : ℕ} (a y u : Fin n → ℂ)
    (π : Equiv.Perm (Fin n)) (hπ : π.IsCycle) (hlen : 3 ≤ π.support.card)
    (hmax : ∀ τ,assignmentScore a y τ ≤ assignmentScore a y (Equiv.refl _))
    (heq : assignmentScore a y π=assignmentScore a y (Equiv.refl _))
    (htwo : ∀ τ,assignmentScore a y τ=assignmentScore a y (Equiv.refl _) → τ=Equiv.refl _ ∨ τ=π)
    (hmono : ∀ i j,0 ≤ inner ℝ (y i-y j) (Complex.I*(u i-u j)))
    (hD : 0<assignmentScore a u π-assignmentScore a u (Equiv.refl _)) :
    ∃ q : ℂ,(∀ i,π i≠i → q∉segment ℝ (y i) (y (π i))) ∧
      0<∑ i,Complex.arg ((y (π i)-q)/(y i-q)) := by
  classical
  have hpair := long_tie_strictPairMonotone a y π hlen hmax htwo
  have hy := strictPairMonotone_injective_right a y hpair
  obtain ⟨r,c,hbound,hexact⟩ := exists_exact_dual_support
    (fun i j => inner ℝ (a i) (y j)) π hmax heq htwo
  let m := π.support.card
  have hm : 0<m := by dsimp [m]; omega
  have hm2 : 2≤m := by dsimp [m]; omega
  let : NeZero m := ⟨Nat.ne_of_gt hm⟩
  obtain ⟨E,hE⟩ := exists_ordered_cycle_enumeration π hπ
  let e : Fin m → Fin n := fun i => (E i).val
  let v := y∘e
  have he : Function.Injective e := fun i j h => E.injective (Subtype.ext h)
  have hsucc (i : Fin m) : e (finRotate m i)=π (e i) := hE i
  have hmove (i : Fin m) : π (e i)≠e i := Equiv.Perm.mem_support.mp (E i).property
  have h2 (i : Fin m) : π (π (e i))≠e i := long_cycle_no_two_step π hπ hlen (hmove i)
  have hcover (i : Fin n) (hi : π i≠i) : ∃ j, e j=i := by
    obtain ⟨j,hj⟩ := E.surjective ⟨i,Equiv.Perm.mem_support.mpr hi⟩
    exact ⟨j,congrArg Subtype.val hj⟩
  have htrans (i j : Fin m) : ∃ k : ℕ, (finRotate m^k) i=j := by
    have hx (x : Fin m) : finRotate m x≠x := Equiv.Perm.mem_support.mp
      (by rw [support_finRotate_of_le hm2]; exact Finset.mem_univ _)
    exact (isCycle_finRotate_of_le hm2).exists_pow_eq (hx i) (hx j)
  have hfixed (j : Fin n) (hj : j∉Set.range e) : π j=j := by
    by_contra h
    exact hj (hcover j h)
  have hindex (q : ℂ) : (∑ i,Complex.arg ((y (π i)-q)/(y i-q)))=
      polygonIndexPhase (finRotate m) v q := by
    rw [sum_injection_complement e he]
    have hz : (∑ i : Fin n, if i∈Set.range e then 0 else
        Complex.arg ((y (π i)-q)/(y i-q)))=0 := by
      apply Finset.sum_eq_zero
      intro i _
      by_cases hi : i∈Set.range e
      · simp [hi]
      · rw [ite_eq_right hi,hfixed i hi]
        by_cases hq : y i-q=0 <;> simp [hq]
    rw [hz,add_zero]
    unfold polygonIndexPhase polygonPhase
    apply Finset.sum_congr rfl
    intro i _
    simp only [v,Function.comp_def,hsucc]
  obtain ⟨hL,hR,hvalues⟩ := general_positive_transition_polygon_winding (finRotate m) htrans a y u hy π r c
    hbound hexact e he hsucc hmove h2 hcover hmono hD
  have hactive (i : Fin m) (t : ℝ) (ht : t∈Set.Icc (0:ℝ) 1) (j : Fin n) :
      dualRow a r j ((1-t) • v i+t • v (finRotate m i))≤
        dualRow a r (e i) ((1-t) • v i+t • v (finRotate m i)) := by
    simpa only [v,Function.comp_def,hsucc] using transition_closed_edge_row_max a y π r c hbound hexact (e i) j ht
  have hmid : edgeCrossPoint (v 0) (v (finRotate m 0)) (1/2) 0∈strictDualCell a r (e 0) := by
    rw [edgeCrossPoint_zero_offset]
    intro j hj
    simpa only [v,Function.comp_def,hsucc] using transition_edge_unique_row a y π r c hbound hexact
      (e 0) (h2 0) j hj (by norm_num : (0:ℝ)<1/2) (by norm_num : (1/2:ℝ)<1)
  have hne : v 0≠v (finRotate m 0) := by
    dsimp only [v,Function.comp_def]
    rw [hsucc]
    exact hy.ne (hmove 0).symm
  obtain ⟨q,hq,hq0⟩ := exists_nonzero_polygon_index_of_cell_sides (finRotate m) v 0 hne
    (isOpen_strictDualCell a r (e 0)) hmid
    (fun q hq hb => strictDualCell_polygon_boundary_subset (finRotate m) v a r e he hactive 0 hq hb)
    (2*Real.pi) 0 (by ring) (hL 0) (hR 0)
  refine ⟨q,?_,?_⟩
  · intro i hi hs
    obtain ⟨j,rfl⟩ := hcover i hi
    apply hq
    apply Set.mem_iUnion.mpr ⟨j,?_⟩
    simpa only [v,Function.comp_def,hsucc] using hs
  · rw [hindex]
    rcases hvalues q hq with h | h
    · exact (hq0 h).elim
    · rw [h]; exact Real.two_pi_pos

/-- Exact long-cycle charge for general clockwise data, with the orientation
hypothesis fully discharged. -/
theorem general_long_cycle_phase_charge {n : ℕ} (a y u : Fin n → ℂ)
    (π : Equiv.Perm (Fin n)) (hπ : π.IsCycle) (hlen : 3 ≤ π.support.card)
    (hmax : ∀ τ,assignmentScore a y τ ≤ assignmentScore a y (Equiv.refl _))
    (heq : assignmentScore a y π=assignmentScore a y (Equiv.refl _))
    (htwo : ∀ τ,assignmentScore a y τ=assignmentScore a y (Equiv.refl _) → τ=Equiv.refl _ ∨ τ=π)
    (hmono : ∀ i j,0 ≤ inner ℝ (y i-y j) (Complex.I*(u i-u j)))
    (hD : 0<assignmentScore a u π-assignmentScore a u (Equiv.refl _)) :
    identityPhase a (y∘π)-identityPhase a y=Real.pi*((π.support.card:ℝ)-1+
      2*((Finset.univ.filter (fun j => π j=j ∧
        (∑ i,Complex.arg ((y (π i)-y j)/(y i-y j)))=2*Real.pi)).card:ℝ)) :=
  exact_long_cycle_phase_charge_of_positive_index a y π hπ hlen hmax heq htwo
    (general_long_cycle_positive_witness a y u π hπ hlen hmax heq htwo hmono hD)

end MonotoneMatching
