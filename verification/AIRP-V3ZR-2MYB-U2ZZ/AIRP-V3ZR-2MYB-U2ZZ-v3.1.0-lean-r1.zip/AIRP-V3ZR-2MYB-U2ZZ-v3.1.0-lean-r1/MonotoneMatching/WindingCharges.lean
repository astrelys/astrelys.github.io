import MonotoneMatching.TrajectoryEvents
noncomputable section
namespace MonotoneMatching
open Set Filter
open scoped BigOperators InnerProductSpace Topology
set_option backward.isDefEq.respectTransparency.types false

/-- The ordered-pair determinant hypothesis implies the monotonicity condition
for all ordered pairs, including the reversed and diagonal cases. -/
theorem ordered_clockwise_data_monotone {n : ℕ} (y u : Fin n → ℂ)
    (hclock : ∀ i j,i<j → (y j-y i).re*(u j-u i).im-(y j-y i).im*(u j-u i).re≤0) :
    ∀ i j,0 ≤ inner ℝ (y i-y j) (Complex.I*(u i-u j)) := by
  apply clockwise_data_monotone
  intro i j
  rcases lt_trichotomy i j with h | rfl | h
  · have hh := hclock i j h
    have he : (y i-y j).re*(u i-u j).im-(y i-y j).im*(u i-u j).re=
        (y j-y i).re*(u j-u i).im-(y j-y i).im*(u j-u i).re := by
      simp only [Complex.sub_re,Complex.sub_im]
      ring
    rwa [he]
  · simp only [sub_self,Complex.zero_re,Complex.zero_im,zero_mul,le_refl]
  · exact hclock j i h

/-- Complete W4: actual generic optimal events have exact local charges and
sum to twice the physical pair winding. The finite event list is proved complete
and injective, and the period seam is represented exactly once. -/
def windingExactChargeStatement : Prop :=
  ∀ (n : ℕ),2≤n → ∀ (b v : Fin n → ℝ → ℂ) (T : ℝ),0<T →
    (∀ i t,HasDerivAt (b i) (v i t) t) → (∀ i,Continuous (v i)) →
    (∀ i,Function.Periodic (b i) T) → (∀ t,Function.Injective (fun i => b i t)) →
    (∀ i j,i<j → ∀ t,(b j t-b i t).re*(v j t-v i t).im-(b j t-b i t).im*(v j t-v i t).re≤0) →
    ∃ φ : Fin n → Fin n → ℝ → ℝ,∃ w : Fin n × Fin n → ℕ,
      (∀ i j,Continuous (φ i j)) ∧ (∀ i t,φ i i t=0) ∧
      (∀ i j,i≠j → ∀ t,(φ i j t:Real.Angle)=(Complex.arg (b j t-b i t):Real.Angle)) ∧
      (∀ p∈increasingPairs n,φ p.1 p.2 T-φ p.1 p.2 0= -(2*Real.pi)*(w p:ℝ)) ∧
    ∃ G : Set (Fin n → ℂ),IsOpen G ∧ Dense G ∧ ∀ a∈G,
      ∃ m : ℕ,0<m ∧ ∃ cut : Fin (m+1) → ℝ,∃ label : Fin m → Equiv.Perm (Fin n),
        StrictMono cut ∧ cut 0=0 ∧ cut (Fin.last m)=T ∧
        (∀ i,∀ t∈Ioo (cut i.castSucc) (cut i.succ),UniqueMinimum a (fun j => b j t) (label i)) ∧
        (∀ i,∀ t∈Icc (cut i.castSucc) (cut i.succ),∀ ρ,
          assignmentScore a (fun j => b j t) ρ≤assignmentScore a (fun j => b j t) (label i)) ∧
        (∀ t∈Icc 0 T,∀ σ,UniqueMinimum a (fun j => b j t) σ → ∃ i,label i=σ) ∧
        Function.Injective (trajectoryTransitionTime cut) ∧
        (∀ i,trajectoryTransitionTime cut i∈Ico (0:ℝ) T) ∧
        (∀ t∈Ico (0:ℝ) T,trajectoryOptimalTie a b t ↔
          ∃ i,trajectoryTransitionTime cut i=t ∧ label (finRotate m i)≠label i) ∧
        (∀ i,(label (finRotate m i)≠label i → ((label i)⁻¹*label (finRotate m i)).IsCycle ∧
          1≤trajectoryCellCharge b cut label i) ∧
          identityPhase a (fun j => b (label (finRotate m i) j) (cut (finRotate m i).castSucc))-
            identityPhase a (fun j => b (label i j) (cut i.succ))=
              Real.pi*(trajectoryCellCharge b cut label i:ℝ)) ∧
        (∑ i,trajectoryCellCharge b cut label i)=2*∑ p∈increasingPairs n,w p

/-- The complete exact-charge and winding-budget conclusion W4. -/
theorem winding_exact_charges : windingExactChargeStatement := by
  intro n _hn b v T hT hd hv hp hy hclock
  obtain ⟨φ,w,hφ,hzero,he,hw⟩ := exists_trajectory_winding_lifts b v T hT hd hp
    (fun i j hij t => (hy t).ne hij) hclock
  have hg := open_dense_genericTrajectorySources b v hd hv hy (Icc 0 T) isCompact_Icc
  refine ⟨φ,w,hφ,hzero,he,hw,{a | GenericTrajectorySources b v (Icc 0 T) a},hg.1,hg.2,?_⟩
  intro a ha
  obtain ⟨m,hm,cut,label,hmono,hfirst,hlast,hunique,hopt,hcover⟩ := exists_generic_trajectory_cells a b v hd T hT ha
  have hmon (t : ℝ) := ordered_clockwise_data_monotone (fun i => b i t) (fun i => v i t)
    (fun i j hij => hclock i j hij t)
  have henum := trajectory_event_enumeration a b v T hm hd hp ha cut label hmono hfirst hlast hunique hopt
  refine ⟨m,hm,cut,label,hmono,hfirst,hlast,hunique,hopt,hcover,henum.1,
    (fun i => trajectory_transition_time_mem hm cut T hmono hfirst hlast i),henum.2,?_,?_⟩
  · exact trajectory_cell_exact_charge a b v T hm hd hp hy hmon ha cut label hmono hfirst hlast hopt
  · exact trajectory_exact_charge_budget a b v T hT hm hd hp hy hmon ha cut label hmono hfirst hlast hopt φ w hφ hzero he hw

end MonotoneMatching
