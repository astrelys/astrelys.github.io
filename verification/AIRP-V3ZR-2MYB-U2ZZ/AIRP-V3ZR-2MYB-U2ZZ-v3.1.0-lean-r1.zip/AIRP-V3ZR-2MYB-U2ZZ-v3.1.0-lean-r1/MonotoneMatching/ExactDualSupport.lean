import MonotoneMatching.DualPotentials
import Mathlib.Topology.Instances.Real.Lemmas
import Mathlib.Tactic.FunProp

/-! Exact dual support at a two-assignment optimum. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

/-- A matrix score, independent of its later geometric realization. -/
def matrixAssignmentScore {α : Type*} [Fintype α] (w : α → α → ℝ)
    (σ : Equiv.Perm α) : ℝ := ∑ i, w i (σ i)

/-- Exact row and column potentials exist when identity and σ are precisely the
optimal assignments. Every unused edge has strictly positive dual slack. -/
theorem exists_exact_dual_support {α : Type*} [Fintype α] [DecidableEq α]
    (w : α → α → ℝ) (σ : Equiv.Perm α)
    (hmax : ∀ τ : Equiv.Perm α, matrixAssignmentScore w τ ≤ matrixAssignmentScore w (Equiv.refl _))
    (heq : matrixAssignmentScore w σ = matrixAssignmentScore w (Equiv.refl _))
    (htwo : ∀ τ : Equiv.Perm α,
      matrixAssignmentScore w τ = matrixAssignmentScore w (Equiv.refl _) →
      τ = Equiv.refl _ ∨ τ = σ) :
    ∃ r c : α → ℝ, (∀ i j, w i j ≤ r i + c j) ∧
      ∀ i j, r i + c j = w i j ↔ j = i ∨ j = σ i := by
  classical
  let d := fun (ε : ℝ) i j => w i j - w i i + if j = i ∨ j = σ i then 0 else ε
  have hzero (τ : Equiv.Perm α) : (∑ i, d 0 i (τ i)) =
      matrixAssignmentScore w τ - matrixAssignmentScore w (Equiv.refl _) := by
    simp [d, matrixAssignmentScore, Finset.sum_sub_distrib]
  have hstrict (τ : Equiv.Perm α) (hτ : τ ≠ Equiv.refl _) (hτσ : τ ≠ σ) :
      (∑ i, d 0 i (τ i)) < 0 := by
    rw [hzero, sub_neg]
    by_contra h
    have he := le_antisymm (hmax τ) (le_of_not_gt h)
    rcases htwo τ he with h | h
    · exact hτ h
    · exact hτσ h
  let U := {ε : ℝ | ∀ τ : Equiv.Perm α, τ ≠ Equiv.refl _ → τ ≠ σ → ∑ i, d ε i (τ i) < 0}
  have hU : IsOpen U := by
    dsimp [U]
    simp only [Set.ofPred_forall]
    apply isOpen_iInter_of_finite
    intro τ
    apply isOpen_iInter_of_finite
    intro _
    apply isOpen_iInter_of_finite
    intro _
    apply isOpen_lt _ continuous_const
    apply continuous_finsetSum
    intro i _
    dsimp [d]
    split_ifs <;> fun_prop
  have h0 : (0 : ℝ) ∈ U := hstrict
  obtain ⟨δ,hδ,hball⟩ := Metric.mem_nhds_iff.mp (hU.mem_nhds h0)
  let ε := δ/2
  have hε : 0 < ε := by dsimp [ε]; linarith
  have hεU : ε ∈ U := by
    apply hball
    rw [Metric.mem_ball, Real.dist_eq, sub_zero, abs_of_pos hε]
    dsimp [ε]; linarith
  have hdiag (i : α) : d ε i i = 0 := by simp [d]
  have hσ : (∑ i, d ε i (σ i)) = 0 := by
    simpa [d, matrixAssignmentScore, Finset.sum_sub_distrib] using sub_eq_zero.mpr heq
  have hall (τ : Equiv.Perm α) : (∑ i, d ε i (τ i)) ≤ 0 := by
    by_cases hτ : τ = Equiv.refl _
    · subst τ; simp [hdiag]
    by_cases hτσ : τ = σ
    · subst τ; exact hσ.le
    exact (hεU τ hτ hτσ).le
  obtain ⟨c,hc⟩ := exists_edge_potential_of_permutation_bound (d ε) hdiag hall
  let r := fun i => w i i - c i
  have hslack (i j : α) : (if j = i ∨ j = σ i then 0 else ε) ≤ r i + c j - w i j := by
    have h := hc i j
    dsimp [d,r] at h ⊢
    linarith
  have hn (i j : α) : 0 ≤ r i + c j - w i j := by
    have h := hslack i j
    split_ifs at h <;> linarith
  have hsum : (∑ i, (r i + c (σ i) - w i (σ i))) = 0 := by
    dsimp [r]
    simp only [Finset.sum_sub_distrib, Finset.sum_add_distrib]
    have hcperm := Equiv.sum_comp σ c
    have hw : (∑ i, w i (σ i)) = ∑ i, w i i := heq
    rw [hcperm,hw]
    ring
  have hσeq (i : α) : r i + c (σ i) = w i (σ i) := by
    have hle := Finset.single_le_sum (fun j _ => hn j (σ j)) (Finset.mem_univ i)
    rw [hsum] at hle
    linarith [hn i (σ i)]
  refine ⟨r,c,fun i j => by linarith [hn i j], ?_⟩
  intro i j
  constructor
  · intro he
    by_contra h
    have hh := hslack i j
    rw [ite_eq_right h,he,sub_self] at hh
    exact (not_le_of_gt hε) hh
  · rintro (rfl | rfl)
    · dsimp [r]; ring
    · exact hσeq i

end MonotoneMatching
