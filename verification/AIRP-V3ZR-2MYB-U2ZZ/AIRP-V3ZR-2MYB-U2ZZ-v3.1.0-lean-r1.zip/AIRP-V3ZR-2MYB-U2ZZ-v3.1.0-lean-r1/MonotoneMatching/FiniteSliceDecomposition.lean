import MonotoneMatching.FiniteFlux

/-! Exact finite horizontal-strip decomposition of polygon edge displacements.
No limiting argument or integral is needed for the flux identity. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

def sliceCrossingSign (u v h : ℝ) : ℝ := (if h<v then 1 else 0)-(if h<u then 1 else 0)

theorem clipped_strip_difference (lo hi t : ℝ) (hlt : lo<hi)
    (havoid : t∉Set.Ioo lo hi) :
    min hi t-min lo t=(hi-lo)*(if (lo+hi)/2<t then 1 else 0) := by
  by_cases hmid : (lo+hi)/2<t
  · have ht : hi≤t := by
      by_contra hn
      exact havoid ⟨by linarith,lt_of_not_ge hn⟩
    rw [min_eq_left ht,min_eq_left (hlt.le.trans ht),ite_eq_left hmid,mul_one]
  · have ht : t≤lo := by
      by_contra hn
      exact havoid ⟨lt_of_not_ge hn,by linarith [le_of_not_gt hmid]⟩
    rw [min_eq_right (ht.trans hlt.le),min_eq_right ht,ite_eq_right hmid]
    ring

/-- A height lying on the subdivision grid is recovered by summing the
widths of the strips below it. -/
theorem finite_slice_height_decomposition {m : ℕ} (cut : Fin (m+1) → ℝ)
    (hcut : StrictMono cut) (t : ℝ) (hlo : cut 0≤t) (hhi : t≤cut (Fin.last m))
    (havoid : ∀ i : Fin m, t∉Set.Ioo (cut i.castSucc) (cut i.succ)) :
    t-cut 0 = ∑ i : Fin m, (cut i.succ-cut i.castSucc)*
      (if (cut i.castSucc+cut i.succ)/2<t then 1 else 0) := by
  have h := subdivision_duration_sum (fun i => min (cut i) t)
  rw [min_eq_right hhi,min_eq_left hlo] at h
  rw [← h]
  apply Finset.sum_congr rfl
  intro i _
  exact clipped_strip_difference _ _ _ (hcut i.castSucc_lt_succ) (havoid i)

/-- Oriented edge height differences are sums of strip widths weighted by
the signed crossing of each strip's midpoint. -/
theorem finite_slice_edge_decomposition {m : ℕ} (cut : Fin (m+1) → ℝ)
    (hcut : StrictMono cut) (u v : ℝ)
    (hu : u∈Set.Icc (cut 0) (cut (Fin.last m))) (hv : v∈Set.Icc (cut 0) (cut (Fin.last m)))
    (hau : ∀ i : Fin m, u∉Set.Ioo (cut i.castSucc) (cut i.succ))
    (hav : ∀ i : Fin m, v∉Set.Ioo (cut i.castSucc) (cut i.succ)) :
    v-u = ∑ i : Fin m, (cut i.succ-cut i.castSucc)*
      sliceCrossingSign u v ((cut i.castSucc+cut i.succ)/2) := by
  have hu' := finite_slice_height_decomposition cut hcut u hu.1 hu.2 hau
  have hv' := finite_slice_height_decomposition cut hcut v hv.1 hv.2 hav
  simp only [sliceCrossingSign,mul_sub,Finset.sum_sub_distrib]
  linarith

/-- The whole weighted flux is a finite nonnegative-width combination of
signed crossing sums, so slice-wise nonpositivity implies flux nonpositivity. -/
theorem finite_slice_flux_nonpos {ι : Type*} [Fintype ι] {m : ℕ}
    (cut : Fin (m+1) → ℝ) (hcut : StrictMono cut) (u v g : ι → ℝ)
    (hu : ∀ j, u j∈Set.Icc (cut 0) (cut (Fin.last m)))
    (hv : ∀ j, v j∈Set.Icc (cut 0) (cut (Fin.last m)))
    (hau : ∀ j (i : Fin m), u j∉Set.Ioo (cut i.castSucc) (cut i.succ))
    (hav : ∀ j (i : Fin m), v j∉Set.Ioo (cut i.castSucc) (cut i.succ))
    (hslice : ∀ i : Fin m, (∑ j, g j*sliceCrossingSign (u j) (v j)
      ((cut i.castSucc+cut i.succ)/2))≤0) :
    (∑ j, g j*(v j-u j))≤0 := by
  have he : (∑ j, g j*(v j-u j)) = ∑ i : Fin m, (cut i.succ-cut i.castSucc)*
      ∑ j, g j*sliceCrossingSign (u j) (v j) ((cut i.castSucc+cut i.succ)/2) := by
    simp_rw [finite_slice_edge_decomposition cut hcut _ _ (hu _) (hv _) (hau _) (hav _),Finset.mul_sum]
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro i _
    apply Finset.sum_congr rfl
    intro j _
    ring
  rw [he]
  apply Finset.sum_nonpos
  intro i _
  exact mul_nonpos_of_nonneg_of_nonpos (sub_nonneg.mpr (hcut i.castSucc_lt_succ).le) (hslice i)

end MonotoneMatching
