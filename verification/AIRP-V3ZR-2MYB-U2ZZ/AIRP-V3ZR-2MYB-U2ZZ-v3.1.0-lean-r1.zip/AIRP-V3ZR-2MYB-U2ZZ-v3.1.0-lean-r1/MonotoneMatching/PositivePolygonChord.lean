import MonotoneMatching.PolygonChordSideSum
import MonotoneMatching.DualCellSideIndices

/-! Positive polygon side indices determine the exact positive chord increment. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval

theorem positive_polygon_chord_increment {m : ℕ} [NeZero m] (v : Fin m → ℂ)
    (hinj : Set.InjOn (periodicPolygonPath (closedCycleVertices v)) (Set.Ico (0:ℝ) m))
    (hne : v 0≠v (finRotate m 0)) {C : Set ℂ} (hC : IsOpen C)
    (hmid : edgeCrossPoint (v 0) (v (finRotate m 0)) (1/2) 0∈C)
    (hinc : ∀ q∈C, q∈polygonBoundary (finRotate m) v → q∈segment ℝ (v 0) (v (finRotate m 0)))
    (hL : ∀ q∈C, 0<edgeSide (v 0) (v (finRotate m 0)) q → polygonIndexPhase (finRotate m) v q=2*Real.pi)
    (hR : ∀ q∈C, edgeSide (v 0) (v (finRotate m 0)) q<0 → polygonIndexPhase (finRotate m) v q=0)
    {d : ℝ} (hd : d∈Set.Ioo (0:ℝ) m) (φ : C(I,ℝ))
    (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg
      (periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ)+d)-
       periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ))) : Real.Angle)) :
    φ 1-φ 0=2*Real.pi := by
  have hm : 0<m := Nat.pos_of_ne_zero (NeZero.ne m)
  have hmR : (1:ℝ)≤m := by exact_mod_cast hm
  let Γ := periodicPolygonPath (closedCycleVertices v)
  let δ := fun s : I => Γ ((1/4:ℝ)+((m:ℝ)-2*(1/4))*(s:ℝ)+1/2)-Γ (1/2)
  have hΓ : Continuous Γ := continuous_periodicPolygonPath hm _ (closedCycleVertices_closed v)
  have hc : Continuous δ := by dsimp [δ]; fun_prop
  have hn (s : I) : δ s≠0 := by
    have hoff : (1/4:ℝ)+((m:ℝ)-2*(1/4))*(s:ℝ)∈Set.Ioo (0:ℝ) m := by
      constructor <;> nlinarith [s.property.1,s.property.2]
    have h := polygon_chord_ne_zero hm (closedCycleVertices v) hinj hoff (1/2)
    simpa only [δ,Γ,add_comm,add_left_comm,add_assoc] using h
  obtain ⟨r,hr,hrn⟩ := compact_arc_translation_radius δ hc hn
  have he (η : ℝ) : edgeCrossPoint (v 0) (v (finRotate m 0)) (1/2) η=
      Γ (1/2)+η • (Complex.I*(v (finRotate m 0)-v 0)) := by
    have hh := periodicPolygonPath_on_closed_edge hm _ (closedCycleVertices_closed v) (0:Fin m)
      (show (1/2:ℝ)∈Set.Icc (0:ℝ) 1 by norm_num)
    simp only [Fin.val_zero,Nat.cast_zero,zero_add,closedCycleVertices_castSucc,closedCycleVertices_succ] at hh
    dsimp only [Γ]
    rw [hh]
    simp only [edgeCrossPoint,Complex.real_smul]
    push_cast
    ring
  obtain ⟨η,hη,hp,hq,hps,hqs⟩ := exists_two_edge_offsets hne (1/2) (hC.inter Metric.isOpen_ball)
    (show edgeCrossPoint (v 0) (v (finRotate m 0)) (1/2) 0∈C∩Metric.ball (Γ (1/2)) r from
      ⟨hmid,by rw [he]; simp only [zero_smul,add_zero]; exact Metric.mem_ball_self hr⟩)
  have hw : ‖η • (Complex.I*(v (finRotate m 0)-v 0))‖<r := by
    have hb := hp.2
    rw [he,Metric.mem_ball,dist_eq_norm,add_sub_cancel_left] at hb
    exact hb
  have hqp : edgeCrossPoint (v 0) (v (finRotate m 0)) (1/2) η∉polygonBoundary (finRotate m) v := by
    intro hb
    exact (ne_of_gt hps) (edgeSide_eq_zero_on_segment _ _ (hinc _ hp.1 hb))
  have hqm : edgeCrossPoint (v 0) (v (finRotate m 0)) (1/2) (-η)∉polygonBoundary (finRotate m) v := by
    intro hb
    exact (ne_of_lt hqs) (edgeSide_eq_zero_on_segment _ _ (hinc _ hq.1 hb))
  have heminus : edgeCrossPoint (v 0) (v (finRotate m 0)) (1/2) (-η)=
      Γ (1/2)-η • (Complex.I*(v (finRotate m 0)-v 0)) := by rw [he]; module
  have hh := polygon_chord_increment_side_sum v hinj η (ne_of_gt hη)
    (hrn _ hw) (by rwa [he] at hqp) (by rwa [heminus] at hqm) hd φ hφ
  rw [← he,← heminus,hL _ hp.1 hps,hR _ hq.1 hqs,add_zero] at hh
  exact hh

end MonotoneMatching
