import MonotoneMatching.TransitionCoherentIndices
import Mathlib.Order.Interval.Set.Infinite

/-! Finite horizontal slices of polygon boundaries and exact side signs. -/
noncomputable section
namespace MonotoneMatching
open Filter
open scoped Topology

def horizontalPoint (x h : ℝ) : ℂ := ⟨x,h⟩

def horizontalEdgeCrossing (z w : ℂ) (h : ℝ) : ℝ :=
  z.re+(h-z.im)*(w.re-z.re)/(w.im-z.im)

theorem continuous_horizontalPoint (h : ℝ) : Continuous (fun x => horizontalPoint x h) := by
  simp only [horizontalPoint,Complex.mk_eq_add_mul_I]
  fun_prop

/-- At a height avoiding the endpoints, an intersected segment has a unique
horizontal crossing and the affine parameter is strictly interior. -/
theorem horizontal_segment_crossing {z w : ℂ} {x h : ℝ}
    (hz : h≠z.im) (hw : h≠w.im) (hmem : horizontalPoint x h∈segment ℝ z w) :
    w.im-z.im≠0 ∧ x=horizontalEdgeCrossing z w h ∧
      ∃ t∈Set.Ioo (0:ℝ) 1, horizontalPoint x h=(1-t) • z+t • w := by
  rw [segment_eq_image] at hmem
  obtain ⟨t,ht,he⟩ := hmem
  have hre := congrArg Complex.re he
  have him := congrArg Complex.im he
  simp only [horizontalPoint,Complex.add_re,Complex.add_im,Complex.smul_re,Complex.smul_im,smul_eq_mul] at hre him
  have ht0 : 0<t := by
    apply lt_of_le_of_ne ht.1
    intro h0
    exact hz (by rw [← h0] at him; simpa using him.symm)
  have ht1 : t<1 := by
    apply lt_of_le_of_ne ht.2
    intro h1
    exact hw (by rw [h1] at him; simpa using him.symm)
  have hd : w.im-z.im≠0 := by
    intro h0
    apply hz
    nlinarith
  refine ⟨hd,?_,t,⟨ht0,ht1⟩,he.symm⟩
  have him' : h-z.im=t*(w.im-z.im) := by linarith
  have hre' : x=z.re+t*(w.re-z.re) := by linarith
  rw [horizontalEdgeCrossing,him',hre']
  field_simp

/-- A horizontal line missing the vertices meets a finite polygon in only
finitely many points, one candidate per edge. -/
theorem finite_horizontal_polygon_crossings {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (h : ℝ) (hh : ∀ i, h≠(v i).im) :
    {x : ℝ | horizontalPoint x h∈polygonBoundary next v}.Finite := by
  apply (Set.finite_range (fun i => horizontalEdgeCrossing (v i) (v (next i)) h)).subset
  intro x hx
  obtain ⟨i,hi⟩ := Set.mem_iUnion.mp hx
  have hc := horizontal_segment_crossing (hh i) (hh (next i)) hi
  exact ⟨i,hc.2.1.symm⟩

theorem edgeSide_horizontal_difference (z w : ℂ) (x c h : ℝ) :
    edgeSide z w (horizontalPoint x h)=edgeSide z w (horizontalPoint c h)-(w.im-z.im)*(x-c) := by
  simp only [edgeSide,horizontalPoint,Complex.mul_im,Complex.sub_re,Complex.sub_im,
    Complex.conj_re,Complex.conj_im]
  ring

theorem edgeSide_horizontal_crossing {z w : ℂ} {c h : ℝ}
    (hc : horizontalPoint c h∈segment ℝ z w) (x : ℝ) :
    edgeSide z w (horizontalPoint x h)= -(w.im-z.im)*(x-c) := by
  rw [edgeSide_horizontal_difference z w x c h,edgeSide_eq_zero_on_segment z w hc]
  ring

/-- The polygon phase is constant along any connected horizontal interval
that avoids its boundary. -/
theorem polygonIndexPhase_horizontal_constant {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (h : ℝ) {s : Set ℝ} (hs : IsPreconnected s)
    (havoid : ∀ x∈s, horizontalPoint x h∉polygonBoundary next v)
    {x y : ℝ} (hx : x∈s) (hy : y∈s) :
    polygonIndexPhase next v (horizontalPoint x h)=polygonIndexPhase next v (horizontalPoint y h) := by
  apply polygonIndexPhase_eq_on_connected next v
    (hs.image (fun x => horizontalPoint x h) (continuous_horizontalPoint h).continuousOn) _
    (Set.mem_image_of_mem _ hx) (Set.mem_image_of_mem _ hy)
  intro q hq
  obtain ⟨t,ht,rfl⟩ := hq
  exact havoid t ht

/-- An off-boundary point can be perturbed to a height avoiding every vertex
without changing its exact real polygon phase. -/
theorem polygonIndexPhase_generic_height {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) {q : ℂ} (hq : q∉polygonBoundary next v) :
    ∃ h : ℝ, (∀ i, h≠(v i).im) ∧ horizontalPoint q.re h∉polygonBoundary next v ∧
      polygonIndexPhase next v q=polygonIndexPhase next v (horizontalPoint q.re h) := by
  obtain ⟨δ,hδ,hphase⟩ := polygonIndexPhase_locally_constant next v hq
  have hc : Continuous (fun h => horizontalPoint q.re h) := by
    simp only [horizontalPoint,Complex.mk_eq_add_mul_I]
    fun_prop
  have hsame : horizontalPoint q.re q.im=q := by apply Complex.ext <;> rfl
  have hopen : IsOpen ((fun h => horizontalPoint q.re h) ⁻¹'
      (Metric.ball q δ ∩ (polygonBoundary next v)ᶜ)) :=
    (Metric.isOpen_ball.inter (isCompact_polygonBoundary next v).isClosed.isOpen_compl).preimage hc
  have hcenter : q.im∈(fun h => horizontalPoint q.re h) ⁻¹'
      (Metric.ball q δ ∩ (polygonBoundary next v)ᶜ) := by
    change horizontalPoint q.re q.im∈Metric.ball q δ ∩ (polygonBoundary next v)ᶜ
    rw [hsame]
    exact ⟨Metric.mem_ball_self hδ,hq⟩
  obtain ⟨ε,hε,hball⟩ := Metric.isOpen_iff.mp hopen q.im hcenter
  obtain ⟨h,hh,hnot⟩ := (Set.Ioo_infinite (show q.im-ε<q.im+ε by linarith)).exists_notMem_finite
    (Set.finite_range (fun i => (v i).im))
  have hb : h∈Metric.ball q.im ε := by
    rw [Metric.mem_ball,Real.dist_eq,abs_sub_lt_iff]
    constructor <;> linarith [hh.1,hh.2]
  have himage := hball hb
  refine ⟨h,?_,himage.2,(hphase _ himage.1).symm⟩
  intro i hi
  exact hnot ⟨i,hi.symm⟩

theorem exists_horizontal_exterior_left {ι : Type*} [Fintype ι]
    (v : ι → ℂ) (x : ℝ) : ∃ u : ℝ, u<x ∧ ∀ i, u<(v i).re := by
  obtain ⟨b,hb⟩ := (Set.finite_range (fun i => (v i).re)).bddBelow
  refine ⟨min b x-1,by linarith [min_le_right b x],?_⟩
  intro i
  have hi := hb (Set.mem_range_self i)
  linarith [min_le_left b x]

/-- Immediately to the right of a transverse edge crossing, the phase is
one of the two coherent side values. A boundary-free interval transports it
to any later point before the next crossing. -/
theorem horizontal_right_interval_side {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (h : ℝ) (C : ι → Set ℂ)
    (hC : ∀ i, IsOpen (C i)) (L R : ℝ)
    (hL : ∀ i q, q∈C i → 0<edgeSide (v i) (v (next i)) q → polygonIndexPhase next v q=L)
    (hR : ∀ i q, q∈C i → edgeSide (v i) (v (next i)) q<0 → polygonIndexPhase next v q=R)
    (i : ι) {c x : ℝ} (hcx : c<x)
    (hmem : horizontalPoint c h∈segment ℝ (v i) (v (next i)))
    (hcC : horizontalPoint c h∈C i) (hdy : (v (next i)).im-(v i).im≠0)
    (havoid : ∀ t∈Set.Ioc c x, horizontalPoint t h∉polygonBoundary next v) :
    polygonIndexPhase next v (horizontalPoint x h)=L ∨ polygonIndexPhase next v (horizontalPoint x h)=R := by
  have hc := (continuous_horizontalPoint h).continuousAt (x := c)
  have hevent := hc.eventually ((hC i).mem_nhds hcC)
  have hlt := eventually_lt_nhds hcx
  obtain ⟨z,hzC,hzx,hcz⟩ := ((hevent.filter_mono nhdsWithin_le_nhds).and
    ((hlt.filter_mono nhdsWithin_le_nhds).and
      (self_mem_nhdsWithin : ∀ᶠ t in 𝓝[>] c, t∈Set.Ioi c))).exists
  have heq := polygonIndexPhase_horizontal_constant next v h
    (convex_Ioc (𝕜 := ℝ) c x).isPreconnected havoid
    (show z∈Set.Ioc c x from ⟨hcz,hzx.le⟩) (show x∈Set.Ioc c x from ⟨hcx,le_rfl⟩)
  have hn : edgeSide (v i) (v (next i)) (horizontalPoint z h)≠0 := by
    rw [edgeSide_horizontal_crossing hmem]
    exact mul_ne_zero (neg_ne_zero.mpr hdy) (ne_of_gt (sub_pos.mpr hcz))
  rcases lt_or_gt_of_ne hn with hs | hs
  · exact Or.inr (heq.symm.trans (hR i _ hzC hs))
  · exact Or.inl (heq.symm.trans (hL i _ hzC hs))

/-- Every point on a generic horizontal slice has exterior phase zero or
one of the coherent edge-side phases. -/
theorem polygonIndexPhase_horizontal_values {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (h : ℝ) (hh : ∀ i, h≠(v i).im)
    (C : ι → Set ℂ) (hC : ∀ i, IsOpen (C i))
    (hedge : ∀ i, ∀ t∈Set.Ioo (0:ℝ) 1, (1-t) • v i+t • v (next i)∈C i)
    (L R : ℝ)
    (hL : ∀ i q, q∈C i → 0<edgeSide (v i) (v (next i)) q → polygonIndexPhase next v q=L)
    (hR : ∀ i q, q∈C i → edgeSide (v i) (v (next i)) q<0 → polygonIndexPhase next v q=R)
    (x : ℝ) (hx : horizontalPoint x h∉polygonBoundary next v) :
    polygonIndexPhase next v (horizontalPoint x h)=0 ∨
      polygonIndexPhase next v (horizontalPoint x h)=L ∨ polygonIndexPhase next v (horizontalPoint x h)=R := by
  classical
  let T := (finite_horizontal_polygon_crossings next v h hh).toFinset
  let S := T.filter (· < x)
  have hT (t : ℝ) : t∈T ↔ horizontalPoint t h∈polygonBoundary next v := Set.Finite.mem_toFinset _
  by_cases hS : S.Nonempty
  · let c := S.max' hS
    have hcS : c∈S := S.max'_mem hS
    have hcB := (hT c).mp (Finset.mem_filter.mp hcS).1
    have hcx : c<x := (Finset.mem_filter.mp hcS).2
    obtain ⟨i,hi⟩ := Set.mem_iUnion.mp hcB
    have hcross := horizontal_segment_crossing (hh i) (hh (next i)) hi
    obtain ⟨t,ht,he⟩ := hcross.2.2
    have hcC : horizontalPoint c h∈C i := by rw [he]; exact hedge i t ht
    right
    apply horizontal_right_interval_side next v h C hC L R hL hR i hcx hi hcC hcross.1
    intro z hz hb
    have hzx : z<x := lt_of_le_of_ne hz.2 (fun he => hx (he ▸ hb))
    have hzS : z∈S := Finset.mem_filter.mpr ⟨(hT z).mpr hb,hzx⟩
    have hle : z≤c := S.le_max' z hzS
    exact (not_lt_of_ge hle) hz.1
  · obtain ⟨u,hux,hu⟩ := exists_horizontal_exterior_left v x
    have havoid : ∀ z∈Set.Icc u x, horizontalPoint z h∉polygonBoundary next v := by
      intro z hz hb
      have hzx : z<x := lt_of_le_of_ne hz.2 (fun he => hx (he ▸ hb))
      exact hS ⟨z,Finset.mem_filter.mpr ⟨(hT z).mpr hb,hzx⟩⟩
    have heq := polygonIndexPhase_horizontal_constant next v h
      (convex_Icc (𝕜 := ℝ) u x).isPreconnected havoid
      (show u∈Set.Icc u x from ⟨le_rfl,hux.le⟩) (show x∈Set.Icc u x from ⟨hux.le,le_rfl⟩)
    left
    rw [← heq]
    exact polygonIndexPhase_zero_left next v _ hu

/-- The first boundary crossing on any generic horizontal line has exterior
phase zero on its left, so one coherent side phase must be zero. -/
theorem horizontal_crossing_zero_side {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (h : ℝ) (hh : ∀ i, h≠(v i).im)
    (C : ι → Set ℂ) (hC : ∀ i, IsOpen (C i))
    (hedge : ∀ i, ∀ t∈Set.Ioo (0:ℝ) 1, (1-t) • v i+t • v (next i)∈C i)
    (L R : ℝ)
    (hL : ∀ i q, q∈C i → 0<edgeSide (v i) (v (next i)) q → polygonIndexPhase next v q=L)
    (hR : ∀ i q, q∈C i → edgeSide (v i) (v (next i)) q<0 → polygonIndexPhase next v q=R)
    (hex : ∃ c : ℝ, horizontalPoint c h∈polygonBoundary next v) : L=0 ∨ R=0 := by
  classical
  let T := (finite_horizontal_polygon_crossings next v h hh).toFinset
  have hT (t : ℝ) : t∈T ↔ horizontalPoint t h∈polygonBoundary next v := Set.Finite.mem_toFinset _
  have hne : T.Nonempty := by obtain ⟨c,hc⟩ := hex; exact ⟨c,(hT c).mpr hc⟩
  let c := T.min' hne
  have hcB := (hT c).mp (T.min'_mem hne)
  obtain ⟨i,hi⟩ := Set.mem_iUnion.mp hcB
  have hcross := horizontal_segment_crossing (hh i) (hh (next i)) hi
  obtain ⟨t,ht,he⟩ := hcross.2.2
  have hcC : horizontalPoint c h∈C i := by rw [he]; exact hedge i t ht
  obtain ⟨u,huc,hu⟩ := exists_horizontal_exterior_left v c
  have hevent := (continuous_horizontalPoint h).continuousAt.eventually ((hC i).mem_nhds hcC)
  have hgt := eventually_gt_nhds huc
  obtain ⟨z,hzC,huz,hzc⟩ := ((hevent.filter_mono nhdsWithin_le_nhds).and
    ((hgt.filter_mono nhdsWithin_le_nhds).and
      (self_mem_nhdsWithin : ∀ᶠ t in 𝓝[<] c, t∈Set.Iio c))).exists
  have havoid : ∀ t∈Set.Ico u c, horizontalPoint t h∉polygonBoundary next v := by
    intro t ht hb
    have hle : c≤t := T.min'_le t ((hT t).mpr hb)
    exact (not_lt_of_ge hle) ht.2
  have heq := polygonIndexPhase_horizontal_constant next v h
    (convex_Ico (𝕜 := ℝ) u c).isPreconnected havoid
    (show u∈Set.Ico u c from ⟨le_rfl,huc⟩) (show z∈Set.Ico u c from ⟨huz.le,hzc⟩)
  have hz0 : polygonIndexPhase next v (horizontalPoint z h)=0 := by
    rw [← heq]
    exact polygonIndexPhase_zero_left next v _ hu
  have hn : edgeSide (v i) (v (next i)) (horizontalPoint z h)≠0 := by
    rw [edgeSide_horizontal_crossing hi]
    exact mul_ne_zero (neg_ne_zero.mpr hcross.1) (ne_of_lt (sub_neg.mpr hzc))
  rcases lt_or_gt_of_ne hn with hs | hs
  · exact Or.inr ((hR i _ hzC hs).symm.trans hz0)
  · exact Or.inl ((hL i _ hzC hs).symm.trans hz0)

/-- The finite-slice value classification extends to every off-boundary
point by a phase-preserving perturbation of the height. -/
theorem polygonIndexPhase_three_values {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ)
    (C : ι → Set ℂ) (hC : ∀ i, IsOpen (C i))
    (hedge : ∀ i, ∀ t∈Set.Ioo (0:ℝ) 1, (1-t) • v i+t • v (next i)∈C i)
    (L R : ℝ)
    (hL : ∀ i q, q∈C i → 0<edgeSide (v i) (v (next i)) q → polygonIndexPhase next v q=L)
    (hR : ∀ i q, q∈C i → edgeSide (v i) (v (next i)) q<0 → polygonIndexPhase next v q=R)
    {q : ℂ} (hq : q∉polygonBoundary next v) :
    polygonIndexPhase next v q=0 ∨ polygonIndexPhase next v q=L ∨ polygonIndexPhase next v q=R := by
  obtain ⟨h,hh,hq',heq⟩ := polygonIndexPhase_generic_height next v hq
  rw [heq]
  exact polygonIndexPhase_horizontal_values next v h hh C hC hedge L R hL hR q.re hq'

/-- The exact local two-pi side jump guarantees a point of nonzero index. -/
theorem exists_nonzero_polygon_index_of_cell_sides {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (i : ι) (hne : v i≠v (next i))
    {C : Set ℂ} (hC : IsOpen C)
    (hmid : edgeCrossPoint (v i) (v (next i)) (1/2) 0∈C)
    (hboundary : ∀ q∈C, q∈polygonBoundary next v → q∈segment ℝ (v i) (v (next i)))
    (L R : ℝ) (hgap : L-R=2*Real.pi)
    (hL : ∀ q∈C, 0<edgeSide (v i) (v (next i)) q → polygonIndexPhase next v q=L)
    (hR : ∀ q∈C, edgeSide (v i) (v (next i)) q<0 → polygonIndexPhase next v q=R) :
    ∃ q : ℂ, q∉polygonBoundary next v ∧ polygonIndexPhase next v q≠0 := by
  obtain ⟨ε,_,hp,hm,hps,hms⟩ := exists_two_edge_offsets hne (1/2) hC hmid
  by_cases hL0 : L=0
  · refine ⟨edgeCrossPoint (v i) (v (next i)) (1/2) (-ε),?_,?_⟩
    · intro hb
      exact (ne_of_lt hms) (edgeSide_eq_zero_on_segment _ _ (hboundary _ hm hb))
    · rw [hR _ hm hms]
      intro hR0
      rw [hL0,hR0] at hgap
      linarith [Real.pi_pos]
  · refine ⟨edgeCrossPoint (v i) (v (next i)) (1/2) ε,?_,?_⟩
    · intro hb
      exact (ne_of_gt hps) (edgeSide_eq_zero_on_segment _ _ (hboundary _ hp hb))
    · rwa [hL _ hp hps]

/-- Nonzero phase on a horizontal slice forces a boundary crossing between
that point and the exterior. -/
theorem nonzero_horizontal_index_has_crossing {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (x h : ℝ)
    (hn : polygonIndexPhase next v (horizontalPoint x h)≠0) :
    ∃ c : ℝ, horizontalPoint c h∈polygonBoundary next v := by
  by_contra hnone
  push Not at hnone
  obtain ⟨u,hux,hu⟩ := exists_horizontal_exterior_left v x
  have heq := polygonIndexPhase_horizontal_constant next v h
    (convex_Icc (𝕜 := ℝ) u x).isPreconnected (fun t _ => hnone t)
    (show u∈Set.Icc u x from ⟨le_rfl,hux.le⟩) (show x∈Set.Icc u x from ⟨hux.le,le_rfl⟩)
  apply hn
  rw [← heq]
  exact polygonIndexPhase_zero_left next v _ hu

/-- Coherent side values with a genuine nonzero-index point have exactly
one exterior side: either (left,right)=(two pi,zero) or (zero,minus two pi). -/
theorem coherent_polygon_orientation_dichotomy {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ)
    (C : ι → Set ℂ) (hC : ∀ i, IsOpen (C i))
    (hedge : ∀ i, ∀ t∈Set.Ioo (0:ℝ) 1, (1-t) • v i+t • v (next i)∈C i)
    (L R : ℝ) (hgap : L-R=2*Real.pi)
    (hL : ∀ i q, q∈C i → 0<edgeSide (v i) (v (next i)) q → polygonIndexPhase next v q=L)
    (hR : ∀ i q, q∈C i → edgeSide (v i) (v (next i)) q<0 → polygonIndexPhase next v q=R)
    (hex : ∃ q : ℂ, q∉polygonBoundary next v ∧ polygonIndexPhase next v q≠0) :
    (L=2*Real.pi ∧ R=0) ∨ (L=0 ∧ R= -(2*Real.pi)) := by
  obtain ⟨q,hq,hn⟩ := hex
  obtain ⟨h,hh,_,heq⟩ := polygonIndexPhase_generic_height next v hq
  have hn' : polygonIndexPhase next v (horizontalPoint q.re h)≠0 := by rwa [← heq]
  have hc := nonzero_horizontal_index_has_crossing next v q.re h hn'
  rcases horizontal_crossing_zero_side next v h hh C hC hedge L R hL hR hc with hL0 | hR0
  · right; exact ⟨hL0,by linarith⟩
  · left; exact ⟨by linarith,hR0⟩

end MonotoneMatching
