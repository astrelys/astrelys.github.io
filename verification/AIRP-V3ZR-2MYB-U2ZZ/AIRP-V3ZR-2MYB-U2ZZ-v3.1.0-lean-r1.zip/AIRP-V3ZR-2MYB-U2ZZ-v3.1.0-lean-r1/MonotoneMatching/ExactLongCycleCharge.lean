import MonotoneMatching.PositivePolygonChord
import MonotoneMatching.PositiveTransitionWinding
import MonotoneMatching.InternalCycleCharge
import MonotoneMatching.InjectedPairSums
import MonotoneMatching.CycleEnumeration
import MonotoneMatching.TransitionEmbedding
import MonotoneMatching.UpperBoundReduction

noncomputable section
namespace MonotoneMatching
open scoped BigOperators unitInterval InnerProductSpace

theorem injected_pair_sum_exact {α β : Type*} [Fintype α] [Fintype β] [DecidableEq α]
    (e : β → α) (he : Function.Injective e) (f : α → α → ℝ)
    (hsymm : ∀ i j, f i j=f j i)
    (hzero : ∀ i j, i∉Set.range e → j∉Set.range e → f i j=0) :
    (∑ i : α,∑ j : α,f i j)=
      (∑ i : β,∑ j : β,f (e i) (e j))+
      2*(∑ j : α,if j∈Set.range e then 0 else ∑ i : β,f (e i) j) := by
  classical
  have hfixed (i : α) (hi : i∉Set.range e) :
      (∑ j : α,f i j)=∑ j : β,f (e j) i := by
    rw [sum_injection_complement e he (f i)]
    have hz : (∑ j : α,if j∈Set.range e then 0 else f i j)=0 := by
      apply Finset.sum_eq_zero
      intro j _
      by_cases hj : j∈Set.range e
      · simp [hj]
      · simp [hj,hzero i j hi hj]
    rw [hz,add_zero]
    apply Finset.sum_congr rfl
    intro j _
    exact hsymm i (e j)
  have hrest : (∑ i : α,if i∈Set.range e then 0 else ∑ j : α,f i j)=
      ∑ i : α,if i∈Set.range e then 0 else ∑ j : β,f (e j) i := by
    apply Finset.sum_congr rfl
    intro i _
    by_cases hi : i∈Set.range e
    · simp [hi]
    · simp only [hi,ite_false,hfixed i hi]
  have hblock : (∑ i : β,∑ j : α,f (e i) j)=
      (∑ i : β,∑ j : β,f (e i) (e j))+
      ∑ j : α,if j∈Set.range e then 0 else ∑ i : β,f (e i) j := by
    simp_rw [sum_injection_complement e he (fun j => f (e _) j)]
    rw [Finset.sum_add_distrib,Finset.sum_comm (f := fun i j => if j∈Set.range e then 0 else f (e i) j)]
    congr 1
    apply Finset.sum_congr rfl
    intro j _
    by_cases hj : j∈Set.range e <;> simp [hj]
  rw [sum_injection_complement e he (fun i => ∑ j : α,f i j),hrest,hblock]
  ring


/-- Exact long-cycle phase charge, conditional only on a positive winding
witness for the actual transition polygon. The general velocity orientation
step is an explicit separate obligation. -/
theorem exact_long_cycle_phase_charge_of_positive_index {n : ℕ} (a y : Fin n → ℂ)
    (π : Equiv.Perm (Fin n)) (hπ : π.IsCycle) (hlen : 3 ≤ π.support.card)
    (hmax : ∀ τ, assignmentScore a y τ ≤ assignmentScore a y (Equiv.refl _))
    (heq : assignmentScore a y π=assignmentScore a y (Equiv.refl _))
    (htwo : ∀ τ, assignmentScore a y τ=assignmentScore a y (Equiv.refl _) →
      τ=Equiv.refl _ ∨ τ=π)
    (hpositive : ∃ q : ℂ, (∀ i, π i ≠ i → q ∉ segment ℝ (y i) (y (π i))) ∧
      0 < ∑ i, Complex.arg ((y (π i)-q)/(y i-q))) :
    identityPhase a (y∘π)-identityPhase a y = Real.pi*((π.support.card : ℝ)-1+
      2*((Finset.univ.filter (fun j => π j=j ∧
        (∑ i,Complex.arg ((y (π i)-y j)/(y i-y j)))=2*Real.pi)).card : ℝ)) := by
  classical
  have hpair := long_tie_strictPairMonotone a y π hlen hmax htwo
  have hpair' := long_tie_relabel_strictPairMonotone a y π hlen hmax heq htwo
  have hy := strictPairMonotone_injective_right a y hpair
  obtain ⟨r,c,hbound,hexact⟩ := exists_exact_dual_support
    (fun i j => inner ℝ (a i) (y j)) π hmax heq htwo
  let m := π.support.card
  have hm : 0<m := by dsimp [m]; omega
  have hm2 : 2≤m := by dsimp [m]; omega
  let : NeZero m := ⟨Nat.ne_of_gt hm⟩
  obtain ⟨E,hE⟩ := exists_ordered_cycle_enumeration π hπ
  let e : Fin m → Fin n := fun i => (E i).val
  let v := y∘e
  have he : Function.Injective e := fun i j h => E.injective (Subtype.ext h)
  have hsucc (i : Fin m) : e (finRotate m i)=π (e i) := hE i
  have hmove (i : Fin m) : π (e i)≠e i := Equiv.Perm.mem_support.mp (E i).property
  have h2 (i : Fin m) : π (π (e i))≠e i := long_cycle_no_two_step π hπ hlen (hmove i)
  have hcover (i : Fin n) (hi : π i≠i) : ∃ j, e j=i := by
    obtain ⟨j,hj⟩ := E.surjective ⟨i,Equiv.Perm.mem_support.mpr hi⟩
    exact ⟨j,congrArg Subtype.val hj⟩
  have htrans (i j : Fin m) : ∃ k : ℕ, (finRotate m^k) i=j := by
    have hx (x : Fin m) : finRotate m x≠x := Equiv.Perm.mem_support.mp
      (by rw [support_finRotate_of_le hm2]; exact Finset.mem_univ _)
    exact (isCycle_finRotate_of_le hm2).exists_pow_eq (hx i) (hx j)
  have hfixed (j : Fin n) (hj : j∉Set.range e) : π j=j := by
    by_contra h
    exact hj (hcover j h)
  have hindex (q : ℂ) : (∑ i,Complex.arg ((y (π i)-q)/(y i-q)))=
      polygonIndexPhase (finRotate m) v q := by
    rw [sum_injection_complement e he]
    have hz : (∑ i : Fin n, if i∈Set.range e then 0 else
        Complex.arg ((y (π i)-q)/(y i-q)))=0 := by
      apply Finset.sum_eq_zero
      intro i _
      by_cases hi : i∈Set.range e
      · simp [hi]
      · rw [ite_eq_right hi,hfixed i hi]
        by_cases hq : y i-q=0 <;> simp [hq]
    rw [hz,add_zero]
    unfold polygonIndexPhase polygonPhase
    apply Finset.sum_congr rfl
    intro i _
    simp only [v,Function.comp_def,hsucc]
  obtain ⟨L,R,hgap,hdich,hL,hR,hvalues⟩ := transition_polygon_orientation_dichotomy
    (finRotate m) htrans a y hy π r c hbound hexact e he hsucc hmove h2
  have horient : L=2*Real.pi ∧ R=0 := by
    rcases hdich with h | h
    · exact h
    · obtain ⟨q,hq,hpos⟩ := hpositive
      have hq' : q∉polygonBoundary (finRotate m) v := by
        intro hb
        obtain ⟨i,hi⟩ := Set.mem_iUnion.mp hb
        exact hq (e i) (hmove i) (by simpa only [v,Function.comp_def,hsucc] using hi)
      rw [hindex] at hpos
      rcases hvalues q hq' with hz | hz | hz <;> rw [hz] at hpos
      · exact (lt_irrefl 0 hpos).elim
      · rw [h.1] at hpos; exact (lt_irrefl 0 hpos).elim
      · rw [h.2] at hpos; linarith [Real.pi_pos]
  have hL' : ∀ i q, q∈strictDualCell a r (e i) → 0<edgeSide (v i) (v (finRotate m i)) q →
      polygonIndexPhase (finRotate m) v q=2*Real.pi := by
    intro i q hq hs
    exact (hL i q hq hs).trans horient.1
  have hR' : ∀ i q, q∈strictDualCell a r (e i) → edgeSide (v i) (v (finRotate m i)) q<0 →
      polygonIndexPhase (finRotate m) v q=0 := by
    intro i q hq hs
    exact (hR i q hq hs).trans horient.2
  have hvalues' : ∀ q, q∉polygonBoundary (finRotate m) v →
      polygonIndexPhase (finRotate m) v q=0 ∨ polygonIndexPhase (finRotate m) v q=2*Real.pi := by
    intro q hq
    rcases hvalues q hq with h | h | h
    · exact Or.inl h
    · exact Or.inr (h.trans horient.1)
    · exact Or.inl (h.trans horient.2)
  have hinj : Set.InjOn (periodicPolygonPath (closedCycleVertices v)) (Set.Ico (0:ℝ) m) := by
    apply periodicPolygonPath_injective_base hm
    intro i j s t hs ht h
    rw [closedCycleVertices_castSucc,closedCycleVertices_succ,
      closedCycleVertices_castSucc,closedCycleVertices_succ] at h
    dsimp only [v,Function.comp_def] at h
    rw [hsucc,hsucc] at h
    obtain ⟨hij,hst⟩ := transition_boundary_injective a y π hπ hlen hy r c hbound hexact
      (hmove i) (hmove j) hs ht h
    exact ⟨he hij,hst⟩
  have hactive (i : Fin m) (t : ℝ) (ht : t∈Set.Icc (0:ℝ) 1) (j : Fin n) :
      dualRow a r j ((1-t) • v i+t • v (finRotate m i))≤
        dualRow a r (e i) ((1-t) • v i+t • v (finRotate m i)) := by
    simpa only [v,Function.comp_def,hsucc] using transition_closed_edge_row_max a y π r c hbound hexact (e i) j ht
  have hmid : edgeCrossPoint (v 0) (v (finRotate m 0)) (1/2) 0∈strictDualCell a r (e 0) := by
    rw [edgeCrossPoint_zero_offset]
    intro j hj
    simpa only [v,Function.comp_def,hsucc] using transition_edge_unique_row a y π r c hbound hexact
      (e 0) (h2 0) j hj (by norm_num : (0:ℝ)<1/2) (by norm_num : (1/2:ℝ)<1)
  have hne : v 0≠v (finRotate m 0) := by
    dsimp only [v,Function.comp_def]
    rw [hsucc]
    exact hy.ne (hmove 0).symm
  have hchord (d : ℝ) (hd : d∈Set.Ioo (0:ℝ) m) (φ : C(I,ℝ))
      (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg
        (periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ)+d)-
         periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ))) : Real.Angle)) :
      φ 1-φ 0=2*Real.pi :=
    positive_polygon_chord_increment v hinj hne (isOpen_strictDualCell a r (e 0)) hmid
      (fun q hq hb => strictDualCell_polygon_boundary_subset (finRotate m) v a r e he hactive 0 hq hb)
      (hL' 0) (hR' 0) hd φ hφ
  have hblock := internal_cycle_pair_charge v hinj hchord
  let f := fun i j : Fin n => Complex.arg ((y (π j)-y (π i))/(y j-y i))
  have hqfixed (j : Fin n) (hj : j∉Set.range e) : y j∉polygonBoundary (finRotate m) v := by
    intro hb
    obtain ⟨i,hi⟩ := Set.mem_iUnion.mp hb
    rw [segment_eq_image] at hi
    obtain ⟨t,ht,heq'⟩ := hi
    by_cases ht0 : t=0
    · simp only [ht0,sub_zero,one_smul,zero_smul,add_zero] at heq'
      exact hj ⟨i,hy heq'⟩
    by_cases ht1 : t=1
    · simp only [ht1,sub_self,zero_smul,one_smul,zero_add] at heq'
      exact hj ⟨finRotate m i,hy heq'⟩
    have ht0p : 0<t := lt_of_le_of_ne ht.1 (Ne.symm ht0)
    have ht1p : t<1 := lt_of_le_of_ne ht.2 ht1
    apply target_not_on_transition_open_edge a y π r c hbound hexact (e i) (h2 i) j ht0p ht1p
    simpa only [v,Function.comp_def,hsucc] using heq'.symm
  have hcross (j : Fin n) (hj : j∉Set.range e) :
      (∑ i : Fin m,f (e i) j)=polygonIndexPhase (finRotate m) v (y j) := by
    unfold polygonIndexPhase polygonPhase
    apply Finset.sum_congr rfl
    intro i _
    dsimp only [f,v,Function.comp_def]
    rw [hsucc,hfixed j hj]
    congr 1
    rw [show y j-y (π (e i))= -(y (π (e i))-y j) by ring,
      show y j-y (e i)= -(y (e i)-y j) by ring,neg_div_neg_eq]
  have hzero (i j : Fin n) (hi : i∉Set.range e) (hj : j∉Set.range e) : f i j=0 := by
    dsimp [f]
    rw [hfixed i hi,hfixed j hj]
    by_cases hij : y j-y i=0 <;> simp [hij]
  have hsplit := injected_pair_sum_exact e he f (pair_increment_symmetric y (y∘π)) hzero
  have hb : (∑ i : Fin m,∑ j : Fin m,f (e i) (e j))=((m:ℝ)-1)*(2*Real.pi) := by
    simpa only [f,v,Function.comp_def,hsucc] using hblock
  have hphase := twice_phase_difference_pairs a y (y∘π) hpair hpair'
  change 2*(identityPhase a (y∘π)-identityPhase a y)=∑ i,∑ j,f i j at hphase
  have hfixiff (j : Fin n) : j∉Set.range e ↔ π j=j := by
    constructor
    · exact hfixed j
    · intro hj ⟨i,hi⟩
      exact hmove i (by simpa only [hi] using hj)
  have hcrosssum : (∑ j : Fin n,if j∈Set.range e then 0 else ∑ i : Fin m,f (e i) j)=
      ((Finset.univ.filter (fun j => π j=j ∧
        (∑ i,Complex.arg ((y (π i)-y j)/(y i-y j)))=2*Real.pi)).card : ℝ)*(2*Real.pi) := by
    rw [← nsmul_eq_mul,← Finset.sum_const,Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro j _
    by_cases hj : j∈Set.range e
    · have hfix : π j≠j := by intro hh; exact (hfixiff j).mpr hh hj
      simp [hj,hfix]
    · have hfix := (hfixiff j).mp hj
      rw [ite_eq_right hj,hcross j hj]
      simp only [hfix,true_and,hindex]
      rcases hvalues' (y j) (hqfixed j hj) with hz | hz
      · rw [hz]; simp
      · rw [hz,ite_eq_left rfl]
  rw [hb,hcrosssum,← hphase] at hsplit
  dsimp only [m] at hsplit
  linarith

end MonotoneMatching
