import MonotoneMatching.TransposePhase
import Mathlib.Algebra.Group.Fin.Basic

/-! Exact reindexing of pair increments by cyclic gaps and ordered pairs. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

theorem sum_pairs_by_cyclic_gap {m : ℕ} [NeZero m] (f : Fin m → Fin m → ℝ) :
    (∑ i, ∑ j, f i j)=∑ d, ∑ i, f i (i+d) := by
  rw [Finset.sum_comm (f := fun d i : Fin m => f i (i+d))]
  apply Finset.sum_congr rfl
  intro i _
  exact (Equiv.sum_comp (Equiv.addLeft i) (fun j => f i j)).symm

theorem cyclic_gap_sum_constant {m : ℕ} [NeZero m] (f : Fin m → Fin m → ℝ)
    (hzero : ∀ i, f i i=0) (c : ℝ)
    (hgap : ∀ d : Fin m, d≠0 → (∑ i, f i (i+d))=c) :
    (∑ i, ∑ j, f i j)=((m:ℝ)-1)*c := by
  rw [sum_pairs_by_cyclic_gap]
  have he (d : Fin m) : (∑ i, f i (i+d))=if d=0 then 0 else c := by
    by_cases hd : d=0
    · subst d; simp [hzero]
    · simp only [hd,ite_false,hgap d hd]
  simp_rw [he]
  have h := Finset.sum_erase_add (s := (Finset.univ : Finset (Fin m)))
    (f := fun _ => c) (a := 0) (Finset.mem_univ _)
  have hs : (∑ d : Fin m, if d=0 then 0 else c)=∑ d∈(Finset.univ.erase (0:Fin m)), c := by
    rw [← Finset.sum_erase_add (s := Finset.univ) (f := fun d : Fin m => if d=0 then 0 else c)
      (a := 0) (Finset.mem_univ _)]
    simp only [ite_true,add_zero]
    apply Finset.sum_congr rfl
    intro d hd
    exact ite_eq_right (Finset.mem_erase.mp hd).1
  rw [hs]
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] at h ⊢
  linarith

theorem twice_phase_difference_pairs {n : ℕ} (a y z : Fin n → ℂ)
    (hy : StrictPairMonotone a y) (hz : StrictPairMonotone a z) :
    2*(identityPhase a z-identityPhase a y)=
      ∑ i, ∑ j, Complex.arg ((z j-z i)/(y j-y i)) := by
  rw [mul_sub,twice_identityPhase,twice_identityPhase,← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro i _
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro j _
  by_cases hij : i=j
  · subst j; simp
  · exact pairPhase_difference a y z i j (hy j i (Ne.symm hij)) (hz j i (Ne.symm hij))

theorem pair_increment_symmetric {ι : Type*} (y z : ι → ℂ) (i j : ι) :
    Complex.arg ((z j-z i)/(y j-y i))=Complex.arg ((z i-z j)/(y i-y j)) := by
  congr 1
  rw [show z i-z j= -(z j-z i) by ring,show y i-y j= -(y j-y i) by ring,neg_div_neg_eq]

end MonotoneMatching
