import MonotoneMatching.FiniteSliceDecomposition

/-! Exact correspondence between signed strip crossings and polygon intersections. -/
noncomputable section
namespace MonotoneMatching

theorem sliceCrossingSign_ne_zero_iff (u v h : ℝ) (hu : h≠u) (hv : h≠v) :
    sliceCrossingSign u v h≠0 ↔ (u<h ∧ h<v) ∨ (v<h ∧ h<u) := by
  constructor
  · intro hn
    by_cases hhv : h<v
    · by_cases hhu : h<u
      · simp [sliceCrossingSign,hhv,hhu] at hn
      · exact Or.inl ⟨lt_of_le_of_ne (le_of_not_gt hhu) hu.symm,hhv⟩
    · by_cases hhu : h<u
      · exact Or.inr ⟨lt_of_le_of_ne (le_of_not_gt hhv) hv.symm,hhu⟩
      · simp [sliceCrossingSign,hhv,hhu] at hn
  · intro hc
    rcases hc with hc | hc
    · simp [sliceCrossingSign,hc.2,not_lt_of_ge hc.1.le]
    · simp [sliceCrossingSign,hc.2,not_lt_of_ge hc.1.le]

theorem sliceCrossingSign_at_segment {z w : ℂ} {x h : ℝ}
    (hz : h≠z.im) (hw : h≠w.im) (hc : horizontalPoint x h∈segment ℝ z w) :
    sliceCrossingSign z.im w.im h = if 0<w.im-z.im then 1 else -1 := by
  obtain ⟨hd,_,t,ht,he⟩ := horizontal_segment_crossing hz hw hc
  have him := congrArg Complex.im he
  simp only [horizontalPoint,Complex.add_im,Complex.smul_im,smul_eq_mul] at him
  by_cases hp : 0<w.im-z.im
  · have h1 : z.im<h := by nlinarith [mul_pos ht.1 hp]
    have h2 : h<w.im := by nlinarith [mul_pos (sub_pos.mpr ht.2) hp]
    simp [sliceCrossingSign,hp,h2,not_lt_of_ge h1.le]
  · have hn : w.im-z.im<0 := lt_of_le_of_ne (le_of_not_gt hp) hd
    have h1 : h<z.im := by nlinarith [mul_neg_of_pos_of_neg ht.1 hn]
    have h2 : w.im<h := by nlinarith [mul_neg_of_pos_of_neg (sub_pos.mpr ht.2) hn]
    simp [sliceCrossingSign,hp,h1,not_lt_of_ge h2.le]

theorem horizontal_segment_exists_of_crossing_sign {z w : ℂ} {h : ℝ}
    (hz : h≠z.im) (hw : h≠w.im) (hs : sliceCrossingSign z.im w.im h≠0) :
    ∃ x : ℝ, horizontalPoint x h∈segment ℝ z w := by
  have hreal : h∈segment ℝ z.im w.im := by
    rcases (sliceCrossingSign_ne_zero_iff _ _ _ hz hw).mp hs with hh | hh
    · rw [segment_eq_Icc (le_of_lt (hh.1.trans hh.2))]
      exact ⟨hh.1.le,hh.2.le⟩
    · rw [segment_symm,segment_eq_Icc (le_of_lt (hh.1.trans hh.2))]
      exact ⟨hh.1.le,hh.2.le⟩
  rw [segment_eq_image] at hreal
  obtain ⟨t,ht,him⟩ := hreal
  let q := (1-t) • z+t • w
  have hqim : q.im=h := by simpa only [q,Complex.add_im,Complex.smul_im,smul_eq_mul] using him
  have he : horizontalPoint q.re h=q := by
    apply Complex.ext
    · rfl
    · exact hqim.symm
  refine ⟨q.re,?_⟩
  rw [he]
  simpa only [q,AffineMap.lineMap_apply_module] using lineMap_mem_segment ℝ z w ht

end MonotoneMatching
