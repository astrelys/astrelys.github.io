import MonotoneMatching.AffineArgumentIncrement
import MonotoneMatching.CyclicCells

/-! Exact subdivision and elementary algebra of real argument lifts. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval BigOperators

def uniformArgumentNode {m : ℕ} (hm : 0<m) (i : Fin (m+1)) : I :=
  ⟨(i.val:ℝ)/m,by
    have hp : (0:ℝ)<m := Nat.cast_pos.mpr hm
    constructor
    · exact div_nonneg (Nat.cast_nonneg _) hp.le
    · apply (div_le_one hp).mpr
      exact_mod_cast (Nat.le_of_lt_succ i.isLt)⟩

def uniformArgumentSubparameter {m : ℕ} (hm : 0<m) (i : Fin m) (s : I) : I :=
  ⟨((i.val:ℝ)+(s:ℝ))/m,by
    have hp : (0:ℝ)<m := Nat.cast_pos.mpr hm
    constructor
    · exact div_nonneg (add_nonneg (Nat.cast_nonneg _) s.property.1) hp.le
    · apply (div_le_one hp).mpr
      have hi : (i.val:ℝ)+1≤m := by exact_mod_cast i.isLt
      linarith [s.property.2]⟩

theorem continuous_uniformArgumentSubparameter {m : ℕ} (hm : 0<m) (i : Fin m) :
    Continuous (uniformArgumentSubparameter hm i) := by
  apply Continuous.subtype_mk
  exact (continuous_const.add continuous_subtype_val).div_const _

theorem uniformArgumentSubparameter_zero {m : ℕ} (hm : 0<m) (i : Fin m) :
    uniformArgumentSubparameter hm i 0=uniformArgumentNode hm i.castSucc := by
  apply Subtype.ext
  simp [uniformArgumentSubparameter,uniformArgumentNode]

theorem uniformArgumentSubparameter_one {m : ℕ} (hm : 0<m) (i : Fin m) :
    uniformArgumentSubparameter hm i 1=uniformArgumentNode hm i.succ := by
  apply Subtype.ext
  simp [uniformArgumentSubparameter,uniformArgumentNode]

theorem uniformArgumentNode_zero {m : ℕ} (hm : 0<m) : uniformArgumentNode hm 0=0 := by
  apply Subtype.ext
  simp [uniformArgumentNode]

theorem uniformArgumentNode_last {m : ℕ} (hm : 0<m) : uniformArgumentNode hm (Fin.last m)=1 := by
  apply Subtype.ext
  simp [uniformArgumentNode,Nat.ne_of_gt hm]

/-- The exact real increment of an affine-piecewise path is the sum of its
principal segment increments, since each segment avoids zero. -/
theorem argument_increment_affine_subdivision {m : ℕ} (hm : 0<m)
    (γ : I → ℂ) (hn : ∀ s, γ s≠0) (v : Fin (m+1) → ℂ)
    (hedge : ∀ i : Fin m, ∀ s : I, γ (uniformArgumentSubparameter hm i s)=
      (1-(s:ℝ)) • v i.castSucc+(s:ℝ) • v i.succ)
    (φ : C(I,ℝ)) (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg (γ s) : Real.Angle)) :
    φ 1-φ 0=∑ i : Fin m, Complex.arg (v i.succ/v i.castSucc) := by
  have he (i : Fin m) : φ (uniformArgumentNode hm i.succ)-φ (uniformArgumentNode hm i.castSucc)=
      Complex.arg (v i.succ/v i.castSucc) := by
    let ψ : C(I,ℝ) := ⟨fun s => φ (uniformArgumentSubparameter hm i s),
      φ.continuous.comp (continuous_uniformArgumentSubparameter hm i)⟩
    have hne : ∀ t∈Set.Icc (0:ℝ) 1, (1-t) • v i.castSucc+t • v i.succ≠0 := by
      intro t ht
      simpa only [hedge] using hn (uniformArgumentSubparameter hm i ⟨t,ht⟩)
    have hψ (s : I) : (ψ s : Real.Angle)=
        (Complex.arg ((1-(s:ℝ)) • v i.castSucc+(s:ℝ) • v i.succ) : Real.Angle) := by
      change (φ (uniformArgumentSubparameter hm i s) : Real.Angle)=_
      rw [hφ,hedge]
    have h := affine_argument_increment (v i.castSucc) (v i.succ) hne ψ hψ
    simpa only [ψ,ContinuousMap.coe_mk,uniformArgumentSubparameter_zero,
      uniformArgumentSubparameter_one] using h
  have ht := subdivision_duration_sum (fun i => φ (uniformArgumentNode hm i))
  rw [uniformArgumentNode_zero,uniformArgumentNode_last] at ht
  rw [← ht]
  apply Finset.sum_congr rfl
  intro i _
  exact he i

/-- Negating a nonvanishing path changes a real lift by a constant pi and
therefore preserves its exact real increment. -/
theorem argument_increment_neg (γ : I → ℂ) (hn : ∀ s, γ s≠0)
    (φ ψ : C(I,ℝ))
    (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg (γ s) : Real.Angle))
    (hψ : ∀ s, (ψ s : Real.Angle)=(Complex.arg (-γ s) : Real.Angle)) :
    ψ 1-ψ 0=φ 1-φ 0 := by
  have he (s : I) : (ψ s : Real.Angle)=((φ s+Real.pi : ℝ) : Real.Angle) := by
    rw [hψ,Real.Angle.coe_add,hφ,Complex.arg_neg_coe_angle (hn s)]
  have h := argument_lift_increment_unique ψ (fun s => φ s+Real.pi) ψ.continuous
    (φ.continuous.add continuous_const) he 0 1
  linarith

/-- Products add exact real increments, including all full turns. -/
theorem argument_increment_mul (γ δ : I → ℂ) (hγ : ∀ s, γ s≠0) (hδ : ∀ s, δ s≠0)
    (φ ψ χ : C(I,ℝ))
    (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg (γ s) : Real.Angle))
    (hψ : ∀ s, (ψ s : Real.Angle)=(Complex.arg (δ s) : Real.Angle))
    (hχ : ∀ s, (χ s : Real.Angle)=(Complex.arg (γ s*δ s) : Real.Angle)) :
    χ 1-χ 0=(φ 1-φ 0)+(ψ 1-ψ 0) := by
  have he (s : I) : (χ s : Real.Angle)=((φ s+ψ s : ℝ) : Real.Angle) := by
    rw [hχ,Real.Angle.coe_add,hφ,hψ,Complex.arg_mul_coe_angle (hγ s) (hδ s)]
  have h := argument_lift_increment_unique χ (fun s => φ s+ψ s) χ.continuous
    (φ.continuous.add ψ.continuous) he 0 1
  linarith

end MonotoneMatching
