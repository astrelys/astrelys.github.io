import MonotoneMatching.PolygonPhase
import Mathlib.Topology.Homotopy.Lifting

/-! Continuous real argument lifts and exact loop increments. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval

/-- The circle-valued argument is continuous on every nonvanishing family. -/
theorem continuous_argument_angle {X : Type*} [TopologicalSpace X]
    (γ : X → ℂ) (hc : Continuous γ) (hn : ∀ x, γ x ≠ 0) :
    Continuous (fun x => (Complex.arg (γ x) : Real.Angle)) := by
  apply continuous_iff_continuousAt.mpr
  intro x
  exact ContinuousAt.comp (f := γ) (Complex.continuousAt_arg_coe_angle (hn x)) hc.continuousAt

/-- Every nonvanishing complex path has a real argument lift starting at the
specified principal argument. -/
theorem exists_continuous_argument_lift (γ : I → ℂ) (hc : Continuous γ)
    (hn : ∀ t, γ t ≠ 0) :
    ∃ φ : C(I,ℝ), (∀ t, (φ t : Real.Angle)=(Complex.arg (γ t) : Real.Angle)) ∧
      φ 0=Complex.arg (γ 0) := by
  let g : C(I,Real.Angle) := ⟨_,continuous_argument_angle γ hc hn⟩
  let cov := AddCircle.isCoveringMap_coe (2*Real.pi)
  obtain ⟨φ,hφ,h0⟩ := cov.exists_path_lifts g (Complex.arg (γ 0)) rfl
  exact ⟨φ,fun t => congrFun hφ t,h0⟩

/-- Any two continuous real lifts of the same circle-valued path differ by a
constant; therefore they give exactly the same real increment. -/
theorem argument_lift_increment_unique {X : Type*} [TopologicalSpace X] [PreconnectedSpace X]
    (φ ψ : X → ℝ) (hφ : Continuous φ) (hψ : Continuous ψ)
    (he : ∀ x, (φ x : Real.Angle)=(ψ x : Real.Angle)) (u v : X) :
    φ v-φ u=ψ v-ψ u := by
  have hc : Continuous (fun x => φ x-ψ x) := hφ.sub hψ
  have hz (x : X) : ((φ x-ψ x : ℝ) : Real.Angle)=0 := by
    rw [Real.Angle.coe_sub,he,sub_self]
  have h := (AddCircle.isCoveringMap_coe (2*Real.pi)).const_of_comp hc
    (fun x y => (hz x).trans (hz y).symm) u v
  linarith

/-- A nonvanishing closed loop has a real increment equal to an integral
multiple of two pi, for every continuous argument lift. -/
theorem argument_loop_increment_integer (γ : I → ℂ) (φ : I → ℝ)
    (hφ : ∀ t, (φ t : Real.Angle)=(Complex.arg (γ t) : Real.Angle))
    (hclosed : γ 1=γ 0) : ∃ k : ℤ, φ 1-φ 0=k*(2*Real.pi) := by
  have he : ((φ 1-φ 0 : ℝ) : Real.Angle)=0 := by
    rw [Real.Angle.coe_sub,hφ,hφ,hclosed,sub_self]
  obtain ⟨k,hk⟩ := Real.Angle.coe_eq_zero_iff.mp he
  exact ⟨k,by simpa only [zsmul_eq_mul] using hk.symm⟩

/-- A nonvanishing homotopy of closed loops preserves the exact real
argument increment. This will compare polygon chords at different offsets. -/
theorem argument_loop_increment_homotopy (H : I × I → ℂ) (hc : Continuous H)
    (hn : ∀ x, H x ≠ 0) (hclosed : ∀ t, H (t,1)=H (t,0))
    (φ ψ : C(I,ℝ))
    (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg (H (0,s)) : Real.Angle))
    (hψ : ∀ s, (ψ s : Real.Angle)=(Complex.arg (H (1,s)) : Real.Angle)) :
    φ 1-φ 0=ψ 1-ψ 0 := by
  let g : C(I × I,Real.Angle) := ⟨_,continuous_argument_angle H hc hn⟩
  let cov := AddCircle.isCoveringMap_coe (2*Real.pi)
  have hg0 : ∀ s, g (0,s)=(φ s : Real.Angle) := fun s => (hφ s).symm
  let G := cov.liftHomotopy g φ hg0
  have hG (x : I × I) : (G x : Real.Angle)=(Complex.arg (H x) : Real.Angle) :=
    congrFun (cov.liftHomotopy_lifts g φ hg0) x
  have hG0 (s : I) : G (0,s)=φ s := cov.liftHomotopy_zero g φ hg0 s
  have hdiff : Continuous (fun t => G (t,1)-G (t,0)) :=
    (G.continuous.comp (continuous_id.prodMk continuous_const)).sub
      (G.continuous.comp (continuous_id.prodMk continuous_const))
  have hzero (t : I) : ((G (t,1)-G (t,0) : ℝ) : Real.Angle)=0 := by
    rw [Real.Angle.coe_sub,hG,hG,hclosed,sub_self]
  have hconstant := cov.const_of_comp hdiff (fun t u => (hzero t).trans (hzero u).symm) 0 1
  have hfinal := argument_lift_increment_unique (fun s => G (1,s)) ψ
    (G.continuous.comp (continuous_const.prodMk continuous_id)) ψ.continuous
    (fun s => (hG (1,s)).trans (hψ s).symm) 0 1
  rw [hG0,hG0] at hconstant
  exact hconstant.trans hfinal

end MonotoneMatching
