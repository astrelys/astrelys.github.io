import MonotoneMatching.SliceCrossingSigns

/-! A sorted list of geometric crossings enumerates exactly the edges with
nonzero slice crossing sign. -/
noncomputable section
namespace MonotoneMatching

theorem horizontal_crossing_edge_enumeration {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (h : ℝ) (hh : ∀ i, h≠(v i).im)
    {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ) (e : ι → Fin n) (he : Function.Injective e)
    (hedge : ∀ i, ∀ t∈Set.Ioo (0:ℝ) 1, (1-t) • v i+t • v (next i)∈strictDualCell a r (e i))
    {m : ℕ} (x : Fin m → ℝ) (hx : Function.Injective x)
    (hcover : ∀ t, horizontalPoint t h∈polygonBoundary next v ↔ ∃ k, x k=t) :
    ∃ edge : Fin m → ι, Function.Injective edge ∧
      (∀ k, horizontalPoint (x k) h∈segment ℝ (v (edge k)) (v (next (edge k)))) ∧
      (∀ k, horizontalPoint (x k) h∈strictDualCell a r (e (edge k))) ∧
      (∀ i, sliceCrossingSign (v i).im (v (next i)).im h≠0 → ∃ k, edge k=i) := by
  have hex (k : Fin m) : ∃ i, horizontalPoint (x k) h∈segment ℝ (v i) (v (next i)) :=
    Set.mem_iUnion.mp ((hcover (x k)).mpr ⟨k,rfl⟩)
  choose edge hedgeMem using hex
  have hcell (i : ι) (t : ℝ) (ht : horizontalPoint t h∈segment ℝ (v i) (v (next i))) :
      horizontalPoint t h∈strictDualCell a r (e i) := by
    obtain ⟨_,_,s,hs,heq⟩ := horizontal_segment_crossing (hh i) (hh (next i)) ht
    rw [heq]
    exact hedge i s hs
  refine ⟨edge,?_,hedgeMem,fun k => hcell (edge k) (x k) (hedgeMem k),?_⟩
  · intro k l hkl
    apply hx
    have hk := (horizontal_segment_crossing (hh (edge k)) (hh (next (edge k))) (hedgeMem k)).2.1
    have hl := (horizontal_segment_crossing (hh (edge l)) (hh (next (edge l))) (hedgeMem l)).2.1
    rw [hk,hl,hkl]
  · intro i hi
    obtain ⟨t,ht⟩ := horizontal_segment_exists_of_crossing_sign (hh i) (hh (next i)) hi
    obtain ⟨k,hk⟩ := (hcover t).mp (Set.mem_iUnion.mpr ⟨i,ht⟩)
    refine ⟨k,?_⟩
    by_contra hneq
    have hc1 := hcell i t ht
    have hc2 := hcell (edge k) (x k) (hedgeMem k)
    rw [hk] at hc2
    exact Set.disjoint_left.mp (strictDualCell_disjoint a r (he.ne hneq)) hc2 hc1

end MonotoneMatching
