import MonotoneMatching.HorizontalCrossings

/-! Exact oriented winding jumps across generic horizontal intersections. -/
noncomputable section
namespace MonotoneMatching
open Filter
open scoped Topology

theorem horizontal_right_interval_value {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (h : ℝ) {C : Set ℂ} (hC : IsOpen C)
    (L R : ℝ) (i : ι)
    (hL : ∀ q∈C, 0<edgeSide (v i) (v (next i)) q → polygonIndexPhase next v q=L)
    (hR : ∀ q∈C, edgeSide (v i) (v (next i)) q<0 → polygonIndexPhase next v q=R)
    {c x : ℝ} (hcx : c<x) (hmem : horizontalPoint c h∈segment ℝ (v i) (v (next i)))
    (hcC : horizontalPoint c h∈C) (hdy : (v (next i)).im-(v i).im≠0)
    (havoid : ∀ t∈Set.Ioc c x, horizontalPoint t h∉polygonBoundary next v) :
    polygonIndexPhase next v (horizontalPoint x h)=
      if 0<(v (next i)).im-(v i).im then R else L := by
  have hevent := (continuous_horizontalPoint h).continuousAt.eventually (hC.mem_nhds hcC)
  have hlt := eventually_lt_nhds hcx
  obtain ⟨z,hzC,hzx,hcz⟩ := ((hevent.filter_mono nhdsWithin_le_nhds).and
    ((hlt.filter_mono nhdsWithin_le_nhds).and
      (self_mem_nhdsWithin : ∀ᶠ t in 𝓝[>] c, t∈Set.Ioi c))).exists
  have heq := polygonIndexPhase_horizontal_constant next v h
    (convex_Ioc (𝕜 := ℝ) c x).isPreconnected havoid
    (show z∈Set.Ioc c x from ⟨hcz,hzx.le⟩) (show x∈Set.Ioc c x from ⟨hcx,le_rfl⟩)
  by_cases hd : 0<(v (next i)).im-(v i).im
  · rw [ite_eq_left hd]
    apply heq.symm.trans (hR _ hzC _)
    rw [edgeSide_horizontal_crossing hmem]
    exact mul_neg_of_neg_of_pos (neg_neg_of_pos hd) (sub_pos.mpr hcz)
  · rw [ite_eq_right hd]
    apply heq.symm.trans (hL _ hzC _)
    rw [edgeSide_horizontal_crossing hmem]
    exact mul_pos (neg_pos.mpr (lt_of_le_of_ne (le_of_not_gt hd) hdy)) (sub_pos.mpr hcz)

theorem horizontal_left_interval_value {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (h : ℝ) {C : Set ℂ} (hC : IsOpen C)
    (L R : ℝ) (i : ι)
    (hL : ∀ q∈C, 0<edgeSide (v i) (v (next i)) q → polygonIndexPhase next v q=L)
    (hR : ∀ q∈C, edgeSide (v i) (v (next i)) q<0 → polygonIndexPhase next v q=R)
    {c x : ℝ} (hxc : x<c) (hmem : horizontalPoint c h∈segment ℝ (v i) (v (next i)))
    (hcC : horizontalPoint c h∈C) (hdy : (v (next i)).im-(v i).im≠0)
    (havoid : ∀ t∈Set.Ico x c, horizontalPoint t h∉polygonBoundary next v) :
    polygonIndexPhase next v (horizontalPoint x h)=
      if 0<(v (next i)).im-(v i).im then L else R := by
  have hevent := (continuous_horizontalPoint h).continuousAt.eventually (hC.mem_nhds hcC)
  have hgt := eventually_gt_nhds hxc
  obtain ⟨z,hzC,hxz,hzc⟩ := ((hevent.filter_mono nhdsWithin_le_nhds).and
    ((hgt.filter_mono nhdsWithin_le_nhds).and
      (self_mem_nhdsWithin : ∀ᶠ t in 𝓝[<] c, t∈Set.Iio c))).exists
  have heq := polygonIndexPhase_horizontal_constant next v h
    (convex_Ico (𝕜 := ℝ) x c).isPreconnected havoid
    (show x∈Set.Ico x c from ⟨le_rfl,hxc⟩) (show z∈Set.Ico x c from ⟨hxz.le,hzc⟩)
  by_cases hd : 0<(v (next i)).im-(v i).im
  · rw [ite_eq_left hd]
    apply heq.trans (hL _ hzC _)
    rw [edgeSide_horizontal_crossing hmem]
    exact mul_pos_of_neg_of_neg (neg_neg_of_pos hd) (sub_neg.mpr hzc)
  · rw [ite_eq_right hd]
    apply heq.trans (hR _ hzC _)
    rw [edgeSide_horizontal_crossing hmem]
    exact mul_neg_of_pos_of_neg (neg_pos.mpr (lt_of_le_of_ne (le_of_not_gt hd) hdy)) (sub_neg.mpr hzc)

theorem horizontal_coherent_jump {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (h : ℝ) {C : Set ℂ} (hC : IsOpen C)
    (L R : ℝ) (hgap : L-R=2*Real.pi) (i : ι)
    (hL : ∀ q∈C, 0<edgeSide (v i) (v (next i)) q → polygonIndexPhase next v q=L)
    (hR : ∀ q∈C, edgeSide (v i) (v (next i)) q<0 → polygonIndexPhase next v q=R)
    {c x z : ℝ} (hxc : x<c) (hcz : c<z)
    (hmem : horizontalPoint c h∈segment ℝ (v i) (v (next i)))
    (hcC : horizontalPoint c h∈C) (hdy : (v (next i)).im-(v i).im≠0)
    (hleft : ∀ t∈Set.Ico x c, horizontalPoint t h∉polygonBoundary next v)
    (hright : ∀ t∈Set.Ioc c z, horizontalPoint t h∉polygonBoundary next v) :
    polygonIndexPhase next v (horizontalPoint x h)-polygonIndexPhase next v (horizontalPoint z h)=
      (if 0<(v (next i)).im-(v i).im then 1 else -1)*(2*Real.pi) := by
  rw [horizontal_left_interval_value next v h hC L R i hL hR hxc hmem hcC hdy hleft,
    horizontal_right_interval_value next v h hC L R i hL hR hcz hmem hcC hdy hright]
  split_ifs <;> linarith

theorem polygonIndexPhase_zero_right {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (q : ℂ) (h : ∀ i, (v i).re<q.re) :
    polygonIndexPhase next v q=0 := by
  have hp : polygonPhase next (fun i => q-v i)=0 :=
    polygonPhase_zero_of_re_pos next (fun i => q-v i) (fun i => sub_pos.mpr (h i))
  rw [← hp]
  unfold polygonIndexPhase polygonPhase
  apply Finset.sum_congr rfl
  intro i _
  have hz : v i-q= -(q-v i) := by abel
  have hw : v (next i)-q= -(q-v (next i)) := by abel
  dsimp only
  rw [hz,hw,neg_div_neg_eq]

end MonotoneMatching
