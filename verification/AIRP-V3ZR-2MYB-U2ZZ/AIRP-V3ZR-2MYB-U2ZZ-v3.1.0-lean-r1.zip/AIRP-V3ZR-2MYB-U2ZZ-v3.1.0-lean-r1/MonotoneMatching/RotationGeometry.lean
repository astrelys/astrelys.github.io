import MonotoneMatching.Stability
import Mathlib.Algebra.Field.Periodic

/-! Elementary geometric bridges for the rotational target. -/
noncomputable section
namespace MonotoneMatching

/-- The real-angle model is exactly periodic with the manuscript's 2π period. -/
theorem rotateClockwise_periodic : Function.Periodic rotateClockwise (2 * Real.pi) := by
  intro t
  funext z
  apply Complex.ext <;> simp [rotateClockwise, Real.sin_add_two_pi, Real.cos_add_two_pi]

/-- Counting witnesses over all real angles is identical to counting in one period. -/
theorem mem_rotationOptimizers_iff_one_period {n : ℕ} (a b : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) :
    σ ∈ rotationOptimizers a b ↔ ∃ t ∈ Set.Ico (0 : ℝ) (2 * Real.pi),
      UniqueMinimum a (rotateClockwise t ∘ b) σ := by
  rw [mem_rotationOptimizers]
  constructor
  · rintro ⟨t, ht⟩
    obtain ⟨s, hs, he⟩ := rotateClockwise_periodic.exists_mem_Ico₀ Real.two_pi_pos t
    exact ⟨s, hs, by simpa [he] using ht⟩
  · rintro ⟨t, _, ht⟩
    exact ⟨t, ht⟩

/-- Rotation preserves the actual squared Euclidean norm. -/
theorem rotateClockwise_norm_sq (t : ℝ) (z : ℂ) :
    ‖rotateClockwise t z‖ ^ 2 = ‖z‖ ^ 2 := by
  rw [Complex.sq_norm, Complex.sq_norm]
  simp only [Complex.normSq_apply, rotateClockwise, ← sq]
  calc
    _ = (Real.sin t ^ 2 + Real.cos t ^ 2) * (z.re^2 + z.im^2) := by ring
    _ = _ := by rw [Real.sin_sq_add_cos_sq, one_mul]

/-- Differences rotate as differences, so point separation is preserved. -/
theorem rotateClockwise_sub (t : ℝ) (z w : ℂ) :
    rotateClockwise t (z-w) = rotateClockwise t z - rotateClockwise t w := by
  apply Complex.ext <;> simp [rotateClockwise] <;> ring

/-- Every fixed-angle rotation is injective, including at degenerate source inputs. -/
theorem rotateClockwise_injective (t : ℝ) : Function.Injective (rotateClockwise t) := by
  intro z w h
  have hn := rotateClockwise_norm_sq t (z-w)
  rw [rotateClockwise_sub, h, sub_self, norm_zero, zero_pow (by decide : 2 ≠ 0)] at hn
  have hz : ‖z-w‖ = 0 := (sq_eq_zero_iff).mp hn.symm
  exact sub_eq_zero.mp (norm_eq_zero.mp hz)

end MonotoneMatching
