import MonotoneMatching.RotationalMain
import MonotoneMatching.WindingMain
noncomputable section
namespace MonotoneMatching

/-- The two main geometric theorem statements of the reference manuscript. -/
def mainGeometricTheoremsStatement : Prop :=
  sharpRotationalCountStatement ∧ windingBoundStatement

/-- Complete formal verification of the sharp rotational count and winding-bound
main theorems; algorithmic and weighted extensions are outside this statement. -/
theorem main_geometric_theorems : mainGeometricTheoremsStatement :=
  ⟨sharp_rotational_count,winding_bound⟩

end MonotoneMatching
