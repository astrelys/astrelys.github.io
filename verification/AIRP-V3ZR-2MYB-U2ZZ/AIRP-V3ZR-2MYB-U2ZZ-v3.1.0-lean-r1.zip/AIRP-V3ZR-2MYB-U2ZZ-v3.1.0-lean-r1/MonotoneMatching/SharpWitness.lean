import MonotoneMatching.Rotation
import Mathlib.Tactic.Positivity
import Lean.Elab.Tactic.Omega

/-! Arithmetic separation for the all-n sharpness witness from geometry.tex. -/
noncomputable section
namespace MonotoneMatching

/-- A sum of two distinct binary powers lies in the interval determined by its larger exponent. -/
theorem binary_pair_bounds {p q : ℕ} (hpq : p < q) :
    2 ^ q ≤ 2 ^ p + 2 ^ q ∧ 2 ^ p + 2 ^ q < 2 ^ (q + 1) := by
  constructor
  · exact Nat.le_add_left _ _
  · have h : (2 : ℕ) ^ p < 2 ^ q := Nat.pow_lt_pow_right (by decide) hpq
    rw [pow_succ]
    omega

/-- Distinct unordered index pairs produce distinct witness slopes.
The interval argument is equivalent to the manuscript's binary-valuation argument. -/
theorem binary_pair_sum_injective {p q r s : ℕ} (hpq : p < q) (hrs : r < s)
    (he : 2 ^ p + 2 ^ q = 2 ^ r + 2 ^ s) : p = r ∧ q = s := by
  have hq : q = s := by
    apply Nat.le_antisymm
    · by_contra h
      have hs : s + 1 ≤ q := by omega
      have hpow : (2 : ℕ) ^ (s + 1) ≤ 2 ^ q := Nat.pow_le_pow_right (by decide) hs
      have ha := binary_pair_bounds hpq
      have hb := binary_pair_bounds hrs
      omega
    · by_contra h
      have hq : q + 1 ≤ s := by omega
      have hpow : (2 : ℕ) ^ (q + 1) ≤ 2 ^ s := Nat.pow_le_pow_right (by decide) hq
      have ha := binary_pair_bounds hpq
      have hb := binary_pair_bounds hrs
      omega
  subst s
  have hpow : (2 : ℕ) ^ p = 2 ^ r := by omega
  have hp : p = r := by
    apply Nat.le_antisymm
    · by_contra h
      have hlt : (2 : ℕ) ^ r < 2 ^ p := Nat.pow_lt_pow_right (by decide) (by omega)
      omega
    · by_contra h
      have hlt : (2 : ℕ) ^ p < 2 ^ r := Nat.pow_lt_pow_right (by decide) (by omega)
      omega
  exact ⟨hp, rfl⟩

/-- The target coordinates in the paper's sharpness construction. -/
def sharpTarget (j : ℕ) : ℂ := ⟨(2 : ℝ) ^ j, (4 : ℝ) ^ j⟩

/-- The denominator of the pair slope is nonzero for every ordered pair. -/
theorem sharpTarget_re_sub_ne_zero {p q : ℕ} (hpq : p < q) :
    (sharpTarget q).re - (sharpTarget p).re ≠ 0 := by
  apply sub_ne_zero.mpr
  exact ne_of_gt (pow_lt_pow_right₀ (by norm_num : (1 : ℝ) < 2) hpq)

/-- Every sharpness pair slope is the sum of the corresponding powers of two. -/
theorem sharpTarget_pair_slope {p q : ℕ} (hpq : p < q) :
    ((sharpTarget q).im - (sharpTarget p).im) /
      ((sharpTarget q).re - (sharpTarget p).re) = (2 : ℝ)^p + 2^q := by
  apply (div_eq_iff (sharpTarget_re_sub_ne_zero hpq)).mpr
  change (4 : ℝ)^q - 4^p = (2^p + 2^q) * (2^q - 2^p)
  have hp : (4 : ℝ)^p = (2^p)^2 := by rw [← pow_mul, mul_comm p 2, pow_mul]; norm_num
  have hq : (4 : ℝ)^q = (2^q)^2 := by rw [← pow_mul, mul_comm q 2, pow_mul]; norm_num
  rw [hp, hq]
  ring

/-- Different index pairs in the construction cannot have the same unoriented slope. -/
theorem sharpTarget_pair_slope_injective {p q r s : ℕ} (hpq : p < q) (hrs : r < s)
    (h : ((sharpTarget q).im - (sharpTarget p).im) /
        ((sharpTarget q).re - (sharpTarget p).re) =
      ((sharpTarget s).im - (sharpTarget r).im) /
        ((sharpTarget s).re - (sharpTarget r).re)) : p = r ∧ q = s := by
  rw [sharpTarget_pair_slope hpq, sharpTarget_pair_slope hrs] at h
  apply binary_pair_sum_injective hpq hrs
  exact_mod_cast h

/-- The witness targets are noncollinear already when at least three labels are present. -/
theorem sharpTarget_noncollinear {n : ℕ} (hn : 3 ≤ n) :
    NoncollinearList (fun i : Fin n => sharpTarget i.val) := by
  refine ⟨⟨0, by omega⟩, ⟨1, by omega⟩, ⟨2, by omega⟩, ?_⟩
  norm_num [sharpTarget]

/-- Two projected sharpness pairs can tie at the same angle only if they are
exactly the same unordered pair. This excludes all simultaneous distinct pair ties. -/
theorem sharpTarget_no_simultaneous_projection_ties {p q r s : ℕ}
    (hpq : p < q) (hrs : r < s) (t : ℝ)
    (hp : (rotateClockwise t (sharpTarget p)).re = (rotateClockwise t (sharpTarget q)).re)
    (hr : (rotateClockwise t (sharpTarget r)).re = (rotateClockwise t (sharpTarget s)).re) :
    p = r ∧ q = s := by
  have pair_ratio : ∀ i j : ℕ, i < j →
      (rotateClockwise t (sharpTarget i)).re = (rotateClockwise t (sharpTarget j)).re →
      ((sharpTarget j).im - (sharpTarget i).im) /
        ((sharpTarget j).re - (sharpTarget i).re) = -Real.cos t / Real.sin t := by
    intro i j hij he
    have hd := sharpTarget_re_sub_ne_zero hij
    have hz : Real.cos t * ((sharpTarget j).re - (sharpTarget i).re) +
        Real.sin t * ((sharpTarget j).im - (sharpTarget i).im) = 0 := by
      dsimp [rotateClockwise] at he
      nlinarith
    have hs : Real.sin t ≠ 0 := by
      intro hzero
      rw [hzero, zero_mul, add_zero] at hz
      have hc : Real.cos t = 0 := (mul_eq_zero.mp hz).resolve_right hd
      have hcirc := Real.sin_sq_add_cos_sq t
      rw [hzero, hc] at hcirc
      norm_num at hcirc
    apply (div_eq_div_iff hd hs).mpr
    nlinarith [hz]
  apply sharpTarget_pair_slope_injective hpq hrs
  exact (pair_ratio p q hpq hp).trans (pair_ratio r s hrs hr).symm

end MonotoneMatching
