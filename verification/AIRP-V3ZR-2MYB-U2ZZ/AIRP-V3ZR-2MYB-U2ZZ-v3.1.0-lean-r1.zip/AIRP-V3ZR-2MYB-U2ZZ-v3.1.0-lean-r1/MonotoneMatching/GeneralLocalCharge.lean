import MonotoneMatching.GeneralLongCharge
import MonotoneMatching.GeneralTranspose
import MonotoneMatching.TrajectoryCells
noncomputable section
namespace MonotoneMatching
open scoped BigOperators InnerProductSpace
set_option backward.isDefEq.respectTransparency.types false

/-- Fixed targets with positive polygon index; for a positive simple transition
polygon this is precisely the interior-target count. -/
def cycleInteriorCount {n : ℕ} (y : Fin n → ℂ) (π : Equiv.Perm (Fin n)) : ℕ :=
  (Finset.univ.filter (fun j => π j=j ∧
    (∑ i,Complex.arg ((y (π i)-y j)/(y i-y j)))=2*Real.pi)).card

/-- The paper's event charge: one for a transposition, k-1+2r for a long cycle. -/
def cycleEventCharge {n : ℕ} (y : Fin n → ℂ) (π : Equiv.Perm (Fin n)) : ℕ :=
  if π.support.card=2 then 1 else π.support.card-1+2*cycleInteriorCount y π

/-- The pairwise determinant condition is exactly monotonicity of rotated velocities. -/
theorem clockwise_data_monotone {ι : Type*} (y u : ι → ℂ)
    (hclock : ∀ i j,(y i-y j).re*(u i-u j).im-(y i-y j).im*(u i-u j).re≤0) :
    ∀ i j,0≤ inner ℝ (y i-y j) (Complex.I*(u i-u j)) := by
  intro i j
  have h := hclock i j
  simp only [Complex.inner,Complex.mul_re,Complex.mul_im,Complex.conj_re,Complex.conj_im,
    Complex.I_re,Complex.I_im,zero_mul,one_mul,zero_sub,zero_add]
  linarith

/-- Every actual two-optimum transverse event has the exact charge prescribed
by the manuscript, including arbitrary clockwise velocities. -/
theorem general_two_optima_exact_charge {n : ℕ} (a y u : Fin n → ℂ)
    (hy : Function.Injective y) (π : Equiv.Perm (Fin n)) (hne : π≠Equiv.refl _)
    (hmax : ∀ τ,assignmentScore a y τ≤assignmentScore a y (Equiv.refl _))
    (heq : assignmentScore a y π=assignmentScore a y (Equiv.refl _))
    (htwo : ∀ τ,assignmentScore a y τ=assignmentScore a y (Equiv.refl _) → τ=Equiv.refl _ ∨ τ=π)
    (hmono : ∀ i j,0≤ inner ℝ (y i-y j) (Complex.I*(u i-u j)))
    (hD : 0<assignmentScore a u π-assignmentScore a u (Equiv.refl _)) :
    π.IsCycle ∧ 1≤cycleEventCharge y π ∧
      identityPhase a (y∘π)-identityPhase a y=Real.pi*(cycleEventCharge y π:ℝ) := by
  classical
  have hc := two_optima_identity_isCycle a y π hne hmax heq htwo
  have hlen := hc.two_le_card_support
  refine ⟨hc,?_⟩
  by_cases h2 : π.support.card=2
  · have hq : cycleEventCharge y π=1 := by simp only [cycleEventCharge,h2,ite_true]
    rw [hq]
    refine ⟨le_rfl,?_⟩
    obtain ⟨i,j,hij,rfl⟩ := Equiv.Perm.card_support_eq_two.mp h2
    have hm := hmono j i
    have hd : (y j-y i).re*(u j-u i).im-(y j-y i).im*(u j-u i).re≤0 := by
      simp only [Complex.inner,Complex.mul_re,Complex.mul_im,Complex.conj_re,Complex.conj_im,
        Complex.I_re,Complex.I_im,zero_mul,one_mul,zero_sub,zero_add] at hm
      linarith
    simpa only [Nat.cast_one,mul_one] using
      general_two_optima_transposition_phase_charge a y u i j hij (hy.ne hij) hmax heq htwo hD hd
  · have h3 : 3≤π.support.card := by omega
    have hq : cycleEventCharge y π=π.support.card-1+2*cycleInteriorCount y π := by
      simp only [cycleEventCharge,h2,ite_false]
    constructor
    · rw [hq]; omega
    · have hh := general_long_cycle_phase_charge a y u π hc h3 hmax heq htwo hmono hD
      rw [hq,Nat.cast_add,Nat.cast_mul,Nat.cast_ofNat,Nat.cast_sub (by omega : 1≤π.support.card),Nat.cast_one]
      exact hh

/-- Relabeling the old optimum to identity gives the exact charge at a genuine
rightward transition of a generic trajectory. -/
theorem generic_trajectory_event_exact_charge {n : ℕ} (a : Fin n → ℂ)
    (b v : Fin n → ℝ → ℂ) (hd : ∀ i t,HasDerivAt (b i) (v i t) t)
    (K : Set ℝ) (ha : GenericTrajectorySources b v K a)
    (σ τ : Equiv.Perm (Fin n)) (hne : σ≠τ) {u w : ℝ} (hu : u∈K) (huw : u<w)
    (hy : Function.Injective (fun i => b i u))
    (hmono : ∀ i j,0≤ inner ℝ (b i u-b j u) (Complex.I*(v i u-v j u)))
    (hold : ∀ ρ,assignmentScore a (fun i => b i u) ρ≤assignmentScore a (fun i => b i u) σ)
    (hnew : ∀ t∈Set.Icc u w,∀ ρ,assignmentScore a (fun i => b i t) ρ≤assignmentScore a (fun i => b i t) τ) :
    (σ⁻¹*τ).IsCycle ∧ 1≤cycleEventCharge (fun i => b (σ i) u) (σ⁻¹*τ) ∧
    identityPhase a (fun i => b (τ i) u)-identityPhase a (fun i => b (σ i) u)=
      Real.pi*(cycleEventCharge (fun i => b (σ i) u) (σ⁻¹*τ):ℝ) := by
  let Y := fun i => b (σ i) u
  let U := fun i => v (σ i) u
  let π := σ⁻¹*τ
  have heq : assignmentScore a (fun i => b i u) σ=assignmentScore a (fun i => b i u) τ :=
    le_antisymm (hnew u (Set.left_mem_Icc.mpr huw.le) σ) (hold τ)
  have hπ : π≠Equiv.refl _ := by
    intro h
    have he : σ⁻¹*τ=1 := h
    have hh := congrArg (fun ρ => σ*ρ) he
    have hτ : τ=σ := by simpa [← mul_assoc] using hh
    exact hne hτ.symm
  have hid : assignmentScore a Y (Equiv.refl _)=assignmentScore a (fun i => b i u) σ := by
    change assignmentScore a (fun i => b i u) (σ*1)=_
    rw [mul_one]
  have hπscore : assignmentScore a Y π=assignmentScore a (fun i => b i u) τ := by
    change assignmentScore a (fun i => b i u) (σ*(σ⁻¹*τ))=_
    rw [mul_inv_cancel_left]
  have hmax : ∀ ρ,assignmentScore a Y ρ≤assignmentScore a Y (Equiv.refl _) := by
    intro ρ
    rw [hid]
    exact hold (σ*ρ)
  have htwo : ∀ ρ,assignmentScore a Y ρ=assignmentScore a Y (Equiv.refl _) → ρ=Equiv.refl _ ∨ ρ=π := by
    intro ρ h
    rw [hid] at h
    change assignmentScore a (fun i => b i u) (σ*ρ)=assignmentScore a (fun i => b i u) σ at h
    rcases (generic_trajectory_optimal_tie_isCycle b v K a ha u hu σ τ hne hold heq.symm).2 (σ*ρ) h with h | h
    · left
      exact mul_left_cancel (h.trans (mul_one σ).symm)
    · right
      have hh := congrArg (fun ν => σ⁻¹*ν) h
      simpa [← mul_assoc,π] using hh
  have hD : 0<assignmentScore a U π-assignmentScore a U (Equiv.refl _) := by
    change 0<assignmentScore a (fun i => v i u) (σ*(σ⁻¹*τ))-assignmentScore a (fun i => v i u) (σ*1)
    rw [mul_inv_cancel_left,mul_one]
    exact generic_trajectory_transition_derivative_pos a b v hd K ha σ τ hne hu huw heq
      (fun t ht => hnew t ⟨ht.1.le,ht.2.le⟩ σ)
  have hh := general_two_optima_exact_charge a Y U (hy.comp σ.injective) π hπ hmax
    (by rw [hπscore,hid,heq]) htwo (fun i j => hmono (σ i) (σ j)) hD
  have he : Y∘π=(fun i => b (τ i) u) := by funext i; simp [Y,π,Function.comp_def]
  rw [he] at hh
  exact hh

end MonotoneMatching
