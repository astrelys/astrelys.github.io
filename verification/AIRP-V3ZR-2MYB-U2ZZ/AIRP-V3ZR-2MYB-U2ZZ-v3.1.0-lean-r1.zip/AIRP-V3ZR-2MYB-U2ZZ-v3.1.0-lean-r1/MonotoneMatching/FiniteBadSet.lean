import MonotoneMatching.OptimalTieSeparation
import Mathlib.Data.Set.Card
noncomputable section
namespace MonotoneMatching
open Set Filter
open scoped Topology
set_option backward.isDefEq.respectTransparency.types false

/-- Failure of local constancy in real time. -/
def policyBad {κ : Type*} (f : ℝ → κ) (t : ℝ) : Prop :=
  ¬∀ᶠ u in 𝓝 t,f u=f t

theorem policy_bad_sample {κ : Type*} (f : ℝ → κ) (t : ℝ) (ht : policyBad f t)
    {ε : ℝ} (hε : 0<ε) : ∃ u,|u-t|<ε ∧ f u≠f t := by
  by_contra! hh
  apply ht
  rw [Metric.eventually_nhds_iff]
  exact ⟨ε,hε,fun u hu => hh u (by simpa only [Real.dist_eq] using hu)⟩

/-- A finite set of interior points has mutually disjoint small intervals,
with explicit separation estimates useful for assigning distinct events. -/
theorem finite_separated_radii (s : Finset ℝ) {L U : ℝ}
    (hs : ∀ t∈s,t∈Ioo L U) :
    ∀ t∈s,∃ ε,0<ε ∧ ε<t-L ∧ ε<U-t ∧
      ∀ z∈s,z≠t → 3*ε< |t-z| := by
  intro t ht
  have hleft : ∀ᶠ ε in 𝓝[>] (0:ℝ),ε<t-L :=
    (eventually_lt_nhds (show (0:ℝ)<t-L by linarith [(hs t ht).1])).filter_mono nhdsWithin_le_nhds
  have hright : ∀ᶠ ε in 𝓝[>] (0:ℝ),ε<U-t :=
    (eventually_lt_nhds (show (0:ℝ)<U-t by linarith [(hs t ht).2])).filter_mono nhdsWithin_le_nhds
  have hsep : ∀ᶠ ε in 𝓝[>] (0:ℝ),∀ z∈s,z≠t → 3*ε< |t-z| := by
    apply s.eventually_all.mpr
    intro z _
    by_cases he : z=t
    · exact Eventually.of_forall (fun _ h => (h he).elim)
    · have hp : 0< |t-z|/3 := div_pos (abs_pos.mpr (sub_ne_zero.mpr (Ne.symm he))) (by norm_num)
      have hh : ∀ᶠ ε in 𝓝[>] (0:ℝ),ε< |t-z|/3 := (eventually_lt_nhds hp).filter_mono nhdsWithin_le_nhds
      filter_upwards [hh] with ε hε _
      linarith
  have hpositive : ∀ᶠ ε in 𝓝[>] (0:ℝ),0<ε := self_mem_nhdsWithin
  obtain ⟨ε,hε,hL,hU,hsep⟩ := (hpositive.and (hleft.and (hright.and hsep))).exists
  exact ⟨ε,hε,hL,hU,hsep⟩

/-- Every finite collection of bad points consumes at least as many actual
optimal events in any simultaneous strict realization of its nearby samples. -/
theorem finite_bad_points_inject_events {n : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (hb : ∀ i,Continuous (b i))
    (hy : ∀ t,Function.Injective (fun j => b j t))
    (G : Set (Fin n → ℂ)) (hg : Dense G) (s : Finset ℝ) (L U : ℝ)
    (hs : ∀ t∈s,t∈Ioo L U ∧ policyBad (fun u => canonicalPermutation a (fun j => b j u)) t) :
    ∃ a'∈G,∃ e : {t // t∈s} → ℝ,Function.Injective e ∧
      ∀ t,e t∈Ioo L U ∧ trajectoryOptimalTie a' b (e t) := by
  classical
  have hr := finite_separated_radii s (fun t ht => (hs t ht).1)
  choose radius hpos hleft hright hsep using (fun t : {t // t∈s} => hr t.val t.property)
  have hsample (t : {t // t∈s}) := policy_bad_sample
    (fun u => canonicalPermutation a (fun j => b j u)) t.val (hs t.val t.property).2 (hpos t)
  choose sample hdist hne using hsample
  let samples := s∪Finset.univ.image sample
  obtain ⟨a',ha',hstrict⟩ := canonical_finite_dense_realization a b hy G hg samples
  have hex (t : {t // t∈s}) : ∃ e∈uIcc t.val (sample t),trajectoryOptimalTie a' b e := by
    exact optimal_tie_between_distinct_strict_samples a' b hb t.val (sample t) _ _
      (Ne.symm (hne t))
      (hstrict t.val (Finset.mem_union_left _ t.property))
      (hstrict (sample t) (Finset.mem_union_right _ (Finset.mem_image.mpr ⟨t,Finset.mem_univ _,rfl⟩)))
  choose event hbetween htie using hex
  have hedist (t : {t // t∈s}) : |event t-t.val|<radius t := by
    have hmem := hbetween t
    have hd := hdist t
    rcases le_total t.val (sample t) with h | h
    · rw [uIcc_of_le h] at hmem
      rw [abs_of_nonneg (sub_nonneg.mpr hmem.1)]
      have hh := (abs_lt.mp hd).2
      linarith [hmem.2]
    · rw [uIcc_of_ge h] at hmem
      rw [abs_of_nonpos (sub_nonpos.mpr hmem.2)]
      have hh := (abs_lt.mp hd).1
      linarith [hmem.1]
  refine ⟨a',ha',event,?_,?_⟩
  · intro t z he
    by_contra htz
    have hn : z.val≠t.val := fun h => htz (Subtype.ext h.symm)
    have h1 := hsep t z.val z.property hn
    have h2 := hsep z t.val t.property (Ne.symm hn)
    have h3 := hedist t
    have h4 := hedist z
    rw [abs_sub_comm z.val t.val] at h2
    have htri : |t.val-z.val|≤ |event t-t.val|+|event z-z.val| := by
      rw [← he]
      calc
        |t.val-z.val| = |(t.val-event t)+(event t-z.val)| := by congr 1; ring
        _ ≤ |t.val-event t|+|event t-z.val| := abs_add_le _ _
        _ = _ := by rw [abs_sub_comm t.val (event t)]
    linarith [abs_nonneg (t.val-z.val)]
  · intro t
    have hd := abs_lt.mp (hedist t)
    exact ⟨⟨by linarith [hleft t],by linarith [hright t]⟩,htie t⟩

end MonotoneMatching
