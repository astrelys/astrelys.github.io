import Mathlib.Tactic
noncomputable section
namespace MonotoneMatching

/-- The adjugate pairing of two positive semidefinite real quadratic forms is nonnegative. -/
theorem planar_positive_adjugate_pairing (a b c d e f : ℝ)
    (hA : ∀ x y : ℝ,0 ≤ a*x^2+2*b*x*y+c*y^2)
    (hH : ∀ x y : ℝ,0 ≤ d*x^2+2*e*x*y+f*y^2) :
    0 ≤ c*d-2*b*e+a*f := by
  have ha : 0 ≤ a := by simpa using hA 1 0
  have hc : 0 ≤ c := by simpa using hA 0 1
  have hd : 0 ≤ d := by simpa using hH 1 0
  rcases eq_or_lt_of_le ha with ha0 | hap
  · have hb : b=0 := by
      by_contra hb
      have hm := hA (-(c+1)/(2*b)) 1
      rw [← ha0] at hm
      have heq : 0 * (-(c+1)/(2*b))^2+2*b*(-(c+1)/(2*b))*1+c*1^2 = -1 := by
        field_simp
        ring
      rw [heq] at hm
      norm_num at hm
    rw [← ha0,hb]
    nlinarith [mul_nonneg hc hd]
  · have hdet : 0 ≤ a*c-b^2 := by
      have hm := hA (-b) a
      have heq : a*(-b)^2+2*b*(-b)*a+c*a^2 = a*(a*c-b^2) := by ring
      rw [heq] at hm
      exact nonneg_of_mul_nonneg_right hm hap
    have hhh := hH b (-a)
    have hn := mul_nonneg hd hdet
    have heq : (d*b^2+2*e*b*(-a)+f*(-a)^2)+d*(a*c-b^2) =
        a*(c*d-2*b*e+a*f) := by ring
    have hp : 0 ≤ a*(c*d-2*b*e+a*f) := by rw [← heq]; exact add_nonneg hhh hn
    exact nonneg_of_mul_nonneg_right hp hap

end MonotoneMatching
