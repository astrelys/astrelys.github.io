import MonotoneMatching.VertexSideSamples

/-! Adjacent edge side indices agree through every vertex neighborhood. -/
noncomputable section
namespace MonotoneMatching

theorem exists_polygon_vertex_ball {ι : Type*} [Fintype ι] [DecidableEq ι]
    (next : Equiv.Perm ι) (verts : ι → ℂ) (i : ι)
    (hother : ∀ j, j≠next.symm i → j≠i →
      verts i ∉ segment ℝ (verts j) (verts (next j))) :
    ∃ δ : ℝ, 0<δ ∧ ∀ q∈Metric.ball (verts i) δ,
      q∈polygonBoundary next verts →
      q∈segment ℝ (verts (next.symm i)) (verts i) ∨
      q∈segment ℝ (verts i) (verts (next i)) := by
  let S : Set ℂ := ⋃ j : {j : ι // j≠next.symm i ∧ j≠i},
    segment ℝ (verts j.val) (verts (next j.val))
  have hc : IsCompact S := isCompact_iUnion (fun j => isCompact_complex_segment _ _)
  have hv : verts i ∈ Sᶜ := by
    intro h
    obtain ⟨j,hj⟩ := Set.mem_iUnion.mp h
    exact hother j.val j.property.1 j.property.2 hj
  obtain ⟨δ,hδ,hball⟩ := Metric.isOpen_iff.mp hc.isClosed.isOpen_compl (verts i) hv
  refine ⟨δ,hδ,?_⟩
  intro q hq hb
  obtain ⟨j,hj⟩ := Set.mem_iUnion.mp hb
  by_cases hjp : j=next.symm i
  · left
    simpa only [hjp,next.apply_symm_apply] using hj
  by_cases hji : j=i
  · right
    simpa only [hji] using hj
  exact (hball hq (Set.mem_iUnion.mpr ⟨⟨j,hjp,hji⟩,hj⟩)).elim

/-- The left phase values of any two incident open edge cells agree. The
positive-turn case uses their common-left sector; the nonpositive-turn case
uses the connected union of the two left half-balls. -/
theorem adjacent_left_indices_equal {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (verts : ι → ℂ) (p v w : ℂ)
    (hpv : p≠v) (hvw : v≠w)
    {C D : Set ℂ} (hC : IsOpen C) (hD : IsOpen D)
    (hCin : ∀ t∈Set.Ioo (0:ℝ) 1, edgeCrossPoint p v t 0∈C)
    (hDout : ∀ t∈Set.Ioo (0:ℝ) 1, edgeCrossPoint v w t 0∈D)
    (hex : ∃ q : ℂ, 0<edgeSide p v q ∧ 0<edgeSide v w q)
    {δ : ℝ} (hδ : 0<δ)
    (hlocal : ∀ q∈Metric.ball v δ, q∈polygonBoundary next verts →
      q∈segment ℝ p v ∨ q∈segment ℝ v w)
    (L M : ℝ)
    (hL : ∀ q∈C, 0<edgeSide p v q → polygonIndexPhase next verts q=L)
    (hM : ∀ q∈D, 0<edgeSide v w q → polygonIndexPhase next verts q=M) : L=M := by
  obtain ⟨x,hxb,hxC,hxleft,hxextra⟩ := incoming_left_sample p v w hpv hδ hC hCin
  obtain ⟨y,hyb,hyD,hyleft,hyextra⟩ := outgoing_left_sample p v w hvw hδ hD hDout
  have he : polygonIndexPhase next verts x=polygonIndexPhase next verts y := by
    by_cases ht : 0<edgeSide p v w
    · exact polygonIndexPhase_common_vertex_sector next verts p v w δ hlocal hxb hyb
        hxleft (hxextra ht) (hyextra ht) hyleft
    · exact polygonIndexPhase_reflex_vertex_connection next verts p v w hδ (le_of_not_gt ht)
        hex hlocal hxb hyb hxleft hyleft
  rwa [hL x hxC hxleft,hM y hyD hyleft] at he

end MonotoneMatching
