import Mathlib.Analysis.InnerProductSpace.Calculus
import Mathlib.Analysis.Calculus.Deriv.Slope
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.Analysis.Calculus.LocalExtr.Basic
import Mathlib.Analysis.Complex.Basic
import Mathlib.Analysis.Normed.Group.Bounded
import Mathlib.Topology.Order.Compact
noncomputable section
namespace MonotoneMatching
open scoped BigOperators Topology InnerProductSpace
open Filter
set_option backward.isDefEq.respectTransparency.types false

/-- Squared positive part has a derivative even at the clipping threshold. -/
theorem hasDerivAt_positive_part_sq (x : ℝ) :
    HasDerivAt (fun t : ℝ => (max t 0)^2) (2*max x 0) x := by
  rcases lt_trichotomy x 0 with hx | hx | hx
  · rw [max_eq_right hx.le,mul_zero]
    apply (hasDerivAt_const x (0:ℝ)).congr_of_eventuallyEq
    filter_upwards [eventually_lt_nhds hx] with t ht
    simp [max_eq_right ht.le]
  · subst x
    rw [max_self,mul_zero,hasDerivAt_iff_tendsto_slope]
    have he : slope (fun t : ℝ => (max t 0)^2) 0 = fun t => max t 0 := by
      funext t
      rw [slope_def_field]
      by_cases ht : 0 ≤ t
      · simp only [max_eq_left ht,max_self,zero_pow (by decide : 2 ≠ 0),sub_zero]
        by_cases hz : t=0
        · simp [hz]
        · field_simp
      · have ht' : t ≤ 0 := (lt_of_not_ge ht).le
        simp [max_eq_right ht']
    rw [he]
    simpa only [id_eq,max_self] using (((continuous_id.max continuous_const).continuousAt :
      ContinuousAt (fun t : ℝ => max t 0) 0).mono_left (nhdsWithin_le_nhds (s := {0}ᶜ)))
  · rw [max_eq_left hx.le]
    have hd : HasDerivAt (fun t : ℝ => t^2) (2*x) x := by simpa [Pi.pow_apply] using! (hasDerivAt_id x).pow 2
    apply hd.congr_of_eventuallyEq
    filter_upwards [eventually_gt_nhds hx] with t ht
    simp [max_eq_left ht.le]

/-- Every finite family of squared ball violations has a global minimizer. -/
theorem exists_minimum_squared_ball_violations {ι : Type*} [Fintype ι] [Nonempty ι]
    (y : ι → ℂ) (r : ι → ℝ) :
    ∃ z : ℂ, ∀ w : ℂ,
      (∑ i,(max (‖z-y i‖^2-r i) 0)^2) ≤ ∑ i,(max (‖w-y i‖^2-r i) 0)^2 := by
  let f : ℂ → ℝ := fun z => ∑ i,(max (‖z-y i‖^2-r i) 0)^2
  have hc : Continuous f := by unfold f; fun_prop
  let i : ι := Classical.choice inferInstance
  have hn : Tendsto (fun z : ℂ => ‖z-y i‖) (cocompact ℂ) atTop := by
    apply tendsto_norm_cocompact_atTop.comp
    exact (Homeomorph.subRight (y i)).isClosedEmbedding.tendsto_cocompact
  have hq : Tendsto (fun z : ℂ => ‖z-y i‖^2-r i) (cocompact ℂ) atTop := by
    simpa only [sub_eq_add_neg,Function.comp_def] using! tendsto_atTop_add_const_right (cocompact ℂ) (-r i)
      ((tendsto_pow_atTop (by decide : 2 ≠ 0)).comp hn)
  have hm : Tendsto (fun z : ℂ => max (‖z-y i‖^2-r i) 0) (cocompact ℂ) atTop :=
    tendsto_atTop_mono (fun z => le_max_left _ _) hq
  have hs : Tendsto (fun z : ℂ => (max (‖z-y i‖^2-r i) 0)^2) (cocompact ℂ) atTop :=
    (tendsto_pow_atTop (by decide : 2 ≠ 0)).comp hm
  have hf : Tendsto f (cocompact ℂ) atTop :=
    tendsto_atTop_mono (fun z => Finset.single_le_sum (fun j _ => sq_nonneg _) (Finset.mem_univ i)) hs
  exact hc.exists_forall_le' 0 (hf.eventually_ge_atTop (f 0))

/-- At the minimizer the positive ball violations give a balanced weighted
combination of the center differences. -/
theorem squared_ball_minimum_balance {ι : Type*} [Fintype ι]
    (y : ι → ℂ) (r : ι → ℝ) (z : ℂ)
    (hmin : ∀ w : ℂ, (∑ i,(max (‖z-y i‖^2-r i) 0)^2) ≤
      ∑ i,(max (‖w-y i‖^2-r i) 0)^2) :
    (∑ i,max (‖z-y i‖^2-r i) 0 • (z-y i))=0 := by
  let B : ℂ := ∑ i,max (‖z-y i‖^2-r i) 0 • (z-y i)
  have hd (i : ι) : HasDerivAt (fun t : ℝ => (max (‖z+t • B-y i‖^2-r i) 0)^2)
      (4*max (‖z-y i‖^2-r i) 0*inner ℝ (z-y i) B) 0 := by
    have hl : HasDerivAt (fun t : ℝ => z+t • B-y i) B 0 := by
      simpa using! (((hasDerivAt_id (0:ℝ)).smul_const B).const_add z).sub_const (y i)
    have hq : HasDerivAt (fun t : ℝ => ‖z+t • B-y i‖^2-r i)
        (2*inner ℝ (z-y i) B) 0 := by
      simpa using! hl.norm_sq.sub_const (r i)
    have hh := (hasDerivAt_positive_part_sq (‖z+(0:ℝ) • B-y i‖^2-r i)).comp 0 hq
    have hc : HasDerivAt (fun t : ℝ => (max (‖z+t • B-y i‖^2-r i) 0)^2)
        (2*max (‖z-y i‖^2-r i) 0*(2*inner ℝ (z-y i) B)) 0 := by
      simpa only [Function.comp_def,zero_smul,add_zero] using! hh
    convert hc using 1
    ring
  have hdall := HasDerivAt.fun_sum (fun i (_ : i∈Finset.univ) => hd i)
  have hlocal : IsLocalMin (fun t : ℝ => ∑ i,(max (‖z+t • B-y i‖^2-r i) 0)^2) 0 := by
    apply Filter.Eventually.of_forall
    intro t
    simpa using hmin (z+t • B)
  have hz := hlocal.hasDerivAt_eq_zero hdall
  have he : (∑ i,4*max (‖z-y i‖^2-r i) 0*inner ℝ (z-y i) B)=4*inner ℝ B B := by
    have hB : inner ℝ B B=∑ i,max (‖z-y i‖^2-r i) 0*inner ℝ (z-y i) B := by
      change inner ℝ (∑ i,max (‖z-y i‖^2-r i) 0 • (z-y i)) B=_
      simp only [sum_inner,real_inner_smul_left]
    rw [hB,Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    ring
  rw [he] at hz
  change B=0
  apply inner_self_eq_zero.mp (show inner ℝ B B=0 by linarith)

/-- Weighted pairwise squared distances are twice the centered second moment. -/
theorem weighted_pair_squared_norm_identity {ι : Type*} [Fintype ι]
    (x : ι → ℂ) (w : ι → ℝ) (hw : ∑ i,w i=1) :
    (∑ i,∑ j,w i*w j*‖x i-x j‖^2)=
      2*(∑ i,w i*‖x i‖^2)-2*‖∑ i,w i • x i‖^2 := by
  let B := ∑ i,w i • x i
  have hrow (i : ι) : (∑ j,w i*w j*‖x i-x j‖^2)=
      w i*‖x i‖^2-2*w i*inner ℝ (x i) B+w i*(∑ j,w j*‖x j‖^2) := by
    have he (j : ι) : w i*w j*‖x i-x j‖^2 =
        w j*(w i*‖x i‖^2)-(2*w i)*(w j*inner ℝ (x i) (x j))+
        w i*(w j*‖x j‖^2) := by
      rw [norm_sub_sq_real]
      ring
    simp_rw [he]
    rw [Finset.sum_add_distrib,Finset.sum_sub_distrib,← Finset.sum_mul,hw,one_mul,
      ← Finset.mul_sum,← Finset.mul_sum]
    have hB : (∑ j,w j*inner ℝ (x i) (x j))=inner ℝ (x i) B := by
      change (∑ j,w j*inner ℝ (x i) (x j))=inner ℝ (x i) (∑ j,w j • x j)
      simp only [inner_sum,real_inner_smul_right]
    rw [hB]
  simp_rw [hrow]
  rw [Finset.sum_add_distrib,Finset.sum_sub_distrib,← Finset.sum_mul,hw,one_mul]
  have he : (∑ i,2*w i*inner ℝ (x i) B)=2*‖B‖^2 := by
    rw [← real_inner_self_eq_norm_sq]
    have hB : inner ℝ B B=∑ i,w i*inner ℝ (x i) B := by
      change inner ℝ (∑ i,w i • x i) B=_
      simp only [sum_inner,real_inner_smul_left]
    rw [hB,Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    ring
  rw [he]
  change _=2*(∑ i,w i*‖x i‖^2)-2*‖B‖^2
  ring

/-- The same identity around any specified point. -/
theorem weighted_pair_squared_distance_identity {ι : Type*} [Fintype ι]
    (x : ι → ℂ) (q : ℂ) (w : ι → ℝ) (hw : ∑ i,w i=1) :
    (∑ i,∑ j,w i*w j*‖x i-x j‖^2)=
      2*(∑ i,w i*‖q-x i‖^2)-2*‖∑ i,w i • (q-x i)‖^2 := by
  have h := weighted_pair_squared_norm_identity (fun i => q-x i) w hw
  have he (i j : ι) : ‖(q-x i)-(q-x j)‖=‖x i-x j‖ := by
    rw [show (q-x i)-(q-x j)= -(x i-x j) by ring,norm_neg]
  simpa only [he] using h

/-- Finite Euclidean one-point extension: pairwise nonexpansion makes all the
prescribed closed balls meet. The proof uses a smooth penalty and variance. -/
theorem finite_nonexpansive_ball_intersection {ι : Type*} [Fintype ι] [Nonempty ι]
    (x y : ι → ℂ) (q : ℂ)
    (hxy : ∀ i j, ‖y i-y j‖ ≤ ‖x i-x j‖) :
    ∃ z : ℂ, ∀ i, ‖z-y i‖^2 ≤ ‖q-x i‖^2 := by
  classical
  obtain ⟨z,hmin⟩ := exists_minimum_squared_ball_violations y (fun i => ‖q-x i‖^2)
  refine ⟨z,?_⟩
  by_contra hbad
  push Not at hbad
  obtain ⟨j,hj⟩ := hbad
  let d : ι → ℝ := fun i => ‖z-y i‖^2-‖q-x i‖^2
  let w : ι → ℝ := fun i => max (d i) 0
  let S := ∑ i,w i
  have hw (i : ι) : 0 ≤ w i := le_max_right _ _
  have hdj : 0 < d j := sub_pos.mpr hj
  have hwj : 0 < w j := lt_of_lt_of_le hdj (le_max_left _ _)
  have hS : 0 < S := lt_of_lt_of_le hwj
    (Finset.single_le_sum (fun i _ => hw i) (Finset.mem_univ j))
  let p : ι → ℝ := fun i => w i/S
  have hp (i : ι) : 0 ≤ p i := div_nonneg (hw i) hS.le
  have hpsum : (∑ i,p i)=1 := by
    change (∑ i,w i/S)=1
    rw [← Finset.sum_div]
    exact div_self (ne_of_gt hS)
  have hbalance : (∑ i,p i • (z-y i))=0 := by
    have h := squared_ball_minimum_balance y (fun i => ‖q-x i‖^2) z hmin
    change (∑ i,w i • (z-y i))=0 at h
    change (∑ i,(w i/S) • (z-y i))=0
    simp_rw [div_eq_inv_mul,mul_smul]
    rw [← Finset.smul_sum,h,smul_zero]
  have hY := weighted_pair_squared_distance_identity y z p hpsum
  rw [hbalance,norm_zero,zero_pow (by decide : 2 ≠ 0),mul_zero,sub_zero] at hY
  have hX := weighted_pair_squared_distance_identity x q p hpsum
  have hpair : (∑ i,∑ k,p i*p k*‖y i-y k‖^2) ≤
      ∑ i,∑ k,p i*p k*‖x i-x k‖^2 := by
    apply Finset.sum_le_sum
    intro i _
    apply Finset.sum_le_sum
    intro k _
    apply mul_le_mul_of_nonneg_left _ (mul_nonneg (hp i) (hp k))
    nlinarith [hxy i k,norm_nonneg (y i-y k),norm_nonneg (x i-x k)]
  have hdiff : (∑ i,p i*d i) ≤ 0 := by
    change (∑ i,p i*(‖z-y i‖^2-‖q-x i‖^2)) ≤ 0
    simp only [mul_sub,Finset.sum_sub_distrib]
    rw [hY,hX] at hpair
    nlinarith [sq_nonneg ‖∑ i,p i • (q-x i)‖]
  have hterm (i : ι) : 0 ≤ p i*d i := by
    by_cases hd : 0 ≤ d i
    · exact mul_nonneg (hp i) hd
    · have hw0 : w i=0 := max_eq_right (lt_of_not_ge hd).le
      change 0 ≤ w i/S*d i
      rw [hw0,zero_div,zero_mul]
  have hp : 0 < p j*d j := mul_pos (div_pos hwj hS) hdj
  have hsumpos : 0 < ∑ i,p i*d i := lt_of_lt_of_le hp
    (Finset.single_le_sum (fun i _ => hterm i) (Finset.mem_univ j))
  exact (not_lt_of_ge hdiff) hsumpos

/-- Compactness upgrades the finite ball condition to an arbitrary family. -/
theorem nonexpansive_ball_intersection {ι : Type*} (x y : ι → ℂ) (q : ℂ)
    (hxy : ∀ i j, ‖y i-y j‖ ≤ ‖x i-x j‖) :
    ∃ z : ℂ, ∀ i, ‖z-y i‖ ≤ ‖q-x i‖ := by
  classical
  cases isEmpty_or_nonempty ι with
  | inl h => exact ⟨0,fun i => isEmptyElim i⟩
  | inr h =>
    let i₀ : ι := Classical.choice h
    let B : ι → Set ℂ := fun i => Metric.closedBall (y i) ‖q-x i‖
    have hfinite (u : Finset ι) : (B i₀ ∩ ⋂ i ∈ u,B i).Nonempty := by
      let A := ↥(insert i₀ u)
      have : Nonempty A := ⟨⟨i₀,Finset.mem_insert_self _ _⟩⟩
      obtain ⟨z,hz⟩ := finite_nonexpansive_ball_intersection
        (fun i : A => x i) (fun i : A => y i) q (fun i j => hxy i j)
      have hmem (i : ι) (hi : i ∈ insert i₀ u) : z ∈ B i := by
        change dist z (y i) ≤ ‖q-x i‖
        rw [dist_eq_norm]
        have hh := hz ⟨i,hi⟩
        nlinarith [norm_nonneg (z-y i),norm_nonneg (q-x i)]
      refine ⟨z,hmem i₀ (Finset.mem_insert_self _ _),?_⟩
      exact Set.mem_iInter.mpr (fun i => Set.mem_iInter.mpr (fun hi =>
        hmem i (Finset.mem_insert_of_mem hi)))
    obtain ⟨z,_,hz⟩ := (isCompact_closedBall (y i₀) ‖q-x i₀‖).inter_iInter_nonempty
      B (fun _ => Metric.isClosed_closedBall) hfinite
    refine ⟨z,?_⟩
    intro i
    have hh := Set.mem_iInter.mp hz i
    change dist z (y i) ≤ ‖q-x i‖ at hh
    simpa only [dist_eq_norm] using hh

/-- Euclidean nonexpansive extension on an arbitrary subset of the plane. -/
theorem exists_plane_nonexpansive_extension (s : Set ℂ) (f : ℂ → ℂ)
    (hf : ∀ x ∈ s, ∀ y ∈ s, ‖f x-f y‖ ≤ ‖x-y‖) :
    ∃ g : ℂ → ℂ, (∀ x ∈ s,g x=f x) ∧ ∀ x y, ‖g x-g y‖ ≤ ‖x-y‖ := by
  classical
  let good : Set (Set (ℂ × ℂ)) := {R | ∀ p ∈ R, ∀ q ∈ R, ‖p.2-q.2‖ ≤ ‖p.1-q.1‖}
  let initial : Set (ℂ × ℂ) := {p | p.1∈s ∧ p.2=f p.1}
  have hini : initial∈good := by
    rintro p ⟨hp,hpf⟩ q ⟨hq,hqf⟩
    rw [hpf,hqf]
    exact hf p.1 hp q.1 hq
  have hchains : ∀ chain ⊆ good, IsChain (· ⊆ ·) chain → chain.Nonempty →
      ∃ ub∈good, ∀ R∈chain,R⊆ub := by
    intro chain hchain htotal _
    refine ⟨⋃₀ chain,?_,fun R hR => Set.subset_sUnion_of_mem hR⟩
    intro p hp q hq
    obtain ⟨A,hA,hp⟩ := Set.mem_sUnion.mp hp
    obtain ⟨B,hB,hq⟩ := Set.mem_sUnion.mp hq
    rcases htotal.total hA hB with hAB | hBA
    · exact hchain hB p (hAB hp) q hq
    · exact hchain hA p hp q (hBA hq)
  obtain ⟨R,hsub,hmax⟩ := zorn_subset_nonempty good hchains initial hini
  have hR : R∈good := hmax.1
  have htotal (x : ℂ) : ∃ y : ℂ,(x,y)∈R := by
    obtain ⟨y,hy⟩ := nonexpansive_ball_intersection
      (fun p : R => p.val.1) (fun p : R => p.val.2) x
      (fun p q => hR p p.property q q.property)
    have hnew : insert (x,y) R∈good := by
      intro p hp q hq
      rcases hp with rfl | hp <;> rcases hq with rfl | hq
      · simp
      · exact hy ⟨q,hq⟩
      · simpa only [norm_sub_rev] using hy ⟨p,hp⟩
      · exact hR p hp q hq
    have hh := hmax.2 hnew (Set.subset_insert (x,y) R)
    exact ⟨y,hh (Set.mem_insert (x,y) R)⟩
  choose g hg using htotal
  refine ⟨g,?_,fun x y => hR _ (hg x) _ (hg y)⟩
  intro x hx
  have hh := hR _ (hg x) (x,f x) (hsub ⟨hx,rfl⟩)
  simp only [sub_self,norm_zero] at hh
  exact sub_eq_zero.mp (norm_eq_zero.mp (le_antisymm hh (norm_nonneg _)))

/-- Euclidean extension preserves any positive Lipschitz constant exactly. -/
theorem exists_plane_lipschitz_extension (s : Set ℂ) (f : ℂ → ℂ)
    (k : ℝ) (hk : 0 < k)
    (hf : ∀ x ∈ s, ∀ y ∈ s, ‖f x-f y‖ ≤ k*‖x-y‖) :
    ∃ g : ℂ → ℂ, (∀ x ∈ s,g x=f x) ∧ ∀ x y, ‖g x-g y‖ ≤ k*‖x-y‖ := by
  have hscaled : ∀ x∈s,∀ y∈s, ‖k⁻¹ • f x-k⁻¹ • f y‖ ≤ ‖x-y‖ := by
    intro x hx y hy
    rw [← smul_sub,norm_smul,Real.norm_eq_abs,abs_of_pos (inv_pos.mpr hk)]
    have h := mul_le_mul_of_nonneg_left (hf x hx y hy) (inv_pos.mpr hk).le
    simpa only [← mul_assoc,inv_mul_cancel₀ (ne_of_gt hk),one_mul] using h
  obtain ⟨g,hfix,hg⟩ := exists_plane_nonexpansive_extension s (fun x => k⁻¹ • f x) hscaled
  refine ⟨fun x => k • g x,?_,?_⟩
  · intro x hx
    change k • g x=f x
    rw [hfix x hx,smul_smul,mul_inv_cancel₀ (ne_of_gt hk),one_smul]
  · intro x y
    rw [← smul_sub,norm_smul,Real.norm_eq_abs,abs_of_pos hk]
    exact mul_le_mul_of_nonneg_left (hg x y) hk.le

end MonotoneMatching
