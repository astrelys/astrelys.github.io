import MonotoneMatching.TransitionCellIncidence

/-! Exact left and right winding phases associated with each strict dual cell. -/
noncomputable section
namespace MonotoneMatching
open Filter
open scoped Topology

/-- Small normal offsets on both sides of an edge stay in any open
neighborhood of its chosen interior point. -/
theorem exists_two_edge_offsets {z w : ℂ} (hne : z≠w) (r : ℝ)
    {s : Set ℂ} (hs : IsOpen s) (hq : edgeCrossPoint z w r 0∈s) :
    ∃ ε : ℝ, 0<ε ∧ edgeCrossPoint z w r ε∈s ∧ edgeCrossPoint z w r (-ε)∈s ∧
      0<edgeSide z w (edgeCrossPoint z w r ε) ∧ edgeSide z w (edgeCrossPoint z w r (-ε))<0 := by
  have hc := continuous_edgeCrossPoint z w r
  have hp := hc.continuousAt.eventually (hs.mem_nhds hq)
  have hm : ∀ᶠ ε in 𝓝 (0:ℝ), edgeCrossPoint z w r (-ε)∈s := by
    have ht := (hc.comp continuous_neg).continuousAt (x := (0:ℝ))
    change ∀ᶠ ε in 𝓝 (0:ℝ), s (edgeCrossPoint z w r (-ε))
    simpa only [Function.comp_def,neg_zero] using ht.eventually
      (hs.mem_nhds (show edgeCrossPoint z w r (-(0:ℝ))∈s by simpa only [neg_zero] using hq))
  obtain ⟨ε,hp,hm,hε⟩ := ((hp.filter_mono nhdsWithin_le_nhds).and
    ((hm.filter_mono nhdsWithin_le_nhds).and
      (self_mem_nhdsWithin : ∀ᶠ ε in 𝓝[>] (0:ℝ), ε∈Set.Ioi (0:ℝ)))).exists
  have hn : 0<Complex.normSq (w-z) := Complex.normSq_pos.mpr (sub_ne_zero.mpr hne.symm)
  refine ⟨ε,hε,hp,hm,?_,?_⟩
  · rw [edgeSide_crossPoint]; exact mul_pos hε hn
  · rw [edgeSide_crossPoint]; exact mul_neg_of_neg_of_pos (neg_neg_of_pos hε) hn

/-- Each edge's open convex dual cell has a well-defined left and right
phase, with the exact difference two pi. -/
theorem exists_dual_cell_side_indices {ι : Type*} [Fintype ι] [DecidableEq ι]
    (next : Equiv.Perm ι) (verts : ι → ℂ) {n : ℕ}
    (a : Fin n → ℂ) (r : Fin n → ℝ) (e : ι → Fin n) (he : Function.Injective e)
    (hactive : ∀ i : ι, ∀ t ∈ Set.Icc (0:ℝ) 1, ∀ j : Fin n,
      dualRow a r j ((1-t) • verts i+t • verts (next i)) ≤
        dualRow a r (e i) ((1-t) • verts i+t • verts (next i)))
    (hmid : ∀ i, edgeCrossPoint (verts i) (verts (next i)) (1/2) 0 ∈ strictDualCell a r (e i))
    (hne : ∀ i, verts i≠verts (next i)) (i : ι) :
    ∃ L R : ℝ, L-R=2*Real.pi ∧
      (∀ q∈strictDualCell a r (e i), 0<edgeSide (verts i) (verts (next i)) q →
        polygonIndexPhase next verts q=L) ∧
      (∀ q∈strictDualCell a r (e i), edgeSide (verts i) (verts (next i)) q<0 →
        polygonIndexPhase next verts q=R) := by
  let q0 := edgeCrossPoint (verts i) (verts (next i)) (1/2) 0
  obtain ⟨δ,hδ,hball⟩ := Metric.isOpen_iff.mp (isOpen_strictDualCell a r (e i)) q0 (hmid i)
  have hother : ∀ j, j≠i → Disjoint (Metric.ball q0 δ) (segment ℝ (verts j) (verts (next j))) := by
    intro j hj
    apply Set.disjoint_left.mpr
    intro q hq hqj
    have hc := hball hq
    rw [segment_eq_image] at hqj
    obtain ⟨t,ht,rfl⟩ := hqj
    have hh := hc (e j) (fun h => hj (he h))
    exact (not_lt_of_ge (hactive j t ht (e i))) hh
  obtain ⟨ε,hε,hp,hm,hps,hms⟩ := exists_two_edge_offsets (hne i) (1/2)
    Metric.isOpen_ball (Metric.mem_ball_self hδ)
  let xp := edgeCrossPoint (verts i) (verts (next i)) (1/2) ε
  let xm := edgeCrossPoint (verts i) (verts (next i)) (1/2) (-ε)
  have hinc (q : ℂ) (hq : q∈strictDualCell a r (e i)) (hb : q∈polygonBoundary next verts) :=
    strictDualCell_polygon_boundary_subset next verts a r e he hactive i hq hb
  refine ⟨polygonIndexPhase next verts xp,polygonIndexPhase next verts xm,?_,?_,?_⟩
  · exact polygonIndexPhase_isolated_collar_jump next verts i (hne i) (by norm_num) hδ hother hp hm hps hms
  · intro q hq hs
    exact polygonIndexPhase_dual_cell_left next verts a r (e i) (verts i) (verts (next i))
      (fun q hq hb => hinc q hq hb) hq (hball hp) hs hps
  · intro q hq hs
    exact polygonIndexPhase_dual_cell_right next verts a r (e i) (verts i) (verts (next i))
      (fun q hq hb => hinc q hq hb) hq (hball hm) hs hms

end MonotoneMatching
