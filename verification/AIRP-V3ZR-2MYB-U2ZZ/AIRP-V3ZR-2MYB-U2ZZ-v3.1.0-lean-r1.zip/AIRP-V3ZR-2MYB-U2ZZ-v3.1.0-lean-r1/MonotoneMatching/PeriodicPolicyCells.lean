import MonotoneMatching.PolicyTopology
import MonotoneMatching.SubdivisionCardinality
noncomputable section
namespace MonotoneMatching
open Set Filter
open scoped Topology
set_option backward.isDefEq.respectTransparency.types false

/-- Starting at the first bad point makes one sorted bad-point set a complete
list for the following period, including the part crossing the old good seam. -/
theorem periodic_bad_first_period {κ : Type*} (f : ℝ → κ) (T s : ℝ) (_hT : 0<T)
    (hp : Function.Periodic f T) (hgood : ¬policyBad f s)
    (B : Finset ℝ) (hB : ∀ t,t∈B ↔ t∈Ioo s (s+T) ∧ policyBad f t)
    (hBne : B.Nonempty) :
    ∀ t∈Ioo (B.min' hBne) (B.min' hBne+T),policyBad f t → t∈B := by
  intro t ht hbad
  have hu := (hB _).mp (B.min'_mem hBne)
  rcases lt_trichotomy t (s+T) with hlo | heq | hhi
  · exact (hB t).mpr ⟨⟨lt_trans hu.1.1 ht.1,hlo⟩,hbad⟩
  · subst t
    exact ((policy_bad_periodic f T s hp).mp hbad |> hgood).elim
  · have hsub : t-T∈Ioo s (s+T) := by
      constructor
      · linarith
      · linarith [hu.1.2,ht.2]
    have hbsub : policyBad f (t-T) := by
      apply (policy_bad_periodic f T (t-T) hp).mp
      simpa only [sub_add_cancel] using hbad
    have hm := B.min'_le (t-T) ((hB (t-T)).mpr ⟨hsub,hbsub⟩)
    linarith [ht.2]

/-- Exact circular subdivision: starting at a bad point avoids an artificial
extra cell at a good seam. Empty bad sets give one full-circle cell. -/
theorem periodic_policy_good_subdivision {κ : Type*} (f : ℝ → κ) (T : ℝ) (hT : 0<T)
    (hp : Function.Periodic f T) (N : ℕ)
    (hbad : ∀ s, {t | t∈Ioo s (s+T) ∧ policyBad f t}.Finite ∧
      {t | t∈Ioo s (s+T) ∧ policyBad f t}.ncard≤N) :
    ∃ m : ℕ,0<m ∧ m≤max 1 N ∧ ∃ cut : Fin (m+1) → ℝ,
      StrictMono cut ∧ cut (Fin.last m)=cut 0+T ∧
      ∀ i : Fin m,∀ t∈Ioo (cut i.castSucc) (cut i.succ),¬policyBad f t := by
  classical
  obtain ⟨s,_hs,hgood⟩ := exists_good_policy_seam f hT (by simpa only [zero_add] using (hbad 0).1)
  let D := {t | t∈Ioo s (s+T) ∧ policyBad f t}
  have hD : D.Finite := (hbad s).1
  let B := hD.toFinset
  have hB (t : ℝ) : t∈B ↔ t∈Ioo s (s+T) ∧ policyBad f t := hD.mem_toFinset
  have hcard : B.card≤N := by
    change hD.toFinset.card≤N
    rw [← Set.ncard_eq_toFinset_card D hD]
    exact (hbad s).2
  by_cases hne : B.Nonempty
  · let u := B.min' hne
    have hu := (hB u).mp (B.min'_mem hne)
    have hbnd : (B : Set ℝ) ⊆ Icc u (u+T) := by
      intro t ht
      have hh := (hB t).mp ht
      exact ⟨B.min'_le t ht,by linarith [hu.1.1,hh.1.2]⟩
    obtain ⟨m,hm,cut,hmono,hfirst,hlast,hsize,hnot,_hcover⟩ :=
      finite_event_subdivision_with_cardinality (B : Set ℝ) B.finite_toSet
        (show u<u+T by linarith) hbnd
    have huB : u∈B := B.min'_mem hne
    have hend : u+T∉B := by
      intro h
      have hh := ((hB (u+T)).mp h).1.2
      linarith [hu.1.1]
    have hsize' : m=B.card := by
      simpa only [Finset.finite_toSet_toFinset,Finset.insert_comm u (u+T),
        Finset.insert_eq_of_mem huB,Finset.card_insert_of_notMem hend,Nat.add_right_cancel_iff] using hsize
    refine ⟨m,hm,?_,cut,hmono,by rw [hlast,hfirst],?_⟩
    · rw [hsize']
      exact hcard.trans (le_max_right _ _)
    · intro i t ht hbt
      have hti : t∈Ioo u (u+T) := by
        constructor
        · rw [← hfirst]
          exact lt_of_le_of_lt (hmono.monotone (Fin.zero_le _)) ht.1
        · rw [← hlast]
          exact lt_of_lt_of_le ht.2 (hmono.monotone (Fin.le_last _))
      exact hnot i t ht (periodic_bad_first_period f T s hT hp hgood B hB hne t hti hbt)
  · have hBempty : B=∅ := Finset.not_nonempty_iff_eq_empty.mp hne
    obtain ⟨m,hm,cut,hmono,hfirst,hlast,hsize,_hnot,_hcover⟩ :=
      finite_event_subdivision_with_cardinality (∅ : Set ℝ) Set.finite_empty
        (show s<s+T by linarith) (by simp)
    have hneEnd : s≠s+T := by linarith
    have hmone : m=1 := by
      have hsize' : m+1=2 := by simpa [Set.Finite.toFinset_empty,hneEnd] using hsize
      omega
    refine ⟨m,hm,by rw [hmone]; exact le_max_left _ _,cut,hmono,by rw [hlast,hfirst],?_⟩
    intro i t ht hbt
    have hti : t∈Ioo s (s+T) := by
      constructor
      · rw [← hfirst]
        exact lt_of_le_of_lt (hmono.monotone (Fin.zero_le _)) ht.1
      · rw [← hlast]
        exact lt_of_lt_of_le ht.2 (hmono.monotone (Fin.le_last _))
    have hh := (hB t).mpr ⟨hti,hbt⟩
    simp only [hBempty,Finset.notMem_empty] at hh

/-- A periodic policy with the proved finite bad-point budget admits at most
max(1,N) constant open cells over one complete period. -/
theorem periodic_policy_cells {κ : Type*} (f : ℝ → κ) (T : ℝ) (hT : 0<T)
    (hp : Function.Periodic f T) (N : ℕ)
    (hbad : ∀ s, {t | t∈Ioo s (s+T) ∧ policyBad f t}.Finite ∧
      {t | t∈Ioo s (s+T) ∧ policyBad f t}.ncard≤N) :
    ∃ m : ℕ,0<m ∧ m≤max 1 N ∧ ∃ cut : Fin (m+1) → ℝ,∃ label : Fin m → κ,
      StrictMono cut ∧ cut (Fin.last m)=cut 0+T ∧
      ∀ i : Fin m,∀ t∈Ioo (cut i.castSucc) (cut i.succ),f t=label i := by
  obtain ⟨m,hm,hbound,cut,hmono,hlast,hgood⟩ := periodic_policy_good_subdivision f T hT hp N hbad
  have hlabel (i : Fin m) : ∃ q,∀ t∈Ioo (cut i.castSucc) (cut i.succ),f t=q := by
    obtain ⟨u,hu⟩ := nonempty_Ioo.mpr (hmono i.castSucc_lt_succ)
    exact ⟨f u,policy_constant_on_connected f _ isPreconnected_Ioo (hgood i) u hu⟩
  choose label hlabel using hlabel
  exact ⟨m,hm,hbound,cut,label,hmono,hlast,hlabel⟩

end MonotoneMatching
