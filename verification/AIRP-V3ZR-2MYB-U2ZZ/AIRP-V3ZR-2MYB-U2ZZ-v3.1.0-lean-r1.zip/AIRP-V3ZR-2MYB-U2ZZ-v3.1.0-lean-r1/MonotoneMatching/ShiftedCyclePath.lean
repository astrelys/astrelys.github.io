import MonotoneMatching.CycleArgumentBridge
import MonotoneMatching.PeriodicArgumentHomotopy

/-! Shifted polygon loops retain their exact index and have an affine interior-edge neighborhood. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval

theorem closedCyclePath_shift_phase_increment {m : ℕ} [NeZero m] (v : Fin m → ℂ)
    {q : ℂ} (hq : q∉polygonBoundary (finRotate m) v) (b : ℝ)
    (φ : C(I,ℝ)) (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg
      (periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ)+b)-q) : Real.Angle)) :
    φ 1-φ 0=polygonIndexPhase (finRotate m) v q := by
  have hm : 0<m := Nat.pos_of_ne_zero (NeZero.ne m)
  let γ := fun t => periodicPolygonPath (closedCycleVertices v) t-q
  have hc : Continuous γ := (continuous_periodicPolygonPath hm _ (closedCycleVertices_closed v)).sub continuous_const
  have hp : Function.Periodic γ (m:ℝ) := fun t => by dsimp [γ]; rw [periodicPolygonPath_periodic hm]
  have hn : ∀ t, γ t≠0 := closedCyclePath_relative_ne_zero v hq
  obtain ⟨ψ,hψ,_⟩ := exists_continuous_argument_lift (fun s : I => γ ((m:ℝ)*(s:ℝ)))
    (by apply hc.comp; fun_prop) (fun s => hn _)
  have he := periodic_argument_increment_reparam γ hc m hp hn
    (fun s => (m:ℝ)*(s:ℝ)+b) (by fun_prop) (by simp; ring) ψ φ hψ hφ
  rw [← he]
  exact closedCyclePath_phase_increment v hq ψ hψ

theorem closedCyclePath_edge_midpoint_affine {m : ℕ} [NeZero m] (v : Fin m → ℂ)
    {t : ℝ} (ht : t∈Set.Icc (-(1/4:ℝ)) (1/4:ℝ)) :
    periodicPolygonPath (closedCycleVertices v) (t+1/2)=
      periodicPolygonPath (closedCycleVertices v) (1/2)+t • (v (finRotate m 0)-v 0) := by
  have hm : 0<m := Nat.pos_of_ne_zero (NeZero.ne m)
  have he (s : ℝ) (hs : s∈Set.Icc (0:ℝ) 1) :
      periodicPolygonPath (closedCycleVertices v) s=(1-s) • v 0+s • v (finRotate m 0) := by
    have h := periodicPolygonPath_on_closed_edge hm _ (closedCycleVertices_closed v) (0:Fin m) hs
    simpa only [Fin.val_zero,Nat.cast_zero,zero_add,closedCycleVertices_castSucc,closedCycleVertices_succ] using h
  rw [he (t+1/2) ⟨by linarith [ht.1],by linarith [ht.2]⟩,he (1/2) (by constructor <;> norm_num)]
  module

end MonotoneMatching
