import MonotoneMatching.WindingCounts
noncomputable section
namespace MonotoneMatching
open Set
open scoped BigOperators
set_option backward.isDefEq.respectTransparency.types false

/-- The real increment of a periodic argument lift is independent of the seam. -/
theorem periodic_lift_increment (γ : ℝ → ℂ) (φ : ℝ → ℝ) (T s : ℝ)
    (hφ : Continuous φ) (hp : Function.Periodic γ T)
    (he : ∀ t,(φ t:Real.Angle)=(Complex.arg (γ t):Real.Angle)) :
    φ (s+T)-φ s=φ T-φ 0 := by
  have hh := argument_lift_increment_unique (fun t => φ (t+T)) φ
    (hφ.comp (continuous_id.add continuous_const)) hφ
    (fun t => by rw [he,hp t,← he t]) 0 s
  simp only [zero_add] at hh
  linarith

/-- Actual pair windings agree for different lifts and different time seams. -/
theorem shifted_pair_winding_eq {n : ℕ} (b : Fin n → ℝ → ℂ)
    (φ ψ : Fin n → Fin n → ℝ → ℝ) (w w' : Fin n × Fin n → ℕ) (T s : ℝ)
    (hp : ∀ i,Function.Periodic (b i) T)
    (hφ : ∀ i j,Continuous (φ i j)) (hψ : ∀ i j,Continuous (ψ i j))
    (heφ : ∀ i j,i≠j → ∀ t,(φ i j t:Real.Angle)=(Complex.arg (b j t-b i t):Real.Angle))
    (heψ : ∀ i j,i≠j → ∀ t,(ψ i j t:Real.Angle)=(Complex.arg (b j (t+s)-b i (t+s)):Real.Angle))
    (hw : ∀ p∈increasingPairs n,φ p.1 p.2 T-φ p.1 p.2 0= -(2*Real.pi)*(w p:ℝ))
    (hw' : ∀ p∈increasingPairs n,ψ p.1 p.2 T-ψ p.1 p.2 0= -(2*Real.pi)*(w' p:ℝ)) :
    ∀ p∈increasingPairs n,w' p=w p := by
  intro p hpairs
  have hij : p.1≠p.2 := ne_of_lt ((Finset.mem_filter.mp hpairs).2)
  have hγ : Function.Periodic (fun t => b p.2 t-b p.1 t) T := fun t => by dsimp only; rw [hp p.2 t,hp p.1 t]
  have hseam := periodic_lift_increment (fun t => b p.2 t-b p.1 t) (φ p.1 p.2) T s
    (hφ _ _) hγ (heφ _ _ hij)
  have hh := argument_lift_increment_unique (ψ p.1 p.2) (fun t => φ p.1 p.2 (t+s))
    (hψ _ _) ((hφ _ _).comp (continuous_id.add continuous_const))
    (fun t => (heψ _ _ hij t).trans (heφ _ _ hij (t+s)).symm) 0 T
  simp only [zero_add] at hh
  rw [add_comm T s,hseam,hw p hpairs,hw' p hpairs] at hh
  have hc : (w' p:ℝ)=(w p:ℝ) := (mul_left_cancel₀ (neg_ne_zero.mpr (ne_of_gt Real.two_pi_pos))) hh
  exact_mod_cast hc

/-- A dense source set has an event cover of bounded cardinality in the open
period; the seam may be arbitrary. This only counts genuine optimal ties. -/
def boundedOptimalEvents {n : ℕ} (b : Fin n → ℝ → ℂ) (L U : ℝ) (N : ℕ) : Prop :=
  ∃ G : Set (Fin n → ℂ),Dense G ∧ ∀ a∈G,∃ E : Finset ℝ,E.card≤N ∧
    ∀ t∈Ioo L U,trajectoryOptimalTie a b t → t∈E

/-- The accepted event budget is valid at every choice of time-circle seam,
with the same physical winding numbers. -/
theorem winding_bounded_events_every_seam {n : ℕ} (hn : 2≤n)
    (b v : Fin n → ℝ → ℂ) (T : ℝ) (hT : 0<T)
    (hd : ∀ i t,HasDerivAt (b i) (v i t) t) (hv : ∀ i,Continuous (v i))
    (hp : ∀ i,Function.Periodic (b i) T) (hy : ∀ t,Function.Injective (fun i => b i t))
    (hclock : ∀ i j,i<j → ∀ t,(b j t-b i t).re*(v j t-v i t).im-(b j t-b i t).im*(v j t-v i t).re≤0)
    (φ : Fin n → Fin n → ℝ → ℝ) (w : Fin n × Fin n → ℕ)
    (hφ : ∀ i j,Continuous (φ i j))
    (he : ∀ i j,i≠j → ∀ t,(φ i j t:Real.Angle)=(Complex.arg (b j t-b i t):Real.Angle))
    (hw : ∀ p∈increasingPairs n,φ p.1 p.2 T-φ p.1 p.2 0= -(2*Real.pi)*(w p:ℝ))
    (s : ℝ) : boundedOptimalEvents b s (s+T) (2*∑ p∈increasingPairs n,w p) := by
  classical
  let bs := fun i t => b i (t+s)
  let vs := fun i t => v i (t+s)
  have hds : ∀ i t,HasDerivAt (bs i) (vs i t) t := by
    intro i t
    have ht : HasDerivAt (fun x : ℝ => x+s) 1 t := by
      simpa only [id_eq] using (hasDerivAt_id t).add_const s
    simpa only [one_smul,Function.comp_def] using (hd i (t+s)).scomp t ht
  have hvs : ∀ i,Continuous (vs i) := fun i => (hv i).comp (continuous_id.add continuous_const)
  have hps : ∀ i,Function.Periodic (bs i) T := by
    intro i t
    dsimp [bs]
    rw [add_right_comm t T s,hp i (t+s)]
  obtain ⟨ψ,w',hψ,_hz,heψ,hw',G,_ho,hg,hG⟩ := winding_event_count n hn bs vs T hT hds hvs hps
    (fun t => hy (t+s)) (fun i j hij t => hclock i j hij (t+s))
  have hew := shifted_pair_winding_eq b φ ψ w w' T s hp hφ hψ he heψ hw hw'
  have hsum : (∑ p∈increasingPairs n,w' p)=∑ p∈increasingPairs n,w p := Finset.sum_congr rfl hew
  refine ⟨G,hg,?_⟩
  intro a ha
  obtain ⟨m,_hm,cut,label,_hmono,_hfirst,_hlast,_hunique,_hopt,_hcover,_hinj,_htime,henum,
    _hcharge,_hbudget,_heq,_hformula,hcount⟩ := hG a ha
  let S := Finset.univ.filter (fun i => label (finRotate m i)≠label i)
  let E := S.image (fun i => trajectoryTransitionTime cut i+s)
  refine ⟨E,?_,?_⟩
  · have hc : S.card≤2*∑ p∈increasingPairs n,w p := by simpa only [S,trajectoryEventCount,hsum] using hcount
    exact Finset.card_image_le.trans hc
  · intro t ht htie
    have hr : t-s∈Ico (0:ℝ) T := ⟨by linarith [ht.1],by linarith [ht.2]⟩
    have hh : trajectoryOptimalTie a bs (t-s) := by simpa only [trajectoryOptimalTie,bs,sub_add_cancel] using htie
    obtain ⟨i,hi,hchange⟩ := (henum (t-s) hr).mp hh
    exact Finset.mem_image.mpr ⟨i,Finset.mem_filter.mpr ⟨Finset.mem_univ _,hchange⟩,by rw [hi]; ring⟩

end MonotoneMatching
