import MonotoneMatching.RotationScore
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Topology.Algebra.Polynomial
import Mathlib.Topology.Separation.Basic

/-! Source-genericity by polynomial restrictions, avoiding motion perturbations. -/
noncomputable section
namespace MonotoneMatching
open scoped Polynomial

/-- A function that is polynomial on lines toward a nonzero witness has dense
nonzero locus. This is used only after supplying the actual polynomial formula. -/
theorem dense_nonzero_of_polynomial_lines {E : Type*} [AddCommGroup E] [Module ℝ E]
    [TopologicalSpace E] [ContinuousAdd E] [ContinuousSMul ℝ E]
    (f : E → ℝ) (v : E) (hv : f v ≠ 0)
    (hpoly : ∀ x : E, ∃ p : ℝ[X], ∀ t : ℝ,
      p.eval t = f ((1-t) • x + t • v)) : Dense {x | f x ≠ 0} := by
  intro x
  obtain ⟨p,hp⟩ := hpoly x
  have hpn : p ≠ 0 := by
    intro hz
    have h := hp 1
    simp [hz] at h
    exact hv h.symm
  have hd : Dense ({t : ℝ | p.eval t ≠ 0}) := by
    have h := dense_univ.sdiff_finite (Polynomial.finite_setOfPred_isRoot hpn)
    have he : Set.univ \ {t : ℝ | p.IsRoot t} = {t : ℝ | p.eval t ≠ 0} := by
      ext t
      simp only [Set.mem_sdiff, Set.mem_univ, Set.mem_ofPred_eq, true_and, Polynomial.IsRoot]
    rwa [he] at h
  let γ : ℝ → E := fun t => (1-t) • x + t • v
  have hc : Continuous γ := by fun_prop
  have hcl : γ 0 ∈ closure (γ '' {t : ℝ | p.eval t ≠ 0}) :=
    hc.continuousWithinAt.mem_closure_image (hd 0)
  have hsub : γ '' {t : ℝ | p.eval t ≠ 0} ⊆ {y | f y ≠ 0} := by
    rintro y ⟨t,ht,rfl⟩
    change f ((1-t) • x + t • v) ≠ 0
    rwa [← hp]
  have h := closure_mono hsub hcl
  simpa [γ] using h

end MonotoneMatching
