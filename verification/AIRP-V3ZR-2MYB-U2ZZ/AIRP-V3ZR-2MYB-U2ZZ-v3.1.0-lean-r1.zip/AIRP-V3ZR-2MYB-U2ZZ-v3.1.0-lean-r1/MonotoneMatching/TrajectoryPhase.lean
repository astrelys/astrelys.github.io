import MonotoneMatching.PhaseIntervals
import MonotoneMatching.TransposePhase
import MonotoneMatching.PairWinding
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

/-- The principal phase in a closed right half-plane has the same real increment
as every continuous argument lift of the physical nonzero vector. -/
theorem halfPlane_argument_lift_transport (γ : ℝ → ℂ) (c : ℂ) (φ : ℝ → ℝ)
    (hc : c ≠ 0) (hγ : Continuous γ) (hφ : Continuous φ)
    (hn : ∀ t, γ t ≠ 0)
    (he : ∀ t, (φ t : Real.Angle) = (Complex.arg (γ t) : Real.Angle))
    {s : Set ℝ} (hs : IsPreconnected s) (hr : ∀ t ∈ s, 0 ≤ (γ t*c).re)
    {u v : ℝ} (hu : u ∈ s) (hv : v ∈ s) :
    Complex.arg (γ v*c)-Complex.arg (γ u*c) = φ v-φ u := by
  have hcont : ContinuousOn (fun t => Complex.arg (γ t*c)-φ t) s := by
    apply ContinuousOn.sub _ hφ.continuousOn
    intro t ht
    exact ((Complex.continuousAt_arg
      (mem_slitPlane_of_re_nonneg (mul_ne_zero (hn t) hc) (hr t ht))).comp (f := fun t => γ t*c)
      (hγ.mul continuous_const).continuousAt).continuousWithinAt
  have hang (t : ℝ) : ((Complex.arg (γ t*c)-φ t : ℝ) : Real.Angle) =
      (Complex.arg c : Real.Angle) := by
    rw [Real.Angle.coe_sub, Complex.arg_mul_coe_angle (hn t) hc, he t]
    abel
  have h := (AddCircle.isCoveringMap_coe (2*Real.pi)).constOn_of_comp hs hcont
    (fun t _ t' _ => (hang t).trans (hang t').symm) hu hv
  linarith

/-- Exact transport on an actual weakly optimal cell, including its endpoints. -/
theorem identityPhase_trajectory_transport {n : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (φ : Fin n → Fin n → ℝ → ℝ)
    (ha : Function.Injective a) (hb : ∀ i, Continuous (b i))
    (hn : ∀ i j, i ≠ j → ∀ t, b i t ≠ b j t)
    (hφ : ∀ i j, Continuous (φ i j))
    (he : ∀ i j, i < j → ∀ t,
      (φ i j t : Real.Angle) = (Complex.arg (b j t-b i t) : Real.Angle))
    {s : Set ℝ} (hs : IsPreconnected s)
    (hopt : ∀ t ∈ s, ∀ τ, assignmentScore a (fun i => b i t) τ ≤
      assignmentScore a (fun i => b i t) (Equiv.refl _))
    {u v : ℝ} (hu : u ∈ s) (hv : v ∈ s) :
    identityPhase a (fun i => b i v)-identityPhase a (fun i => b i u) =
      ∑ p ∈ increasingPairs n, (φ p.1 p.2 v-φ p.1 p.2 u) := by
  classical
  rw [identityPhase,identityPhase,← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro p hp
  have hlt : p.1 < p.2 := (Finset.mem_filter.mp hp).2
  apply halfPlane_argument_lift_transport (fun t => b p.2 t-b p.1 t)
    ((starRingEnd ℂ) (a p.2-a p.1)) (φ p.1 p.2)
    ((map_ne_zero (starRingEnd ℂ)).mpr (sub_ne_zero.mpr (ha.ne hlt.ne.symm)))
    ((hb p.2).sub (hb p.1)) (hφ _ _)
    (fun t => sub_ne_zero.mpr (hn _ _ hlt.ne.symm t)) (he _ _ hlt) hs _ hu hv
  intro t ht
  exact weak_identity_pair_nonneg a (fun i => b i t) (hopt t ht) p.2 p.1

/-- Multiplication by a fixed nonzero complex number preserves lift increments. -/
theorem argument_lift_mul_increment (γ : ℝ → ℂ) (c : ℂ) (φ ψ : ℝ → ℝ)
    (hc : c ≠ 0) (hn : ∀ t, γ t ≠ 0) (hφ : Continuous φ) (hψ : Continuous ψ)
    (heφ : ∀ t, (φ t : Real.Angle) = (Complex.arg (γ t) : Real.Angle))
    (heψ : ∀ t, (ψ t : Real.Angle) = (Complex.arg (γ t*c) : Real.Angle))
    (u v : ℝ) : ψ v-ψ u=φ v-φ u := by
  have hang (t : ℝ) : ((ψ t-φ t : ℝ) : Real.Angle) = (Complex.arg c : Real.Angle) := by
    rw [Real.Angle.coe_sub,heψ t,heφ t,Complex.arg_mul_coe_angle (hn t) hc]
    abel
  have h := (AddCircle.isCoveringMap_coe (2*Real.pi)).const_of_comp (hψ.sub hφ)
    (fun t t' => (hang t).trans (hang t').symm) u v
  change ψ u-φ u=ψ v-φ v at h
  linarith

/-- Summing a symmetric off-diagonal quantity once per unordered pair. -/
theorem twice_increasingPairs_sum {n : ℕ} (f : Fin n → Fin n → ℝ)
    (hz : ∀ i, f i i=0) (hsym : ∀ i j, f i j=f j i) :
    2*(∑ p ∈ increasingPairs n, f p.1 p.2)=∑ i,∑ j,f i j := by
  classical
  have h (i j : Fin n) : f i j =
      (if i < j then f i j else 0)+(if j < i then f j i else 0) := by
    rcases lt_trichotomy i j with h | h | h
    · simp [h,not_lt_of_gt h]
    · subst j; simp [hz]
    · simp [h,not_lt_of_gt h,hsym i j]
  have he : (∑ p ∈ increasingPairs n, f p.1 p.2)=
      ∑ i,∑ j,if i < j then f i j else 0 := by
    simp only [increasingPairs,Finset.sum_filter,Finset.sum_product]
  conv_rhs => arg 2; ext i; arg 2; ext j; rw [h i j]
  simp only [Finset.sum_add_distrib]
  rw [Finset.sum_comm (f := fun i j : Fin n => if j < i then f j i else 0),← he]
  ring

/-- Unordered symmetric pair sums are invariant under relabeling. -/
theorem increasingPairs_sum_perm {n : ℕ} (f : Fin n → Fin n → ℝ)
    (hz : ∀ i, f i i=0) (hsym : ∀ i j, f i j=f j i) (σ : Equiv.Perm (Fin n)) :
    (∑ p ∈ increasingPairs n, f (σ p.1) (σ p.2))=∑ p ∈ increasingPairs n, f p.1 p.2 := by
  have h1 := twice_increasingPairs_sum (fun i j => f (σ i) (σ j))
    (fun i => hz (σ i)) (fun i j => hsym (σ i) (σ j))
  have h2 := twice_increasingPairs_sum f hz hsym
  have he : (∑ i,∑ j,f (σ i) (σ j))=∑ i,∑ j,f i j := by
    calc
      (∑ i,∑ j,f (σ i) (σ j)) = ∑ i,∑ j,f (σ i) j :=
        Finset.sum_congr rfl (fun i _ => Equiv.sum_comp σ (f (σ i)))
      _ = ∑ i,∑ j,f i j := Equiv.sum_comp σ (fun i => ∑ j,f i j)
  linarith

/-- Physical pair lift increments are symmetric in the two target labels. -/
theorem trajectory_lift_increment_symm {n : ℕ} (b : Fin n → ℝ → ℂ)
    (φ : Fin n → Fin n → ℝ → ℝ)
    (hn : ∀ i j, i ≠ j → ∀ t, b i t ≠ b j t)
    (hφ : ∀ i j, Continuous (φ i j))
    (he : ∀ i j, i ≠ j → ∀ t,
      (φ i j t : Real.Angle) = (Complex.arg (b j t-b i t) : Real.Angle))
    (u v : ℝ) (i j : Fin n) : φ i j v-φ i j u=φ j i v-φ j i u := by
  by_cases hij : i=j
  · subst j; rfl
  apply (argument_lift_mul_increment (fun t => b j t-b i t) (-1) (φ i j) (φ j i)
    (by norm_num) (fun t => sub_ne_zero.mpr (hn j i (Ne.symm hij) t)) (hφ i j) (hφ j i)
    (he i j hij) _ u v).symm
  intro t
  rw [show (b j t-b i t)*(-1)=b i t-b j t by ring]
  exact he j i (Ne.symm hij) t

/-- A simultaneous family of physical argument lifts, with zero diagonal. -/
theorem exists_trajectory_pair_lifts {n : ℕ} (b : Fin n → ℝ → ℂ)
    (hb : ∀ i, Continuous (b i))
    (hn : ∀ i j, i ≠ j → ∀ t, b i t ≠ b j t) :
    ∃ φ : Fin n → Fin n → ℝ → ℝ,
      (∀ i j, Continuous (φ i j)) ∧ (∀ i t, φ i i t=0) ∧
      (∀ i j, i ≠ j → ∀ t,
        (φ i j t : Real.Angle) = (Complex.arg (b j t-b i t) : Real.Angle)) := by
  classical
  have hex (i j : Fin n) : ∃ φ : ℝ → ℝ, Continuous φ ∧
      (i=j → ∀ t, φ t=0) ∧ (i≠j → ∀ t,
        (φ t : Real.Angle) = (Complex.arg (b j t-b i t) : Real.Angle)) := by
    by_cases hij : i=j
    · exact ⟨fun _ => 0,continuous_const,fun _ _ => rfl,fun h => False.elim (h hij)⟩
    · obtain ⟨φ,hφ⟩ := exists_real_argument_lift (fun t => b j t-b i t)
        ((hb j).sub (hb i)) (fun t => sub_ne_zero.mpr (hn j i (Ne.symm hij) t))
      exact ⟨φ,φ.continuous,fun h => False.elim (hij h),fun _ => hφ⟩
  choose φ hc hz he using hex
  exact ⟨φ,hc,fun i => hz i i rfl,he⟩

/-- Every optimal permutation cell transports the same physical total phase. -/
theorem identityPhase_trajectory_relabel_transport {n : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (φ : Fin n → Fin n → ℝ → ℝ)
    (ha : Function.Injective a) (hb : ∀ i, Continuous (b i))
    (hn : ∀ i j, i ≠ j → ∀ t, b i t ≠ b j t)
    (hφ : ∀ i j, Continuous (φ i j)) (hzero : ∀ i t, φ i i t=0)
    (he : ∀ i j, i ≠ j → ∀ t,
      (φ i j t : Real.Angle) = (Complex.arg (b j t-b i t) : Real.Angle))
    (σ : Equiv.Perm (Fin n)) {s : Set ℝ} (hs : IsPreconnected s)
    (hopt : ∀ t ∈ s, ∀ τ, assignmentScore a (fun i => b i t) τ ≤
      assignmentScore a (fun i => b i t) σ)
    {u v : ℝ} (hu : u ∈ s) (hv : v ∈ s) :
    identityPhase a (fun i => b (σ i) v)-identityPhase a (fun i => b (σ i) u) =
      ∑ p ∈ increasingPairs n, (φ p.1 p.2 v-φ p.1 p.2 u) := by
  have h := identityPhase_trajectory_transport a (fun i => b (σ i))
    (fun i j => φ (σ i) (σ j)) ha (fun i => hb (σ i))
    (fun i j hij => hn (σ i) (σ j) (σ.injective.ne hij))
    (fun i j => hφ (σ i) (σ j))
    (fun i j hij => he (σ i) (σ j) (σ.injective.ne hij.ne)) hs
    (fun t ht τ => hopt t ht (σ*τ)) hu hv
  rw [h]
  exact increasingPairs_sum_perm (fun i j => φ i j v-φ i j u)
    (fun i => by rw [hzero,hzero,sub_self])
    (trajectory_lift_increment_symm b φ hn hφ he u v) σ

end MonotoneMatching
