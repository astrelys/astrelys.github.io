import Mathlib.GroupTheory.Perm.List
import Mathlib.Data.Fintype.List
import Mathlib.Data.List.Chain
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Tactic

/-! Finite weighted paths for exact assignment dual potentials. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

def walkWeight {α : Type*} (d : α → α → ℝ) : List α → ℝ
  | [] => 0
  | [_] => 0
  | a :: b :: l => d a b + walkWeight d (b :: l)

theorem walkWeight_join {α : Type*} (d : α → α → ℝ) (l r : List α) (a : α) :
    walkWeight d (l ++ a :: r) = walkWeight d (l ++ [a]) + walkWeight d (a :: r) := by
  induction l with
  | nil => simp [walkWeight]
  | cons b l ih =>
    cases l with
    | nil => simp [walkWeight]
    | cons c l => simp only [List.cons_append, walkWeight] at ih ⊢; linarith

theorem walkWeight_append_last {α : Type*} (d : α → α → ℝ)
    (l : List α) (a b : α) :
    walkWeight d (l ++ [a,b]) = walkWeight d (l ++ [a]) + d a b := by
  simpa [walkWeight] using walkWeight_join d l [b] a

/-- If a function sends each vertex to the next one along a closed walk,
the edge sum is its permutation score on the listed vertices. -/
theorem walkWeight_eq_map_sum_of_chain {α : Type*} (d : α → α → ℝ) (f : α → α)
    (l : List α) (a : α) (h : (l ++ [a]).IsChain (fun x y => f x = y)) :
    walkWeight d (l ++ [a]) = (l.map (fun x => d x (f x))).sum := by
  induction l with
  | nil => simp [walkWeight]
  | cons b l ih =>
    cases l with
    | nil =>
      have hb : f b = a := by simpa using h
      simp [walkWeight, hb]
    | cons c l =>
      have hc : f b = c ∧ (c :: l ++ [a]).IsChain (fun x y => f x = y) := by simpa using h
      simp only [List.cons_append, walkWeight, List.map_cons, List.sum_cons]
      rw [hc.1]
      simpa only [List.cons_append, List.map_cons, List.sum_cons] using
        congrArg (fun w => d b c + w) (ih hc.2)

/-- The list permutation follows the simple closed walk exactly. -/
theorem formPerm_closed_chain {α : Type*} [DecidableEq α] (a : α) (l : List α)
    (h : (a::l).Nodup) :
    ((a::l) ++ [a]).IsChain (fun x y => (a::l).formPerm x = y) := by
  rw [List.isChain_iff_getElem]
  intro i hi
  have hil : i < (a::l).length := by simp only [List.length_append, List.length_singleton] at hi; omega
  rw [List.getElem_append_left hil]
  have hf := List.formPerm_apply_getElem (a::l) h i hil
  by_cases he : i+1 < (a::l).length
  · rw [List.getElem_append_left he]
    simpa only [Nat.mod_eq_of_lt he] using hf
  · have heq : i+1 = (a::l).length := by omega
    rw [List.getElem_append_right (by omega)]
    simpa [heq] using hf

/-- If every permutation has nonpositive total weight and diagonal weights
vanish, every simple closed walk has nonpositive weight. -/
theorem simple_closed_walk_nonpositive {α : Type*} [Fintype α] [DecidableEq α]
    (d : α → α → ℝ) (hdiag : ∀ i, d i i = 0)
    (hperm : ∀ σ : Equiv.Perm α, (∑ i, d i (σ i)) ≤ 0)
    (a : α) (l : List α) (h : (a::l).Nodup) :
    walkWeight d ((a::l) ++ [a]) ≤ 0 := by
  rw [walkWeight_eq_map_sum_of_chain d ((a::l).formPerm) (a::l) a
    (formPerm_closed_chain a l h)]
  rw [← List.sum_toFinset _ h]
  have he : (∑ i ∈ (a::l).toFinset, d i ((a::l).formPerm i)) =
      ∑ i, d i ((a::l).formPerm i) := by
    apply Finset.sum_subset (Finset.subset_univ _)
    intro i _ hi
    have hn : i ∉ a::l := by simpa only [List.mem_toFinset] using hi
    rw [List.formPerm_apply_of_notMem hn, hdiag]
  rw [he]
  exact hperm _

end MonotoneMatching
