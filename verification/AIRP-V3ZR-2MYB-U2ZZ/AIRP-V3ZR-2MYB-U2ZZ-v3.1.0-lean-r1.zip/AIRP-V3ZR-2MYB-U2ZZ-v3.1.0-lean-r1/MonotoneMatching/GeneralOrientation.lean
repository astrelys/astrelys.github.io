import MonotoneMatching.TransitionOrientationDichotomy
import MonotoneMatching.FiniteVelocityFlux
import MonotoneMatching.RotationFluxIdentity

/-! Clockwise finite velocity data select the positive transition orientation. -/
noncomputable section
namespace MonotoneMatching
open scoped InnerProductSpace BigOperators

/-- Actual score derivatives reduce exactly to the active cycle. -/
theorem general_event_derivative_cycle_flux {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) {n : ℕ} (a u : Fin n → ℂ) (σ : Equiv.Perm (Fin n))
    (e : ι → Fin n) (he : Function.Injective e) (hsucc : ∀ i,e (next i)=σ (e i))
    (hcover : ∀ i,σ i≠i → ∃ j,e j=i) :
    assignmentScore a u σ-assignmentScore a u (Equiv.refl _)=
      ∑ i,inner ℝ (a (e i)) (u (e (next i))-u (e i)) := by
  simp only [assignmentScore,Equiv.refl_apply,← Finset.sum_sub_distrib,← inner_sub_right]
  symm
  apply Fintype.sum_of_injective e he
  · intro i hi
    have hfix : σ i=i := by by_contra hn; exact hi (hcover i hn)
    simp only [hfix,sub_self,inner_zero_right]
  · intro i
    rw [hsucc]

theorem general_positive_transition_polygon_winding {ι : Type*} [Fintype ι] [DecidableEq ι] [Nonempty ι]
    (next : Equiv.Perm ι) (htrans : ∀ i j : ι, ∃ k : ℕ, (next^k) i=j)
    {n : ℕ} (a y u : Fin n → ℂ) (hy : Function.Injective y)
    (σ : Equiv.Perm (Fin n)) (r c : Fin n → ℝ)
    (hbound : ∀ i j, inner ℝ (a i) (y j) ≤ r i+c j)
    (hexact : ∀ i j, r i+c j=inner ℝ (a i) (y j) ↔ j=i ∨ j=σ i)
    (e : ι → Fin n) (he : Function.Injective e) (hsucc : ∀ i, e (next i)=σ (e i))
    (hm : ∀ i, σ (e i)≠e i) (h2 : ∀ i, σ (σ (e i))≠e i)
    (hcover : ∀ i, σ i≠i → ∃ j, e j=i)
    (hmono : ∀ i j,0 ≤ inner ℝ (y i-y j) (Complex.I*(u i-u j)))
    (hD : 0 < assignmentScore a u σ-assignmentScore a u (Equiv.refl _)) :
    (∀ i q, q∈strictDualCell a r (e i) → 0<edgeSide (y (e i)) (y (e (next i))) q →
      polygonIndexPhase next (y∘e) q=2*Real.pi) ∧
    (∀ i q, q∈strictDualCell a r (e i) → edgeSide (y (e i)) (y (e (next i))) q<0 →
      polygonIndexPhase next (y∘e) q=0) ∧
    (∀ q, q∉polygonBoundary next (y∘e) → polygonIndexPhase next (y∘e) q=0 ∨
      polygonIndexPhase next (y∘e) q=2*Real.pi) := by
  let : Nonempty (Fin n) := ⟨e (Classical.choice inferInstance)⟩
  obtain ⟨L,R,hgap,hdich,hL,hR,hvalues⟩ := transition_polygon_orientation_dichotomy
    next htrans a y hy σ r c hbound hexact e he hsucc hm h2
  rcases hdich with hp | hn
  · refine ⟨?_,?_,?_⟩
    · intro i q hq hs
      exact (hL i q hq hs).trans hp.1
    · intro i q hq hs
      exact (hR i q hq hs).trans hp.2
    · intro q hq
      rcases hvalues q hq with hz | hl | hr
      · exact Or.inl hz
      · exact Or.inr (hl.trans hp.1)
      · exact Or.inl (hr.trans hp.2)
  · have hphase (q : ℂ) (hq : q∉polygonBoundary next (y∘e)) : polygonIndexPhase next (y∘e) q≤0 := by
      rcases hvalues q hq with hz | hl | hr
      · exact hz.le
      · rw [hl,hn.1]
      · rw [hr,hn.2]
        linarith [Real.pi_pos]
    have hedge (i : ι) (t : ℝ) (ht : t∈Set.Ioo (0:ℝ) 1) :
        (1-t) • (y∘e) i+t • (y∘e) (next i)∈strictDualCell a r (e i) := by
      intro j hj
      simpa only [Function.comp_def,hsucc] using
        transition_edge_unique_row a y σ r c hbound hexact (e i) (h2 i) j hj ht.1 ht.2
    have hflux := finite_velocity_dual_polygon_flux_nonpos next (y∘e) (u∘e) (hy.comp he)
      a r e he hedge L R hgap hL hR hphase (fun i j => hmono (e i) (e j))
    rw [general_event_derivative_cycle_flux next a u σ e he hsucc hcover] at hD
    exact ((not_lt_of_ge hflux) hD).elim

end MonotoneMatching
