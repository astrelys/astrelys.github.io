import MonotoneMatching.PolygonPrimitiveReduction
import MonotoneMatching.PlanarPositiveForms
import Mathlib.Analysis.Convex.Deriv
import Mathlib.Analysis.Calculus.FDeriv.Symmetric
import Mathlib.Analysis.Calculus.FDeriv.CompCLM
import Mathlib.Analysis.InnerProductSpace.Basic
noncomputable section
namespace MonotoneMatching
open Set
open scoped BigOperators InnerProductSpace
set_option backward.isDefEq.respectTransparency.types false

/-- The second derivative of a twice differentiable convex planar function has a
nonnegative quadratic form. -/
theorem convex_planar_hessian_nonnegative
    (g : ℂ → ℝ) (Dg : ℂ → ℂ →L[ℝ] ℝ) (Hg : ℂ → ℂ →L[ℝ] ℂ →L[ℝ] ℝ)
    (hconv : ConvexOn ℝ univ g) (hdg : ∀ p,HasFDerivAt g (Dg p) p)
    (hHg : ∀ p,HasFDerivAt Dg (Hg p) p) (p v : ℂ) : 0 ≤ Hg p v v := by
  let f : ℝ → ℝ := fun t => g (p+t • v)
  have hfconv : ConvexOn ℝ univ f := by
    refine ⟨convex_univ,?_⟩
    intro s _ t _ a b ha hb hab
    have he : a • (p+s • v)+b • (p+t • v)=p+(a*s+b*t) • v := by
      calc
        a • (p+s • v)+b • (p+t • v)=(a+b) • p+(a*s+b*t) • v := by module
        _ = p+(a*s+b*t) • v := by rw [hab,one_smul]
    have hh := hconv.2 (mem_univ (p+s • v)) (mem_univ (p+t • v)) ha hb hab
    rw [he] at hh
    exact hh
  have hp (t : ℝ) : HasDerivAt (fun t : ℝ => p+t • v) v t := by
    simpa using (hasDerivAt_id t).smul_const v |>.const_add p
  have hfd (t : ℝ) : HasDerivAt f (Dg (p+t • v) v) t := (hdg _).comp_hasDerivAt t (hp t)
  have hm : Monotone (fun t : ℝ => Dg (p+t • v) v) := by
    intro s t hst
    have hh := hfconv.monotoneOn_deriv (fun t _ => (hfd t).differentiableAt)
      (mem_univ s) (mem_univ t) hst
    rwa [(hfd s).deriv,(hfd t).deriv] at hh
  have hd : HasDerivAt (fun t : ℝ => Dg (p+t • v) v) (Hg p v v) 0 := by
    have hh := ((ContinuousLinearMap.apply ℝ ℝ v).hasFDerivAt.comp (p+(0:ℝ) • v)
      (hHg _)).comp_hasDerivAt 0 (hp 0)
    simpa only [Function.comp_def,ContinuousLinearMap.apply_apply,zero_smul,add_zero] using! hh
  rw [← hd.deriv]
  exact hm.deriv_nonneg


/-- Coordinate expansion of a planar bilinear form. -/
theorem planar_bilinear_coordinates (H : ℂ →L[ℝ] ℂ →L[ℝ] ℝ) (z w : ℂ) :
    H z w=z.re*w.re*H 1 1+z.re*w.im*H 1 Complex.I+
      z.im*w.re*H Complex.I 1+z.im*w.im*H Complex.I Complex.I := by
  have hz : z=z.re • (1:ℂ)+z.im • Complex.I := by
    apply Complex.ext <;> simp [Complex.real_smul]
  have hw : w=w.re • (1:ℂ)+w.im • Complex.I := by
    apply Complex.ext <;> simp [Complex.real_smul]
  conv_lhs => rw [hz,hw]
  simp only [map_add,map_smul,add_apply,smul_apply,smul_eq_mul]
  ring

/-- The uncancelled part of the convex flux curl is nonnegative. -/
theorem convex_flux_curl_algebra (B : ℂ →L[ℝ] ℂ) (H : ℂ →L[ℝ] ℂ →L[ℝ] ℝ)
    (hsym : H 1 Complex.I=H Complex.I 1) (hH : ∀ z,0 ≤ H z z)
    (hB : ∀ z,0 ≤ inner ℝ z (Complex.I*B z)) :
    0 ≤ H 1 (B Complex.I)-H Complex.I (B 1) := by
  have hA (x y : ℝ) : 0 ≤ -(B 1).im*x^2+
      2*(((B 1).re-(B Complex.I).im)/2)*x*y+(B Complex.I).re*y^2 := by
    have hh := hB (x • (1:ℂ)+y • Complex.I)
    simp only [map_add,map_smul] at hh
    simp [Complex.inner,Complex.real_smul] at hh
    nlinarith
  have hC (x y : ℝ) : 0 ≤ H 1 1*x^2+2*H 1 Complex.I*x*y+H Complex.I Complex.I*y^2 := by
    have hh := hH (x • (1:ℂ)+y • Complex.I)
    rw [planar_bilinear_coordinates] at hh
    simp only [Complex.add_re,Complex.add_im,Complex.smul_re,Complex.smul_im,
      smul_eq_mul,Complex.one_re,Complex.one_im,Complex.I_re,Complex.I_im] at hh
    rw [← hsym] at hh
    nlinarith
  have hp := planar_positive_adjugate_pairing (-(B 1).im) (((B 1).re-(B Complex.I).im)/2)
    (B Complex.I).re (H 1 1) (H 1 Complex.I) (H Complex.I Complex.I) hA hC
  rw [planar_bilinear_coordinates H 1 (B Complex.I),planar_bilinear_coordinates H Complex.I (B 1)]
  simp only [Complex.one_re,Complex.one_im,Complex.I_re,Complex.I_im,one_mul,zero_mul,zero_add,add_zero]
  rw [← hsym]
  nlinarith

/-- Smooth convex-gradient flux is nonpositive on a negatively oriented transition polygon.
Both derivative levels are actual derivatives; mixed velocity derivatives cancel by symmetry. -/
theorem smooth_convex_velocity_polygon_flux_nonpos {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (y : ι → ℂ)
    {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ) (e : ι → Fin n) (he : Function.Injective e)
    (hedge : ∀ i, ∀ t∈Set.Ioo (0:ℝ) 1, (1-t) • y i+t • y (next i)∈strictDualCell a r (e i))
    (L R : ℝ) (hgap : L-R=2*Real.pi)
    (hL : ∀ i q, q∈strictDualCell a r (e i) → 0<edgeSide (y i) (y (next i)) q → polygonIndexPhase next y q=L)
    (hR : ∀ i q, q∈strictDualCell a r (e i) → edgeSide (y i) (y (next i)) q<0 → polygonIndexPhase next y q=R)
    (hphase : ∀ q, q∉polygonBoundary next y → polygonIndexPhase next y q≤0)
    (g : ℂ → ℝ) (Dg : ℂ → ℂ →L[ℝ] ℝ) (Hg : ℂ → ℂ →L[ℝ] ℂ →L[ℝ] ℝ)
    (v : ℂ → ℂ) (Dv : ℂ → ℂ →L[ℝ] ℂ) (DDv : ℂ → ℂ →L[ℝ] ℂ →L[ℝ] ℂ)
    (hconv : ConvexOn ℝ univ g) (hDg : Continuous Dg) (hHg : Continuous Hg)
    (hDv : Continuous Dv) (hDDv : Continuous DDv)
    (hdg : ∀ p,HasFDerivAt g (Dg p) p) (h2g : ∀ p,HasFDerivAt Dg (Hg p) p)
    (hdv : ∀ p,HasFDerivAt v (Dv p) p) (h2v : ∀ p,HasFDerivAt Dv (DDv p) p)
    (hmono : ∀ p z,0 ≤ inner ℝ z (Complex.I*Dv p z)) :
    (∑ i,∫ t in (0:ℝ)..1,Dg ((1-t) • y i+t • y (next i))
      (Dv ((1-t) • y i+t • y (next i)) (y (next i)-y i))) ≤ 0 := by
  let F (u : ℂ) (p : ℂ) := Dg p (Dv p u)
  let DF (u : ℂ) (p : ℂ) := (Dg p).comp ((ContinuousLinearMap.apply ℝ ℂ u).comp (DDv p))+
    (Hg p).flip (Dv p u)
  have hF (u : ℂ) : Continuous (F u) := hDg.clm_apply (hDv.clm_apply continuous_const)
  have hDF (u : ℂ) : Continuous (DF u) := by
    dsimp [DF]
    have hflip : Continuous (fun p => (Hg p).flip) :=
      (ContinuousLinearMap.flipₗᵢ ℝ ℂ ℂ ℝ).continuous.comp hHg
    exact (hDg.clm_comp (continuous_const.clm_comp hDDv)).add
      (hflip.clm_apply (hDv.clm_apply continuous_const))
  have hdF (u p : ℂ) : HasFDerivAt (F u) (DF u p) p :=
    (h2g p).clm_apply ((ContinuousLinearMap.apply ℝ ℂ u).hasFDerivAt.comp p (h2v p))
  have hcurl (p : ℂ) : 0 ≤ DF Complex.I p 1-DF 1 p Complex.I := by
    have hg_sym := second_derivative_symmetric hdg (h2g p) 1 Complex.I
    have hv_sym := second_derivative_symmetric hdv (h2v p) 1 Complex.I
    have hp := convex_flux_curl_algebra (Dv p) (Hg p) hg_sym
      (convex_planar_hessian_nonnegative g Dg Hg hconv hdg h2g p) (hmono p)
    dsimp [DF]
    simp only [add_apply,ContinuousLinearMap.comp_apply,ContinuousLinearMap.apply_apply,
      ContinuousLinearMap.flip_apply,hv_sym]
    linarith
  have hb := polygon_nonnegative_curl_integral_nonpos next y a r e he hedge L R hgap hL hR hphase
    (F 1) (F Complex.I) (DF 1) (DF Complex.I) (hF 1) (hF Complex.I) (hDF 1) (hdF 1) (hdF Complex.I) hcurl
  convert hb using 1
  apply Finset.sum_congr rfl
  intro i _
  apply intervalIntegral.integral_congr
  intro t _
  have hz : y (next i)-y i=((y (next i)).re-(y i).re) • (1:ℂ)+
      ((y (next i)).im-(y i).im) • Complex.I := by
    apply Complex.ext <;> simp [Complex.real_smul]
  dsimp only
  rw [hz,map_add,map_smul,map_smul,map_add,map_smul,map_smul]
  dsimp [F]
  ring

end MonotoneMatching
