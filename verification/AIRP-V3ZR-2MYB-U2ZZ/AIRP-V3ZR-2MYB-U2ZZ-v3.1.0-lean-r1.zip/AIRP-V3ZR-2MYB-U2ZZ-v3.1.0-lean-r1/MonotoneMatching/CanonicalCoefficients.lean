import MonotoneMatching.SourceStability
import Mathlib.Order.PiLex
noncomputable section
namespace MonotoneMatching
open Set Filter
open scoped BigOperators Topology
set_option backward.isDefEq.respectTransparency.types false

/-- Finite polynomial written in increasing coefficient order. -/
def coefficientPolynomial {d : ℕ} (c : Fin d → ℝ) (x : ℝ) : ℝ :=
  ∑ i,c i*x^i.val

/-- The first nonzero coefficient controls the sign at sufficiently small
positive real arguments. No global genericity of the perturbation curve is used. -/
theorem polynomial_positive_of_first_positive {d : ℕ} (c : Fin d → ℝ)
    (h : ∃ i,(∀ j,j < i → c j=0) ∧ 0<c i) :
    ∀ᶠ x in 𝓝[>] (0:ℝ),0<coefficientPolynomial c x := by
  induction d with
  | zero => obtain ⟨i,_⟩ := h; exact Fin.elim0 i
  | succ d ih =>
    obtain ⟨i,hbefore,hpos⟩ := h
    refine Fin.cases ?_ (fun k => ?_) i
      (motive := fun i => (∀ j,j < i → c j=0) → 0<c i →
        ∀ᶠ x in 𝓝[>] (0:ℝ),0<coefficientPolynomial c x) hbefore hpos
    · intro _ hc
      have hcont : Continuous (coefficientPolynomial c) := by
        unfold coefficientPolynomial
        fun_prop
      have he : coefficientPolynomial c 0=c 0 := by
        simp [coefficientPolynomial,Fin.sum_univ_succ]
      have hp : ∀ᶠ x in 𝓝 (0:ℝ),0<coefficientPolynomial c x :=
        hcont.continuousAt.eventually (isOpen_Ioi.mem_nhds (by rwa [he]))
      exact hp.filter_mono nhdsWithin_le_nhds
    · intro hb hc
      have hzero : c 0=0 := hb 0 (by simp)
      have ht := ih (fun j => c j.succ) ⟨k,fun j hj => hb j.succ (Fin.succ_lt_succ_iff.mpr hj),hc⟩
      filter_upwards [ht,self_mem_nhdsWithin] with x hx hxp
      have he : coefficientPolynomial c x=x*coefficientPolynomial (fun j => c j.succ) x := by
        simp only [coefficientPolynomial,Fin.sum_univ_succ,hzero,zero_mul,zero_add,
          Fin.val_succ,pow_succ,Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro j _
        ring
      rw [he]
      exact mul_pos hxp hx

/-- Standard coordinate order: Re(z_0), Im(z_0), Re(z_1), Im(z_1), ... . -/
def flatRealCoordinates {n : ℕ} (z : Fin n → ℂ) (k : Fin (n*2)) : ℝ :=
  if (finProdFinEquiv.symm k).2=0 then (z (finProdFinEquiv.symm k).1).re
    else (z (finProdFinEquiv.symm k).1).im

theorem flatRealCoordinates_injective {n : ℕ} :
    Function.Injective (flatRealCoordinates (n := n)) := by
  intro x y h
  funext i
  apply Complex.ext
  · have hh := congrFun h (finProdFinEquiv (i,0))
    simpa only [flatRealCoordinates,Equiv.symm_apply_apply,ite_true] using hh
  · have hh := congrFun h (finProdFinEquiv (i,1))
    simpa only [flatRealCoordinates,Equiv.symm_apply_apply,(by decide : (1 : Fin 2) ≠ 0),ite_false] using hh

/-- Original score first, followed by the standard target coordinates. -/
def canonicalCoefficients {n : ℕ} (a y : Fin n → ℂ) (σ : Equiv.Perm (Fin n)) :
    Fin (n*2+1) → ℝ := Fin.cons (assignmentScore a y σ) (flatRealCoordinates (y∘σ))

theorem canonicalCoefficients_injective {n : ℕ} (a y : Fin n → ℂ)
    (hy : Function.Injective y) : Function.Injective (canonicalCoefficients a y) := by
  intro σ τ h
  have he : flatRealCoordinates (y∘σ)=flatRealCoordinates (y∘τ) := by
    funext k
    exact congrFun h k.succ
  have hh := flatRealCoordinates_injective he
  apply Equiv.ext
  intro i
  exact hy (congrFun hh i)

/-- A lexicographic maximizing permutation, defined at every configuration.
Noncollision makes this maximizing permutation unique. -/
def canonicalPermutation {n : ℕ} (a y : Fin n → ℂ) : Equiv.Perm (Fin n) :=
  Classical.choose (Finset.exists_max_image Finset.univ
    (fun σ : Equiv.Perm (Fin n) => toLex (canonicalCoefficients a y σ)) Finset.univ_nonempty)

theorem canonicalPermutation_maximal {n : ℕ} (a y : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) :
    toLex (canonicalCoefficients a y σ)≤toLex (canonicalCoefficients a y (canonicalPermutation a y)) :=
  (Classical.choose_spec (Finset.exists_max_image Finset.univ
    (fun σ : Equiv.Perm (Fin n) => toLex (canonicalCoefficients a y σ)) Finset.univ_nonempty)).2 σ
      (Finset.mem_univ σ)

theorem canonicalPermutation_strict {n : ℕ} (a y : Fin n → ℂ)
    (hy : Function.Injective y) (σ : Equiv.Perm (Fin n)) (hne : σ≠canonicalPermutation a y) :
    toLex (canonicalCoefficients a y σ)<toLex (canonicalCoefficients a y (canonicalPermutation a y)) := by
  apply lt_of_le_of_ne (canonicalPermutation_maximal a y σ)
  intro he
  exact hne (canonicalCoefficients_injective a y hy (congrArg ofLex he))

/-- The first lexicographic criterion guarantees optimality for the original score. -/
theorem canonicalPermutation_optimal {n : ℕ} (a y : Fin n → ℂ) (σ : Equiv.Perm (Fin n)) :
    assignmentScore a y σ≤assignmentScore a y (canonicalPermutation a y) := by
  by_contra! hh
  have hl : toLex (canonicalCoefficients a y (canonicalPermutation a y))<
      toLex (canonicalCoefficients a y σ) := by
    exact ⟨0,fun j hj => (Fin.not_lt_zero j hj).elim,hh⟩
  exact (not_lt_of_ge (canonicalPermutation_maximal a y σ)) hl

/-- The manuscript's source perturbation with fixed standard-coordinate powers. -/
def sourceLexPerturb {n : ℕ} (a : Fin n → ℂ) (x : ℝ) (i : Fin n) : ℂ :=
  a i+⟨x^(2*i.val+1),x^(2*i.val+2)⟩

theorem sourceLexPerturb_score {n : ℕ} (a y : Fin n → ℂ) (σ : Equiv.Perm (Fin n)) (x : ℝ) :
    assignmentScore (sourceLexPerturb a x) y σ=coefficientPolynomial (canonicalCoefficients a y σ) x := by
  rw [coefficientPolynomial,Fin.sum_univ_succ]
  simp only [canonicalCoefficients,Fin.cons_zero,Fin.val_zero,pow_zero,mul_one,Fin.cons_succ,Fin.val_succ]
  rw [← Equiv.sum_comp finProdFinEquiv]
  simp only [Fintype.sum_prod_type,Fin.sum_univ_two,flatRealCoordinates,Equiv.symm_apply_apply,
    ite_true,(by decide : (1 : Fin 2) ≠ 0),ite_false]
  simp only [assignmentScore,sourceLexPerturb,Complex.inner,Complex.add_re,Complex.add_im,
    Complex.conj_re,Complex.conj_im,Complex.mul_re]
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  change _ = (y (σ i)).re*(a i).re-(y (σ i)).im*(-(a i).im)+
    ((y (σ i)).re*x^(0+2*i.val+1)+(y (σ i)).im*x^(1+2*i.val+1))
  have h1 : 0+2*i.val+1=2*i.val+1 := by omega
  have h2 : 1+2*i.val+1=2*i.val+2 := by omega
  rw [h1,h2]
  ring

/-- Every canonical choice becomes a strict optimum along the same polynomial
source perturbation, eventually for small positive parameters. -/
theorem canonical_eventually_strict {n : ℕ} (a y : Fin n → ℂ)
    (hy : Function.Injective y) :
    ∀ᶠ x in 𝓝[>] (0:ℝ),UniqueMinimum (sourceLexPerturb a x) y (canonicalPermutation a y) := by
  classical
  apply Filter.eventually_all.mpr
  intro σ
  by_cases he : σ=canonicalPermutation a y
  · exact Filter.Eventually.of_forall (fun _ h => (h he).elim)
  · have hl := canonicalPermutation_strict a y hy σ he
    obtain ⟨k,hbefore,hpos⟩ := hl
    have hp := polynomial_positive_of_first_positive
      (fun j => canonicalCoefficients a y (canonicalPermutation a y) j-canonicalCoefficients a y σ j)
      ⟨k,fun j hj => sub_eq_zero.mpr (hbefore j hj).symm,sub_pos.mpr hpos⟩
    filter_upwards [hp] with x hx _
    apply (assignmentCost_lt_iff_score_gt _ _ _ _).mpr
    rw [sourceLexPerturb_score,sourceLexPerturb_score]
    have heval : coefficientPolynomial
        (fun j => canonicalCoefficients a y (canonicalPermutation a y) j-canonicalCoefficients a y σ j) x=
        coefficientPolynomial (canonicalCoefficients a y (canonicalPermutation a y)) x-
          coefficientPolynomial (canonicalCoefficients a y σ) x := by
      simp only [coefficientPolynomial,sub_mul,Finset.sum_sub_distrib]
    rwa [heval,sub_pos] at hx

/-- Simultaneous strict realization of any finite list of canonical samples. -/
theorem canonical_finite_strict_realization {n : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (hy : ∀ t,Function.Injective (fun j => b j t)) (s : Finset ℝ) :
    ∃ a' : Fin n → ℂ,∀ t∈s,UniqueMinimum a' (fun j => b j t)
      (canonicalPermutation a (fun j => b j t)) := by
  have hh : ∀ᶠ x in 𝓝[>] (0:ℝ),∀ t∈s,UniqueMinimum (sourceLexPerturb a x)
      (fun j => b j t) (canonicalPermutation a (fun j => b j t)) :=
    s.eventually_all.mpr (fun t _ => canonical_eventually_strict a (fun j => b j t) (hy t))
  obtain ⟨x,hx⟩ := hh.exists
  exact ⟨sourceLexPerturb a x,hx⟩

/-- A dense source set can realize the same finite canonical samples strictly. -/
theorem canonical_finite_dense_realization {n : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (hy : ∀ t,Function.Injective (fun j => b j t))
    (G : Set (Fin n → ℂ)) (hg : Dense G) (s : Finset ℝ) :
    ∃ a'∈G,∀ t∈s,UniqueMinimum a' (fun j => b j t)
      (canonicalPermutation a (fun j => b j t)) := by
  obtain ⟨a',ha'⟩ := canonical_finite_strict_realization a b hy s
  let U := {z : Fin n → ℂ | ∀ t∈s,UniqueMinimum z (fun j => b j t)
    (canonicalPermutation a (fun j => b j t))}
  have ho : IsOpen U := by
    dsimp [U]
    simp only [Set.ofPred_forall]
    exact isOpen_biInter_finset fun t _ => isOpen_source_uniqueMinimum _ _
  obtain ⟨z,hz,hU⟩ := hg.exists_mem_open ho ⟨a',ha'⟩
  exact ⟨z,hz,hU⟩

end MonotoneMatching
