import MonotoneMatching.ProjectionSweep

/-! All-n lower bound from two disjoint finite families of strict projection orders. -/
noncomputable section
namespace MonotoneMatching

/-- The two oriented sweeps yield twice as many different actual optima as pair thresholds. -/
theorem sharp_rotationCount_ge_twice_thresholds (n : ℕ) :
    2 * (sharpThresholds n).card ≤
      rotationCount (fun i : Fin n => (i.val : ℂ)) (fun i => sharpTarget i.val) := by
  classical
  let s := sharpThresholds n
  by_cases hs : s.Nonempty
  swap
  · have hz : s = ∅ := Finset.not_nonempty_iff_eq_empty.mp hs
    change 2 * s.card ≤ _
    simp [hz]
  have hex : ∀ x : s × Bool, ∃ σ : Equiv.Perm (Fin n),
      StrictMono (fun i => signedSweep (finiteCut s x.1.val) x.2 (σ i).val) := by
    intro x
    exact exists_sorted_permutation _
      (signedSweep_injective _ _ (finiteCut_not_mem s x.1.val))
  choose σ hσ using hex
  have hmem (x : s × Bool) : σ x ∈ rotationOptimizers
      (fun i : Fin n => (i.val : ℂ)) (fun i => sharpTarget i.val) :=
    signedSweep_sorted_mem _ _ _ (hσ x)
  have hcomp (x y : s × Bool) (he : σ x = σ y) (z : ℝ) (hz : z ∈ s) :
      (if x.2 then z < finiteCut s x.1.val else finiteCut s x.1.val < z) ↔
      (if y.2 then z < finiteCut s y.1.val else finiteCut s y.1.val < z) := by
    obtain ⟨⟨p,q⟩, hpq, rfl⟩ := Finset.mem_image.mp hz
    have hp : p.val < q.val := (Finset.mem_filter.mp hpq).2
    have hx := sorted_permutation_comparison (fun i : Fin n => signedSweep (finiteCut s x.1.val) x.2 i.val) (σ x) (hσ x) p q
    have hy := sorted_permutation_comparison (fun i : Fin n => signedSweep (finiteCut s y.1.val) y.2 i.val) (σ y) (hσ y) p q
    rw [he] at hx
    have h := hx.trans hy.symm
    simpa only [signedSweep_comparison _ _ hp] using h
  have hinj : Function.Injective σ := by
    intro x y he
    have hb : x.2 = y.2 := by
      have hm := s.max'_mem hs
      have hx : finiteCut s x.1.val < s.max' hs :=
        (finiteCut_lt s x.1.val).trans_le (s.le_max' _ x.1.property)
      have hy : finiteCut s y.1.val < s.max' hs :=
        (finiteCut_lt s y.1.val).trans_le (s.le_max' _ y.1.property)
      have h := hcomp x y he _ hm
      cases hxb : x.2 <;> cases hyb : y.2
      · rfl
      · simp only [hxb, hyb, Bool.false_eq_true, ↓reduceIte] at h
        exact False.elim ((not_lt_of_gt hy) (h.mp hx))
      · simp only [hxb, hyb, Bool.false_eq_true, ↓reduceIte] at h
        exact False.elim ((not_lt_of_gt hx) (h.mpr hy))
      · rfl
    have hv : x.1.val = y.1.val := by
      have aux : ∀ u v : s × Bool, σ u = σ v → u.2 = v.2 → ¬u.1.val < v.1.val := by
        intro u v heq hb' huv
        have hu := finiteCut_lt s u.1.val
        have hv := (lt_finiteCut_iff s v.1.val u.1.val u.1.property).mpr huv
        have h := hcomp u v heq _ u.1.property
        rw [hb'] at h
        cases hvb : v.2
        · simp only [hvb, Bool.false_eq_true, ↓reduceIte] at h
          exact (not_lt_of_gt hv) (h.mp hu)
        · simp only [hvb, ↓reduceIte] at h
          exact (not_lt_of_gt hu) (h.mpr hv)
      exact le_antisymm (le_of_not_gt (aux y x he.symm hb.symm))
        (le_of_not_gt (aux x y he hb))
    exact Prod.ext (Subtype.ext hv) hb
  let f : s × Bool → rotationOptimizers
      (fun i : Fin n => (i.val : ℂ)) (fun i => sharpTarget i.val) :=
    fun x => ⟨σ x, hmem x⟩
  have hf : Function.Injective f := fun x y h => hinj (congrArg Subtype.val h)
  have hcard := Fintype.card_le_of_injective f hf
  simp only [Fintype.card_prod, Fintype.card_coe, Fintype.card_bool] at hcard
  change 2 * s.card ≤ _
  exact (Nat.mul_comm 2 s.card) ▸ hcard

theorem twice_choose_two (n : ℕ) : 2 * n.choose 2 = n * (n - 1) := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [Nat.choose_succ_succ, Nat.choose_one_right]
    simp only [Nat.add_sub_cancel]
    by_cases hn : n = 0
    · simp [hn]
    · have hs : n - 1 + 1 = n := by omega
      nlinarith

/-- The explicit configuration realizes at least n(n-1) distinct strict optima
for every n. This is an unconditional all-n lower bound. -/
theorem sharp_rotationCount_lower_bound (n : ℕ) :
    n * (n - 1) ≤
      rotationCount (fun i : Fin n => (i.val : ℂ)) (fun i => sharpTarget i.val) := by
  have h := sharp_rotationCount_ge_twice_thresholds n
  rwa [sharpThresholds_card, twice_choose_two] at h

end MonotoneMatching
