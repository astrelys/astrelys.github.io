import MonotoneMatching.RotationScore
import Mathlib.GroupTheory.Perm.Cycle.Factors

/-! Exactly two optimal assignments differ by one nontrivial cycle. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

/-- The score changes of disjoint permutation factors add exactly. -/
theorem assignmentScore_disjoint_factors {n : ℕ} (a b : Fin n → ℂ)
    (σ τ : Equiv.Perm (Fin n)) (h : Equiv.Perm.Disjoint σ τ) :
    assignmentScore a b (σ*τ) + assignmentScore a b (Equiv.refl _) =
      assignmentScore a b σ + assignmentScore a b τ := by
  unfold assignmentScore
  rw [← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  rcases h i with hs | ht
  · have he : (σ*τ) i = τ i := by rw [h.commute.eq]; simp [Equiv.Perm.mul_apply, hs]
    simp only [he, Equiv.refl_apply, hs]
    exact add_comm _ _
  · simp [Equiv.Perm.mul_apply, ht]

/-- If identity and σ are the only maximizing assignments, σ is one cycle.
The proof extracts one cycle and uses optimality to rule out a second one. -/
theorem two_optima_identity_isCycle {n : ℕ} (a b : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (hne : σ ≠ Equiv.refl _)
    (hmax : ∀ τ : Equiv.Perm (Fin n), assignmentScore a b τ ≤ assignmentScore a b (Equiv.refl _))
    (heq : assignmentScore a b σ = assignmentScore a b (Equiv.refl _))
    (htwo : ∀ τ : Equiv.Perm (Fin n),
      assignmentScore a b τ = assignmentScore a b (Equiv.refl _) →
      τ = Equiv.refl _ ∨ τ = σ) : σ.IsCycle := by
  classical
  obtain ⟨i,hi⟩ : ∃ i, σ i ≠ i := by
    by_contra h
    push Not at h
    exact hne (Equiv.ext h)
  let c := σ.cycleOf i
  have hc : c.IsCycle := Equiv.Perm.isCycle_cycleOf σ hi
  have hmem : c ∈ σ.cycleFactorsFinset :=
    Equiv.Perm.cycleOf_mem_cycleFactorsFinset_iff.mpr (Equiv.Perm.mem_support.mpr hi)
  have hd := Equiv.Perm.disjoint_mul_inv_of_mem_cycleFactorsFinset hmem
  have hadd := assignmentScore_disjoint_factors a b (σ*c⁻¹) c hd
  rw [inv_mul_cancel_right, heq] at hadd
  have h1 := hmax c
  have h2 := hmax (σ*c⁻¹)
  have he : assignmentScore a b c = assignmentScore a b (Equiv.refl _) := by linarith
  rcases htwo c he with h | h
  · have hh : c = 1 := h
    exact False.elim (hi ((Equiv.Perm.cycleOf_eq_one_iff σ).mp hh))
  · exact h ▸ hc

end MonotoneMatching
