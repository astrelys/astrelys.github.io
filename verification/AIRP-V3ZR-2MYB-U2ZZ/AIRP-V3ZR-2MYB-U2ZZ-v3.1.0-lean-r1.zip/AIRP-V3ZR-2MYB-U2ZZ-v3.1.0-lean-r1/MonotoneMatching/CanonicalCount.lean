import MonotoneMatching.CanonicalCoefficients
import MonotoneMatching.WindingCounts
noncomputable section
namespace MonotoneMatching
open Set
open scoped BigOperators
set_option backward.isDefEq.respectTransparency.types false

/-- Full canonical image, including choices attained only at tie points. -/
def canonicalValues {n : ℕ} (a : Fin n → ℂ) (b : Fin n → ℝ → ℂ) (T : ℝ) :
    Finset (Equiv.Perm (Fin n)) := by
  classical
  exact Finset.univ.filter (fun σ => ∃ t∈Icc 0 T,canonicalPermutation a (fun j => b j t)=σ)

theorem mem_canonicalValues {n : ℕ} (a : Fin n → ℂ) (b : Fin n → ℝ → ℂ) (T : ℝ)
    (σ : Equiv.Perm (Fin n)) :
    σ∈canonicalValues a b T ↔ ∃ t∈Icc 0 T,canonicalPermutation a (fun j => b j t)=σ := by
  classical
  simp only [canonicalValues,Finset.mem_filter,Finset.mem_univ,true_and]

/-- One perturbed source list strictly realizes every value of the original
canonical policy, including values with no open witness interval. -/
theorem canonical_image_strict_realization {n : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (T : ℝ) (hy : ∀ t,Function.Injective (fun j => b j t)) :
    ∃ a' : Fin n → ℂ,canonicalValues a b T ⊆ trajectoryOptimizers a' b T := by
  classical
  have h : ∀ σ : {σ // σ∈canonicalValues a b T},∃ t,t∈Icc 0 T ∧
      canonicalPermutation a (fun j => b j t)=σ.val := by
    intro σ
    exact (mem_canonicalValues a b T σ.val).mp σ.property
  choose time ht he using h
  obtain ⟨a',ha'⟩ := canonical_finite_strict_realization a b hy (Finset.univ.image time)
  refine ⟨a',?_⟩
  intro σ hσ
  let z : {σ // σ∈canonicalValues a b T} := ⟨σ,hσ⟩
  apply (mem_trajectoryOptimizers a' b T σ).mpr
  refine ⟨time z,ht z,?_⟩
  have hh := ha' (time z) (Finset.mem_image.mpr ⟨z,Finset.mem_univ _,rfl⟩)
  rwa [he z] at hh

/-- W6: the complete lexicographic policy image satisfies the winding bound. -/
def windingCanonicalCountStatement : Prop :=
  ∀ (n : ℕ),2≤n → ∀ (b v : Fin n → ℝ → ℂ) (T : ℝ),0<T →
    (∀ i t,HasDerivAt (b i) (v i t) t) → (∀ i,Continuous (v i)) →
    (∀ i,Function.Periodic (b i) T) → (∀ t,Function.Injective (fun i => b i t)) →
    (∀ i j,i<j → ∀ t,(b j t-b i t).re*(v j t-v i t).im-(b j t-b i t).im*(v j t-v i t).re≤0) →
    ∃ φ : Fin n → Fin n → ℝ → ℝ,∃ w : Fin n × Fin n → ℕ,
      (∀ i j,Continuous (φ i j)) ∧ (∀ i t,φ i i t=0) ∧
      (∀ i j,i≠j → ∀ t,(φ i j t:Real.Angle)=(Complex.arg (b j t-b i t):Real.Angle)) ∧
      (∀ p∈increasingPairs n,φ p.1 p.2 T-φ p.1 p.2 0= -(2*Real.pi)*(w p:ℝ)) ∧
      ∀ a : Fin n → ℂ,(canonicalValues a b T).card≤max 1 (2*∑ p∈increasingPairs n,w p)


/-- Finite simultaneous strict realization transfers the all-source count to
exactly the canonical policy specified in the manuscript. -/
theorem winding_canonical_count : windingCanonicalCountStatement := by
  intro n hn b v T hT hd hv hp hy hclock
  obtain ⟨φ,w,hφ,hzero,he,hw,hbound⟩ := winding_distinct_count n hn b v T hT hd hv hp hy hclock
  refine ⟨φ,w,hφ,hzero,he,hw,?_⟩
  intro a
  obtain ⟨a',hsub⟩ := canonical_image_strict_realization a b T hy
  exact (Finset.card_le_card hsub).trans (hbound a')

end MonotoneMatching
