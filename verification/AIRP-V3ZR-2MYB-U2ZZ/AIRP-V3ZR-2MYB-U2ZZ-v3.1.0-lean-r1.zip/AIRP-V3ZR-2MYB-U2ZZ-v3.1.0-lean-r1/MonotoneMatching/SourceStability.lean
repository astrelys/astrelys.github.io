import MonotoneMatching.WindingCharges
import MonotoneMatching.Stability
noncomputable section
namespace MonotoneMatching
open Set
open scoped BigOperators

/-- Unique optimizers witnessed during one closed period. -/
def trajectoryOptimizers {n : ℕ} (a : Fin n → ℂ) (b : Fin n → ℝ → ℂ)
    (T : ℝ) : Finset (Equiv.Perm (Fin n)) := by
  classical
  exact Finset.univ.filter (fun σ => ∃ t∈Icc 0 T,UniqueMinimum a (fun j => b j t) σ)

theorem mem_trajectoryOptimizers {n : ℕ} (a : Fin n → ℂ) (b : Fin n → ℝ → ℂ)
    (T : ℝ) (σ : Equiv.Perm (Fin n)) :
    σ∈trajectoryOptimizers a b T ↔ ∃ t∈Icc 0 T,UniqueMinimum a (fun j => b j t) σ := by
  classical
  simp only [trajectoryOptimizers,Finset.mem_filter,Finset.mem_univ,true_and]

theorem continuous_source_cost {n : ℕ} (y : Fin n → ℂ) (σ : Equiv.Perm (Fin n)) :
    Continuous (fun a : Fin n → ℂ => assignmentCost a y σ) := by
  unfold assignmentCost
  apply continuous_finsetSum
  intro i _
  exact ((continuous_apply i).sub continuous_const).norm.pow 2

theorem isOpen_source_uniqueMinimum {n : ℕ} (y : Fin n → ℂ) (σ : Equiv.Perm (Fin n)) :
    IsOpen {a : Fin n → ℂ | UniqueMinimum a y σ} := by
  classical
  change IsOpen {a : Fin n → ℂ | ∀ τ,τ≠σ → assignmentCost a y σ<assignmentCost a y τ}
  simp only [Set.ofPred_forall]
  apply isOpen_iInter_of_finite
  intro τ
  apply isOpen_iInter_of_finite
  intro _
  exact isOpen_lt (continuous_source_cost y σ) (continuous_source_cost y τ)

theorem isOpen_trajectory_witness {n : ℕ} (b : Fin n → ℝ → ℂ) (T : ℝ)
    (σ : Equiv.Perm (Fin n)) : IsOpen {a : Fin n → ℂ | σ∈trajectoryOptimizers a b T} := by
  simp only [mem_trajectoryOptimizers,Set.ofPred_exists]
  apply isOpen_iUnion
  intro t
  by_cases ht : t∈Icc 0 T
  · simpa only [ht,true_and] using isOpen_source_uniqueMinimum (fun j => b j t) σ
  · simp only [ht,false_and,Set.ofPred_false,isOpen_empty]

/-- Every finite collection of strict witnesses survives in one source neighborhood. -/
theorem trajectory_optimizers_persist {n : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (T : ℝ) :
    ∃ U : Set (Fin n → ℂ),IsOpen U ∧ a∈U ∧
      ∀ a'∈U,trajectoryOptimizers a b T ⊆ trajectoryOptimizers a' b T := by
  classical
  let U := {a' : Fin n → ℂ | ∀ σ∈trajectoryOptimizers a b T,σ∈trajectoryOptimizers a' b T}
  refine ⟨U,?_,?_,?_⟩
  · dsimp [U]
    simp only [Set.ofPred_forall]
    exact isOpen_biInter_finset fun σ _ => isOpen_trajectory_witness b T σ
  · intro σ hσ
    exact hσ
  · intro a' ha' σ hσ
    exact ha' σ hσ

theorem trajectory_count_from_dense_sources {n : ℕ} (b : Fin n → ℝ → ℂ)
    (T : ℝ) (G : Set (Fin n → ℂ)) (hg : Dense G) (N : ℕ)
    (hbound : ∀ a∈G,(trajectoryOptimizers a b T).card≤N) (a : Fin n → ℂ) :
    (trajectoryOptimizers a b T).card≤N := by
  obtain ⟨U,ho,ha,hU⟩ := trajectory_optimizers_persist a b T
  obtain ⟨a',hgen,hin⟩ := hg.exists_mem_open ho ⟨a,ha⟩
  exact (Finset.card_le_card (hU a' hin)).trans (hbound a' hgen)

end MonotoneMatching
