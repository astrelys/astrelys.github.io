import MonotoneMatching.GenericScoreWitness
import Mathlib.MeasureTheory.Function.Jacobian
import Mathlib.MeasureTheory.Measure.OpenPos
import Mathlib.Analysis.Calculus.FDeriv.Pi
import Mathlib.Analysis.Calculus.Deriv.Pi
import Mathlib.Analysis.Calculus.Deriv.Inv
import Mathlib.Analysis.Calculus.Deriv.Prod

set_option backward.isDefEq.respectTransparency.types false

noncomputable section
namespace MonotoneMatching
open scoped BigOperators Topology
open MeasureTheory MeasureTheory.Measure

/-- Equal-dimensional Sard, with a concrete nonzero kernel witness at each point. -/
theorem null_image_of_derivative_kernel {E : Type*} [NormedAddCommGroup E]
    [NormedSpace ℝ E] [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]
    (μ : Measure E) [IsAddHaarMeasure μ] (f : E → E) (s : Set E)
    (hd : ∀ x ∈ s, DifferentiableAt ℝ f x)
    (hk : ∀ x ∈ s, ∃ v : E, v ≠ 0 ∧ fderiv ℝ f x v = 0) : μ (f '' s) = 0 := by
  apply addHaar_image_eq_zero_of_det_fderivWithin_eq_zero μ
    (fun x hx => (hd x hx).hasFDerivAt.hasFDerivWithinAt)
  intro x hx
  change (fderiv ℝ f x).toLinearMap.det = 0
  apply LinearMap.det_eq_zero_iff_ker_ne_bot.mpr
  intro he
  obtain ⟨v,hv,hkv⟩ := hk x hx
  have hm : v ∈ LinearMap.ker (fderiv ℝ f x).toLinearMap := hkv
  rw [he] at hm
  exact hv hm

/-- Real coordinate pairing for general time-dependent score configurations. -/
def motionPairing {ι : Type*} [Fintype ι] (A d : ι → ℝ) : ℝ := ∑ i, A i * d i

/-- A chart for the hyperplane of sources tied at time x(i). -/
def pairTieChart {ι : Type*} [Fintype ι] [DecidableEq ι]
    (d : ℝ → ι → ℝ) (i : ι) (x : ι → ℝ) : ι → ℝ :=
  Function.update x i (-(∑ j ∈ Finset.univ.erase i, x j * d (x i) j) / d (x i) i)

theorem pairTieChart_pairing_zero {ι : Type*} [Fintype ι] [DecidableEq ι]
    (d : ℝ → ι → ℝ) (i : ι) (x : ι → ℝ) (hn : d (x i) i ≠ 0) :
    motionPairing (pairTieChart d i x) (d (x i)) = 0 := by
  unfold motionPairing
  rw [← Finset.sum_erase_add _ _ (Finset.mem_univ i)]
  simp only [pairTieChart, Function.update_self]
  have he : (∑ j ∈ Finset.univ.erase i,
      Function.update x i (-(∑ j ∈ Finset.univ.erase i, x j * d (x i) j) / d (x i) i) j *
        d (x i) j) = ∑ j ∈ Finset.univ.erase i, x j * d (x i) j := by
    apply Finset.sum_congr rfl
    intro j hj
    rw [Function.update_of_ne (Finset.ne_of_mem_erase hj)]
  rw [he, div_mul_cancel₀ _ hn]
  ring

/-- Any tied source is represented by a nonzero-coordinate chart. -/
theorem pairTieChart_covers {ι : Type*} [Fintype ι] [DecidableEq ι]
    (d : ℝ → ι → ℝ) (i : ι) (A : ι → ℝ) (t : ℝ)
    (hn : d t i ≠ 0) (hz : motionPairing A (d t) = 0) :
    pairTieChart d i (Function.update A i t) = A := by
  have he : (∑ j ∈ Finset.univ.erase i, A j * d t j) + A i * d t i = 0 := by
    simpa only [motionPairing, Finset.sum_erase_add _ _ (Finset.mem_univ i)] using hz
  ext j
  by_cases hj : j = i
  · subst j
    simp only [pairTieChart, Function.update_self]
    apply (div_eq_iff hn).mpr
    have hs : (∑ j ∈ Finset.univ.erase i, Function.update A i t j * d t j) =
        ∑ j ∈ Finset.univ.erase i, A j * d t j := by
      apply Finset.sum_congr rfl
      intro j hj
      rw [Function.update_of_ne (Finset.ne_of_mem_erase hj)]
    rw [hs]
    linarith
  · simp [pairTieChart, Function.update_of_ne hj]

/-- The tie chart is differentiable wherever its pivot coordinate is nonzero. -/
theorem differentiableAt_pairTieChart {ι : Type*} [Fintype ι] [DecidableEq ι]
    (d : ℝ → ι → ℝ) (hd : ∀ j, Differentiable ℝ (fun t => d t j))
    (i : ι) (x : ι → ℝ) (hn : d (x i) i ≠ 0) :
    DifferentiableAt ℝ (pairTieChart d i) x := by
  have hdc (j : ι) : DifferentiableAt ℝ (fun z : ι → ℝ => d (z i) j) x := by
    simpa only [Function.comp_def] using! (hd j (x i)).comp x (differentiableAt_apply (𝕜 := ℝ) i x)
  apply differentiableAt_pi.mpr
  intro j
  by_cases hj : j = i
  · subst j
    simp only [pairTieChart, Function.update_self]
    simp only [div_eq_mul_inv]
    refine DifferentiableAt.mul ?_ ((hdc i).inv hn)
    · apply DifferentiableAt.neg
      apply DifferentiableAt.fun_sum
      intro k hk
      exact (differentiableAt_apply k x).mul
        (hdc k)
  · simpa [pairTieChart, Function.update_of_ne hj] using differentiableAt_apply j x

/-- At a nontransverse pair tie, the time direction lies in the chart derivative's kernel. -/
theorem pairTieChart_derivative_kernel {ι : Type*} [Fintype ι] [DecidableEq ι]
    (d v : ℝ → ι → ℝ) (hd : ∀ j t, HasDerivAt (fun s => d s j) (v t j) t)
    (i : ι) (x : ι → ℝ) (hn : d (x i) i ≠ 0)
    (hc : motionPairing (pairTieChart d i x) (v (x i)) = 0) :
    fderiv ℝ (pairTieChart d i) x (Pi.single i 1) = 0 := by
  let P := pairTieChart d i
  let w := fderiv ℝ P x (Pi.single i 1)
  have hP := differentiableAt_pairTieChart d
    (fun j t => (hd j t).differentiableAt) i x hn
  have hp : HasDerivAt (fun t => P (Function.update x i t)) w (x i) := by
    have h := hP.hasFDerivAt
    rw [← Function.update_eq_self i x] at h
    simpa only [Function.update_eq_self, Function.comp_def] using! h.comp_hasDerivAt (x i) (hasDerivAt_update x i (x i))
  have hother (j : ι) (hj : j ≠ i) : w j = 0 := by
    have hjd := hasDerivAt_pi.mp hp j
    have he : (fun t => P (Function.update x i t) j) = fun _ => x j := by
      funext t
      simp [P, pairTieChart, Function.update_of_ne hj]
    rw [he] at hjd
    exact hjd.unique (hasDerivAt_const (x i) (x j))
  have hsum : HasDerivAt (fun t => motionPairing (P (Function.update x i t)) (d t))
      (∑ j, (w j * d (x i) j + P x j * v (x i) j)) (x i) := by
    simpa only [motionPairing, Function.update_eq_self, Finset.sum_apply, Pi.mul_apply] using!
      HasDerivAt.fun_sum (u := Finset.univ) (fun j _ => (hasDerivAt_pi.mp hp j).fun_mul (hd j (x i)))
  have hnear : ∀ᶠ t in 𝓝 (x i), d t i ≠ 0 := (hd i (x i)).continuousAt.eventually_ne hn
  have hz : (fun t => motionPairing (P (Function.update x i t)) (d t)) =ᶠ[𝓝 (x i)]
      (fun _ => 0) := by
    filter_upwards [hnear] with t ht
    simpa only [Function.update_self] using
      pairTieChart_pairing_zero d i (Function.update x i t) (by simpa only [Function.update_self] using ht)
  have hsum0 := hsum.unique ((hasDerivAt_const (x i) (0 : ℝ)).congr_of_eventuallyEq hz)
  rw [Finset.sum_add_distrib] at hsum0
  change (∑ j, w j * d (x i) j) + motionPairing (P x) (v (x i)) = 0 at hsum0
  rw [hc, add_zero] at hsum0
  have hwi : w i = 0 := by
    have he : (∑ j, w j * d (x i) j) = w i * d (x i) i := by
      apply Finset.sum_eq_single i
      · intro j _ hj
        rw [hother j hj, zero_mul]
      · simp
    rw [he] at hsum0
    exact (mul_eq_zero.mp hsum0).resolve_right hn
  change w = 0
  ext j
  by_cases hj : j = i
  · subst j
    exact hwi
  · exact hother j hj

/-- Nontransverse pair ties form a Lebesgue-null set of source parameters. -/
theorem pair_tie_bad_sources_null {ι : Type*} [Fintype ι] [DecidableEq ι]
    (μ : Measure (ι → ℝ)) [IsAddHaarMeasure μ]
    (d v : ℝ → ι → ℝ) (hd : ∀ j t, HasDerivAt (fun s => d s j) (v t j) t)
    (hn : ∀ t, d t ≠ 0) :
    μ {A | ∃ t, motionPairing A (d t) = 0 ∧ motionPairing A (v t) = 0} = 0 := by
  let S (i : ι) := {x : ι → ℝ | d (x i) i ≠ 0 ∧
    motionPairing (pairTieChart d i x) (v (x i)) = 0}
  have hnull (i : ι) : μ (pairTieChart d i '' S i) = 0 := by
    apply null_image_of_derivative_kernel μ
    · intro x hx
      exact differentiableAt_pairTieChart d (fun j t => (hd j t).differentiableAt) i x hx.1
    · intro x hx
      refine ⟨Pi.single i 1, ?_, pairTieChart_derivative_kernel d v hd i x hx.1 hx.2⟩
      intro he
      have := congrFun he i
      simp at this
  have hsub : {A | ∃ t, motionPairing A (d t) = 0 ∧ motionPairing A (v t) = 0} ⊆
      ⋃ i, pairTieChart d i '' S i := by
    rintro A ⟨t,ht,hv⟩
    obtain ⟨i,hi⟩ : ∃ i, d t i ≠ 0 := by
      by_contra hz
      push Not at hz
      exact hn t (funext hz)
    apply Set.mem_iUnion.mpr
    refine ⟨i, Function.update A i t, ?_, pairTieChart_covers d i A t hi ht⟩
    change d (Function.update A i t i) i ≠ 0 ∧
      motionPairing (pairTieChart d i (Function.update A i t)) (v (Function.update A i t i)) = 0
    simpa only [Function.update_self, pairTieChart_covers d i A t hi ht] using And.intro hi hv
  exact measure_mono_null hsub (measure_iUnion_null hnull)

/-- Transverse pair-score sources are dense for every nonvanishing differentiable motion. -/
theorem dense_pair_tie_transverse_sources {ι : Type*} [Fintype ι] [DecidableEq ι]
    (d v : ℝ → ι → ℝ) (hd : ∀ j t, HasDerivAt (fun s => d s j) (v t j) t)
    (hn : ∀ t, d t ≠ 0) :
    Dense {A | ∀ t, motionPairing A (d t) = 0 → motionPairing A (v t) ≠ 0} := by
  have h := interior_eq_empty_iff_dense_compl.mp
    (MeasureTheory.Measure.interior_eq_empty_of_null (pair_tie_bad_sources_null volume d v hd hn))
  simpa only [Set.compl_ofPred, not_exists, not_and] using h

end MonotoneMatching
