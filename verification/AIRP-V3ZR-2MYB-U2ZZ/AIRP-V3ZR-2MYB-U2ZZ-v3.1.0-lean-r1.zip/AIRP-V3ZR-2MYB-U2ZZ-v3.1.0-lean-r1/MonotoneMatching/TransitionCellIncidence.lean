import MonotoneMatching.TransitionCellCollar

/-! Boundary incidence and openness of the strict dual cells. -/
noncomputable section
namespace MonotoneMatching
open scoped InnerProductSpace Topology

theorem continuous_dualRow {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ) (i : Fin n) :
    Continuous (dualRow a r i) := by
  unfold dualRow
  simp only [Complex.inner]
  fun_prop

theorem isOpen_strictDualCell {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ) (i : Fin n) :
    IsOpen (strictDualCell a r i) := by
  have he : strictDualCell a r i=⋂ j : {j : Fin n // j≠i},
      {q | dualRow a r j.val q<dualRow a r i q} := by
    ext q
    simp only [strictDualCell,Set.mem_ofPred_eq,Set.mem_iInter]
    constructor
    · intro h j; exact h j.val j.property
    · intro h j hj; exact h ⟨j,hj⟩
  rw [he]
  exact isOpen_iInter_of_finite (fun j => isOpen_lt (continuous_dualRow _ _ _) (continuous_dualRow _ _ _))

/-- The matching row remains a weak maximizer on its entire closed edge. -/
theorem transition_closed_edge_row_max {n : ℕ} (a y : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (r c : Fin n → ℝ)
    (hbound : ∀ i j, inner ℝ (a i) (y j) ≤ r i+c j)
    (hexact : ∀ i j, r i+c j=inner ℝ (a i) (y j) ↔ j=i ∨ j=σ i)
    (i j : Fin n) {t : ℝ} (ht : t∈Set.Icc (0:ℝ) 1) :
    dualRow a r j ((1-t) • y i+t • y (σ i)) ≤
      dualRow a r i ((1-t) • y i+t • y (σ i)) := by
  have h0 := (hexact i i).mpr (Or.inl rfl)
  have h1 := (hexact i (σ i)).mpr (Or.inr rfl)
  have hb0 := hbound j i
  have hb1 := hbound j (σ i)
  rw [dualRow_combination,dualRow_combination]
  simp only [dualRow]
  rw [← h0,← h1]
  have hh0 := mul_nonneg (sub_nonneg.mpr ht.2) (sub_nonneg.mpr hb0)
  have hh1 := mul_nonneg ht.1 (sub_nonneg.mpr hb1)
  nlinarith

/-- A strict cell intersects the polygon boundary only on its own edge.
This gives whole-edge side transport directly from convex assignment cells. -/
theorem strictDualCell_polygon_boundary_subset {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (verts : ι → ℂ) {n : ℕ}
    (a : Fin n → ℂ) (r : Fin n → ℝ) (e : ι → Fin n) (he : Function.Injective e)
    (hactive : ∀ i : ι, ∀ t ∈ Set.Icc (0:ℝ) 1, ∀ j : Fin n,
      dualRow a r j ((1-t) • verts i+t • verts (next i)) ≤
        dualRow a r (e i) ((1-t) • verts i+t • verts (next i)))
    (i : ι) {q : ℂ} (hq : q∈strictDualCell a r (e i))
    (hb : q∈polygonBoundary next verts) : q∈segment ℝ (verts i) (verts (next i)) := by
  obtain ⟨j,hj⟩ := Set.mem_iUnion.mp hb
  by_cases hji : j=i
  · simpa only [hji] using hj
  have hneq : e j≠e i := fun h => hji (he h)
  rw [segment_eq_image] at hj
  obtain ⟨t,ht,rfl⟩ := hj
  exact False.elim ((not_lt_of_ge (hactive j t ht (e i))) (hq (e j) hneq))

end MonotoneMatching
