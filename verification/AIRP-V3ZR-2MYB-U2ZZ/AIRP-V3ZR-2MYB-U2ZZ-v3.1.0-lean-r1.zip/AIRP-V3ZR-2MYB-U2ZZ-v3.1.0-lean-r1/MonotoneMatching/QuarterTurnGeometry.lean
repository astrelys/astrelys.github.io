import MonotoneMatching.HorizontalCrossings

/-! Quarter-turn covariance of exact dual cells and real polygon winding. -/
noncomputable section
namespace MonotoneMatching
open scoped InnerProductSpace

theorem quarter_turn_inner (a b : ℂ) : inner ℝ (Complex.I*a) (Complex.I*b)=inner ℝ a b := by
  simp [Complex.inner]

theorem quarter_turn_affine (z w : ℂ) (t : ℝ) :
    (1-t) • (Complex.I*z)+t • (Complex.I*w)=Complex.I*((1-t) • z+t • w) := by
  simp only [Complex.real_smul]
  ring

theorem quarter_turn_segment (z w q : ℂ) :
    Complex.I*q∈segment ℝ (Complex.I*z) (Complex.I*w) ↔ q∈segment ℝ z w := by
  constructor
  · intro h
    rw [segment_eq_image] at h ⊢
    obtain ⟨t,ht,he⟩ := h
    dsimp only at he
    rw [quarter_turn_affine] at he
    exact ⟨t,ht,mul_left_cancel₀ Complex.I_ne_zero he⟩
  · intro h
    rw [segment_eq_image] at h ⊢
    obtain ⟨t,ht,he⟩ := h
    refine ⟨t,ht,?_⟩
    dsimp only at he ⊢
    rw [quarter_turn_affine,he]

theorem quarter_turn_polygonBoundary {ι : Type*}
    (next : Equiv.Perm ι) (v : ι → ℂ) (q : ℂ) :
    Complex.I*q∈polygonBoundary next (fun i => Complex.I*v i) ↔ q∈polygonBoundary next v := by
  simp only [polygonBoundary,Set.mem_iUnion,quarter_turn_segment]

theorem quarter_turn_edgeSide (z w q : ℂ) :
    edgeSide (Complex.I*z) (Complex.I*w) (Complex.I*q)=edgeSide z w q := by
  simp [edgeSide]
  ring

theorem quarter_turn_polygonIndexPhase {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (q : ℂ) :
    polygonIndexPhase next (fun i => Complex.I*v i) (Complex.I*q)=polygonIndexPhase next v q := by
  unfold polygonIndexPhase polygonPhase
  apply Finset.sum_congr rfl
  intro i _
  dsimp only
  rw [← mul_sub,← mul_sub,mul_div_mul_left _ _ Complex.I_ne_zero]

theorem quarter_turn_dualRow {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ) (i : Fin n) (q : ℂ) :
    dualRow (fun j => Complex.I*a j) r i (Complex.I*q)=dualRow a r i q := by
  simp only [dualRow,quarter_turn_inner]

theorem quarter_turn_strictDualCell {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ) (i : Fin n) (q : ℂ) :
    Complex.I*q∈strictDualCell (fun j => Complex.I*a j) r i ↔ q∈strictDualCell a r i := by
  simp only [strictDualCell,Set.mem_ofPred_eq,quarter_turn_dualRow]

theorem quarter_turn_surjective : Function.Surjective (fun q : ℂ => Complex.I*q) := by
  intro q
  refine ⟨-Complex.I*q,?_⟩
  calc
    Complex.I*(-Complex.I*q)= -(Complex.I*Complex.I)*q := by ring
    _ = q := by rw [Complex.I_mul_I]; simp

end MonotoneMatching
