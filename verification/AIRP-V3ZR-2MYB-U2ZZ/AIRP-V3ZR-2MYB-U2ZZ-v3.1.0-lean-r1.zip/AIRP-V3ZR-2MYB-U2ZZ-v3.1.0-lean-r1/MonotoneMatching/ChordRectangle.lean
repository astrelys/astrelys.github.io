import MonotoneMatching.PolygonChords

/-! A four-piece ordered-pair path inside the noncolliding chord strip. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval

theorem polygonInterpolation_mem_convex {m : ℕ} (hm : 0<m) (v : Fin (m+1) → ℂ)
    {S : Set ℂ} (hS : Convex ℝ S) (hv : ∀ i, v i∈S) {t : ℝ}
    (ht : t∈Set.Icc (0:ℝ) m) : polygonInterpolation v t∈S := by
  by_cases hlt : t<(m:ℝ)
  · obtain ⟨i,s,hs,he⟩ := exists_unit_edge_parameter ⟨ht.1,hlt⟩
    rw [he,polygonInterpolation_on_edge v i ⟨hs.1,hs.2.le⟩]
    exact hS (hv i.castSucc) (hv i.succ) (sub_nonneg.mpr hs.2.le) hs.1 (by ring)
  · have he : t=(m:ℝ) := le_antisymm ht.2 (le_of_not_gt hlt)
    rw [he,polygonInterpolation_last hm]
    exact hv _

def chordRectangleVertices (P ε : ℝ) : Fin 5 → ℂ :=
  ![⟨0,ε⟩,⟨0,P-ε⟩,⟨ε,P⟩,⟨P-ε,P⟩,⟨P,P+ε⟩]

def chordRectangleParameter (P ε : ℝ) (s : I) : ℂ :=
  polygonInterpolation (chordRectangleVertices P ε) (4*(s:ℝ))

theorem continuous_chordRectangleParameter (P ε : ℝ) : Continuous (chordRectangleParameter P ε) := by
  apply (continuous_polygonInterpolation _).comp
  fun_prop

theorem chordRectangleParameter_zero (P ε : ℝ) : chordRectangleParameter P ε 0=⟨0,ε⟩ := by
  have h := polygonInterpolation_zero (m := 4) (by norm_num) (chordRectangleVertices P ε)
  simpa [chordRectangleParameter,chordRectangleVertices] using h

theorem chordRectangleParameter_one (P ε : ℝ) : chordRectangleParameter P ε 1=⟨P,P+ε⟩ := by
  have h := polygonInterpolation_last (m := 4) (by norm_num) (chordRectangleVertices P ε)
  simpa [chordRectangleParameter,chordRectangleVertices] using h

theorem chordRectangleParameter_proper (P ε : ℝ) (hε : 0<ε) (hεP : ε<P) (s : I) :
    (chordRectangleParameter P ε s).im-(chordRectangleParameter P ε s).re∈Set.Ioo (0:ℝ) P := by
  have hS : Convex ℝ {z : ℂ | z.im-z.re∈Set.Ioo (0:ℝ) P} :=
    (convex_Ioo (𝕜 := ℝ) (0:ℝ) P).linear_preimage (Complex.imCLM-Complex.reCLM).toLinearMap
  have hv (i : Fin 5) : chordRectangleVertices P ε i∈{z : ℂ | z.im-z.re∈Set.Ioo (0:ℝ) P} := by
    fin_cases i <;> simp [chordRectangleVertices] <;> constructor <;> linarith
  exact polygonInterpolation_mem_convex (m := 4) (by norm_num) _ hS hv
    ⟨mul_nonneg (by norm_num) s.property.1,by norm_num; linarith [s.property.2]⟩

theorem chordRectangleParameter_endpoints (P ε : ℝ) :
    (chordRectangleParameter P ε 1).re=(chordRectangleParameter P ε 0).re+P ∧
    (chordRectangleParameter P ε 1).im=(chordRectangleParameter P ε 0).im+P := by
  rw [chordRectangleParameter_zero,chordRectangleParameter_one]
  constructor <;> dsimp <;> ring

end MonotoneMatching
