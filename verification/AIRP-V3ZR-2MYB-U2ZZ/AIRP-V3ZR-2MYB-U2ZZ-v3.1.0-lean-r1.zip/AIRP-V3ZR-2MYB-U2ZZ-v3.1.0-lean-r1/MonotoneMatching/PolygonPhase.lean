import MonotoneMatching.PairPhase
import Mathlib.Topology.Covering.AddCircle

/-! Exact winding phases of polygonal loops, without quotienting away turns. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

/-- The real sum of principal increments on an ordered polygonal loop. -/
def polygonPhase {ι : Type*} [Fintype ι] (next : Equiv.Perm ι) (z : ι → ℂ) : ℝ :=
  ∑ i, Complex.arg (z (next i)/z i)

/-- A segment avoiding zero has an endpoint ratio away from the argument cut. -/
theorem ratio_mem_slitPlane_of_segment_nonzero {z w : ℂ} (hz : z ≠ 0) (hw : w ≠ 0)
    (hseg : ∀ t : ℝ, 0 < t → t < 1 → (1-t) • z + t • w ≠ 0) :
    w/z ∈ Complex.slitPlane := by
  by_contra h
  rw [Complex.mem_slitPlane_iff] at h
  push Not at h
  have hr : (w/z).re < 0 := by
    apply lt_of_le_of_ne h.1
    intro he
    have heq : w/z = 0 := Complex.ext he h.2
    exact (div_ne_zero hw hz) heq
  let r := (w/z).re
  have hr0 : r < 0 := hr
  have he : w = (r : ℂ)*z := by
    have heq : w/z = (r : ℂ) := Complex.ext rfl (by simpa using h.2)
    exact (div_eq_iff hz).mp heq
  let t : ℝ := 1/(1-r)
  have hd : 0 < 1-r := by linarith
  have ht0 : 0 < t := one_div_pos.mpr hd
  have ht1 : t < 1 := (div_lt_one hd).mpr (by linarith)
  apply hseg t ht0 ht1
  rw [he]
  have ht : (1-t)+t*r=0 := by dsimp [t]; field_simp; ring
  simp only [Complex.real_smul]
  calc
    _ = ((1-t : ℝ) + t*r : ℂ)*z := by push_cast; ring
    _ = 0 := by rw [← Complex.ofReal_mul,← Complex.ofReal_add,ht]; simp

/-- The full real polygon phase is an integral multiple of two pi. -/
theorem polygonPhase_integer {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (z : ι → ℂ) (hz : ∀ i, z i ≠ 0) :
    ∃ k : ℤ, polygonPhase next z = k*(2*Real.pi) := by
  have he : (polygonPhase next z : Real.Angle) = 0 := by
    change Real.Angle.coeHom (∑ i, Complex.arg (z (next i)/z i)) = 0
    rw [map_sum]
    change (∑ i, (Complex.arg (z (next i)/z i) : Real.Angle)) = 0
    simp_rw [Complex.arg_div_coe_angle (hz _) (hz _)]
    rw [Finset.sum_sub_distrib,Equiv.sum_comp next (fun i => (Complex.arg (z i) : Real.Angle)),sub_self]
  obtain ⟨k,hk⟩ := Real.Angle.coe_eq_zero_iff.mp he
  exact ⟨k,by simpa only [zsmul_eq_mul] using hk.symm⟩

/-- A polygon confined to a right half-plane has zero winding phase. -/
theorem polygonPhase_zero_of_re_pos {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (z : ι → ℂ) (hz : ∀ i, 0 < (z i).re) :
    polygonPhase next z = 0 := by
  unfold polygonPhase
  simp_rw [arg_div_eq_sub_of_re_pos (hz _) (hz _)]
  rw [Finset.sum_sub_distrib,Equiv.sum_comp next (fun i => Complex.arg (z i)),sub_self]

/-- Continuity of polygon phase when no edge meets the origin. -/
theorem continuousOn_polygonPhase {ι X : Type*} [Fintype ι] [TopologicalSpace X]
    (next : Equiv.Perm ι) (z : X → ι → ℂ) {s : Set X}
    (hz : ∀ i, ContinuousOn (fun x => z x i) s)
    (hnz : ∀ x ∈ s, ∀ i, z x i ≠ 0)
    (hseg : ∀ x ∈ s, ∀ i, ∀ t : ℝ, 0 < t → t < 1 →
      (1-t) • z x i + t • z x (next i) ≠ 0) :
    ContinuousOn (fun x => polygonPhase next (z x)) s := by
  unfold polygonPhase
  apply continuousOn_finsetSum
  intro i _ x hx
  apply ContinuousAt.comp_continuousWithinAt (f := fun x => z x (next i)/z x i)
    (Complex.continuousAt_arg (ratio_mem_slitPlane_of_segment_nonzero
      (hnz x hx i) (hnz x hx (next i)) (hseg x hx i)))
  exact (hz (next i) x hx).div (hz i x hx) (hnz x hx i)

/-- Polygon winding phase is invariant under any connected noncrossing
homotopy. Its value remains a real number, not only a circle-valued angle. -/
theorem polygonPhase_homotopy_invariant {ι X : Type*} [Fintype ι] [TopologicalSpace X]
    (next : Equiv.Perm ι) (z : X → ι → ℂ) {s : Set X} (hs : IsPreconnected s)
    (hz : ∀ i, ContinuousOn (fun x => z x i) s)
    (hnz : ∀ x ∈ s, ∀ i, z x i ≠ 0)
    (hseg : ∀ x ∈ s, ∀ i, ∀ t : ℝ, 0 < t → t < 1 →
      (1-t) • z x i + t • z x (next i) ≠ 0)
    {u v : X} (hu : u ∈ s) (hv : v ∈ s) :
    polygonPhase next (z u) = polygonPhase next (z v) := by
  apply (AddCircle.isCoveringMap_coe (2*Real.pi)).constOn_of_comp hs
    (continuousOn_polygonPhase next z hz hnz hseg) _ hu hv
  intro x hx y hy
  obtain ⟨kx,hkx⟩ := polygonPhase_integer next (z x) (hnz x hx)
  obtain ⟨ky,hky⟩ := polygonPhase_integer next (z y) (hnz y hy)
  have hx0 : (polygonPhase next (z x) : Real.Angle) = 0 :=
    Real.Angle.coe_eq_zero_iff.mpr ⟨kx,by simpa only [zsmul_eq_mul] using hkx.symm⟩
  have hy0 : (polygonPhase next (z y) : Real.Angle) = 0 :=
    Real.Angle.coe_eq_zero_iff.mpr ⟨ky,by simpa only [zsmul_eq_mul] using hky.symm⟩
  exact hx0.trans hy0.symm

end MonotoneMatching
