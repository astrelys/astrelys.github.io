import MonotoneMatching.GenericMotionPair
import Mathlib.Topology.Maps.Proper.Basic
import Mathlib.Analysis.Calculus.Deriv.Inverse

set_option backward.isDefEq.respectTransparency.types false
noncomputable section
namespace MonotoneMatching
open scoped BigOperators Topology
open MeasureTheory MeasureTheory.Measure

/-- The source-time pairing is continuous in both variables. -/
theorem continuous_motionPairing_family {ι : Type*} [Fintype ι]
    {X : Type*} [TopologicalSpace X] (d : X → ι → ℝ) (hd : Continuous d) :
    Continuous (fun z : (ι → ℝ) × X => motionPairing z.1 (d z.2)) := by
  unfold motionPairing
  fun_prop

/-- Existence of a simultaneous tie over a compact time set is a closed condition on sources. -/
theorem isClosed_exists_compact_tie {ι : Type*} [Fintype ι]
    (d e : ℝ → ι → ℝ) (hd : Continuous d) (he : Continuous e)
    (K : Set ℝ) (hK : IsCompact K) :
    IsClosed {A | ∃ t ∈ K, motionPairing A (d t) = 0 ∧ motionPairing A (e t) = 0} := by
  have : CompactSpace K := isCompact_iff_compactSpace.mp hK
  have hc : IsClosed {z : (ι → ℝ) × K |
      motionPairing z.1 (d z.2) = 0 ∧ motionPairing z.1 (e z.2) = 0} :=
    (isClosed_eq (continuous_motionPairing_family (fun t : K => d t)
      (hd.comp continuous_subtype_val)) continuous_const).inter
      (isClosed_eq (continuous_motionPairing_family (fun t : K => e t)
      (he.comp continuous_subtype_val)) continuous_const)
  have hproj := isClosedMap_fst_of_compactSpace _ hc
  convert hproj using 1
  ext A
  constructor
  · rintro ⟨t,ht,h1,h2⟩
    exact ⟨(A,⟨t,ht⟩), ⟨h1,h2⟩, rfl⟩
  · rintro ⟨⟨B,t⟩,⟨h1,h2⟩,rfl⟩
    exact ⟨t,t.property,h1,h2⟩

/-- A differentiable real function with only regular zeros has finitely many
zeros on any compact set; no analyticity or explicit zero-finding oracle is used. -/
theorem finite_regular_zeros_on_compact (f v : ℝ → ℝ)
    (hd : ∀ t, HasDerivAt f (v t) t) (K : Set ℝ) (hK : IsCompact K)
    (hr : ∀ t ∈ K, f t = 0 → v t ≠ 0) : {t ∈ K | f t = 0}.Finite := by
  have hc : Continuous f := continuous_iff_continuousAt.mpr fun t => (hd t).continuousAt
  have hcompact : IsCompact {t ∈ K | f t = 0} := hK.inter_right (isClosed_eq hc continuous_const)
  by_contra hfinite
  obtain ⟨t,ht,ha⟩ := exists_nhds_ne_inf_principal_neBot hcompact hfinite
  have := ha
  have hn : ∀ᶠ z in 𝓝[≠] t, f z ≠ 0 := (hd t).eventually_ne (hr t ht.1 ht.2)
  have hmem : ∀ᶠ z in 𝓝[≠] t ⊓ Filter.principal {z ∈ K | f z = 0}, f z = 0 :=
    Filter.Eventually.filter_mono inf_le_right (Filter.eventually_principal.mpr fun z hz => hz.2)
  have hnot := hn.filter_mono (show 𝓝[≠] t ⊓ Filter.principal {z ∈ K | f z = 0} ≤ 𝓝[≠] t from inf_le_left)
  obtain ⟨z,hz,hz'⟩ := (hmem.and hnot).exists
  exact hz' hz

end MonotoneMatching
