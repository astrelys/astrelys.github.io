import MonotoneMatching.GeneralLocalCharge
import MonotoneMatching.TrajectoryBudget
noncomputable section
namespace MonotoneMatching
open Set Filter
open scoped BigOperators InnerProductSpace Topology
set_option backward.isDefEq.respectTransparency.types false

/-- Canonical time of a cyclic cell transition; the period seam is represented
at zero, so no event is counted twice. -/
def trajectoryTransitionTime {m : ℕ} (cut : Fin (m+1) → ℝ) (i : Fin m) : ℝ :=
  cut (finRotate m i).castSucc

/-- Zero at artificial subdivision boundaries; the paper's exact natural
charge at actual label changes. -/
def trajectoryCellCharge {n m : ℕ} (b : Fin n → ℝ → ℂ) (cut : Fin (m+1) → ℝ)
    (label : Fin m → Equiv.Perm (Fin n)) (i : Fin m) : ℕ :=
  if label (finRotate m i)=label i then 0 else
    cycleEventCharge (fun j => b (label i j) (trajectoryTransitionTime cut i))
      ((label i)⁻¹*label (finRotate m i))

theorem trajectory_transition_time_mem {m : ℕ} (_hm : 0<m) (cut : Fin (m+1) → ℝ)
    (T : ℝ) (hmono : StrictMono cut) (hfirst : cut 0=0) (hlast : cut (Fin.last m)=T)
    (i : Fin m) : trajectoryTransitionTime cut i∈Ico (0:ℝ) T := by
  constructor
  · rw [← hfirst]
    exact hmono.monotone (Fin.zero_le _)
  · rw [← hlast]
    exact hmono (by change (finRotate m i).val<m; exact (finRotate m i).isLt)

/-- Every genuine label change has the paper's exact local charge. Periodicity
transports the old optimum across the seam; derivatives are taken at the actual
canonical transition time. -/
theorem trajectory_cell_exact_charge {n m : ℕ} (a : Fin n → ℂ)
    (b v : Fin n → ℝ → ℂ) (T : ℝ) (hm : 0<m)
    (hd : ∀ i t,HasDerivAt (b i) (v i t) t) (hp : ∀ i,Function.Periodic (b i) T)
    (hy : ∀ t,Function.Injective (fun i => b i t))
    (hclock : ∀ t i j,0≤ inner ℝ (b i t-b j t) (Complex.I*(v i t-v j t)))
    (ha : GenericTrajectorySources b v (Icc 0 T) a)
    (cut : Fin (m+1) → ℝ) (label : Fin m → Equiv.Perm (Fin n))
    (hmono : StrictMono cut) (hfirst : cut 0=0) (hlast : cut (Fin.last m)=T)
    (hopt : ∀ i,∀ t∈Icc (cut i.castSucc) (cut i.succ),∀ ρ,
      assignmentScore a (fun j => b j t) ρ≤assignmentScore a (fun j => b j t) (label i))
    (i : Fin m) :
    (label (finRotate m i)≠label i → ((label i)⁻¹*label (finRotate m i)).IsCycle ∧
      1≤trajectoryCellCharge b cut label i) ∧
    identityPhase a (fun j => b (label (finRotate m i) j) (cut (finRotate m i).castSucc))-
      identityPhase a (fun j => b (label i j) (cut i.succ))=
        Real.pi*(trajectoryCellCharge b cut label i:ℝ) := by
  classical
  have hphase := trajectory_phase_subdivision_seam a b T hp hm cut hfirst hlast (label i) i
  by_cases he : label (finRotate m i)=label i
  · refine ⟨fun h => (h he).elim,?_⟩
    rw [he,hphase]
    simp only [trajectoryCellCharge,he,ite_true,Nat.cast_zero,mul_zero,sub_self]
  · have hu := trajectory_transition_time_mem hm cut T hmono hfirst hlast i
    have hseam (ρ : Equiv.Perm (Fin n)) := periodic_subdivision_seam hm cut hfirst hlast
      (fun t => assignmentScore a (fun j => b j t) ρ)
      (by intro t; exact congrArg (fun y : Fin n → ℂ => assignmentScore a y ρ) (funext (fun j => hp j t))) i
    have hold : ∀ ρ,assignmentScore a (fun j => b j (trajectoryTransitionTime cut i)) ρ≤
        assignmentScore a (fun j => b j (trajectoryTransitionTime cut i)) (label i) := by
      intro ρ
      dsimp only [trajectoryTransitionTime]
      rw [hseam ρ,hseam (label i)]
      exact hopt i _ (right_mem_Icc.mpr (hmono i.castSucc_lt_succ).le) ρ
    have hh := generic_trajectory_event_exact_charge a b v hd (Icc 0 T) ha
      (label i) (label (finRotate m i)) (Ne.symm he) ⟨hu.1,hu.2.le⟩
      (hmono (finRotate m i).castSucc_lt_succ) (hy _) (hclock _) hold
      (hopt (finRotate m i))
    refine ⟨fun _ => ⟨hh.1,?_⟩,?_⟩
    · simpa only [trajectoryCellCharge,he,ite_false] using hh.2.1
    · rw [← hphase]
      simpa only [trajectoryCellCharge,he,ite_false,trajectoryTransitionTime] using hh.2.2

/-- The exact natural-number event budget on a realized optimal subdivision.
The boundary charges come from actual velocity data, not assumed phase signs. -/
theorem trajectory_exact_charge_budget {n m : ℕ} (a : Fin n → ℂ)
    (b v : Fin n → ℝ → ℂ) (T : ℝ) (hT : 0<T) (hm : 0<m)
    (hd : ∀ i t,HasDerivAt (b i) (v i t) t) (hp : ∀ i,Function.Periodic (b i) T)
    (hy : ∀ t,Function.Injective (fun i => b i t))
    (hclock : ∀ t i j,0≤ inner ℝ (b i t-b j t) (Complex.I*(v i t-v j t)))
    (ha : GenericTrajectorySources b v (Icc 0 T) a)
    (cut : Fin (m+1) → ℝ) (label : Fin m → Equiv.Perm (Fin n))
    (hmono : StrictMono cut) (hfirst : cut 0=0) (hlast : cut (Fin.last m)=T)
    (hopt : ∀ i,∀ t∈Icc (cut i.castSucc) (cut i.succ),∀ ρ,
      assignmentScore a (fun j => b j t) ρ≤assignmentScore a (fun j => b j t) (label i))
    (φ : Fin n → Fin n → ℝ → ℝ) (w : Fin n × Fin n → ℕ)
    (hφ : ∀ i j,Continuous (φ i j)) (hzero : ∀ i t,φ i i t=0)
    (he : ∀ i j,i≠j → ∀ t,(φ i j t:Real.Angle)=(Complex.arg (b j t-b i t):Real.Angle))
    (hw : ∀ p∈increasingPairs n,φ p.1 p.2 T-φ p.1 p.2 0= -(2*Real.pi)*(w p:ℝ)) :
    ∑ i,trajectoryCellCharge b cut label i=2*∑ p∈increasingPairs n,w p := by
  have hb (i : Fin n) : Continuous (b i) := continuous_iff_continuousAt.mpr (fun t => (hd i t).continuousAt)
  have hai := genericTrajectorySources_injective a b v (Icc 0 T) ⟨0,⟨le_rfl,hT.le⟩⟩ ha
  have hbudget := realized_trajectory_phase_budget a b φ hai hb
    (fun i j hij t => (hy t).ne hij) hφ hzero he T w hw cut label hmono hfirst hlast hopt
  have heq (i : Fin m) := (trajectory_cell_exact_charge a b v T hm hd hp hy hclock ha cut label hmono hfirst hlast hopt i).2
  simp_rw [heq] at hbudget
  rw [← Finset.mul_sum] at hbudget
  have hreal : (∑ i,(trajectoryCellCharge b cut label i:ℝ))=2*∑ p∈increasingPairs n,(w p:ℝ) := by
    nlinarith [Real.pi_pos]
  exact_mod_cast hreal

end MonotoneMatching
