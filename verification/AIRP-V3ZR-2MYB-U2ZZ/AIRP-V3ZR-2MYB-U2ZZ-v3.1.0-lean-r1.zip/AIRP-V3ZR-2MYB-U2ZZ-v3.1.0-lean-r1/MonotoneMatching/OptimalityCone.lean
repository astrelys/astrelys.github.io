import MonotoneMatching.Stability
import Mathlib.Analysis.Convex.Contractible

/-! The collision-free convex region used to close the optimal-configuration path. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators InnerProductSpace

/-- The score loss of a transposition is exactly the paired inner product. -/
theorem score_swap_difference {n : ℕ} (a b : Fin n → ℂ) (i j : Fin n) (hij : i ≠ j) :
    assignmentScore a b (Equiv.refl _) - assignmentScore a b (Equiv.swap i j) =
      inner ℝ (a i - a j) (b i - b j) := by
  classical
  unfold assignmentScore
  rw [← Finset.sum_sub_distrib]
  calc
    _ = ∑ k : Fin n,
        ((if k = i then inner ℝ (a i) (b i) - inner ℝ (a i) (b j) else 0) +
         (if k = j then inner ℝ (a j) (b j) - inner ℝ (a j) (b i) else 0)) := by
      apply Finset.sum_congr rfl
      intro k _
      by_cases hki : k = i
      · subst k; simp [hij]
      · by_cases hkj : k = j
        · subst k; simp [hij.symm]
        · simp [Equiv.swap_apply_of_ne_of_ne hki hkj, hki, hkj]
    _ = _ := by
      simp [Finset.sum_add_distrib, inner_sub_left, inner_sub_right]
      ring

/-- A strict identity optimum places every paired difference in a strict half-plane. -/
theorem unique_identity_pair_positive {n : ℕ} (a b : Fin n → ℂ)
    (h : UniqueMinimum a b (Equiv.refl _)) (i j : Fin n) (hij : i ≠ j) :
    0 < inner ℝ (a i - a j) (b i - b j) := by
  have hne : Equiv.swap i j ≠ Equiv.refl _ := by
    intro he
    have hh := congrArg (fun σ : Equiv.Perm (Fin n) => σ i) he
    exact hij (by simpa using hh.symm)
  have hs := (assignmentCost_lt_iff_score_gt _ _ _ _).mp (h _ hne)
  rw [← score_swap_difference a b i j hij]
  exact sub_pos.mpr hs

/-- The strict identity-optimality region from the manuscript. -/
def identityOptimalityCone {n : ℕ} (a : Fin n → ℂ) : Set (Fin n → ℂ) :=
  {b | UniqueMinimum a b (Equiv.refl _)}

theorem mem_identityOptimalityCone_iff {n : ℕ} (a b : Fin n → ℂ) :
    b ∈ identityOptimalityCone a ↔ ∀ σ : Equiv.Perm (Fin n), σ ≠ Equiv.refl _ →
      assignmentScore a b σ < assignmentScore a b (Equiv.refl _) := by
  simp only [identityOptimalityCone, Set.mem_ofPred_eq, UniqueMinimum,
    assignmentCost_lt_iff_score_gt]

theorem assignmentScore_target_combination {n : ℕ} (a b c : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (r s : ℝ) :
    assignmentScore a (r • b + s • c) σ =
      r * assignmentScore a b σ + s * assignmentScore a c σ := by
  simp only [assignmentScore, Pi.add_apply, Pi.smul_apply, inner_add_right,
    real_inner_smul_right, Finset.sum_add_distrib, ← Finset.mul_sum]

theorem convex_identityOptimalityCone {n : ℕ} (a : Fin n → ℂ) :
    Convex ℝ (identityOptimalityCone a) := by
  intro b hb c hc r s hr hs hrs
  rw [mem_identityOptimalityCone_iff] at hb hc ⊢
  intro σ hσ
  rw [assignmentScore_target_combination, assignmentScore_target_combination]
  have h1 := hb σ hσ
  have h2 := hc σ hσ
  have h3 := mul_nonneg hr (sub_nonneg.mpr h1.le)
  have h4 := mul_nonneg hs (sub_nonneg.mpr h2.le)
  rcases eq_or_lt_of_le hr with he | he
  · have hsr : s = 1 := by linarith
    rw [← he, hsr]
    simpa using h2
  · have hh := mul_pos he (sub_pos.mpr h1)
    nlinarith

theorem identityOptimalityCone_injective {n : ℕ} (a b : Fin n → ℂ)
    (hb : b ∈ identityOptimalityCone a) : Function.Injective b := by
  intro i j hij
  by_contra hn
  exact not_uniqueMinimum_of_repeated_target a b hn hij (Equiv.refl _) hb

/-- Every nonempty identity-optimality region is contractible. -/
theorem contractible_identityOptimalityCone {n : ℕ} (a : Fin n → ℂ)
    (h : (identityOptimalityCone a).Nonempty) :
    ContractibleSpace (identityOptimalityCone a) :=
  (convex_identityOptimalityCone a).contractibleSpace h

end MonotoneMatching
