import MonotoneMatching.PairPhase
import MonotoneMatching.RotationScore

/-! Exact real phase charge at a transposition event. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators InnerProductSpace

def pairPhase {n : ℕ} (a y : Fin n → ℂ) (i j : Fin n) : ℝ :=
  Complex.arg ((y j-y i)*(starRingEnd ℂ) (a j-a i))

theorem pairPhase_symm {n : ℕ} (a y : Fin n → ℂ) (i j : Fin n) :
    pairPhase a y i j = pairPhase a y j i := by
  unfold pairPhase
  congr 1
  rw [show y i-y j = -(y j-y i) by ring,
    show a i-a j = -(a j-a i) by ring, map_neg, neg_mul_neg]

@[simp] theorem pairPhase_self {n : ℕ} (a y : Fin n → ℂ) (i : Fin n) :
    pairPhase a y i i = 0 := by simp [pairPhase]

theorem twice_identityPhase {n : ℕ} (a y : Fin n → ℂ) :
    2 * identityPhase a y = ∑ i, ∑ j, pairPhase a y i j := by
  classical
  have h (i j : Fin n) : pairPhase a y i j =
      (if i < j then pairPhase a y i j else 0) +
      (if j < i then pairPhase a y j i else 0) := by
    rcases lt_trichotomy i j with h | h | h
    · simp [h, not_lt_of_gt h]
    · subst j; simp
    · simp [h, not_lt_of_gt h, pairPhase_symm a y i j]
  have hs : identityPhase a y = ∑ i, ∑ j, if i < j then pairPhase a y i j else 0 := by
    simp only [identityPhase, increasingPairs, Finset.sum_filter, Finset.sum_product,
      pairPhase]
  conv_rhs => arg 2; ext i; arg 2; ext j; rw [h i j]
  simp only [Finset.sum_add_distrib]
  rw [Finset.sum_comm (f := fun i j : Fin n => if j < i then pairPhase a y j i else 0)]
  rw [← hs]
  ring

theorem pairPhase_difference {n : ℕ} (a y z : Fin n → ℂ) (i j : Fin n)
    (hy : 0 < ((y j-y i)*(starRingEnd ℂ) (a j-a i)).re)
    (hz : 0 < ((z j-z i)*(starRingEnd ℂ) (a j-a i)).re) :
    pairPhase a z i j - pairPhase a y i j =
      Complex.arg ((z j-z i)/(y j-y i)) := by
  have ha : (starRingEnd ℂ) (a j-a i) ≠ 0 := by
    intro h; rw [h,mul_zero] at hy; exact lt_irrefl 0 hy
  unfold pairPhase
  rw [← arg_div_eq_sub_of_re_pos hy hz, mul_div_mul_right _ _ ha]

theorem pairPhase_abs_lt {n : ℕ} (a y : Fin n → ℂ) (i j : Fin n)
    (h : 0 < ((y j-y i)*(starRingEnd ℂ) (a j-a i)).re) :
    |pairPhase a y i j| < Real.pi/2 :=
  Complex.abs_arg_lt_pi_div_two_iff.mpr (Or.inl h)

/-- Pairwise phase cancellation away from the exceptional transposed pair.
The source vectors cancel from the exact angle difference. -/
theorem pairPhase_involution_cancel {n : ℕ} (a y : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (hσ : ∀ i, σ (σ i) = i) (i j : Fin n)
    (hy : 0 < ((y j-y i)*(starRingEnd ℂ) (a j-a i)).re)
    (hz : 0 < ((y (σ j)-y (σ i))*(starRingEnd ℂ) (a j-a i)).re)
    (hy' : 0 < ((y (σ j)-y (σ i))*(starRingEnd ℂ) (a (σ j)-a (σ i))).re)
    (hz' : 0 < ((y j-y i)*(starRingEnd ℂ) (a (σ j)-a (σ i))).re) :
    (pairPhase a (y ∘ σ) i j - pairPhase a y i j) +
      (pairPhase a (y ∘ σ) (σ i) (σ j) - pairPhase a y (σ i) (σ j)) = 0 := by
  have h1 := pairPhase_difference a y (y ∘ σ) i j hy hz
  have h2 := pairPhase_difference a y (y ∘ σ) (σ i) (σ j) hy'
    (by simpa [Function.comp_def,hσ] using hz')
  have hb1 := pairPhase_abs_lt a y i j hy
  have hb2 := pairPhase_abs_lt a (y ∘ σ) i j hz
  have hn : Complex.arg ((y (σ j)-y (σ i))/(y j-y i)) ≠ Real.pi := by
    intro he
    rw [abs_lt] at hb1 hb2
    change _ = Complex.arg ((y (σ j)-y (σ i))/(y j-y i)) at h1
    rw [he] at h1
    linarith
  rw [h1,h2]
  simp only [Function.comp_def,hσ]
  rw [show (y j-y i)/(y (σ j)-y (σ i)) =
      ((y (σ j)-y (σ i))/(y j-y i))⁻¹ by rw [inv_div]]
  rw [Complex.arg_inv,ite_eq_right_iff.mpr (fun h => (hn h).elim)]
  ring

/-- A transposition with its exceptional pair crossing the negative imaginary
half-axis has phase charge exactly pi. All other pair contributions cancel. -/
theorem transposition_phase_charge {n : ℕ} (a y : Fin n → ℂ)
    (i j : Fin n) (hij : i ≠ j)
    (hstrict : ∀ p q : Fin n, p ≠ q → ¬ ((p=i ∧ q=j) ∨ (p=j ∧ q=i)) →
      0 < ((y q-y p)*(starRingEnd ℂ) (a q-a p)).re ∧
      0 < ((y (Equiv.swap i j q)-y (Equiv.swap i j p)) *
        (starRingEnd ℂ) (a q-a p)).re)
    (hneg : ((y j-y i)*(starRingEnd ℂ) (a j-a i)).im < 0) :
    identityPhase a (y ∘ Equiv.swap i j) - identityPhase a y = Real.pi := by
  classical
  let σ := Equiv.swap i j
  let f := fun p q => pairPhase a (y ∘ σ) p q - pairPhase a y p q
  have hfij : f i j = Real.pi := by
    dsimp [f,pairPhase,σ]
    simp only [Equiv.swap_apply_left,Equiv.swap_apply_right]
    rw [show y i-y j = -(y j-y i) by ring, neg_mul,
      Complex.arg_neg_eq_arg_add_pi_of_im_neg hneg]
    ring
  have hfji : f j i = Real.pi := by
    dsimp [f]
    rw [pairPhase_symm a (y ∘ σ) j i,pairPhase_symm a y j i]
    exact hfij
  have hσ : ∀ p, σ (σ p) = p := fun p => Equiv.swap_apply_self i j p
  have hp (p q : Fin n) : f p q + f (σ p) (σ q) =
      (if p=i ∧ q=j then 2*Real.pi else 0) +
      (if p=j ∧ q=i then 2*Real.pi else 0) := by
    by_cases he : (p=i ∧ q=j) ∨ (p=j ∧ q=i)
    · rcases he with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ <;>
        simp [σ,hfij,hfji,hij,hij.symm, two_mul]
    · have he' : ¬ ((σ p=i ∧ σ q=j) ∨ (σ p=j ∧ σ q=i)) := by
        intro h
        apply he
        rcases h with ⟨hp,hq⟩ | ⟨hp,hq⟩
        · right
          constructor
          · have := congrArg σ hp; simpa [hσ,σ] using this
          · have := congrArg σ hq; simpa [hσ,σ] using this
        · left
          constructor
          · have := congrArg σ hp; simpa [hσ,σ] using this
          · have := congrArg σ hq; simpa [hσ,σ] using this
      have h0 : f p q + f (σ p) (σ q) = 0 := by
        by_cases hpq : p=q
        · subst q; simp [f]
        · obtain ⟨hy,hz⟩ := hstrict p q hpq he
          obtain ⟨hy',hz'⟩ := hstrict (σ p) (σ q) (σ.injective.ne hpq) he'
          apply pairPhase_involution_cancel a y σ hσ p q hy hz hy'
          simpa only [σ,Equiv.swap_apply_self] using hz'
      rw [h0,ite_eq_right (fun h => he (Or.inl h)),ite_eq_right (fun h => he (Or.inr h))]
      ring
  have hs : (∑ p, ∑ q, f (σ p) (σ q)) = ∑ p, ∑ q, f p q := by
    simp only [Equiv.sum_comp]
    exact Equiv.sum_comp σ (fun p => ∑ q, f p q)
  have hsum := congrArg (fun g : Fin n → Fin n → ℝ => ∑ p, ∑ q, g p q) (funext fun p => funext (hp p))
  simp only [Finset.sum_add_distrib] at hsum
  rw [hs] at hsum
  have hr : (∑ p : Fin n, ∑ q : Fin n, if p=i ∧ q=j then 2*Real.pi else 0) = 2*Real.pi := by
    simp [ite_and]
  have hr' : (∑ p : Fin n, ∑ q : Fin n, if p=j ∧ q=i then 2*Real.pi else 0) = 2*Real.pi := by
    simp [ite_and]
  rw [hr,hr'] at hsum
  have hphase : (∑ p, ∑ q, f p q) =
      2*identityPhase a (y ∘ σ) - 2*identityPhase a y := by
    simp only [f,Finset.sum_sub_distrib,← twice_identityPhase]
  rw [hphase] at hsum
  change identityPhase a (y ∘ σ) - identityPhase a y = _
  linarith

/-- At a two-optimum tie, every unrelated transposition has positive slack. -/
theorem two_optima_pair_strict {n : ℕ} (a y : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n))
    (hmax : ∀ τ, assignmentScore a y τ ≤ assignmentScore a y (Equiv.refl _))
    (htwo : ∀ τ, assignmentScore a y τ = assignmentScore a y (Equiv.refl _) →
      τ = Equiv.refl _ ∨ τ = σ)
    (p q : Fin n) (hpq : p ≠ q) (hne : Equiv.swap p q ≠ σ) :
    0 < inner ℝ (a p-a q) (y p-y q) := by
  have hs : assignmentScore a y (Equiv.swap p q) < assignmentScore a y (Equiv.refl _) := by
    by_contra h
    rcases htwo _ (le_antisymm (hmax _) (le_of_not_gt h)) with h | h
    · exact hpq (Equiv.swap_eq_refl_iff.mp h)
    · exact hne h
  rw [← score_swap_difference a y p q hpq]
  exact sub_pos.mpr hs

theorem swap_ne_of_pair_ne {n : ℕ} (i j p q : Fin n) (hpq : p ≠ q)
    (h : ¬ ((p=i ∧ q=j) ∨ (p=j ∧ q=i))) : Equiv.swap p q ≠ Equiv.swap i j := by
  intro he
  have hm : Equiv.swap i j p ≠ p := by rw [← he,Equiv.swap_apply_left]; exact hpq.symm
  rcases Equiv.eq_or_eq_of_swap_apply_ne_self hm with hp | hp
  · apply h; left; refine ⟨hp,?_⟩
    have hh := congrArg (fun π : Equiv.Perm (Fin n) => π p) he
    simpa [hp] using hh
  · apply h; right; refine ⟨hp,?_⟩
    have hh := congrArg (fun π : Equiv.Perm (Fin n) => π p) he
    simpa [hp] using hh

/-- Two optimal assignments related by a transposition satisfy the strict
half-plane hypotheses for every other unordered pair. -/
theorem two_optima_transposition_pair_strict {n : ℕ} (a y : Fin n → ℂ)
    (i j : Fin n)
    (hmax : ∀ τ, assignmentScore a y τ ≤ assignmentScore a y (Equiv.refl _))
    (heq : assignmentScore a y (Equiv.swap i j) = assignmentScore a y (Equiv.refl _))
    (htwo : ∀ τ, assignmentScore a y τ = assignmentScore a y (Equiv.refl _) →
      τ = Equiv.refl _ ∨ τ = Equiv.swap i j)
    (p q : Fin n) (hpq : p ≠ q) (hne : ¬ ((p=i ∧ q=j) ∨ (p=j ∧ q=i))) :
    0 < ((y q-y p)*(starRingEnd ℂ) (a q-a p)).re ∧
    0 < ((y (Equiv.swap i j q)-y (Equiv.swap i j p)) *
      (starRingEnd ℂ) (a q-a p)).re := by
  let σ := Equiv.swap i j
  have hn : Equiv.swap q p ≠ σ := by
    rw [Equiv.swap_comm q p]
    exact swap_ne_of_pair_ne i j p q hpq hne
  constructor
  · exact two_optima_pair_strict a y σ hmax htwo q p hpq.symm hn
  · apply two_optima_pair_strict a (y ∘ σ) σ _ _ q p hpq.symm hn
    · intro τ
      rw [assignmentScore_relabel_targets,assignmentScore_relabel_targets]
      change assignmentScore a y (σ*τ) ≤ assignmentScore a y (σ*1)
      rw [mul_one,heq]
      exact hmax _
    · intro τ h
      rw [assignmentScore_relabel_targets,assignmentScore_relabel_targets] at h
      change assignmentScore a y (σ*τ) = assignmentScore a y (σ*1) at h
      rw [mul_one,heq] at h
      rcases htwo _ h with h | h
      · right
        have he : σ*τ = 1 := h
        have hh := congrArg (fun π => σ⁻¹ * π) he
        simpa [← mul_assoc,σ] using hh
      · left
        have he : σ*τ = σ*1 := h.trans (mul_one σ).symm
        exact mul_left_cancel he

/-- The complex version of the exact transposition score gap. -/
theorem complexScore_swap_difference {n : ℕ} (a y : Fin n → ℂ)
    (i j : Fin n) (hij : i ≠ j) :
    complexAssignmentScore a y (Equiv.refl _) - complexAssignmentScore a y (Equiv.swap i j) =
      (starRingEnd ℂ) (a i-a j)*(y i-y j) := by
  classical
  unfold complexAssignmentScore
  rw [← Finset.sum_sub_distrib]
  calc
    _ = ∑ k : Fin n,
        ((if k=i then (starRingEnd ℂ) (a i) * (y i-y j) else 0) +
         (if k=j then (starRingEnd ℂ) (a j) * (y j-y i) else 0)) := by
      apply Finset.sum_congr rfl
      intro k _
      by_cases hi : k=i
      · subst k; simp [hij]; ring
      · by_cases hj : k=j
        · subst k; simp [hij.symm]; ring
        · simp [Equiv.swap_apply_of_ne_of_ne hi hj,hi,hj]
    _ = _ := by
      simp [Finset.sum_add_distrib,map_sub]
      ring

/-- A genuine transverse rotational transposition event has positive unit
phase charge. The hypothesis is the old-to-new score derivative. -/
theorem two_optima_transposition_phase_charge {n : ℕ} (a y : Fin n → ℂ)
    (i j : Fin n) (hij : i ≠ j)
    (hmax : ∀ τ, assignmentScore a y τ ≤ assignmentScore a y (Equiv.refl _))
    (heq : assignmentScore a y (Equiv.swap i j) = assignmentScore a y (Equiv.refl _))
    (htwo : ∀ τ, assignmentScore a y τ = assignmentScore a y (Equiv.refl _) →
      τ = Equiv.refl _ ∨ τ = Equiv.swap i j)
    (hderiv : 0 < directionalScoreDerivative
      (complexAssignmentScore a y (Equiv.swap i j)-complexAssignmentScore a y (Equiv.refl _)) 0) :
    identityPhase a (y ∘ Equiv.swap i j) - identityPhase a y = Real.pi := by
  apply transposition_phase_charge a y i j hij
    (two_optima_transposition_pair_strict a y i j hmax heq htwo)
  have hs := complexScore_swap_difference a y i j hij
  have hh := congrArg Complex.im hs
  simp only [directionalScoreDerivative,Real.sin_zero,Real.cos_zero,neg_zero,
    zero_mul,one_mul,zero_add,Complex.sub_im] at hderiv
  have he : (y j-y i)*(starRingEnd ℂ) (a j-a i) =
      (starRingEnd ℂ) (a i-a j)*(y i-y j) := by
    rw [show y j-y i = -(y i-y j) by ring,
      show a j-a i = -(a i-a j) by ring,map_neg,neg_mul_neg,mul_comm]
  rw [he]
  simp only [Complex.sub_im] at hh
  linarith

end MonotoneMatching
