import MonotoneMatching.RectangleChordPieces

/-! A boundary time change separates the long anchored arc from its straight connector. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval

def arcClosureVertices (P ε : ℝ) : Fin 3 → ℂ := ![(ε:ℂ),((P-ε:ℝ):ℂ),((P+ε:ℝ):ℂ)]
def arcClosureParameter (P ε : ℝ) (s : I) : ℝ :=
  (polygonInterpolation (arcClosureVertices P ε) (2*(s:ℝ))).re

theorem continuous_arcClosureParameter (P ε : ℝ) : Continuous (arcClosureParameter P ε) := by
  apply Complex.continuous_re.comp
  apply (continuous_polygonInterpolation _).comp
  fun_prop

theorem arcClosureParameter_zero (P ε : ℝ) : arcClosureParameter P ε 0=ε := by
  have h := polygonInterpolation_zero (m := 2) (by norm_num) (arcClosureVertices P ε)
  simpa [arcClosureParameter,arcClosureVertices] using congrArg Complex.re h

theorem arcClosureParameter_one (P ε : ℝ) : arcClosureParameter P ε 1=P+ε := by
  have h := polygonInterpolation_last (m := 2) (by norm_num) (arcClosureVertices P ε)
  simpa [arcClosureParameter,arcClosureVertices] using congrArg Complex.re h

theorem arcClosureParameter_piece (P ε : ℝ) (i : Fin 2) (s : I) :
    arcClosureParameter P ε (uniformArgumentSubparameter (by norm_num) i s)=
      ((1-(s:ℝ)) • arcClosureVertices P ε i.castSucc+
        (s:ℝ) • arcClosureVertices P ε i.succ).re := by
  dsimp only [arcClosureParameter,uniformArgumentSubparameter]
  norm_num only [Nat.cast_ofNat]
  rw [show (2:ℝ)*((i.val+s)/2)=i.val+s by ring]
  rw [polygonInterpolation_on_edge _ i s.property]

theorem arcClosureParameter_long (P ε : ℝ) (s : I) :
    arcClosureParameter P ε (uniformArgumentSubparameter (m := 2) (by norm_num) 0 s)=
      ε+(P-2*ε)*(s:ℝ) := by
  rw [arcClosureParameter_piece]
  norm_num [arcClosureVertices,Complex.add_re,Complex.smul_re,smul_eq_mul]
  ring

theorem arcClosureParameter_short (P ε : ℝ) (s : I) :
    arcClosureParameter P ε (uniformArgumentSubparameter (m := 2) (by norm_num) 1 s)=
      (-ε+2*ε*(s:ℝ))+P := by
  rw [arcClosureParameter_piece]
  norm_num [arcClosureVertices,Complex.add_re,Complex.smul_re,smul_eq_mul]
  ring

end MonotoneMatching
