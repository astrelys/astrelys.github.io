import MonotoneMatching.PolygonCollar

/-! Connections between the left collars of consecutive polygon edges. -/
noncomputable section
namespace MonotoneMatching
open ComplexConjugate Filter
open scoped Topology InnerProductSpace

theorem edgeSide_cyclic (p v w : ℂ) : edgeSide p v w=edgeSide v w p := by
  simp only [edgeSide,Complex.mul_im,Complex.sub_re,Complex.sub_im,Complex.conj_re,Complex.conj_im]
  ring

theorem edgeSide_self (p v : ℂ) : edgeSide p v p=0 := by simp [edgeSide]

theorem edgeSide_end (p v : ℂ) : edgeSide p v v=0 := by
  simp only [edgeSide,Complex.mul_im,Complex.sub_re,Complex.sub_im,Complex.conj_re,Complex.conj_im]
  ring

/-- At a nonpositive turn, each incident segment stays out of the other
edge's strict left half-plane. -/
theorem edgeSide_nonpos_on_incoming (p v w : ℂ) (ht : edgeSide p v w≤0)
    {q : ℂ} (hq : q ∈ segment ℝ p v) : edgeSide v w q≤0 := by
  rw [segment_eq_image] at hq
  obtain ⟨t,htm,rfl⟩ := hq
  rw [edgeSide_affine _ _ _ _ _ _ (by ring),← edgeSide_cyclic,edgeSide_self,mul_zero,add_zero]
  exact mul_nonpos_of_nonneg_of_nonpos (sub_nonneg.mpr htm.2) ht

theorem edgeSide_nonpos_on_outgoing (p v w : ℂ) (ht : edgeSide p v w≤0)
    {q : ℂ} (hq : q ∈ segment ℝ v w) : edgeSide p v q≤0 := by
  rw [segment_eq_image] at hq
  obtain ⟨t,htm,rfl⟩ := hq
  rw [edgeSide_affine _ _ _ _ _ _ (by ring),edgeSide_end,mul_zero,zero_add]
  exact mul_nonpos_of_nonneg_of_nonpos htm.1 ht

/-- The common-left witness exists constructively whenever the two incident
supporting lines are not parallel. Scaling later places it in any vertex ball. -/
theorem exists_common_left_of_turn_ne_zero (p v w : ℂ) (ht : edgeSide p v w≠0) :
    ∃ q : ℂ, 0<edgeSide p v q ∧ 0<edgeSide v w q := by
  let d := edgeSide p v w
  let q := v+d • (w+p-(2:ℝ) • v)
  have h1 : edgeSide p v q=d^2 := by
    dsimp only [q,d]
    simp only [edgeSide,Complex.mul_im,Complex.sub_re,Complex.sub_im,Complex.add_re,
      Complex.add_im,Complex.smul_re,Complex.smul_im,smul_eq_mul,Complex.conj_re,Complex.conj_im]
    ring
  have h2 : edgeSide v w q=d^2 := by
    dsimp only [q,d]
    simp only [edgeSide,Complex.mul_im,Complex.sub_re,Complex.sub_im,Complex.add_re,
      Complex.add_im,Complex.smul_re,Complex.smul_im,smul_eq_mul,Complex.conj_re,Complex.conj_im]
    ring
  exact ⟨q,by rw [h1]; exact sq_pos_of_ne_zero ht,by rw [h2]; exact sq_pos_of_ne_zero ht⟩

/-- Intersecting the two strict left half-planes always avoids both incident
segments, even at a reflex vertex. -/
theorem common_left_avoids_incident (p v w q : ℂ)
    (h1 : 0<edgeSide p v q) (h2 : 0<edgeSide v w q) :
    q ∉ segment ℝ p v ∧ q ∉ segment ℝ v w := by
  exact ⟨fun h => (ne_of_gt h1) (edgeSide_eq_zero_on_segment _ _ h),
    fun h => (ne_of_gt h2) (edgeSide_eq_zero_on_segment _ _ h)⟩

/-- At a nonpositive turn the union of the left half-planes also avoids both
incident segments, allowing the collars to connect around a reflex vertex. -/
theorem union_left_avoids_incident (p v w q : ℂ) (ht : edgeSide p v w≤0)
    (h : 0<edgeSide p v q ∨ 0<edgeSide v w q) :
    q ∉ segment ℝ p v ∧ q ∉ segment ℝ v w := by
  rcases h with h | h
  · exact ⟨fun hq => (ne_of_gt h) (edgeSide_eq_zero_on_segment _ _ hq),
      fun hq => (not_lt_of_ge (edgeSide_nonpos_on_outgoing p v w ht hq)) h⟩
  · exact ⟨fun hq => (not_lt_of_ge (edgeSide_nonpos_on_incoming p v w ht hq)) h,
      fun hq => (ne_of_gt h) (edgeSide_eq_zero_on_segment _ _ hq)⟩

/-- A common-left point can be chosen arbitrarily close to the vertex. -/
theorem common_left_in_ball (p v w : ℂ) {δ : ℝ} (hδ : 0<δ)
    (hex : ∃ q : ℂ, 0<edgeSide p v q ∧ 0<edgeSide v w q) :
    ∃ q ∈ Metric.ball v δ, 0<edgeSide p v q ∧ 0<edgeSide v w q := by
  obtain ⟨q,hq1,hq2⟩ := hex
  let f := fun t : ℝ => (1-t) • v+t • q
  have hc : Continuous f := by fun_prop
  have h0 : f 0=v := by simp [f]
  have hb : ∀ᶠ t in 𝓝 (0:ℝ), f t ∈ Metric.ball v δ :=
    hc.continuousAt.eventually (Metric.isOpen_ball.mem_nhds (by rw [h0]; exact Metric.mem_ball_self hδ))
  obtain ⟨t,hb,ht⟩ := ((hb.filter_mono nhdsWithin_le_nhds).and
    (self_mem_nhdsWithin : ∀ᶠ t in 𝓝[>] (0:ℝ), t∈Set.Ioi (0:ℝ))).exists
  refine ⟨f t,hb,?_,?_⟩
  · rw [edgeSide_affine _ _ _ _ _ _ (by ring),edgeSide_end,mul_zero,zero_add]
    exact mul_pos ht hq1
  · rw [edgeSide_affine _ _ _ _ _ _ (by ring),edgeSide_self,mul_zero,zero_add]
    exact mul_pos ht hq2

/-- Points in the common-left sector have equal index whenever the vertex
ball meets only the two incident segments. -/
theorem polygonIndexPhase_common_vertex_sector {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (verts : ι → ℂ) (p v w : ℂ) (δ : ℝ)
    (hlocal : ∀ q ∈ Metric.ball v δ, q ∈ polygonBoundary next verts →
      q ∈ segment ℝ p v ∨ q ∈ segment ℝ v w)
    {x y : ℂ} (hx : x ∈ Metric.ball v δ) (hy : y ∈ Metric.ball v δ)
    (hx1 : 0<edgeSide p v x) (hx2 : 0<edgeSide v w x)
    (hy1 : 0<edgeSide p v y) (hy2 : 0<edgeSide v w y) :
    polygonIndexPhase next verts x=polygonIndexPhase next verts y := by
  apply polygonIndexPhase_eq_on_connected next verts
    (((convex_ball v δ).inter (convex_edgeSide_pos p v)).inter
      (convex_edgeSide_pos v w)).isPreconnected _ ⟨⟨hx,hx1⟩,hx2⟩ ⟨⟨hy,hy1⟩,hy2⟩
  intro q hq hb
  have hh := common_left_avoids_incident p v w q hq.1.2 hq.2
  exact (hlocal q hq.1.1 hb).elim hh.1 hh.2

/-- At a reflex or straight vertex, the two entire left half-balls join
through their common-left sector without crossing either incident edge. -/
theorem polygonIndexPhase_reflex_vertex_connection {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (verts : ι → ℂ) (p v w : ℂ) {δ : ℝ} (hδ : 0<δ)
    (ht : edgeSide p v w≤0)
    (hex : ∃ q : ℂ, 0<edgeSide p v q ∧ 0<edgeSide v w q)
    (hlocal : ∀ q ∈ Metric.ball v δ, q ∈ polygonBoundary next verts →
      q ∈ segment ℝ p v ∨ q ∈ segment ℝ v w)
    {x y : ℂ} (hx : x ∈ Metric.ball v δ) (hy : y ∈ Metric.ball v δ)
    (hx1 : 0<edgeSide p v x) (hy2 : 0<edgeSide v w y) :
    polygonIndexPhase next verts x=polygonIndexPhase next verts y := by
  obtain ⟨q,hq,hq1,hq2⟩ := common_left_in_ball p v w hδ hex
  have hc := ((convex_ball v δ).inter (convex_edgeSide_pos p v)).isPreconnected.union q
    (show q ∈ Metric.ball v δ ∩ {z | 0<edgeSide p v z} from ⟨hq,hq1⟩)
    (show q ∈ Metric.ball v δ ∩ {z | 0<edgeSide v w z} from ⟨hq,hq2⟩)
    ((convex_ball v δ).inter (convex_edgeSide_pos v w)).isPreconnected
  apply polygonIndexPhase_eq_on_connected next verts hc _ (Or.inl ⟨hx,hx1⟩) (Or.inr ⟨hy,hy2⟩)
  intro z hz hb
  rcases hz with hz | hz
  · have hh := union_left_avoids_incident p v w z ht (Or.inl hz.2)
    exact (hlocal z hz.1 hb).elim hh.1 hh.2
  · have hh := union_left_avoids_incident p v w z ht (Or.inr hz.2)
    exact (hlocal z hz.1 hb).elim hh.1 hh.2

/-- A vector having positive projections onto both incident directions gives
a common-left witness. This also covers straight vertices and will be supplied
by the difference of the two active assignment dual gradients. -/
theorem common_left_of_positive_inner (p v w g : ℂ)
    (h1 : 0 < inner ℝ g (v-p)) (h2 : 0 < inner ℝ g (w-v)) :
    ∃ q : ℂ, 0<edgeSide p v q ∧ 0<edgeSide v w q := by
  refine ⟨v+Complex.I*g,?_,?_⟩
  · have he : edgeSide p v (v+Complex.I*g)=inner ℝ g (v-p) := by
      simp [edgeSide,Complex.mul_im,Complex.mul_re,Complex.inner]
      ring
    rw [he]
    exact h1
  · have he : edgeSide v w (v+Complex.I*g)=inner ℝ g (w-v) := by
      simp [edgeSide,Complex.mul_im,Complex.mul_re,Complex.inner]
      ring
    rw [he]
    exact h2

end MonotoneMatching
