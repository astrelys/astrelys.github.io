import MonotoneMatching.RotationGeometry
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Deriv

/-! Exact sinusoidal score geometry for the rotational upper bound. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators InnerProductSpace

/-- The complex coefficient of a labeled assignment's rotating score. -/
def complexAssignmentScore {n : ℕ} (a b : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) : ℂ :=
  ∑ i, (starRingEnd ℂ) (a i) * b (σ i)

/-- Evaluation of a complex score coefficient at a rotation angle. -/
def directionalScore (z : ℂ) (t : ℝ) : ℝ := Real.cos t * z.re + Real.sin t * z.im

/-- Its exact angular derivative. -/
def directionalScoreDerivative (z : ℂ) (t : ℝ) : ℝ :=
  -Real.sin t * z.re + Real.cos t * z.im

theorem assignmentScore_rotation_coefficient {n : ℕ} (a b : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (t : ℝ) :
    assignmentScore a (rotateClockwise t ∘ b) σ =
      directionalScore (complexAssignmentScore a b σ) t := by
  unfold assignmentScore directionalScore complexAssignmentScore
  simp only [Complex.re_sum, Complex.im_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  simp [Complex.inner, rotateClockwise]
  ring

theorem directionalScore_sub (z w : ℂ) (t : ℝ) :
    directionalScore (z-w) t = directionalScore z t - directionalScore w t := by
  simp only [directionalScore, Complex.sub_re, Complex.sub_im]
  ring

theorem hasDerivAt_directionalScore (z : ℂ) (t : ℝ) :
    HasDerivAt (directionalScore z) (directionalScoreDerivative z t) t := by
  exact ((Real.hasDerivAt_cos t).mul_const z.re).add
    ((Real.hasDerivAt_sin t).mul_const z.im)

theorem directionalScore_square_identity (z : ℂ) (t : ℝ) :
    directionalScore z t ^ 2 + directionalScoreDerivative z t ^ 2 = z.re^2 + z.im^2 := by
  dsimp [directionalScore, directionalScoreDerivative]
  nlinarith [congrArg (fun x : ℝ => x * (z.re^2 + z.im^2)) (Real.sin_sq_add_cos_sq t)]

/-- Every zero of a nonzero coefficient is transverse. -/
theorem directionalScore_transverse {z : ℂ} (hz : z ≠ 0) {t : ℝ}
    (ht : directionalScore z t = 0) : directionalScoreDerivative z t ≠ 0 := by
  intro hd
  have h := directionalScore_square_identity z t
  rw [ht, hd] at h
  have hre : z.re = 0 := by nlinarith [sq_nonneg z.im]
  have him : z.im = 0 := by nlinarith [sq_nonneg z.re]
  exact hz (Complex.ext hre him)

/-- Two distinct assignment coefficients have only transverse score crossings. -/
theorem assignmentScore_rotation_transverse {n : ℕ} (a b : Fin n → ℂ)
    (σ τ : Equiv.Perm (Fin n))
    (h : complexAssignmentScore a b σ ≠ complexAssignmentScore a b τ) (t : ℝ)
    (ht : assignmentScore a (rotateClockwise t ∘ b) σ =
      assignmentScore a (rotateClockwise t ∘ b) τ) :
    directionalScoreDerivative (complexAssignmentScore a b σ - complexAssignmentScore a b τ) t ≠ 0 := by
  apply directionalScore_transverse (sub_ne_zero.mpr h)
  rw [directionalScore_sub]
  simp only [assignmentScore_rotation_coefficient] at ht
  exact sub_eq_zero.mpr ht

/-- A common projection zero forces two coefficient vectors to be collinear. -/
theorem directionalScore_common_zero_determinant {z w : ℂ} {t : ℝ}
    (hz : directionalScore z t = 0) (hw : directionalScore w t = 0) :
    z.re * w.im - z.im * w.re = 0 := by
  dsimp [directionalScore] at hz hw
  have hc := Real.sin_sq_add_cos_sq t
  by_cases hs : Real.sin t = 0
  · have hcos : Real.cos t ≠ 0 := by intro h; rw [hs,h] at hc; norm_num at hc
    rw [hs, zero_mul, add_zero] at hz hw
    have hzr := (mul_eq_zero.mp hz).resolve_left hcos
    have hwr := (mul_eq_zero.mp hw).resolve_left hcos
    simp [hzr,hwr]
  · have hdet : Real.sin t * (z.re * w.im - z.im * w.re) = 0 := by
      nlinarith [congrArg (fun x : ℝ => x * w.re) hz,
        congrArg (fun x : ℝ => x * z.re) hw]
    exact (mul_eq_zero.mp hdet).resolve_left hs

end MonotoneMatching
