import MonotoneMatching.ArgumentLifts

/-! A compact nonvanishing arc stays nonvanishing under sufficiently small translations. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval

theorem compact_arc_translation_radius (δ : I → ℂ) (hc : Continuous δ) (hn : ∀ s, δ s≠0) :
    ∃ r : ℝ, 0<r ∧ ∀ w : ℂ, ‖w‖<r → ∀ t s : I,
      δ s-(t:ℝ) • w≠0 ∧ δ s+(t:ℝ) • w≠0 := by
  obtain ⟨s₀,_,hs₀⟩ := isCompact_univ.exists_isMinOn (Set.univ_nonempty : (Set.univ : Set I).Nonempty)
    hc.norm.continuousOn
  refine ⟨‖δ s₀‖,norm_pos_iff.mpr (hn s₀),?_⟩
  intro w hw t s
  have hmin : ‖δ s₀‖≤‖δ s‖ := hs₀ (Set.mem_univ s)
  have hnorm : ‖(t:ℝ) • w‖<‖δ s‖ := by
    rw [norm_smul,Real.norm_eq_abs,abs_of_nonneg t.property.1]
    have hle : (t:ℝ)*‖w‖≤‖w‖ := by nlinarith [norm_nonneg w,t.property.2]
    exact lt_of_le_of_lt hle (lt_of_lt_of_le hw hmin)
  constructor
  · intro he
    have hz := congrArg norm (sub_eq_zero.mp he)
    linarith
  · intro he
    have hz := congrArg norm (eq_neg_of_add_eq_zero_left he)
    rw [norm_neg] at hz
    linarith

end MonotoneMatching
