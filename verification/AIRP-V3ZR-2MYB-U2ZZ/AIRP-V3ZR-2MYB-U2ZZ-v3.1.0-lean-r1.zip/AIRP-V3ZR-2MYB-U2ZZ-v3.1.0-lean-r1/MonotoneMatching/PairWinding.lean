import MonotoneMatching.ArgumentLifts
import Mathlib.Analysis.SpecialFunctions.Complex.LogDeriv
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Topology.Homotopy.Contractible

noncomputable section
namespace MonotoneMatching
open scoped Topology

/-- A continuous argument lift on the real time axis exists for any nonzero path. -/
theorem exists_real_argument_lift (γ : ℝ → ℂ) (hc : Continuous γ)
    (hn : ∀ t, γ t ≠ 0) :
    ∃ φ : C(ℝ, ℝ), ∀ t, (φ t : Real.Angle) = (Complex.arg (γ t) : Real.Angle) := by
  let g : C(ℝ, Real.Angle) := ⟨_, continuous_argument_angle γ hc hn⟩
  obtain ⟨φ, hφ, _⟩ := (AddCircle.isCoveringMap_coe (2 * Real.pi)).existsUnique_continuousMap_lifts
    g 0 (Complex.arg (γ 0)) rfl
  exact ⟨φ, fun t => congrFun hφ.2 t⟩

/-- A continuous argument lift differentiates through a local logarithm branch. -/
theorem argument_lift_hasDerivAt (γ : ℝ → ℂ) (φ : ℝ → ℝ) (x : ℝ) (v : ℂ)
    (hφ : ContinuousAt φ x) (hn : ∀ t, γ t ≠ 0)
    (he : ∀ t, (φ t : Real.Angle) = (Complex.arg (γ t) : Real.Angle))
    (hd : HasDerivAt γ v x) : HasDerivAt φ (v / γ x).im x := by
  let ψ : ℝ → ℝ := fun t => (Complex.log (γ t / γ x)).im + φ x
  have hlog := (hd.div_const (γ x)).clog_real (by simp [hn x, Complex.slitPlane])
  have hψ : HasDerivAt ψ (v / γ x).im x := by
    simpa [ψ, hn x] using (Complex.imCLM.hasFDerivAt.comp_hasDerivAt x hlog).add_const (φ x)
  have hψx : ψ x = φ x := by simp [ψ, hn x]
  have hangle (t : ℝ) : (ψ t : Real.Angle) = (φ t : Real.Angle) := by
    simp only [ψ, Complex.log_im, Real.Angle.coe_add]
    rw [Complex.arg_div_coe_angle (hn t) (hn x), he x, he t]
    abel
  obtain ⟨U, hU, hx, hinj⟩ :=
    (AddCircle.isCoveringMap_coe (2 * Real.pi)).isLocalHomeomorph.isLocallyInjective (φ x)
  have h1 : ∀ᶠ t in 𝓝 x, φ t ∈ U := hφ (hU.mem_nhds hx)
  have h2 : ∀ᶠ t in 𝓝 x, ψ t ∈ U := hψ.continuousAt (hψx ▸ hU.mem_nhds hx)
  apply hψ.congr_of_eventuallyEq
  filter_upwards [h1, h2] with t ht ht'
  exact hinj ht ht' (hangle t).symm

/-- The exact angular derivative formula uses the standard oriented planar area. -/
theorem argument_lift_hasDerivAt_area (γ : ℝ → ℂ) (φ : ℝ → ℝ) (x : ℝ) (v : ℂ)
    (hφ : ContinuousAt φ x) (hn : ∀ t, γ t ≠ 0)
    (he : ∀ t, (φ t : Real.Angle) = (Complex.arg (γ t) : Real.Angle))
    (hd : HasDerivAt γ v x) :
    HasDerivAt φ (((γ x).re * v.im - (γ x).im * v.re) / Complex.normSq (γ x)) x := by
  convert argument_lift_hasDerivAt γ φ x v hφ hn he hd using 1
  rw [Complex.div_im]
  ring

/-- Nonpositive oriented area velocity makes every continuous argument lift antitone. -/
theorem argument_lift_deriv_nonpos (γ : ℝ → ℂ) (φ : ℝ → ℝ) (v : ℝ → ℂ)
    (hc : Continuous φ) (hn : ∀ t, γ t ≠ 0)
    (he : ∀ t, (φ t : Real.Angle) = (Complex.arg (γ t) : Real.Angle))
    (hd : ∀ t, HasDerivAt γ (v t) t)
    (hdet : ∀ t, (γ t).re * (v t).im - (γ t).im * (v t).re ≤ 0) :
    Antitone φ := by
  apply antitone_of_hasDerivAt_nonpos
    (fun t => argument_lift_hasDerivAt γ φ t (v t) hc.continuousAt hn he (hd t))
  intro t
  change (v t / γ t).im ≤ 0
  rw [Complex.div_im, ← sub_div]
  apply div_nonpos_of_nonpos_of_nonneg
  · nlinarith [hdet t]
  · exact Complex.normSq_nonneg _

open scoped unitInterval

/-- Every nonvanishing differentiable closed path with nonpositive angular velocity
has a nonnegative integral clockwise winding, independently of the chosen lift. -/
theorem nonnegative_integer_clockwise_winding (γ : ℝ → ℂ) (v : ℝ → ℂ)
    (T : ℝ) (hT : 0 < T) (hd : ∀ t, HasDerivAt γ (v t) t)
    (hn : ∀ t, γ t ≠ 0) (hclosed : γ T = γ 0)
    (hdet : ∀ t, (γ t).re * (v t).im - (γ t).im * (v t).re ≤ 0) :
    ∃ w : ℕ,
      (∃ φ : C(I, ℝ), ∀ t, (φ t : Real.Angle) =
        (Complex.arg (γ (T * t)) : Real.Angle)) ∧
      ∀ φ : C(I, ℝ),
        (∀ t, (φ t : Real.Angle) = (Complex.arg (γ (T * t)) : Real.Angle)) →
        -(φ 1 - φ 0) / (2 * Real.pi) = (w : ℝ) := by
  have hc : Continuous γ := continuous_iff_continuousAt.mpr fun t => (hd t).continuousAt
  obtain ⟨ψ, hψ⟩ := exists_real_argument_lift γ hc hn
  have ha := argument_lift_deriv_nonpos γ ψ v ψ.continuous hn hψ hd hdet
  have hz : ((ψ 0 - ψ T : ℝ) : Real.Angle) = 0 := by
    rw [Real.Angle.coe_sub, hψ, hψ, hclosed, sub_self]
  obtain ⟨k, hk⟩ := Real.Angle.coe_eq_zero_iff.mp hz
  have hk' : ψ 0 - ψ T = (k : ℝ) * (2 * Real.pi) := by
    simpa only [zsmul_eq_mul] using hk.symm
  have hk0 : 0 ≤ k := by
    have : (0 : ℝ) ≤ k := (mul_nonneg_iff_of_pos_right Real.two_pi_pos).mp
      (hk' ▸ sub_nonneg.mpr (ha hT.le))
    exact_mod_cast this
  let θ : C(I, ℝ) := ⟨fun t => ψ (T * t),
    ψ.continuous.comp (continuous_const.mul continuous_subtype_val)⟩
  have hθ (t : I) : (θ t : Real.Angle) = (Complex.arg (γ (T * t)) : Real.Angle) := hψ _
  refine ⟨k.toNat, ⟨θ, hθ⟩, ?_⟩
  intro φ hφ
  have hi := argument_lift_increment_unique φ θ φ.continuous θ.continuous
    (fun t => (hφ t).trans (hθ t).symm) 0 1
  have ht : θ 1 - θ 0 = ψ T - ψ 0 := by simp [θ]
  rw [hi, ht]
  have hcast : (k.toNat : ℝ) = (k : ℝ) := by exact_mod_cast Int.toNat_of_nonneg hk0
  rw [hcast]
  apply (div_eq_iff (ne_of_gt Real.two_pi_pos)).mpr
  linarith

/-- Exact W2 target: smooth periodic trajectories are represented on the real time
axis, with actual derivatives, pairwise separation, and clockwise area inequality.
Only differentiability and endpoint closure are needed for this conclusion. -/
def pairWindingNonnegativeStatement : Prop :=
  ∀ (n : ℕ) (b v : Fin n → ℝ → ℂ) (T : ℝ), 0 < T →
    (∀ i t, HasDerivAt (b i) (v i t) t) →
    (∀ i, Function.Periodic (b i) T) →
    (∀ i j, i ≠ j → ∀ t, b i t ≠ b j t) →
    (∀ i j, i < j → ∀ t,
      (b j t - b i t).re * (v j t - v i t).im -
        (b j t - b i t).im * (v j t - v i t).re ≤ 0) →
    ∀ i j, i < j → ∃ w : ℕ,
      (∃ φ : C(I, ℝ), ∀ t, (φ t : Real.Angle) =
        (Complex.arg (b j (T * t) - b i (T * t)) : Real.Angle)) ∧
      ∀ φ : C(I, ℝ),
        (∀ t, (φ t : Real.Angle) =
          (Complex.arg (b j (T * t) - b i (T * t)) : Real.Angle)) →
        -(φ 1 - φ 0) / (2 * Real.pi) = (w : ℝ)

/-- W2 of the winding theorem: every clockwise pair winding is a nonnegative
integer, with existence of a continuous lift and independence of its choice. -/
theorem pair_winding_nonnegative_integer : pairWindingNonnegativeStatement := by
  intro n b v T hT hd hp hn ha i j hij
  apply nonnegative_integer_clockwise_winding
    (fun t => b j t - b i t) (fun t => v j t - v i t) T hT
  · intro t
    exact (hd j t).sub (hd i t)
  · intro t
    exact sub_ne_zero.mpr (hn j i (ne_of_gt hij) t)
  · simpa using congrArg₂ (· - ·) (hp j 0) (hp i 0)
  · exact ha i j hij

end MonotoneMatching
