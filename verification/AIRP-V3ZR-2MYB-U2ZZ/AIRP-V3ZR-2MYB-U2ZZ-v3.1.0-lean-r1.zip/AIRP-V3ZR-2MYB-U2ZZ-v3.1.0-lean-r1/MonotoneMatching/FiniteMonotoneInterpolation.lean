import MonotoneMatching.FiniteLipschitzExtension
import MonotoneMatching.CayleyMonotone
import Mathlib.Data.Finset.Max
noncomputable section
namespace MonotoneMatching
open scoped BigOperators InnerProductSpace
set_option backward.isDefEq.respectTransparency.types false

/-- A finite strictly monotone list has strictly contracting Cayley data. -/
theorem finite_cayley_contraction {ι : Type*} [Fintype ι] (x G : ι → ℂ)
    (hmono : ∀ i j,i ≠ j → 0 < inner ℝ (x i-x j) (G i-G j)) :
    Function.Injective (fun i => x i+G i) ∧
      ∃ k : ℝ, 0 < k ∧ k < 1 ∧ ∀ i j,
        ‖(x i-G i)-(x j-G j)‖ ≤ k*‖(x i+G i)-(x j+G j)‖ := by
  classical
  let u := fun i => x i+G i
  let z := fun i => x i-G i
  have hstrict (i j : ι) (hij : i ≠ j) : ‖z i-z j‖ < ‖u i-u j‖ := by
    have hdiff : ‖u i-u j‖^2-‖z i-z j‖^2=4*inner ℝ (x i-x j) (G i-G j) := by
      rw [show u i-u j=(x i-x j)+(G i-G j) by dsimp [u]; ring,
        show z i-z j=(x i-x j)-(G i-G j) by dsimp [z]; ring,
        norm_add_sq_real (x i-x j) (G i-G j),norm_sub_sq_real (x i-x j) (G i-G j)]
      ring
    nlinarith [hmono i j hij,norm_nonneg (z i-z j),norm_nonneg (u i-u j)]
  have hu : Function.Injective u := by
    intro i j he
    by_contra hij
    have h := hstrict i j hij
    rw [he,sub_self,norm_zero] at h
    exact (not_lt_of_ge (norm_nonneg _)) h
  refine ⟨hu,?_⟩
  let ratio (p : ι × ι) := ‖z p.1-z p.2‖/‖u p.1-u p.2‖
  have hratio (p : ι × ι) : ratio p < 1 := by
    by_cases he : p.1=p.2
    · simp [ratio,he]
    · exact (div_lt_one (norm_pos_iff.mpr (sub_ne_zero.mpr (hu.ne he)))).mpr (hstrict _ _ he)
  let S : Finset ℝ := insert 0 (Finset.univ.image ratio)
  have hS : S.Nonempty := ⟨0,Finset.mem_insert_self _ _⟩
  let M := S.max' hS
  have hM0 : 0 ≤ M := Finset.le_max' _ _ (Finset.mem_insert_self _ _)
  have hM1 : M < 1 := by
    apply (Finset.max'_lt_iff _ _).mpr
    intro t ht
    rcases Finset.mem_insert.mp ht with rfl | ht
    · norm_num
    · obtain ⟨p,_,rfl⟩ := Finset.mem_image.mp ht
      exact hratio p
  let k := (M+1)/2
  have hk0 : 0 < k := by dsimp [k]; linarith
  have hk1 : k < 1 := by dsimp [k]; linarith
  refine ⟨k,hk0,hk1,?_⟩
  intro i j
  by_cases he : i=j
  · subst j; simp
  have hden : 0 < ‖u i-u j‖ := norm_pos_iff.mpr (sub_ne_zero.mpr (hu.ne he))
  have hr : ratio (i,j) ≤ M := Finset.le_max' _ _
    (Finset.mem_insert_of_mem (Finset.mem_image.mpr ⟨(i,j),Finset.mem_univ _,rfl⟩))
  have hrk : ratio (i,j) ≤ k := by dsimp [k]; linarith
  exact (div_le_iff₀ hden).mp hrk

/-- Strictly monotone finite data admit an exact global monotone Lipschitz interpolant. -/
theorem finite_strict_monotone_global_interpolation {ι : Type*} [Fintype ι]
    (x G : ι → ℂ)
    (hmono : ∀ i j,i ≠ j → 0 < inner ℝ (x i-x j) (G i-G j)) :
    ∃ F : ℂ → ℂ, ∃ L : ℝ, 0 < L ∧
      (∀ i,F (x i)=G i) ∧ (∀ p q,0 ≤ inner ℝ (p-q) (F p-F q)) ∧
      (∀ p q,‖F p-F q‖ ≤ L*‖p-q‖) := by
  classical
  obtain ⟨hu,k,hk0,hk1,hk⟩ := finite_cayley_contraction x G hmono
  let u := fun i => x i+G i
  let z := fun i => x i-G i
  let f := Function.extend u z (fun _ => 0)
  have hf (i : ι) : f (u i)=z i := hu.extend_apply _ _ i
  obtain ⟨Z,hZfix,hZ⟩ := exists_plane_lipschitz_extension (Set.range u) f k hk0 (by
    rintro _ ⟨i,rfl⟩ _ ⟨j,rfl⟩
    rw [hf,hf]
    exact hk i j)
  have hZi (i : ι) : Z (u i)=z i := (hZfix _ (Set.mem_range_self i)).trans (hf i)
  obtain ⟨F,hFmono,hFLip,hFi⟩ := cayley_monotone_field Z k hk0.le hk1 hZ
  refine ⟨F,2/(1-k)+1,by positivity,?_,hFmono,hFLip⟩
  intro i
  have h := hFi (u i)
  rw [hZi] at h
  have hx : ((1/2):ℝ) • (u i+z i)=x i := by
    change ((1/2):ℝ) • ((x i+G i)+(x i-G i))=x i
    module
  have hG : ((1/2):ℝ) • (u i-z i)=G i := by
    change ((1/2):ℝ) • ((x i+G i)-(x i-G i))=G i
    module
  rwa [hx,hG] at h

/-- Weakly monotone finite data admit exact global interpolation after arbitrarily small
positive identity regularization. -/
theorem finite_weak_monotone_global_regularization {ι : Type*} [Fintype ι]
    (x G : ι → ℂ) (hx : Function.Injective x)
    (hmono : ∀ i j,0 ≤ inner ℝ (x i-x j) (G i-G j))
    (ε : ℝ) (hε : 0 < ε) :
    ∃ F : ℂ → ℂ, ∃ L : ℝ, 0 < L ∧
      (∀ i,F (x i)=G i+ε • x i) ∧ (∀ p q,0 ≤ inner ℝ (p-q) (F p-F q)) ∧
      (∀ p q,‖F p-F q‖ ≤ L*‖p-q‖) := by
  apply finite_strict_monotone_global_interpolation x (fun i => G i+ε • x i)
  intro i j hij
  have he : (G i+ε • x i)-(G j+ε • x j)=(G i-G j)+ε • (x i-x j) := by module
  rw [he,inner_add_right,inner_smul_right,real_inner_self_eq_norm_sq]
  have hn : 0 < ‖x i-x j‖ := norm_pos_iff.mpr (sub_ne_zero.mpr (hx.ne hij))
  exact add_pos_of_nonneg_of_pos (hmono i j) (mul_pos hε (sq_pos_of_pos hn))

end MonotoneMatching
