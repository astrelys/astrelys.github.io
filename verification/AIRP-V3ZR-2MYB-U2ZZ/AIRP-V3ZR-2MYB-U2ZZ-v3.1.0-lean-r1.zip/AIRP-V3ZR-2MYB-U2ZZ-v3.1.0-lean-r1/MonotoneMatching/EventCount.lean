import MonotoneMatching.WindingCharges
import MonotoneMatching.CyclicLabels
noncomputable section
namespace MonotoneMatching
open Set
open scoped BigOperators
set_option backward.isDefEq.respectTransparency.types false

/-- The correction contributed by a long cycle, zero for a transposition
or an artificial subdivision point. -/
def trajectoryCellExcess {n m : ℕ} (b : Fin n → ℝ → ℂ) (cut : Fin (m+1) → ℝ)
    (label : Fin m → Equiv.Perm (Fin n)) (i : Fin m) : ℕ :=
  if label (finRotate m i)=label i then 0 else
    if ((label i)⁻¹*label (finRotate m i)).support.card=2 then 0 else
      ((label i)⁻¹*label (finRotate m i)).support.card-2+
        2*cycleInteriorCount (fun j => b (label i j) (trajectoryTransitionTime cut i))
          ((label i)⁻¹*label (finRotate m i))

/-- Number of genuine changes around the time circle. -/
def trajectoryEventCount {n m : ℕ} (label : Fin m → Equiv.Perm (Fin n)) : ℕ :=
  (Finset.univ.filter (fun i => label (finRotate m i)≠label i)).card

theorem trajectory_charge_eq_indicator_add_excess {n m : ℕ}
    (b : Fin n → ℝ → ℂ) (cut : Fin (m+1) → ℝ)
    (label : Fin m → Equiv.Perm (Fin n)) (i : Fin m)
    (hc : label (finRotate m i)≠label i → ((label i)⁻¹*label (finRotate m i)).IsCycle) :
    trajectoryCellCharge b cut label i=
      (if label (finRotate m i)≠label i then 1 else 0)+trajectoryCellExcess b cut label i := by
  classical
  by_cases he : label (finRotate m i)=label i
  · simp only [trajectoryCellCharge,trajectoryCellExcess,he,ite_true,ne_eq,not_true_eq_false,ite_false,add_zero]
  · have hk := (hc he).two_le_card_support
    simp only [trajectoryCellCharge,trajectoryCellExcess,he,ite_false]
    unfold cycleEventCharge
    split_ifs with h2
    · omega
    · omega

theorem trajectory_event_count_formula {n m : ℕ}
    (b : Fin n → ℝ → ℂ) (cut : Fin (m+1) → ℝ)
    (label : Fin m → Equiv.Perm (Fin n)) (W : ℕ)
    (hc : ∀ i,label (finRotate m i)≠label i → ((label i)⁻¹*label (finRotate m i)).IsCycle)
    (hq : (∑ i,trajectoryCellCharge b cut label i)=2*W) :
    trajectoryEventCount label+∑ i,trajectoryCellExcess b cut label i=2*W ∧
    trajectoryEventCount label=2*W-∑ i,trajectoryCellExcess b cut label i ∧
    trajectoryEventCount label≤2*W := by
  classical
  have he : (∑ i,trajectoryCellCharge b cut label i)=
      trajectoryEventCount label+∑ i,trajectoryCellExcess b cut label i := by
    simp_rw [trajectory_charge_eq_indicator_add_excess b cut label _ (hc _)]
    rw [Finset.sum_add_distrib]
    simp [trajectoryEventCount,Finset.card_filter]
  rw [he] at hq
  exact ⟨hq,by omega,by omega⟩

theorem cyclic_trajectory_label_count {n m : ℕ} (hm : 0<m)
    (label : Fin m → Equiv.Perm (Fin n)) (W : ℕ)
    (hcount : trajectoryEventCount label≤2*W) :
    (Finset.univ.image label).card≤max 1 (2*W) := by
  classical
  by_cases hn : ∃ i j,label i≠label j
  · have hm2 : 2≤m := by
      obtain ⟨i,j,hij⟩ := hn
      have : i≠j := fun h => hij (congrArg label h)
      have hi := i.isLt
      have hj := j.isLt
      have hv : i.val≠j.val := fun h => this (Fin.ext h)
      omega
    exact (cyclic_label_count_le_changes (finRotate m) label
      (finRotate_reaches_all hm2) hn).trans (hcount.trans (le_max_right _ _))
  · have hs : Finset.univ.image label ⊆ {label ⟨0,hm⟩} := by
      intro x hx
      obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp hx
      simp only [Finset.mem_singleton]
      by_contra he
      exact hn ⟨i,⟨0,hm⟩,he⟩
    exact (Finset.card_le_card hs).trans (by simp)

end MonotoneMatching
