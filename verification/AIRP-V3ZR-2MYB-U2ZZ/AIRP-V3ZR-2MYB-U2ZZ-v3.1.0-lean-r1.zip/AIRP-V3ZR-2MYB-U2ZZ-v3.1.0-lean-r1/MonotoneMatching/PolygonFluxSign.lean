import MonotoneMatching.HorizontalSliceFlux
import MonotoneMatching.QuarterTurnGeometry

/-! The sign of rotational flux follows from exact finite horizontal strips,
then a quarter-turn supplies the second coordinate component. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

theorem polygon_horizontal_flux_nonpos {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ)
    {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ) (e : ι → Fin n) (he : Function.Injective e)
    (hedge : ∀ i, ∀ t∈Set.Ioo (0:ℝ) 1, (1-t) • v i+t • v (next i)∈strictDualCell a r (e i))
    (L R : ℝ) (hgap : L-R=2*Real.pi)
    (hL : ∀ i q, q∈strictDualCell a r (e i) → 0<edgeSide (v i) (v (next i)) q → polygonIndexPhase next v q=L)
    (hR : ∀ i q, q∈strictDualCell a r (e i) → edgeSide (v i) (v (next i)) q<0 → polygonIndexPhase next v q=R)
    (hphase : ∀ q, q∉polygonBoundary next v → polygonIndexPhase next v q≤0) :
    (∑ i, (a (e i)).re*((v (next i)).im-(v i).im))≤0 := by
  obtain ⟨lo,hlo⟩ := (Set.finite_range (fun i => (v i).im)).bddBelow
  obtain ⟨hi,hhi⟩ := (Set.finite_range (fun i => (v i).im)).bddAbove
  let lower := min lo hi-1
  let upper := max lo hi+1
  have hlt : lower<upper := by dsimp [lower,upper]; linarith [min_le_left lo hi,le_max_left lo hi]
  have hB (j : ι) : (v j).im∈Set.Icc lower upper := by
    have hl := hlo (Set.mem_range_self j)
    have hh := hhi (Set.mem_range_self j)
    dsimp [lower,upper]
    constructor <;> linarith [min_le_left lo hi,le_max_right lo hi]
  obtain ⟨m,_,cut,hcut,hfirst,hlast,havoid,_⟩ := finite_event_subdivision
    (Set.range (fun i => (v i).im)) (Set.finite_range _) hlt
    (by rintro t ⟨j,rfl⟩; exact hB j)
  have hBC (j : ι) : (v j).im∈Set.Icc (cut 0) (cut (Fin.last m)) := by rw [hfirst,hlast]; exact hB j
  have hno (j : ι) (i : Fin m) : (v j).im∉Set.Ioo (cut i.castSucc) (cut i.succ) := by
    intro ht
    exact havoid i _ ht (Set.mem_range_self j)
  apply finite_slice_flux_nonpos cut hcut (fun i => (v i).im) (fun i => (v (next i)).im)
    (fun i => (a (e i)).re) hBC (fun i => hBC (next i)) hno (fun i => hno (next i))
  intro i
  have hc : cut i.castSucc<cut i.succ := hcut i.castSucc_lt_succ
  have hm : (cut i.castSucc+cut i.succ)/2∈Set.Ioo (cut i.castSucc) (cut i.succ) := by constructor <;> linarith
  have hh : ∀ j, (cut i.castSucc+cut i.succ)/2≠(v j).im := by
    intro j heq
    exact havoid i _ hm ⟨j,heq.symm⟩
  exact horizontal_slice_flux_nonpos next v _ hh a r e he hedge L R hgap hL hR hphase

theorem polygon_rotational_flux_nonpos {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ)
    {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ) (e : ι → Fin n) (he : Function.Injective e)
    (hedge : ∀ i, ∀ t∈Set.Ioo (0:ℝ) 1, (1-t) • v i+t • v (next i)∈strictDualCell a r (e i))
    (L R : ℝ) (hgap : L-R=2*Real.pi)
    (hL : ∀ i q, q∈strictDualCell a r (e i) → 0<edgeSide (v i) (v (next i)) q → polygonIndexPhase next v q=L)
    (hR : ∀ i q, q∈strictDualCell a r (e i) → edgeSide (v i) (v (next i)) q<0 → polygonIndexPhase next v q=R)
    (hphase : ∀ q, q∉polygonBoundary next v → polygonIndexPhase next v q≤0) :
    (∑ i, ((a (e i)).re*((v (next i)).im-(v i).im)-
      (a (e i)).im*((v (next i)).re-(v i).re)))≤0 := by
  have h1 := polygon_horizontal_flux_nonpos next v a r e he hedge L R hgap hL hR hphase
  let v' := fun i => Complex.I*v i
  let a' := fun i => Complex.I*a i
  have hedge' (i : ι) (t : ℝ) (ht : t∈Set.Ioo (0:ℝ) 1) :
      (1-t) • v' i+t • v' (next i)∈strictDualCell a' r (e i) := by
    change (1-t) • (Complex.I*v i)+t • (Complex.I*v (next i))∈strictDualCell a' r (e i)
    rw [quarter_turn_affine,quarter_turn_strictDualCell]
    exact hedge i t ht
  have hL' (i : ι) (q : ℂ) (hq : q∈strictDualCell a' r (e i))
      (hs : 0<edgeSide (v' i) (v' (next i)) q) : polygonIndexPhase next v' q=L := by
    obtain ⟨p,rfl⟩ := quarter_turn_surjective q
    rw [quarter_turn_strictDualCell] at hq
    rw [quarter_turn_edgeSide] at hs
    rw [quarter_turn_polygonIndexPhase]
    exact hL i p hq hs
  have hR' (i : ι) (q : ℂ) (hq : q∈strictDualCell a' r (e i))
      (hs : edgeSide (v' i) (v' (next i)) q<0) : polygonIndexPhase next v' q=R := by
    obtain ⟨p,rfl⟩ := quarter_turn_surjective q
    rw [quarter_turn_strictDualCell] at hq
    rw [quarter_turn_edgeSide] at hs
    rw [quarter_turn_polygonIndexPhase]
    exact hR i p hq hs
  have hphase' (q : ℂ) (hq : q∉polygonBoundary next v') : polygonIndexPhase next v' q≤0 := by
    obtain ⟨p,rfl⟩ := quarter_turn_surjective q
    rw [quarter_turn_polygonBoundary] at hq
    rw [quarter_turn_polygonIndexPhase]
    exact hphase p hq
  have h2 := polygon_horizontal_flux_nonpos next v' a' r e he hedge' L R hgap hL' hR' hphase'
  simp only [a',v',Complex.mul_re,Complex.mul_im,Complex.I_re,Complex.I_im,
    zero_mul,one_mul,zero_sub,zero_add,neg_mul,Finset.sum_neg_distrib] at h2
  rw [Finset.sum_sub_distrib]
  linarith

end MonotoneMatching
