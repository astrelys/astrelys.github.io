import MonotoneMatching.TrajectoryGenericity
import MonotoneMatching.RotationCells
import MonotoneMatching.TransitionEvents
noncomputable section
namespace MonotoneMatching
open scoped BigOperators
set_option backward.isDefEq.respectTransparency.types false

theorem continuous_trajectory_score {n : ℕ} (a : Fin n → ℂ) (b : Fin n → ℝ → ℂ)
    (hb : ∀ i, Continuous (b i)) (σ : Equiv.Perm (Fin n)) :
    Continuous (fun t => assignmentScore a (fun i => b i t) σ) := by
  unfold assignmentScore
  exact continuous_finsetSum _ (fun i _ => continuous_const.inner (hb (σ i)))

theorem exists_trajectory_score_maximizer {n : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (t : ℝ) :
    ∃ σ : Equiv.Perm (Fin n), ∀ τ,
      assignmentScore a (fun i => b i t) τ ≤ assignmentScore a (fun i => b i t) σ := by
  classical
  obtain ⟨σ,_,hσ⟩ := Finset.exists_max_image Finset.univ
    (fun σ : Equiv.Perm (Fin n) => assignmentScore a (fun i => b i t) σ)
    Finset.univ_nonempty
  exact ⟨σ,fun τ => hσ τ (Finset.mem_univ τ)⟩

/-- Every nonempty connected region with no score ties has one fixed unique
optimizer throughout the region. -/
theorem exists_trajectory_optimizer_on_tie_free_connected {n : ℕ} (a : Fin n → ℂ) (b : Fin n → ℝ → ℂ)
    (hb : ∀ i, Continuous (b i))
    {s : Set ℝ} (hs : IsPreconnected s) (hne : s.Nonempty)
    (htie : ∀ t ∈ s, ∀ σ τ : Equiv.Perm (Fin n), σ ≠ τ →
      assignmentScore a (fun i => b i t) σ ≠ assignmentScore a (fun i => b i t) τ) :
    ∃ σ : Equiv.Perm (Fin n), ∀ t ∈ s, UniqueMinimum a (fun i => b i t) σ := by
  obtain ⟨u,hu⟩ := hne
  obtain ⟨σ,hσ⟩ := exists_trajectory_score_maximizer a b u
  refine ⟨σ,?_⟩
  intro t ht τ hτ
  apply (assignmentCost_lt_iff_score_gt _ _ _ _).mpr
  apply strict_comparison_on_connected hs
    (continuous_trajectory_score a b hb τ).continuousOn
    (continuous_trajectory_score a b hb σ).continuousOn
    (fun t ht => htie t ht τ σ hτ) hu _ t ht
  exact lt_of_le_of_ne (hσ τ) (htie u hu τ σ hτ)

/-- An optimizer throughout the open cell remains weakly optimal at both
endpoints, without any genericity assumption at the endpoints. -/
theorem trajectory_optimizer_on_closed_cell {n : ℕ} (a : Fin n → ℂ) (b : Fin n → ℝ → ℂ)
    (hb : ∀ i, Continuous (b i))
    (σ : Equiv.Perm (Fin n)) {u v : ℝ} (huv : u < v)
    (h : ∀ t ∈ Set.Ioo u v, UniqueMinimum a (fun i => b i t) σ) :
    ∀ t ∈ Set.Icc u v, ∀ τ, assignmentScore a (fun i => b i t) τ ≤
      assignmentScore a (fun i => b i t) σ := by
  intro t ht τ
  apply le_on_closure (s := Set.Ioo u v)
    (f := fun t => assignmentScore a (fun i => b i t) τ)
    (g := fun t => assignmentScore a (fun i => b i t) σ)
  · intro x hx
    by_cases he : τ = σ
    · simp [he]
    · exact ((assignmentCost_lt_iff_score_gt _ _ _ _).mp (h x hx τ he)).le
  · exact (continuous_trajectory_score a b hb τ).continuousOn
  · exact (continuous_trajectory_score a b hb σ).continuousOn
  · rwa [closure_Ioo huv.ne]

/-- Generic trajectory scores admit actual constant-label open cells with weak
optimality at every endpoint. Every optimizer is represented in the labels. -/
theorem exists_generic_trajectory_cells {n : ℕ} (a : Fin n → ℂ) (b v : Fin n → ℝ → ℂ)
    (hd : ∀ i t, HasDerivAt (b i) (v i t) t) (P : ℝ) (hP : 0 < P)
    (ha : GenericTrajectorySources b v (Set.Icc 0 P) a) :
    ∃ m : ℕ, 0 < m ∧ ∃ cut : Fin (m+1) → ℝ, ∃ label : Fin m → Equiv.Perm (Fin n),
      StrictMono cut ∧ cut 0=0 ∧ cut (Fin.last m)=P ∧
      (∀ i, ∀ t ∈ Set.Ioo (cut i.castSucc) (cut i.succ),
        UniqueMinimum a (fun i => b i t) (label i)) ∧
      (∀ i, ∀ t ∈ Set.Icc (cut i.castSucc) (cut i.succ), ∀ τ,
        assignmentScore a (fun i => b i t) τ ≤
          assignmentScore a (fun i => b i t) (label i)) ∧
      (∀ t ∈ Set.Icc 0 P, ∀ σ, UniqueMinimum a (fun i => b i t) σ → ∃ i, label i=σ) := by
  classical
  let T : Set ℝ := {t | t ∈ Set.Icc 0 (P) ∧
    ∃ σ τ : Equiv.Perm (Fin n), σ ≠ τ ∧
      assignmentScore a (fun i => b i t) σ = assignmentScore a (fun i => b i t) τ}
  obtain ⟨m,hm,cut,hmono,hfirst,hlast,hnot,_⟩ := finite_event_subdivision T
    (finite_generic_trajectory_ties b v hd _ isCompact_Icc a ha) hP (fun _ h => h.1)
  have hinside (i : Fin m) (t : ℝ) (ht : t ∈ Set.Ioo (cut i.castSucc) (cut i.succ)) :
      t ∈ Set.Icc 0 (P) := by
    constructor
    · rw [← hfirst]
      exact le_trans (hmono.monotone (Fin.zero_le _)) ht.1.le
    · rw [← hlast]
      exact le_trans ht.2.le (hmono.monotone (Fin.le_last _))
  have hex (i : Fin m) : ∃ σ, ∀ t ∈ Set.Ioo (cut i.castSucc) (cut i.succ),
      UniqueMinimum a (fun i => b i t) σ := by
    apply exists_trajectory_optimizer_on_tie_free_connected a b (fun i => continuous_iff_continuousAt.mpr (fun t => (hd i t).continuousAt)) isPreconnected_Ioo
      (Set.nonempty_Ioo.mpr (hmono i.castSucc_lt_succ))
    intro t ht σ τ hne he
    exact hnot i t ht ⟨hinside i t ht,σ,τ,hne,he⟩
  choose label hlabel using hex
  have hclosed (i : Fin m) := trajectory_optimizer_on_closed_cell a b (fun i => continuous_iff_continuousAt.mpr (fun t => (hd i t).continuousAt)) (label i)
    (hmono i.castSucc_lt_succ) (hlabel i)
  refine ⟨m,hm,cut,label,hmono,hfirst,hlast,hlabel,hclosed,?_⟩
  intro t ht σ hunique
  obtain ⟨i,hi⟩ := finite_subdivision_closed_cover hm cut hmono
    (by simpa only [hfirst,hlast] using ht)
  exact ⟨i,(uniqueMinimum_eq_of_score_max a (fun i => b i t) σ (label i)
    hunique (hclosed i t hi)).symm⟩

/-- A genuine generic change has positive old-to-new velocity score. -/
theorem generic_trajectory_transition_derivative_pos {n : ℕ} (a : Fin n → ℂ)
    (b v : Fin n → ℝ → ℂ) (hd : ∀ i t, HasDerivAt (b i) (v i t) t)
    (K : Set ℝ) (ha : GenericTrajectorySources b v K a)
    (σ τ : Equiv.Perm (Fin n)) (hne : σ ≠ τ) {u w : ℝ} (hu : u ∈ K) (huw : u < w)
    (heq : assignmentScore a (fun i => b i u) σ = assignmentScore a (fun i => b i u) τ)
    (hnew : ∀ t ∈ Set.Ioo u w, assignmentScore a (fun i => b i t) σ ≤
      assignmentScore a (fun i => b i t) τ) :
    0 < assignmentScore a (fun i => v i u) τ-assignmentScore a (fun i => v i u) σ := by
  have hn := generic_trajectory_pair_transverse b v K a ha u hu σ τ hne heq
  apply lt_of_le_of_ne _ hn.symm
  apply derivative_nonneg_of_right_nonneg huw
    ((assignmentScore_trajectory_hasDerivAt a b v hd τ u).sub
      (assignmentScore_trajectory_hasDerivAt a b v hd σ u))
    (sub_eq_zero.mpr heq.symm)
  intro t ht
  exact sub_nonneg.mpr (hnew t ht)

/-- A generic source list on a nonempty time set has distinct source labels. -/
theorem genericTrajectorySources_injective {n : ℕ} (a : Fin n → ℂ)
    (b v : Fin n → ℝ → ℂ) (K : Set ℝ) (hK : K.Nonempty)
    (ha : GenericTrajectorySources b v K a) : Function.Injective a := by
  intro i j he
  by_contra hij
  obtain ⟨t,ht⟩ := hK
  have hz (y : Fin n → ℂ) : assignmentScore a y (Equiv.refl _) =
      assignmentScore a y (Equiv.swap i j) := by
    have h := score_swap_difference a y i j hij
    rw [he,sub_self,inner_zero_left] at h
    exact sub_eq_zero.mp h
  have hne : Equiv.refl (Fin n) ≠ Equiv.swap i j := by
    intro h
    exact hij (Equiv.swap_eq_refl_iff.mp h.symm)
  have h := generic_trajectory_pair_transverse b v K a ha t ht _ _ hne (hz _)
  exact h (sub_eq_zero.mpr (hz _).symm)

end MonotoneMatching
