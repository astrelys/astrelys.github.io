import Mathlib.Analysis.Complex.Basic
import Mathlib.LinearAlgebra.Dual.Lemmas
import Mathlib.Tactic.Linarith

/-! Complex-linear projections separating real directions. -/
noncomputable section
namespace MonotoneMatching

/-- If every complex-linear projection pair is real-collinear, the two
functionals differ by a real scalar. -/
theorem real_multiple_of_all_pairings_collinear {E : Type*}
    [AddCommGroup E] [Module ℂ E] (L M : E →ₗ[ℂ] ℂ) (v : E) (hv : L v = 1)
    (h : ∀ x : E, ((starRingEnd ℂ) (L x) * M x).im = 0) :
    ∃ r : ℝ, ∀ x, M x = (r : ℂ) * L x := by
  have hm : (M v).im = 0 := by simpa [hv] using h v
  have hker : ∀ w : E, L w = 0 → M w = 0 := by
    intro w hw
    have h1 := h (v + w)
    have h2 := h (v + Complex.I • w)
    simp only [map_add, map_smul, smul_eq_mul, hv, hw, mul_zero, add_zero,
      map_one, one_mul, Complex.add_im, hm, zero_add] at h1 h2
    apply Complex.ext
    · simpa using h2
    · exact h1
  refine ⟨(M v).re, ?_⟩
  intro x
  have hk : L (x - L x • v) = 0 := by simp [hv]
  have hx := hker _ hk
  simp only [map_sub, map_smul, smul_eq_mul] at hx
  have he : M v = ((M v).re : ℂ) := Complex.ext rfl hm
  rw [he] at hx
  exact (sub_eq_zero.mp hx).trans (mul_comm _ _)

/-- Real-independent complex-valued linear forms can be separated by a source. -/
theorem exists_noncollinear_linear_projection {E : Type*}
    [AddCommGroup E] [Module ℂ E] (L M : E →ₗ[ℂ] ℂ) (hL : L ≠ 0)
    (hM : ¬∃ r : ℝ, ∀ x, M x = (r : ℂ) * L x) :
    ∃ x : E, ((starRingEnd ℂ) (L x) * M x).im ≠ 0 := by
  by_contra hn
  push Not at hn
  obtain ⟨v,hv⟩ : ∃ v, L v ≠ 0 := by
    by_contra h
    push Not at h
    exact hL (LinearMap.ext h)
  have hunit : L ((L v)⁻¹ • v) = 1 := by simp [hv]
  exact hM (real_multiple_of_all_pairings_collinear L M _ hunit hn)

open scoped BigOperators
/-- The finite complex pairing as a linear functional of its first argument. -/
def coordinatePairing {n : ℕ} (u : Fin n → ℂ) : (Fin n → ℂ) →ₗ[ℂ] ℂ where
  toFun c := ∑ i, c i * u i
  map_add' c d := by simp [add_mul, Finset.sum_add_distrib]
  map_smul' r c := by simp [mul_assoc, Finset.mul_sum]

theorem coordinatePairing_single {n : ℕ} (u : Fin n → ℂ) (i : Fin n) :
    coordinatePairing u (Pi.single i 1) = u i := by
  classical
  simp [coordinatePairing, Pi.single_apply]

theorem coordinatePairing_ne_zero {n : ℕ} (u : Fin n → ℂ) (hu : u ≠ 0) :
    coordinatePairing u ≠ 0 := by
  intro he
  apply hu
  funext i
  have h := congrArg (fun L : (Fin n → ℂ) →ₗ[ℂ] ℂ => L (Pi.single i 1)) he
  simpa only [coordinatePairing_single, LinearMap.zero_apply, Pi.zero_apply] using h

/-- A real scalar relation between all pairings is exactly a relation between
configuration differences, so no degeneracy assumption is hidden in the projection. -/
theorem coordinatePairing_real_dependence {n : ℕ} (u v : Fin n → ℂ) (r : ℝ)
    (h : ∀ c, coordinatePairing v c = (r : ℂ) * coordinatePairing u c) :
    v = r • u := by
  funext i
  have hi := h (Pi.single i 1)
  simpa only [coordinatePairing_single, Pi.smul_apply, Complex.real_smul] using hi

end MonotoneMatching
