import MonotoneMatching.RotationCells
import Mathlib.Analysis.Calculus.Deriv.Slope

/-! Transverse orientation and relabeling of actual optimal rotation events. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators Topology
open Filter

/-- A differentiable function nonnegative just to the right of a zero has
nonnegative rightward derivative there. -/
theorem derivative_nonneg_of_right_nonneg {f : ℝ → ℝ} {d u v : ℝ}
    (huv : u < v) (hd : HasDerivAt f d u) (hu : f u=0)
    (h : ∀ t ∈ Set.Ioo u v, 0 ≤ f t) : 0 ≤ d := by
  have ht := hd.tendsto_slope.mono_left (nhdsGT_le_nhdsNE u)
  apply ge_of_tendsto ht
  have hv : ∀ᶠ t in 𝓝[>] u, t < v :=
    (eventually_lt_nhds huv).filter_mono nhdsWithin_le_nhds
  filter_upwards [self_mem_nhdsWithin,hv] with t ht hv
  rw [slope_def_field,hu,sub_zero]
  exact div_nonneg (h t ⟨ht,hv⟩) (sub_nonneg.mpr (le_of_lt ht))

/-- At an actual generic tie, the new right-hand optimum has strictly positive
old-to-new score derivative. -/
theorem generic_transition_derivative_pos {n : ℕ} (a b : Fin n → ℂ)
    (ha : GenericRotationSources b a) (σ τ : Equiv.Perm (Fin n)) (hne : σ ≠ τ)
    {u v : ℝ} (huv : u < v)
    (heq : assignmentScore a (rotateClockwise u ∘ b) σ =
      assignmentScore a (rotateClockwise u ∘ b) τ)
    (hnew : ∀ t ∈ Set.Ioo u v, assignmentScore a (rotateClockwise t ∘ b) σ ≤
      assignmentScore a (rotateClockwise t ∘ b) τ) :
    0 < directionalScoreDerivative
      (complexAssignmentScore a b τ-complexAssignmentScore a b σ) u := by
  have hd := hasDerivAt_directionalScore
    (complexAssignmentScore a b τ-complexAssignmentScore a b σ) u
  have he : directionalScore (complexAssignmentScore a b τ-complexAssignmentScore a b σ) u=0 := by
    rw [directionalScore_sub]
    simpa only [assignmentScore_rotation_coefficient] using sub_eq_zero.mpr heq.symm
  have hn := directionalScore_transverse (sub_ne_zero.mpr (ha.1 τ σ hne.symm)) he
  apply lt_of_le_of_ne _ hn.symm
  apply derivative_nonneg_of_right_nonneg huv hd he
  intro t ht
  rw [directionalScore_sub]
  exact sub_nonneg.mpr (by simpa only [assignmentScore_rotation_coefficient] using hnew t ht)

/-- Rotation acts on each complex score coefficient by the same unit factor. -/
theorem complexAssignmentScore_rotation {n : ℕ} (a b : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (t : ℝ) :
    complexAssignmentScore a (rotateClockwise t ∘ b) σ =
      (⟨Real.cos t,-Real.sin t⟩ : ℂ)*complexAssignmentScore a b σ := by
  unfold complexAssignmentScore
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  simp only [Function.comp_def,rotateClockwise_eq_mul]
  ring

theorem directionalScoreDerivative_rotation_im (z : ℂ) (t : ℝ) :
    directionalScoreDerivative z t =
      ((⟨Real.cos t,-Real.sin t⟩ : ℂ)*z).im := by
  simp only [directionalScoreDerivative,Complex.mul_im]
  ring

theorem complexAssignmentScore_relabel_targets {n : ℕ} (a y : Fin n → ℂ)
    (σ τ : Equiv.Perm (Fin n)) :
    complexAssignmentScore a (y ∘ σ) τ = complexAssignmentScore a y (σ*τ) := rfl

/-- The time-u old-to-new derivative becomes the time-zero derivative after
rotating and relabeling the old optimum to identity. -/
theorem relative_transition_derivative {n : ℕ} (a b : Fin n → ℂ)
    (σ τ : Equiv.Perm (Fin n)) (u : ℝ) :
    directionalScoreDerivative
      (complexAssignmentScore a ((rotateClockwise u ∘ b) ∘ σ) (σ⁻¹*τ) -
        complexAssignmentScore a ((rotateClockwise u ∘ b) ∘ σ) (Equiv.refl _)) 0 =
      directionalScoreDerivative (complexAssignmentScore a b τ-complexAssignmentScore a b σ) u := by
  rw [complexAssignmentScore_relabel_targets,complexAssignmentScore_relabel_targets]
  change directionalScoreDerivative
    (complexAssignmentScore a (rotateClockwise u ∘ b) (σ*(σ⁻¹*τ)) -
      complexAssignmentScore a (rotateClockwise u ∘ b) (σ*1)) 0 = _
  rw [mul_inv_cancel_left,mul_one,complexAssignmentScore_rotation,
    complexAssignmentScore_rotation,← mul_sub,directionalScoreDerivative_rotation_im]
  simp only [Real.cos_zero,Real.sin_zero,neg_zero]
  have hunit : (⟨(1:ℝ),0⟩ : ℂ)=1 := rfl
  rw [hunit,one_mul,← directionalScoreDerivative_rotation_im]

/-- A local geometric charge theorem applies to actual generic optimizer
changes, with all two-optimum and orientation hypotheses derived here. -/
theorem actual_event_charge_of_local_geometry {n : ℕ} (a b : Fin n → ℂ)
    (ha : GenericRotationSources b a)
    (hgeometry : ∀ (A Y : Fin n → ℂ) (π : Equiv.Perm (Fin n)), π ≠ Equiv.refl _ →
      (∀ ρ, assignmentScore A Y ρ ≤ assignmentScore A Y (Equiv.refl _)) →
      assignmentScore A Y π = assignmentScore A Y (Equiv.refl _) →
      (∀ ρ, assignmentScore A Y ρ = assignmentScore A Y (Equiv.refl _) →
        ρ = Equiv.refl _ ∨ ρ = π) →
      0 < directionalScoreDerivative (complexAssignmentScore A Y π-
        complexAssignmentScore A Y (Equiv.refl _)) 0 →
      Real.pi ≤ identityPhase A (Y ∘ π)-identityPhase A Y)
    (σ τ : Equiv.Perm (Fin n)) (hne : σ ≠ τ) {u v : ℝ} (huv : u < v)
    (hold : ∀ ρ, assignmentScore a (rotateClockwise u ∘ b) ρ ≤
      assignmentScore a (rotateClockwise u ∘ b) σ)
    (hnew : ∀ t ∈ Set.Icc u v, ∀ ρ, assignmentScore a (rotateClockwise t ∘ b) ρ ≤
      assignmentScore a (rotateClockwise t ∘ b) τ) :
    Real.pi ≤ identityPhase a ((rotateClockwise u ∘ b) ∘ τ)-
      identityPhase a ((rotateClockwise u ∘ b) ∘ σ) := by
  let Y := (rotateClockwise u ∘ b) ∘ σ
  let π := σ⁻¹*τ
  have heq : assignmentScore a (rotateClockwise u ∘ b) σ =
      assignmentScore a (rotateClockwise u ∘ b) τ :=
    le_antisymm (hnew u (Set.left_mem_Icc.mpr huv.le) σ) (hold τ)
  have hπ : π ≠ Equiv.refl _ := by
    intro h
    have he : σ⁻¹*τ = 1 := h
    have hh := congrArg (fun ρ => σ*ρ) he
    have hτ : τ=σ := by simpa [← mul_assoc] using hh
    exact hne hτ.symm
  have hid : assignmentScore a Y (Equiv.refl _) = assignmentScore a (rotateClockwise u ∘ b) σ := by
    change assignmentScore a (rotateClockwise u ∘ b) (σ*1) = _
    rw [mul_one]
  have hπscore : assignmentScore a Y π = assignmentScore a (rotateClockwise u ∘ b) τ := by
    change assignmentScore a (rotateClockwise u ∘ b) (σ*(σ⁻¹*τ)) = _
    rw [mul_inv_cancel_left]
  have hmax : ∀ ρ, assignmentScore a Y ρ ≤ assignmentScore a Y (Equiv.refl _) := by
    intro ρ
    rw [hid]
    exact hold (σ*ρ)
  have htwo : ∀ ρ, assignmentScore a Y ρ = assignmentScore a Y (Equiv.refl _) →
      ρ=Equiv.refl _ ∨ ρ=π := by
    intro ρ h
    rw [hid] at h
    change assignmentScore a (rotateClockwise u ∘ b) (σ*ρ) =
      assignmentScore a (rotateClockwise u ∘ b) σ at h
    rcases generic_rotation_no_triple_tie a b ha u hne heq h.symm with h | h
    · left
      have he : σ*ρ=σ*1 := h.trans (mul_one σ).symm
      exact mul_left_cancel he
    · right
      have hh := congrArg (fun ν => σ⁻¹*ν) h
      simpa [← mul_assoc,π] using hh
  have hd : 0 < directionalScoreDerivative
      (complexAssignmentScore a Y π-complexAssignmentScore a Y (Equiv.refl _)) 0 := by
    rw [relative_transition_derivative]
    apply generic_transition_derivative_pos a b ha σ τ hne huv heq
    intro t ht
    exact hnew t ⟨ht.1.le,ht.2.le⟩ σ
  have h := hgeometry a Y π hπ hmax (by rw [hπscore,hid,heq]) htwo hd
  have he : Y ∘ π = (rotateClockwise u ∘ b) ∘ τ := by
    funext i
    simp [Y,π,Function.comp_def]
  rwa [he] at h

end MonotoneMatching
