import MonotoneMatching.Rotation
import Mathlib.Algebra.Order.Rearrangement
import Mathlib.Order.Preorder.Finite
import Mathlib.Data.Finset.Sort

/-! Strict rearrangement, the combinatorial engine for the sharpness witness. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

/-- Strictly increasing source coordinates and target projections have a unique
score-maximizing labeling. This is valid for every finite linear order. -/
theorem strict_rearrangement_unique {ι : Type*} [Fintype ι] [LinearOrder ι]
    (f g : ι → ℝ) (hf : StrictMono f) (hg : StrictMono g)
    (σ : Equiv.Perm ι) (hσ : σ ≠ Equiv.refl _) :
    (∑ i, f i * g (σ i)) < ∑ i, f i * g i := by
  have hfg : Monovary f g := fun _ _ h => hf.monotone (hg.lt_iff_lt.mp h).le
  apply hfg.sum_mul_comp_perm_lt_sum_mul_iff.mpr
  intro he
  have hgs : Monotone (g ∘ σ) := hf.trans_monovary he.symm
  have hmono : Monotone σ := fun i j hij => hg.le_iff_le.mp (hgs hij)
  have hstrict : StrictMono σ := hmono.strictMono_of_injective σ.injective
  apply hσ
  apply Equiv.ext
  intro i
  exact hstrict.apply_eq

/-- Relabeling a target projection into increasing order gives a strict maximizing
permutation, with all competing labeled permutations quantified. -/
theorem sorted_projection_unique {ι : Type*} [Fintype ι] [LinearOrder ι]
    (f g : ι → ℝ) (hf : StrictMono f) (σ : Equiv.Perm ι)
    (hg : StrictMono (g ∘ σ)) :
    ∀ τ : Equiv.Perm ι, τ ≠ σ → (∑ i, f i * g (τ i)) < ∑ i, f i * g (σ i) := by
  intro τ hτ
  have hn : τ.trans σ.symm ≠ Equiv.refl _ := by
    intro h
    apply hτ
    apply Equiv.ext
    intro i
    have hi := congrArg (fun e : Equiv.Perm ι => e i) h
    have hi' := congrArg σ hi
    simpa using hi'
  have h := strict_rearrangement_unique f (g ∘ σ) hf hg (τ.trans σ.symm) hn
  simpa [Function.comp_def] using h

/-- For real-axis source points, the score is the weighted real projection sum. -/
theorem real_axis_assignmentScore {n : ℕ} (f : Fin n → ℝ) (b : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) :
    assignmentScore (fun i => (f i : ℂ)) b σ = ∑ i, f i * (b (σ i)).re := by
  unfold assignmentScore
  apply Finset.sum_congr rfl
  intro i _
  simp [Complex.inner, mul_comm]

/-- The strict rearrangement lemma applies to the actual Euclidean matching objective. -/
theorem real_axis_sorted_uniqueMinimum {n : ℕ} (f : Fin n → ℝ) (b : Fin n → ℂ)
    (hf : StrictMono f) (σ : Equiv.Perm (Fin n))
    (hb : StrictMono (fun i => (b (σ i)).re)) :
    UniqueMinimum (fun i => (f i : ℂ)) b σ := by
  intro τ hτ
  apply (assignmentCost_lt_iff_score_gt _ _ _ _).mpr
  rw [real_axis_assignmentScore, real_axis_assignmentScore]
  exact sorted_projection_unique f (fun i => (b i).re) hf σ hb τ hτ

/-- Every injective finite real projection can be sorted by a permutation. -/
theorem exists_sorted_permutation {n : ℕ} (g : Fin n → ℝ)
    (hg : Function.Injective g) :
    ∃ σ : Equiv.Perm (Fin n), StrictMono (g ∘ σ) := by
  classical
  let s := Finset.univ.image g
  have hs : s.card = n := by
    rw [Finset.card_image_of_injective _ hg]
    exact Fintype.card_fin n
  let e : Fin n ≃ s := Equiv.ofBijective
    (fun i => ⟨g i, Finset.mem_image.mpr ⟨i, Finset.mem_univ _, rfl⟩⟩)
    ⟨fun i j h => hg (congrArg Subtype.val h), by
      rintro ⟨x, hx⟩
      obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hx
      exact ⟨i, rfl⟩⟩
  let σ : Equiv.Perm (Fin n) := (s.orderIsoOfFin hs).toEquiv.trans e.symm
  refine ⟨σ, ?_⟩
  have he (i : Fin n) : g (σ i) = s.orderEmbOfFin hs i := by
    have h := congrArg Subtype.val (e.apply_symm_apply ((s.orderIsoOfFin hs) i))
    exact h
  simpa only [Function.comp_def, he] using (s.orderEmbOfFin hs).strictMono

/-- Distinct target projections give an actual unique optimal matching for
strictly increasing real-axis sources; no sorted permutation is assumed. -/
theorem real_axis_exists_uniqueMinimum {n : ℕ} (f : Fin n → ℝ)
    (b : Fin n → ℂ) (hf : StrictMono f)
    (hb : Function.Injective (fun i => (b i).re)) :
    ∃ σ : Equiv.Perm (Fin n), UniqueMinimum (fun i => (f i : ℂ)) b σ := by
  obtain ⟨σ, hσ⟩ := exists_sorted_permutation (fun i => (b i).re) hb
  exact ⟨σ, real_axis_sorted_uniqueMinimum f b hf σ hσ⟩

/-- A sorted permutation records every strict comparison of the original data. -/
theorem sorted_permutation_comparison {n : ℕ} (g : Fin n → ℝ)
    (σ : Equiv.Perm (Fin n)) (h : StrictMono (g ∘ σ)) (p q : Fin n) :
    g p < g q ↔ σ.symm p < σ.symm q := by
  simpa only [Function.comp_apply, Equiv.apply_symm_apply] using
    (h.lt_iff_lt (a := σ.symm p) (b := σ.symm q))

end MonotoneMatching
