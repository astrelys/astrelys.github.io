import Mathlib.GroupTheory.Perm.Fin
import Mathlib.Data.Finset.Card

/-! Distinct labels on a nonconstant finite cycle are bounded by its changes. -/
noncomputable section
namespace MonotoneMatching

/-- Every label in a nonconstant cycle has an incoming edge on which the
label changes. This avoids an artificial extra cell at the chosen seam. -/
theorem cyclic_label_has_entry {ι κ : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (label : ι → κ)
    (hreach : ∀ i j, ∃ k : ℕ, (next^k) i = j)
    (hnonconstant : ∃ i j, label i ≠ label j)
    (j : ι) : ∃ i, label (next i) = label j ∧ label (next i) ≠ label i := by
  classical
  by_contra h
  push Not at h
  have hback (i : ι) (hi : label (next i) = label j) : label i = label j :=
    (h i hi).symm.trans hi
  have hind (k : ℕ) (i : ι) : label ((next^k) i) = label j → label i = label j := by
    induction k with
    | zero => simp
    | succ k ih =>
      intro he
      rw [pow_succ',Equiv.Perm.mul_apply] at he
      exact ih (hback _ he)
  have hall (i : ι) : label i = label j := by
    obtain ⟨k,hk⟩ := hreach i j
    exact hind k i (by rw [hk])
  obtain ⟨p,q,hpq⟩ := hnonconstant
  exact hpq ((hall p).trans (hall q).symm)

/-- The image-cardinality bound used after the real phase budget. -/
theorem cyclic_label_count_le_changes {ι κ : Type*} [Fintype ι] [DecidableEq κ]
    (next : Equiv.Perm ι) (label : ι → κ)
    (hreach : ∀ i j, ∃ k : ℕ, (next^k) i = j)
    (hnonconstant : ∃ i j, label i ≠ label j) :
    (Finset.univ.image label).card ≤
      (Finset.univ.filter (fun i => label (next i) ≠ label i)).card := by
  classical
  let E := Finset.univ.filter (fun i => label (next i) ≠ label i)
  have hsub : Finset.univ.image label ⊆ E.image (fun i => label (next i)) := by
    intro z hz
    obtain ⟨j,_,rfl⟩ := Finset.mem_image.mp hz
    obtain ⟨i,hi,he⟩ := cyclic_label_has_entry next label hreach hnonconstant j
    exact Finset.mem_image.mpr ⟨i,Finset.mem_filter.mpr ⟨Finset.mem_univ _,he⟩,hi⟩
  exact (Finset.card_le_card hsub).trans (Finset.card_image_le)

/-- The usual successor permutation reaches every cell of a nontrivial circle. -/
theorem finRotate_reaches_all {m : ℕ} (hm : 2 ≤ m) (i j : Fin m) :
    ∃ k : ℕ, (finRotate m ^ k) i = j := by
  have hmove (i : Fin m) : finRotate m i ≠ i := by
    apply Equiv.Perm.mem_support.mp
    rw [support_finRotate_of_le hm]
    exact Finset.mem_univ _
  exact ((isCycle_finRotate_of_le hm).sameCycle (hmove i) (hmove j)).exists_nat_pow_eq

end MonotoneMatching
