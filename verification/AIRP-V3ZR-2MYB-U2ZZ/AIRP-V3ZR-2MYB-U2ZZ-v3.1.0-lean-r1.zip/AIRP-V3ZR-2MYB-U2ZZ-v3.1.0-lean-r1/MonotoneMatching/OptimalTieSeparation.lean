import MonotoneMatching.CanonicalCount
noncomputable section
namespace MonotoneMatching
open Set Filter
open scoped Topology
set_option backward.isDefEq.respectTransparency.types false

theorem isOpen_time_uniqueMinimum {n : ℕ} (a : Fin n → ℂ) (b : Fin n → ℝ → ℂ)
    (hb : ∀ i,Continuous (b i)) (σ : Equiv.Perm (Fin n)) :
    IsOpen {t : ℝ | UniqueMinimum a (fun j => b j t) σ} := by
  classical
  simp only [UniqueMinimum,assignmentCost_lt_iff_score_gt,Set.ofPred_forall]
  apply isOpen_iInter_of_finite
  intro τ
  apply isOpen_iInter_of_finite
  intro _
  exact isOpen_lt (continuous_trajectory_score a b hb τ) (continuous_trajectory_score a b hb σ)

theorem uniqueMinimum_of_no_optimal_tie {n : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (t : ℝ) (h : ¬trajectoryOptimalTie a b t) :
    ∃ σ,UniqueMinimum a (fun j => b j t) σ := by
  obtain ⟨σ,hσ⟩ := exists_trajectory_score_maximizer a b t
  refine ⟨σ,?_⟩
  intro τ hτ
  apply (assignmentCost_lt_iff_score_gt _ _ _ _).mpr
  exact lt_of_le_of_ne (hσ τ) (fun he => h ⟨σ,τ,Ne.symm hτ,hσ,he⟩)

theorem uniqueMinimum_eq {n : ℕ} (a y : Fin n → ℂ) (σ τ : Equiv.Perm (Fin n))
    (hσ : UniqueMinimum a y σ) (hτ : UniqueMinimum a y τ) : σ=τ := by
  by_contra he
  exact (lt_asymm (hσ τ (Ne.symm he))) (hτ σ he)

/-- Absence of actual optimal ties suffices for constancy; suboptimal score
ties are allowed and are not counted as switching events. -/
theorem optimizer_constant_without_optimal_ties {n : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (hb : ∀ i,Continuous (b i)) (s : Set ℝ)
    (hs : IsPreconnected s) (hnt : ∀ t∈s,¬trajectoryOptimalTie a b t)
    (u : ℝ) (hu : u∈s) (σ : Equiv.Perm (Fin n))
    (hσ : UniqueMinimum a (fun j => b j u) σ) :
    ∀ t∈s,UniqueMinimum a (fun j => b j t) σ := by
  classical
  let U := {t : ℝ | UniqueMinimum a (fun j => b j t) σ}
  let V := {t : ℝ | ∃ τ : Equiv.Perm (Fin n),τ≠σ ∧ UniqueMinimum a (fun j => b j t) τ}
  have hoU : IsOpen U := isOpen_time_uniqueMinimum a b hb σ
  have hoV : IsOpen V := by
    dsimp [V]
    simp only [← exists_prop,Set.ofPred_exists]
    exact isOpen_iUnion fun τ => isOpen_iUnion fun _ => isOpen_time_uniqueMinimum a b hb τ
  have hd : Disjoint U V := by
    apply Set.disjoint_left.mpr
    rintro t ht ⟨τ,hτ,htτ⟩
    exact hτ (uniqueMinimum_eq a _ τ σ htτ ht)
  have hc : s ⊆ U∪V := by
    intro t ht
    obtain ⟨τ,hτ⟩ := uniqueMinimum_of_no_optimal_tie a b t (hnt t ht)
    by_cases he : τ=σ
    · subst τ
      exact Or.inl hτ
    · exact Or.inr ⟨τ,he,hτ⟩
  exact IsPreconnected.subset_left_of_subset_union hoU hoV hd hc ⟨u,hu,hσ⟩ hs

/-- Different strict optimizers at two sample times force a genuine optimal
tie between them. The conclusion concerns optimal ties, not arbitrary equal scores. -/
theorem optimal_tie_between_distinct_strict_samples {n : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (hb : ∀ i,Continuous (b i)) (u v : ℝ)
    (σ τ : Equiv.Perm (Fin n)) (hne : σ≠τ)
    (hσ : UniqueMinimum a (fun j => b j u) σ)
    (hτ : UniqueMinimum a (fun j => b j v) τ) :
    ∃ t∈uIcc u v,trajectoryOptimalTie a b t := by
  by_contra! hh
  have ht := optimizer_constant_without_optimal_ties a b hb (uIcc u v)
    isPreconnected_uIcc hh u left_mem_uIcc σ hσ v right_mem_uIcc
  exact hne (uniqueMinimum_eq a _ σ τ ht hτ)

end MonotoneMatching
