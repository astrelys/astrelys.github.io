import MonotoneMatching.ArgumentSubdivision

/-! Exact argument accounting for an anchored arc, a constant connector,
its negative arc, and a second constant connector. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval BigOperators

theorem argument_increment_constant (z : ℂ) (φ : C(I,ℝ))
    (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg z : Real.Angle)) : φ 1-φ 0=0 := by
  have h := argument_lift_increment_unique φ (fun _ : I => Complex.arg z) φ.continuous
    continuous_const hφ 0 1
  simpa only [sub_self] using h

theorem four_piece_anchored_increment (γ δ : I → ℂ) (hn : ∀ s, δ s≠0)
    (c₁ c₃ : ℂ)
    (h0 : ∀ s, γ (uniformArgumentSubparameter (m := 4) (by norm_num) 0 s)=δ s)
    (h1 : ∀ s, γ (uniformArgumentSubparameter (m := 4) (by norm_num) 1 s)=c₁)
    (h2 : ∀ s, γ (uniformArgumentSubparameter (m := 4) (by norm_num) 2 s)= -δ s)
    (h3 : ∀ s, γ (uniformArgumentSubparameter (m := 4) (by norm_num) 3 s)=c₃)
    (φ ψ : C(I,ℝ))
    (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg (γ s) : Real.Angle))
    (hψ : ∀ s, (ψ s : Real.Angle)=(Complex.arg (δ s) : Real.Angle)) :
    φ 1-φ 0=2*(ψ 1-ψ 0) := by
  let χ : Fin 4 → C(I,ℝ) := fun i => ⟨fun s => φ (uniformArgumentSubparameter (by norm_num) i s),
    φ.continuous.comp (continuous_uniformArgumentSubparameter (by norm_num) i)⟩
  have ha0 (s : I) : (χ 0 s : Real.Angle)=(Complex.arg (δ s) : Real.Angle) := by
    change (φ (uniformArgumentSubparameter _ _ s) : Real.Angle)=_
    rw [hφ,h0]
  have ha1 (s : I) : (χ 1 s : Real.Angle)=(Complex.arg c₁ : Real.Angle) := by
    change (φ (uniformArgumentSubparameter _ _ s) : Real.Angle)=_
    rw [hφ,h1]
  have ha2 (s : I) : (χ 2 s : Real.Angle)=(Complex.arg (-δ s) : Real.Angle) := by
    change (φ (uniformArgumentSubparameter _ _ s) : Real.Angle)=_
    rw [hφ,h2]
  have ha3 (s : I) : (χ 3 s : Real.Angle)=(Complex.arg c₃ : Real.Angle) := by
    change (φ (uniformArgumentSubparameter _ _ s) : Real.Angle)=_
    rw [hφ,h3]
  have hd0 := argument_lift_increment_unique (χ 0) ψ (χ 0).continuous ψ.continuous
    (fun s => (ha0 s).trans (hψ s).symm) 0 1
  have hd1 := argument_increment_constant c₁ (χ 1) ha1
  have hd2 := argument_increment_neg δ hn ψ (χ 2) hψ ha2
  have hd3 := argument_increment_constant c₃ (χ 3) ha3
  have hsum : (∑ i : Fin 4, (χ i 1-χ i 0))=φ 1-φ 0 := by
    have ht := subdivision_duration_sum (fun i => φ (uniformArgumentNode (m := 4) (by norm_num) i))
    simpa only [χ,ContinuousMap.coe_mk,uniformArgumentSubparameter_one,
      uniformArgumentSubparameter_zero,uniformArgumentNode_zero,uniformArgumentNode_last] using ht
  have he : (∑ i : Fin 4, (χ i 1-χ i 0)) =
      (χ 0 1-χ 0 0)+(χ 1 1-χ 1 0)+(χ 2 1-χ 2 0)+(χ 3 1-χ 3 0) := by
    simp [Fin.sum_univ_succ]
    ring
  rw [he] at hsum
  linarith

end MonotoneMatching
