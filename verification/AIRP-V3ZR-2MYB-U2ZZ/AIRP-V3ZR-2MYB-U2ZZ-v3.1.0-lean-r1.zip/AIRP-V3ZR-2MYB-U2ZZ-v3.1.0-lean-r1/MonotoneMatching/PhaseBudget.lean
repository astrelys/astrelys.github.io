import MonotoneMatching.SharpLowerBound

/-! Finite real-valued phase accounting around the rotation circle. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

/-- The sum of bridge jumps exactly cancels the sum of physical-cell changes.
This is a real equality, so it retains every multiple of two pi. -/
theorem cyclic_phase_balance {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (left right : ι → ℝ) :
    (∑ i, (left (next i)-right i)) = -(∑ i, (right i-left i)) := by
  simp only [Finset.sum_sub_distrib,Equiv.sum_comp]
  ring

/-- Exact phase transport on a finite cyclic subdivision gives the full
rotation budget, once the cell durations cover exactly one period. -/
theorem cyclic_rotation_phase_budget {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (left right duration : ι → ℝ) (N : ℕ)
    (hcell : ∀ i, right i-left i = -(N : ℝ)*duration i)
    (hperiod : ∑ i, duration i = 2*Real.pi) :
    (∑ i, (left (next i)-right i)) = 2*Real.pi*N := by
  rw [cyclic_phase_balance]
  simp_rw [hcell]
  rw [← Finset.mul_sum,hperiod]
  ring

/-- Each nonzero transition consumes at least pi of the exact budget.
The positive-charge premise is an explicit geometric obligation. -/
theorem positive_charge_count_bound {ι : Type*} [Fintype ι]
    (charge : ι → ℝ) (N : ℕ)
    (hcharge : ∀ i, charge i = 0 ∨ Real.pi ≤ charge i)
    (hbudget : ∑ i, charge i = 2*Real.pi*N) :
    (Finset.univ.filter (fun i => charge i ≠ 0)).card ≤ 2*N := by
  classical
  have he (i : ι) : (if charge i ≠ 0 then Real.pi else 0) ≤ charge i := by
    rcases hcharge i with h | h
    · simp [h]
    · have hn : charge i ≠ 0 := ne_of_gt (lt_of_lt_of_le Real.pi_pos h)
      simpa [hn] using h
  have hs := Finset.sum_le_sum (s := Finset.univ) (fun i _ => he i)
  rw [hbudget] at hs
  have hc : (∑ i, if charge i ≠ 0 then Real.pi else 0) =
      ((Finset.univ.filter (fun i => charge i ≠ 0)).card : ℝ)*Real.pi := by
    rw [← Finset.sum_filter,Finset.sum_const,nsmul_eq_mul]
  rw [hc] at hs
  have hr : ((Finset.univ.filter (fun i => charge i ≠ 0)).card : ℝ) ≤ 2*(N : ℝ) := by
    nlinarith [Real.pi_pos]
  exact_mod_cast hr

/-- The rotational degree is exactly the advertised quadratic event bound. -/
theorem rotational_charge_count_bound {ι : Type*} [Fintype ι]
    (charge : ι → ℝ) (n : ℕ)
    (hcharge : ∀ i, charge i = 0 ∨ Real.pi ≤ charge i)
    (hbudget : ∑ i, charge i = 2*Real.pi*(n.choose 2)) :
    (Finset.univ.filter (fun i => charge i ≠ 0)).card ≤ n*(n-1) := by
  have h := positive_charge_count_bound charge (n.choose 2) hcharge hbudget
  rwa [twice_choose_two] at h

end MonotoneMatching
