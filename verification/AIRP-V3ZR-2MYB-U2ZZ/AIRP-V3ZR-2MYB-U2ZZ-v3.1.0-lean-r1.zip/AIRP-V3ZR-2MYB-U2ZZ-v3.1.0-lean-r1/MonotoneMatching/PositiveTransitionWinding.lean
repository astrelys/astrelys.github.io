import MonotoneMatching.TransitionOrientationDichotomy
import MonotoneMatching.PolygonFluxSign
import MonotoneMatching.RotationFluxIdentity

/-! A positive rotational event derivative selects the positive orientation
of its genuine long transition polygon, using only finite flux identities. -/
noncomputable section
namespace MonotoneMatching
open scoped InnerProductSpace

theorem positive_transition_polygon_winding {ι : Type*} [Fintype ι] [DecidableEq ι] [Nonempty ι]
    (next : Equiv.Perm ι) (htrans : ∀ i j : ι, ∃ k : ℕ, (next^k) i=j)
    {n : ℕ} (a y : Fin n → ℂ) (hy : Function.Injective y)
    (σ : Equiv.Perm (Fin n)) (r c : Fin n → ℝ)
    (hbound : ∀ i j, inner ℝ (a i) (y j) ≤ r i+c j)
    (hexact : ∀ i j, r i+c j=inner ℝ (a i) (y j) ↔ j=i ∨ j=σ i)
    (e : ι → Fin n) (he : Function.Injective e) (hsucc : ∀ i, e (next i)=σ (e i))
    (hm : ∀ i, σ (e i)≠e i) (h2 : ∀ i, σ (σ (e i))≠e i)
    (hcover : ∀ i, σ i≠i → ∃ j, e j=i)
    (hD : 0 < directionalScoreDerivative (complexAssignmentScore a y σ-
      complexAssignmentScore a y (Equiv.refl _)) 0) :
    (∀ i q, q∈strictDualCell a r (e i) → 0<edgeSide (y (e i)) (y (e (next i))) q →
      polygonIndexPhase next (y∘e) q=2*Real.pi) ∧
    (∀ i q, q∈strictDualCell a r (e i) → edgeSide (y (e i)) (y (e (next i))) q<0 →
      polygonIndexPhase next (y∘e) q=0) ∧
    (∀ q, q∉polygonBoundary next (y∘e) → polygonIndexPhase next (y∘e) q=0 ∨
      polygonIndexPhase next (y∘e) q=2*Real.pi) := by
  obtain ⟨L,R,hgap,hdich,hL,hR,hvalues⟩ := transition_polygon_orientation_dichotomy
    next htrans a y hy σ r c hbound hexact e he hsucc hm h2
  rcases hdich with hp | hn
  · refine ⟨?_,?_,?_⟩
    · intro i q hq hs
      exact (hL i q hq hs).trans hp.1
    · intro i q hq hs
      exact (hR i q hq hs).trans hp.2
    · intro q hq
      rcases hvalues q hq with hz | hl | hr
      · exact Or.inl hz
      · exact Or.inr (hl.trans hp.1)
      · exact Or.inl (hr.trans hp.2)
  · have hphase (q : ℂ) (hq : q∉polygonBoundary next (y∘e)) : polygonIndexPhase next (y∘e) q≤0 := by
      rcases hvalues q hq with hz | hl | hr
      · exact hz.le
      · rw [hl,hn.1]
      · rw [hr,hn.2]
        linarith [Real.pi_pos]
    have hedge (i : ι) (t : ℝ) (ht : t∈Set.Ioo (0:ℝ) 1) :
        (1-t) • (y∘e) i+t • (y∘e) (next i)∈strictDualCell a r (e i) := by
      intro j hj
      simpa only [Function.comp_def,hsucc] using
        transition_edge_unique_row a y σ r c hbound hexact (e i) (h2 i) j hj ht.1 ht.2
    have hflux := polygon_rotational_flux_nonpos next (y∘e) a r e he hedge L R hgap hL hR hphase
    rw [rotation_event_derivative_cycle_flux next a y σ e he hsucc hcover] at hD
    exact ((not_lt_of_ge hflux) hD).elim

end MonotoneMatching
