import MonotoneMatching.CyclicPairSums

/-! A symmetric pair sum dominates its moved block when all fixed-column charges are nonnegative. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

theorem sum_injection_complement {α β : Type*} [Fintype α] [Fintype β] [DecidableEq α]
    (e : β → α) (he : Function.Injective e) (f : α → ℝ) :
    (∑ i, f i)=(∑ j, f (e j))+∑ i, if i∈Set.range e then 0 else f i := by
  classical
  have h := Fintype.sum_of_injective e he (fun j => f (e j))
    (fun i => if i∈Set.range e then f i else 0)
    (fun i hi => by simp only [hi,ite_false])
    (fun j => by simp)
  rw [h,← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  by_cases hi : i∈Set.range e <;> simp [hi]

theorem injected_pair_sum_lower_bound {α β : Type*} [Fintype α] [Fintype β] [DecidableEq α]
    (e : β → α) (he : Function.Injective e) (f : α → α → ℝ)
    (hsymm : ∀ i j, f i j=f j i)
    (hzero : ∀ i j, i∉Set.range e → j∉Set.range e → f i j=0)
    (hcross : ∀ j, j∉Set.range e → 0≤∑ i, f (e i) j) :
    (∑ i : β, ∑ j : β, f (e i) (e j))≤∑ i : α, ∑ j : α, f i j := by
  classical
  have hrow (i : α) := sum_injection_complement e he (f i)
  simp_rw [hrow,Finset.sum_add_distrib]
  have hc : 0≤∑ i : α, ∑ j : α, if j∈Set.range e then 0 else f i j := by
    rw [Finset.sum_comm]
    apply Finset.sum_nonneg
    intro j _
    by_cases hj : j∈Set.range e
    · simp [hj]
    · simp only [hj,ite_false]
      rw [sum_injection_complement e he (fun i => f i j)]
      have hz : (∑ i : α, if i∈Set.range e then 0 else f i j)=0 := by
        apply Finset.sum_eq_zero
        intro i _
        by_cases hi : i∈Set.range e
        · simp [hi]
        · simp [hi,hzero i j hi hj]
      rw [hz,add_zero]
      exact hcross j hj
  have hl : (∑ i : β, ∑ j : β, f (e i) (e j))≤∑ i : α, ∑ j : β, f i (e j) := by
    rw [sum_injection_complement e he (fun i => ∑ j : β, f i (e j))]
    apply le_add_of_nonneg_right
    apply Finset.sum_nonneg
    intro i _
    by_cases hi : i∈Set.range e
    · simp [hi]
    · simp only [hi,ite_false]
      simp_rw [hsymm i]
      exact hcross i hi
  exact le_trans hl (le_add_of_nonneg_right hc)

end MonotoneMatching
