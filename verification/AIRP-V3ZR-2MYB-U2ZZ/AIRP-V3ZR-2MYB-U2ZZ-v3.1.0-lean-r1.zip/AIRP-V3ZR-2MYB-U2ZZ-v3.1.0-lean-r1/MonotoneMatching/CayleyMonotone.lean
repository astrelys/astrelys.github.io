import Mathlib.Analysis.Complex.Basic
import Mathlib.Analysis.InnerProductSpace.Basic
import Mathlib.Topology.MetricSpace.Contracting
noncomputable section
namespace MonotoneMatching
open scoped InnerProductSpace
set_option backward.isDefEq.respectTransparency.types false

/-- A strict planar contraction has a globally defined inverse Cayley coordinate. -/
theorem exists_cayley_inverse (Z : ℂ → ℂ) (k : ℝ) (hk : 0 ≤ k) (hk1 : k < 1)
    (hZ : ∀ u v, ‖Z u-Z v‖ ≤ k*‖u-v‖) :
    ∃ U : ℂ → ℂ, (∀ x,U x+Z (U x)= (2:ℝ) • x) ∧
      (∀ x y, ‖U x-U y‖ ≤ (2/(1-k))*‖x-y‖) ∧
      (∀ u,U (((1/2):ℝ) • (u+Z u))=u) := by
  have hex (x : ℂ) : ∃ u : ℂ,u+Z u= (2:ℝ) • x := by
    have hc : ContractingWith ⟨k,hk⟩ (fun u : ℂ => (2:ℝ) • x-Z u) := by
      refine ⟨hk1,LipschitzWith.of_dist_le_mul ?_⟩
      intro u v
      simp only [dist_eq_norm,sub_sub_sub_cancel_left]
      change ‖Z v-Z u‖ ≤ k*‖u-v‖
      simpa only [norm_sub_rev] using hZ v u
    obtain ⟨u,hu,_⟩ := hc.exists_fixedPoint 0 (by simp)
    exact ⟨u,(sub_eq_iff_eq_add.mp hu).symm⟩
  choose U hU using hex
  have hdiff (x y : ℂ) : (U x-U y)+(Z (U x)-Z (U y))= (2:ℝ) • (x-y) := by
    rw [smul_sub]
    calc
      _ = (U x+Z (U x))-(U y+Z (U y)) := by abel
      _ = _ := by rw [hU,hU]
  refine ⟨U,hU,?_,?_⟩
  · intro x y
    have hn : ‖U x-U y‖ ≤ 2*‖x-y‖+‖Z (U x)-Z (U y)‖ := by
      calc
        _ = ‖(2:ℝ) • (x-y)-(Z (U x)-Z (U y))‖ := by
          rw [← hdiff]; congr 1; abel
        _ ≤ ‖(2:ℝ) • (x-y)‖+‖Z (U x)-Z (U y)‖ := norm_sub_le _ _
        _ = _ := by rw [norm_smul]; norm_num
    have hz := hZ (U x) (U y)
    rw [div_mul_eq_mul_div]
    apply (le_div_iff₀ (sub_pos.mpr hk1)).mpr
    nlinarith
  · intro u
    let x := ((1/2):ℝ) • (u+Z u)
    have he : U x+Z (U x)=u+Z u := by simpa [x,smul_smul] using hU x
    have hd : U x-u=Z u-Z (U x) := by linear_combination he
    have hn : ‖U x-u‖ ≤ k*‖U x-u‖ := by
      calc
        _ = ‖Z u-Z (U x)‖ := congrArg norm hd
        _ ≤ k*‖u-U x‖ := hZ u (U x)
        _ = _ := by rw [norm_sub_rev]
    have hz : ‖U x-u‖=0 := by nlinarith [norm_nonneg (U x-u)]
    exact sub_eq_zero.mp (norm_eq_zero.mp hz)

/-- The inverse Cayley field is globally monotone and Lipschitz. -/
theorem cayley_monotone_field (Z : ℂ → ℂ) (k : ℝ) (hk : 0 ≤ k) (hk1 : k < 1)
    (hZ : ∀ u v, ‖Z u-Z v‖ ≤ k*‖u-v‖) :
    ∃ F : ℂ → ℂ,
      (∀ x y,0 ≤ inner ℝ (x-y) (F x-F y)) ∧
      (∀ x y,‖F x-F y‖ ≤ (2/(1-k)+1)*‖x-y‖) ∧
      (∀ u,F (((1/2):ℝ) • (u+Z u))=((1/2):ℝ) • (u-Z u)) := by
  obtain ⟨U,hU,hLip,hInv⟩ := exists_cayley_inverse Z k hk hk1 hZ
  let F : ℂ → ℂ := fun x => U x-x
  have hsum (x y : ℂ) : (2:ℝ) • (x-y)=(U x-U y)+(Z (U x)-Z (U y)) := by
    rw [smul_sub,← hU x,← hU y]
    abel
  have hsub (x y : ℂ) : (2:ℝ) • (F x-F y)=(U x-U y)-(Z (U x)-Z (U y)) := by
    change (2:ℝ) • ((U x-x)-(U y-y))=_
    rw [show (U x-x)-(U y-y)=(U x-U y)-(x-y) by abel,smul_sub,hsum x y]
    module
  refine ⟨F,?_,?_,?_⟩
  · intro x y
    have hid : 4*inner ℝ (x-y) (F x-F y)=‖U x-U y‖^2-‖Z (U x)-Z (U y)‖^2 := by
      calc
        _ = inner ℝ ((2:ℝ) • (x-y)) ((2:ℝ) • (F x-F y)) := by
          simp only [real_inner_smul_left,real_inner_smul_right]; ring
        _ = _ := by
          rw [hsum,hsub,inner_sub_right,inner_add_left,inner_add_left]
          rw [real_inner_comm (Z (U x)-Z (U y)) (U x-U y)]
          simp only [real_inner_self_eq_norm_sq]
          ring
    have hz : ‖Z (U x)-Z (U y)‖ ≤ ‖U x-U y‖ :=
      (hZ _ _).trans (by nlinarith [norm_nonneg (U x-U y)])
    nlinarith [norm_nonneg (U x-U y),norm_nonneg (Z (U x)-Z (U y))]
  · intro x y
    calc
      ‖F x-F y‖ = ‖(U x-U y)-(x-y)‖ := by congr 1; dsimp [F]; abel
      _ ≤ ‖U x-U y‖+‖x-y‖ := norm_sub_le _ _
      _ ≤ (2/(1-k)+1)*‖x-y‖ := by linarith [hLip x y]
  · intro u
    change U (((1/2):ℝ) • (u+Z u))-((1/2):ℝ) • (u+Z u)=_
    rw [hInv]
    module

end MonotoneMatching
