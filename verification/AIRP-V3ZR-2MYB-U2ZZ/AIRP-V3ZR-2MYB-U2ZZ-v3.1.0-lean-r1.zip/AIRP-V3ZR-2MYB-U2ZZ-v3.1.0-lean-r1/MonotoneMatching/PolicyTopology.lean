import MonotoneMatching.BadSetBound
import Mathlib.Topology.LocallyConstant.Basic
noncomputable section
namespace MonotoneMatching
open Set Filter
open scoped Topology
set_option backward.isDefEq.respectTransparency.types false

/-- Periodicity transports local constancy, including across the chosen seam. -/
theorem policy_local_shift {κ : Type*} (f : ℝ → κ) (T t : ℝ)
    (hp : Function.Periodic f T) (h : ¬policyBad f t) : ¬policyBad f (t+T) := by
  have hh : ∀ᶠ u in 𝓝 t,f u=f t := not_not.mp h
  have ht : Tendsto (fun u : ℝ => u-T) (𝓝 (t+T)) (𝓝 t) := by
    have hc : Continuous (fun u : ℝ => u-T) := continuous_id.sub continuous_const
    have ht' : Tendsto (fun u : ℝ => u-T) (𝓝 (t+T)) (𝓝 ((t+T)-T)) := hc.continuousAt
    simpa only [add_sub_cancel_right] using ht'
  have he := ht.eventually hh
  apply not_not.mpr
  filter_upwards [he] with u hu
  rw [hp.sub_eq u] at hu
  rwa [hp t]

theorem policy_bad_periodic {κ : Type*} (f : ℝ → κ) (T t : ℝ)
    (hp : Function.Periodic f T) : policyBad f (t+T) ↔ policyBad f t := by
  change (¬∀ᶠ u in 𝓝 (t+T),f u=f (t+T)) ↔ (¬∀ᶠ u in 𝓝 t,f u=f t)
  apply not_congr
  constructor
  · intro h
    have hh := policy_local_shift f (-T) (t+T) hp.neg (not_not.mpr h)
    simp only [add_neg_cancel_right] at hh
    exact not_not.mp hh
  · intro h
    exact not_not.mp (policy_local_shift f T t hp (not_not.mpr h))

/-- A policy with no bad points on a connected region is constant there. -/
theorem policy_constant_on_connected {κ : Type*} (f : ℝ → κ) (s : Set ℝ)
    (hs : IsPreconnected s) (hgood : ∀ t∈s,¬policyBad f t)
    (u : ℝ) (hu : u∈s) : ∀ t∈s,f t=f u := by
  let g : s → κ := fun x => f x.val
  have hg : IsLocallyConstant g := by
    rw [IsLocallyConstant.iff_eventually_eq]
    intro x
    exact (continuous_subtype_val.continuousAt (x := x)).eventually (not_not.mp (hgood x.val x.property))
  have : PreconnectedSpace s := isPreconnected_iff_preconnectedSpace.mp hs
  intro t ht
  exact hg.apply_eq_of_preconnectedSpace ⟨t,ht⟩ ⟨u,hu⟩

/-- A finite bad set always leaves a good seam in a nonempty open interval. -/
theorem exists_good_policy_seam {κ : Type*} (f : ℝ → κ) {L U : ℝ} (hLU : L<U)
    (hf : {t | t∈Ioo L U ∧ policyBad f t}.Finite) :
    ∃ s∈Ioo L U,¬policyBad f s := by
  by_contra! hh
  have hfin : (Ioo L U).Finite := hf.subset (fun t ht => ⟨ht,hh t ht⟩)
  exact (Set.Ioo_infinite hLU) hfin

/-- Every canonical policy is periodic whenever the labeled targets are periodic. -/
theorem canonical_policy_periodic {n : ℕ} (a : Fin n → ℂ) (b : Fin n → ℝ → ℂ)
    (T : ℝ) (hp : ∀ i,Function.Periodic (b i) T) :
    Function.Periodic (fun t => canonicalPermutation a (fun j => b j t)) T := by
  intro t
  exact congrArg (canonicalPermutation a) (funext (fun j => hp j t))

end MonotoneMatching
