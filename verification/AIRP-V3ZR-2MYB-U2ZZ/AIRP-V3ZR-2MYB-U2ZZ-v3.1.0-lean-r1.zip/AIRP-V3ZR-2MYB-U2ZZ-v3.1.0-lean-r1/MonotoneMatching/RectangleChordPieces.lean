import MonotoneMatching.ChordRectangle
import MonotoneMatching.FourPieceArguments

/-! The chord rectangle traverses an anchored arc twice with constant connectors. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval

theorem chordRectangleParameter_piece (P ε : ℝ) (i : Fin 4) (s : I) :
    chordRectangleParameter P ε (uniformArgumentSubparameter (by norm_num) i s)=
      (1-(s:ℝ)) • chordRectangleVertices P ε i.castSucc+
        (s:ℝ) • chordRectangleVertices P ε i.succ := by
  dsimp only [chordRectangleParameter,uniformArgumentSubparameter]
  norm_num only [Nat.cast_ofNat]
  rw [show (4:ℝ)*((i.val+s)/4)=i.val+s by ring]
  exact polygonInterpolation_on_edge _ i s.property

theorem rectangle_chord_anchored_increment (γ : ℝ → ℂ) (P ε : ℝ)
    (hp : Function.Periodic γ P) (hε : 0<ε)
    (u : ℂ) (hloc : ∀ t∈Set.Icc (-ε) ε, γ t=γ 0+t • u)
    (hn : ∀ s : I, γ (ε+(P-2*ε)*(s:ℝ))-γ 0≠0)
    (φ ψ : C(I,ℝ))
    (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg
      (γ (chordRectangleParameter P ε s).im-γ (chordRectangleParameter P ε s).re) : Real.Angle))
    (hψ : ∀ s, (ψ s : Real.Angle)=(Complex.arg
      (γ (ε+(P-2*ε)*(s:ℝ))-γ 0) : Real.Angle)) :
    φ 1-φ 0=2*(ψ 1-ψ 0) := by
  apply four_piece_anchored_increment
    (fun s => γ (chordRectangleParameter P ε s).im-γ (chordRectangleParameter P ε s).re)
    (fun s => γ (ε+(P-2*ε)*(s:ℝ))-γ 0) hn (-ε • u) (ε • u) _ _ _ _ φ ψ hφ hψ
  · intro s
    rw [chordRectangleParameter_piece]
    norm_num [chordRectangleVertices,Complex.add_re,Complex.add_im,
      Complex.smul_re,Complex.smul_im,smul_eq_mul]
    rw [show (1-(s:ℝ))*ε+(s:ℝ)*(P-ε)=ε+(P-2*ε)*(s:ℝ) by ring]
  · intro s
    rw [chordRectangleParameter_piece]
    norm_num [chordRectangleVertices,Complex.add_re,Complex.add_im,
      Complex.smul_re,Complex.smul_im,smul_eq_mul]
    have he : (1-(s:ℝ))*(P-ε)+(s:ℝ)*P=(s:ℝ)*ε-ε+P := by ring
    rw [he,hp,hloc ((s:ℝ)*ε-ε) ⟨by nlinarith [s.property.1],by nlinarith [s.property.2]⟩,
      hloc ((s:ℝ)*ε) ⟨by nlinarith [s.property.1],by nlinarith [s.property.2]⟩]
    simp only [Complex.real_smul]
    push_cast
    ring
  · intro s
    rw [chordRectangleParameter_piece]
    norm_num [chordRectangleVertices,Complex.add_re,Complex.add_im,
      Complex.smul_re,Complex.smul_im,smul_eq_mul]
    have he : (1-(s:ℝ))*P+(s:ℝ)*P=0+P := by ring
    have hf : (1-(s:ℝ))*ε+(s:ℝ)*(P-ε)=ε+(P-2*ε)*(s:ℝ) := by ring
    rw [he,hf,hp]

  · intro s
    rw [chordRectangleParameter_piece]
    norm_num [chordRectangleVertices,Complex.add_re,Complex.add_im,
      Complex.smul_re,Complex.smul_im,smul_eq_mul]
    have he : (1-(s:ℝ))*P+(s:ℝ)*(P+ε)=(s:ℝ)*ε+P := by ring
    have hf : (1-(s:ℝ))*(P-ε)+(s:ℝ)*P=(s:ℝ)*ε-ε+P := by ring
    rw [he,hf,hp,hp,
      hloc ((s:ℝ)*ε) ⟨by nlinarith [s.property.1],by nlinarith [s.property.2]⟩,
      hloc ((s:ℝ)*ε-ε) ⟨by nlinarith [s.property.1],by nlinarith [s.property.2]⟩]
    simp only [Complex.real_smul]
    push_cast
    ring

end MonotoneMatching
