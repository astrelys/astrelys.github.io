import MonotoneMatching.GenericSources
import MonotoneMatching.GenericScoreWitness
import MonotoneMatching.Stability
import Mathlib.Topology.Baire.Lemmas

/-! Open dense source conditions for the rigid-rotation problem. -/
noncomputable section
namespace MonotoneMatching
open scoped Polynomial

theorem continuous_complexAssignmentScore_source {n : ℕ} (b : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) : Continuous (fun a => complexAssignmentScore a b σ) := by
  unfold complexAssignmentScore
  fun_prop

theorem continuous_scoreCoefficientDet_source {n : ℕ} (b : Fin n → ℂ)
    (σ τ ρ : Equiv.Perm (Fin n)) : Continuous (fun a => scoreCoefficientDet a b σ τ ρ) := by
  unfold scoreCoefficientDet
  exact Complex.continuous_im.comp (((continuous_complexAssignmentScore_source b τ).sub
    (continuous_complexAssignmentScore_source b σ)).star.mul
      ((continuous_complexAssignmentScore_source b ρ).sub
        (continuous_complexAssignmentScore_source b σ)))

theorem dense_distinct_score_coefficients {n : ℕ} (b : Fin n → ℂ)
    (hb : Function.Injective b) {σ τ : Equiv.Perm (Fin n)} (h : σ ≠ τ) :
    Dense {a | complexAssignmentScore a b σ ≠ complexAssignmentScore a b τ} := by
  obtain ⟨v,hv⟩ := exists_source_distinct_coefficients b hb h
  let f := fun a => Complex.normSq (complexAssignmentScore a b σ - complexAssignmentScore a b τ)
  have hfv : f v ≠ 0 := by
    exact fun he => (sub_ne_zero.mpr hv) (Complex.normSq_eq_zero.mp he)
  have hd := dense_nonzero_of_polynomial_lines f v hfv (fun a => ?_)
  · simpa only [f, ne_eq, Complex.normSq_eq_zero, sub_eq_zero] using hd
  · let u := complexAssignmentScore a b σ - complexAssignmentScore a b τ
    let w := complexAssignmentScore v b σ - complexAssignmentScore v b τ
    refine ⟨(Polynomial.C u.re * (1-Polynomial.X) + Polynomial.C w.re * Polynomial.X)^2 +
      (Polynomial.C u.im * (1-Polynomial.X) + Polynomial.C w.im * Polynomial.X)^2, ?_⟩
    intro t
    simp only [Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_sub,
      Polynomial.eval_pow, Polynomial.eval_C, Polynomial.eval_one, Polynomial.eval_X]
    dsimp [f, u, w]
    simp [complexAssignmentScore_source_combination, Complex.normSq_apply]
    ring

theorem dense_noncollinear_score_coefficients {n : ℕ} (b : Fin n → ℂ)
    (hb : Function.Injective b) {σ τ ρ : Equiv.Perm (Fin n)}
    (hστ : σ ≠ τ) (hσρ : σ ≠ ρ) (hτρ : τ ≠ ρ) :
    Dense {a | scoreCoefficientDet a b σ τ ρ ≠ 0} := by
  obtain ⟨v,hv⟩ := exists_source_noncollinear_coefficients b hb hστ hσρ hτρ
  apply dense_nonzero_of_polynomial_lines (fun a => scoreCoefficientDet a b σ τ ρ) v hv
  intro a
  let u := complexAssignmentScore a b τ - complexAssignmentScore a b σ
  let w := complexAssignmentScore v b τ - complexAssignmentScore v b σ
  let z := complexAssignmentScore a b ρ - complexAssignmentScore a b σ
  let q := complexAssignmentScore v b ρ - complexAssignmentScore v b σ
  refine ⟨(Polynomial.C u.re * (1-Polynomial.X) + Polynomial.C w.re * Polynomial.X) *
      (Polynomial.C z.im * (1-Polynomial.X) + Polynomial.C q.im * Polynomial.X) -
    (Polynomial.C u.im * (1-Polynomial.X) + Polynomial.C w.im * Polynomial.X) *
      (Polynomial.C z.re * (1-Polynomial.X) + Polynomial.C q.re * Polynomial.X), ?_⟩
  intro t
  simp only [Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_sub,
    Polynomial.eval_C, Polynomial.eval_one, Polynomial.eval_X]
  dsimp [scoreCoefficientDet, u, w, z, q]
  simp [complexAssignmentScore_source_combination]
  ring

/-- The rigid-rotation genericity conditions: distinct coefficient points and
no collinear triple of distinct coefficient points. -/
def GenericRotationSources {n : ℕ} (b a : Fin n → ℂ) : Prop :=
  (∀ σ τ : Equiv.Perm (Fin n), σ ≠ τ →
    complexAssignmentScore a b σ ≠ complexAssignmentScore a b τ) ∧
  (∀ σ τ ρ : Equiv.Perm (Fin n), σ ≠ τ → σ ≠ ρ → τ ≠ ρ →
    scoreCoefficientDet a b σ τ ρ ≠ 0)

/-- General-position sources form a dense set for every fixed distinct target list. -/
theorem dense_genericRotationSources {n : ℕ} (b : Fin n → ℂ)
    (hb : Function.Injective b) : Dense {a | GenericRotationSources b a} := by
  classical
  let P := fun σ τ : Equiv.Perm (Fin n) =>
    {a | σ ≠ τ → complexAssignmentScore a b σ ≠ complexAssignmentScore a b τ}
  let T := fun σ τ ρ : Equiv.Perm (Fin n) =>
    {a | σ ≠ τ → σ ≠ ρ → τ ≠ ρ → scoreCoefficientDet a b σ τ ρ ≠ 0}
  have po (σ τ) : IsOpen (P σ τ) := by
    by_cases h : σ = τ
    · simp [P,h]
    · simpa [P,h] using isOpen_ne_fun
        (continuous_complexAssignmentScore_source b σ) (continuous_complexAssignmentScore_source b τ)
  have pd (σ τ) : Dense (P σ τ) := by
    by_cases h : σ = τ
    · simp [P,h]
    · simpa [P,h] using dense_distinct_score_coefficients b hb h
  have topn (σ τ ρ) : IsOpen (T σ τ ρ) := by
    by_cases h1 : σ = τ
    · simp [T,h1]
    by_cases h2 : σ = ρ
    · simp [T,h2]
    by_cases h3 : τ = ρ
    · simp [T,h3]
    simpa [T,h1,h2,h3] using isOpen_ne_fun
      (continuous_scoreCoefficientDet_source b σ τ ρ) continuous_const
  have td (σ τ ρ) : Dense (T σ τ ρ) := by
    by_cases h1 : σ = τ
    · simp [T,h1]
    by_cases h2 : σ = ρ
    · simp [T,h2]
    by_cases h3 : τ = ρ
    · simp [T,h3]
    simpa [T,h1,h2,h3] using dense_noncollinear_score_coefficients b hb h1 h2 h3
  have fd {ι : Type} [Finite ι] {f : ι → Set (Fin n → ℂ)}
      (ho : ∀ i, IsOpen (f i)) (hd : ∀ i, Dense (f i)) : Dense (⋂ i, f i) := by
    rw [← Set.sInter_range]
    apply (Set.finite_range f).dense_sInter
    · rintro _ ⟨i,rfl⟩; exact ho i
    · rintro _ ⟨i,rfl⟩; exact hd i
  have hP : Dense (⋂ σ, ⋂ τ, P σ τ) :=
    fd (fun σ => isOpen_iInter_of_finite (po σ))
      (fun σ => fd (po σ) (pd σ))
  have hTO : IsOpen (⋂ σ, ⋂ τ, ⋂ ρ, T σ τ ρ) :=
    isOpen_iInter_of_finite (fun σ => isOpen_iInter_of_finite
      (fun τ => isOpen_iInter_of_finite (topn σ τ)))
  have hT : Dense (⋂ σ, ⋂ τ, ⋂ ρ, T σ τ ρ) :=
    fd (fun σ => isOpen_iInter_of_finite
      (fun τ => isOpen_iInter_of_finite (topn σ τ)))
      (fun σ => fd (fun τ => isOpen_iInter_of_finite (topn σ τ))
        (fun τ => fd (topn σ τ) (td σ τ)))
  convert hP.inter_of_isOpen_right hT hTO using 1
  ext a
  simp only [Set.mem_inter_iff, Set.mem_iInter, Set.mem_ofPred_eq, GenericRotationSources, P, T]

/-- Any upper bound proved for generic sources transfers to every source list,
without changing the target list or its rotation. -/
theorem rotation_upper_bound_from_generic_sources {n : ℕ} (b : Fin n → ℂ)
    (hb : Function.Injective b) (K : ℕ)
    (hbound : ∀ a : Fin n → ℂ, GenericRotationSources b a → rotationCount a b ≤ K)
    (a : Fin n → ℂ) : rotationCount a b ≤ K := by
  obtain ⟨U,ho,ha,hU⟩ := rotation_count_persists a b
  let γ : (Fin n → ℂ) → (Fin n → ℂ) × (Fin n → ℂ) := fun a' => (a',b)
  have hc : Continuous γ := continuous_id.prodMk continuous_const
  have hne : (γ ⁻¹' U).Nonempty := ⟨a,ha⟩
  obtain ⟨a',hgen,hin⟩ := (dense_genericRotationSources b hb).exists_mem_open (ho.preimage hc) hne
  exact (hU (γ a') hin).trans (hbound a' hgen)

end MonotoneMatching
