import MonotoneMatching.OptimalCells
import MonotoneMatching.FiniteSubdivision
import MonotoneMatching.PhaseIntervals

/-! A genuine finite subdivision carrying all rotational optimizers. -/
noncomputable section
namespace MonotoneMatching

/-- The closed cells of a finite increasing subdivision cover its full span. -/
theorem finite_subdivision_closed_cover {m : ℕ} (hm : 0 < m)
    (cut : Fin (m+1) → ℝ) (hmono : StrictMono cut)
    {t : ℝ} (ht : t ∈ Set.Icc (cut 0) (cut (Fin.last m))) :
    ∃ i : Fin m, t ∈ Set.Icc (cut i.castSucc) (cut i.succ) := by
  classical
  by_cases he : t = cut (Fin.last m)
  · let i : Fin m := ⟨m-1,by omega⟩
    have hi : i.succ = Fin.last m := Fin.ext (by dsimp [i]; omega)
    exact ⟨i,by rw [he,← hi]; exact ⟨(hmono i.castSucc_lt_succ).le,le_rfl⟩⟩
  · have htlast : t < cut (Fin.last m) := lt_of_le_of_ne ht.2 he
    let S := Finset.univ.filter (fun i => t < cut i)
    have hS : S.Nonempty := ⟨Fin.last m,by simp [S,htlast]⟩
    let k := S.min' hS
    have hk : t < cut k := (Finset.mem_filter.mp (Finset.min'_mem S hS)).2
    have hkpos : 0 < k.val := by
      by_contra h
      have hk0 : k=0 := Fin.ext (by change k.val=0; omega)
      rw [hk0] at hk
      exact (not_lt_of_ge ht.1) hk
    let i : Fin m := ⟨k.val-1,by have := k.isLt; omega⟩
    have hi : i.succ=k := Fin.ext (by dsimp [i]; omega)
    refine ⟨i,?_,by rw [hi]; exact hk.le⟩
    by_contra h
    have hiS : i.castSucc ∈ S := Finset.mem_filter.mpr ⟨Finset.mem_univ _,lt_of_not_ge h⟩
    have hki := Finset.min'_le S _ hiS
    change k.val ≤ i.val at hki
    dsimp [i] at hki
    omega

/-- A unique optimizer equals any weak optimizer at the same angle. -/
theorem uniqueMinimum_eq_of_score_max {n : ℕ} (a b : Fin n → ℂ)
    (σ τ : Equiv.Perm (Fin n)) (hσ : UniqueMinimum a b σ)
    (hτ : ∀ ρ, assignmentScore a b ρ ≤ assignmentScore a b τ) : σ=τ := by
  by_contra h
  have hh := (assignmentCost_lt_iff_score_gt _ _ _ _).mp (hσ τ (fun he => h he.symm))
  exact (not_lt_of_ge (hτ σ)) hh

/-- Generic rotating scores admit actual constant-label open cells with weak
optimality at every endpoint. Every optimizer is represented in the labels. -/
theorem exists_generic_rotation_cells {n : ℕ} (a b : Fin n → ℂ)
    (ha : GenericRotationSources b a) :
    ∃ m : ℕ, 0 < m ∧ ∃ cut : Fin (m+1) → ℝ, ∃ label : Fin m → Equiv.Perm (Fin n),
      StrictMono cut ∧ cut 0=0 ∧ cut (Fin.last m)=2*Real.pi ∧
      (∀ i, ∀ t ∈ Set.Ioo (cut i.castSucc) (cut i.succ),
        UniqueMinimum a (rotateClockwise t ∘ b) (label i)) ∧
      (∀ i, ∀ t ∈ Set.Icc (cut i.castSucc) (cut i.succ), ∀ τ,
        assignmentScore a (rotateClockwise t ∘ b) τ ≤
          assignmentScore a (rotateClockwise t ∘ b) (label i)) ∧
      (∀ σ ∈ rotationOptimizers a b, ∃ i, label i=σ) := by
  classical
  let T : Set ℝ := {t | t ∈ Set.Icc 0 (2*Real.pi) ∧
    ∃ σ τ : Equiv.Perm (Fin n), σ ≠ τ ∧
      assignmentScore a (rotateClockwise t ∘ b) σ = assignmentScore a (rotateClockwise t ∘ b) τ}
  obtain ⟨m,hm,cut,hmono,hfirst,hlast,hnot,_⟩ := finite_event_subdivision T
    (finite_generic_rotation_ties a b ha) Real.two_pi_pos (fun _ h => h.1)
  have hinside (i : Fin m) (t : ℝ) (ht : t ∈ Set.Ioo (cut i.castSucc) (cut i.succ)) :
      t ∈ Set.Icc 0 (2*Real.pi) := by
    constructor
    · rw [← hfirst]
      exact le_trans (hmono.monotone (Fin.zero_le _)) ht.1.le
    · rw [← hlast]
      exact le_trans ht.2.le (hmono.monotone (Fin.le_last _))
  have hex (i : Fin m) : ∃ σ, ∀ t ∈ Set.Ioo (cut i.castSucc) (cut i.succ),
      UniqueMinimum a (rotateClockwise t ∘ b) σ := by
    apply exists_unique_optimizer_on_tie_free_connected a b isPreconnected_Ioo
      (Set.nonempty_Ioo.mpr (hmono i.castSucc_lt_succ))
    intro t ht σ τ hne he
    exact hnot i t ht ⟨hinside i t ht,σ,τ,hne,he⟩
  choose label hlabel using hex
  have hclosed (i : Fin m) := rotation_optimizer_on_closed_cell a b (label i)
    (hmono i.castSucc_lt_succ) (hlabel i)
  refine ⟨m,hm,cut,label,hmono,hfirst,hlast,hlabel,hclosed,?_⟩
  intro σ hσ
  obtain ⟨t,ht,hunique⟩ := (mem_rotationOptimizers_iff_one_period a b σ).mp hσ
  obtain ⟨i,hi⟩ := finite_subdivision_closed_cover hm cut hmono
    (by simpa only [hfirst,hlast] using (show t ∈ Set.Icc 0 (2*Real.pi) from ⟨ht.1,ht.2.le⟩))
  exact ⟨i,(uniqueMinimum_eq_of_score_max a (rotateClockwise t ∘ b) σ (label i)
    hunique (hclosed i t hi)).symm⟩

end MonotoneMatching
