import MonotoneMatching.PolygonPhase
import Mathlib.Analysis.Convex.Topology
import Mathlib.Tactic.Module

/-! The real winding phase of a polygon about a point off its boundary. -/
noncomputable section
namespace MonotoneMatching

def polygonBoundary {ι : Type*} (next : Equiv.Perm ι) (v : ι → ℂ) : Set ℂ :=
  ⋃ i, segment ℝ (v i) (v (next i))

def polygonIndexPhase {ι : Type*} [Fintype ι] (next : Equiv.Perm ι) (v : ι → ℂ) (q : ℂ) : ℝ :=
  polygonPhase next (fun i => v i-q)

theorem isCompact_complex_segment (z w : ℂ) : IsCompact (segment ℝ z w) := by
  rw [segment_eq_image]
  exact isCompact_Icc.image (by fun_prop)

theorem isCompact_polygonBoundary {ι : Type*} [Finite ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) : IsCompact (polygonBoundary next v) :=
  isCompact_iUnion (fun i => isCompact_complex_segment (v i) (v (next i)))

theorem polygon_vertex_ne_of_not_mem_boundary {ι : Type*}
    (next : Equiv.Perm ι) (v : ι → ℂ) {q : ℂ} (hq : q ∉ polygonBoundary next v) (i : ι) :
    v i-q ≠ 0 := by
  intro h
  apply hq
  rw [← sub_eq_zero.mp h]
  exact Set.mem_iUnion.mpr ⟨i,left_mem_segment ℝ _ _⟩

theorem polygon_relative_segment_ne_zero {ι : Type*}
    (next : Equiv.Perm ι) (v : ι → ℂ) {q : ℂ} (hq : q ∉ polygonBoundary next v)
    (i : ι) {t : ℝ} (ht : t ∈ Set.Icc (0:ℝ) 1) :
    (1-t) • (v i-q)+t • (v (next i)-q) ≠ 0 := by
  intro h
  have he : (1-t) • v i+t • v (next i)=q := by
    have hh : (1-t) • (v i-q)+t • (v (next i)-q)=
        ((1-t) • v i+t • v (next i))-q := by module
    rw [hh] at h
    exact sub_eq_zero.mp h
  apply hq
  refine Set.mem_iUnion.mpr ⟨i,?_⟩
  rw [← he]
  simpa only [AffineMap.lineMap_apply_module] using lineMap_mem_segment ℝ (v i) (v (next i)) ht

theorem polygonIndexPhase_integer {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) {q : ℂ} (hq : q ∉ polygonBoundary next v) :
    ∃ k : ℤ, polygonIndexPhase next v q=k*(2*Real.pi) :=
  polygonPhase_integer next (fun i => v i-q) (polygon_vertex_ne_of_not_mem_boundary next v hq)

theorem continuousOn_polygonIndexPhase {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) :
    ContinuousOn (polygonIndexPhase next v) (polygonBoundary next v)ᶜ := by
  apply continuousOn_polygonPhase next (fun q i => v i-q)
  · intro i; exact (continuous_const.sub continuous_id).continuousOn
  · intro q hq i
    exact polygon_vertex_ne_of_not_mem_boundary next v hq i
  · intro q hq i t ht0 ht1
    exact polygon_relative_segment_ne_zero next v hq i ⟨ht0.le,ht1.le⟩

/-- The index is constant on every connected region avoiding the boundary. -/
theorem polygonIndexPhase_eq_on_connected {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) {s : Set ℂ} (hs : IsPreconnected s)
    (havoid : s ⊆ (polygonBoundary next v)ᶜ) {p q : ℂ} (hp : p ∈ s) (hq : q ∈ s) :
    polygonIndexPhase next v p=polygonIndexPhase next v q := by
  apply polygonPhase_homotopy_invariant next (fun q i => v i-q) hs _ _ _ hp hq
  · intro i; exact (continuous_const.sub continuous_id).continuousOn
  · intro x hx i
    exact polygon_vertex_ne_of_not_mem_boundary next v (havoid hx) i
  · intro x hx i t ht0 ht1
    exact polygon_relative_segment_ne_zero next v (havoid hx) i ⟨ht0.le,ht1.le⟩

/-- Every off-boundary point has a ball on which the exact real index is
constant. The radius follows from compactness of the finite boundary. -/
theorem polygonIndexPhase_locally_constant {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) {q : ℂ} (hq : q ∉ polygonBoundary next v) :
    ∃ ε : ℝ, 0<ε ∧ ∀ p ∈ Metric.ball q ε,
      polygonIndexPhase next v p=polygonIndexPhase next v q := by
  have ho : IsOpen (polygonBoundary next v)ᶜ := (isCompact_polygonBoundary next v).isClosed.isOpen_compl
  obtain ⟨ε,hε,hball⟩ := Metric.isOpen_iff.mp ho q hq
  refine ⟨ε,hε,?_⟩
  intro p hp
  exact polygonIndexPhase_eq_on_connected next v (convex_ball q ε).isPreconnected
    hball hp (Metric.mem_ball_self hε)

/-- A point strictly to the left of all vertices has zero winding phase. -/
theorem polygonIndexPhase_zero_left {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (q : ℂ) (h : ∀ i, q.re < (v i).re) :
    polygonIndexPhase next v q=0 := by
  apply polygonPhase_zero_of_re_pos
  intro i
  exact sub_pos.mpr (h i)

end MonotoneMatching
