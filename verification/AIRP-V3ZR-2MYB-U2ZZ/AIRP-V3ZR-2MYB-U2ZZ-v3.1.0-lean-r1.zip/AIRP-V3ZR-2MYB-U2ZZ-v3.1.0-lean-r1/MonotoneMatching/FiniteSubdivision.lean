import MonotoneMatching.FiniteRotationTies
import Mathlib.Data.Finset.Sort

/-! A finite set of event times gives an ordered closed-interval subdivision. -/
noncomputable section
namespace MonotoneMatching

/-- Insert the endpoints and sort all events. Each open subinterval contains
no event, and every non-event point belongs to one such interval. -/
theorem finite_event_subdivision (T : Set ℝ) (hT : T.Finite)
    {u v : ℝ} (huv : u < v) (hbound : T ⊆ Set.Icc u v) :
    ∃ m : ℕ, 0 < m ∧ ∃ cut : Fin (m+1) → ℝ,
      StrictMono cut ∧ cut 0 = u ∧ cut (Fin.last m) = v ∧
      (∀ i : Fin m, ∀ t ∈ Set.Ioo (cut i.castSucc) (cut i.succ), t ∉ T) ∧
      (∀ t ∈ Set.Ioo u v, t ∉ T → ∃ i : Fin m,
        t ∈ Set.Ioo (cut i.castSucc) (cut i.succ)) := by
  classical
  let C := insert u (insert v hT.toFinset)
  have huC : u ∈ C := Finset.mem_insert_self _ _
  have hvC : v ∈ C := Finset.mem_insert_of_mem (Finset.mem_insert_self _ _)
  have hC : ∀ t ∈ C, t ∈ Set.Icc u v := by
    intro t ht
    rcases Finset.mem_insert.mp ht with rfl | ht
    · exact ⟨le_rfl,huv.le⟩
    rcases Finset.mem_insert.mp ht with rfl | ht
    · exact ⟨huv.le,le_rfl⟩
    exact hbound (hT.mem_toFinset.mp ht)
  have hcpos : 0 < C.card := Finset.card_pos.mpr ⟨u,huC⟩
  obtain ⟨m,hm⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hcpos)
  let e := C.orderIsoOfFin hm
  let cut : Fin (m+1) → ℝ := fun i => (e i).val
  have hmono : StrictMono cut := (C.orderEmbOfFin hm).strictMono
  have hmem (i : Fin (m+1)) : cut i ∈ C := (e i).property
  have hsurj (t : ℝ) (ht : t ∈ C) : ∃ i, cut i=t := by
    obtain ⟨i,hi⟩ := e.surjective ⟨t,ht⟩
    exact ⟨i,congrArg Subtype.val hi⟩
  have hfirst : cut 0 = u := by
    obtain ⟨i,hi⟩ := hsurj u huC
    apply le_antisymm
    · rw [← hi]; exact hmono.monotone (Fin.zero_le i)
    · exact (hC _ (hmem 0)).1
  have hlast : cut (Fin.last m) = v := by
    obtain ⟨i,hi⟩ := hsurj v hvC
    apply le_antisymm
    · exact (hC _ (hmem _)).2
    · rw [← hi]; exact hmono.monotone (Fin.le_last i)
  have hmpos : 0 < m := by
    by_contra h
    have hm0 : m=0 := by omega
    subst m
    have hi : (Fin.last 0 : Fin 1) = 0 := rfl
    rw [hi,hfirst] at hlast
    exact (ne_of_lt huv) hlast
  refine ⟨m,hmpos,cut,hmono,hfirst,hlast,?_,?_⟩
  · intro i t ht htin
    have htC : t ∈ C := Finset.mem_insert_of_mem
      (Finset.mem_insert_of_mem (hT.mem_toFinset.mpr htin))
    obtain ⟨j,hj⟩ := hsurj t htC
    rw [← hj] at ht
    have hlo := hmono.lt_iff_lt.mp ht.1
    have hhi := hmono.lt_iff_lt.mp ht.2
    change i.val < j.val at hlo
    change j.val < i.val+1 at hhi
    omega
  · intro t ht htn
    have hnC : t ∉ C := by
      intro h
      rcases Finset.mem_insert.mp h with he | h
      · exact (ne_of_gt ht.1) he
      rcases Finset.mem_insert.mp h with he | h
      · exact (ne_of_lt ht.2) he
      exact htn (hT.mem_toFinset.mp h)
    let S := Finset.univ.filter (fun i : Fin (m+1) => t < cut i)
    have hS : S.Nonempty := ⟨Fin.last m,by simp [S,hlast,ht.2]⟩
    let k := S.min' hS
    have hk : k ∈ S := Finset.min'_mem S hS
    have htlt : t < cut k := (Finset.mem_filter.mp hk).2
    have hkpos : 0 < k.val := by
      by_contra h
      have he : k=0 := Fin.ext (by change k.val=0; omega)
      rw [he,hfirst] at htlt
      exact (not_lt_of_gt ht.1) htlt
    let i : Fin m := ⟨k.val-1,by have := k.isLt; omega⟩
    have he : i.succ = k := Fin.ext (by dsimp [i]; omega)
    have hl : cut i.castSucc < t := by
      apply lt_of_le_of_ne
      · by_contra h
        have hiS : i.castSucc ∈ S := Finset.mem_filter.mpr ⟨Finset.mem_univ _,lt_of_not_ge h⟩
        have hki := Finset.min'_le S _ hiS
        change k.val ≤ i.val at hki
        dsimp [i] at hki
        omega
      · intro heq
        exact hnC (heq ▸ hmem i.castSucc)
    exact ⟨i,hl,by rwa [he]⟩

end MonotoneMatching
