import MonotoneMatching.LongCycleCharge

/-! The complete sharp rotational count theorem, aligned with
geometry.tex:469-475 (thm:rotation), manuscript version 3.1.0.
All local geometric obligations are discharged by proved dependencies. -/
noncomputable section
namespace MonotoneMatching

/-- Full main theorem: universal bound, sharpness for every n, open noncollinear
sharpness for n at least three, and the one-label case. -/
theorem sharp_rotational_count : sharpRotationalCountStatement :=
  sharpRotationalCountStatement_of_long_cycle_charge (fun n _ => positiveLongCycleCharge n)

/-- The universal upper bound includes repeated source or target labels. -/
theorem rotational_count_upper_bound {n : ℕ} (hn : 2≤n) (a b : Fin n → ℂ) :
    rotationCount a b≤n*(n-1) := sharp_rotational_count.1 n hn a b

/-- The explicit binary-power construction attains the upper bound. -/
theorem rotational_count_explicit_sharpness {n : ℕ} (hn : 2≤n) :
    rotationCount (fun i : Fin n => (i.val:ℂ)) (fun i => sharpTarget i.val)=n*(n-1) :=
  le_antisymm (rotational_count_upper_bound hn _ _) (sharp_rotationCount_lower_bound n)

/-- Sharpness persists on a nonempty open set of pairs of noncollinear lists. -/
theorem rotational_count_open_noncollinear_sharpness {n : ℕ} (hn : 3≤n) :
    ∃ U : Set ((Fin n → ℂ)×(Fin n → ℂ)), IsOpen U ∧ U.Nonempty ∧
      ∀ p∈U, NoncollinearList p.1 ∧ NoncollinearList p.2 ∧ rotationCount p.1 p.2=n*(n-1) :=
  sharp_rotational_count.2.2.1 n hn

end MonotoneMatching
