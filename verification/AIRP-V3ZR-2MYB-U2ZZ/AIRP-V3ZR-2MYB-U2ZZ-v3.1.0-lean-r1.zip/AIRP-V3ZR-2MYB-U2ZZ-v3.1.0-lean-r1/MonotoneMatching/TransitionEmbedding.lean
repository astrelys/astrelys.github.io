import MonotoneMatching.PairPhase
import Mathlib.Tactic.Module

/-! Injectivity of the complete polygonal boundary at a long optimal transition. -/
noncomputable section
namespace MonotoneMatching

/-- A nondegenerate affine segment has a unique real parameter. -/
theorem affine_segment_parameter_injective {z w : ℂ} (hzw : z ≠ w) {s t : ℝ}
    (h : (1-s) • z+s • w = (1-t) • z+t • w) : s=t := by
  have he : (s-t) • (w-z)=0 := by
    calc
      _ = ((1-s) • z+s • w)-((1-t) • z+t • w) := by module
      _ = 0 := sub_eq_zero.mpr h
  rcases smul_eq_zero.mp he with hs | hz
  · exact sub_eq_zero.mp hs
  · exact (hzw (sub_eq_zero.mp hz).symm).elim

/-- The half-open edge parameterization is injective over all moved edges.
Thus open-edge separation also handles vertices and adjacent-edge endpoints. -/
theorem transition_boundary_injective {n : ℕ} (a y : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (hσ : σ.IsCycle) (hlen : 3 ≤ σ.support.card)
    (hy : Function.Injective y) (r c : Fin n → ℝ)
    (hbound : ∀ i j, inner ℝ (a i) (y j) ≤ r i+c j)
    (hexact : ∀ i j, r i+c j=inner ℝ (a i) (y j) ↔ j=i ∨ j=σ i)
    {i j : Fin n} (hi : σ i ≠ i) (hj : σ j ≠ j)
    {s t : ℝ} (hs : s ∈ Set.Ico (0:ℝ) 1) (ht : t ∈ Set.Ico (0:ℝ) 1)
    (he : (1-s) • y i+s • y (σ i) = (1-t) • y j+t • y (σ j)) :
    i=j ∧ s=t := by
  have h2i := long_cycle_no_two_step σ hσ hlen hi
  have h2j := long_cycle_no_two_step σ hσ hlen hj
  have hij : i=j := by
    by_cases hs0 : s=0
    · rw [hs0] at he
      simp only [sub_zero,one_smul,zero_smul,add_zero] at he
      by_cases ht0 : t=0
      · rw [ht0] at he
        simp only [sub_zero,one_smul,zero_smul,add_zero] at he
        exact hy he
      · exact (target_not_on_transition_open_edge a y σ r c hbound hexact j h2j i
          (lt_of_le_of_ne ht.1 (Ne.symm ht0)) ht.2 he).elim
    · have hsp : 0<s := lt_of_le_of_ne hs.1 (Ne.symm hs0)
      by_cases ht0 : t=0
      · rw [ht0] at he
        simp only [sub_zero,one_smul,zero_smul,add_zero] at he
        exact (target_not_on_transition_open_edge a y σ r c hbound hexact i h2i j
          hsp hs.2 he.symm).elim
      · by_contra hne
        exact transition_open_edges_disjoint a y σ r c hbound hexact h2i h2j hne
          hsp hs.2 (lt_of_le_of_ne ht.1 (Ne.symm ht0)) ht.2 he
  refine ⟨hij,?_⟩
  subst j
  exact affine_segment_parameter_injective (hy.ne hi.symm) he

/-- Full simple-boundary geometry is derived directly from the genuine
long-cycle optimality hypotheses. -/
theorem two_optima_long_boundary_embedding {n : ℕ} (a y : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (hne : σ ≠ Equiv.refl _) (hlen : 3 ≤ σ.support.card)
    (hmax : ∀ τ, assignmentScore a y τ ≤ assignmentScore a y (Equiv.refl _))
    (heq : assignmentScore a y σ = assignmentScore a y (Equiv.refl _))
    (htwo : ∀ τ, assignmentScore a y τ = assignmentScore a y (Equiv.refl _) →
      τ=Equiv.refl _ ∨ τ=σ) :
    ∀ i j : Fin n, σ i ≠ i → σ j ≠ j → ∀ s t : ℝ,
      s ∈ Set.Ico (0:ℝ) 1 → t ∈ Set.Ico (0:ℝ) 1 →
      (1-s) • y i+s • y (σ i) = (1-t) • y j+t • y (σ j) → i=j ∧ s=t := by
  have hcycle := two_optima_identity_isCycle a y σ hne hmax heq htwo
  have hpair := long_tie_strictPairMonotone a y σ hlen hmax htwo
  have hy := strictPairMonotone_injective_right a y hpair
  obtain ⟨r,c,hb,he⟩ := exists_exact_dual_support
    (fun i j => inner ℝ (a i) (y j)) σ hmax heq htwo
  intro i j hi hj s t hs ht h
  exact transition_boundary_injective a y σ hcycle hlen hy r c hb he hi hj hs ht h

end MonotoneMatching
