import MonotoneMatching.FiniteMonotoneInterpolation
import MonotoneMatching.MonotoneSmoothing
import Mathlib.Analysis.SpecificLimits.Basic
noncomputable section
namespace MonotoneMatching
open scoped BigOperators InnerProductSpace
set_option backward.isDefEq.respectTransparency.types false

/-- Any prescribed finite weakly monotone planar data can be approximated arbitrarily
closely by a smooth globally monotone field, with no time-coherence assumption. -/
theorem finite_smooth_monotone_approximation {ι : Type*} [Fintype ι]
    (x G : ι → ℂ) (hx : Function.Injective x)
    (hmono : ∀ i j,0 ≤ inner ℝ (x i-x j) (G i-G j))
    (ε : ℝ) (hε : 0 < ε) :
    ∃ F : ℂ → ℂ, ContDiff ℝ (⊤ : ℕ∞) F ∧
      (∀ p q,0 ≤ inner ℝ (p-q) (F p-F q)) ∧
      (∀ i,‖F (x i)-G i‖ ≤ ε) := by
  classical
  let B := ∑ i,‖x i‖
  have hB : 0 ≤ B := Finset.sum_nonneg (fun i _ => norm_nonneg (x i))
  have hBi (i : ι) : ‖x i‖ ≤ B := Finset.single_le_sum
    (fun j _ => norm_nonneg (x j)) (Finset.mem_univ i)
  let δ := ε/(2*(B+1))
  have hδ : 0 < δ := by dsimp [δ]; positivity
  obtain ⟨H,L,hL,hHi,hHm,hHL⟩ := finite_weak_monotone_global_regularization x G hx hmono δ hδ
  obtain ⟨F,hFs,hFm,hFa⟩ := exists_smooth_monotone_approximation H L hL hHL hHm (ε/2) (by positivity)
  refine ⟨F,hFs,hFm,?_⟩
  intro i
  have hb : δ*‖x i‖ ≤ ε/2 := by
    calc
      δ*‖x i‖ ≤ δ*(B+1) := mul_le_mul_of_nonneg_left (by linarith [hBi i]) hδ.le
      _ = ε/2 := by dsimp [δ]; field_simp
  calc
    ‖F (x i)-G i‖ ≤ ‖F (x i)-H (x i)‖+‖H (x i)-G i‖ := norm_sub_le_norm_sub_add_norm_sub _ _ _
    _ ≤ ε/2+ε/2 := add_le_add (hFa (x i)) (by simpa [hHi,norm_smul,Real.norm_eq_abs,abs_of_pos hδ] using hb)
    _ = ε := by ring

/-- Sequence form of the manuscript's finite monotone interpolation lemma. -/
theorem finite_smooth_monotone_approximation_sequence {ι : Type*} [Fintype ι]
    (x G : ι → ℂ) (hx : Function.Injective x)
    (hmono : ∀ i j,0 ≤ inner ℝ (x i-x j) (G i-G j)) :
    ∃ F : ℕ → ℂ → ℂ, (∀ k, ContDiff ℝ (⊤ : ℕ∞) (F k)) ∧
      (∀ k p q,0 ≤ inner ℝ (p-q) (F k p-F k q)) ∧
      (∀ i, Filter.Tendsto (fun k => F k (x i)) Filter.atTop (nhds (G i))) := by
  choose F hFs hFm hFa using (fun k : ℕ =>
    finite_smooth_monotone_approximation x G hx hmono (1/((k:ℝ)+1)) (by positivity))
  refine ⟨F,hFs,hFm,?_⟩
  intro i
  apply tendsto_iff_norm_sub_tendsto_zero.mpr
  exact squeeze_zero (fun k => norm_nonneg _) (fun k => hFa k i)
    tendsto_one_div_add_atTop_nhds_zero_nat

/-- Complete finite smooth monotone interpolation, including positive semidefinite
symmetric Jacobians expressed by their quadratic forms. -/
theorem finite_smooth_monotone_interpolation {ι : Type*} [Fintype ι]
    (x G : ι → ℂ) (hx : Function.Injective x)
    (hmono : ∀ i j,0 ≤ inner ℝ (x i-x j) (G i-G j)) :
    ∃ F : ℕ → ℂ → ℂ, (∀ k, ContDiff ℝ (⊤ : ℕ∞) (F k)) ∧
      (∀ k p q,0 ≤ inner ℝ (p-q) (F k p-F k q)) ∧
      (∀ k p v,0 ≤ inner ℝ v (fderiv ℝ (F k) p v)) ∧
      (∀ i, Filter.Tendsto (fun k => F k (x i)) Filter.atTop (nhds (G i))) := by
  obtain ⟨F,hFs,hFm,hFl⟩ := finite_smooth_monotone_approximation_sequence x G hx hmono
  refine ⟨F,hFs,hFm,?_,hFl⟩
  intro k p v
  exact monotone_field_derivative_nonnegative (F k) (hFm k) p (fderiv ℝ (F k) p)
    (((hFs k).differentiable (by norm_num)) p).hasFDerivAt v

end MonotoneMatching
