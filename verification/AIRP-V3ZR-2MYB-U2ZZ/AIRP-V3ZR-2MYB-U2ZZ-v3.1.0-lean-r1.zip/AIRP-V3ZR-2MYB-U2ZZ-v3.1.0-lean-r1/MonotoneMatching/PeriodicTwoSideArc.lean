import MonotoneMatching.ArcClosureParameter
import MonotoneMatching.TwoSideArc
import MonotoneMatching.PeriodicArgumentHomotopy

/-! Two complete displaced boundary increments equal the doubled anchored arc increment. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval

theorem periodic_two_side_anchored_increment (γ : ℝ → ℂ) (hc : Continuous γ)
    (P ε η : ℝ) (hp : Function.Periodic γ P) (hε : 0<ε) (hη : η≠0)
    (u : ℂ) (hloc : ∀ t∈Set.Icc (-ε) ε, γ t=γ 0+t • u)
    (hn : ∀ t s : I, γ (ε+(P-2*ε)*(s:ℝ))-γ 0-(t:ℝ) • (η • (Complex.I*u))≠0 ∧
      γ (ε+(P-2*ε)*(s:ℝ))-γ 0+(t:ℝ) • (η • (Complex.I*u))≠0)
    (hgn : ∀ t, γ t-γ 0-η • (Complex.I*u)≠0 ∧ γ t-γ 0+η • (Complex.I*u)≠0)
    (φ ψ χ : C(I,ℝ))
    (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg (γ (P*(s:ℝ))-γ 0-η • (Complex.I*u)) : Real.Angle))
    (hψ : ∀ s, (ψ s : Real.Angle)=(Complex.arg (γ (P*(s:ℝ))-γ 0+η • (Complex.I*u)) : Real.Angle))
    (hχ : ∀ s, (χ s : Real.Angle)=(Complex.arg (γ (ε+(P-2*ε)*(s:ℝ))-γ 0) : Real.Angle)) :
    (φ 1-φ 0)+(ψ 1-ψ 0)=2*(χ 1-χ 0) := by
  let a := arcClosureParameter P ε
  have ha : Continuous a := continuous_arcClosureParameter P ε
  have hend : a 1=a 0+P := by dsimp [a]; rw [arcClosureParameter_zero,arcClosureParameter_one]; ring
  let γp := fun t => γ t-γ 0-η • (Complex.I*u)
  let γm := fun t => γ t-γ 0+η • (Complex.I*u)
  have hcp : Continuous γp := by dsimp [γp]; fun_prop
  have hcm : Continuous γm := by dsimp [γm]; fun_prop
  have hpp : Function.Periodic γp P := fun t => by dsimp [γp]; rw [hp]
  have hpm : Function.Periodic γm P := fun t => by dsimp [γm]; rw [hp]
  obtain ⟨Φ,hΦ,_⟩ := exists_continuous_argument_lift (γp∘a) (hcp.comp ha) (fun s => (hgn (a s)).1)
  obtain ⟨Ψ,hΨ,_⟩ := exists_continuous_argument_lift (γm∘a) (hcm.comp ha) (fun s => (hgn (a s)).2)
  have hep := periodic_argument_increment_reparam γp hcp P hpp (fun t => (hgn t).1) a ha hend φ Φ hφ hΦ
  have hem := periodic_argument_increment_reparam γm hcm P hpm (fun t => (hgn t).2) a ha hend ψ Ψ hψ hΨ
  rw [hep,hem]
  apply two_side_anchored_increment (fun s => γ (a s)-γ 0)
    (fun s => γ (ε+(P-2*ε)*(s:ℝ))-γ 0) (by fun_prop) (ε • u) (η • (Complex.I*u)) (u*u)
    _ _ hn _ _ (fun s => hgn (a s)) Φ Ψ χ hΦ hΨ hχ
  · simp only [show ((0:I):ℝ)=0 from rfl,mul_zero,add_zero]
    rw [hloc ε ⟨by linarith,le_rfl⟩]
    abel
  · simp only [show ((1:I):ℝ)=1 from rfl,mul_one]
    rw [show ε+(P-2*ε)= -ε+P by ring,hp,hloc (-ε) ⟨le_rfl,by linarith⟩]
    module
  · intro s
    rw [show a (uniformArgumentSubparameter (m := 2) (by norm_num) 0 s)=
      ε+(P-2*ε)*(s:ℝ) from arcClosureParameter_long P ε s]
  · intro s
    rw [show a (uniformArgumentSubparameter (m := 2) (by norm_num) 1 s)=
      (-ε+2*ε*(s:ℝ))+P from arcClosureParameter_short P ε s,hp,
      hloc (-ε+2*ε*(s:ℝ)) ⟨by nlinarith [s.property.1],by nlinarith [s.property.2]⟩]
    simp only [add_sub_cancel_left,normal_connector_product_arg u _ η hη]

end MonotoneMatching
