import MonotoneMatching.FiniteFlux

/-! A monotone finite list of crossing slopes extends by any common upper bound. -/
noncomputable section
namespace MonotoneMatching

theorem monotone_lastCases_upper {m : ℕ} (g : Fin m → ℝ) (hg : Monotone g)
    (M : ℝ) (hM : ∀ i, g i≤M) : Monotone (Fin.lastCases M g) := by
  let G : Fin (m+1) → ℝ := Fin.lastCases M g
  have hb (i : Fin (m+1)) : G i≤M := by
    refine Fin.lastCases ?_ (fun j => ?_) i
    · simp [G]
    · simpa [G] using hM j
  change Monotone G
  intro i j hij
  by_cases hj : j=Fin.last m
  · rw [hj]
    simpa [G] using hb i
  · have hjm : j.val<m := by
      have hn : j.val≠m := fun h => hj (Fin.ext h)
      have hl := j.isLt
      omega
    have him : i.val<m := lt_of_le_of_lt hij hjm
    let i' : Fin m := ⟨i.val,him⟩
    let j' : Fin m := ⟨j.val,hjm⟩
    have hi' : i=i'.castSucc := by apply Fin.ext; rfl
    have hj' : j=j'.castSucc := by apply Fin.ext; rfl
    rw [hi',hj']
    simpa [G] using hg (show i'≤j' from hij)

end MonotoneMatching
