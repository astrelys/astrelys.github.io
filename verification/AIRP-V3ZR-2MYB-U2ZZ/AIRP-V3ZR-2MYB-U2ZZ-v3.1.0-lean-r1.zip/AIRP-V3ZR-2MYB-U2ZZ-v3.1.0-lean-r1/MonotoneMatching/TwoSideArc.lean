import MonotoneMatching.AnchoredProduct

/-! Exact addition of the winding increments on opposite sides of a straight edge. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval

theorem two_side_anchored_increment (γ δ : I → ℂ) (hc : Continuous δ)
    (z w c : ℂ) (hδ0 : δ 0=z) (hδ1 : δ 1= -z)
    (hn : ∀ t s : I, δ s-(t:ℝ) • w≠0 ∧ δ s+(t:ℝ) • w≠0)
    (hγ : ∀ s, γ (uniformArgumentSubparameter (m := 2) (by norm_num) 0 s)=δ s)
    (hs : ∀ s, (Complex.arg
      ((γ (uniformArgumentSubparameter (m := 2) (by norm_num) 1 s)-w)*
       (γ (uniformArgumentSubparameter (m := 2) (by norm_num) 1 s)+w)) : Real.Angle)=
       (Complex.arg c : Real.Angle))
    (hgn : ∀ s, γ s-w≠0 ∧ γ s+w≠0)
    (φ ψ χ : C(I,ℝ))
    (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg (γ s-w) : Real.Angle))
    (hψ : ∀ s, (ψ s : Real.Angle)=(Complex.arg (γ s+w) : Real.Angle))
    (hχ : ∀ s, (χ s : Real.Angle)=(Complex.arg (δ s) : Real.Angle)) :
    (φ 1-φ 0)+(ψ 1-ψ 0)=2*(χ 1-χ 0) := by
  let Φ : C(I,ℝ) := ⟨fun s => φ s+ψ s,φ.continuous.add ψ.continuous⟩
  let A : Fin 2 → C(I,ℝ) := fun i => ⟨fun s => Φ (uniformArgumentSubparameter (by norm_num) i s),
    Φ.continuous.comp (continuous_uniformArgumentSubparameter (by norm_num) i)⟩
  have hΦ (s : I) : (Φ s : Real.Angle)=(Complex.arg ((γ s-w)*(γ s+w)) : Real.Angle) := by
    simp only [Φ,ContinuousMap.coe_mk,Real.Angle.coe_add,hφ,hψ,
      Complex.arg_mul_coe_angle (hgn s).1 (hgn s).2]
  have ha (s : I) : (A 0 s : Real.Angle)=(Complex.arg ((δ s-w)*(δ s+w)) : Real.Angle) := by
    change (Φ (uniformArgumentSubparameter _ _ s) : Real.Angle)=_
    rw [hΦ,hγ]
  have hb (s : I) : (A 1 s : Real.Angle)=(Complex.arg c : Real.Angle) := by
    change (Φ (uniformArgumentSubparameter _ _ s) : Real.Angle)=_
    rw [hΦ,hs]
  have hA := anchored_product_increment δ hc z w hδ0 hδ1 hn χ (A 0) hχ ha
  have hB := argument_increment_constant c (A 1) hb
  have hsum := argument_increment_two_pieces Φ
  change Φ 1-Φ 0=(A 0 1-A 0 0)+(A 1 1-A 1 0) at hsum
  rw [hA,hB] at hsum
  dsimp only [Φ,ContinuousMap.coe_mk] at hsum
  linarith

theorem normal_connector_product_arg (u : ℂ) (t η : ℝ) (hη : η≠0) :
    Complex.arg ((t • u-η • (Complex.I*u))*(t • u+η • (Complex.I*u)))=
      Complex.arg (u*u) := by
  have he : (t • u-η • (Complex.I*u))*(t • u+η • (Complex.I*u))=
      ((t*t+η*η:ℝ):ℂ)*(u*u) := by
    simp only [Complex.real_smul,Complex.ofReal_add,Complex.ofReal_mul]
    calc
      _ = ((t:ℂ)*(t:ℂ)-(η:ℂ)*(η:ℂ)*(Complex.I*Complex.I))*(u*u) := by ring
      _ = _ := by rw [Complex.I_mul_I]; ring
  rw [he]
  exact Complex.arg_real_mul _ (by nlinarith [sq_pos_of_ne_zero hη,sq_nonneg t])

end MonotoneMatching
