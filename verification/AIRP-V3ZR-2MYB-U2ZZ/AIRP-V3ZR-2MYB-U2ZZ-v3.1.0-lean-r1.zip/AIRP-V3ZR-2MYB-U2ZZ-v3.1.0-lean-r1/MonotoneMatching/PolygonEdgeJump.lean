import MonotoneMatching.PolygonIndex
import MonotoneMatching.EdgeCrossingPhase

/-! The exact winding jump across an isolated interior point of a polygon edge. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators Topology
open Filter

def edgeCrossPoint (z w : ℂ) (r ε : ℝ) : ℂ :=
  z+(r:ℂ)*(w-z)+(ε:ℂ)*Complex.I*(w-z)

theorem continuous_edgeCrossPoint (z w : ℂ) (r : ℝ) : Continuous (edgeCrossPoint z w r) := by
  unfold edgeCrossPoint
  fun_prop

theorem edgeCrossPoint_ratio (z w : ℂ) (hzw : z ≠ w) (r ε : ℝ) :
    (w-edgeCrossPoint z w r ε)/(z-edgeCrossPoint z w r ε)=edgeCrossRatio r ε := by
  have he : w-z ≠ 0 := sub_ne_zero.mpr hzw.symm
  unfold edgeCrossPoint edgeCrossRatio
  simp only [Complex.mk_eq_add_mul_I]
  push_cast
  rw [show w-(z+(r:ℂ)*(w-z)+(ε:ℂ)*Complex.I*(w-z)) =
      (1-(r:ℂ)+ -(ε:ℂ)*Complex.I)*(w-z) by ring,
    show z-(z+(r:ℂ)*(w-z)+(ε:ℂ)*Complex.I*(w-z)) =
      (-(r:ℂ)+ -(ε:ℂ)*Complex.I)*(w-z) by ring,
    mul_div_mul_right _ _ he]

/-- A real phase constrained to the two-pi lattice and converging to two pi
is eventually exactly two pi. -/
theorem integral_phase_eventually_two_pi {X : Type*} {L : Filter X} (f : X → ℝ)
    (hint : ∀ᶠ x in L, ∃ k : ℤ, f x=k*(2*Real.pi))
    (hlim : Tendsto f L (𝓝 (2*Real.pi))) : ∀ᶠ x in L, f x=2*Real.pi := by
  have hb := hlim.eventually (Ioo_mem_nhds (by linarith [Real.pi_pos] : Real.pi < 2*Real.pi)
    (by linarith [Real.pi_pos] : 2*Real.pi < 3*Real.pi))
  filter_upwards [hint,hb] with x hx hb
  obtain ⟨k,hk⟩ := hx
  have hk0 : (0:ℝ)<(k:ℝ) := by rw [hk] at hb; nlinarith [Real.pi_pos]
  have hk2 : (k:ℝ)<2 := by rw [hk] at hb; nlinarith [Real.pi_pos]
  have hk0' : (0:ℤ)<k := by exact_mod_cast hk0
  have hk2' : k<(2:ℤ) := by exact_mod_cast hk2
  have he : k=1 := by omega
  simpa [he] using hk

/-- The endpoint ratio avoids the argument cut whenever the viewed point
is off the corresponding closed edge. -/
theorem segment_relative_ratio_mem_slitPlane (z w q : ℂ) (hq : q ∉ segment ℝ z w) :
    (w-q)/(z-q) ∈ Complex.slitPlane := by
  have hz : z-q ≠ 0 := by intro h; exact hq (sub_eq_zero.mp h ▸ left_mem_segment ℝ z w)
  have hw : w-q ≠ 0 := by intro h; exact hq (sub_eq_zero.mp h ▸ right_mem_segment ℝ z w)
  apply ratio_mem_slitPlane_of_segment_nonzero hz hw
  intro t ht0 ht1 h
  have he : (1-t) • z+t • w=q := by
    have hh : (1-t) • (z-q)+t • (w-q)=((1-t) • z+t • w)-q := by module
    rw [hh] at h
    exact sub_eq_zero.mp h
  apply hq
  rw [← he]
  simpa only [AffineMap.lineMap_apply_module] using lineMap_mem_segment ℝ z w ⟨ht0.le,ht1.le⟩

def polygonRemainderPhase {ι : Type*} [Fintype ι] [DecidableEq ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (i : ι) (q : ℂ) : ℝ :=
  ∑ j ∈ Finset.univ.erase i, Complex.arg ((v (next j)-q)/(v j-q))

theorem polygonIndexPhase_eq_edge_add_remainder {ι : Type*} [Fintype ι] [DecidableEq ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (i : ι) (q : ℂ) :
    polygonIndexPhase next v q =
      Complex.arg ((v (next i)-q)/(v i-q))+polygonRemainderPhase next v i q := by
  exact (Finset.add_sum_erase _ _ (Finset.mem_univ i)).symm

theorem continuousAt_polygonRemainderPhase {ι : Type*} [Fintype ι] [DecidableEq ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (i : ι) (q : ℂ)
    (hother : ∀ j, j ≠ i → q ∉ segment ℝ (v j) (v (next j))) :
    ContinuousAt (polygonRemainderPhase next v i) q := by
  apply tendsto_finsetSum
  intro j hj
  have hq := hother j (Finset.mem_erase.mp hj).1
  have hz : v j-q ≠ 0 := by intro h; exact hq (sub_eq_zero.mp h ▸ left_mem_segment ℝ _ _)
  apply ContinuousAt.comp (f := fun q => (v (next j)-q)/(v j-q))
    (Complex.continuousAt_arg (segment_relative_ratio_mem_slitPlane _ _ _ hq))
  exact (continuousAt_const.sub continuousAt_id).div (continuousAt_const.sub continuousAt_id) hz

/-- The full polygon index jump has limit two pi: every other edge contributes
a continuous term and cancels from the two-sided difference. -/
theorem polygonIndexPhase_edge_jump_limit {ι : Type*} [Fintype ι] [DecidableEq ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (i : ι) (hne : v i ≠ v (next i))
    {r : ℝ} (hr : r ∈ Set.Ioo (0:ℝ) 1)
    (hother : ∀ j, j ≠ i → edgeCrossPoint (v i) (v (next i)) r 0 ∉
      segment ℝ (v j) (v (next j))) :
    Tendsto (fun ε =>
      polygonIndexPhase next v (edgeCrossPoint (v i) (v (next i)) r ε)-
      polygonIndexPhase next v (edgeCrossPoint (v i) (v (next i)) r (-ε)))
      (𝓝[>] (0:ℝ)) (𝓝 (2*Real.pi)) := by
  let q := edgeCrossPoint (v i) (v (next i)) r
  have hc := continuousAt_polygonRemainderPhase next v i (q 0) hother
  have hq := (continuous_edgeCrossPoint (v i) (v (next i)) r).continuousAt (x := 0)
  have hp := (hc.comp (f := q) hq).tendsto.mono_left (nhdsWithin_le_nhds (s := Set.Ioi (0:ℝ)))
  have hc0 : ContinuousAt (fun ε => polygonRemainderPhase next v i (q ε)) (-(0:ℝ)) := by
    simpa only [Function.comp_def, neg_zero] using hc.comp (f := q) hq
  have hm := (hc0.comp (f := fun ε : ℝ => -ε) continuousAt_neg).tendsto.mono_left (nhdsWithin_le_nhds (s := Set.Ioi (0:ℝ)))
  have hrem := hp.sub hm
  simp only [Function.comp_def, neg_zero, sub_self] at hrem
  have h := (edgeCrossRatio_argument_jump_limit hr).add hrem
  simp only [add_zero] at h
  convert h using 1
  funext ε
  rw [polygonIndexPhase_eq_edge_add_remainder next v i,
    polygonIndexPhase_eq_edge_add_remainder next v i,
    edgeCrossPoint_ratio _ _ hne,edgeCrossPoint_ratio _ _ hne]
  dsimp [q]
  ring

/-- Crossing a single polygon edge changes the full real winding phase by
exactly two pi for all sufficiently small positive offsets. -/
theorem polygonIndexPhase_edge_jump {ι : Type*} [Fintype ι] [DecidableEq ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (i : ι) (hne : v i ≠ v (next i))
    {r : ℝ} (hr : r ∈ Set.Ioo (0:ℝ) 1)
    (hother : ∀ j, j ≠ i → edgeCrossPoint (v i) (v (next i)) r 0 ∉
      segment ℝ (v j) (v (next j))) :
    ∀ᶠ ε in 𝓝[>] (0:ℝ),
      polygonIndexPhase next v (edgeCrossPoint (v i) (v (next i)) r ε)-
        polygonIndexPhase next v (edgeCrossPoint (v i) (v (next i)) r (-ε)) = 2*Real.pi := by
  let q := edgeCrossPoint (v i) (v (next i)) r
  have hv (j : ι) : v j-q 0 ≠ 0 := by
    by_cases hj : j=i
    · subst j
      have he : v i-q 0= -(r:ℂ)*(v (next i)-v i) := by simp [q,edgeCrossPoint]
      rw [he]
      exact mul_ne_zero (neg_ne_zero.mpr (Complex.ofReal_ne_zero.mpr (ne_of_gt hr.1)))
        (sub_ne_zero.mpr hne.symm)
    · intro h
      exact hother j hj (sub_eq_zero.mp h ▸ left_mem_segment ℝ _ _)
  have hqc : Continuous q := continuous_edgeCrossPoint (v i) (v (next i)) r
  have hp : ∀ᶠ ε in 𝓝 (0:ℝ), ∀ j, v j-q ε ≠ 0 := by
    apply Filter.eventually_all.mpr
    intro j
    exact ((continuous_const.sub hqc).continuousAt.ne_iff_eventually_ne continuousAt_const).mp (hv j)
  have hm : ∀ᶠ ε in 𝓝 (0:ℝ), ∀ j, v j-q (-ε) ≠ 0 := by
    apply Filter.eventually_all.mpr
    intro j
    apply ((continuous_const.sub (hqc.comp continuous_neg)).continuousAt.ne_iff_eventually_ne
      continuousAt_const).mp
    simpa only [Pi.sub_apply, Function.comp_def, neg_zero] using hv j
  apply integral_phase_eventually_two_pi _ _ (polygonIndexPhase_edge_jump_limit next v i hne hr hother)
  filter_upwards [hp.filter_mono nhdsWithin_le_nhds,hm.filter_mono nhdsWithin_le_nhds] with ε hp hm
  obtain ⟨k,hk⟩ := polygonPhase_integer next (fun j => v j-q ε) hp
  obtain ⟨l,hl⟩ := polygonPhase_integer next (fun j => v j-q (-ε)) hm
  refine ⟨k-l,?_⟩
  change polygonPhase next (fun j => v j-q ε)-polygonPhase next (fun j => v j-q (-ε)) = _
  rw [hk,hl]
  push_cast
  ring

end MonotoneMatching
