import MonotoneMatching.TrajectoryCharges
import Mathlib.Analysis.Calculus.LocalExtr.Basic
noncomputable section
namespace MonotoneMatching
open Set Filter
open scoped BigOperators InnerProductSpace Topology
set_option backward.isDefEq.respectTransparency.types false

/-- Adjacent bounds combine into a neighborhood bound, including a periodic seam. -/
theorem periodic_subdivision_local_bound {m : ℕ} (hm : 0<m)
    (cut : Fin (m+1) → ℝ) (T : ℝ) (hmono : StrictMono cut)
    (hfirst : cut 0=0) (hlast : cut (Fin.last m)=T)
    (f : ℝ → ℝ) (hp : Function.Periodic f T) (i : Fin m)
    (hleft : ∀ t∈Icc (cut i.castSucc) (cut i.succ),f t≤0)
    (hright : ∀ t∈Icc (cut (finRotate m i).castSucc) (cut (finRotate m i).succ),f t≤0) :
    ∀ᶠ t in 𝓝 (trajectoryTransitionTime cut i),f t≤0 := by
  obtain ⟨k,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hm)
  by_cases hi : i=Fin.last k
  · subst i
    have h0 : (0:Fin (k+1)).castSucc=(0:Fin (k+1+1)) := rfl
    have hl : (Fin.last k).succ=Fin.last (k+1) := rfl
    have hlo : cut (Fin.last k).castSucc<T := by rw [← hlast,← hl]; exact hmono (Fin.last k).castSucc_lt_succ
    have hro : 0<cut (0:Fin (k+1)).succ := by rw [← hfirst,← h0]; exact hmono (0:Fin (k+1)).castSucc_lt_succ
    simp only [finRotate_last,h0,hfirst] at hright
    simp only [trajectoryTransitionTime,finRotate_last,h0,hfirst]
    filter_upwards [Ioo_mem_nhds (by linarith : cut (Fin.last k).castSucc-T<0) hro] with t ht
    by_cases ht0 : t<0
    · rw [← hp t]
      apply hleft
      rw [hl,hlast]
      constructor <;> linarith [ht.1]
    · exact hright t ⟨le_of_not_gt ht0,ht.2.le⟩
  · have he : (finRotate (k+1) i).castSucc=i.succ := by
      apply Fin.ext
      simpa only [Fin.val_castSucc,Fin.val_succ] using coe_finRotate_of_ne_last hi
    have hlu := hmono i.castSucc_lt_succ
    have hur : cut i.succ<cut (finRotate (k+1) i).succ := by
      rw [← he]; exact hmono (finRotate (k+1) i).castSucc_lt_succ
    simp only [trajectoryTransitionTime,he]
    filter_upwards [Ioo_mem_nhds hlu hur] with t ht
    by_cases htu : t≤cut i.succ
    · exact hleft t ⟨ht.1.le,htu⟩
    · apply hright
      rw [he]
      exact ⟨(lt_of_not_ge htu).le,ht.2.le⟩

/-- A locally persistent optimum at a generic time is unique: an additional
optimum would have zero score derivative, contradicting transversality. -/
theorem generic_trajectory_locally_optimal_unique {n : ℕ} (a : Fin n → ℂ)
    (b v : Fin n → ℝ → ℂ) (hd : ∀ i t,HasDerivAt (b i) (v i t) t)
    (K : Set ℝ) (ha : GenericTrajectorySources b v K a) (u : ℝ) (hu : u∈K)
    (σ : Equiv.Perm (Fin n))
    (hlocal : ∀ ρ,∀ᶠ t in 𝓝 u,assignmentScore a (fun i => b i t) ρ≤assignmentScore a (fun i => b i t) σ)
    (τ : Equiv.Perm (Fin n))
    (heq : assignmentScore a (fun i => b i u) τ=assignmentScore a (fun i => b i u) σ) : τ=σ := by
  by_contra hne
  have ht := generic_trajectory_pair_transverse b v K a ha u hu σ τ (Ne.symm hne) heq.symm
  have hm : IsLocalMax (fun t => assignmentScore a (fun i => b i t) τ-assignmentScore a (fun i => b i t) σ) u := by
    change ∀ᶠ t in 𝓝 u,assignmentScore a (fun i => b i t) τ-assignmentScore a (fun i => b i t) σ≤
      assignmentScore a (fun i => b i u) τ-assignmentScore a (fun i => b i u) σ
    rw [heq,sub_self]
    filter_upwards [hlocal τ] with t ht
    exact sub_nonpos.mpr ht
  exact ht (hm.hasDerivAt_eq_zero ((assignmentScore_trajectory_hasDerivAt a b v hd τ u).sub
    (assignmentScore_trajectory_hasDerivAt a b v hd σ u)))

/-- The exact predicate for an optimal tie, distinguished from a mere tie
between two suboptimal scores. -/
def trajectoryOptimalTie {n : ℕ} (a : Fin n → ℂ) (b : Fin n → ℝ → ℂ) (t : ℝ) : Prop :=
  ∃ σ τ : Equiv.Perm (Fin n),σ≠τ ∧
    (∀ ρ,assignmentScore a (fun j => b j t) ρ≤assignmentScore a (fun j => b j t) σ) ∧
    assignmentScore a (fun j => b j t) τ=assignmentScore a (fun j => b j t) σ

/-- At each canonical boundary a generic optimal tie occurs exactly when the
two adjacent cell labels differ. -/
theorem trajectory_boundary_tie_iff_change {n m : ℕ} (a : Fin n → ℂ)
    (b v : Fin n → ℝ → ℂ) (T : ℝ) (hm : 0<m)
    (hd : ∀ i t,HasDerivAt (b i) (v i t) t) (hp : ∀ i,Function.Periodic (b i) T)
    (ha : GenericTrajectorySources b v (Icc 0 T) a)
    (cut : Fin (m+1) → ℝ) (label : Fin m → Equiv.Perm (Fin n))
    (hmono : StrictMono cut) (hfirst : cut 0=0) (hlast : cut (Fin.last m)=T)
    (hopt : ∀ i,∀ t∈Icc (cut i.castSucc) (cut i.succ),∀ ρ,
      assignmentScore a (fun j => b j t) ρ≤assignmentScore a (fun j => b j t) (label i))
    (i : Fin m) : trajectoryOptimalTie a b (trajectoryTransitionTime cut i) ↔ label (finRotate m i)≠label i := by
  have hperiod (ρ : Equiv.Perm (Fin n)) : Function.Periodic (fun t => assignmentScore a (fun j => b j t) ρ) T := by
    intro t
    exact congrArg (fun y : Fin n → ℂ => assignmentScore a y ρ) (funext (fun j => hp j t))
  have hseam (ρ : Equiv.Perm (Fin n)) := periodic_subdivision_seam hm cut hfirst hlast _ (hperiod ρ) i
  have hold : ∀ ρ,assignmentScore a (fun j => b j (trajectoryTransitionTime cut i)) ρ≤
      assignmentScore a (fun j => b j (trajectoryTransitionTime cut i)) (label i) := by
    intro ρ
    dsimp only [trajectoryTransitionTime]
    rw [hseam ρ,hseam (label i)]
    exact hopt i _ (right_mem_Icc.mpr (hmono i.castSucc_lt_succ).le) ρ
  have hnew := hopt (finRotate m i) _ (left_mem_Icc.mpr (hmono (finRotate m i).castSucc_lt_succ).le)
  constructor
  · rintro ⟨σ,τ,hne,hσ,heq⟩ hsame
    have hlocal (ρ : Equiv.Perm (Fin n)) : ∀ᶠ t in 𝓝 (trajectoryTransitionTime cut i),
        assignmentScore a (fun j => b j t) ρ≤assignmentScore a (fun j => b j t) (label i) := by
      have hh := periodic_subdivision_local_bound hm cut T hmono hfirst hlast
        (fun t => assignmentScore a (fun j => b j t) ρ-assignmentScore a (fun j => b j t) (label i))
        ((hperiod ρ).sub (hperiod (label i))) i
        (fun t ht => sub_nonpos.mpr (hopt i t ht ρ))
        (fun t ht => sub_nonpos.mpr (by simpa only [hsame] using hopt (finRotate m i) t ht ρ))
      exact hh.mono (fun _ h => sub_nonpos.mp h)
    have hu := trajectory_transition_time_mem hm cut T hmono hfirst hlast i
    have hσeq := le_antisymm (hold σ) (hσ (label i))
    have hs := generic_trajectory_locally_optimal_unique a b v hd (Icc 0 T) ha _ ⟨hu.1,hu.2.le⟩ (label i) hlocal σ hσeq
    have ht := generic_trajectory_locally_optimal_unique a b v hd (Icc 0 T) ha _ ⟨hu.1,hu.2.le⟩ (label i) hlocal τ (heq.trans hσeq)
    exact hne (hs.trans ht.symm)
  · intro hne
    exact ⟨label i,label (finRotate m i),Ne.symm hne,hold,le_antisymm (hold _) (hnew _)⟩

/-- A point in the half-open period that is in no cell interior is one of the
canonical cyclic boundaries. -/
theorem subdivision_noninterior_boundary {m : ℕ} (hm : 0<m) (cut : Fin (m+1) → ℝ)
    (T : ℝ) (hmono : StrictMono cut) (hfirst : cut 0=0) (hlast : cut (Fin.last m)=T)
    (t : ℝ) (ht : t∈Ico (0:ℝ) T)
    (hnot : ∀ j : Fin m,t∉Ioo (cut j.castSucc) (cut j.succ)) :
    ∃ i : Fin m,trajectoryTransitionTime cut i=t := by
  obtain ⟨j,hj⟩ := finite_subdivision_closed_cover hm cut hmono (by simpa only [hfirst,hlast] using ⟨ht.1,ht.2.le⟩)
  by_cases hs : t=cut j.castSucc
  · refine ⟨(finRotate m).symm j,?_⟩
    simp only [trajectoryTransitionTime,Equiv.apply_symm_apply,hs]
  · have he : t=cut j.succ := by
      by_contra he
      exact hnot j ⟨lt_of_le_of_ne hj.1 (Ne.symm hs),lt_of_le_of_ne hj.2 he⟩
    obtain ⟨k,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hm)
    have hjlast : j≠Fin.last k := by
      intro h
      have he' : j.succ=Fin.last (k+1) := by subst j; rfl
      rw [he',hlast] at he
      exact (ne_of_lt ht.2) he
    refine ⟨j,?_⟩
    have hnext : (finRotate (k+1) j).castSucc=j.succ := by
      apply Fin.ext
      simpa only [Fin.val_castSucc,Fin.val_succ] using coe_finRotate_of_ne_last hjlast
    simp only [trajectoryTransitionTime,hnext,he]

/-- No optimal event is omitted or duplicated: canonical transition times are
injective, and every optimal tie in [0,T) occurs at a genuine label change. -/
theorem trajectory_event_enumeration {n m : ℕ} (a : Fin n → ℂ)
    (b v : Fin n → ℝ → ℂ) (T : ℝ) (hm : 0<m)
    (hd : ∀ i t,HasDerivAt (b i) (v i t) t) (hp : ∀ i,Function.Periodic (b i) T)
    (ha : GenericTrajectorySources b v (Icc 0 T) a)
    (cut : Fin (m+1) → ℝ) (label : Fin m → Equiv.Perm (Fin n))
    (hmono : StrictMono cut) (hfirst : cut 0=0) (hlast : cut (Fin.last m)=T)
    (hunique : ∀ i,∀ t∈Ioo (cut i.castSucc) (cut i.succ),UniqueMinimum a (fun j => b j t) (label i))
    (hopt : ∀ i,∀ t∈Icc (cut i.castSucc) (cut i.succ),∀ ρ,
      assignmentScore a (fun j => b j t) ρ≤assignmentScore a (fun j => b j t) (label i)) :
    Function.Injective (trajectoryTransitionTime cut) ∧
    ∀ t∈Ico (0:ℝ) T,trajectoryOptimalTie a b t ↔
      ∃ i,trajectoryTransitionTime cut i=t ∧ label (finRotate m i)≠label i := by
  constructor
  · intro i j h
    apply (finRotate m).injective
    apply Fin.castSucc_injective
    exact hmono.injective h
  · intro t ht
    constructor
    · intro htie
      have hnot (j : Fin m) : t∉Ioo (cut j.castSucc) (cut j.succ) := by
        intro hmem
        obtain ⟨σ,τ,hne,hσ,heq⟩ := htie
        have hs := uniqueMinimum_eq_of_score_max a (fun i => b i t) (label j) σ (hunique j t hmem) hσ
        have ht := uniqueMinimum_eq_of_score_max a (fun i => b i t) (label j) τ (hunique j t hmem)
          (fun ρ => by rw [heq]; exact hσ ρ)
        exact hne (hs.symm.trans ht)
      obtain ⟨i,hi⟩ := subdivision_noninterior_boundary hm cut T hmono hfirst hlast t ht hnot
      refine ⟨i,hi,?_⟩
      apply (trajectory_boundary_tie_iff_change a b v T hm hd hp ha cut label hmono hfirst hlast hopt i).mp
      rwa [hi]
    · rintro ⟨i,hi,hchange⟩
      rw [← hi]
      exact (trajectory_boundary_tie_iff_change a b v T hm hd hp ha cut label hmono hfirst hlast hopt i).mpr hchange

end MonotoneMatching
