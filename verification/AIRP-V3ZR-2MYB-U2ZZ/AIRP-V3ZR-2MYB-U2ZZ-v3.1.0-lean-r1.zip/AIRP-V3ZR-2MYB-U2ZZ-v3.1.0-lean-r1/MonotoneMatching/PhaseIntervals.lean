import MonotoneMatching.PairPhase
import Mathlib.Topology.Covering.AddCircle
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Complex

/-! Exact real phase transport on connected intervals of optimality. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators InnerProductSpace

theorem continuous_rotation_time (z : ℂ) : Continuous (fun t => rotateClockwise t z) := by
  simp only [rotateClockwise,Complex.mk_eq_add_mul_I]
  fun_prop

theorem rotation_unit_ne_zero (t : ℝ) : (⟨Real.cos t, -Real.sin t⟩ : ℂ) ≠ 0 := by
  intro h
  have hr := congrArg Complex.re h
  have hi := congrArg Complex.im h
  simp only [Complex.zero_re,Complex.zero_im] at hr hi
  have ht := Real.sin_sq_add_cos_sq t
  nlinarith

theorem rotation_arg_compensation_angle (t : ℝ) {z : ℂ} (hz : z ≠ 0) :
    ((Complex.arg (rotateClockwise t z) + t : ℝ) : Real.Angle) = (z.arg : Real.Angle) := by
  have hu : (⟨Real.cos t,-Real.sin t⟩ : ℂ) =
      ((Real.Angle.cos (-t : Real.Angle) : ℝ) : ℂ) +
        (Real.Angle.sin (-t : Real.Angle) : ℝ) * Complex.I := by
    apply Complex.ext <;> simp [Complex.cos_ofReal_re,Complex.sin_ofReal_re]
  have ha := Complex.arg_cos_add_sin_mul_I_coe_angle (-t : Real.Angle)
  rw [← hu] at ha
  rw [Real.Angle.coe_add,rotateClockwise_eq_mul,
    Complex.arg_mul_coe_angle (rotation_unit_ne_zero t) hz,ha]
  simp

/-- A nonzero vector in the closed right half-plane avoids the argument cut. -/
theorem mem_slitPlane_of_re_nonneg {z : ℂ} (hz : z ≠ 0) (hr : 0 ≤ z.re) :
    z ∈ Complex.slitPlane := by
  by_cases hi : z.im = 0
  · left
    apply lt_of_le_of_ne hr
    intro h
    exact hz (Complex.ext h.symm hi)
  · exact Or.inr hi

/-- Compensation by elapsed clockwise angle is constant on any connected set
where the rotating vector stays in the closed right half-plane. -/
theorem rotation_arg_transport {z : ℂ} (hz : z ≠ 0) {s : Set ℝ}
    (hs : IsPreconnected s) (hr : ∀ t ∈ s, 0 ≤ (rotateClockwise t z).re)
    {u v : ℝ} (hu : u ∈ s) (hv : v ∈ s) :
    Complex.arg (rotateClockwise v z) - Complex.arg (rotateClockwise u z) = -(v-u) := by
  have hn (t : ℝ) : rotateClockwise t z ≠ 0 := by
    rw [rotateClockwise_eq_mul]
    exact mul_ne_zero (rotation_unit_ne_zero t) hz
  have hc : ContinuousOn (fun t => Complex.arg (rotateClockwise t z) + t) s := by
    apply ContinuousOn.add _ continuousOn_id
    intro t ht
    exact ((Complex.continuousAt_arg (mem_slitPlane_of_re_nonneg (hn t) (hr t ht))).comp (f := fun t => rotateClockwise t z)
      (continuous_rotation_time z).continuousAt).continuousWithinAt
  have he := (AddCircle.isCoveringMap_coe (2*Real.pi)).constOn_of_comp hs hc
    (fun t _ t' _ => (rotation_arg_compensation_angle t hz).trans
      (rotation_arg_compensation_angle t' hz).symm) hu hv
  linarith

/-- Pairwise optimality at a weak optimum gives closed-half-plane constraints. -/
theorem weak_identity_pair_nonneg {n : ℕ} (a y : Fin n → ℂ)
    (h : ∀ τ, assignmentScore a y τ ≤ assignmentScore a y (Equiv.refl _))
    (i j : Fin n) : 0 ≤ inner ℝ (a i-a j) (y i-y j) := by
  by_cases hij : i=j
  · subst j; simp
  · rw [← score_swap_difference a y i j hij]
    exact sub_nonneg.mpr (h _)

/-- Throughout a connected cell of identity optimality the exact real phase
falls by choose(n,2) times the elapsed angle, including the weak endpoints. -/
theorem identityPhase_rotation_transport {n : ℕ} (a b : Fin n → ℂ)
    (ha : Function.Injective a) (hb : Function.Injective b) {s : Set ℝ}
    (hs : IsPreconnected s)
    (hopt : ∀ t ∈ s, ∀ τ, assignmentScore a (rotateClockwise t ∘ b) τ ≤
      assignmentScore a (rotateClockwise t ∘ b) (Equiv.refl _))
    {u v : ℝ} (hu : u ∈ s) (hv : v ∈ s) :
    identityPhase a (rotateClockwise v ∘ b) - identityPhase a (rotateClockwise u ∘ b) =
      -(n.choose 2 : ℝ) * (v-u) := by
  classical
  rw [identityPhase,identityPhase,← Finset.sum_sub_distrib]
  have hpair (p : Fin n × Fin n) (hp : p ∈ increasingPairs n) :
      Complex.arg (((rotateClockwise v ∘ b) p.2-(rotateClockwise v ∘ b) p.1)*
        (starRingEnd ℂ) (a p.2-a p.1)) -
      Complex.arg (((rotateClockwise u ∘ b) p.2-(rotateClockwise u ∘ b) p.1)*
        (starRingEnd ℂ) (a p.2-a p.1)) = -(v-u) := by
    have hne : p.2 ≠ p.1 := (ne_of_lt (Finset.mem_filter.mp hp).2).symm
    let z := (b p.2-b p.1)*(starRingEnd ℂ) (a p.2-a p.1)
    have hz : z ≠ 0 := by
      apply mul_ne_zero (sub_ne_zero.mpr (hb.ne hne))
      exact (map_ne_zero (starRingEnd ℂ)).mpr (sub_ne_zero.mpr (ha.ne hne))
    have he (t : ℝ) : ((rotateClockwise t ∘ b) p.2-(rotateClockwise t ∘ b) p.1)*
        (starRingEnd ℂ) (a p.2-a p.1) = rotateClockwise t z := by
      simp only [Function.comp_def,rotateClockwise_eq_mul,z]
      ring
    rw [he v,he u]
    apply rotation_arg_transport hz hs _ hu hv
    intro t ht
    rw [← he]
    exact weak_identity_pair_nonneg a (rotateClockwise t ∘ b) (hopt t ht) p.2 p.1
  rw [Finset.sum_congr rfl hpair,Finset.sum_const, nsmul_eq_mul]
  have hc : (increasingPairs n).card = n.choose 2 := by
    simpa [increasingPairs] using
      (Finset.card_product_filter_lt (s := (Finset.univ : Finset (Fin n))))
  rw [hc]
  ring

end MonotoneMatching
