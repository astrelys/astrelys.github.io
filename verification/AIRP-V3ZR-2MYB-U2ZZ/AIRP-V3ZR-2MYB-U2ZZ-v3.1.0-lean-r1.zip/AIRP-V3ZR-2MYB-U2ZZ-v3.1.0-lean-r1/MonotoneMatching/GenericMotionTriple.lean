import MonotoneMatching.GenericMotionPair

set_option backward.isDefEq.respectTransparency.types false
noncomputable section
namespace MonotoneMatching
open scoped BigOperators Topology
open MeasureTheory MeasureTheory.Measure

/-- A coordinate that a differentiable map ignores gives an explicit kernel vector. -/
theorem fderiv_eq_zero_of_update_invariant {ι : Type*} [Fintype ι] [DecidableEq ι]
    (f : (ι → ℝ) → (ι → ℝ)) (x : ι → ℝ) (i : ι)
    (hd : DifferentiableAt ℝ f x) (hi : ∀ t, f (Function.update x i t) = f x) :
    fderiv ℝ f x (Pi.single i 1) = 0 := by
  have h := hd.hasFDerivAt
  rw [← Function.update_eq_self i x] at h
  have hc := h.comp_hasDerivAt (x i) (hasDerivAt_update x i (x i))
  have he : f ∘ Function.update x i = fun _ => f x := funext hi
  rw [he] at hc
  simpa only [Function.update_eq_self] using hc.unique (hasDerivAt_const (x i) (f x))

/-- The two-coordinate pivot minor for independent score differences. -/
def tieMinor {ι : Type*} (d e : ℝ → ι → ℝ) (i j : ι) (t : ℝ) : ℝ :=
  d t i * e t j - d t j * e t i

/-- The contribution of all source coordinates outside the two pivots. -/
def outsidePairing {ι : Type*} [Fintype ι] [DecidableEq ι]
    (d : ℝ → ι → ℝ) (i j : ι) (x : ι → ℝ) (t : ℝ) : ℝ :=
  ∑ k ∈ (Finset.univ.erase i).erase j, x k * d t k

/-- A chart of triple-score ties. x(i) is time and x(j) is ignored. -/
def tripleTieChart {ι : Type*} [Fintype ι] [DecidableEq ι]
    (d e : ℝ → ι → ℝ) (i j : ι) (x : ι → ℝ) : ι → ℝ :=
  Function.update (Function.update x i
    ((d (x i) j * outsidePairing e i j x (x i) -
      e (x i) j * outsidePairing d i j x (x i)) / tieMinor d e i j (x i))) j
    ((e (x i) i * outsidePairing d i j x (x i) -
      d (x i) i * outsidePairing e i j x (x i)) / tieMinor d e i j (x i))

theorem outsidePairing_update_left {ι : Type*} [Fintype ι] [DecidableEq ι]
    (d : ℝ → ι → ℝ) (i j : ι) (x : ι → ℝ) (t u : ℝ) :
    outsidePairing d i j (Function.update x i u) t = outsidePairing d i j x t := by
  apply Finset.sum_congr rfl
  intro k hk
  rw [Function.update_of_ne (Finset.ne_of_mem_erase (Finset.mem_of_mem_erase hk))]

theorem outsidePairing_update_right {ι : Type*} [Fintype ι] [DecidableEq ι]
    (d : ℝ → ι → ℝ) (i j : ι) (x : ι → ℝ) (t u : ℝ) :
    outsidePairing d i j (Function.update x j u) t = outsidePairing d i j x t := by
  apply Finset.sum_congr rfl
  intro k hk
  rw [Function.update_of_ne (Finset.ne_of_mem_erase hk)]

/-- Triple-tie charts ignore the second pivot parameter everywhere. -/
theorem tripleTieChart_update_invariant {ι : Type*} [Fintype ι] [DecidableEq ι]
    (d e : ℝ → ι → ℝ) (i j : ι) (hij : i ≠ j) (x : ι → ℝ) (u : ℝ) :
    tripleTieChart d e i j (Function.update x j u) = tripleTieChart d e i j x := by
  simp only [tripleTieChart, Function.update_of_ne hij, outsidePairing_update_right]
  rw [Function.update_comm hij, Function.update_idem, Function.update_comm hij.symm]

theorem differentiableAt_tripleTieChart {ι : Type*} [Fintype ι] [DecidableEq ι]
    (d e : ℝ → ι → ℝ)
    (hd : ∀ j, Differentiable ℝ (fun t => d t j))
    (he : ∀ j, Differentiable ℝ (fun t => e t j))
    (i j : ι) (x : ι → ℝ) (hn : tieMinor d e i j (x i) ≠ 0) :
    DifferentiableAt ℝ (tripleTieChart d e i j) x := by
  have hdc (k : ι) : DifferentiableAt ℝ (fun z : ι → ℝ => d (z i) k) x := by
    simpa only [Function.comp_def] using! (hd k (x i)).comp x (differentiableAt_apply (𝕜 := ℝ) i x)
  have hec (k : ι) : DifferentiableAt ℝ (fun z : ι → ℝ => e (z i) k) x := by
    simpa only [Function.comp_def] using! (he k (x i)).comp x (differentiableAt_apply (𝕜 := ℝ) i x)
  have hod : DifferentiableAt ℝ (fun z : ι → ℝ => outsidePairing d i j z (z i)) x := by
    apply DifferentiableAt.fun_sum
    intro k _
    exact (differentiableAt_apply k x).mul (hdc k)
  have hoe : DifferentiableAt ℝ (fun z : ι → ℝ => outsidePairing e i j z (z i)) x := by
    apply DifferentiableAt.fun_sum
    intro k _
    exact (differentiableAt_apply k x).mul (hec k)
  have hminor : DifferentiableAt ℝ (fun z : ι → ℝ => tieMinor d e i j (z i)) x :=
    ((hdc i).mul (hec j)).sub ((hdc j).mul (hec i))
  have hfirst := (((hdc j).mul hoe).sub ((hec j).mul hod)).mul (hminor.inv hn)
  have hsecond := (((hec i).mul hod).sub ((hdc i).mul hoe)).mul (hminor.inv hn)
  apply differentiableAt_pi.mpr
  intro k
  by_cases hkj : k = j
  · subst k
    simpa only [tripleTieChart, Function.update_self, div_eq_mul_inv, Pi.mul_apply, Pi.sub_apply, Pi.inv_apply] using! hsecond
  · by_cases hki : k = i
    · subst k
      simpa only [tripleTieChart, Function.update_of_ne hkj, Function.update_self, div_eq_mul_inv, Pi.mul_apply, Pi.sub_apply, Pi.inv_apply]
        using! hfirst
    · simpa only [tripleTieChart, Function.update_of_ne hkj, Function.update_of_ne hki]
        using differentiableAt_apply (𝕜 := ℝ) k x

theorem motionPairing_split_two {ι : Type*} [Fintype ι] [DecidableEq ι]
    (d : ℝ → ι → ℝ) (i j : ι) (hij : i ≠ j) (A : ι → ℝ) (t : ℝ) :
    outsidePairing d i j A t + A i * d t i + A j * d t j = motionPairing A (d t) := by
  unfold motionPairing outsidePairing
  rw [← Finset.sum_erase_add _ _ (Finset.mem_univ i),
    ← Finset.sum_erase_add _ _ (Finset.mem_erase.mpr ⟨hij.symm, Finset.mem_univ j⟩)]
  ring

/-- Every source with two independent score ties belongs to a two-pivot chart. -/
theorem tripleTieChart_covers {ι : Type*} [Fintype ι] [DecidableEq ι]
    (d e : ℝ → ι → ℝ) (i j : ι) (hij : i ≠ j) (A : ι → ℝ) (t : ℝ)
    (hn : tieMinor d e i j t ≠ 0)
    (hd : motionPairing A (d t) = 0) (he : motionPairing A (e t) = 0) :
    tripleTieChart d e i j (Function.update A i t) = A := by
  have h1 := (motionPairing_split_two d i j hij A t).trans hd
  have h2 := (motionPairing_split_two e i j hij A t).trans he
  have hi : (d t j * outsidePairing e i j A t - e t j * outsidePairing d i j A t) /
      tieMinor d e i j t = A i := by
    apply (div_eq_iff hn).mpr
    unfold tieMinor
    linear_combination (d t j) * h2 - (e t j) * h1
  have hj : (e t i * outsidePairing d i j A t - d t i * outsidePairing e i j A t) /
      tieMinor d e i j t = A j := by
    apply (div_eq_iff hn).mpr
    unfold tieMinor
    linear_combination (e t i) * h1 - (d t i) * h2
  simp only [tripleTieChart, Function.update_self, outsidePairing_update_left, hi, hj,
    Function.update_idem, Function.update_eq_self]

/-- Independent score differences admit a nonzero two-coordinate minor. -/
theorem exists_nonzero_tieMinor {ι : Type*} (d e : ℝ → ι → ℝ) (t : ℝ)
    (hd : d t ≠ 0) (he : ¬∃ r : ℝ, e t = r • d t) :
    ∃ i j, i ≠ j ∧ tieMinor d e i j t ≠ 0 := by
  obtain ⟨i,hi⟩ : ∃ i, d t i ≠ 0 := by
    by_contra hz
    push Not at hz
    exact hd (funext hz)
  by_contra hz
  push Not at hz
  apply he
  refine ⟨e t i / d t i, ?_⟩
  ext j
  have hm : tieMinor d e i j t = 0 := by
    by_cases hij : i = j
    · subst j
      simp [tieMinor]
    · exact hz i j hij
  simp only [Pi.smul_apply, smul_eq_mul]
  unfold tieMinor at hm
  rw [div_mul_eq_mul_div]
  apply (eq_div_iff hi).mpr
  nlinarith [hm]

/-- Triple ties occupy a null set of sources whenever the two score differences
are independent at every time. -/
theorem triple_tie_bad_sources_null {ι : Type*} [Fintype ι] [DecidableEq ι]
    (μ : Measure (ι → ℝ)) [IsAddHaarMeasure μ]
    (d e : ℝ → ι → ℝ)
    (hd : ∀ j, Differentiable ℝ (fun t => d t j))
    (he : ∀ j, Differentiable ℝ (fun t => e t j))
    (hind : ∀ t, d t ≠ 0 ∧ ¬∃ r : ℝ, e t = r • d t) :
    μ {A | ∃ t, motionPairing A (d t) = 0 ∧ motionPairing A (e t) = 0} = 0 := by
  let S (i j : ι) := {x : ι → ℝ | i ≠ j ∧ tieMinor d e i j (x i) ≠ 0}
  have hnull (i j : ι) : μ (tripleTieChart d e i j '' S i j) = 0 := by
    apply null_image_of_derivative_kernel μ
    · intro x hx
      exact differentiableAt_tripleTieChart d e hd he i j x hx.2
    · intro x hx
      refine ⟨Pi.single j 1, ?_, ?_⟩
      · intro hz
        have := congrFun hz j
        simp at this
      · exact fderiv_eq_zero_of_update_invariant _ x j
          (differentiableAt_tripleTieChart d e hd he i j x hx.2)
          (tripleTieChart_update_invariant d e i j hx.1 x)
  have hsub : {A | ∃ t, motionPairing A (d t) = 0 ∧ motionPairing A (e t) = 0} ⊆
      ⋃ i, ⋃ j, tripleTieChart d e i j '' S i j := by
    rintro A ⟨t,ht,hu⟩
    obtain ⟨i,j,hij,hminor⟩ := exists_nonzero_tieMinor d e t (hind t).1 (hind t).2
    apply Set.mem_iUnion.mpr
    refine ⟨i, Set.mem_iUnion.mpr ⟨j, ?_⟩⟩
    refine ⟨Function.update A i t, ?_, tripleTieChart_covers d e i j hij A t hminor ht hu⟩
    exact ⟨hij, by simpa only [Function.update_self] using hminor⟩
  exact measure_mono_null hsub (measure_iUnion_null fun i => measure_iUnion_null (hnull i))

end MonotoneMatching
