import MonotoneMatching.ArgumentLifts
import Mathlib.Tactic.Module

/-! Exact real argument increments along nonvanishing affine segments. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval

theorem affine_argument_increment (z w : ℂ)
    (hn : ∀ t∈Set.Icc (0:ℝ) 1, (1-t) • z+t • w≠0)
    (φ : C(I,ℝ))
    (hφ : ∀ t, (φ t : Real.Angle)=
      (Complex.arg ((1-(t:ℝ)) • z+(t:ℝ) • w) : Real.Angle)) :
    φ 1-φ 0=Complex.arg (w/z) := by
  let γ := fun t : I => (1-(t:ℝ)) • z+(t:ℝ) • w
  have hz : z≠0 := by simpa using hn 0 ⟨le_rfl,by norm_num⟩
  have hγ (t : I) : γ t≠0 := hn t t.property
  have hc : Continuous γ := by fun_prop
  have hslit (t : I) : γ t/z∈Complex.slitPlane := by
    apply ratio_mem_slitPlane_of_segment_nonzero hz (hγ t)
    intro s hs0 hs1 he
    have hst : s*(t:ℝ)∈Set.Icc (0:ℝ) 1 :=
      ⟨mul_nonneg hs0.le t.property.1,(mul_le_mul_of_nonneg_right hs1.le t.property.1).trans (by simpa using t.property.2)⟩
    apply hn (s*(t:ℝ)) hst
    calc
      (1-s*(t:ℝ)) • z+(s*(t:ℝ)) • w = (1-s) • z+s • γ t := by dsimp only [γ]; module
      _ = 0 := he
  let ψ := fun t : I => Complex.arg (γ t/z)+Complex.arg z
  have hψ : Continuous ψ := by
    apply Continuous.add _ continuous_const
    apply continuous_iff_continuousAt.mpr
    intro t
    exact ContinuousAt.comp (f := fun t => γ t/z) (Complex.continuousAt_arg (hslit t))
      (hc.continuousAt.div_const z)
  have hangle (t : I) : (φ t : Real.Angle)=(ψ t : Real.Angle) := by
    dsimp only [ψ]
    rw [Real.Angle.coe_add,Complex.arg_div_coe_angle (hγ t) hz,hφ]
    change (Complex.arg (γ t) : Real.Angle)=_
    abel
  have heq := argument_lift_increment_unique φ ψ φ.continuous hψ hangle 0 1
  rw [heq]
  simp [ψ,γ,hz]

end MonotoneMatching
