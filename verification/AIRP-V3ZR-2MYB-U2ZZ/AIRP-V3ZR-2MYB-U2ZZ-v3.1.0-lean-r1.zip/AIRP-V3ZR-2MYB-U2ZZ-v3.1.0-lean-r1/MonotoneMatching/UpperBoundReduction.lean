import MonotoneMatching.CyclicCells
import MonotoneMatching.TransitionEvents
import MonotoneMatching.OpenWitness

/-! Explicit geometric interface and complete global reduction.
`LongCycleCharge` discharges the interface; `RotationalMain` proves the full target. -/
noncomputable section
namespace MonotoneMatching

/-- The local charge assertion required at an oriented two-optimum event. -/
def PositiveLocalCharge (n : ℕ) : Prop :=
  ∀ (A Y : Fin n → ℂ) (π : Equiv.Perm (Fin n)), π ≠ Equiv.refl _ →
    (∀ ρ, assignmentScore A Y ρ ≤ assignmentScore A Y (Equiv.refl _)) →
    assignmentScore A Y π = assignmentScore A Y (Equiv.refl _) →
    (∀ ρ, assignmentScore A Y ρ = assignmentScore A Y (Equiv.refl _) →
      ρ = Equiv.refl _ ∨ ρ = π) →
    0 < directionalScoreDerivative (complexAssignmentScore A Y π-
      complexAssignmentScore A Y (Equiv.refl _)) 0 →
    Real.pi ≤ identityPhase A (Y ∘ π)-identityPhase A Y

/-- The local long-cycle charge interface discharged in `LongCycleCharge`. -/
def PositiveLongCycleCharge (n : ℕ) : Prop :=
  ∀ (A Y : Fin n → ℂ) (π : Equiv.Perm (Fin n)), π.IsCycle → 3 ≤ π.support.card →
    (∀ ρ, assignmentScore A Y ρ ≤ assignmentScore A Y (Equiv.refl _)) →
    assignmentScore A Y π = assignmentScore A Y (Equiv.refl _) →
    (∀ ρ, assignmentScore A Y ρ = assignmentScore A Y (Equiv.refl _) →
      ρ = Equiv.refl _ ∨ ρ = π) →
    0 < directionalScoreDerivative (complexAssignmentScore A Y π-
      complexAssignmentScore A Y (Equiv.refl _)) 0 →
    Real.pi ≤ identityPhase A (Y ∘ π)-identityPhase A Y

/-- Transpositions are discharged by their exact pi charge; longer cycles
are retained as the explicit geometric premise. -/
theorem positiveLocalCharge_of_longCycleCharge {n : ℕ}
    (hlong : PositiveLongCycleCharge n) : PositiveLocalCharge n := by
  intro A Y π hne hmax heq htwo hd
  have hcycle := two_optima_identity_isCycle A Y π hne hmax heq htwo
  have hlen := hcycle.two_le_card_support
  by_cases h3 : 3 ≤ π.support.card
  · exact hlong A Y π hcycle h3 hmax heq htwo hd
  · have h2 : π.support.card=2 := by omega
    obtain ⟨i,j,hij,rfl⟩ := Equiv.Perm.card_support_eq_two.mp h2
    exact (two_optima_transposition_phase_charge A Y i j hij hmax heq htwo hd).ge

/-- The finite-cell realization, event orientation, phase budget and cyclic
counting together prove the generic bound from the local geometric assertion. -/
theorem generic_rotationCount_le_of_local_charge {n : ℕ} (hn : 2 ≤ n)
    (hgeometry : PositiveLocalCharge n) (a b : Fin n → ℂ)
    (hb : Function.Injective b) (ha : GenericRotationSources b a) :
    rotationCount a b ≤ n*(n-1) := by
  obtain ⟨m,hm,cut,label,hmono,hfirst,hlast,_,hopt,hcover⟩ := exists_generic_rotation_cells a b ha
  apply rotationCount_le_of_realized_cell_charges a b hn hm
    (genericRotationSources_injective a b ha) hb cut label hmono hfirst hlast hopt hcover
  intro i hchange
  obtain ⟨k,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hm)
  by_cases hi : i=Fin.last k
  · subst i
    have h0 : (0 : Fin (k+1)).castSucc = (0 : Fin (k+1+1)) := rfl
    have hl : (Fin.last k).succ = Fin.last (k+1) := rfl
    have hrot : rotateClockwise (2*Real.pi)=rotateClockwise 0 := by
      simpa using rotateClockwise_periodic 0
    rw [finRotate_last,h0,hl,hfirst,hlast,hrot]
    rw [finRotate_last] at hchange
    apply actual_event_charge_of_local_geometry a b ha hgeometry
      (label (Fin.last k)) (label 0) hchange.symm
      (v := cut (Fin.succ 0))
    · rw [← hfirst]
      exact hmono (Fin.succ_pos 0)
    · intro ρ
      have h := hopt (Fin.last k) (cut (Fin.last (k+1)))
        (by rw [← hl]; exact Set.right_mem_Icc.mpr (hmono (Fin.last k).castSucc_lt_succ).le) ρ
      simpa only [hlast,hrot] using h
    · intro t ht ρ
      apply hopt 0 t _ ρ
      simpa only [h0,hfirst] using ht
  · have he : (finRotate (k+1) i).castSucc=i.succ := by
      apply Fin.ext
      simpa only [Fin.val_castSucc,Fin.val_succ] using coe_finRotate_of_ne_last hi
    rw [he]
    apply actual_event_charge_of_local_geometry a b ha hgeometry
      (label i) (label (finRotate (k+1) i)) hchange.symm
      (v := cut (finRotate (k+1) i).succ)
    · rw [← he]
      exact hmono (finRotate (k+1) i).castSucc_lt_succ
    · exact hopt i _ (Set.right_mem_Icc.mpr (hmono i.castSucc_lt_succ).le)
    · intro t ht ρ
      apply hopt (finRotate (k+1) i) t _ ρ
      rwa [he]

/-- Generic-source transfer and repeated-target handling complete the upper
bound once the long-cycle geometric assertion is supplied. -/
theorem rotationCount_le_of_long_cycle_charge {n : ℕ} (hn : 2 ≤ n)
    (hgeometry : PositiveLongCycleCharge n) (a b : Fin n → ℂ) :
    rotationCount a b ≤ n*(n-1) := by
  by_cases hb : Function.Injective b
  · exact rotation_upper_bound_from_generic_sources b hb (n*(n-1))
      (fun A hA => generic_rotationCount_le_of_local_charge hn
        (positiveLocalCharge_of_longCycleCharge hgeometry) A b hb hA) a
  · simp only [Function.Injective] at hb
    push Not at hb
    obtain ⟨i,j,hij,hne⟩ := hb
    rw [rotationCount_eq_zero_of_repeated_target a b hne hij]
    exact Nat.zero_le _

/-- Conditional assembly of the full main theorem. The geometric premise
must be proved before this can certify the manuscript theorem. -/
theorem sharpRotationalCountStatement_of_long_cycle_charge
    (hgeometry : ∀ n : ℕ, 2 ≤ n → PositiveLongCycleCharge n) :
    sharpRotationalCountStatement := by
  apply sharpRotationalCountStatement_of_upper_bound
  intro n hn a b
  exact rotationCount_le_of_long_cycle_charge hn (hgeometry n hn) a b

end MonotoneMatching
