import MonotoneMatching.FiniteRotationTies
import MonotoneMatching.TransposePhase
import Mathlib.Topology.Order.IntermediateValue

/-! Actual optimizer cells between the finite score-tie events. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

theorem continuous_rotation_score {n : ℕ} (a b : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) :
    Continuous (fun t => assignmentScore a (rotateClockwise t ∘ b) σ) := by
  simp only [assignmentScore_rotation_coefficient,directionalScore]
  fun_prop

/-- A finite score family attains a maximum at every angle. -/
theorem exists_rotation_score_maximizer {n : ℕ} (a b : Fin n → ℂ) (t : ℝ) :
    ∃ σ : Equiv.Perm (Fin n), ∀ τ,
      assignmentScore a (rotateClockwise t ∘ b) τ ≤ assignmentScore a (rotateClockwise t ∘ b) σ := by
  classical
  obtain ⟨σ,_,hσ⟩ := Finset.exists_max_image Finset.univ
    (fun σ : Equiv.Perm (Fin n) => assignmentScore a (rotateClockwise t ∘ b) σ)
    Finset.univ_nonempty
  exact ⟨σ,fun τ => hσ τ (Finset.mem_univ τ)⟩

/-- On a connected tie-free set, every strict score comparison is preserved. -/
theorem strict_comparison_on_connected {s : Set ℝ} (hs : IsPreconnected s)
    {f g : ℝ → ℝ} (hf : ContinuousOn f s) (hg : ContinuousOn g s)
    (hne : ∀ t ∈ s, f t ≠ g t) {u : ℝ} (hu : u ∈ s) (hlt : f u < g u) :
    ∀ t ∈ s, f t < g t := by
  intro t ht
  by_contra h
  obtain ⟨x,hx,he⟩ := hs.intermediate_value₂ hu ht hf hg hlt.le (le_of_not_gt h)
  exact hne x hx he

/-- Every nonempty connected region with no score ties has one fixed unique
optimizer throughout the region. -/
theorem exists_unique_optimizer_on_tie_free_connected {n : ℕ} (a b : Fin n → ℂ)
    {s : Set ℝ} (hs : IsPreconnected s) (hne : s.Nonempty)
    (htie : ∀ t ∈ s, ∀ σ τ : Equiv.Perm (Fin n), σ ≠ τ →
      assignmentScore a (rotateClockwise t ∘ b) σ ≠ assignmentScore a (rotateClockwise t ∘ b) τ) :
    ∃ σ : Equiv.Perm (Fin n), ∀ t ∈ s, UniqueMinimum a (rotateClockwise t ∘ b) σ := by
  obtain ⟨u,hu⟩ := hne
  obtain ⟨σ,hσ⟩ := exists_rotation_score_maximizer a b u
  refine ⟨σ,?_⟩
  intro t ht τ hτ
  apply (assignmentCost_lt_iff_score_gt _ _ _ _).mpr
  apply strict_comparison_on_connected hs
    (continuous_rotation_score a b τ).continuousOn
    (continuous_rotation_score a b σ).continuousOn
    (fun t ht => htie t ht τ σ hτ) hu _ t ht
  exact lt_of_le_of_ne (hσ τ) (htie u hu τ σ hτ)

/-- An optimizer throughout the open cell remains weakly optimal at both
endpoints, without any genericity assumption at the endpoints. -/
theorem rotation_optimizer_on_closed_cell {n : ℕ} (a b : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) {u v : ℝ} (huv : u < v)
    (h : ∀ t ∈ Set.Ioo u v, UniqueMinimum a (rotateClockwise t ∘ b) σ) :
    ∀ t ∈ Set.Icc u v, ∀ τ, assignmentScore a (rotateClockwise t ∘ b) τ ≤
      assignmentScore a (rotateClockwise t ∘ b) σ := by
  intro t ht τ
  apply le_on_closure (s := Set.Ioo u v)
    (f := fun t => assignmentScore a (rotateClockwise t ∘ b) τ)
    (g := fun t => assignmentScore a (rotateClockwise t ∘ b) σ)
  · intro x hx
    by_cases he : τ = σ
    · simp [he]
    · exact ((assignmentCost_lt_iff_score_gt _ _ _ _).mp (h x hx τ he)).le
  · exact (continuous_rotation_score a b τ).continuousOn
  · exact (continuous_rotation_score a b σ).continuousOn
  · rwa [closure_Ioo huv.ne]

/-- Generic score coefficients force the source labels themselves to be distinct. -/
theorem genericRotationSources_injective {n : ℕ} (a b : Fin n → ℂ)
    (ha : GenericRotationSources b a) : Function.Injective a := by
  intro i j he
  by_contra hij
  have hs := complexScore_swap_difference a b i j hij
  rw [he,sub_self,map_zero,zero_mul] at hs
  have hn : Equiv.refl (Fin n) ≠ Equiv.swap i j := by
    intro h
    exact hij (Equiv.swap_eq_refl_iff.mp h.symm)
  exact ha.1 _ _ hn (sub_eq_zero.mp hs)

end MonotoneMatching
