import MonotoneMatching.VertexIndexConnection

/-! Propagation of left and right winding phases around a single polygon cycle. -/
noncomputable section
namespace MonotoneMatching

theorem transitive_permutation_invariant_constant {ι : Type*} (next : Equiv.Perm ι)
    (htrans : ∀ i j : ι, ∃ k : ℕ, (next^k) i=j) (f : ι → ℝ)
    (hstep : ∀ i, f (next i)=f i) (i j : ι) : f i=f j := by
  have hp (k : ℕ) : f ((next^k) i)=f i := by
    induction k with
    | zero => simp
    | succ k ih => rw [pow_succ',Equiv.Perm.mul_apply,hstep,ih]
  obtain ⟨k,hk⟩ := htrans i j
  rw [← hk]
  exact (hp k).symm

/-- Once the local dual cells and vertex neighborhoods are supplied, the
left index is the same at every edge of a single cycle. -/
theorem coherent_polygon_left_indices {ι : Type*} [Fintype ι] [DecidableEq ι]
    (next : Equiv.Perm ι) (verts : ι → ℂ)
    (htrans : ∀ i j : ι, ∃ k : ℕ, (next^k) i=j)
    (hne : ∀ i, verts i≠verts (next i))
    (C : ι → Set ℂ) (hC : ∀ i, IsOpen (C i))
    (hedge : ∀ i, ∀ t∈Set.Ioo (0:ℝ) 1, edgeCrossPoint (verts i) (verts (next i)) t 0∈C i)
    (hvertex : ∀ i j, j≠next.symm i → j≠i → verts i∉segment ℝ (verts j) (verts (next j)))
    (hcommon : ∀ i, ∃ q : ℂ, 0<edgeSide (verts (next.symm i)) (verts i) q ∧
      0<edgeSide (verts i) (verts (next i)) q)
    (L : ι → ℝ)
    (hL : ∀ i q, q∈C i → 0<edgeSide (verts i) (verts (next i)) q →
      polygonIndexPhase next verts q=L i) (i j : ι) : L i=L j := by
  have hadj (k : ι) : L (next.symm k)=L k := by
    obtain ⟨δ,hδ,hlocal⟩ := exists_polygon_vertex_ball next verts k (hvertex k)
    apply adjacent_left_indices_equal next verts (verts (next.symm k)) (verts k) (verts (next k))
      (by simpa only [next.apply_symm_apply] using hne (next.symm k)) (hne k)
      (hC (next.symm k)) (hC k) _ (hedge k) (hcommon k) hδ hlocal
      (L (next.symm k)) (L k) _ (hL k)
    · intro t ht
      simpa only [next.apply_symm_apply] using hedge (next.symm k) t ht
    · intro q hq hs
      apply hL (next.symm k) q hq
      simpa only [next.apply_symm_apply] using hs
  apply transitive_permutation_invariant_constant next htrans L _ i j
  intro k
  simpa only [next.symm_apply_apply] using (hadj (next k)).symm

theorem coherent_polygon_right_indices {ι : Type*} (L R : ι → ℝ)
    (hjump : ∀ i, L i-R i=2*Real.pi) (hL : ∀ i j, L i=L j) (i j : ι) : R i=R j := by
  linarith [hjump i,hjump j,hL i j]

end MonotoneMatching
