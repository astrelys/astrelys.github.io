import MonotoneMatching.ExactDualSupport
import MonotoneMatching.OptimalCycle

/-! Exact dual support forces open transition edges into disjoint affine cells. -/
noncomputable section
namespace MonotoneMatching
open scoped InnerProductSpace

/-- An affine row function in the dual maximum representation. -/
def dualRow {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ) (i : Fin n) (z : ℂ) : ℝ :=
  inner ℝ (a i) z - r i

theorem dualRow_combination {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ)
    (i : Fin n) (x y : ℂ) (t : ℝ) :
    dualRow a r i ((1-t) • x + t • y) =
      (1-t) * dualRow a r i x + t * dualRow a r i y := by
  simp only [dualRow, inner_add_right, real_inner_smul_right]
  ring

/-- Row i is the only active affine row on the open edge from y_i to y_(σ i),
provided that this is not a one- or two-cycle. -/
theorem transition_edge_unique_row {n : ℕ} (a y : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (r c : Fin n → ℝ)
    (hbound : ∀ i j, inner ℝ (a i) (y j) ≤ r i + c j)
    (hexact : ∀ i j, r i + c j = inner ℝ (a i) (y j) ↔ j = i ∨ j = σ i)
    (i : Fin n) (h2 : σ (σ i) ≠ i) (k : Fin n) (hk : k ≠ i)
    {t : ℝ} (ht0 : 0 < t) (ht1 : t < 1) :
    dualRow a r k ((1-t) • y i + t • y (σ i)) <
      dualRow a r i ((1-t) • y i + t • y (σ i)) := by
  have hi0 := (hexact i i).mpr (Or.inl rfl)
  have hi1 := (hexact i (σ i)).mpr (Or.inr rfl)
  have hk0 := hbound k i
  have hk1 := hbound k (σ i)
  have hstrict : r k + c i ≠ inner ℝ (a k) (y i) ∨
      r k + c (σ i) ≠ inner ℝ (a k) (y (σ i)) := by
    by_contra h
    push Not at h
    obtain (h0 | h0) := (hexact k i).mp h.1
    · exact hk h0.symm
    obtain (h1 | h1) := (hexact k (σ i)).mp h.2
    · exact h2 (by rw [h1,h0])
    · exact hk (σ.injective h1).symm
  rw [dualRow_combination,dualRow_combination]
  simp only [dualRow]
  rw [← hi0, ← hi1]
  have hp : 0 < 1-t := by linarith
  have hn0 := mul_nonneg hp.le (sub_nonneg.mpr hk0)
  have hn1 := mul_nonneg ht0.le (sub_nonneg.mpr hk1)
  rcases hstrict with hs | hs
  · have hh := mul_pos hp (sub_pos.mpr (lt_of_le_of_ne hk0 hs.symm))
    nlinarith
  · have hh := mul_pos ht0 (sub_pos.mpr (lt_of_le_of_ne hk1 hs.symm))
    nlinarith

/-- Distinct open long-cycle edges cannot intersect, since their unique affine
maximizers would disagree at the intersection. -/
theorem transition_open_edges_disjoint {n : ℕ} (a y : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (r c : Fin n → ℝ)
    (hbound : ∀ i j, inner ℝ (a i) (y j) ≤ r i + c j)
    (hexact : ∀ i j, r i + c j = inner ℝ (a i) (y j) ↔ j = i ∨ j = σ i)
    {i j : Fin n} (hi : σ (σ i) ≠ i) (hj : σ (σ j) ≠ j) (hij : i ≠ j)
    {s t : ℝ} (hs0 : 0 < s) (hs1 : s < 1) (ht0 : 0 < t) (ht1 : t < 1) :
    (1-s) • y i + s • y (σ i) ≠ (1-t) • y j + t • y (σ j) := by
  intro he
  have h1 := transition_edge_unique_row a y σ r c hbound hexact i hi j hij.symm hs0 hs1
  have h2 := transition_edge_unique_row a y σ r c hbound hexact j hj i hij ht0 ht1
  rw [he] at h1
  exact (not_lt_of_gt h1) h2

/-- No target vertex lies on an open long-cycle edge. This also keeps targets
outside the cycle off the boundary used in the charge calculation. -/
theorem target_not_on_transition_open_edge {n : ℕ} (a y : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (r c : Fin n → ℝ)
    (hbound : ∀ i j, inner ℝ (a i) (y j) ≤ r i + c j)
    (hexact : ∀ i j, r i + c j = inner ℝ (a i) (y j) ↔ j = i ∨ j = σ i)
    (i : Fin n) (h2 : σ (σ i) ≠ i) (j : Fin n)
    {t : ℝ} (ht0 : 0 < t) (ht1 : t < 1) :
    y j ≠ (1-t) • y i + t • y (σ i) := by
  intro he
  have hm : σ i ≠ i := by intro h; exact h2 (by rw [h,h])
  obtain ⟨k,hki,hact⟩ : ∃ k : Fin n, k ≠ i ∧ r k + c j = inner ℝ (a k) (y j) := by
    by_cases hji : j = i
    · refine ⟨σ.symm i, ?_, ?_⟩
      · intro h
        exact hm (by simpa using (congrArg σ h).symm)
      · apply (hexact _ _).mpr
        right
        simp [hji]
    · exact ⟨j,hji,(hexact j j).mpr (Or.inl rfl)⟩
  have hs := transition_edge_unique_row a y σ r c hbound hexact i h2 k hki ht0 ht1
  rw [← he] at hs
  have hb := hbound i j
  simp only [dualRow] at hs
  linarith

/-- Every moved vertex of a cycle of length at least three avoids a two-cycle. -/
theorem long_cycle_no_two_step {n : ℕ} (σ : Equiv.Perm (Fin n)) (hσ : σ.IsCycle)
    (hlen : 3 ≤ σ.support.card) {i : Fin n} (hi : σ i ≠ i) : σ (σ i) ≠ i := by
  intro h
  have he := hσ.eq_swap_of_apply_apply_eq_self hi h
  have hc : σ.support.card = 2 := by
    rw [he, Equiv.Perm.card_support_swap hi.symm]
  omega

/-- At a genuine two-optimum long-cycle event, exact support and simple-edge
geometry are obtained from optimality itself, rather than imposed as assumptions. -/
theorem two_optima_long_transition_geometry {n : ℕ} (a y : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (hne : σ ≠ Equiv.refl _)
    (hlen : 3 ≤ σ.support.card)
    (hmax : ∀ τ : Equiv.Perm (Fin n), assignmentScore a y τ ≤ assignmentScore a y (Equiv.refl _))
    (heq : assignmentScore a y σ = assignmentScore a y (Equiv.refl _))
    (htwo : ∀ τ : Equiv.Perm (Fin n),
      assignmentScore a y τ = assignmentScore a y (Equiv.refl _) →
      τ = Equiv.refl _ ∨ τ = σ) :
    σ.IsCycle ∧ ∃ r c : Fin n → ℝ,
      (∀ i j, inner ℝ (a i) (y j) ≤ r i + c j) ∧
      (∀ i j, r i + c j = inner ℝ (a i) (y j) ↔ j = i ∨ j = σ i) ∧
      ∀ i : Fin n, σ i ≠ i → ∀ k : Fin n, k ≠ i → ∀ t : ℝ, 0 < t → t < 1 →
        dualRow a r k ((1-t) • y i + t • y (σ i)) <
          dualRow a r i ((1-t) • y i + t • y (σ i)) := by
  have hσ := two_optima_identity_isCycle a y σ hne hmax heq htwo
  obtain ⟨r,c,hb,he⟩ := exists_exact_dual_support
    (fun i j => inner ℝ (a i) (y j)) σ hmax heq htwo
  refine ⟨hσ,r,c,hb,he,?_⟩
  intro i hi k hk t ht0 ht1
  exact transition_edge_unique_row a y σ r c hb he i
    (long_cycle_no_two_step σ hσ hlen hi) k hk ht0 ht1

end MonotoneMatching
