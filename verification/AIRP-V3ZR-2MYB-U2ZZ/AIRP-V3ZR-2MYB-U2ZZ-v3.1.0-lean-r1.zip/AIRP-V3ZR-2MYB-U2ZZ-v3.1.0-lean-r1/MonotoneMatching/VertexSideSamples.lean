import MonotoneMatching.VertexCollar
import MonotoneMatching.DualCellSideIndices

/-! Left-side samples of incident open edge cells can be chosen arbitrarily
close to their shared vertex, with the extra sector conditions at convex turns. -/
noncomputable section
namespace MonotoneMatching
open Filter
open scoped Topology

theorem edgeCrossPoint_zero_offset (z w : ℂ) (t : ℝ) :
    edgeCrossPoint z w t 0=(1-t) • z+t • w := by
  simp only [edgeCrossPoint,Complex.ofReal_zero,zero_mul,add_zero,Complex.real_smul]
  push_cast
  ring

theorem exists_incoming_edge_in_ball (p v : ℂ) {δ : ℝ} (hδ : 0<δ) :
    ∃ t ∈ Set.Ioo (0:ℝ) 1, edgeCrossPoint p v t 0∈Metric.ball v δ := by
  let f := fun t : ℝ => (1-t) • p+t • v
  have hc : Continuous f := by fun_prop
  have hf : f 1=v := by simp [f]
  have hb : ∀ᶠ t in 𝓝 (1:ℝ), f t∈Metric.ball v δ :=
    hc.continuousAt.eventually (Metric.isOpen_ball.mem_nhds (by rw [hf]; exact Metric.mem_ball_self hδ))
  have hp : ∀ᶠ t in 𝓝 (1:ℝ), 0<t := eventually_gt_nhds (by norm_num : (0:ℝ)<1)
  obtain ⟨t,hb,hp,ht⟩ := ((hb.filter_mono nhdsWithin_le_nhds).and
    ((hp.filter_mono nhdsWithin_le_nhds).and
      (self_mem_nhdsWithin : ∀ᶠ t in 𝓝[<] (1:ℝ), t∈Set.Iio (1:ℝ)))).exists
  exact ⟨t,⟨hp,ht⟩,by rwa [edgeCrossPoint_zero_offset]⟩

theorem exists_outgoing_edge_in_ball (v w : ℂ) {δ : ℝ} (hδ : 0<δ) :
    ∃ t ∈ Set.Ioo (0:ℝ) 1, edgeCrossPoint v w t 0∈Metric.ball v δ := by
  obtain ⟨t,ht,hb⟩ := exists_incoming_edge_in_ball w v hδ
  refine ⟨1-t,⟨by linarith [ht.2],by linarith [ht.1]⟩,?_⟩
  have he : edgeCrossPoint v w (1-t) 0=edgeCrossPoint w v t 0 := by
    rw [edgeCrossPoint_zero_offset,edgeCrossPoint_zero_offset]
    module
  rwa [he]

theorem incoming_left_sample (p v w : ℂ) (hne : p≠v) {δ : ℝ} (hδ : 0<δ)
    {C : Set ℂ} (hC : IsOpen C)
    (hedge : ∀ t∈Set.Ioo (0:ℝ) 1, edgeCrossPoint p v t 0∈C) :
    ∃ x∈Metric.ball v δ, x∈C ∧ 0<edgeSide p v x ∧
      (0<edgeSide p v w → 0<edgeSide v w x) := by
  obtain ⟨t,ht,hb⟩ := exists_incoming_edge_in_ball p v hδ
  by_cases hturn : 0<edgeSide p v w
  · have hs : 0<edgeSide v w (edgeCrossPoint p v t 0) := by
      rw [edgeCrossPoint_zero_offset,edgeSide_affine _ _ _ _ _ _ (by ring),
        ← edgeSide_cyclic,edgeSide_self,mul_zero,add_zero]
      exact mul_pos (sub_pos.mpr ht.2) hturn
    obtain ⟨ε,hε,hp,_,hps,_⟩ := exists_two_edge_offsets hne t
      ((hC.inter Metric.isOpen_ball).inter (isOpen_lt continuous_const (continuous_edgeSide v w)))
      (show edgeCrossPoint p v t 0∈(C ∩ Metric.ball v δ) ∩ {q | 0<edgeSide v w q} from ⟨⟨hedge t ht,hb⟩,hs⟩)
    exact ⟨_,hp.1.2,hp.1.1,hps,fun _ => hp.2⟩
  · obtain ⟨ε,hε,hp,_,hps,_⟩ := exists_two_edge_offsets hne t (hC.inter Metric.isOpen_ball)
      (show edgeCrossPoint p v t 0∈C ∩ Metric.ball v δ from ⟨hedge t ht,hb⟩)
    exact ⟨_,hp.2,hp.1,hps,fun h => (hturn h).elim⟩

theorem outgoing_left_sample (p v w : ℂ) (hne : v≠w) {δ : ℝ} (hδ : 0<δ)
    {C : Set ℂ} (hC : IsOpen C)
    (hedge : ∀ t∈Set.Ioo (0:ℝ) 1, edgeCrossPoint v w t 0∈C) :
    ∃ x∈Metric.ball v δ, x∈C ∧ 0<edgeSide v w x ∧
      (0<edgeSide p v w → 0<edgeSide p v x) := by
  obtain ⟨t,ht,hb⟩ := exists_outgoing_edge_in_ball v w hδ
  by_cases hturn : 0<edgeSide p v w
  · have hs : 0<edgeSide p v (edgeCrossPoint v w t 0) := by
      rw [edgeCrossPoint_zero_offset,edgeSide_affine _ _ _ _ _ _ (by ring),
        edgeSide_end,mul_zero,zero_add]
      exact mul_pos ht.1 hturn
    obtain ⟨ε,hε,hp,_,hps,_⟩ := exists_two_edge_offsets hne t
      ((hC.inter Metric.isOpen_ball).inter (isOpen_lt continuous_const (continuous_edgeSide p v)))
      (show edgeCrossPoint v w t 0∈(C ∩ Metric.ball v δ) ∩ {q | 0<edgeSide p v q} from ⟨⟨hedge t ht,hb⟩,hs⟩)
    exact ⟨_,hp.1.2,hp.1.1,hps,fun _ => hp.2⟩
  · obtain ⟨ε,hε,hp,_,hps,_⟩ := exists_two_edge_offsets hne t (hC.inter Metric.isOpen_ball)
      (show edgeCrossPoint v w t 0∈C ∩ Metric.ball v δ from ⟨hedge t ht,hb⟩)
    exact ⟨_,hp.2,hp.1,hps,fun h => (hturn h).elim⟩

end MonotoneMatching
