import MonotoneMatching.Assignment
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.Complex.Basic
import Mathlib.GroupTheory.Perm.Fin
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum

/-! Exact target language for the complete rotational count theorem.
`sharpRotationalCountStatement` specifies the target; `RotationalMain` proves it.
The complex plane carries its standard Euclidean norm and real topology.
-/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

/-- Clockwise planar rotation, with angle measured in radians. -/
def rotateClockwise (t : ℝ) (z : ℂ) : ℂ :=
  ⟨Real.cos t * z.re + Real.sin t * z.im,
    -Real.sin t * z.re + Real.cos t * z.im⟩

/-- Strict comparison against every distinct labeled permutation. -/
def UniqueMinimum {ι V : Type*} [Fintype ι] [NormedAddCommGroup V]
    (a b : ι → V) (σ : Equiv.Perm ι) : Prop :=
  ∀ τ, τ ≠ σ → assignmentCost a b σ < assignmentCost a b τ

/-- All labeled assignments uniquely optimal at some real rotation angle. -/
def rotationOptimizers {n : ℕ} (a b : Fin n → ℂ) : Finset (Equiv.Perm (Fin n)) :=
  by
    classical
    exact Finset.univ.filter fun σ => ∃ t : ℝ, UniqueMinimum a (rotateClockwise t ∘ b) σ

/-- The number of distinct assignments, not the number of witness times. -/
def rotationCount {n : ℕ} (a b : Fin n → ℂ) : ℕ := (rotationOptimizers a b).card

/-- Noncollinearity: an actual triple has nonzero oriented area. -/
def NoncollinearList {n : ℕ} (a : Fin n → ℂ) : Prop :=
  ∃ i j k, (a j - a i).re * (a k - a i).im -
    (a j - a i).im * (a k - a i).re ≠ 0

/-- Full source target, geometry.tex:469-475. This definition supplies no proof. -/
def sharpRotationalCountStatement : Prop :=
  (∀ n : ℕ, 2 ≤ n → ∀ a b : Fin n → ℂ, rotationCount a b ≤ n * (n - 1)) ∧
  (∀ n : ℕ, 2 ≤ n → ∃ a b : Fin n → ℂ, rotationCount a b = n * (n - 1)) ∧
  (∀ n : ℕ, 3 ≤ n → ∃ U : Set ((Fin n → ℂ) × (Fin n → ℂ)),
    IsOpen U ∧ U.Nonempty ∧ ∀ p ∈ U,
      NoncollinearList p.1 ∧ NoncollinearList p.2 ∧ rotationCount p.1 p.2 = n * (n - 1)) ∧
  (∀ a b : Fin 1 → ℂ, rotationCount a b = 1)

@[simp] theorem rotateClockwise_zero (z : ℂ) : rotateClockwise 0 z = z := by
  apply Complex.ext <;> simp [rotateClockwise]

@[simp] theorem rotateClockwise_pi (z : ℂ) : rotateClockwise Real.pi z = -z := by
  apply Complex.ext <;> simp [rotateClockwise]

@[simp] theorem mem_rotationOptimizers {n : ℕ} (a b : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) :
    σ ∈ rotationOptimizers a b ↔ ∃ t : ℝ, UniqueMinimum a (rotateClockwise t ∘ b) σ := by
  simp [rotationOptimizers]

section RepeatedTargets
variable {ι V : Type*} [Fintype ι] [DecidableEq ι] [NormedAddCommGroup V]

omit [Fintype ι] [NormedAddCommGroup V] in
/-- A target-label swap preserves the target function when the two values coincide. -/
theorem target_swap_eq (b : ι → V) {i j : ι} (h : b i = b j) (k : ι) :
    b (Equiv.swap i j k) = b k := by
  by_cases hi : k = i
  · subst k; simp [h]
  by_cases hj : k = j
  · subst k; simp [h]
  simp [Equiv.swap_apply_of_ne_of_ne hi hj]

/-- Every assignment has a distinct equal-cost competitor if two target labels coincide. -/
theorem repeated_target_competitor (a b : ι → V) {i j : ι}
    (hij : i ≠ j) (h : b i = b j) (σ : Equiv.Perm ι) :
    ∃ τ : Equiv.Perm ι, τ ≠ σ ∧ assignmentCost a b τ = assignmentCost a b σ := by
  refine ⟨σ.trans (Equiv.swap i j), ?_, ?_⟩
  · intro he
    have hh := congrArg (fun e : Equiv.Perm ι => e (σ.symm i)) he
    have : j = i := by simpa using hh
    exact hij this.symm
  · unfold assignmentCost
    apply Finset.sum_congr rfl
    intro k _
    simp only [Equiv.trans_apply, target_swap_eq b h]

/-- Coincident target labels rule out unique optimality, without any source assumption. -/
theorem not_uniqueMinimum_of_repeated_target (a b : ι → V) {i j : ι}
    (hij : i ≠ j) (h : b i = b j) (σ : Equiv.Perm ι) : ¬ UniqueMinimum a b σ := by
  obtain ⟨τ, hτ, he⟩ := repeated_target_competitor a b hij h σ
  intro hs
  have hh := hs τ hτ
  rw [he] at hh
  exact (lt_irrefl _ hh)
end RepeatedTargets

/-- The repeated-target branch of the rotational theorem has zero unique optima. -/
theorem rotationCount_eq_zero_of_repeated_target {n : ℕ} (a b : Fin n → ℂ)
    {i j : Fin n} (hij : i ≠ j) (h : b i = b j) : rotationCount a b = 0 := by
  have hempty : rotationOptimizers a b = ∅ := by
    apply Finset.eq_empty_iff_forall_notMem.mpr
    intro σ hs
    obtain ⟨t, ht⟩ := (mem_rotationOptimizers a b σ).mp hs
    exact not_uniqueMinimum_of_repeated_target a (rotateClockwise t ∘ b) hij
      (congrArg (rotateClockwise t) h) σ ht
  simp [rotationCount, hempty]

/-- With one label there is exactly one optimizer, for every pair of planar lists. -/
theorem rotationCount_one (a b : Fin 1 → ℂ) : rotationCount a b = 1 := by
  have hfull : rotationOptimizers a b = Finset.univ := by
    ext σ
    simp only [mem_rotationOptimizers, Finset.mem_univ, iff_true]
    refine ⟨0, ?_⟩
    intro τ hτ
    exact (hτ (Subsingleton.elim _ _)).elim
  simp [rotationCount, hfull]

end MonotoneMatching
