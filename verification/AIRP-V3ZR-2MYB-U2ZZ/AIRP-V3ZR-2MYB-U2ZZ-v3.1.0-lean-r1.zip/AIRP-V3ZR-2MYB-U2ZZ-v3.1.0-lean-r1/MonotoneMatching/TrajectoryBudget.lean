import MonotoneMatching.TrajectoryCells
import MonotoneMatching.TrajectoryPhase
import MonotoneMatching.CyclicCells
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

/-- Any global physical lift of a clockwise periodic pair has a nonnegative
integer period decrement. -/
theorem global_clockwise_lift_increment (γ v : ℝ → ℂ) (φ : ℝ → ℝ)
    (T : ℝ) (hT : 0 < T) (hc : Continuous φ) (hn : ∀ t, γ t ≠ 0)
    (he : ∀ t, (φ t : Real.Angle) = (Complex.arg (γ t) : Real.Angle))
    (hd : ∀ t, HasDerivAt γ (v t) t) (hp : γ T=γ 0)
    (hdet : ∀ t, (γ t).re*(v t).im-(γ t).im*(v t).re ≤ 0) :
    ∃ w : ℕ, φ T-φ 0= -(2*Real.pi)*(w : ℝ) := by
  have ha := argument_lift_deriv_nonpos γ φ v hc hn he hd hdet
  have hz : ((φ 0-φ T : ℝ) : Real.Angle)=0 := by
    rw [Real.Angle.coe_sub,he,he,hp,sub_self]
  obtain ⟨k,hk⟩ := Real.Angle.coe_eq_zero_iff.mp hz
  have hk' : φ 0-φ T=(k : ℝ)*(2*Real.pi) := by simpa only [zsmul_eq_mul] using hk.symm
  have hkn : 0 ≤ k := by
    have hh : (0 : ℝ) ≤ k := (mul_nonneg_iff_of_pos_right Real.two_pi_pos).mp
      (hk' ▸ sub_nonneg.mpr (ha hT.le))
    exact_mod_cast hh
  refine ⟨k.toNat,?_⟩
  have heq : (k.toNat : ℝ)=(k : ℝ) := by exact_mod_cast Int.toNat_of_nonneg hkn
  rw [heq]
  linarith

/-- Exact real jump accounting on any realized optimal trajectory subdivision.
No orientation or charge positivity is assumed in this identity. -/
theorem realized_trajectory_phase_budget {n m : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (φ : Fin n → Fin n → ℝ → ℝ)
    (ha : Function.Injective a) (hb : ∀ i, Continuous (b i))
    (hn : ∀ i j, i ≠ j → ∀ t, b i t ≠ b j t)
    (hφ : ∀ i j, Continuous (φ i j)) (hzero : ∀ i t, φ i i t=0)
    (he : ∀ i j, i ≠ j → ∀ t,
      (φ i j t : Real.Angle) = (Complex.arg (b j t-b i t) : Real.Angle))
    (T : ℝ) (w : Fin n × Fin n → ℕ)
    (hw : ∀ p ∈ increasingPairs n, φ p.1 p.2 T-φ p.1 p.2 0= -(2*Real.pi)*(w p : ℝ))
    (cut : Fin (m+1) → ℝ) (label : Fin m → Equiv.Perm (Fin n))
    (hmono : StrictMono cut) (hfirst : cut 0=0) (hlast : cut (Fin.last m)=T)
    (hopt : ∀ i, ∀ t ∈ Set.Icc (cut i.castSucc) (cut i.succ), ∀ τ,
      assignmentScore a (fun j => b j t) τ ≤ assignmentScore a (fun j => b j t) (label i)) :
    (∑ i, (identityPhase a (fun j => b (label (finRotate m i) j) (cut (finRotate m i).castSucc))-
      identityPhase a (fun j => b (label i j) (cut i.succ)))) =
      2*Real.pi*∑ p ∈ increasingPairs n, (w p : ℝ) := by
  rw [cyclic_phase_balance (finRotate m)
    (fun i => identityPhase a (fun j => b (label i j) (cut i.castSucc)))
    (fun i => identityPhase a (fun j => b (label i j) (cut i.succ)))]
  have hcell (i : Fin m) := identityPhase_trajectory_relabel_transport a b φ ha hb hn hφ
    hzero he (label i) isPreconnected_Icc (hopt i)
    (Set.left_mem_Icc.mpr (hmono i.castSucc_lt_succ).le)
    (Set.right_mem_Icc.mpr (hmono i.castSucc_lt_succ).le)
  simp_rw [hcell]
  rw [Finset.sum_comm]
  have htel (p : Fin n × Fin n) :
      (∑ i : Fin m, (φ p.1 p.2 (cut i.succ)-φ p.1 p.2 (cut i.castSucc)))=
      φ p.1 p.2 T-φ p.1 p.2 0 := by
    simpa only [hfirst,hlast] using subdivision_duration_sum (fun i => φ p.1 p.2 (cut i))
  simp_rw [htel]
  rw [Finset.sum_congr rfl hw,← Finset.mul_sum]
  ring

/-- The period seam gives the same instantaneous configuration for every label. -/
theorem trajectory_phase_subdivision_seam {n m : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (T : ℝ) (hp : ∀ i, Function.Periodic (b i) T)
    (hm : 0 < m) (cut : Fin (m+1) → ℝ) (hfirst : cut 0=0)
    (hlast : cut (Fin.last m)=T) (σ : Equiv.Perm (Fin n)) (i : Fin m) :
    identityPhase a (fun j => b (σ j) (cut (finRotate m i).castSucc))=
      identityPhase a (fun j => b (σ j) (cut i.succ)) := by
  apply periodic_subdivision_seam hm cut hfirst hlast
    (fun t => identityPhase a (fun j => b (σ j) t)) _ i
  intro t
  change identityPhase a (fun j => b (σ j) (t+T))=identityPhase a (fun j => b (σ j) t)
  congr 1
  funext j
  exact hp (σ j) t

/-- Actual clockwise periodic trajectories supply the full simultaneous lift
and nonnegative integral winding data used in the real phase budget. -/
theorem exists_trajectory_winding_lifts {n : ℕ} (b v : Fin n → ℝ → ℂ)
    (T : ℝ) (hT : 0 < T) (hd : ∀ i t, HasDerivAt (b i) (v i t) t)
    (hp : ∀ i, Function.Periodic (b i) T)
    (hn : ∀ i j, i ≠ j → ∀ t, b i t ≠ b j t)
    (hdet : ∀ i j, i < j → ∀ t,
      (b j t-b i t).re*(v j t-v i t).im-(b j t-b i t).im*(v j t-v i t).re ≤ 0) :
    ∃ φ : Fin n → Fin n → ℝ → ℝ, ∃ w : Fin n × Fin n → ℕ,
      (∀ i j, Continuous (φ i j)) ∧ (∀ i t, φ i i t=0) ∧
      (∀ i j, i ≠ j → ∀ t,
        (φ i j t : Real.Angle) = (Complex.arg (b j t-b i t) : Real.Angle)) ∧
      (∀ p ∈ increasingPairs n, φ p.1 p.2 T-φ p.1 p.2 0= -(2*Real.pi)*(w p : ℝ)) := by
  classical
  obtain ⟨φ,hφ,hzero,he⟩ := exists_trajectory_pair_lifts b
    (fun i => continuous_iff_continuousAt.mpr fun t => (hd i t).continuousAt) hn
  have hex (p : Fin n × Fin n) : ∃ w : ℕ, p ∈ increasingPairs n →
      φ p.1 p.2 T-φ p.1 p.2 0= -(2*Real.pi)*(w : ℝ) := by
    by_cases hh : p ∈ increasingPairs n
    · have hlt : p.1 < p.2 := (Finset.mem_filter.mp hh).2
      obtain ⟨w,hw⟩ := global_clockwise_lift_increment
        (fun t => b p.2 t-b p.1 t) (fun t => v p.2 t-v p.1 t) (φ p.1 p.2)
        T hT (hφ _ _) (fun t => sub_ne_zero.mpr (hn _ _ hlt.ne.symm t))
        (he _ _ hlt.ne) (fun t => (hd p.2 t).sub (hd p.1 t))
        (by simpa only [zero_add] using congrArg₂ (fun x y : ℂ => x-y) (hp p.2 0) (hp p.1 0))
        (hdet _ _ hlt)
      exact ⟨w,fun _ => hw⟩
    · exact ⟨0,fun h => False.elim (hh h)⟩
  choose w hw using hex
  exact ⟨φ,w,hφ,hzero,he,hw⟩

end MonotoneMatching
