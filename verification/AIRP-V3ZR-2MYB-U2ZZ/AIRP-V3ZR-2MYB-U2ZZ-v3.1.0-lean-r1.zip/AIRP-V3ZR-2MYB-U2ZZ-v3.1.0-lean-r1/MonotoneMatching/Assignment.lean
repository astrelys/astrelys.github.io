import Mathlib.Analysis.InnerProductSpace.Basic
import Mathlib.Tactic.Linarith

/-! # Assignment costs and scores

Foundational translation for the squared-distance matching objective in
AIRP-V3ZR-2MYB-U2ZZ v3.1.0, Introduction. The index type is finite and the
ambient space is any real inner product space; the paper is the instance
`ι = Fin n`, `V = EuclideanSpace ℝ (Fin 2)`.
-/

namespace MonotoneMatching

open scoped BigOperators InnerProductSpace

variable {ι V : Type*} [Fintype ι] [NormedAddCommGroup V] [InnerProductSpace ℝ V]

/-- Squared Euclidean assignment cost, with labels retained. -/
def assignmentCost (a b : ι → V) (σ : Equiv.Perm ι) : ℝ :=
  ∑ i, ‖a i - b (σ i)‖ ^ 2

/-- The inner-product score maximized in the manuscript. -/
def assignmentScore (a b : ι → V) (σ : Equiv.Perm ι) : ℝ :=
  ∑ i, ⟪a i, b (σ i)⟫_ℝ

omit [InnerProductSpace ℝ V] in
/-- Permuting labels preserves the target norm sum, without any rigid-motion assumption. -/
theorem target_norm_sum_invariant (b : ι → V) (σ : Equiv.Perm ι) :
    (∑ i, ‖b (σ i)‖ ^ 2) = ∑ i, ‖b i‖ ^ 2 :=
  Equiv.sum_comp σ (fun i => ‖b i‖ ^ 2)

/-- The permutation-dependent part of squared-distance cost is minus twice the score. -/
theorem assignmentCost_eq (a b : ι → V) (σ : Equiv.Perm ι) :
    assignmentCost a b σ = (∑ i, ‖a i‖ ^ 2) + (∑ i, ‖b i‖ ^ 2) -
      2 * assignmentScore a b σ := by
  simp only [assignmentCost, assignmentScore, norm_sub_sq_real, Finset.sum_add_distrib,
    Finset.sum_sub_distrib, ← Finset.mul_sum, target_norm_sum_invariant]
  ring

/-- Every pairwise cost comparison is exactly the reverse score comparison. -/
theorem assignmentCost_le_iff_score_ge (a b : ι → V) (σ τ : Equiv.Perm ι) :
    assignmentCost a b σ ≤ assignmentCost a b τ ↔
      assignmentScore a b τ ≤ assignmentScore a b σ := by
  rw [assignmentCost_eq, assignmentCost_eq]
  constructor <;> intro h <;> linarith

/-- Strict comparisons, hence strict witness gaps, are preserved as well. -/
theorem assignmentCost_lt_iff_score_gt (a b : ι → V) (σ τ : Equiv.Perm ι) :
    assignmentCost a b σ < assignmentCost a b τ ↔
      assignmentScore a b τ < assignmentScore a b σ := by
  rw [assignmentCost_eq, assignmentCost_eq]
  constructor <;> intro h <;> linarith

/-- Global optimization ranges over all labeled permutations. -/
theorem minimizes_cost_iff_maximizes_score (a b : ι → V) (σ : Equiv.Perm ι) :
    (∀ τ, assignmentCost a b σ ≤ assignmentCost a b τ) ↔
      (∀ τ, assignmentScore a b τ ≤ assignmentScore a b σ) := by
  simp only [assignmentCost_le_iff_score_ge]

/-- Unique optimality is translated using strict comparisons with every other permutation. -/
theorem uniquely_minimizes_cost_iff_uniquely_maximizes_score
    (a b : ι → V) (σ : Equiv.Perm ι) :
    (∀ τ, τ ≠ σ → assignmentCost a b σ < assignmentCost a b τ) ↔
      (∀ τ, τ ≠ σ → assignmentScore a b τ < assignmentScore a b σ) := by
  simp only [assignmentCost_lt_iff_score_gt]

end MonotoneMatching
