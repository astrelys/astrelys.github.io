import MonotoneMatching.TransitionCells
import MonotoneMatching.PolygonCollar

/-! Convex dual cells transport a polygon's side index along an entire edge. -/
noncomputable section
namespace MonotoneMatching
open scoped InnerProductSpace

def strictDualCell {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ) (i : Fin n) : Set ℂ :=
  {q | ∀ j, j≠i → dualRow a r j q<dualRow a r i q}

theorem convex_strictDualCell {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ) (i : Fin n) :
    Convex ℝ (strictDualCell a r i) := by
  intro x hx y hy s t hs ht hst j hj
  have he : s=1-t := by linarith
  rw [he,dualRow_combination,dualRow_combination]
  have h1 := hx j hj
  have h2 := hy j hj
  have hp : 0≤1-t := by linarith
  by_cases ht0 : t=0
  · simpa only [ht0,sub_zero,one_smul,zero_mul,one_mul,add_zero] using h1
  · have hpos := mul_pos (lt_of_le_of_ne ht (Ne.symm ht0)) (sub_pos.mpr h2)
    have hnonneg := mul_nonneg hp (sub_nonneg.mpr h1.le)
    nlinarith

theorem strictDualCell_disjoint {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ)
    {i j : Fin n} (hij : i≠j) : Disjoint (strictDualCell a r i) (strictDualCell a r j) := by
  apply Set.disjoint_left.mpr
  intro q hi hj
  exact (not_lt_of_gt (hi j hij.symm)) (hj i hij)

/-- Any convex region inside a row's strict cell and on one side of its
edge has constant winding, once the boundary-cell incidence is known. -/
theorem polygonIndexPhase_dual_cell_left {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (verts : ι → ℂ) {n : ℕ}
    (a : Fin n → ℂ) (r : Fin n → ℝ) (i : Fin n) (z w : ℂ)
    (hboundary : ∀ q ∈ strictDualCell a r i,
      q ∈ polygonBoundary next verts → q ∈ segment ℝ z w)
    {x y : ℂ} (hx : x∈strictDualCell a r i) (hy : y∈strictDualCell a r i)
    (hxs : 0<edgeSide z w x) (hys : 0<edgeSide z w y) :
    polygonIndexPhase next verts x=polygonIndexPhase next verts y := by
  apply polygonIndexPhase_eq_on_connected next verts
    ((convex_strictDualCell a r i).inter (convex_edgeSide_pos z w)).isPreconnected _
    ⟨hx,hxs⟩ ⟨hy,hys⟩
  intro q hq hb
  exact (ne_of_gt hq.2) (edgeSide_eq_zero_on_segment z w (hboundary q hq.1 hb))

theorem polygonIndexPhase_dual_cell_right {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (verts : ι → ℂ) {n : ℕ}
    (a : Fin n → ℂ) (r : Fin n → ℝ) (i : Fin n) (z w : ℂ)
    (hboundary : ∀ q ∈ strictDualCell a r i,
      q ∈ polygonBoundary next verts → q ∈ segment ℝ z w)
    {x y : ℂ} (hx : x∈strictDualCell a r i) (hy : y∈strictDualCell a r i)
    (hxs : edgeSide z w x<0) (hys : edgeSide z w y<0) :
    polygonIndexPhase next verts x=polygonIndexPhase next verts y := by
  apply polygonIndexPhase_eq_on_connected next verts
    ((convex_strictDualCell a r i).inter (convex_edgeSide_neg z w)).isPreconnected _
    ⟨hx,hxs⟩ ⟨hy,hys⟩
  intro q hq hb
  exact (ne_of_lt hq.2) (edgeSide_eq_zero_on_segment z w (hboundary q hq.1 hb))

end MonotoneMatching
