import MonotoneMatching.VandermondePhase
import MonotoneMatching.TransitionCells

/-! Exact principal-angle increments for collision-free transition bridges. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators InnerProductSpace

/-- Both endpoints in the open right half-plane have an unambiguous argument
increment in (-π,π). -/
theorem arg_div_eq_sub_of_re_pos {z w : ℂ} (hz : 0 < z.re) (hw : 0 < w.re) :
    (w/z).arg = w.arg - z.arg := by
  have hzn : z ≠ 0 := by intro h; simp [h] at hz
  have hwn : w ≠ 0 := by intro h; simp [h] at hw
  have hbz := (Complex.abs_arg_lt_pi_div_two_iff.mpr (Or.inl hz))
  have hbw := (Complex.abs_arg_lt_pi_div_two_iff.mpr (Or.inl hw))
  have hbounds : -(Real.pi) < w.arg-z.arg ∧ w.arg-z.arg ≤ Real.pi := by
    rw [abs_lt] at hbz hbw
    constructor <;> linarith
  have h := congrArg Real.Angle.toReal (Complex.arg_div_coe_angle hwn hzn)
  rw [Complex.arg_coe_angle_toReal_eq_arg, ← Real.Angle.coe_sub,
    Real.Angle.toReal_coe_eq_self_iff.mpr hbounds] at h
  exact h

/-- A weaker cone that remains strict at long-cycle optimal ties. -/
def StrictPairMonotone {n : ℕ} (a y : Fin n → ℂ) : Prop :=
  ∀ i j : Fin n, i ≠ j → 0 < inner ℝ (a i-a j) (y i-y j)

theorem unique_identity_strictPairMonotone {n : ℕ} (a y : Fin n → ℂ)
    (h : UniqueMinimum a y (Equiv.refl _)) : StrictPairMonotone a y :=
  unique_identity_pair_positive a y h

/-- For any two configurations in the same strict pair cone, the exact real
phase difference equals the sum of the straight pairwise angle increments. -/
theorem identityPhase_difference {n : ℕ} (a y z : Fin n → ℂ)
    (hy : StrictPairMonotone a y) (hz : StrictPairMonotone a z) :
    identityPhase a z - identityPhase a y =
      ∑ p ∈ increasingPairs n, Complex.arg ((z p.2-z p.1)/(y p.2-y p.1)) := by
  classical
  rw [identityPhase, identityPhase, ← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro p hp
  have hp' : p.2 ≠ p.1 := (ne_of_lt (Finset.mem_filter.mp hp).2).symm
  have hy' : 0 < ((y p.2-y p.1)*(starRingEnd ℂ) (a p.2-a p.1)).re := hy _ _ hp'
  have hz' : 0 < ((z p.2-z p.1)*(starRingEnd ℂ) (a p.2-a p.1)).re := hz _ _ hp'
  have ha : (starRingEnd ℂ) (a p.2-a p.1) ≠ 0 := by
    intro h
    rw [h,mul_zero] at hy'
    exact lt_irrefl 0 hy'
  rw [← arg_div_eq_sub_of_re_pos hy' hz']
  congr 1
  exact mul_div_mul_right _ _ ha

/-- At a two-optimum tie whose nonidentity permutation moves at least three
labels, every transposition has a strict score gap. -/
theorem long_tie_strictPairMonotone {n : ℕ} (a y : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (hlen : 3 ≤ σ.support.card)
    (hmax : ∀ τ : Equiv.Perm (Fin n), assignmentScore a y τ ≤ assignmentScore a y (Equiv.refl _))
    (htwo : ∀ τ : Equiv.Perm (Fin n),
      assignmentScore a y τ = assignmentScore a y (Equiv.refl _) →
      τ = Equiv.refl _ ∨ τ = σ) : StrictPairMonotone a y := by
  intro i j hij
  have hn0 : Equiv.swap i j ≠ Equiv.refl _ := by
    intro h
    have hi := congrArg (fun π : Equiv.Perm (Fin n) => π i) h
    exact hij (by simpa using hi.symm)
  have hnσ : Equiv.swap i j ≠ σ := by
    intro h
    have hc : σ.support.card = 2 := by rw [← h, Equiv.Perm.card_support_swap hij]
    omega
  have hs : assignmentScore a y (Equiv.swap i j) < assignmentScore a y (Equiv.refl _) := by
    by_contra h
    have he := le_antisymm (hmax _) (le_of_not_gt h)
    rcases htwo _ he with h | h
    · exact hn0 h
    · exact hnσ h
  rw [← score_swap_difference a y i j hij]
  exact sub_pos.mpr hs

theorem assignmentScore_relabel_targets {n : ℕ} (a y : Fin n → ℂ)
    (σ τ : Equiv.Perm (Fin n)) :
    assignmentScore a (y ∘ σ) τ = assignmentScore a y (σ*τ) := rfl

/-- Both limiting endpoint configurations of a long optimal transition belong
to the same strict pair cone. -/
theorem long_tie_relabel_strictPairMonotone {n : ℕ} (a y : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (hlen : 3 ≤ σ.support.card)
    (hmax : ∀ τ : Equiv.Perm (Fin n), assignmentScore a y τ ≤ assignmentScore a y (Equiv.refl _))
    (heq : assignmentScore a y σ = assignmentScore a y (Equiv.refl _))
    (htwo : ∀ τ : Equiv.Perm (Fin n),
      assignmentScore a y τ = assignmentScore a y (Equiv.refl _) →
      τ = Equiv.refl _ ∨ τ = σ) : StrictPairMonotone a (y ∘ σ) := by
  apply long_tie_strictPairMonotone a (y ∘ σ) σ⁻¹
    (by simpa only [Equiv.Perm.support_inv] using hlen)
  · intro τ
    rw [assignmentScore_relabel_targets, assignmentScore_relabel_targets]
    change assignmentScore a y (σ*τ) ≤ assignmentScore a y (σ*1)
    rw [mul_one,heq]
    exact hmax _
  · intro τ h
    rw [assignmentScore_relabel_targets, assignmentScore_relabel_targets] at h
    change assignmentScore a y (σ*τ) = assignmentScore a y (σ*1) at h
    rw [mul_one,heq] at h
    rcases htwo _ h with h | h
    · right
      have he : σ*τ = 1 := h
      have hh := congrArg (fun π => σ⁻¹ * π) he
      simpa [← mul_assoc] using hh
    · left
      have he : σ*τ = σ*1 := by simpa using h
      exact mul_left_cancel he

/-- The discriminant-angle lift extends to the strict pair cone, including
long-cycle tie endpoints. -/
theorem identityPhase_coe_angle_of_pair {n : ℕ} (a y : Fin n → ℂ)
    (hy : StrictPairMonotone a y) :
    (identityPhase a y : Real.Angle) =
      (Complex.arg (configurationVandermonde y *
        (starRingEnd ℂ) (configurationVandermonde a)) : Real.Angle) := by
  classical
  have hnz : ∀ p ∈ increasingPairs n,
      (y p.2-y p.1)*(starRingEnd ℂ) (a p.2-a p.1) ≠ 0 := by
    intro p hp hz
    have h : 0 < ((y p.2-y p.1)*(starRingEnd ℂ) (a p.2-a p.1)).re :=
      hy _ _ (ne_of_lt (Finset.mem_filter.mp hp).2).symm
    rw [hz] at h
    exact lt_irrefl 0 h
  change Real.Angle.coeHom (∑ p ∈ increasingPairs n,
    Complex.arg ((y p.2-y p.1)*(starRingEnd ℂ) (a p.2-a p.1))) = _
  rw [map_sum]
  change (∑ p ∈ increasingPairs n,
    (Complex.arg ((y p.2-y p.1)*(starRingEnd ℂ) (a p.2-a p.1)) : Real.Angle)) = _
  rw [← arg_prod_coe_angle _ _ hnz]
  congr 2
  rw [Finset.prod_mul_distrib, configurationVandermonde_product,
    configurationVandermonde_product, map_prod]

theorem strictPairMonotone_injective_left {n : ℕ} (a y : Fin n → ℂ)
    (h : StrictPairMonotone a y) : Function.Injective a := by
  intro i j he
  by_contra hn
  have hp := h i j hn
  rw [he,sub_self,inner_zero_left] at hp
  exact lt_irrefl 0 hp

theorem strictPairMonotone_injective_right {n : ℕ} (a y : Fin n → ℂ)
    (h : StrictPairMonotone a y) : Function.Injective y := by
  intro i j he
  by_contra hn
  have hp := h i j hn
  rw [he,sub_self,inner_zero_right] at hp
  exact lt_irrefl 0 hp

/-- A relabeling bridge in a strict pair cone has an exact integral multiple
of π as its real phase increment. Positivity is a separate obligation. -/
theorem permutation_phase_integer {n : ℕ} (a y : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (hy : StrictPairMonotone a y)
    (hz : StrictPairMonotone a (y ∘ σ)) :
    ∃ k : ℤ, identityPhase a (y ∘ σ) - identityPhase a y = k * Real.pi := by
  let Z := configurationVandermonde y * (starRingEnd ℂ) (configurationVandermonde a)
  have hZ : Z ≠ 0 := by
    apply mul_ne_zero
    · exact (configurationVandermonde_ne_zero_iff y).mpr
        (strictPairMonotone_injective_right a y hy)
    · simpa using (configurationVandermonde_ne_zero_iff a).mpr
        (strictPairMonotone_injective_left a y hy)
  have hya := identityPhase_coe_angle_of_pair a y hy
  have hza := identityPhase_coe_angle_of_pair a (y ∘ σ) hz
  let D := identityPhase a (y ∘ σ) - identityPhase a y
  have hD : (D : Real.Angle) = 0 ∨ (D : Real.Angle) = (Real.pi : Real.Angle) := by
    rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with hs | hs
    · left
      dsimp [D]
      rw [hza,hya,configurationVandermonde_permute]
      simp [hs]
    · right
      dsimp [D]
      rw [hza,hya,configurationVandermonde_permute]
      have hh := Complex.arg_neg_coe_angle hZ
      simpa [hs,Z] using congrArg (fun θ : Real.Angle => θ - (Z.arg : Real.Angle)) hh
  rcases hD with h | h
  · obtain ⟨k,hk⟩ := Real.Angle.coe_eq_zero_iff.mp h
    refine ⟨2*k, ?_⟩
    change D = _
    simp only [zsmul_eq_mul] at hk
    push_cast
    nlinarith
  · have he : ((D-Real.pi : ℝ) : Real.Angle) = 0 := by
      rw [Real.Angle.coe_sub,h,sub_self]
    obtain ⟨k,hk⟩ := Real.Angle.coe_eq_zero_iff.mp he
    refine ⟨2*k+1, ?_⟩
    change D = _
    simp only [zsmul_eq_mul] at hk
    push_cast
    nlinarith

end MonotoneMatching
