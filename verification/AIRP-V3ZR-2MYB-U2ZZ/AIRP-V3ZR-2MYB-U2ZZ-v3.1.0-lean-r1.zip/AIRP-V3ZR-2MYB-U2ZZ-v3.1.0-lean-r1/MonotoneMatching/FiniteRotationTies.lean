import MonotoneMatching.GenericRotationSources
import MonotoneMatching.VandermondePhase
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Complex
import Mathlib.Data.Int.Interval

/-! General-position rotations have finitely many transverse pair ties and no triple ties. -/
noncomputable section
namespace MonotoneMatching

theorem directionalScore_eq_norm_cos (z : ℂ) (t : ℝ) :
    directionalScore z t = ‖z‖ * Real.cos (t-z.arg) := by
  rw [Real.cos_sub]
  dsimp [directionalScore]
  rw [← Complex.norm_mul_cos_arg z, ← Complex.norm_mul_sin_arg z]
  ring

/-- A nonzero sinusoidal coefficient has finitely many zeros on one closed period. -/
theorem finite_directionalScore_zeros {z : ℂ} (hz : z ≠ 0) :
    Set.Finite {t : ℝ | t ∈ Set.Icc 0 (2*Real.pi) ∧ directionalScore z t = 0} := by
  apply ((Set.finite_Icc (-5 : ℤ) 5).image
    (fun k : ℤ => z.arg + (2*k+1)*Real.pi/2)).subset
  intro t ht
  change t ∈ Set.Icc 0 (2*Real.pi) ∧ directionalScore z t = 0 at ht
  have hcos : Real.cos (t-z.arg) = 0 := by
    rw [directionalScore_eq_norm_cos] at ht
    exact (mul_eq_zero.mp ht.2).resolve_left (norm_ne_zero_iff.mpr hz)
  obtain ⟨k,hk⟩ := Real.cos_eq_zero_iff.mp hcos
  have harg0 := Complex.neg_pi_lt_arg z
  have harg1 := Complex.arg_le_pi z
  have hpi := Real.pi_pos
  have hklo : (-5 : ℝ) ≤ (k : ℝ) := by nlinarith [ht.1.1, ht.1.2]
  have hkhi : (k : ℝ) ≤ 5 := by nlinarith [ht.1.1, ht.1.2]
  refine ⟨k, ⟨by exact_mod_cast hklo, by exact_mod_cast hkhi⟩, ?_⟩
  linarith

/-- All pair-score ties in one period form a finite set for generic sources. -/
theorem finite_generic_rotation_ties {n : ℕ} (a b : Fin n → ℂ)
    (ha : GenericRotationSources b a) :
    Set.Finite {t : ℝ | t ∈ Set.Icc 0 (2*Real.pi) ∧
      ∃ σ τ : Equiv.Perm (Fin n), σ ≠ τ ∧
        assignmentScore a (rotateClockwise t ∘ b) σ =
          assignmentScore a (rotateClockwise t ∘ b) τ} := by
  have hf (σ τ : Equiv.Perm (Fin n)) :
      Set.Finite {t : ℝ | t ∈ Set.Icc 0 (2*Real.pi) ∧ σ ≠ τ ∧
        assignmentScore a (rotateClockwise t ∘ b) σ =
          assignmentScore a (rotateClockwise t ∘ b) τ} := by
    by_cases h : σ = τ
    · simp [h]
    · apply (finite_directionalScore_zeros (sub_ne_zero.mpr (ha.1 σ τ h))).subset
      intro t ht
      refine ⟨ht.1, ?_⟩
      rw [directionalScore_sub]
      exact sub_eq_zero.mpr (by simpa only [assignmentScore_rotation_coefficient] using ht.2.2)
  apply (Set.finite_iUnion (fun σ => Set.finite_iUnion (hf σ))).subset
  rintro t ⟨ht,σ,τ,hne,he⟩
  exact Set.mem_iUnion.mpr ⟨σ,Set.mem_iUnion.mpr ⟨τ,ht,hne,he⟩⟩

/-- A score tie can involve at most two distinct labelings for generic sources. -/
theorem generic_rotation_no_triple_tie {n : ℕ} (a b : Fin n → ℂ)
    (ha : GenericRotationSources b a) (t : ℝ) {σ τ ρ : Equiv.Perm (Fin n)}
    (hστ : σ ≠ τ)
    (h1 : assignmentScore a (rotateClockwise t ∘ b) σ =
      assignmentScore a (rotateClockwise t ∘ b) τ)
    (h2 : assignmentScore a (rotateClockwise t ∘ b) σ =
      assignmentScore a (rotateClockwise t ∘ b) ρ) : ρ = σ ∨ ρ = τ := by
  by_contra hn
  push Not at hn
  have hne := ha.2 σ τ ρ hστ hn.1.symm hn.2.symm
  have hu : directionalScore (complexAssignmentScore a b τ - complexAssignmentScore a b σ) t = 0 := by
    rw [directionalScore_sub]
    exact sub_eq_zero.mpr (by simpa only [assignmentScore_rotation_coefficient] using h1.symm)
  have hv : directionalScore (complexAssignmentScore a b ρ - complexAssignmentScore a b σ) t = 0 := by
    rw [directionalScore_sub]
    exact sub_eq_zero.mpr (by simpa only [assignmentScore_rotation_coefficient] using h2.symm)
  have hdet := directionalScore_common_zero_determinant hu hv
  apply hne
  dsimp [scoreCoefficientDet]
  simp only [Complex.mul_im, Complex.conj_re, Complex.conj_im]
  linarith

end MonotoneMatching
