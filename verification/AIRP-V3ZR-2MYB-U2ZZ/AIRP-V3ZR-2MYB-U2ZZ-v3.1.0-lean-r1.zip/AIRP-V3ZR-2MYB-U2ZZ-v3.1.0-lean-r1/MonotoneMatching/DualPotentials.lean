import MonotoneMatching.WeightedPaths
import Mathlib.Data.Finset.Max

/-! Assignment dual potentials constructed from finite simple paths. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

/-- Nonpositive simple closed walks admit a potential dominating every edge.
The maximum is over a finite set of simple paths, never over an unbounded walk set. -/
theorem exists_edge_potential {α : Type*} [Fintype α] [DecidableEq α]
    (d : α → α → ℝ)
    (hcycle : ∀ a : α, ∀ l : List α, (a::l).Nodup → walkWeight d ((a::l) ++ [a]) ≤ 0) :
    ∃ c : α → ℝ, ∀ i j, d i j ≤ c j - c i := by
  classical
  let paths (j : α) : Finset {l : List α // l.Nodup} :=
    Finset.univ.filter (fun p => p.val.getLast? = some j)
  have hp (j : α) : (paths j).Nonempty := by
    refine ⟨⟨[j],by simp⟩, ?_⟩
    simp [paths]
  have hmax (j : α) : ∃ p : {l : List α // l.Nodup},
      p.val.getLast? = some j ∧ ∀ q : {l : List α // l.Nodup},
        q.val.getLast? = some j → walkWeight d q.val ≤ walkWeight d p.val := by
    obtain ⟨p,hp',hm⟩ := Finset.exists_max_image (paths j) (fun p => walkWeight d p.val) (hp j)
    refine ⟨p,(Finset.mem_filter.mp hp').2, ?_⟩
    intro q hq
    exact hm q (Finset.mem_filter.mpr ⟨Finset.mem_univ _,hq⟩)
  choose p hp hmax using hmax
  refine ⟨fun i => walkWeight d (p i).val, ?_⟩
  intro i j
  obtain ⟨tail,htail⟩ := List.getLast?_eq_some_iff.mp (hp i)
  have hstep : walkWeight d ((p i).val ++ [j]) = walkWeight d (p i).val + d i j := by
    rw [htail]
    simpa only [List.append_assoc, List.cons_append, List.nil_append] using walkWeight_append_last d tail i j
  by_cases hj : j ∈ (p i).val
  · obtain ⟨l,r,he⟩ := List.mem_iff_append.mp hj
    have hnodup : (l ++ j::r).Nodup := he ▸ (p i).property
    have hq : (l ++ [j]).Nodup := by
      have h' : ((l ++ [j]) ++ r).Nodup := by simpa only [List.append_assoc, List.singleton_append] using hnodup
      exact h'.of_append_left
    have hr : (j::r).Nodup := hnodup.of_append_right
    have hqmax := hmax j ⟨l ++ [j],hq⟩ (List.getLast?_concat)
    have hcy := hcycle j r hr
    have hew : walkWeight d ((p i).val ++ [j]) =
        walkWeight d (l ++ [j]) + walkWeight d ((j::r) ++ [j]) := by
      rw [he]
      simpa only [List.append_assoc, List.cons_append] using walkWeight_join d l (r ++ [j]) j
    rw [hstep] at hew
    change walkWeight d (l ++ [j]) ≤ walkWeight d (p j).val at hqmax
    linarith
  · have hq : ((p i).val ++ [j]).Nodup := by
      simpa only [List.concat_eq_append] using List.Nodup.concat hj (p i).property
    have hqmax := hmax j ⟨(p i).val ++ [j],hq⟩ List.getLast?_concat
    change walkWeight d ((p i).val ++ [j]) ≤ walkWeight d (p j).val at hqmax
    rw [hstep] at hqmax
    linarith

/-- Permutation optimality suffices for a dominating edge potential. -/
theorem exists_edge_potential_of_permutation_bound {α : Type*} [Fintype α] [DecidableEq α]
    (d : α → α → ℝ) (hdiag : ∀ i, d i i = 0)
    (hperm : ∀ σ : Equiv.Perm α, (∑ i, d i (σ i)) ≤ 0) :
    ∃ c : α → ℝ, ∀ i j, d i j ≤ c j - c i :=
  exists_edge_potential d (simple_closed_walk_nonpositive d hdiag hperm)

end MonotoneMatching
