import MonotoneMatching.EventCount
import MonotoneMatching.SourceStability
noncomputable section
namespace MonotoneMatching
open Set
open scoped BigOperators
set_option backward.isDefEq.respectTransparency.types false

/-- W5: complete generic event enumeration, exact excess formula and event bound. -/
def windingEventCountStatement : Prop :=
  ∀ (n : ℕ),2≤n → ∀ (b v : Fin n → ℝ → ℂ) (T : ℝ),0<T →
    (∀ i t,HasDerivAt (b i) (v i t) t) → (∀ i,Continuous (v i)) →
    (∀ i,Function.Periodic (b i) T) → (∀ t,Function.Injective (fun i => b i t)) →
    (∀ i j,i<j → ∀ t,(b j t-b i t).re*(v j t-v i t).im-(b j t-b i t).im*(v j t-v i t).re≤0) →
    ∃ φ : Fin n → Fin n → ℝ → ℝ,∃ w : Fin n × Fin n → ℕ,
      (∀ i j,Continuous (φ i j)) ∧ (∀ i t,φ i i t=0) ∧
      (∀ i j,i≠j → ∀ t,(φ i j t:Real.Angle)=(Complex.arg (b j t-b i t):Real.Angle)) ∧
      (∀ p∈increasingPairs n,φ p.1 p.2 T-φ p.1 p.2 0= -(2*Real.pi)*(w p:ℝ)) ∧
    ∃ G : Set (Fin n → ℂ),IsOpen G ∧ Dense G ∧ ∀ a∈G,
      ∃ m : ℕ,0<m ∧ ∃ cut : Fin (m+1) → ℝ,∃ label : Fin m → Equiv.Perm (Fin n),
        StrictMono cut ∧ cut 0=0 ∧ cut (Fin.last m)=T ∧
        (∀ i,∀ t∈Ioo (cut i.castSucc) (cut i.succ),UniqueMinimum a (fun j => b j t) (label i)) ∧
        (∀ i,∀ t∈Icc (cut i.castSucc) (cut i.succ),∀ ρ,
          assignmentScore a (fun j => b j t) ρ≤assignmentScore a (fun j => b j t) (label i)) ∧
        (∀ t∈Icc 0 T,∀ σ,UniqueMinimum a (fun j => b j t) σ → ∃ i,label i=σ) ∧
        Function.Injective (trajectoryTransitionTime cut) ∧
        (∀ i,trajectoryTransitionTime cut i∈Ico (0:ℝ) T) ∧
        (∀ t∈Ico (0:ℝ) T,trajectoryOptimalTie a b t ↔
          ∃ i,trajectoryTransitionTime cut i=t ∧ label (finRotate m i)≠label i) ∧
        (∀ i,(label (finRotate m i)≠label i → ((label i)⁻¹*label (finRotate m i)).IsCycle ∧
          1≤trajectoryCellCharge b cut label i) ∧
          identityPhase a (fun j => b (label (finRotate m i) j) (cut (finRotate m i).castSucc))-
            identityPhase a (fun j => b (label i j) (cut i.succ))=
              Real.pi*(trajectoryCellCharge b cut label i:ℝ)) ∧
        (∑ i,trajectoryCellCharge b cut label i)=2*∑ p∈increasingPairs n,w p ∧
        trajectoryEventCount label+∑ i,trajectoryCellExcess b cut label i=2*∑ p∈increasingPairs n,w p ∧
        trajectoryEventCount label=2*(∑ p∈increasingPairs n,w p)-∑ i,trajectoryCellExcess b cut label i ∧
        trajectoryEventCount label≤2*∑ p∈increasingPairs n,w p

/-- W5 is derived from the physical winding budget without an assumed event bound. -/
theorem winding_event_count : windingEventCountStatement := by
  intro n hn b v T hT hd hv hp hy hclock
  obtain ⟨φ,w,hφ,hzero,he,hw,G,ho,hg,hG⟩ := winding_exact_charges n hn b v T hT hd hv hp hy hclock
  refine ⟨φ,w,hφ,hzero,he,hw,G,ho,hg,?_⟩
  intro a ha
  obtain ⟨m,hm,cut,label,hmono,hfirst,hlast,hunique,hopt,hcover,hinj,htime,henum,hcharge,hbudget⟩ := hG a ha
  refine ⟨m,hm,cut,label,hmono,hfirst,hlast,hunique,hopt,hcover,hinj,htime,henum,hcharge,hbudget,?_⟩
  exact trajectory_event_count_formula b cut label _ (fun i hi => ((hcharge i).1 hi).1) hbudget

/-- W1: for every source list, the number of permutations uniquely optimal
somewhere in a period is at most max(1, twice the physical pair winding). -/
def windingDistinctCountStatement : Prop :=
  ∀ (n : ℕ),2≤n → ∀ (b v : Fin n → ℝ → ℂ) (T : ℝ),0<T →
    (∀ i t,HasDerivAt (b i) (v i t) t) → (∀ i,Continuous (v i)) →
    (∀ i,Function.Periodic (b i) T) → (∀ t,Function.Injective (fun i => b i t)) →
    (∀ i j,i<j → ∀ t,(b j t-b i t).re*(v j t-v i t).im-(b j t-b i t).im*(v j t-v i t).re≤0) →
    ∃ φ : Fin n → Fin n → ℝ → ℝ,∃ w : Fin n × Fin n → ℕ,
      (∀ i j,Continuous (φ i j)) ∧ (∀ i t,φ i i t=0) ∧
      (∀ i j,i≠j → ∀ t,(φ i j t:Real.Angle)=(Complex.arg (b j t-b i t):Real.Angle)) ∧
      (∀ p∈increasingPairs n,φ p.1 p.2 T-φ p.1 p.2 0= -(2*Real.pi)*(w p:ℝ)) ∧
      ∀ a : Fin n → ℂ,(trajectoryOptimizers a b T).card≤max 1 (2*∑ p∈increasingPairs n,w p)

/-- The generic bound transfers through simultaneous persistence of all strict
witnesses; no genericity hypothesis is imposed on the original sources. -/
theorem winding_distinct_count : windingDistinctCountStatement := by
  classical
  intro n hn b v T hT hd hv hp hy hclock
  obtain ⟨φ,w,hφ,hzero,he,hw,G,_ho,hg,hG⟩ := winding_event_count n hn b v T hT hd hv hp hy hclock
  refine ⟨φ,w,hφ,hzero,he,hw,?_⟩
  apply trajectory_count_from_dense_sources b T G hg
  intro a ha
  obtain ⟨m,hm,cut,label,_hmono,_hfirst,_hlast,_hunique,_hopt,hcover,_hinj,_htime,_henum,_hcharge,_hbudget,_hsum,_hformula,hcount⟩ := hG a ha
  have hs : trajectoryOptimizers a b T ⊆ Finset.univ.image label := by
    intro σ hσ
    obtain ⟨t,ht,hσ⟩ := (mem_trajectoryOptimizers a b T σ).mp hσ
    obtain ⟨i,hi⟩ := hcover t ht σ hσ
    exact Finset.mem_image.mpr ⟨i,Finset.mem_univ _,hi⟩
  exact (Finset.card_le_card hs).trans (cyclic_trajectory_label_count hm label _ hcount)

end MonotoneMatching
