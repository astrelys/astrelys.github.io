import MonotoneMatching.PeriodicTwoSideArc
import MonotoneMatching.ShiftedCyclePath
import MonotoneMatching.CompactArcPerturbation

/-! A chord loop has the sum of the indices at two sufficiently close opposite edge-side points. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval

theorem polygon_chord_increment_side_sum {m : ℕ} [NeZero m] (v : Fin m → ℂ)
    (hinj : Set.InjOn (periodicPolygonPath (closedCycleVertices v)) (Set.Ico (0:ℝ) m))
    (η : ℝ) (hη : η≠0)
    (hn : ∀ t s : I,
      periodicPolygonPath (closedCycleVertices v) ((1/4:ℝ)+((m:ℝ)-2*(1/4))*(s:ℝ)+1/2)-
        periodicPolygonPath (closedCycleVertices v) (1/2)-(t:ℝ) • (η • (Complex.I*(v (finRotate m 0)-v 0)))≠0 ∧
      periodicPolygonPath (closedCycleVertices v) ((1/4:ℝ)+((m:ℝ)-2*(1/4))*(s:ℝ)+1/2)-
        periodicPolygonPath (closedCycleVertices v) (1/2)+(t:ℝ) • (η • (Complex.I*(v (finRotate m 0)-v 0)))≠0)
    (hqp : periodicPolygonPath (closedCycleVertices v) (1/2)+η • (Complex.I*(v (finRotate m 0)-v 0))
      ∉polygonBoundary (finRotate m) v)
    (hqm : periodicPolygonPath (closedCycleVertices v) (1/2)-η • (Complex.I*(v (finRotate m 0)-v 0))
      ∉polygonBoundary (finRotate m) v)
    {d : ℝ} (hd : d∈Set.Ioo (0:ℝ) m) (φ : C(I,ℝ))
    (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg
      (periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ)+d)-
       periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ))) : Real.Angle)) :
    φ 1-φ 0=
      polygonIndexPhase (finRotate m) v (periodicPolygonPath (closedCycleVertices v) (1/2)+η • (Complex.I*(v (finRotate m 0)-v 0)))+
      polygonIndexPhase (finRotate m) v (periodicPolygonPath (closedCycleVertices v) (1/2)-η • (Complex.I*(v (finRotate m 0)-v 0))) := by
  have hm : 0<m := Nat.pos_of_ne_zero (NeZero.ne m)
  have hmR : (1:ℝ)≤m := by exact_mod_cast hm
  let Γ := periodicPolygonPath (closedCycleVertices v)
  let γ := fun t => Γ (t+1/2)
  let u := v (finRotate m 0)-v 0
  let w := η • (Complex.I*u)
  have hΓ : Continuous Γ := continuous_periodicPolygonPath hm _ (closedCycleVertices_closed v)
  have hc : Continuous γ := by apply hΓ.comp; fun_prop
  have hp : Function.Periodic γ (m:ℝ) := fun t => by
    dsimp only [γ]
    rw [show t+(m:ℝ)+1/2=(t+1/2)+m by ring]
    exact periodicPolygonPath_periodic hm _ _
  have hloc (t : ℝ) (ht : t∈Set.Icc (-(1/4:ℝ)) (1/4:ℝ)) : γ t=γ 0+t • u := by
    simpa only [γ,u,zero_add] using closedCyclePath_edge_midpoint_affine v ht
  let δ := fun s : I => γ ((1/4:ℝ)+((m:ℝ)-2*(1/4))*(s:ℝ))-γ 0
  have hδ : Continuous δ := by dsimp [δ]; fun_prop
  have hδn (s : I) : δ s≠0 := by simpa [δ,γ,Γ,w,u] using (hn 0 s).1
  obtain ⟨χ,hχ,_⟩ := exists_continuous_argument_lift δ hδ hδn
  let a := fun s : I => (chordRectangleParameter m (1/4) s).re+1/2
  let b := fun s : I => (chordRectangleParameter m (1/4) s).im+1/2
  have ha : Continuous a := (Complex.continuous_re.comp (continuous_chordRectangleParameter _ _)).add continuous_const
  have hb : Continuous b := (Complex.continuous_im.comp (continuous_chordRectangleParameter _ _)).add continuous_const
  have hproper (s : I) : b s-a s∈Set.Ioo (0:ℝ) m := by
    simpa only [a,b,add_sub_add_right_eq_sub] using chordRectangleParameter_proper (m:ℝ) (1/4) (by norm_num) (by linarith) s
  have haend : a 1=a 0+m := by have h := (chordRectangleParameter_endpoints (m:ℝ) (1/4)).1; dsimp [a]; linarith
  have hbend : b 1=b 0+m := by have h := (chordRectangleParameter_endpoints (m:ℝ) (1/4)).2; dsimp [b]; linarith
  let C := fun s : I => Γ (b s)-Γ (a s)
  have hC : Continuous C := (hΓ.comp hb).sub (hΓ.comp ha)
  have hCn (s : I) : C s≠0 := by
    have h := polygon_chord_ne_zero hm (closedCycleVertices v) hinj (hproper s) (a s)
    simpa only [add_sub_cancel] using h
  obtain ⟨ψ,hψ,_⟩ := exists_continuous_argument_lift C hC hCn
  have hch := polygon_chord_strip_increment hm (closedCycleVertices v) (closedCycleVertices_closed v)
    hinj hd a b ha hb hproper haend hbend φ ψ hφ hψ
  have hr := rectangle_chord_anchored_increment γ m (1/4) hp (by norm_num) u hloc hδn ψ χ hψ hχ
  let gp := fun s : I => γ ((m:ℝ)*(s:ℝ))-γ 0-w
  let gm := fun s : I => γ ((m:ℝ)*(s:ℝ))-γ 0+w
  have hgn (t : ℝ) : γ t-γ 0-w≠0 ∧ γ t-γ 0+w≠0 := by
    constructor
    · have h := closedCyclePath_relative_ne_zero v hqp (t+1/2)
      simpa only [γ,Γ,zero_add,w,u,sub_add_eq_sub_sub] using h
    · have h := closedCyclePath_relative_ne_zero v hqm (t+1/2)
      simpa only [γ,Γ,zero_add,w,u,sub_eq_add_neg,neg_add_rev,neg_neg,add_assoc,add_comm,add_left_comm] using h
  obtain ⟨Φ,hΦ,_⟩ := exists_continuous_argument_lift gp (by dsimp [gp]; fun_prop) (fun s => (hgn _).1)
  obtain ⟨Ψ,hΨ,_⟩ := exists_continuous_argument_lift gm (by dsimp [gm]; fun_prop) (fun s => (hgn _).2)
  have hs := periodic_two_side_anchored_increment γ hc m (1/4) η hp (by norm_num) hη u hloc (by simpa only [γ,Γ,u,zero_add] using hn) hgn Φ Ψ χ hΦ hΨ hχ
  have hΦ' := closedCyclePath_shift_phase_increment v hqp (1/2) Φ
    (fun s => by simpa only [gp,γ,Γ,w,u,zero_add,sub_add_eq_sub_sub] using hΦ s)
  have hΨ' := closedCyclePath_shift_phase_increment v hqm (1/2) Ψ
    (fun s => by simpa only [gm,γ,Γ,w,u,zero_add,sub_eq_add_neg,neg_add_rev,neg_neg,add_assoc,add_comm,add_left_comm] using hΨ s)
  rw [hch,hr,← hs,hΦ',hΨ']

end MonotoneMatching
