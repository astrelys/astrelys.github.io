import MonotoneMatching.PolygonPhase

/-! Exact argument jump when a point crosses the interior of an oriented edge. -/
noncomputable section
namespace MonotoneMatching
open scoped Topology
open Filter

/-- Endpoint ratio for the edge from 0 to 1 viewed from r + epsilon*i. -/
def edgeCrossRatio (r ε : ℝ) : ℂ := (⟨1-r,-ε⟩ : ℂ)/(⟨-r,-ε⟩ : ℂ)

theorem edgeCrossRatio_im (r ε : ℝ) : (edgeCrossRatio r ε).im=ε/(r^2+ε^2) := by
  simp only [edgeCrossRatio,Complex.div_im,Complex.normSq_apply]
  ring

theorem edgeCrossRatio_zero {r : ℝ} (hr : 0<r) :
    edgeCrossRatio r 0=(((r-1)/r : ℝ) : ℂ) := by
  apply Complex.ext
  · simp only [edgeCrossRatio,Complex.div_re,Complex.normSq_apply,Complex.ofReal_re,neg_zero,
      mul_zero,add_zero]
    field_simp
    ring
  · simp [edgeCrossRatio,Complex.div_im,Complex.normSq_apply]

theorem continuousAt_edgeCrossRatio_zero {r : ℝ} (hr : 0<r) : ContinuousAt (edgeCrossRatio r) 0 := by
  unfold edgeCrossRatio
  apply ContinuousAt.div
  · simp only [Complex.mk_eq_add_mul_I]; fun_prop
  · simp only [Complex.mk_eq_add_mul_I]; fun_prop
  · intro h
    have hh := congrArg Complex.re h
    simp only [Complex.zero_re] at hh
    linarith

/-- Viewed from the left side of an oriented edge, its ratio argument tends
to +pi; from the right side it tends to -pi. -/
theorem edgeCrossRatio_argument_side_limits {r : ℝ} (hr : r ∈ Set.Ioo (0:ℝ) 1) :
    Tendsto (fun ε => (edgeCrossRatio r ε).arg) (𝓝[>] (0:ℝ)) (𝓝 Real.pi) ∧
    Tendsto (fun ε => (edgeCrossRatio r (-ε)).arg) (𝓝[>] (0:ℝ)) (𝓝 (-Real.pi)) := by
  have hneg : (r-1)/r < 0 := div_neg_of_neg_of_pos (sub_neg.mpr hr.2) hr.1
  have hzero : Complex.arg (-edgeCrossRatio r 0)=0 := by
    rw [edgeCrossRatio_zero hr.1]
    apply Complex.arg_eq_zero_iff.mpr
    simp only [Complex.neg_re,Complex.ofReal_re,Complex.neg_im,Complex.ofReal_im,neg_zero]
    exact ⟨by linarith, trivial⟩
  have hre : 0 < (-edgeCrossRatio r 0).re := by
    rw [edgeCrossRatio_zero hr.1]
    simpa using neg_pos.mpr hneg
  have hc : ContinuousAt (fun ε => Complex.arg (-edgeCrossRatio r ε)) 0 :=
    ContinuousAt.comp (f := fun ε => -edgeCrossRatio r ε)
      (Complex.continuousAt_arg (Or.inl hre)) (continuousAt_edgeCrossRatio_zero hr.1).neg
  have ht : Tendsto (fun ε => Complex.arg (-edgeCrossRatio r ε)) (𝓝[>] (0:ℝ)) (𝓝 0) := by
    simpa only [hzero] using hc.tendsto.mono_left nhdsWithin_le_nhds
  constructor
  · have h := ht.add_const Real.pi
    simp only [zero_add] at h
    apply h.congr'
    filter_upwards [self_mem_nhdsWithin] with ε hε
    have hi : 0 < (edgeCrossRatio r ε).im := by
      rw [edgeCrossRatio_im]
      exact div_pos hε (by nlinarith [sq_pos_of_pos hr.1,sq_nonneg ε])
    have ha := Complex.arg_neg_eq_arg_sub_pi_of_im_pos hi
    linarith
  · have hc' : ContinuousAt (fun ε => Complex.arg (-edgeCrossRatio r (-ε))) 0 := by
      have hc0 : ContinuousAt (fun ε => Complex.arg (-edgeCrossRatio r ε)) (-(0:ℝ)) := by
        simpa only [neg_zero] using hc
      exact hc0.comp (f := fun ε : ℝ => -ε) continuousAt_neg
    have ht' : Tendsto (fun ε => Complex.arg (-edgeCrossRatio r (-ε))) (𝓝[>] (0:ℝ)) (𝓝 0) := by
      simpa only [neg_zero,hzero] using hc'.tendsto.mono_left nhdsWithin_le_nhds
    have h := ht'.sub_const Real.pi
    simp only [zero_sub] at h
    apply h.congr'
    filter_upwards [self_mem_nhdsWithin] with ε hε
    have hi : (edgeCrossRatio r (-ε)).im < 0 := by
      rw [edgeCrossRatio_im]
      exact div_neg_of_neg_of_pos (neg_neg_of_pos hε) (by nlinarith [sq_pos_of_pos hr.1,sq_nonneg ε])
    have ha := Complex.arg_neg_eq_arg_add_pi_of_im_neg hi
    linarith

theorem edgeCrossRatio_argument_jump_limit {r : ℝ} (hr : r ∈ Set.Ioo (0:ℝ) 1) :
    Tendsto (fun ε => (edgeCrossRatio r ε).arg-(edgeCrossRatio r (-ε)).arg)
      (𝓝[>] (0:ℝ)) (𝓝 (2*Real.pi)) := by
  have h := (edgeCrossRatio_argument_side_limits hr).1.sub (edgeCrossRatio_argument_side_limits hr).2
  simpa only [sub_neg_eq_add,two_mul] using h

end MonotoneMatching
