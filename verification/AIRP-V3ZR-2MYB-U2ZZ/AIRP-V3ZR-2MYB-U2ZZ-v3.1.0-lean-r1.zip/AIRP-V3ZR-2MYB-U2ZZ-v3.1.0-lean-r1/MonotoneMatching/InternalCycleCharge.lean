import MonotoneMatching.CyclicChordPhase
import MonotoneMatching.CyclicPairSums

/-! The internal ordered-pair charge is the sum of the nonzero cyclic chord gaps. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators unitInterval

theorem internal_cycle_pair_charge {m : ℕ} [NeZero m] (v : Fin m → ℂ)
    (hinj : Set.InjOn (periodicPolygonPath (closedCycleVertices v)) (Set.Ico (0:ℝ) m))
    (hchord : ∀ d : ℝ, d∈Set.Ioo (0:ℝ) m → ∀ φ : C(I,ℝ),
      (∀ s, (φ s : Real.Angle)=(Complex.arg
        (periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ)+d)-
         periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ))) : Real.Angle)) → φ 1-φ 0=2*Real.pi) :
    (∑ i : Fin m, ∑ j : Fin m,
      Complex.arg ((v (finRotate m j)-v (finRotate m i))/(v j-v i)))=((m:ℝ)-1)*(2*Real.pi) := by
  apply cyclic_gap_sum_constant _ (fun i => by simp) (2*Real.pi)
  intro d hd
  have hm : 0<m := Nat.pos_of_ne_zero (NeZero.ne m)
  have hd0 : (0:ℝ)<d.val := by exact_mod_cast (Fin.pos_iff_ne_zero.mpr hd)
  have hdm : (d.val:ℝ)<m := by exact_mod_cast d.isLt
  let γ := fun s : I => periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ)+d.val)-
    periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ))
  have hc : Continuous γ := by
    apply Continuous.sub
    · apply (continuous_periodicPolygonPath hm _ (closedCycleVertices_closed v)).comp; fun_prop
    · apply (continuous_periodicPolygonPath hm _ (closedCycleVertices_closed v)).comp; fun_prop
  have hn (s : I) : γ s≠0 := polygon_chord_ne_zero hm _ hinj ⟨hd0,hdm⟩ _
  obtain ⟨φ,hφ,_⟩ := exists_continuous_argument_lift γ hc hn
  have hp := hchord d.val ⟨hd0,hdm⟩ φ hφ
  have he := cyclic_chord_phase_increment v hinj d hd φ hφ
  rw [he] at hp
  convert hp using 1
  apply Finset.sum_congr rfl
  intro i _
  have hs : finRotate m (i+d)=finRotate m i+d := by simp only [finRotate_apply]; ac_rfl
  rw [hs]

end MonotoneMatching
