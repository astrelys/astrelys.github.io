import MonotoneMatching.FiniteSliceDecomposition
import MonotoneMatching.MonotoneSliceFlux
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic
import Mathlib.MeasureTheory.Integral.IntervalIntegral.IntegrationByParts
noncomputable section
namespace MonotoneMatching
open MeasureTheory Set
open scoped BigOperators
set_option backward.isDefEq.respectTransparency.types false

/-- Heaviside truncation realizes an oriented interval endpoint. -/
theorem integral_heaviside_truncation (f : ℝ → ℝ) (lo hi t : ℝ)
    (ht : t ∈ Icc lo hi) :
    (∫ h in lo..hi, (if h<t then 1 else 0)*f h) = ∫ h in lo..t, f h := by
  rw [← intervalIntegral.integral_indicator ht]
  apply intervalIntegral.integral_congr_ae
  filter_upwards [volume.ae_ne t] with h hn
  intro _
  by_cases he : h<t
  · simp [he,le_of_lt he]
  · have hne : ¬ h≤t := by intro hle; exact he (lt_of_le_of_ne hle hn)
    simp [he,hne]

/-- Truncated continuous functions are interval integrable. -/
theorem intervalIntegrable_heaviside (f : ℝ → ℝ) (hf : Continuous f)
    (lo hi t : ℝ) : IntervalIntegrable (fun h => (if h<t then 1 else 0)*f h) volume lo hi := by
  have hfi := hf.intervalIntegrable (μ := volume) (a := lo) (b := hi)
  have he : (fun h => (if h<t then 1 else 0)*f h) = (Iio t).indicator f := by
    funext h
    by_cases ht : h<t <;> simp [ht]
  rw [he]
  exact ⟨hfi.1.indicator measurableSet_Iio,hfi.2.indicator measurableSet_Iio⟩

/-- A weighted oriented edge interval equals its signed slice integral. -/
theorem integral_slice_crossing (f : ℝ → ℝ) (hf : Continuous f)
    (lo hi u v : ℝ) (hu : u ∈ Icc lo hi) (hv : v ∈ Icc lo hi) :
    (∫ h in lo..hi, sliceCrossingSign u v h*f h) = ∫ h in u..v, f h := by
  simp only [sliceCrossingSign,sub_mul]
  rw [intervalIntegral.integral_sub (intervalIntegrable_heaviside f hf lo hi v) (intervalIntegrable_heaviside f hf lo hi u),
    integral_heaviside_truncation f lo hi v hv,integral_heaviside_truncation f lo hi u hu]
  exact intervalIntegral.integral_interval_sub_left (hf.intervalIntegrable _ _) (hf.intervalIntegrable _ _)

/-- The signed crossing weight preserves interval integrability. -/
theorem intervalIntegrable_slice_crossing (f : ℝ → ℝ) (hf : Continuous f)
    (lo hi u v : ℝ) : IntervalIntegrable (fun h => sliceCrossingSign u v h*f h) volume lo hi := by
  simpa only [sliceCrossingSign,sub_mul] using
    (intervalIntegrable_heaviside f hf lo hi v).sub (intervalIntegrable_heaviside f hf lo hi u)

/-- Slice-wise nonpositivity gives nonpositive total oriented weighted edge integrals. -/
theorem integrated_slice_flux_nonpos {ι : Type*} [Fintype ι]
    (f : ι → ℝ → ℝ) (hf : ∀ i,Continuous (f i)) (u v : ι → ℝ)
    (lo hi : ℝ) (hlohi : lo ≤ hi)
    (hu : ∀ i,u i ∈ Icc lo hi) (hv : ∀ i,v i ∈ Icc lo hi)
    (hslice : ∀ᵐ h, (∑ i,sliceCrossingSign (u i) (v i) h*f i h) ≤ 0) :
    (∑ i,∫ h in u i..v i,f i h) ≤ 0 := by
  have he : (∑ i,∫ h in u i..v i,f i h) =
      ∫ h in lo..hi,∑ i,sliceCrossingSign (u i) (v i) h*f i h := by
    rw [intervalIntegral.integral_finsetSum]
    · apply Finset.sum_congr rfl
      intro i _
      exact (integral_slice_crossing (f i) (hf i) lo hi (u i) (v i) (hu i) (hv i)).symm
    · intro i _
      exact intervalIntegrable_slice_crossing (f i) (hf i) lo hi (u i) (v i)
  rw [he]
  have hn := intervalIntegral.integral_nonneg_of_ae hlohi (hslice.mono (fun _ h => neg_nonneg.mpr h))
  rw [intervalIntegral.integral_neg] at hn
  exact neg_nonneg.mp hn

/-- A continuous vertical one-form on a straight edge is its horizontal slice integral. -/
theorem affine_edge_vertical_integral (Q : ℂ → ℝ) (hQ : Continuous Q) (z w : ℂ) :
    (∫ t in (0:ℝ)..1,Q ((1-t) • z+t • w)*(w.im-z.im)) =
      ∫ h in z.im..w.im,Q (horizontalPoint (horizontalEdgeCrossing z w h) h) := by
  by_cases hd : w.im-z.im=0
  · have he : w.im=z.im := sub_eq_zero.mp hd
    simp [he]
  let f : ℝ → ℝ := fun t => z.im+t*(w.im-z.im)
  let g : ℝ → ℝ := fun h => Q (horizontalPoint (horizontalEdgeCrossing z w h) h)
  have hf (t : ℝ) : HasDerivAt f (w.im-z.im) t := by
    simpa only [one_mul,id_eq] using! ((hasDerivAt_id t).mul_const (w.im-z.im)).const_add z.im
  have hg : Continuous g := by
    apply hQ.comp
    dsimp [horizontalPoint,horizontalEdgeCrossing]
    simp only [Complex.mk_eq_add_mul_I]
    fun_prop
  have hp (t : ℝ) : horizontalPoint (horizontalEdgeCrossing z w (f t)) (f t) =
      (1-t) • z+t • w := by
    apply Complex.ext <;> simp only [horizontalPoint,horizontalEdgeCrossing,f,Complex.add_re,Complex.add_im,
      Complex.smul_re,Complex.smul_im,smul_eq_mul]
    · field_simp
      ring
    · ring
  have hc := intervalIntegral.integral_comp_mul_deriv (a := 0) (b := 1)
    (fun t _ => hf t) continuous_const.continuousOn hg
  have h0 : f 0=z.im := by dsimp [f]; ring
  have h1 : f 1=w.im := by dsimp [f]; ring
  rw [h0,h1] at hc
  simpa only [Function.comp_def,g,hp] using hc

/-- A nonpositive oriented transition polygon has nonpositive vertical flux against every
continuous weight increasing in the horizontal coordinate. -/
theorem polygon_vertical_monotone_integral_nonpos {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ)
    {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ) (e : ι → Fin n) (he : Function.Injective e)
    (hedge : ∀ i, ∀ t∈Set.Ioo (0:ℝ) 1, (1-t) • v i+t • v (next i)∈strictDualCell a r (e i))
    (L R : ℝ) (hgap : L-R=2*Real.pi)
    (hL : ∀ i q, q∈strictDualCell a r (e i) → 0<edgeSide (v i) (v (next i)) q → polygonIndexPhase next v q=L)
    (hR : ∀ i q, q∈strictDualCell a r (e i) → edgeSide (v i) (v (next i)) q<0 → polygonIndexPhase next v q=R)
    (hphase : ∀ q, q∉polygonBoundary next v → polygonIndexPhase next v q≤0)
    (Q : ℂ → ℝ) (hQ : Continuous Q)
    (hQmono : ∀ h,Monotone (fun x => Q (horizontalPoint x h))) :
    (∑ i,∫ t in (0:ℝ)..1,Q ((1-t) • v i+t • v (next i))*((v (next i)).im-(v i).im)) ≤ 0 := by
  obtain ⟨lo,hlo⟩ := (Set.finite_range (fun i => (v i).im)).bddBelow
  obtain ⟨hi,hhi⟩ := (Set.finite_range (fun i => (v i).im)).bddAbove
  let lower := min lo hi-1
  let upper := max lo hi+1
  have hlt : lower ≤ upper := by dsimp [lower,upper]; linarith [min_le_left lo hi,le_max_left lo hi]
  have hB (j : ι) : (v j).im∈Set.Icc lower upper := by
    have hl := hlo (Set.mem_range_self j)
    have hh := hhi (Set.mem_range_self j)
    dsimp [lower,upper]
    constructor <;> linarith [min_le_left lo hi,le_max_right lo hi]
  simp_rw [affine_edge_vertical_integral Q hQ]
  have hQi (i : ι) : Continuous (fun h => Q (horizontalPoint (horizontalEdgeCrossing (v i) (v (next i)) h) h)) := by
    apply hQ.comp
    dsimp [horizontalPoint,horizontalEdgeCrossing]
    simp only [Complex.mk_eq_add_mul_I]
    fun_prop
  apply integrated_slice_flux_nonpos
    (fun i h => Q (horizontalPoint (horizontalEdgeCrossing (v i) (v (next i)) h) h))
    hQi (fun i => (v i).im) (fun i => (v (next i)).im) lower upper hlt hB (fun i => hB (next i))
  have hgeneric : ∀ᵐ h : ℝ,∀ i,h≠(v i).im := ae_all_iff.mpr (fun i => volume.ae_ne ((v i).im))
  filter_upwards [hgeneric] with h hh
  simpa only [mul_comm] using horizontal_slice_monotone_weight_nonpos next v h hh
    a r e he hedge L R hgap hL hR hphase (fun x => Q (horizontalPoint x h)) (hQmono h)

end MonotoneMatching
