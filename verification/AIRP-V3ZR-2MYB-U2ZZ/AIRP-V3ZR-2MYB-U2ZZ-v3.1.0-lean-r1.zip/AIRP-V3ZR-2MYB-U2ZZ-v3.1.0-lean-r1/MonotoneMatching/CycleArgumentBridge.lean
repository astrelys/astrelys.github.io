import MonotoneMatching.ClosedCyclePath
import MonotoneMatching.ArgumentSubdivision

/-! The exact polygon index is the real lifted increment of its periodic path. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval BigOperators

theorem closedCyclePath_phase_increment {m : ℕ} [NeZero m] (v : Fin m → ℂ)
    {q : ℂ} (hq : q∉polygonBoundary (finRotate m) v)
    (φ : C(I,ℝ)) (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg
      (periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ))-q) : Real.Angle)) :
    φ 1-φ 0=polygonIndexPhase (finRotate m) v q := by
  have hm : 0<m := Nat.pos_of_ne_zero (NeZero.ne m)
  let γ := fun s : I => periodicPolygonPath (closedCycleVertices v) ((m:ℝ)*(s:ℝ))-q
  let w := fun i : Fin (m+1) => closedCycleVertices v i-q
  have hn (s : I) : γ s≠0 := closedCyclePath_relative_ne_zero v hq _
  have hedge (i : Fin m) (s : I) : γ (uniformArgumentSubparameter hm i s)=
      (1-(s:ℝ)) • w i.castSucc+(s:ℝ) • w i.succ := by
    have he : (m:ℝ)*(uniformArgumentSubparameter hm i s:ℝ)=(i.val:ℝ)+(s:ℝ) := by
      dsimp only [uniformArgumentSubparameter]
      field_simp
    dsimp only [γ,w]
    rw [he,periodicPolygonPath_on_closed_edge hm _ (closedCycleVertices_closed v) i s.property]
    module
  have h := argument_increment_affine_subdivision hm γ hn w hedge φ hφ
  rw [h]
  unfold polygonIndexPhase polygonPhase
  apply Finset.sum_congr rfl
  intro i _
  simp only [w,closedCycleVertices_succ,closedCycleVertices_castSucc]

end MonotoneMatching
