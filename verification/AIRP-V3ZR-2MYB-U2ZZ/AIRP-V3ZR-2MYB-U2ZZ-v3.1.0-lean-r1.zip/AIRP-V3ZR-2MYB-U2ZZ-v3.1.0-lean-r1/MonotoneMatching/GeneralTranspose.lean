import MonotoneMatching.TransposePhase

noncomputable section
namespace MonotoneMatching
open scoped InnerProductSpace

/-- At a transverse clockwise crossing, the tied source difference selects the
negative imaginary half-axis. This uses arbitrary finite velocities. -/
theorem clockwise_transverse_pair_sign (a d u : ℂ) (hd : d ≠ 0)
    (htie : inner ℝ a d = 0) (hmove : inner ℝ a u < 0)
    (hclock : d.re * u.im - d.im * u.re ≤ 0) :
    (d * (starRingEnd ℂ) a).im < 0 := by
  have hn : 0 < Complex.normSq d := Complex.normSq_pos.mpr hd
  have hid : inner ℝ a u * Complex.normSq d =
      inner ℝ a d * inner ℝ d u -
        (d * (starRingEnd ℂ) a).im * (d.re * u.im - d.im * u.re) := by
    simp only [Complex.inner, Complex.normSq_apply, Complex.mul_re, Complex.mul_im,
      Complex.conj_re, Complex.conj_im]
    ring
  rw [htie, zero_mul, zero_sub] at hid
  have hnegative := mul_neg_of_neg_of_pos hmove hn
  by_contra hm
  have hm0 : 0 ≤ (d * (starRingEnd ℂ) a).im := le_of_not_gt hm
  have hp := mul_nonpos_of_nonneg_of_nonpos hm0 hclock
  linarith

/-- The exact unit phase charge of a genuine transposition holds for any
clockwise finite velocity data, not just rigid rotational velocity. -/
theorem general_two_optima_transposition_phase_charge {n : ℕ} (a y v : Fin n → ℂ)
    (i j : Fin n) (hij : i ≠ j) (hy : y i ≠ y j)
    (hmax : ∀ τ, assignmentScore a y τ ≤ assignmentScore a y (Equiv.refl _))
    (heq : assignmentScore a y (Equiv.swap i j) = assignmentScore a y (Equiv.refl _))
    (htwo : ∀ τ, assignmentScore a y τ = assignmentScore a y (Equiv.refl _) →
      τ = Equiv.refl _ ∨ τ = Equiv.swap i j)
    (hderiv : 0 < assignmentScore a v (Equiv.swap i j) - assignmentScore a v (Equiv.refl _))
    (hclock : (y j-y i).re * (v j-v i).im - (y j-y i).im * (v j-v i).re ≤ 0) :
    identityPhase a (y ∘ Equiv.swap i j) - identityPhase a y = Real.pi := by
  apply transposition_phase_charge a y i j hij
    (two_optima_transposition_pair_strict a y i j hmax heq htwo)
  apply clockwise_transverse_pair_sign (a j-a i) (y j-y i) (v j-v i)
    (sub_ne_zero.mpr hy.symm) _ _ hclock
  · rw [← score_swap_difference a y j i hij.symm, Equiv.swap_comm j i, heq, sub_self]
  · rw [← score_swap_difference a v j i hij.symm, Equiv.swap_comm j i]
    linarith

end MonotoneMatching
