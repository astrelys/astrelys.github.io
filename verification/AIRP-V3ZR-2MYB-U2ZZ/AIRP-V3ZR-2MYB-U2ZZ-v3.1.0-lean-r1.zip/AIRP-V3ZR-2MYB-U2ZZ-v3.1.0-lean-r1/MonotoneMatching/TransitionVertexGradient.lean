import MonotoneMatching.TransitionCells
import MonotoneMatching.VertexCollar

/-! Exact assignment duality supplies a common-left direction at every
vertex of a long transition cycle, including collinear consecutive edges. -/
noncomputable section
namespace MonotoneMatching
open scoped InnerProductSpace

theorem transition_vertex_gradient_positive {n : ℕ} (a y : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (r c : Fin n → ℝ)
    (hbound : ∀ i j, inner ℝ (a i) (y j) ≤ r i+c j)
    (hexact : ∀ i j, r i+c j=inner ℝ (a i) (y j) ↔ j=i ∨ j=σ i)
    (i : Fin n) (hm : σ i≠i) (h2 : σ (σ i)≠i) :
    0 < inner ℝ (a i-a (σ.symm i)) (y i-y (σ.symm i)) ∧
    0 < inner ℝ (a i-a (σ.symm i)) (y (σ i)-y i) := by
  let j := σ.symm i
  have hj : σ j=i := σ.apply_symm_apply i
  have hji : j≠i := by intro h; exact hm (by simpa only [h] using hj)
  have hjs : j≠σ i := by intro h; rw [h] at hj; exact h2 hj
  have hi0 := (hexact i i).mpr (Or.inl rfl)
  have hi1 := (hexact i (σ i)).mpr (Or.inr rfl)
  have hj0 := (hexact j j).mpr (Or.inl rfl)
  have hj1 := (hexact j i).mpr (Or.inr hj.symm)
  have hip : inner ℝ (a i) (y j)<r i+c j := by
    apply lt_of_le_of_ne (hbound i j)
    intro h
    exact ((hexact i j).mp h.symm).elim hji hjs
  have hjw : inner ℝ (a j) (y (σ i))<r j+c (σ i) := by
    apply lt_of_le_of_ne (hbound j (σ i))
    intro h
    rcases (hexact j (σ i)).mp h.symm with he | he
    · exact hjs he.symm
    · rw [hj] at he
      exact hm he
  constructor <;> simp only [inner_sub_left,inner_sub_right] <;>
    dsimp only [j] at * <;> linarith

theorem transition_vertex_common_left {n : ℕ} (a y : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (r c : Fin n → ℝ)
    (hbound : ∀ i j, inner ℝ (a i) (y j) ≤ r i+c j)
    (hexact : ∀ i j, r i+c j=inner ℝ (a i) (y j) ↔ j=i ∨ j=σ i)
    (i : Fin n) (hm : σ i≠i) (h2 : σ (σ i)≠i) :
    ∃ q : ℂ, 0<edgeSide (y (σ.symm i)) (y i) q ∧
      0<edgeSide (y i) (y (σ i)) q := by
  have h := transition_vertex_gradient_positive a y σ r c hbound hexact i hm h2
  exact common_left_of_positive_inner _ _ _ _ h.1 h.2

end MonotoneMatching
