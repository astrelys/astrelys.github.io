import MonotoneMatching.HorizontalCrossings

/-! Exact two-sided winding orientation for a genuine long assignment cycle. -/
noncomputable section
namespace MonotoneMatching
open scoped InnerProductSpace

theorem transition_polygon_orientation_dichotomy {ι : Type*} [Fintype ι] [DecidableEq ι] [Nonempty ι]
    (next : Equiv.Perm ι) (htrans : ∀ i j : ι, ∃ k : ℕ, (next^k) i=j)
    {n : ℕ} (a y : Fin n → ℂ) (hy : Function.Injective y)
    (σ : Equiv.Perm (Fin n)) (r c : Fin n → ℝ)
    (hbound : ∀ i j, inner ℝ (a i) (y j) ≤ r i+c j)
    (hexact : ∀ i j, r i+c j=inner ℝ (a i) (y j) ↔ j=i ∨ j=σ i)
    (e : ι → Fin n) (he : Function.Injective e) (hsucc : ∀ i, e (next i)=σ (e i))
    (hm : ∀ i, σ (e i)≠e i) (h2 : ∀ i, σ (σ (e i))≠e i) :
    ∃ L R : ℝ, L-R=2*Real.pi ∧
      ((L=2*Real.pi ∧ R=0) ∨ (L=0 ∧ R= -(2*Real.pi))) ∧
      (∀ i q, q∈strictDualCell a r (e i) → 0<edgeSide (y (e i)) (y (e (next i))) q →
        polygonIndexPhase next (y∘e) q=L) ∧
      (∀ i q, q∈strictDualCell a r (e i) → edgeSide (y (e i)) (y (e (next i))) q<0 →
        polygonIndexPhase next (y∘e) q=R) ∧
      (∀ q, q∉polygonBoundary next (y∘e) → polygonIndexPhase next (y∘e) q=0 ∨
        polygonIndexPhase next (y∘e) q=L ∨ polygonIndexPhase next (y∘e) q=R) := by
  obtain ⟨L,R,hgap,hL,hR⟩ := transition_polygon_coherent_side_indices next htrans a y hy σ r c
    hbound hexact e he hsucc hm h2
  have hedge (i : ι) (t : ℝ) (ht : t∈Set.Ioo (0:ℝ) 1) :
      (1-t) • (y∘e) i+t • (y∘e) (next i)∈strictDualCell a r (e i) := by
    intro j hj
    simpa only [Function.comp_def,hsucc] using
      transition_edge_unique_row a y σ r c hbound hexact (e i) (h2 i) j hj ht.1 ht.2
  have hactive (i : ι) (t : ℝ) (ht : t∈Set.Icc (0:ℝ) 1) (j : Fin n) :
      dualRow a r j ((1-t) • (y∘e) i+t • (y∘e) (next i)) ≤
        dualRow a r (e i) ((1-t) • (y∘e) i+t • (y∘e) (next i)) := by
    simpa only [Function.comp_def,hsucc] using
      transition_closed_edge_row_max a y σ r c hbound hexact (e i) j ht
  let i0 : ι := Classical.choice inferInstance
  have hne : (y∘e) i0≠(y∘e) (next i0) := by
    change y (e i0)≠y (e (next i0))
    rw [hsucc]
    exact hy.ne (hm i0).symm
  have hmid : edgeCrossPoint ((y∘e) i0) ((y∘e) (next i0)) (1/2) 0∈strictDualCell a r (e i0) := by
    rw [edgeCrossPoint_zero_offset]
    exact hedge i0 (1/2) (by norm_num)
  have hexnonzero := exists_nonzero_polygon_index_of_cell_sides next (y∘e) i0 hne
    (isOpen_strictDualCell a r (e i0)) hmid
    (fun q hq hb => strictDualCell_polygon_boundary_subset next (y∘e) a r e he hactive i0 hq hb)
    L R hgap (hL i0) (hR i0)
  refine ⟨L,R,hgap,?_,hL,hR,?_⟩
  · exact coherent_polygon_orientation_dichotomy next (y∘e) (fun i => strictDualCell a r (e i))
      (fun i => isOpen_strictDualCell a r (e i)) hedge L R hgap hL hR hexnonzero
  · intro q hq
    exact polygonIndexPhase_three_values next (y∘e) (fun i => strictDualCell a r (e i))
      (fun i => isOpen_strictDualCell a r (e i)) hedge L R hL hR hq

end MonotoneMatching
