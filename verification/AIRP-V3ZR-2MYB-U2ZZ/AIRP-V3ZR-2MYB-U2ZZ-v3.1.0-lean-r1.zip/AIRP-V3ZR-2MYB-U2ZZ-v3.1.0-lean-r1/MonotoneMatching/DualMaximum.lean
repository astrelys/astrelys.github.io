import MonotoneMatching.ConvexSmoothing
import MonotoneMatching.TransitionCellIncidence
noncomputable section
namespace MonotoneMatching
open Set MeasureTheory ContinuousLinearMap
open scoped BigOperators InnerProductSpace Convolution Topology
set_option backward.isDefEq.respectTransparency.types false

/-- The actual finite affine maximum associated with the exact dual rows. -/
def dualMaximum {n : ℕ} [Nonempty (Fin n)] (a : Fin n → ℂ) (r : Fin n → ℝ) (p : ℂ) : ℝ :=
  Finset.univ.sup' Finset.univ_nonempty (fun i => dualRow a r i p)

theorem dualRow_le_dualMaximum {n : ℕ} [Nonempty (Fin n)]
    (a : Fin n → ℂ) (r : Fin n → ℝ) (i : Fin n) (p : ℂ) :
    dualRow a r i p ≤ dualMaximum a r p :=
  Finset.le_sup' (f := fun j => dualRow a r j p) (Finset.mem_univ i)

theorem dualMaximum_eq_of_row_max {n : ℕ} [Nonempty (Fin n)]
    (a : Fin n → ℂ) (r : Fin n → ℝ) (i : Fin n) (p : ℂ)
    (h : ∀ j, dualRow a r j p ≤ dualRow a r i p) :
    dualMaximum a r p = dualRow a r i p := by
  apply le_antisymm _ (dualRow_le_dualMaximum a r i p)
  exact (Finset.sup'_le_iff _ _).mpr (fun j _ => h j)

theorem convex_dualMaximum {n : ℕ} [Nonempty (Fin n)]
    (a : Fin n → ℂ) (r : Fin n → ℝ) : ConvexOn ℝ univ (dualMaximum a r) := by
  refine ⟨convex_univ,?_⟩
  intro x _ y _ s t hs ht hst
  apply (Finset.sup'_le_iff _ _).mpr
  intro i _
  have he : dualRow a r i (s • x+t • y)=s*dualRow a r i x+t*dualRow a r i y := by
    simp only [dualRow,inner_add_right,inner_smul_right]
    nlinarith [congrArg (fun z : ℝ => z*r i) hst]
  rw [he]
  exact add_le_add (mul_le_mul_of_nonneg_left (dualRow_le_dualMaximum a r i x) hs)
    (mul_le_mul_of_nonneg_left (dualRow_le_dualMaximum a r i y) ht)

theorem lipschitz_dualMaximum {n : ℕ} [Nonempty (Fin n)]
    (a : Fin n → ℂ) (r : Fin n → ℝ) (L : NNReal) (hL : ∀ i, ‖a i‖ ≤ L) :
    LipschitzWith L (dualMaximum a r) := by
  have hone (x y : ℂ) : dualMaximum a r x-dualMaximum a r y ≤ L*‖x-y‖ := by
    apply sub_le_iff_le_add.mpr
    apply (Finset.sup'_le_iff _ _).mpr
    intro i _
    have hb := real_inner_le_norm (a i) (x-y)
    have hh := mul_le_mul_of_nonneg_right (hL i) (norm_nonneg (x-y))
    have hr := dualRow_le_dualMaximum a r i y
    simp only [inner_sub_right] at hb
    simp only [dualRow] at hr ⊢
    linarith
  apply LipschitzWith.of_dist_le_mul
  intro x y
  rw [Real.dist_eq,dist_eq_norm]
  apply abs_le.mpr
  have h := hone y x
  rw [norm_sub_rev] at h
  exact ⟨by linarith,hone x y⟩

theorem continuous_dualMaximum {n : ℕ} [Nonempty (Fin n)]
    (a : Fin n → ℂ) (r : Fin n → ℝ) : Continuous (dualMaximum a r) := by
  let L : NNReal := ∑ i, ‖a i‖₊
  apply (lipschitz_dualMaximum a r L _).continuous
  intro i
  exact_mod_cast Finset.single_le_sum (fun j _ => (zero_le : (0:NNReal) ≤ ‖a j‖₊)) (Finset.mem_univ i)

theorem dualMaximum_locally_affine {n : ℕ} [Nonempty (Fin n)]
    (a : Fin n → ℂ) (r : Fin n → ℝ) (i : Fin n) (p : ℂ)
    (hp : p ∈ strictDualCell a r i) :
    ∀ᶠ q in 𝓝 p,dualMaximum a r q=dualRow a r i q := by
  filter_upwards [(isOpen_strictDualCell a r i).mem_nhds hp] with q hq
  apply dualMaximum_eq_of_row_max
  intro j
  by_cases hji : j=i
  · subst j; rfl
  · exact (hq j hji).le

end MonotoneMatching
