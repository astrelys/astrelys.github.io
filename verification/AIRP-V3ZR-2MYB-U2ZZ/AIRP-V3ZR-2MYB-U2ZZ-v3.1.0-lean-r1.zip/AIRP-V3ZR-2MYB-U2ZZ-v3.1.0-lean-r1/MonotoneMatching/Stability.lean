import MonotoneMatching.Rotation
import Mathlib.Tactic.FunProp

/-! Finite strict witnesses persist under perturbation of both planar lists. -/
set_option maxHeartbeats 1000000
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

/-- The coordinate rotation is ordinary multiplication by a unit complex number. -/
theorem rotateClockwise_eq_mul (t : ℝ) (z : ℂ) :
    rotateClockwise t z = (⟨Real.cos t, -Real.sin t⟩ : ℂ) * z := by
  apply Complex.ext <;> simp [rotateClockwise, Complex.mul_re, Complex.mul_im]
  ring

/-- Continuity in the input point at a fixed angle. -/
theorem continuous_rotateClockwise (t : ℝ) : Continuous (rotateClockwise t) := by
  have h : rotateClockwise t = fun z => (⟨Real.cos t, -Real.sin t⟩ : ℂ) * z :=
    funext (rotateClockwise_eq_mul t)
  rw [h]
  exact continuous_const.mul continuous_id

/-- Each fixed assignment cost varies continuously with both input lists. -/
theorem continuous_rotated_cost {n : ℕ} (t : ℝ) (σ : Equiv.Perm (Fin n)) :
    Continuous (fun p : (Fin n → ℂ) × (Fin n → ℂ) =>
      assignmentCost p.1 (rotateClockwise t ∘ p.2) σ) := by
  unfold assignmentCost
  apply continuous_finsetSum
  intro i _
  exact ((continuous_apply i).comp continuous_fst |>.sub
    ((continuous_rotateClockwise t).comp ((continuous_apply (σ i)).comp continuous_snd))).norm.pow 2

/-- Fixed-angle unique optimality is an open condition in both lists. -/
theorem isOpen_uniqueMinimum_at {n : ℕ} (t : ℝ) (σ : Equiv.Perm (Fin n)) :
    IsOpen {p : (Fin n → ℂ) × (Fin n → ℂ) |
      UniqueMinimum p.1 (rotateClockwise t ∘ p.2) σ} := by
  classical
  change IsOpen {p : (Fin n → ℂ) × (Fin n → ℂ) | ∀ τ, τ ≠ σ → assignmentCost p.1 (rotateClockwise t ∘ p.2) σ <
    assignmentCost p.1 (rotateClockwise t ∘ p.2) τ}
  simp only [Set.ofPred_forall]
  apply isOpen_iInter_of_finite
  intro τ
  apply isOpen_iInter_of_finite
  intro _
  exact isOpen_lt (continuous_rotated_cost t σ) (continuous_rotated_cost t τ)

/-- Existence of a strict rotation witness is open; the angle need not be uniformly chosen. -/
theorem isOpen_rotation_witness {n : ℕ} (σ : Equiv.Perm (Fin n)) :
    IsOpen {p : (Fin n → ℂ) × (Fin n → ℂ) | σ ∈ rotationOptimizers p.1 p.2} := by
  simp only [mem_rotationOptimizers, Set.ofPred_exists]
  exact isOpen_iUnion fun t => isOpen_uniqueMinimum_at t σ

/-- A single open neighborhood preserves every optimizer witnessed at the original input.
No genericity, noncollision, or upper-bound theorem is assumed. -/
theorem rotation_optimizers_persist {n : ℕ} (a b : Fin n → ℂ) :
    ∃ U : Set ((Fin n → ℂ) × (Fin n → ℂ)), IsOpen U ∧ (a,b) ∈ U ∧
      ∀ p ∈ U, rotationOptimizers a b ⊆ rotationOptimizers p.1 p.2 := by
  classical
  let U : Set ((Fin n → ℂ) × (Fin n → ℂ)) :=
    {p | ∀ σ ∈ rotationOptimizers a b, σ ∈ rotationOptimizers p.1 p.2}
  refine ⟨U, ?_, ?_, ?_⟩
  · dsimp [U]
    simp only [Set.ofPred_forall]
    exact isOpen_biInter_finset fun σ _ => isOpen_rotation_witness σ
  · intro σ hσ
    exact hσ
  · intro p hp σ hσ
    exact hp σ hσ

/-- The number of unique rotation optima cannot drop under sufficiently small input perturbations. -/
theorem rotation_count_persists {n : ℕ} (a b : Fin n → ℂ) :
    ∃ U : Set ((Fin n → ℂ) × (Fin n → ℂ)), IsOpen U ∧ (a,b) ∈ U ∧
      ∀ p ∈ U, rotationCount a b ≤ rotationCount p.1 p.2 := by
  obtain ⟨U, ho, hm, hp⟩ := rotation_optimizers_persist a b
  exact ⟨U, ho, hm, fun p h => Finset.card_le_card (hp p h)⟩

/-- Noncollinearity of a finite planar list is an open condition. -/
theorem isOpen_noncollinearList {n : ℕ} :
    IsOpen {a : Fin n → ℂ | NoncollinearList a} := by
  simp only [NoncollinearList, Set.ofPred_exists]
  apply isOpen_iUnion
  intro i
  apply isOpen_iUnion
  intro j
  apply isOpen_iUnion
  intro k
  apply isOpen_ne_fun
  · fun_prop
  · exact continuous_const

/-- Any noncollinear attaining input has an open noncollinear neighborhood with
at least as many unique optima. This is a lower-bound persistence statement only. -/
theorem noncollinear_count_persists {n : ℕ} (a b : Fin n → ℂ)
    (ha : NoncollinearList a) (hb : NoncollinearList b) :
    ∃ U : Set ((Fin n → ℂ) × (Fin n → ℂ)), IsOpen U ∧ (a,b) ∈ U ∧
      ∀ p ∈ U, NoncollinearList p.1 ∧ NoncollinearList p.2 ∧
        rotationCount a b ≤ rotationCount p.1 p.2 := by
  obtain ⟨U, ho, hm, hc⟩ := rotation_count_persists a b
  refine ⟨U ∩ ({a : Fin n → ℂ | NoncollinearList a} ×ˢ
    {b : Fin n → ℂ | NoncollinearList b}),
    ho.inter (isOpen_noncollinearList.prod isOpen_noncollinearList),
    ⟨hm, ha, hb⟩, ?_⟩
  intro p hp
  exact ⟨hp.2.1, hp.2.2, hc p hp.1⟩

end MonotoneMatching
