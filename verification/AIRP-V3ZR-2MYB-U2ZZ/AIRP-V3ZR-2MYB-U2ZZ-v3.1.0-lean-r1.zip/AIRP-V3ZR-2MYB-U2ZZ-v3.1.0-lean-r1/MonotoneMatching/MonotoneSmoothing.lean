import Mathlib.Analysis.Calculus.BumpFunction.Convolution
import Mathlib.Analysis.Calculus.ContDiff.Convolution
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.Analysis.InnerProductSpace.Dual
import Mathlib.Analysis.Calculus.Deriv.Slope
import Mathlib.Analysis.Calculus.Deriv.Mul
noncomputable section
namespace MonotoneMatching
open MeasureTheory ContinuousLinearMap
open scoped BigOperators InnerProductSpace Convolution
set_option backward.isDefEq.respectTransparency.types false

/-- Convolution with a nonnegative normalized smooth bump preserves monotonicity. -/
theorem monotone_bump_convolution (F : ℂ → ℂ) (hF : Continuous F)
    (hmono : ∀ x y,0 ≤ inner ℝ (x-y) (F x-F y)) (φ : ContDiffBump (0:ℂ)) :
    ∀ x y,0 ≤ inner ℝ (x-y)
      ((φ.normed volume ⋆[lsmul ℝ ℝ,volume] F) x-
       (φ.normed volume ⋆[lsmul ℝ ℝ,volume] F) y) := by
  intro x y
  have hi (p : ℂ) : Integrable (fun t => φ.normed volume t • F (p-t)) :=
    φ.hasCompactSupport_normed.convolutionExists_left_of_continuous_right
      (lsmul ℝ ℝ) φ.continuous_normed.locallyIntegrable hF p
  simp only [convolution_def,lsmul_apply]
  rw [← integral_sub (hi x) (hi y)]
  change 0 ≤ (innerSL ℝ (x-y)) (∫ t,φ.normed volume t • F (x-t)-φ.normed volume t • F (y-t))
  have he := (innerSL ℝ (x-y)).integral_comp_comm ((hi x).sub (hi y))
  simp only [Pi.sub_apply] at he
  rw [← he]
  apply integral_nonneg
  intro t
  change 0 ≤ inner ℝ (x-y) (φ.normed volume t • F (x-t)-φ.normed volume t • F (y-t))
  rw [← smul_sub,inner_smul_right]
  apply mul_nonneg (φ.nonneg_normed t)
  convert hmono (x-t) (y-t) using 1
  congr 1
  abel

/-- Every continuous global monotone field admits smooth monotone convolution approximants. -/
theorem smooth_monotone_bump_convolution (F : ℂ → ℂ) (hF : Continuous F)
    (hmono : ∀ x y,0 ≤ inner ℝ (x-y) (F x-F y)) (φ : ContDiffBump (0:ℂ)) :
    ContDiff ℝ (⊤ : ℕ∞) (φ.normed volume ⋆[lsmul ℝ ℝ,volume] F) ∧
      ∀ x y,0 ≤ inner ℝ (x-y)
        ((φ.normed volume ⋆[lsmul ℝ ℝ,volume] F) x-
         (φ.normed volume ⋆[lsmul ℝ ℝ,volume] F) y) := by
  exact ⟨φ.hasCompactSupport_normed.contDiff_convolution_left (lsmul ℝ ℝ)
    φ.contDiff_normed hF.locallyIntegrable,monotone_bump_convolution F hF hmono φ⟩

/-- Uniform smooth monotone approximation of a globally Lipschitz monotone planar field. -/
theorem exists_smooth_monotone_approximation (F : ℂ → ℂ) (L : ℝ) (hL : 0 < L)
    (hLip : ∀ x y,‖F x-F y‖ ≤ L*‖x-y‖)
    (hmono : ∀ x y,0 ≤ inner ℝ (x-y) (F x-F y)) (ε : ℝ) (hε : 0 < ε) :
    ∃ G : ℂ → ℂ, ContDiff ℝ (⊤ : ℕ∞) G ∧
      (∀ x y,0 ≤ inner ℝ (x-y) (G x-G y)) ∧ (∀ x,‖G x-F x‖ ≤ ε) := by
  have hF : Continuous F := (LipschitzWith.of_dist_le_mul
    (K := ⟨L,hL.le⟩) (fun x y => by
      change dist (F x) (F y) ≤ L*dist x y
      simpa only [dist_eq_norm] using hLip x y)).continuous
  let δ := ε/L
  have hδ : 0 < δ := div_pos hε hL
  let φ : ContDiffBump (0:ℂ) := ⟨δ/2,δ,by positivity,by linarith⟩
  obtain ⟨hs,hm⟩ := smooth_monotone_bump_convolution F hF hmono φ
  refine ⟨_,hs,hm,?_⟩
  intro x
  rw [← dist_eq_norm]
  apply φ.dist_normed_convolution_le hF.aestronglyMeasurable
  intro y hy
  have hd : ‖y-x‖ ≤ δ := (by simpa only [Metric.mem_ball,dist_eq_norm] using hy : ‖y-x‖ < δ).le
  rw [dist_eq_norm]
  calc
    ‖F y-F x‖ ≤ L*‖y-x‖ := hLip y x
    _ ≤ L*δ := mul_le_mul_of_nonneg_left hd hL.le
    _ = ε := by dsimp [δ]; field_simp

/-- The quadratic form of the derivative of a monotone field is nonnegative. -/
theorem monotone_field_derivative_nonnegative (F : ℂ → ℂ)
    (hmono : ∀ x y,0 ≤ inner ℝ (x-y) (F x-F y))
    (x : ℂ) (A : ℂ →L[ℝ] ℂ) (hA : HasFDerivAt F A x) (v : ℂ) :
    0 ≤ inner ℝ v (A v) := by
  let g : ℝ → ℝ := fun t => inner ℝ v (F (x+t • v))
  have hg : Monotone g := by
    intro s t hst
    rcases hst.eq_or_lt with he | hst
    · subst t; rfl
    have hm := hmono (x+t • v) (x+s • v)
    have he : (x+t • v)-(x+s • v)=(t-s) • v := by module
    rw [he,inner_smul_left,inner_sub_right] at hm
    have hp : 0 < t-s := sub_pos.mpr hst
    have hn : 0 ≤ inner ℝ v (F (x+t • v))-inner ℝ v (F (x+s • v)) :=
      (mul_nonneg_iff_of_pos_left hp).mp hm
    exact sub_nonneg.mp hn
  have hv : HasDerivAt (fun t : ℝ => x+t • v) v 0 := by
    simpa using (hasDerivAt_id (0:ℝ)).smul_const v |>.const_add x
  have hcomp : HasDerivAt (fun t : ℝ => F (x+t • v)) (A v) 0 := by
    exact (by simpa only [zero_smul,add_zero] using hA : HasFDerivAt F A (x+(0:ℝ) • v)).comp_hasDerivAt 0 hv
  have hd : HasDerivAt g (inner ℝ v (A v)) 0 :=
    (innerSL ℝ v).hasFDerivAt.comp_hasDerivAt 0 hcomp
  rw [← hd.deriv]
  exact hg.deriv_nonneg

end MonotoneMatching
