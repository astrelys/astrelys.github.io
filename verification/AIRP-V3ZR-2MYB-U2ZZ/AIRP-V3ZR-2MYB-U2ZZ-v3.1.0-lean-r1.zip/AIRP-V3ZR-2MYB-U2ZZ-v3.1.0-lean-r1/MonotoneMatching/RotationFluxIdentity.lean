import MonotoneMatching.RotationScore

/-! The rotational score derivative is exactly the finite dual-gradient flux. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

theorem rotation_event_derivative_flux {n : ℕ} (a y : Fin n → ℂ) (σ : Equiv.Perm (Fin n)) :
    directionalScoreDerivative (complexAssignmentScore a y σ-complexAssignmentScore a y (Equiv.refl _)) 0 =
      ∑ i, ((a i).re*((y (σ i)).im-(y i).im)-(a i).im*((y (σ i)).re-(y i).re)) := by
  simp only [directionalScoreDerivative,Real.sin_zero,Real.cos_zero,neg_zero,zero_mul,one_mul,zero_add,
    Complex.sub_im,complexAssignmentScore,Complex.im_sum,Equiv.refl_apply,← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro i _
  simp only [Complex.mul_im,Complex.conj_re,Complex.conj_im]
  ring

theorem rotation_event_derivative_cycle_flux {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) {n : ℕ} (a y : Fin n → ℂ) (σ : Equiv.Perm (Fin n))
    (e : ι → Fin n) (he : Function.Injective e) (hsucc : ∀ i, e (next i)=σ (e i))
    (hcover : ∀ i, σ i≠i → ∃ j, e j=i) :
    directionalScoreDerivative (complexAssignmentScore a y σ-complexAssignmentScore a y (Equiv.refl _)) 0 =
      ∑ i, ((a (e i)).re*((y (e (next i))).im-(y (e i)).im)-
        (a (e i)).im*((y (e (next i))).re-(y (e i)).re)) := by
  rw [rotation_event_derivative_flux]
  symm
  apply Fintype.sum_of_injective e he
  · intro i hi
    have hfix : σ i=i := by by_contra hn; exact hi (hcover i hn)
    simp only [hfix,sub_self,mul_zero]
  · intro i
    rw [hsucc]

end MonotoneMatching
