import MonotoneMatching.OptimalityCone
import MonotoneMatching.ProjectionSweep
import MonotoneMatching.RotationGeometry
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Analysis.SpecialFunctions.Complex.Arg

/-! A continuous real phase on the strict identity-optimality region. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators InnerProductSpace

/-- The collision discriminant, written as the Vandermonde determinant. -/
def configurationVandermonde {n : ℕ} (b : Fin n → ℂ) : ℂ :=
  (Matrix.vandermonde b).det

theorem configurationVandermonde_ne_zero_iff {n : ℕ} (b : Fin n → ℂ) :
    configurationVandermonde b ≠ 0 ↔ Function.Injective b :=
  Matrix.det_vandermonde_ne_zero_iff

theorem configurationVandermonde_permute {n : ℕ} (b : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) :
    configurationVandermonde (b ∘ σ) =
      (Equiv.Perm.sign σ : ℂ) * configurationVandermonde b := by
  exact Matrix.det_permute σ (Matrix.vandermonde b)

theorem configurationVandermonde_product {n : ℕ} (b : Fin n → ℂ) :
    configurationVandermonde b = ∏ p ∈ increasingPairs n, (b p.2 - b p.1) := by
  classical
  rw [configurationVandermonde, Matrix.det_vandermonde, increasingPairs]
  rw [Finset.prod_filter]
  rw [Finset.prod_product]
  simp only [← Finset.prod_filter]
  apply Finset.prod_congr rfl
  intro i _
  congr 1
  ext j
  simp

theorem configurationVandermonde_scale {n : ℕ} (b : Fin n → ℂ) (z : ℂ) :
    configurationVandermonde (fun i => z * b i) =
      z ^ (n.choose 2) * configurationVandermonde b := by
  classical
  rw [configurationVandermonde_product, configurationVandermonde_product]
  simp_rw [← mul_sub]
  rw [Finset.prod_mul_distrib, Finset.prod_const]
  congr 2
  simpa [increasingPairs] using
    (Finset.card_product_filter_lt (s := (Finset.univ : Finset (Fin n))))

theorem configurationVandermonde_rotation {n : ℕ} (b : Fin n → ℂ) (t : ℝ) :
    configurationVandermonde (rotateClockwise t ∘ b) =
      (⟨Real.cos t, -Real.sin t⟩ : ℂ) ^ (n.choose 2) * configurationVandermonde b := by
  simpa only [Function.comp_def, rotateClockwise_eq_mul] using
    configurationVandermonde_scale b (⟨Real.cos t, -Real.sin t⟩ : ℂ)

/-- Each paired relative direction has positive real part throughout the cone. -/
theorem cone_pair_real_positive {n : ℕ} (a b : Fin n → ℂ)
    (hb : b ∈ identityOptimalityCone a) {i j : Fin n} (hij : i ≠ j) :
    0 < ((b j - b i) * (starRingEnd ℂ) (a j - a i)).re := by
  simpa only [Complex.inner] using unique_identity_pair_positive a b hb j i hij.symm

/-- A single-valued phase determined by the source-pair half-planes. -/
def identityPhase {n : ℕ} (a b : Fin n → ℂ) : ℝ :=
  ∑ p ∈ increasingPairs n, Complex.arg ((b p.2 - b p.1) * (starRingEnd ℂ) (a p.2 - a p.1))

theorem continuous_identityPhase {n : ℕ} (a : Fin n → ℂ) :
    Continuous (fun b : identityOptimalityCone a => identityPhase a b.val) := by
  unfold identityPhase
  apply continuous_finsetSum
  intro p hp
  have hp' : p.1 ≠ p.2 := ne_of_lt (Finset.mem_filter.mp hp).2
  apply continuous_iff_continuousAt.mpr
  intro b
  have hpos := cone_pair_real_positive a b.val b.property hp'
  have hc : Continuous (fun y : identityOptimalityCone a =>
      (y.val p.2 - y.val p.1) * (starRingEnd ℂ) (a p.2 - a p.1)) :=
    (((continuous_apply p.2).comp continuous_subtype_val).sub
      ((continuous_apply p.1).comp continuous_subtype_val)).mul continuous_const
  exact ContinuousAt.comp (f := fun y : identityOptimalityCone a =>
    (y.val p.2 - y.val p.1) * (starRingEnd ℂ) (a p.2 - a p.1))
    (Complex.continuousAt_arg (Or.inl hpos)) hc.continuousAt

/-- Closing a path inside the strict cone closes this real phase exactly,
so no multiple of 2π can be silently discarded. -/
theorem identityPhase_closed_endpoints {n : ℕ} (a : Fin n → ℂ)
    (γ : ℝ → identityOptimalityCone a) {u v : ℝ} (h : γ u = γ v) :
    identityPhase a (γ u).val = identityPhase a (γ v).val := by rw [h]

/-- Argument of a finite nonzero product, with all winding information retained
in the angle group. -/
theorem arg_prod_coe_angle {ι : Type*} (s : Finset ι) (f : ι → ℂ)
    (hf : ∀ i ∈ s, f i ≠ 0) :
    (Complex.arg (∏ i ∈ s, f i) : Real.Angle) =
      ∑ i ∈ s, (Complex.arg (f i) : Real.Angle) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert i s hi ih =>
    rw [Finset.prod_insert hi, Finset.sum_insert hi]
    rw [Complex.arg_mul_coe_angle (hf i (Finset.mem_insert_self _ _))
      (Finset.prod_ne_zero_iff.mpr (fun j hj => hf j (Finset.mem_insert_of_mem hj)))]
    rw [ih (fun j hj => hf j (Finset.mem_insert_of_mem hj))]

/-- The real phase is a lift of the source-normalized collision discriminant. -/
theorem identityPhase_coe_angle {n : ℕ} (a b : Fin n → ℂ)
    (hb : b ∈ identityOptimalityCone a) :
    (identityPhase a b : Real.Angle) =
      (Complex.arg (configurationVandermonde b *
        (starRingEnd ℂ) (configurationVandermonde a)) : Real.Angle) := by
  classical
  have hnz : ∀ p ∈ increasingPairs n,
      (b p.2 - b p.1) * (starRingEnd ℂ) (a p.2 - a p.1) ≠ 0 := by
    intro p hp hz
    have h := cone_pair_real_positive a b hb (ne_of_lt (Finset.mem_filter.mp hp).2)
    rw [hz] at h
    exact lt_irrefl 0 h
  rw [identityPhase]
  change Real.Angle.coeHom (∑ p ∈ increasingPairs n,
    Complex.arg ((b p.2 - b p.1) * (starRingEnd ℂ) (a p.2 - a p.1))) = _
  rw [map_sum]
  change (∑ p ∈ increasingPairs n,
    (Complex.arg ((b p.2 - b p.1) * (starRingEnd ℂ) (a p.2 - a p.1)) : Real.Angle)) = _
  rw [← arg_prod_coe_angle _ _ hnz]
  congr 2
  rw [Finset.prod_mul_distrib, configurationVandermonde_product,
    configurationVandermonde_product, map_prod]

end MonotoneMatching
