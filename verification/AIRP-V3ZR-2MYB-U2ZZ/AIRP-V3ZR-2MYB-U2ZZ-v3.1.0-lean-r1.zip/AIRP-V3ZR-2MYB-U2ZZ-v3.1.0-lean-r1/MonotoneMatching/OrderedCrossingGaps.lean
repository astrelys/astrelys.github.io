import MonotoneMatching.FiniteCuts
import MonotoneMatching.HorizontalCrossings

/-! Ordered finite crossing locations with certified boundary-free gap samples. -/
noncomputable section
namespace MonotoneMatching

theorem ordered_crossing_gap_samples (T : Finset ℝ)
    (top : ℝ) (htop : ∀ t∈T, t<top) :
    ∃ x : Fin T.card → ℝ, ∃ gap : Fin (T.card+1) → ℝ,
      StrictMono x ∧ (∀ t, t∈T ↔ ∃ i, x i=t) ∧
      gap (Fin.last T.card)=top ∧
      (∀ i, gap i.castSucc<x i ∧ x i<gap i.succ) ∧
      (∀ i, ∀ t∈Set.Ico (gap i.castSucc) (x i), t∉T) ∧
      (∀ i, ∀ t∈Set.Ioc (x i) (gap i.succ), t∉T) := by
  let e := T.orderIsoOfFin rfl
  let x : Fin T.card → ℝ := fun i => (e i).val
  let gap : Fin (T.card+1) → ℝ := Fin.lastCases top (fun i => finiteCut T (x i))
  have hx : StrictMono x := (T.orderEmbOfFin rfl).strictMono
  have hmem (i : Fin T.card) : x i∈T := (e i).property
  have hsurj (t : ℝ) (ht : t∈T) : ∃ i, x i=t := by
    obtain ⟨i,hi⟩ := e.surjective ⟨t,ht⟩
    exact ⟨i,congrArg Subtype.val hi⟩
  have hcast (i : Fin T.card) : gap i.castSucc=finiteCut T (x i) := by simp [gap]
  have hlast : gap (Fin.last T.card)=top := by simp [gap]
  have hright (i : Fin T.card) : x i<gap i.succ := by
    by_cases hi : i.val+1=T.card
    · have heq : i.succ=Fin.last T.card := Fin.ext hi
      rw [heq,hlast]
      exact htop _ (hmem i)
    · have hil : i.val+1<T.card := by omega
      let j : Fin T.card := ⟨i.val+1,hil⟩
      have heq : i.succ=j.castSucc := by apply Fin.ext; rfl
      rw [heq,hcast]
      exact (lt_finiteCut_iff T (x j) (x i) (hmem i)).mpr (hx (by change i.val < i.val+1; omega))
  refine ⟨x,gap,hx,?_,hlast,?_,?_,?_⟩
  · intro t
    exact ⟨hsurj t,fun ⟨i,hi⟩ => hi ▸ hmem i⟩
  · intro i
    exact ⟨by rw [hcast]; exact finiteCut_lt T _,hright i⟩
  · intro i t ht htin
    have hlt := (lt_finiteCut_iff T (x i) t htin).mpr ht.2
    rw [← hcast] at hlt
    exact (not_lt_of_ge ht.1) hlt
  · intro i t ht htin
    obtain ⟨k,rfl⟩ := hsurj t htin
    have hik : i<k := hx.lt_iff_lt.mp ht.1
    by_cases hi : i.val+1=T.card
    · have hk := k.isLt
      change i.val<k.val at hik
      omega
    · have hil : i.val+1<T.card := by omega
      let j : Fin T.card := ⟨i.val+1,hil⟩
      have heq : i.succ=j.castSucc := by apply Fin.ext; rfl
      rw [heq,hcast] at ht
      have hklt : x k<finiteCut T (x j) := lt_of_le_of_ne ht.2 (fun he => finiteCut_not_mem T (x j) (he ▸ hmem k))
      have hkj : k<j := hx.lt_iff_lt.mp ((lt_finiteCut_iff T (x j) (x k) (hmem k)).mp hklt)
      change k.val < i.val+1 at hkj
      change i.val<k.val at hik
      omega

end MonotoneMatching
