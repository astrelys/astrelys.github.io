import MonotoneMatching.FourPieceArguments

/-! The two displaced argument increments of an anchored arc can be computed
without choosing a principal-argument branch on that arc. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval

theorem anchored_product_increment (δ : I → ℂ) (hc : Continuous δ)
    (z w : ℂ) (h0 : δ 0=z) (h1 : δ 1= -z)
    (hn : ∀ t s : I, δ s-(t:ℝ) • w≠0 ∧ δ s+(t:ℝ) • w≠0)
    (φ ψ : C(I,ℝ))
    (hφ : ∀ s, (φ s : Real.Angle)=(Complex.arg (δ s) : Real.Angle))
    (hψ : ∀ s, (ψ s : Real.Angle)=(Complex.arg ((δ s-w)*(δ s+w)) : Real.Angle)) :
    ψ 1-ψ 0=2*(φ 1-φ 0) := by
  let H := fun p : I×I => (δ p.2-(p.1:ℝ) • w)*(δ p.2+(p.1:ℝ) • w)
  have hcont : Continuous H := by dsimp [H]; fun_prop
  have hnon (p : I×I) : H p≠0 := mul_ne_zero (hn p.1 p.2).1 (hn p.1 p.2).2
  have hloop (t : I) : H (t,1)=H (t,0) := by dsimp only [H]; rw [h0,h1]; ring
  let χ : C(I,ℝ) := ⟨fun s => φ s+φ s,φ.continuous.add φ.continuous⟩
  have hδ (s : I) : δ s≠0 := by simpa using (hn 0 s).1
  have hχ (s : I) : (χ s : Real.Angle)=(Complex.arg (H (0,s)) : Real.Angle) := by
    simp [χ,H,Real.Angle.coe_add,hφ,Complex.arg_mul_coe_angle (hδ s) (hδ s)]
  have he := argument_loop_increment_homotopy H hcont hnon hloop χ ψ hχ
    (fun s => by simpa [H] using hψ s)
  dsimp only [χ,ContinuousMap.coe_mk] at he
  linarith

theorem argument_increment_two_pieces (φ : C(I,ℝ)) :
    φ 1-φ 0 =
      (φ (uniformArgumentSubparameter (m := 2) (by norm_num) 0 1)-
       φ (uniformArgumentSubparameter (m := 2) (by norm_num) 0 0))+
      (φ (uniformArgumentSubparameter (m := 2) (by norm_num) 1 1)-
       φ (uniformArgumentSubparameter (m := 2) (by norm_num) 1 0)) := by
  simp only [uniformArgumentSubparameter_one,uniformArgumentSubparameter_zero]
  have hmid : (0 : Fin 2).succ=(1 : Fin 2).castSucc := rfl
  rw [hmid]
  have hz : (0 : Fin 2).castSucc=(0 : Fin 3) := rfl
  have ho : (1 : Fin 2).succ=Fin.last 2 := rfl
  rw [hz,ho,uniformArgumentNode_zero,uniformArgumentNode_last]
  ring

end MonotoneMatching
