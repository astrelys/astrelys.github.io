import Mathlib.Data.Finset.Max
import Mathlib.Basic.Real.Basic
import Mathlib.Tactic.Linarith

/-! Finite threshold cuts used to select strict projection witnesses. -/
noncomputable section
namespace MonotoneMatching

/-- Immediately below any member of a finite real set, one can select a point
which has crossed precisely its strictly smaller members. -/
theorem exists_strict_finite_cut (s : Finset ℝ) (x : ℝ) :
    ∃ c : ℝ, c < x ∧ c ∉ s ∧ ∀ y ∈ s, (y < c ↔ y < x) := by
  classical
  let lower := s.filter (· < x)
  by_cases hl : lower.Nonempty
  · let m := lower.max' hl
    have hm : m < x := (Finset.mem_filter.mp (lower.max'_mem hl)).2
    refine ⟨(m + x) / 2, by linarith, ?_, ?_⟩
    · intro hc
      have hmem : (m + x) / 2 ∈ lower := Finset.mem_filter.mpr ⟨hc, by linarith⟩
      have hle := lower.le_max' _ hmem
      change (m + x) / 2 ≤ m at hle
      linarith
    · intro y hy
      constructor
      · intro h; linarith
      · intro h
        have hle := lower.le_max' _ (Finset.mem_filter.mpr ⟨hy, h⟩)
        change y ≤ m at hle
        linarith
  · refine ⟨x - 1, by linarith, ?_, ?_⟩
    · intro hc
      exact hl ⟨x - 1, Finset.mem_filter.mpr ⟨hc, by linarith⟩⟩
    · intro y hy
      constructor
      · intro h; linarith
      · intro h
        exact (hl ⟨y, Finset.mem_filter.mpr ⟨hy, h⟩⟩).elim

/-- A fixed selection of the cuts; all properties are certified below. -/
def finiteCut (s : Finset ℝ) (x : ℝ) : ℝ :=
  Classical.choose (exists_strict_finite_cut s x)

theorem finiteCut_lt (s : Finset ℝ) (x : ℝ) : finiteCut s x < x :=
  (Classical.choose_spec (exists_strict_finite_cut s x)).1

theorem finiteCut_not_mem (s : Finset ℝ) (x : ℝ) : finiteCut s x ∉ s :=
  (Classical.choose_spec (exists_strict_finite_cut s x)).2.1

theorem lt_finiteCut_iff (s : Finset ℝ) (x y : ℝ) (hy : y ∈ s) :
    y < finiteCut s x ↔ y < x :=
  (Classical.choose_spec (exists_strict_finite_cut s x)).2.2 y hy

end MonotoneMatching
