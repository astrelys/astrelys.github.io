import MonotoneMatching.IntegralSliceFlux
import MonotoneMatching.CompactParametricIntegral
import MonotoneMatching.HorizontalPrimitive
noncomputable section
namespace MonotoneMatching
open MeasureTheory Set
open scoped BigOperators Topology
set_option backward.isDefEq.respectTransparency.types false

/-- The integral of an exact planar one-form on a straight edge is its endpoint difference. -/
theorem affine_edge_exact_integral (P J H : ℂ → ℝ) (hP : Continuous P) (hJ : Continuous J)
    (hH : ∀ p,HasFDerivAt H (P p • Complex.reCLM+J p • Complex.imCLM) p) (z w : ℂ) :
    (∫ t in (0:ℝ)..1,P ((1-t) • z+t • w)*(w.re-z.re)+
      J ((1-t) • z+t • w)*(w.im-z.im))=H w-H z := by
  have hc : Continuous (fun t : ℝ => (1-t) • z+t • w) := by fun_prop
  have hd (t : ℝ) : HasDerivAt (fun t : ℝ => H ((1-t) • z+t • w))
      (P ((1-t) • z+t • w)*(w.re-z.re)+J ((1-t) • z+t • w)*(w.im-z.im)) t := by
    have hp : HasDerivAt (fun t : ℝ => (1-t) • z+t • w) (w-z) t := by
      simpa only [Pi.add_def,Pi.sub_def,Pi.neg_apply,id_eq,one_smul,zero_sub,zero_add,neg_smul,
        sub_eq_add_neg,add_comm] using!
        (((hasDerivAt_const t (1:ℝ)).sub (hasDerivAt_id t)).smul_const z).add
          ((hasDerivAt_id t).smul_const w)
    simpa only [add_apply,smul_apply,smul_eq_mul,Complex.reCLM_apply,Complex.imCLM_apply,
      Complex.sub_re,Complex.sub_im] using! (hH _).comp_hasDerivAt t hp
  have hi : Continuous (fun t : ℝ => P ((1-t) • z+t • w)*(w.re-z.re)+
      J ((1-t) • z+t • w)*(w.im-z.im)) :=
    ((hP.comp hc).mul continuous_const).add ((hJ.comp hc).mul continuous_const)
  have he := intervalIntegral.integral_eq_sub_of_hasDerivAt (a := 0) (b := 1)
    (fun t _ => hd t) (hi.intervalIntegrable _ _)
  simpa using he

/-- Subtracting a global primitive does not change the total integral around a polygon. -/
theorem polygon_oneform_primitive_reduction {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (P Q J H : ℂ → ℝ)
    (hP : Continuous P) (hQ : Continuous Q) (hJ : Continuous J)
    (hH : ∀ p,HasFDerivAt H (P p • Complex.reCLM+J p • Complex.imCLM) p) :
    (∑ i,∫ t in (0:ℝ)..1,P ((1-t) • v i+t • v (next i))*((v (next i)).re-(v i).re)+
      Q ((1-t) • v i+t • v (next i))*((v (next i)).im-(v i).im)) =
    (∑ i,∫ t in (0:ℝ)..1,(Q ((1-t) • v i+t • v (next i))-
      J ((1-t) • v i+t • v (next i)))*((v (next i)).im-(v i).im)) := by
  have he (i : ι) :
      (∫ t in (0:ℝ)..1,P ((1-t) • v i+t • v (next i))*((v (next i)).re-(v i).re)+
        Q ((1-t) • v i+t • v (next i))*((v (next i)).im-(v i).im)) =
      H (v (next i))-H (v i)+
      (∫ t in (0:ℝ)..1,(Q ((1-t) • v i+t • v (next i))-
        J ((1-t) • v i+t • v (next i)))*((v (next i)).im-(v i).im)) := by
    have hc : Continuous (fun t : ℝ => (1-t) • v i+t • v (next i)) := by fun_prop
    have hi1 : Continuous (fun t : ℝ => P ((1-t) • v i+t • v (next i))*((v (next i)).re-(v i).re)+
      J ((1-t) • v i+t • v (next i))*((v (next i)).im-(v i).im)) :=
      ((hP.comp hc).mul continuous_const).add ((hJ.comp hc).mul continuous_const)
    have hi2 : Continuous (fun t : ℝ => (Q ((1-t) • v i+t • v (next i))-
      J ((1-t) • v i+t • v (next i)))*((v (next i)).im-(v i).im)) :=
      ((hQ.comp hc).sub (hJ.comp hc)).mul continuous_const
    rw [← affine_edge_exact_integral P J H hP hJ hH (v i) (v (next i)),
      ← intervalIntegral.integral_add (hi1.intervalIntegrable _ _) (hi2.intervalIntegrable _ _)]
    apply intervalIntegral.integral_congr
    intro t _
    ring
  simp_rw [he]
  rw [Finset.sum_add_distrib,Finset.sum_sub_distrib]
  have hc := Equiv.sum_comp next (fun i => H (v i))
  rw [hc,sub_self,zero_add]

/-- Green-type sign theorem for the actual transition polygon, proved by a global primitive
and horizontal slice integration. Nonnegative curl gives nonpositive clockwise flux. -/
theorem polygon_nonnegative_curl_integral_nonpos {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (v : ι → ℂ)
    {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ) (e : ι → Fin n) (he : Function.Injective e)
    (hedge : ∀ i, ∀ t∈Set.Ioo (0:ℝ) 1, (1-t) • v i+t • v (next i)∈strictDualCell a r (e i))
    (L R : ℝ) (hgap : L-R=2*Real.pi)
    (hL : ∀ i q, q∈strictDualCell a r (e i) → 0<edgeSide (v i) (v (next i)) q → polygonIndexPhase next v q=L)
    (hR : ∀ i q, q∈strictDualCell a r (e i) → edgeSide (v i) (v (next i)) q<0 → polygonIndexPhase next v q=R)
    (hphase : ∀ q, q∉polygonBoundary next v → polygonIndexPhase next v q≤0)
    (P Q : ℂ → ℝ) (DP DQ : ℂ → ℂ →L[ℝ] ℝ)
    (hP : Continuous P) (hQ : Continuous Q) (hDP : Continuous DP)
    (hdP : ∀ p,HasFDerivAt P (DP p) p) (hdQ : ∀ p,HasFDerivAt Q (DQ p) p)
    (hcurl : ∀ p,0 ≤ DQ p 1-DP p Complex.I) :
    (∑ i,∫ t in (0:ℝ)..1,P ((1-t) • v i+t • v (next i))*((v (next i)).re-(v i).re)+
      Q ((1-t) • v i+t • v (next i))*((v (next i)).im-(v i).im)) ≤ 0 := by
  let J : ℂ → ℝ := fun p => ∫ x in (0:ℝ)..p.re,DP ((x:ℂ)+(p.im:ℂ)*Complex.I) Complex.I
  let H : ℂ → ℝ := fun p => ∫ t in (0:ℝ)..1,p.re*P (horizontalScaling t p)
  have hJ : Continuous J := continuous_horizontal_primitive_vertical DP hDP
  have hH (p : ℂ) : HasFDerivAt H (P p • Complex.reCLM+J p • Complex.imCLM) p :=
    horizontal_primitive_hasFDerivAt P DP hP hDP hdP p
  rw [polygon_oneform_primitive_reduction next v P Q J H hP hQ hJ hH]
  apply polygon_vertical_monotone_integral_nonpos next v a r e he hedge L R hgap hL hR hphase
    (fun p => Q p-J p) (hQ.sub hJ)
  intro y
  simpa only [horizontalPoint,Complex.mk_eq_add_mul_I,Complex.add_re,Complex.add_im,
    Complex.ofReal_re,Complex.ofReal_im,Complex.mul_re,Complex.mul_im,Complex.I_re,Complex.I_im,
    mul_zero,mul_one,sub_zero,add_zero,zero_add,J] using
    nonnegative_curl_reduced_weight_monotone Q DP DQ hDP hdQ hcurl y

end MonotoneMatching
