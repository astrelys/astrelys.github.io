import MonotoneMatching.GenericMotionTriple
import MonotoneMatching.GenericMotionCompact

set_option backward.isDefEq.respectTransparency.types false
noncomputable section
namespace MonotoneMatching
open scoped BigOperators Topology
open MeasureTheory MeasureTheory.Measure

/-- Genericity for a finite family of linear source scores on a compact time set. -/
def GenericMotionScores {ι κ : Type*} [Fintype ι]
    (C V : κ → ℝ → ι → ℝ) (K : Set ℝ) (A : ι → ℝ) : Prop :=
  (∀ p q, p ≠ q → ∀ t ∈ K,
    motionPairing A (C q t - C p t) = 0 → motionPairing A (V q t - V p t) ≠ 0) ∧
  (∀ p q r, p ≠ q → p ≠ r → q ≠ r → ∀ t ∈ K,
    ¬(motionPairing A (C q t - C p t) = 0 ∧ motionPairing A (C r t - C p t) = 0))

/-- Finite intersections preserve openness and density. -/
theorem finite_open_dense_intersection {E ι : Type*} [TopologicalSpace E] [Finite ι]
    (s : ι → Set E) (ho : ∀ i, IsOpen (s i)) (hd : ∀ i, Dense (s i)) :
    IsOpen (⋂ i, s i) ∧ Dense (⋂ i, s i) := by
  refine ⟨isOpen_iInter_of_finite ho, ?_⟩
  rw [← Set.sInter_range]
  apply (Set.finite_range s).dense_sInter
  · rintro _ ⟨i,rfl⟩
    exact ho i
  · rintro _ ⟨i,rfl⟩
    exact hd i

/-- Source-only genericity for arbitrary C1 motions with distinct configurations
and no collinear triple: an open dense set avoids triple ties and has only regular pair ties. -/
theorem open_dense_genericMotionScores {ι κ : Type*} [Fintype ι] [DecidableEq ι] [Fintype κ]
    (C V : κ → ℝ → ι → ℝ)
    (hd : ∀ p j t, HasDerivAt (fun s => C p s j) (V p t j) t)
    (hv : ∀ p, Continuous (V p))
    (hinj : ∀ t, Function.Injective (fun p => C p t))
    (hind : ∀ p q r, p ≠ q → p ≠ r → q ≠ r → ∀ t,
      ¬∃ c : ℝ, C r t - C p t = c • (C q t - C p t))
    (K : Set ℝ) (hK : IsCompact K) :
    IsOpen {A | GenericMotionScores C V K A} ∧ Dense {A | GenericMotionScores C V K A} := by
  classical
  have hc (p : κ) : Continuous (C p) := continuous_pi fun j =>
    continuous_iff_continuousAt.mpr fun t => (hd p j t).continuousAt
  let P (p q : κ) := {A | p ≠ q → ∀ t ∈ K,
    motionPairing A (C q t - C p t) = 0 → motionPairing A (V q t - V p t) ≠ 0}
  let T (p q r : κ) := {A | p ≠ q → p ≠ r → q ≠ r → ∀ t ∈ K,
    ¬(motionPairing A (C q t - C p t) = 0 ∧ motionPairing A (C r t - C p t) = 0)}
  have po (p q : κ) : IsOpen (P p q) := by
    by_cases hpq : p = q
    · simp [P,hpq]
    have h := (isClosed_exists_compact_tie (fun t => C q t - C p t)
      (fun t => V q t - V p t) ((hc q).sub (hc p)) ((hv q).sub (hv p)) K hK).isOpen_compl
    simpa only [P, hpq, ne_eq, not_false_eq_true, true_implies,
      Set.compl_ofPred, not_exists, not_and] using h
  have pd (p q : κ) : Dense (P p q) := by
    by_cases hpq : p = q
    · simp [P,hpq]
    have hn (t : ℝ) : C q t - C p t ≠ 0 :=
      sub_ne_zero.mpr (fun he => hpq ((hinj t he).symm))
    have h := dense_pair_tie_transverse_sources (fun t => C q t - C p t)
      (fun t => V q t - V p t) (fun j t => (hd q j t).sub (hd p j t)) hn
    apply h.mono
    intro A hA _ t _ ht
    exact hA t ht
  have topn (p q r : κ) : IsOpen (T p q r) := by
    by_cases hpq : p = q
    · simp [T,hpq]
    by_cases hpr : p = r
    · simp [T,hpr]
    by_cases hqr : q = r
    · simp [T,hqr]
    have h := (isClosed_exists_compact_tie (fun t => C q t - C p t)
      (fun t => C r t - C p t) ((hc q).sub (hc p)) ((hc r).sub (hc p)) K hK).isOpen_compl
    simpa only [T, hpq, hpr, hqr, ne_eq, not_false_eq_true, true_implies,
      Set.compl_ofPred, not_exists, not_and] using h
  have td (p q r : κ) : Dense (T p q r) := by
    by_cases hpq : p = q
    · simp [T,hpq]
    by_cases hpr : p = r
    · simp [T,hpr]
    by_cases hqr : q = r
    · simp [T,hqr]
    have hn (t : ℝ) : C q t - C p t ≠ 0 :=
      sub_ne_zero.mpr (fun he => hpq ((hinj t he).symm))
    have hnull := triple_tie_bad_sources_null volume (fun t => C q t - C p t)
      (fun t => C r t - C p t) (fun j t => ((hd q j t).sub (hd p j t)).differentiableAt)
      (fun j t => ((hd r j t).sub (hd p j t)).differentiableAt)
      (fun t => ⟨hn t, hind p q r hpq hpr hqr t⟩)
    have h := interior_eq_empty_iff_dense_compl.mp (MeasureTheory.Measure.interior_eq_empty_of_null hnull)
    apply h.mono
    intro A hA _ _ _ t _ ht
    exact hA ⟨t,ht⟩
  have hP := finite_open_dense_intersection (fun p => ⋂ q, P p q)
    (fun p => (finite_open_dense_intersection (P p) (po p) (pd p)).1)
    (fun p => (finite_open_dense_intersection (P p) (po p) (pd p)).2)
  have hT := finite_open_dense_intersection (fun p => ⋂ q, ⋂ r, T p q r)
    (fun p => (finite_open_dense_intersection (fun q => ⋂ r, T p q r)
      (fun q => (finite_open_dense_intersection (T p q) (topn p q) (td p q)).1)
      (fun q => (finite_open_dense_intersection (T p q) (topn p q) (td p q)).2)).1)
    (fun p => (finite_open_dense_intersection (fun q => ⋂ r, T p q r)
      (fun q => (finite_open_dense_intersection (T p q) (topn p q) (td p q)).1)
      (fun q => (finite_open_dense_intersection (T p q) (topn p q) (td p q)).2)).2)
  have heq : {A | GenericMotionScores C V K A} = (⋂ p, ⋂ q, P p q) ∩ (⋂ p, ⋂ q, ⋂ r, T p q r) := by
    ext A
    simp only [GenericMotionScores, Set.mem_ofPred_eq, Set.mem_inter_iff, Set.mem_iInter, P, T]
  rw [heq]
  exact ⟨hP.1.inter hT.1, hP.2.inter_of_isOpen_right hT.2 hT.1⟩

/-- Generic finite score families have finitely many pair ties on the compact time set. -/
theorem finite_generic_motion_ties {ι κ : Type*} [Fintype ι] [Fintype κ]
    (C V : κ → ℝ → ι → ℝ)
    (hd : ∀ p j t, HasDerivAt (fun s => C p s j) (V p t j) t)
    (K : Set ℝ) (hK : IsCompact K) (A : ι → ℝ) (ha : GenericMotionScores C V K A) :
    {t ∈ K | ∃ p q, p ≠ q ∧ motionPairing A (C q t - C p t) = 0}.Finite := by
  have hf (p q : κ) : {t ∈ K | p ≠ q ∧ motionPairing A (C q t - C p t) = 0}.Finite := by
    by_cases hpq : p = q
    · simp [hpq]
    have hs (t : ℝ) : HasDerivAt (fun s => motionPairing A (C q s - C p s))
        (motionPairing A (V q t - V p t)) t := by
      simpa only [motionPairing, Pi.sub_apply] using!
        HasDerivAt.fun_sum (u := Finset.univ)
          (fun j _ => ((hd q j t).sub (hd p j t)).const_mul (A j))
    apply (finite_regular_zeros_on_compact _ _ hs K hK (ha.1 p q hpq)).subset
    intro t ht
    exact ⟨ht.1,ht.2.2⟩
  apply (Set.finite_iUnion fun p => Set.finite_iUnion (hf p)).subset
  rintro t ⟨ht,p,q,hpq,hzero⟩
  exact Set.mem_iUnion.mpr ⟨p,Set.mem_iUnion.mpr ⟨q,ht,hpq,hzero⟩⟩

end MonotoneMatching
