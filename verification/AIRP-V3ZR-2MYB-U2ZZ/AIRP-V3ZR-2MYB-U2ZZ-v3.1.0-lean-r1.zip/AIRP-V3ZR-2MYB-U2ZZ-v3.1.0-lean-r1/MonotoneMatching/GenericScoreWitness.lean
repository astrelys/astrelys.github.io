import MonotoneMatching.ComplexSeparation
import MonotoneMatching.ConfigurationEnergy

/-! Actual source witnesses for nondegenerate pair and triple score coefficients. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

theorem coordinatePairing_sub {n : ℕ} (u v c : Fin n → ℂ) :
    coordinatePairing (u-v) c = coordinatePairing u c - coordinatePairing v c := by
  simp [coordinatePairing, mul_sub, Finset.sum_sub_distrib]

theorem complexAssignmentScore_conjugate_source {n : ℕ} (c b : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) :
    complexAssignmentScore (fun i => (starRingEnd ℂ) (c i)) b σ =
      coordinatePairing (b ∘ σ) c := by
  simp [complexAssignmentScore, coordinatePairing]

theorem permuted_configuration_ne {n : ℕ} (b : Fin n → ℂ)
    (hb : Function.Injective b) {σ τ : Equiv.Perm (Fin n)} (h : σ ≠ τ) :
    b ∘ σ ≠ b ∘ τ := by
  intro he
  apply h
  apply Equiv.ext
  intro i
  exact hb (congrFun he i)

/-- Every pair of distinct labeled target configurations admits a source whose
complex assignment coefficients differ. -/
theorem exists_source_distinct_coefficients {n : ℕ} (b : Fin n → ℂ)
    (hb : Function.Injective b) {σ τ : Equiv.Perm (Fin n)} (h : σ ≠ τ) :
    ∃ a : Fin n → ℂ, complexAssignmentScore a b σ ≠ complexAssignmentScore a b τ := by
  have hn := coordinatePairing_ne_zero (b ∘ σ - b ∘ τ)
    (sub_ne_zero.mpr (permuted_configuration_ne b hb h))
  obtain ⟨c,hc⟩ : ∃ c, coordinatePairing (b ∘ σ - b ∘ τ) c ≠ 0 := by
    by_contra he
    push Not at he
    exact hn (LinearMap.ext he)
  refine ⟨fun i => (starRingEnd ℂ) (c i), ?_⟩
  rw [coordinatePairing_sub] at hc
  simpa only [complexAssignmentScore_conjugate_source] using sub_ne_zero.mp hc

/-- The oriented area of the three complex coefficient points. -/
def scoreCoefficientDet {n : ℕ} (a b : Fin n → ℂ)
    (σ τ ρ : Equiv.Perm (Fin n)) : ℝ :=
  ((starRingEnd ℂ) (complexAssignmentScore a b τ - complexAssignmentScore a b σ) *
    (complexAssignmentScore a b ρ - complexAssignmentScore a b σ)).im

/-- Every three distinct labelings admit a source whose coefficient triangle
has nonzero area. The equal-energy obstruction is discharged explicitly. -/
theorem exists_source_noncollinear_coefficients {n : ℕ} (b : Fin n → ℂ)
    (hb : Function.Injective b) {σ τ ρ : Equiv.Perm (Fin n)}
    (hστ : σ ≠ τ) (hσρ : σ ≠ ρ) (hτρ : τ ≠ ρ) :
    ∃ a : Fin n → ℂ, scoreCoefficientDet a b σ τ ρ ≠ 0 := by
  let x := b ∘ σ
  let y := b ∘ τ
  let z := b ∘ ρ
  have hxy : x ≠ y := permuted_configuration_ne b hb hστ
  have hxz : x ≠ z := permuted_configuration_ne b hb hσρ
  have hyz : y ≠ z := permuted_configuration_ne b hb hτρ
  have hE (π : Equiv.Perm (Fin n)) : configurationEnergy (b ∘ π) = configurationEnergy b :=
    configurationEnergy_permute b π
  have hind : ¬∃ r : ℝ, z-x = r • (y-x) :=
    equal_energy_not_real_collinear x y z hxy hxz hyz
      ((hE τ).trans (hE σ).symm) ((hE ρ).trans (hE σ).symm)
  have hm : ¬∃ r : ℝ, ∀ c, coordinatePairing (z-x) c =
      (r : ℂ) * coordinatePairing (y-x) c := by
    rintro ⟨r,hr⟩
    exact hind ⟨r,coordinatePairing_real_dependence _ _ r hr⟩
  obtain ⟨c,hc⟩ := exists_noncollinear_linear_projection
    (coordinatePairing (y-x)) (coordinatePairing (z-x))
    (coordinatePairing_ne_zero _ (sub_ne_zero.mpr hxy.symm)) hm
  refine ⟨fun i => (starRingEnd ℂ) (c i), ?_⟩
  simpa only [scoreCoefficientDet, complexAssignmentScore_conjugate_source,
    coordinatePairing_sub, x, y, z] using hc

/-- Scores are real-linear in source coordinates. -/
theorem complexAssignmentScore_source_combination {n : ℕ} (a c b : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) (r s : ℝ) :
    complexAssignmentScore (r • a + s • c) b σ =
      (r : ℂ) * complexAssignmentScore a b σ +
      (s : ℂ) * complexAssignmentScore c b σ := by
  simp only [complexAssignmentScore, Pi.add_apply, Pi.smul_apply, Complex.real_smul,
    map_add, map_mul, Complex.conj_ofReal, add_mul, mul_assoc,
    Finset.sum_add_distrib, ← Finset.mul_sum]

end MonotoneMatching
