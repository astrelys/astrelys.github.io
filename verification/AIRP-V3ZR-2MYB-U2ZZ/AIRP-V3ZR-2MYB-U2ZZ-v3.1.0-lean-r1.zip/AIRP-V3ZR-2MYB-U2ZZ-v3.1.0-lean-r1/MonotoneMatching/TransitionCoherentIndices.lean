import MonotoneMatching.CoherentSideIndices
import MonotoneMatching.TransitionVertexGradient

/-! Coherent polygon side indices derived from the actual assignment dual
support, rather than assumed as a separate topological orientation hypothesis. -/
noncomputable section
namespace MonotoneMatching
open scoped InnerProductSpace

theorem transition_polygon_vertex_incidence {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) {n : ℕ} (a y : Fin n → ℂ) (hy : Function.Injective y)
    (σ : Equiv.Perm (Fin n)) (r c : Fin n → ℝ)
    (hbound : ∀ i j, inner ℝ (a i) (y j) ≤ r i+c j)
    (hexact : ∀ i j, r i+c j=inner ℝ (a i) (y j) ↔ j=i ∨ j=σ i)
    (e : ι → Fin n) (he : Function.Injective e) (hsucc : ∀ i, e (next i)=σ (e i))
    (h2 : ∀ i, σ (σ (e i))≠e i)
    (i j : ι) (hjp : j≠next.symm i) (hji : j≠i) :
    y (e i) ∉ segment ℝ (y (e j)) (y (e (next j))) := by
  intro h
  rw [segment_eq_image] at h
  obtain ⟨t,ht,hty⟩ := h
  by_cases ht0 : t=0
  · simp only [ht0,sub_zero,one_smul,zero_smul,add_zero] at hty
    exact hji (he (hy hty))
  by_cases ht1 : t=1
  · simp only [ht1,sub_self,zero_smul,one_smul,zero_add] at hty
    have hj : next j=i := he (hy hty)
    exact hjp (by rw [← hj]; exact (next.symm_apply_apply j).symm)
  have ht0p : 0<t := lt_of_le_of_ne ht.1 (Ne.symm ht0)
  have ht1p : t<1 := lt_of_le_of_ne ht.2 ht1
  apply target_not_on_transition_open_edge a y σ r c hbound hexact (e j) (h2 j) (e i) ht0p ht1p
  simpa only [hsucc] using hty.symm

theorem transition_polygon_coherent_side_indices {ι : Type*} [Fintype ι] [DecidableEq ι] [Nonempty ι]
    (next : Equiv.Perm ι) (htrans : ∀ i j : ι, ∃ k : ℕ, (next^k) i=j)
    {n : ℕ} (a y : Fin n → ℂ) (hy : Function.Injective y)
    (σ : Equiv.Perm (Fin n)) (r c : Fin n → ℝ)
    (hbound : ∀ i j, inner ℝ (a i) (y j) ≤ r i+c j)
    (hexact : ∀ i j, r i+c j=inner ℝ (a i) (y j) ↔ j=i ∨ j=σ i)
    (e : ι → Fin n) (he : Function.Injective e) (hsucc : ∀ i, e (next i)=σ (e i))
    (hm : ∀ i, σ (e i)≠e i) (h2 : ∀ i, σ (σ (e i))≠e i) :
    ∃ L R : ℝ, L-R=2*Real.pi ∧
      (∀ i q, q∈strictDualCell a r (e i) → 0<edgeSide (y (e i)) (y (e (next i))) q →
        polygonIndexPhase next (y∘e) q=L) ∧
      (∀ i q, q∈strictDualCell a r (e i) → edgeSide (y (e i)) (y (e (next i))) q<0 →
        polygonIndexPhase next (y∘e) q=R) := by
  have hne (i : ι) : (y∘e) i≠(y∘e) (next i) := by
    change y (e i)≠y (e (next i))
    rw [hsucc]
    exact hy.ne (hm i).symm
  have hactive (i : ι) (t : ℝ) (ht : t∈Set.Icc (0:ℝ) 1) (j : Fin n) :
      dualRow a r j ((1-t) • (y∘e) i+t • (y∘e) (next i)) ≤
        dualRow a r (e i) ((1-t) • (y∘e) i+t • (y∘e) (next i)) := by
    simpa only [Function.comp_def,hsucc] using
      transition_closed_edge_row_max a y σ r c hbound hexact (e i) j ht
  have hedge (i : ι) (t : ℝ) (ht : t∈Set.Ioo (0:ℝ) 1) :
      edgeCrossPoint ((y∘e) i) ((y∘e) (next i)) t 0∈strictDualCell a r (e i) := by
    intro j hj
    rw [edgeCrossPoint_zero_offset]
    simpa only [Function.comp_def,hsucc] using
      transition_edge_unique_row a y σ r c hbound hexact (e i) (h2 i) j hj ht.1 ht.2
  have hmid (i : ι) := hedge i (1/2) (by norm_num : (1/2:ℝ)∈Set.Ioo (0:ℝ) 1)
  choose L R hjump hL hR using exists_dual_cell_side_indices next (y∘e) a r e he hactive hmid hne
  have hcommon (i : ι) : ∃ q : ℂ, 0<edgeSide ((y∘e) (next.symm i)) ((y∘e) i) q ∧
      0<edgeSide ((y∘e) i) ((y∘e) (next i)) q := by
    have hprev : e (next.symm i)=σ.symm (e i) := by
      apply σ.injective
      rw [← hsucc,next.apply_symm_apply,σ.apply_symm_apply]
    simpa only [Function.comp_def,hprev,hsucc] using
      transition_vertex_common_left a y σ r c hbound hexact (e i) (hm i) (h2 i)
  have hvertex (i j : ι) (hjp : j≠next.symm i) (hji : j≠i) :
      (y∘e) i∉segment ℝ ((y∘e) j) ((y∘e) (next j)) :=
    transition_polygon_vertex_incidence next a y hy σ r c hbound hexact e he hsucc h2 i j hjp hji
  have hLeq := coherent_polygon_left_indices next (y∘e) htrans hne
    (fun i => strictDualCell a r (e i)) (fun i => isOpen_strictDualCell a r (e i))
    hedge hvertex hcommon L hL
  have hReq := coherent_polygon_right_indices L R hjump hLeq
  let i0 : ι := Classical.choice inferInstance
  refine ⟨L i0,R i0,hjump i0,?_,?_⟩
  · intro i q hq hs
    exact (hL i q hq hs).trans (hLeq i i0)
  · intro i q hq hs
    exact (hR i q hq hs).trans (hReq i i0)

end MonotoneMatching
