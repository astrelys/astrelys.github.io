import MonotoneMatching.PeriodicPolicyCells
noncomputable section
namespace MonotoneMatching
open Set
open scoped BigOperators
set_option backward.isDefEq.respectTransparency.types false

/-- Weak original-score optimality extends to both endpoints of a nonempty cell. -/
theorem trajectory_weak_optimizer_on_closed_cell {n : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (hb : ∀ i,Continuous (b i)) (σ : Equiv.Perm (Fin n))
    {u v : ℝ} (huv : u<v)
    (h : ∀ t∈Ioo u v,∀ τ,assignmentScore a (fun j => b j t) τ≤assignmentScore a (fun j => b j t) σ) :
    ∀ t∈Icc u v,∀ τ,assignmentScore a (fun j => b j t) τ≤assignmentScore a (fun j => b j t) σ := by
  intro t ht τ
  apply le_on_closure (s := Ioo u v)
    (f := fun t => assignmentScore a (fun j => b j t) τ)
    (g := fun t => assignmentScore a (fun j => b j t) σ)
  · exact fun x hx => h x hx τ
  · exact (continuous_trajectory_score a b hb τ).continuousOn
  · exact (continuous_trajectory_score a b hb σ).continuousOn
  · rwa [closure_Ioo huv.ne]

/-- W7: constant canonical open cells over one full circle, with no artificial
extra seam cell, and original-optimal-value coverage at every real time. -/
def windingCanonicalCellsStatement : Prop :=
  ∀ (n : ℕ),2≤n → ∀ (b v : Fin n → ℝ → ℂ) (T : ℝ),0<T →
    (∀ i t,HasDerivAt (b i) (v i t) t) → (∀ i,Continuous (v i)) →
    (∀ i,Function.Periodic (b i) T) → (∀ t,Function.Injective (fun i => b i t)) →
    (∀ i j,i<j → ∀ t,(b j t-b i t).re*(v j t-v i t).im-(b j t-b i t).im*(v j t-v i t).re≤0) →
    ∃ φ : Fin n → Fin n → ℝ → ℝ,∃ w : Fin n × Fin n → ℕ,
      (∀ i j,Continuous (φ i j)) ∧ (∀ i t,φ i i t=0) ∧
      (∀ i j,i≠j → ∀ t,(φ i j t:Real.Angle)=(Complex.arg (b j t-b i t):Real.Angle)) ∧
      (∀ p∈increasingPairs n,φ p.1 p.2 T-φ p.1 p.2 0= -(2*Real.pi)*(w p:ℝ)) ∧
      ∀ a : Fin n → ℂ,
        ∃ m : ℕ,0<m ∧ m≤max 1 (2*∑ p∈increasingPairs n,w p) ∧
        ∃ cut : Fin (m+1) → ℝ,∃ label : Fin m → Equiv.Perm (Fin n),
          StrictMono cut ∧ cut (Fin.last m)=cut 0+T ∧
          (∀ i,∀ t∈Ioo (cut i.castSucc) (cut i.succ),
            canonicalPermutation a (fun j => b j t)=label i) ∧
          (∀ i,∀ t∈Icc (cut i.castSucc) (cut i.succ),∀ ρ,
            assignmentScore a (fun j => b j t) ρ≤assignmentScore a (fun j => b j t) (label i)) ∧
          (∀ t : ℝ,∃ k : ℤ,∃ i : Fin m,t∈Icc (cut i.castSucc+k•T) (cut i.succ+k•T) ∧
            ∀ ρ,assignmentScore a (fun j => b j t) ρ≤assignmentScore a (fun j => b j t) (label i))

/-- The complete canonical open-cell and closure-coverage conclusion. Boundary
canonical values may differ from both neighboring labels. -/
theorem winding_canonical_cells : windingCanonicalCellsStatement := by
  intro n hn b v T hT hd hv hp hy hclock
  obtain ⟨φ,w,hφ,hzero,he,hw⟩ := exists_trajectory_winding_lifts b v T hT hd hp
    (fun i j hij t => (hy t).ne hij) hclock
  refine ⟨φ,w,hφ,hzero,he,hw,?_⟩
  intro a
  have hb : ∀ i,Continuous (b i) := fun i => continuous_iff_continuousAt.mpr (fun t => (hd i t).continuousAt)
  have hbad (s : ℝ) := canonical_bad_set_finite_bound a b hb hy s (s+T) _
    (winding_bounded_events_every_seam hn b v T hT hd hv hp hy hclock φ w hφ he hw s)
  obtain ⟨m,hm,hbound,cut,label,hmono,hlast,hlabel⟩ := periodic_policy_cells
    (fun t => canonicalPermutation a (fun j => b j t)) T hT (canonical_policy_periodic a b T hp) _ hbad
  have hclosed (i : Fin m) := trajectory_weak_optimizer_on_closed_cell a b hb (label i)
    (hmono i.castSucc_lt_succ) (fun t ht ρ => by
      rw [← hlabel i t ht]
      exact canonicalPermutation_optimal a (fun j => b j t) ρ)
  refine ⟨m,hm,hbound,cut,label,hmono,hlast,hlabel,hclosed,?_⟩
  intro t
  obtain ⟨k,hk,_⟩ := existsUnique_sub_zsmul_mem_Ico hT t (cut 0)
  have ht : t-k•T∈Icc (cut 0) (cut (Fin.last m)) := by
    rw [hlast]
    exact ⟨hk.1,hk.2.le⟩
  obtain ⟨i,hi⟩ := finite_subdivision_closed_cover hm cut hmono ht
  refine ⟨k,i,⟨by linarith [hi.1],by linarith [hi.2]⟩,?_⟩
  intro ρ
  have hcfg : (fun j => b j (t-k•T))=(fun j => b j t) := funext (fun j => (hp j).sub_zsmul_eq k)
  simpa only [hcfg] using hclosed i (t-k•T) hi ρ

end MonotoneMatching
