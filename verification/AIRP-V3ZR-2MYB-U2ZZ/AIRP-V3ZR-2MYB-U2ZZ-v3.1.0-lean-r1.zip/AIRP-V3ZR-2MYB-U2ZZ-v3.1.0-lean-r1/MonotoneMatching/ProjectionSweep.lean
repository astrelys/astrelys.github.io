import MonotoneMatching.SharpWitness
import MonotoneMatching.Rearrangement
import MonotoneMatching.FiniteCuts
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Arctan
import Mathlib.Data.Finset.Prod

/-! A finite family of strict directions for the sharp rotational construction. -/
noncomputable section
namespace MonotoneMatching

/-- The unordered label pairs, represented in increasing order. -/
def increasingPairs (n : ℕ) : Finset (Fin n × Fin n) :=
  (Finset.univ ×ˢ Finset.univ).filter (fun p => p.1 < p.2)

/-- All pair thresholds in the real affine projection sweep. -/
def sharpThresholds (n : ℕ) : Finset ℝ :=
  (increasingPairs n).image (fun p => (2 : ℝ)^p.1.val + 2^p.2.val)

theorem mem_sharpThresholds {n : ℕ} (p q : Fin n) (hpq : p < q) :
    (2 : ℝ)^p.val + 2^q.val ∈ sharpThresholds n := by
  classical
  exact Finset.mem_image.mpr ⟨(p,q), by simp [increasingPairs, hpq], rfl⟩

theorem sharpThresholds_card (n : ℕ) : (sharpThresholds n).card = n.choose 2 := by
  classical
  rw [sharpThresholds, Finset.card_image_iff.mpr]
  · simpa [increasingPairs] using
      (Finset.card_product_filter_lt (s := (Finset.univ : Finset (Fin n))))
  · intro p hp q hq he
    have hp' : p.1.val < p.2.val := (Finset.mem_filter.mp hp).2
    have hq' : q.1.val < q.2.val := (Finset.mem_filter.mp hq).2
    change (2 : ℝ)^p.1.val + 2^p.2.val = (2 : ℝ)^q.1.val + 2^q.2.val at he
    have hh : (2 : ℕ)^p.1.val + 2^p.2.val = 2^q.1.val + 2^q.2.val := by exact_mod_cast he
    obtain ⟨h1,h2⟩ := binary_pair_sum_injective hp' hq' hh
    exact Prod.ext (Fin.ext h1) (Fin.ext h2)

/-- A rescaled projection onto direction (-c,1). -/
def sweepProjection (c : ℝ) (j : ℕ) : ℝ := (4 : ℝ)^j - c * 2^j

theorem sweepProjection_sub (c : ℝ) (p q : ℕ) :
    sweepProjection c q - sweepProjection c p =
      ((2 : ℝ)^q - 2^p) * (2^p + 2^q - c) := by
  have h (j : ℕ) : (4 : ℝ)^j = (2^j)^2 := by
    rw [← pow_mul, mul_comm j 2, pow_mul]; norm_num
  simp only [sweepProjection, h]
  ring

theorem sweepProjection_lt_iff (c : ℝ) {p q : ℕ} (hpq : p < q) :
    sweepProjection c p < sweepProjection c q ↔ c < (2 : ℝ)^p + 2^q := by
  rw [← sub_pos, sweepProjection_sub]
  have hp : (0 : ℝ) < 2^q - 2^p := sub_pos.mpr
    (pow_lt_pow_right₀ (by norm_num : (1 : ℝ) < 2) hpq)
  rw [mul_pos_iff_of_pos_left hp, sub_pos]

theorem sweepProjection_injective {n : ℕ} (c : ℝ) (hc : c ∉ sharpThresholds n) :
    Function.Injective (fun i : Fin n => sweepProjection c i.val) := by
  intro p q he
  by_contra hn
  have aux : ∀ p q : Fin n, p < q → sweepProjection c p.val = sweepProjection c q.val → False := by
    intro i j hij hh
    have hd : sweepProjection c j.val - sweepProjection c i.val = 0 := by rw [hh, sub_self]
    rw [sweepProjection_sub] at hd
    have hne := sharpTarget_re_sub_ne_zero hij
    change (2 : ℝ)^j.val - 2^i.val ≠ 0 at hne
    have hz := (mul_eq_zero.mp hd).resolve_left hne
    have heq : c = (2 : ℝ)^i.val + 2^j.val := by linarith
    exact hc (heq ▸ mem_sharpThresholds i j hij)
  rcases lt_or_gt_of_ne hn with h | h
  · exact aux p q h he
  · exact aux q p h he.symm

/-- Every real sweep parameter corresponds to an actual rotation, with a
strictly positive scale factor. -/
theorem rotated_sharp_projection (c : ℝ) (j : ℕ) :
    (rotateClockwise (Real.pi / 2 + Real.arctan c) (sharpTarget j)).re =
      (1 / Real.sqrt (1 + c^2)) * sweepProjection c j := by
  simp [rotateClockwise, sharpTarget, Real.cos_add, Real.sin_add,
    Real.sin_arctan, Real.cos_arctan, sweepProjection]
  ring

theorem sweepProjection_gt_iff (c : ℝ) {p q : ℕ} (hpq : p < q) :
    sweepProjection c q < sweepProjection c p ↔ (2 : ℝ)^p + 2^q < c := by
  rw [← sub_neg, sweepProjection_sub]
  have hp : (0 : ℝ) < 2^q - 2^p := sub_pos.mpr
    (pow_lt_pow_right₀ (by norm_num : (1 : ℝ) < 2) hpq)
  rw [← mul_zero ((2 : ℝ)^q - 2^p), mul_lt_mul_iff_right₀ hp, sub_neg]

/-- Both orientations of the affine sweep are used. -/
def signedSweep (c : ℝ) (b : Bool) (j : ℕ) : ℝ :=
  if b then -sweepProjection c j else sweepProjection c j

theorem signedSweep_injective {n : ℕ} (c : ℝ) (b : Bool)
    (hc : c ∉ sharpThresholds n) :
    Function.Injective (fun i : Fin n => signedSweep c b i.val) := by
  cases b
  · exact sweepProjection_injective c hc
  · intro i j h
    apply sweepProjection_injective c hc
    exact neg_injective h

theorem signedSweep_comparison (c : ℝ) (b : Bool) {p q : ℕ} (hpq : p < q) :
    signedSweep c b p < signedSweep c b q ↔
      if b then (2 : ℝ)^p + 2^q < c else c < (2 : ℝ)^p + 2^q := by
  cases b
  · exact sweepProjection_lt_iff c hpq
  · simpa [signedSweep] using sweepProjection_gt_iff c hpq

/-- Sorting either orientation gives a genuine rotating unique optimum. -/
theorem signedSweep_sorted_mem {n : ℕ} (c : ℝ) (b : Bool)
    (σ : Equiv.Perm (Fin n))
    (hσ : StrictMono (fun i => signedSweep c b (σ i).val)) :
    σ ∈ rotationOptimizers (fun i : Fin n => (i.val : ℂ))
      (fun i => sharpTarget i.val) := by
  rw [mem_rotationOptimizers]
  let t := Real.pi / 2 + Real.arctan c
  let d := 1 / Real.sqrt (1 + c^2)
  have hd : 0 < d := by dsimp [d]; positivity
  have hproj (j : ℕ) :
      (rotateClockwise (t + if b then Real.pi else 0) (sharpTarget j)).re =
      d * signedSweep c b j := by
    cases b
    · simpa [t, d, signedSweep] using rotated_sharp_projection c j
    · have h := rotated_sharp_projection c j
      change (rotateClockwise (t + Real.pi) (sharpTarget j)).re =
        d * (-sweepProjection c j)
      have hneg : (rotateClockwise (t + Real.pi) (sharpTarget j)).re =
          -(rotateClockwise t (sharpTarget j)).re := by
        simp [rotateClockwise, Real.cos_add, Real.sin_add]
        ring
      rw [hneg]
      change -((rotateClockwise (Real.pi / 2 + Real.arctan c) (sharpTarget j)).re) = _
      rw [h]
      ring
  refine ⟨t + if b then Real.pi else 0, ?_⟩
  apply real_axis_sorted_uniqueMinimum (fun i : Fin n => (i.val : ℝ)) _
    (fun i j hij => by
      change (i.val : ℝ) < (j.val : ℝ)
      exact_mod_cast (show i.val < j.val from hij)) σ
  intro i j hij
  change (rotateClockwise _ (sharpTarget (σ i).val)).re <
    (rotateClockwise _ (sharpTarget (σ j).val)).re
  rw [hproj, hproj]
  exact mul_lt_mul_of_pos_left (hσ hij) hd

end MonotoneMatching
