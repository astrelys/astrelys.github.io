import MonotoneMatching.MonotoneSmoothing
import Mathlib.Analysis.Convex.Function
noncomputable section
namespace MonotoneMatching
open MeasureTheory ContinuousLinearMap Set
open scoped BigOperators Convolution
set_option backward.isDefEq.respectTransparency.types false

/-- Nonnegative normalized convolution preserves convexity of a continuous planar function. -/
theorem convex_bump_convolution (f : ℂ → ℝ) (hf : Continuous f)
    (hconv : ConvexOn ℝ univ f) (φ : ContDiffBump (0:ℂ)) :
    ConvexOn ℝ univ (φ.normed volume ⋆[lsmul ℝ ℝ,volume] f) := by
  have hi (p : ℂ) : Integrable (fun t => φ.normed volume t*f (p-t)) :=
    φ.hasCompactSupport_normed.convolutionExists_left_of_continuous_right
      (lsmul ℝ ℝ) φ.continuous_normed.locallyIntegrable hf p
  refine ⟨convex_univ,?_⟩
  intro x _ y _ a b ha hb hab
  simp only [convolution_def,lsmul_apply,smul_eq_mul]
  rw [← integral_const_mul,← integral_const_mul,← integral_add ((hi x).const_mul a) ((hi y).const_mul b)]
  apply integral_mono (hi _) (((hi x).const_mul a).add ((hi y).const_mul b))
  intro t
  have he : a • (x-t)+b • (y-t)=a • x+b • y-t := by
    calc
      a • (x-t)+b • (y-t) = (a • x+b • y)-(a+b) • t := by module
      _ = a • x+b • y-t := by rw [hab,one_smul]
  have hc := hconv.2 (mem_univ (x-t)) (mem_univ (y-t)) ha hb hab
  rw [he] at hc
  have hm := mul_le_mul_of_nonneg_left hc (φ.nonneg_normed (μ := volume) t)
  simp only [smul_eq_mul] at hm
  simp only [Pi.add_apply]
  nlinarith

/-- Convolution with a normalized nonnegative bump preserves the Lipschitz constant. -/
theorem lipschitz_bump_convolution (f : ℂ → ℝ) (hf : Continuous f)
    (L : ℝ) (hLip : ∀ x y,‖f x-f y‖ ≤ L*‖x-y‖)
    (φ : ContDiffBump (0:ℂ)) :
    ∀ x y, ‖(φ.normed volume ⋆[lsmul ℝ ℝ,volume] f) x-
      (φ.normed volume ⋆[lsmul ℝ ℝ,volume] f) y‖ ≤ L*‖x-y‖ := by
  intro x y
  have hi (p : ℂ) : Integrable (fun t => φ.normed volume t*f (p-t)) :=
    φ.hasCompactSupport_normed.convolutionExists_left_of_continuous_right
      (lsmul ℝ ℝ) φ.continuous_normed.locallyIntegrable hf p
  simp only [convolution_def,lsmul_apply,smul_eq_mul]
  rw [← integral_sub (hi x) (hi y)]
  calc
    ‖∫ t,φ.normed volume t*f (x-t)-φ.normed volume t*f (y-t)‖ ≤
        ∫ t,φ.normed volume t*(L*‖x-y‖) := by
      apply norm_integral_le_of_norm_le (φ.integrable_normed.mul_const _)
      filter_upwards with t
      rw [← mul_sub,norm_mul,Real.norm_eq_abs,abs_of_nonneg (φ.nonneg_normed (μ := volume) t)]
      have hh := hLip (x-t) (y-t)
      have he : (x-t)-(y-t)=x-y := by abel
      rw [he] at hh
      exact mul_le_mul_of_nonneg_left hh (φ.nonneg_normed (μ := volume) t)
    _ = L*‖x-y‖ := by rw [integral_mul_const,φ.integral_normed,one_mul]

end MonotoneMatching
