import MonotoneMatching.OptimalCycle
import Mathlib.GroupTheory.Perm.Fin

/-! A moved cycle enumerated in its actual geometric order. -/
noncomputable section
namespace MonotoneMatching

theorem exists_ordered_cycle_enumeration {n : ℕ} (σ : Equiv.Perm (Fin n))
    (hσ : σ.IsCycle) :
    ∃ e : Fin σ.support.card ≃ σ.support,
      ∀ j, (e (finRotate σ.support.card j)).val = σ (e j).val := by
  classical
  have hcopy := hσ
  obtain ⟨i,hi,_⟩ := hcopy
  have hiS : i ∈ σ.support := Equiv.Perm.mem_support.mpr hi
  have hOn : σ.IsCycleOn (σ.support : Set (Fin n)) := by
    rw [Equiv.Perm.coe_support_eq_set_support]
    exact hσ.isCycleOn
  let f : Fin σ.support.card → σ.support := fun j =>
    ⟨(σ^j.val) i,Equiv.Perm.pow_apply_mem_support.mpr hiS⟩
  have hf : Function.Bijective f := by
    constructor
    · intro j k he
      have hpow := congrArg Subtype.val he
      have hmod := hOn.pow_apply_eq_pow_apply hiS |>.mp hpow
      apply Fin.ext
      simpa only [Nat.ModEq,Nat.mod_eq_of_lt j.isLt,Nat.mod_eq_of_lt k.isLt] using hmod
    · intro x
      obtain ⟨k,hk,he⟩ := hOn.exists_pow_eq hiS x.property
      exact ⟨⟨k,hk⟩,Subtype.ext he⟩
  let e := Equiv.ofBijective f hf
  refine ⟨e,?_⟩
  intro j
  change (σ^(finRotate σ.support.card j).val) i = σ ((σ^j.val) i)
  have hpos : 0 < σ.support.card := lt_of_lt_of_le (by decide : 0<2) hσ.two_le_card_support
  let : NeZero σ.support.card := ⟨Nat.ne_of_gt hpos⟩
  have hval : (finRotate σ.support.card j).val = (j.val+1)%σ.support.card := by
    rw [finRotate_apply,Fin.val_add]
    simp only [Fin.val_one',Nat.add_mod_mod]
  have hpow : σ^((j.val+1)%σ.support.card) = σ^(j.val+1) := by
    simpa only [hσ.orderOf] using pow_mod_orderOf σ (j.val+1)
  rw [hval,hpow,pow_succ',Equiv.Perm.mul_apply]

/-- The enumeration preserves the labels and has no repeated vertices after
composing with an injective target list. -/
theorem ordered_cycle_vertices_injective {n : ℕ} (σ : Equiv.Perm (Fin n))
    (e : Fin σ.support.card ≃ σ.support) (y : Fin n → ℂ) (hy : Function.Injective y) :
    Function.Injective (fun j => y (e j).val) := by
  intro i j h
  exact e.injective (Subtype.ext (hy h))

end MonotoneMatching
