import MonotoneMatching.Stability
import MonotoneMatching.SharpWitness
import MonotoneMatching.SharpLowerBound

/-! A concrete noncollinear perturbation of the collinear sharpness sources. -/
noncomputable section
namespace MonotoneMatching

/-- Move only the third source vertically; at ε=0 these are exactly the paper's sources. -/
def sharpSources {n : ℕ} (ε : ℝ) (i : Fin n) : ℂ :=
  (i.val : ℂ) + if i.val = 2 then (ε : ℂ) * Complex.I else 0

@[simp] theorem sharpSources_zero {n : ℕ} (i : Fin n) : sharpSources 0 i = (i.val : ℂ) := by
  simp [sharpSources]

/-- Every nonzero perturbation makes the first three sources noncollinear. -/
theorem sharpSources_noncollinear {n : ℕ} (hn : 3 ≤ n) {ε : ℝ} (hε : ε ≠ 0) :
    NoncollinearList (sharpSources (n := n) ε) := by
  refine ⟨⟨0, by omega⟩, ⟨1, by omega⟩, ⟨2, by omega⟩, ?_⟩
  simpa [sharpSources] using hε

/-- The perturbation tends continuously to the paper's original source list. -/
theorem continuous_sharpSources {n : ℕ} : Continuous (sharpSources (n := n)) := by
  apply continuous_pi
  intro i
  by_cases h : i.val = 2
  · simp only [sharpSources, h, ite_true]
    fun_prop
  · simp only [sharpSources, h, ite_false]
    exact continuous_const

/-- A nonempty open set of noncollinear inputs preserves every strict optimizer
of the paper's explicit construction. No unproved count or upper bound is used. -/
theorem sharp_construction_noncollinear_open_lower_bound {n : ℕ} (hn : 3 ≤ n) :
    ∃ U : Set ((Fin n → ℂ) × (Fin n → ℂ)), IsOpen U ∧ U.Nonempty ∧
      ∀ p ∈ U, NoncollinearList p.1 ∧ NoncollinearList p.2 ∧
        rotationCount (sharpSources (n := n) 0) (fun i => sharpTarget i.val) ≤
          rotationCount p.1 p.2 := by
  let b : Fin n → ℂ := fun i => sharpTarget i.val
  let γ : ℝ → (Fin n → ℂ) × (Fin n → ℂ) := fun ε => (sharpSources ε, b)
  obtain ⟨V, ho, hm, hv⟩ := rotation_count_persists (sharpSources (n := n) 0) b
  have hc : Continuous γ := continuous_sharpSources.prodMk continuous_const
  have hz : (0 : ℝ) ∈ γ ⁻¹' V := hm
  obtain ⟨δ, hδ, hb⟩ := Metric.mem_nhds_iff.mp ((ho.preimage hc).mem_nhds hz)
  have heps : 0 < δ / 2 := by linarith
  have hin : γ (δ / 2) ∈ V := by
    apply hb
    rw [Metric.mem_ball, Real.dist_eq, sub_zero, abs_of_pos heps]
    linarith
  have ha : NoncollinearList (sharpSources (n := n) (δ / 2)) :=
    sharpSources_noncollinear hn (ne_of_gt heps)
  have hbt : NoncollinearList b := sharpTarget_noncollinear hn
  obtain ⟨U, huo, hum, hu⟩ := noncollinear_count_persists
    (sharpSources (n := n) (δ / 2)) b ha hbt
  refine ⟨U, huo, ⟨_, hum⟩, ?_⟩
  intro p hp
  obtain ⟨hpa, hpb, hpc⟩ := hu p hp
  exact ⟨hpa, hpb, (hv (γ (δ / 2)) hin).trans hpc⟩

/-- Conditional assembly of the open-attainment clause. The universal
upper bound and explicit witness count are inputs to this auxiliary theorem;
the complete rotational theorem discharges both inputs. -/
theorem open_sharpness_from_explicit_count_and_upper_bound {n : ℕ} (hn : 3 ≤ n)
    (hupper : ∀ a b : Fin n → ℂ, rotationCount a b ≤ n * (n - 1))
    (hcount : rotationCount (sharpSources (n := n) 0) (fun i => sharpTarget i.val) =
      n * (n - 1)) :
    ∃ U : Set ((Fin n → ℂ) × (Fin n → ℂ)), IsOpen U ∧ U.Nonempty ∧
      ∀ p ∈ U, NoncollinearList p.1 ∧ NoncollinearList p.2 ∧
        rotationCount p.1 p.2 = n * (n - 1) := by
  obtain ⟨U, ho, hnU, hU⟩ := sharp_construction_noncollinear_open_lower_bound hn
  refine ⟨U, ho, hnU, ?_⟩
  intro p hp
  obtain ⟨ha, hb, hle⟩ := hU p hp
  rw [hcount] at hle
  exact ⟨ha, hb, Nat.le_antisymm (hupper p.1 p.2) hle⟩

/-- A nonempty open set of noncollinear inputs has at least n(n-1) strict
rotational optima. The general upper bound is not used. -/
theorem noncollinear_open_rotationCount_lower_bound {n : ℕ} (hn : 3 ≤ n) :
    ∃ U : Set ((Fin n → ℂ) × (Fin n → ℂ)), IsOpen U ∧ U.Nonempty ∧
      ∀ p ∈ U, NoncollinearList p.1 ∧ NoncollinearList p.2 ∧
        n * (n - 1) ≤ rotationCount p.1 p.2 := by
  obtain ⟨U, ho, hne, hU⟩ := sharp_construction_noncollinear_open_lower_bound hn
  refine ⟨U, ho, hne, ?_⟩
  intro p hp
  obtain ⟨ha, hb, hc⟩ := hU p hp
  have h := sharp_rotationCount_lower_bound n
  have hz : sharpSources (n := n) 0 = (fun i : Fin n => (i.val : ℂ)) := by
    funext i; exact sharpSources_zero i
  rw [hz] at hc
  exact ⟨ha, hb, h.trans hc⟩

/-- Only the universal rotational upper bound remains as an assumption in this
assembly theorem. It is recorded as conditional, not as the main theorem. -/
theorem sharpRotationalCountStatement_of_upper_bound
    (hupper : ∀ n : ℕ, 2 ≤ n → ∀ a b : Fin n → ℂ,
      rotationCount a b ≤ n * (n - 1)) : sharpRotationalCountStatement := by
  refine ⟨hupper, ?_, ?_, rotationCount_one⟩
  · intro n hn
    exact ⟨_, _, le_antisymm (hupper n hn _ _) (sharp_rotationCount_lower_bound n)⟩
  · intro n hn
    obtain ⟨U, ho, hne, hU⟩ := noncollinear_open_rotationCount_lower_bound hn
    refine ⟨U, ho, hne, ?_⟩
    intro p hp
    obtain ⟨ha, hb, hc⟩ := hU p hp
    exact ⟨ha, hb, le_antisymm (hupper n (by omega) p.1 p.2) hc⟩

end MonotoneMatching
