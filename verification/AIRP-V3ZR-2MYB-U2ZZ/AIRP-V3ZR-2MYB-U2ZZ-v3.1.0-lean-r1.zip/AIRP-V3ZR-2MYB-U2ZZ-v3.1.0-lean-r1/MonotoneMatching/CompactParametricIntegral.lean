import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
import Mathlib.Analysis.Complex.Basic
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.Calculus.FDeriv.Mul
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
noncomputable section
namespace MonotoneMatching
open MeasureTheory Set Metric Filter
open scoped Topology Interval
set_option backward.isDefEq.respectTransparency.types false

/-- A continuously differentiable planar parameter may be differentiated under a compact
interval integral. The required local domination follows from compactness. -/
theorem hasFDerivAt_compact_interval_integral
    (F : ℂ → ℝ → ℝ) (D : ℂ → ℝ → ℂ →L[ℝ] ℝ)
    (hF : Continuous (Function.uncurry F)) (hD : Continuous (Function.uncurry D))
    (hd : ∀ p t,HasFDerivAt (fun q => F q t) (D p t) p)
    (a b : ℝ) (p : ℂ) :
    HasFDerivAt (fun q => ∫ t in a..b,F q t) (∫ t in a..b,D p t) p := by
  have hK := (isCompact_closedBall p 1).prod (isCompact_uIcc (a := a) (b := b))
  obtain ⟨M,hM⟩ := hK.bddAbove_image hD.norm.continuousOn
  have hbnd (q : ℂ) (t : ℝ) (hq : q ∈ closedBall p 1) (ht : t ∈ uIcc a b) : ‖D q t‖ ≤ M :=
    hM ⟨(q,t),⟨hq,ht⟩,rfl⟩
  have hFt (q : ℂ) : Continuous (F q) := hF.comp (continuous_const.prodMk continuous_id)
  have hDt : Continuous (D p) := hD.comp (continuous_const.prodMk continuous_id)
  apply intervalIntegral.hasFDerivAt_integral_of_dominated_of_fderiv_le
    (s := closedBall p 1) (bound := fun _ => M) (closedBall_mem_nhds p (by norm_num))
  · exact Eventually.of_forall (fun q => (hFt q).aestronglyMeasurable)
  · exact (hFt p).intervalIntegrable _ _
  · exact hDt.aestronglyMeasurable
  · exact Eventually.of_forall (fun t ht q hq => hbnd q t hq (uIoc_subset_uIcc ht))
  · exact intervalIntegrable_const
  · exact Eventually.of_forall (fun t _ q _ => hd q t)

/-- A concrete horizontal scaling map used to integrate a planar potential on a fixed interval. -/
def horizontalScaling (t : ℝ) : ℂ →L[ℝ] ℂ :=
  t • Complex.reCLM.smulRight (1:ℂ)+Complex.imCLM.smulRight Complex.I

theorem horizontalScaling_apply (t : ℝ) (z : ℂ) :
    horizontalScaling t z=(t*z.re:ℂ)+(z.im:ℂ)*Complex.I := by
  simp [horizontalScaling,Complex.real_smul,mul_comm]

theorem continuous_horizontalScaling : Continuous horizontalScaling := by
  unfold horizontalScaling
  fun_prop

/-- Fixed-interval representation of a horizontal primitive, with its full Fréchet derivative. -/
theorem horizontal_primitive_integral_derivative
    (P : ℂ → ℝ) (DP : ℂ → ℂ →L[ℝ] ℝ) (hP : Continuous P) (hDP : Continuous DP)
    (hdP : ∀ p,HasFDerivAt P (DP p) p) (p : ℂ) :
    HasFDerivAt (fun q => ∫ t in (0:ℝ)..1,q.re*P (horizontalScaling t q))
      (∫ t in (0:ℝ)..1,p.re • (DP (horizontalScaling t p)).comp (horizontalScaling t)+
        P (horizontalScaling t p) • Complex.reCLM) p := by
  refine hasFDerivAt_compact_interval_integral
    (fun q t => q.re*P (horizontalScaling t q))
    (fun q t => q.re • (DP (horizontalScaling t q)).comp (horizontalScaling t)+
      P (horizontalScaling t q) • Complex.reCLM) ?_ ?_ ?_ 0 1 p
  · have hc : Continuous (fun z : ℂ × ℝ => horizontalScaling z.2 z.1) :=
      (continuous_horizontalScaling.comp continuous_snd).clm_apply continuous_fst
    exact (Complex.continuous_re.comp continuous_fst).mul (hP.comp hc)
  · have hc : Continuous (fun z : ℂ × ℝ => horizontalScaling z.2 z.1) :=
      (continuous_horizontalScaling.comp continuous_snd).clm_apply continuous_fst
    exact ((Complex.continuous_re.comp continuous_fst).smul
      ((hDP.comp hc).clm_comp (continuous_horizontalScaling.comp continuous_snd))).add
      ((hP.comp hc).smul continuous_const)
  · intro q t
    exact Complex.reCLM.hasFDerivAt.mul ((hdP _).comp q (horizontalScaling t).hasFDerivAt)

/-- Horizontal scaling has the expected coordinate-basis values. -/
theorem horizontalScaling_basis (t : ℝ) :
    horizontalScaling t 1=(t:ℂ) ∧ horizontalScaling t Complex.I=Complex.I := by
  simp [horizontalScaling_apply]

/-- Coordinate derivatives determine a real linear functional on the plane. -/
theorem planar_functional_coordinates (A : ℂ →L[ℝ] ℝ) :
    A = A 1 • Complex.reCLM+A Complex.I • Complex.imCLM := by
  ext z
  have hz : z=z.re • (1:ℂ)+z.im • Complex.I := by
    apply Complex.ext <;> simp [Complex.real_smul]
  conv_lhs => rw [hz]
  simp only [map_add,map_smul,add_apply,smul_apply,
    Complex.reCLM_apply,Complex.imCLM_apply,smul_eq_mul]
  ring

/-- Integration of the horizontal coordinate derivative reduces to the endpoint value. -/
theorem horizontal_primitive_horizontal_coefficient
    (P : ℂ → ℝ) (DP : ℂ → ℂ →L[ℝ] ℝ) (hP : Continuous P) (hDP : Continuous DP)
    (hdP : ∀ p,HasFDerivAt P (DP p) p) (p : ℂ) :
    (∫ t in (0:ℝ)..1,p.re*DP (horizontalScaling t p) (t:ℂ)+P (horizontalScaling t p)) = P p := by
  have hA (t : ℝ) : HasDerivAt (fun t => horizontalScaling t p) (p.re:ℂ) t := by
    simp only [horizontalScaling_apply]
    convert ((Complex.ofRealCLM.hasFDerivAt.comp_hasDerivAt t
      ((hasDerivAt_id t).mul_const p.re)).add_const ((p.im:ℂ)*Complex.I)) using 1 <;> simp
  have hder (t : ℝ) : HasDerivAt (fun t => t*P (horizontalScaling t p))
      (p.re*DP (horizontalScaling t p) (t:ℂ)+P (horizontalScaling t p)) t := by
    have h := (hasDerivAt_id t).mul ((hdP _).comp_hasDerivAt t (hA t))
    have hmul : t*DP (horizontalScaling t p) (p.re:ℂ)=p.re*DP (horizontalScaling t p) (t:ℂ) := by
      have he (s : ℝ) : (s:ℂ)=s • (1:ℂ) := by simp
      rw [he p.re,he t,map_smul,map_smul]
      simp only [smul_eq_mul]
      ring
    simpa only [Pi.mul_apply,Function.comp_def,one_mul,id_eq,hmul,add_comm] using! h
  have hcA : Continuous (fun t => horizontalScaling t p) := continuous_horizontalScaling.clm_apply continuous_const
  have hc : Continuous (fun t => p.re*DP (horizontalScaling t p) (t:ℂ)+P (horizontalScaling t p)) := by
    apply Continuous.add
    · exact continuous_const.mul ((hDP.comp hcA).clm_apply Complex.continuous_ofReal)
    · exact hP.comp hcA
  have he := intervalIntegral.integral_eq_sub_of_hasDerivAt (a := 0) (b := 1) (fun t _ => hder t) (hc.intervalIntegrable _ _)
  have h1 : horizontalScaling 1 p=p := by
    apply Complex.ext <;> simp [horizontalScaling_apply]
  simpa only [h1,one_mul,zero_mul,sub_zero] using he

/-- The vertical primitive coefficient is the horizontal integral of the vertical derivative. -/
theorem horizontal_primitive_vertical_coefficient
    (DP : ℂ → ℂ →L[ℝ] ℝ) (p : ℂ) :
    (∫ t in (0:ℝ)..1,p.re*DP (horizontalScaling t p) Complex.I) =
      ∫ x in (0:ℝ)..p.re,DP ((x:ℂ)+(p.im:ℂ)*Complex.I) Complex.I := by
  rw [intervalIntegral.integral_const_mul]
  simpa only [horizontalScaling_apply,Complex.ofReal_mul,smul_eq_mul,zero_mul,one_mul] using
    (intervalIntegral.smul_integral_comp_mul_right
      (fun x : ℝ => DP ((x:ℂ)+(p.im:ℂ)*Complex.I) Complex.I) (a := 0) (b := 1) p.re)

/-- Horizontal primitive with its explicit planar derivative. -/
theorem horizontal_primitive_hasFDerivAt
    (P : ℂ → ℝ) (DP : ℂ → ℂ →L[ℝ] ℝ) (hP : Continuous P) (hDP : Continuous DP)
    (hdP : ∀ p,HasFDerivAt P (DP p) p) (p : ℂ) :
    HasFDerivAt (fun q => ∫ t in (0:ℝ)..1,q.re*P (horizontalScaling t q))
      (P p • Complex.reCLM+
        (∫ x in (0:ℝ)..p.re,DP ((x:ℂ)+(p.im:ℂ)*Complex.I) Complex.I) • Complex.imCLM) p := by
  let D : ℝ → ℂ →L[ℝ] ℝ := fun t => p.re • (DP (horizontalScaling t p)).comp (horizontalScaling t)+
    P (horizontalScaling t p) • Complex.reCLM
  have hcA : Continuous (fun t => horizontalScaling t p) := continuous_horizontalScaling.clm_apply continuous_const
  have hcD : Continuous D := by
    dsimp [D]
    exact ((continuous_const (y := p.re)).smul ((hDP.comp hcA).clm_comp continuous_horizontalScaling)).add
      ((hP.comp hcA).smul (continuous_const (y := Complex.reCLM)))
  have he1 : (∫ t in (0:ℝ)..1,D t) 1=P p := by
    rw [ContinuousLinearMap.intervalIntegral_apply (hcD.intervalIntegrable _ _)]
    simp only [D,add_apply,smul_apply,
      ContinuousLinearMap.comp_apply,Complex.reCLM_apply,Complex.one_re,smul_eq_mul,mul_one,
      (horizontalScaling_basis _).1]
    exact horizontal_primitive_horizontal_coefficient P DP hP hDP hdP p
  have heI : (∫ t in (0:ℝ)..1,D t) Complex.I=
      ∫ x in (0:ℝ)..p.re,DP ((x:ℂ)+(p.im:ℂ)*Complex.I) Complex.I := by
    rw [ContinuousLinearMap.intervalIntegral_apply (hcD.intervalIntegrable _ _)]
    simp only [D,add_apply,smul_apply,
      ContinuousLinearMap.comp_apply,Complex.reCLM_apply,Complex.I_re,smul_eq_mul,mul_zero,add_zero,
      (horizontalScaling_basis _).2]
    exact horizontal_primitive_vertical_coefficient DP p
  have he := planar_functional_coordinates (∫ t in (0:ℝ)..1,D t)
  rw [he1,heI] at he
  exact he ▸ horizontal_primitive_integral_derivative P DP hP hDP hdP p

end MonotoneMatching
