import MonotoneMatching.FiniteBadSet
import MonotoneMatching.WindingShift
noncomputable section
namespace MonotoneMatching
open Set Filter
open scoped Topology
set_option backward.isDefEq.respectTransparency.types false

/-- Canonical nonlocal-constancy points in an open time interval. -/
def canonicalBadSet {n : ℕ} (a : Fin n → ℂ) (b : Fin n → ℝ → ℂ) (L U : ℝ) : Set ℝ :=
  {t | t∈Ioo L U ∧ policyBad (fun u => canonicalPermutation a (fun j => b j u)) t}

theorem canonical_bad_finset_card_le {n : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (hb : ∀ i,Continuous (b i))
    (hy : ∀ t,Function.Injective (fun j => b j t)) (L U : ℝ) (N : ℕ)
    (hevents : boundedOptimalEvents b L U N)
    (s : Finset ℝ) (hs : (s : Set ℝ) ⊆ canonicalBadSet a b L U) : s.card≤N := by
  classical
  obtain ⟨G,hg,hG⟩ := hevents
  obtain ⟨a',ha',e,hinj,he⟩ := finite_bad_points_inject_events a b hb hy G hg s L U (fun t ht => hs ht)
  obtain ⟨E,hE,hcover⟩ := hG a' ha'
  let f : {t // t∈s} → {t // t∈E} := fun t => ⟨e t,hcover (e t) (he t).1 (he t).2⟩
  have hf : Function.Injective f := fun t z h => hinj (congrArg Subtype.val h)
  have hc := Fintype.card_le_of_injective f hf
  have hc' : s.card≤E.card := by simpa only [Fintype.card_coe] using hc
  exact hc'.trans hE

/-- Nonlocal-constancy points are finite and obey the same event budget;
finiteness is proved from arbitrary finite subsets, not assumed. -/
theorem canonical_bad_set_finite_bound {n : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (hb : ∀ i,Continuous (b i))
    (hy : ∀ t,Function.Injective (fun j => b j t)) (L U : ℝ) (N : ℕ)
    (hevents : boundedOptimalEvents b L U N) :
    (canonicalBadSet a b L U).Finite ∧ (canonicalBadSet a b L U).ncard≤N := by
  classical
  have hf : (canonicalBadSet a b L U).Finite := by
    by_contra hinf
    obtain ⟨s,hs,hcard⟩ := Set.Infinite.exists_subset_card_eq hinf (N+1)
    have hh := canonical_bad_finset_card_le a b hb hy L U N hevents s hs
    omega
  refine ⟨hf,?_⟩
  have hh := canonical_bad_finset_card_le a b hb hy L U N hevents hf.toFinset (by simp)
  simpa only [Set.ncard_eq_toFinset_card _ hf] using hh

end MonotoneMatching
