import MonotoneMatching.DualMaximumFlux
import MonotoneMatching.SmoothFiniteInterpolation
noncomputable section
namespace MonotoneMatching
open MeasureTheory ContinuousLinearMap Set Filter
open scoped BigOperators InnerProductSpace Topology
set_option backward.isDefEq.respectTransparency.types false

/-- Finite clockwise velocity data inherit the nonpositive convex polygon flux
without assuming any global velocity field in the input. -/
theorem finite_velocity_dual_polygon_flux_nonpos {ι : Type*} [Fintype ι]
    (next : Equiv.Perm ι) (y u : ι → ℂ) (hy : Function.Injective y)
    {n : ℕ} [Nonempty (Fin n)] (a : Fin n → ℂ) (r : Fin n → ℝ)
    (e : ι → Fin n) (he : Function.Injective e)
    (hedge : ∀ i, ∀ t∈Ioo (0:ℝ) 1, (1-t) • y i+t • y (next i)∈strictDualCell a r (e i))
    (L R : ℝ) (hgap : L-R=2*Real.pi)
    (hL : ∀ i q, q∈strictDualCell a r (e i) → 0<edgeSide (y i) (y (next i)) q → polygonIndexPhase next y q=L)
    (hR : ∀ i q, q∈strictDualCell a r (e i) → edgeSide (y i) (y (next i)) q<0 → polygonIndexPhase next y q=R)
    (hphase : ∀ q, q∉polygonBoundary next y → polygonIndexPhase next y q≤0)
    (hmono : ∀ i j,0 ≤ inner ℝ (y i-y j) (Complex.I*(u i-u j))) :
    (∑ i,inner ℝ (a (e i)) (u (next i)-u i)) ≤ 0 := by
  obtain ⟨F,hFs,_,hFd,hFl⟩ := finite_smooth_monotone_interpolation y (fun i => Complex.I*u i) hy
    (fun i j => by simpa only [mul_sub] using hmono i j)
  let v (k : ℕ) (p : ℂ) := -Complex.I*F k p
  have hs (k : ℕ) : ContDiff ℝ (⊤:ℕ∞) (v k) := contDiff_const.mul (hFs k)
  have hm (k : ℕ) (p z : ℂ) : 0 ≤ inner ℝ z (Complex.I*fderiv ℝ (v k) p z) := by
    have hd := ((hFs k).differentiable (by simp) p).hasFDerivAt.const_mul (-Complex.I)
    change HasFDerivAt (v k) _ p at hd
    rw [hd.fderiv]
    simpa only [smul_apply,smul_eq_mul,← mul_assoc,mul_neg,Complex.I_mul_I,neg_neg,one_mul] using hFd k p z
  have hb (k : ℕ) := smooth_velocity_dual_polygon_flux_nonpos next y a r e he hedge L R
    hgap hL hR hphase (v k) (hs k) (hm k)
  have hl (i : ι) : Tendsto (fun k => v k (y i)) atTop (𝓝 (u i)) := by
    have hh := tendsto_const_nhds.mul (hFl i) (a := -Complex.I)
    simpa only [v,← mul_assoc,neg_mul,Complex.I_mul_I,neg_neg,one_mul] using hh
  have hsum : Tendsto (fun k => ∑ i,inner ℝ (a (e i)) (v k (y (next i))-v k (y i))) atTop
      (𝓝 (∑ i,inner ℝ (a (e i)) (u (next i)-u i))) :=
    tendsto_finsetSum Finset.univ (fun i _ => tendsto_const_nhds.inner ((hl (next i)).sub (hl i)))
  exact le_of_tendsto hsum (Eventually.of_forall hb)

end MonotoneMatching
