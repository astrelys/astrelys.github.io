import MonotoneMatching.PolygonPath
import MonotoneMatching.ArgumentLifts

/-! Simple polygonal loops have nonzero chord loops of every proper offset. -/
noncomputable section
namespace MonotoneMatching
open scoped unitInterval

theorem exists_unit_edge_parameter {m : ℕ} {t : ℝ} (ht : t ∈ Set.Ico (0:ℝ) m) :
    ∃ i : Fin m, ∃ s ∈ Set.Ico (0:ℝ) 1, t=(i.val:ℝ)+s := by
  let i : Fin m := ⟨Nat.floor t,(Nat.floor_lt ht.1).mpr ht.2⟩
  refine ⟨i,t-i.val,⟨?_,?_⟩,?_⟩
  · exact sub_nonneg.mpr (Nat.floor_le ht.1)
  · have h := Nat.lt_floor_add_one t
    dsimp [i]
    linarith
  · ring

/-- Half-open edge injectivity gives injectivity on a full half-open period. -/
theorem periodicPolygonPath_injective_base {m : ℕ} (hm : 0<m) (v : Fin (m+1) → ℂ)
    (hedge : ∀ i j : Fin m, ∀ s t : ℝ, s ∈ Set.Ico (0:ℝ) 1 → t ∈ Set.Ico (0:ℝ) 1 →
      (1-s) • v i.castSucc+s • v i.succ = (1-t) • v j.castSucc+t • v j.succ → i=j ∧ s=t) :
    Set.InjOn (periodicPolygonPath v) (Set.Ico (0:ℝ) m) := by
  intro x hx y hy he
  obtain ⟨i,s,hs,rfl⟩ := exists_unit_edge_parameter hx
  obtain ⟨j,t,ht,rfl⟩ := exists_unit_edge_parameter hy
  rw [periodicPolygonPath_on_edge hm v i hs,periodicPolygonPath_on_edge hm v j ht] at he
  obtain ⟨hij,hst⟩ := hedge i j s t hs ht he
  rw [hij,hst]

theorem normalized_polygon_parameter_mem {m : ℕ} (hm : 0<m) (t : ℝ) :
    (m:ℝ)*Int.fract (t/m) ∈ Set.Ico (0:ℝ) m := by
  have hp : (0:ℝ)<m := Nat.cast_pos.mpr hm
  exact ⟨mul_nonneg hp.le (Int.fract_nonneg _),by nlinarith [Int.fract_lt_one (t/m)]⟩

theorem periodicPolygonPath_normalized {m : ℕ} (hm : 0<m) (v : Fin (m+1) → ℂ) (t : ℝ) :
    periodicPolygonPath v ((m:ℝ)*Int.fract (t/m))=periodicPolygonPath v t := by
  rw [periodicPolygonPath_on_base hm v (normalized_polygon_parameter_mem hm t)]
  rfl

/-- A proper offset cannot connect a point of a simple periodic polygon
back to itself. The argument keeps the modulo-period issue explicit. -/
theorem polygon_chord_ne_zero {m : ℕ} (hm : 0<m) (v : Fin (m+1) → ℂ)
    (hinj : Set.InjOn (periodicPolygonPath v) (Set.Ico (0:ℝ) m))
    {d : ℝ} (hd : d ∈ Set.Ioo (0:ℝ) m) (t : ℝ) :
    periodicPolygonPath v (t+d)-periodicPolygonPath v t ≠ 0 := by
  intro he
  have hp : (0:ℝ)<m := Nat.cast_pos.mpr hm
  have hnorm := hinj (normalized_polygon_parameter_mem hm (t+d))
    (normalized_polygon_parameter_mem hm t)
    (by rw [periodicPolygonPath_normalized hm v,periodicPolygonPath_normalized hm v];
        exact sub_eq_zero.mp he)
  have hfract : Int.fract ((t+d)/m)=Int.fract (t/m) := mul_left_cancel₀ (ne_of_gt hp) hnorm
  obtain ⟨k,hk⟩ := Int.fract_eq_fract.mp hfract
  have hratio : d/(m:ℝ)=(k:ℝ) := by rw [add_div] at hk; linarith
  have hk0 : (0:ℝ)<(k:ℝ) := by rw [← hratio]; exact div_pos hd.1 hp
  have hk1 : (k:ℝ)<1 := by rw [← hratio]; exact (div_lt_one hp).mpr hd.2
  have hk0' : (0:ℤ)<k := by exact_mod_cast hk0
  have hk1' : k<(1:ℤ) := by exact_mod_cast hk1
  omega

/-- All proper-offset chord loops have the same exact lifted increment.
Only boundary simplicity and continuity are used at this stage. -/
theorem polygon_chord_increment_independent {m : ℕ} (hm : 0<m)
    (v : Fin (m+1) → ℂ) (hclosed : v 0=v (Fin.last m))
    (hinj : Set.InjOn (periodicPolygonPath v) (Set.Ico (0:ℝ) m))
    {d e : ℝ} (hd : d ∈ Set.Ioo (0:ℝ) m) (he : e ∈ Set.Ioo (0:ℝ) m)
    (φ ψ : C(I,ℝ))
    (hφ : ∀ s, (φ s : Real.Angle)=
      (Complex.arg (periodicPolygonPath v ((m:ℝ)*(s:ℝ)+d)-periodicPolygonPath v ((m:ℝ)*(s:ℝ))) : Real.Angle))
    (hψ : ∀ s, (ψ s : Real.Angle)=
      (Complex.arg (periodicPolygonPath v ((m:ℝ)*(s:ℝ)+e)-periodicPolygonPath v ((m:ℝ)*(s:ℝ))) : Real.Angle)) :
    φ 1-φ 0=ψ 1-ψ 0 := by
  let offset := fun r : I => (1-(r:ℝ))*d+(r:ℝ)*e
  have hoff (r : I) : offset r ∈ Set.Ioo (0:ℝ) m := by
    have hr0 := r.property.1
    have hr1 := r.property.2
    simpa only [smul_eq_mul] using
      (convex_Ioo (𝕜 := ℝ) (0:ℝ) (m:ℝ)) hd he (sub_nonneg.mpr hr1) hr0
        (show (1-(r:ℝ))+(r:ℝ)=1 by ring)
  let H := fun p : I × I => periodicPolygonPath v ((m:ℝ)*(p.2:ℝ)+offset p.1) -
    periodicPolygonPath v ((m:ℝ)*(p.2:ℝ))
  have hc : Continuous H := by
    apply Continuous.sub
    · apply (continuous_periodicPolygonPath hm v hclosed).comp
      dsimp [offset]
      fun_prop
    · apply (continuous_periodicPolygonPath hm v hclosed).comp
      fun_prop
  have hn (p : I × I) : H p ≠ 0 := polygon_chord_ne_zero hm v hinj (hoff p.1) _
  have hp := periodicPolygonPath_periodic hm v
  have hloop (r : I) : H (r,1)=H (r,0) := by
    dsimp [H]
    simp only [mul_one,mul_zero,zero_add]
    rw [add_comm (m:ℝ) (offset r),hp (offset r)]
    have hm0 := hp 0
    rw [zero_add] at hm0
    rw [hm0]
  apply argument_loop_increment_homotopy H hc hn hloop φ ψ
  · intro s
    simpa [H,offset] using hφ s
  · intro s
    simpa [H,offset] using hψ s

end MonotoneMatching
