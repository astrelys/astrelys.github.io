import MonotoneMatching.HorizontalCrossings
import MonotoneMatching.CyclicCells

/-! Finite summation by parts for the signed dual-gradient flux across slices. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

theorem finite_jump_summation_by_parts {m : ℕ} (g F : Fin (m+1) → ℝ) :
    (∑ i : Fin m, g i.castSucc*(F i.castSucc-F i.succ)) =
      g 0*F 0-g (Fin.last m)*F (Fin.last m)+
        ∑ i : Fin m, (g i.succ-g i.castSucc)*F i.succ := by
  have ht := subdivision_duration_sum (fun i => g i*F i)
  have he : (∑ i : Fin m, g i.castSucc*(F i.castSucc-F i.succ)) =
      -(∑ i : Fin m, (g i.succ*F i.succ-g i.castSucc*F i.castSucc))+
        ∑ i : Fin m, (g i.succ-g i.castSucc)*F i.succ := by
    rw [← Finset.sum_neg_distrib,← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro i _
    ring
  rw [he,ht]
  ring

/-- A nonpositive phase profile with exterior value zero gives nonpositive
signed flux against an increasing sequence of active dual slopes. -/
theorem finite_jump_flux_nonpos {m : ℕ} (g F : Fin (m+1) → ℝ)
    (hg : Monotone g) (hF : ∀ i, F i≤0) (h0 : F 0=0) (hm : F (Fin.last m)=0) :
    (∑ i : Fin m, g i.castSucc*(F i.castSucc-F i.succ))≤0 := by
  rw [finite_jump_summation_by_parts,h0,hm,mul_zero,mul_zero,sub_self,zero_add]
  apply Finset.sum_nonpos
  intro i _
  exact mul_nonpos_of_nonneg_of_nonpos (sub_nonneg.mpr (hg i.castSucc_lt_succ.le)) (hF i.succ)

/-- Ordered horizontal maximizers of a convex affine maximum have ordered
horizontal gradient components. This uses only the two dual inequalities. -/
theorem horizontal_dual_slopes_monotone {n : ℕ} (a : Fin n → ℂ) (r : Fin n → ℝ)
    (i j : Fin n) {x z h : ℝ} (hxz : x<z)
    (hi : dualRow a r j (horizontalPoint x h)≤dualRow a r i (horizontalPoint x h))
    (hj : dualRow a r i (horizontalPoint z h)≤dualRow a r j (horizontalPoint z h)) :
    (a i).re≤(a j).re := by
  simp [dualRow,horizontalPoint,Complex.inner] at hi hj
  by_contra hn
  have hp := mul_pos (sub_pos.mpr (lt_of_not_ge hn)) (sub_pos.mpr hxz)
  nlinarith

end MonotoneMatching
