import MonotoneMatching.GenericMotionSources
import MonotoneMatching.OptimalCycle
import Mathlib.Analysis.InnerProductSpace.Calculus

set_option backward.isDefEq.respectTransparency.types false
noncomputable section
namespace MonotoneMatching
open scoped BigOperators Topology InnerProductSpace

/-- Standard real source coordinates, with real part before imaginary part. -/
def realCoordinates {n : ℕ} (z : Fin n → ℂ) (k : Fin n × Bool) : ℝ :=
  if k.2 then (z k.1).im else (z k.1).re

/-- The standard real coordinate identification is a homeomorphism. -/
def realCoordinatesHomeomorph (n : ℕ) : (Fin n → ℂ) ≃ₜ ((Fin n × Bool) → ℝ) where
  toFun := realCoordinates
  invFun := fun A i => ⟨A (i,false), A (i,true)⟩
  left_inv := by intro z; funext i; apply Complex.ext <;> rfl
  right_inv := by intro A; funext k; rcases k with ⟨i,b⟩; cases b <;> rfl
  continuous_toFun := by
    apply continuous_pi
    rintro ⟨i,b⟩
    cases b <;> simp only [realCoordinates, Bool.false_eq_true, ↓reduceIte] <;> fun_prop
  continuous_invFun := by
    apply continuous_pi
    intro i
    have h : Continuous (fun A : (Fin n × Bool) → ℝ =>
        (A (i,false) : ℂ) + (A (i,true) : ℂ) * Complex.I) := by fun_prop
    convert h using 1
    funext A
    apply Complex.ext <;> simp

theorem realCoordinates_sub {n : ℕ} (x y : Fin n → ℂ) :
    realCoordinates (x-y) = realCoordinates x - realCoordinates y := by
  funext k
  rcases k with ⟨i,b⟩
  cases b <;> simp [realCoordinates]

theorem realCoordinates_smul {n : ℕ} (r : ℝ) (x : Fin n → ℂ) :
    realCoordinates (r • x) = r • realCoordinates x := by
  funext k
  rcases k with ⟨i,b⟩
  cases b <;> simp [realCoordinates]

/-- The real-coordinate pairing is exactly the manuscript's assignment score. -/
theorem assignmentScore_realCoordinates {n : ℕ} (a b : Fin n → ℂ)
    (π : Equiv.Perm (Fin n)) :
    assignmentScore a b π = motionPairing (realCoordinates a) (realCoordinates (b ∘ π)) := by
  simp [assignmentScore, motionPairing, Fintype.sum_prod_type,
    realCoordinates, Complex.inner, add_comm, mul_comm]

theorem motionPairing_trajectory_score {n : ℕ} (a : Fin n → ℂ)
    (b : Fin n → ℝ → ℂ) (π : Equiv.Perm (Fin n)) (t : ℝ) :
    motionPairing (realCoordinates a) (realCoordinates (fun i => b (π i) t)) =
      assignmentScore a (fun i => b i t) π :=
  (assignmentScore_realCoordinates a (fun i => b i t) π).symm

theorem motionPairing_sub_right {ι : Type*} [Fintype ι] (A d e : ι → ℝ) :
    motionPairing A (d-e) = motionPairing A d - motionPairing A e := by
  simp [motionPairing, mul_sub, Finset.sum_sub_distrib]

/-- Exact source-genericity predicate for actual labeled trajectories. -/
def GenericTrajectorySources {n : ℕ} (b v : Fin n → ℝ → ℂ) (K : Set ℝ)
    (a : Fin n → ℂ) : Prop :=
  GenericMotionScores
    (fun π : Equiv.Perm (Fin n) => fun t => realCoordinates (fun i => b (π i) t))
    (fun π : Equiv.Perm (Fin n) => fun t => realCoordinates (fun i => v (π i) t)) K
    (realCoordinates a)

/-- Generic sources are open and dense for any fixed C1, collision-free labeled
motion. No motion perturbation or special velocity field is used. -/
theorem open_dense_genericTrajectorySources {n : ℕ} (b v : Fin n → ℝ → ℂ)
    (hd : ∀ i t, HasDerivAt (b i) (v i t) t) (hv : ∀ i, Continuous (v i))
    (hb : ∀ t, Function.Injective (fun i => b i t))
    (K : Set ℝ) (hK : IsCompact K) :
    IsOpen {a | GenericTrajectorySources b v K a} ∧ Dense {a | GenericTrajectorySources b v K a} := by
  have hder (π : Equiv.Perm (Fin n)) (k : Fin n × Bool) (t : ℝ) :
      HasDerivAt (fun s => realCoordinates (fun i => b (π i) s) k)
        (realCoordinates (fun i => v (π i) t) k) t := by
    rcases k with ⟨i,c⟩
    cases c
    · simpa only [realCoordinates, Bool.false_eq_true, ↓reduceIte] using!
        Complex.reCLM.hasFDerivAt.comp_hasDerivAt t (hd (π i) t)
    · simpa only [realCoordinates, ↓reduceIte] using!
        Complex.imCLM.hasFDerivAt.comp_hasDerivAt t (hd (π i) t)
  have hvel (π : Equiv.Perm (Fin n)) :
      Continuous (fun t => realCoordinates (fun i => v (π i) t)) :=
    (realCoordinatesHomeomorph n).continuous.comp (continuous_pi fun i => hv (π i))
  have hinj (t : ℝ) : Function.Injective
      (fun π : Equiv.Perm (Fin n) => realCoordinates (fun i => b (π i) t)) := by
    intro π τ he
    apply Equiv.ext
    intro i
    have heq : (fun i => b (π i) t) = fun i => b (τ i) t :=
      (realCoordinatesHomeomorph n).injective he
    exact hb t (congrFun heq i)
  have hind (π τ ρ : Equiv.Perm (Fin n)) (hπτ : π ≠ τ) (hπρ : π ≠ ρ)
      (hτρ : τ ≠ ρ) (t : ℝ) :
      ¬∃ c : ℝ, realCoordinates (fun i => b (ρ i) t) - realCoordinates (fun i => b (π i) t) =
        c • (realCoordinates (fun i => b (τ i) t) - realCoordinates (fun i => b (π i) t)) := by
    let B := fun i => b i t
    have hE (σ : Equiv.Perm (Fin n)) := configurationEnergy_permute B σ
    have hn := equal_energy_not_real_collinear (B ∘ π) (B ∘ τ) (B ∘ ρ)
      (permuted_configuration_ne B (hb t) hπτ) (permuted_configuration_ne B (hb t) hπρ)
      (permuted_configuration_ne B (hb t) hτρ) ((hE τ).trans (hE π).symm)
      ((hE ρ).trans (hE π).symm)
    rintro ⟨c,hc⟩
    apply hn
    refine ⟨c, (realCoordinatesHomeomorph n).injective ?_⟩
    change realCoordinates (B ∘ ρ - B ∘ π) = realCoordinates (c • (B ∘ τ - B ∘ π))
    rw [realCoordinates_sub, realCoordinates_smul, realCoordinates_sub]
    exact hc
  have hg := open_dense_genericMotionScores _ _ hder hvel hinj hind K hK
  exact ⟨(realCoordinatesHomeomorph n).continuous.isOpen_preimage _ hg.1,
    hg.2.preimage (realCoordinatesHomeomorph n).isOpenMap⟩

/-- Actual assignment scores differentiate to the corresponding velocity scores. -/
theorem assignmentScore_trajectory_hasDerivAt {n : ℕ} (a : Fin n → ℂ)
    (b v : Fin n → ℝ → ℂ) (hd : ∀ i t, HasDerivAt (b i) (v i t) t)
    (π : Equiv.Perm (Fin n)) (t : ℝ) :
    HasDerivAt (fun s => assignmentScore a (fun i => b i s) π)
      (assignmentScore a (fun i => v i t) π) t := by
  simpa only [assignmentScore, inner_zero_left, add_zero] using!
    HasDerivAt.fun_sum (u := Finset.univ)
      (fun i _ => (hasDerivAt_const t (a i)).inner ℝ (hd (π i) t))

/-- Every actual pair tie is transverse for the generic trajectory source predicate. -/
theorem generic_trajectory_pair_transverse {n : ℕ} (b v : Fin n → ℝ → ℂ)
    (K : Set ℝ) (a : Fin n → ℂ) (ha : GenericTrajectorySources b v K a)
    (t : ℝ) (ht : t ∈ K) (π τ : Equiv.Perm (Fin n)) (hπτ : π ≠ τ)
    (he : assignmentScore a (fun i => b i t) π = assignmentScore a (fun i => b i t) τ) :
    assignmentScore a (fun i => v i t) τ - assignmentScore a (fun i => v i t) π ≠ 0 := by
  have h := ha.1 π τ hπτ t ht
  simp only [motionPairing_sub_right, motionPairing_trajectory_score] at h
  exact h (sub_eq_zero.mpr he.symm)

/-- A generic source never has a triple tie of actual assignment scores. -/
theorem generic_trajectory_no_triple_tie {n : ℕ} (b v : Fin n → ℝ → ℂ)
    (K : Set ℝ) (a : Fin n → ℂ) (ha : GenericTrajectorySources b v K a)
    (t : ℝ) (ht : t ∈ K) (π τ ρ : Equiv.Perm (Fin n)) (hπτ : π ≠ τ)
    (h1 : assignmentScore a (fun i => b i t) π = assignmentScore a (fun i => b i t) τ)
    (h2 : assignmentScore a (fun i => b i t) π = assignmentScore a (fun i => b i t) ρ) :
    ρ = π ∨ ρ = τ := by
  by_contra hn
  push Not at hn
  have h := ha.2 π τ ρ hπτ hn.1.symm hn.2.symm t ht
  apply h
  constructor
  · rw [motionPairing_sub_right]
    exact sub_eq_zero.mpr (by simpa only [motionPairing_trajectory_score] using h1.symm)
  · rw [motionPairing_sub_right]
    exact sub_eq_zero.mpr (by simpa only [motionPairing_trajectory_score] using h2.symm)

/-- All actual assignment ties in a compact time set form a finite set for generic sources. -/
theorem finite_generic_trajectory_ties {n : ℕ} (b v : Fin n → ℝ → ℂ)
    (hd : ∀ i t, HasDerivAt (b i) (v i t) t)
    (K : Set ℝ) (hK : IsCompact K) (a : Fin n → ℂ) (ha : GenericTrajectorySources b v K a) :
    {t ∈ K | ∃ π τ : Equiv.Perm (Fin n), π ≠ τ ∧
      assignmentScore a (fun i => b i t) π = assignmentScore a (fun i => b i t) τ}.Finite := by
  have hf (π τ : Equiv.Perm (Fin n)) : {t ∈ K | π ≠ τ ∧
      assignmentScore a (fun i => b i t) π = assignmentScore a (fun i => b i t) τ}.Finite := by
    by_cases hπτ : π = τ
    · simp [hπτ]
    have hs (t : ℝ) := (assignmentScore_trajectory_hasDerivAt a b v hd τ t).sub
      (assignmentScore_trajectory_hasDerivAt a b v hd π t)
    have hr : ∀ t ∈ K,
        assignmentScore a (fun i => b i t) τ - assignmentScore a (fun i => b i t) π = 0 →
        assignmentScore a (fun i => v i t) τ - assignmentScore a (fun i => v i t) π ≠ 0 := by
      intro t ht hz
      exact generic_trajectory_pair_transverse b v K a ha t ht π τ hπτ (sub_eq_zero.mp hz).symm
    apply (finite_regular_zeros_on_compact _ _ hs K hK hr).subset
    intro t ht
    exact ⟨ht.1, sub_eq_zero.mpr ht.2.2.symm⟩
  apply (Set.finite_iUnion fun π => Set.finite_iUnion (hf π)).subset
  rintro t ⟨ht,π,τ,hπτ,he⟩
  exact Set.mem_iUnion.mpr ⟨π,Set.mem_iUnion.mpr ⟨τ,ht,hπτ,he⟩⟩

/-- Relabeling an arbitrary old optimum reduces the two-optimum cycle theorem to identity. -/
theorem two_optima_isCycle {n : ℕ} (a b : Fin n → ℂ) (π τ : Equiv.Perm (Fin n))
    (hne : π ≠ τ)
    (hmax : ∀ ρ, assignmentScore a b ρ ≤ assignmentScore a b π)
    (heq : assignmentScore a b τ = assignmentScore a b π)
    (htwo : ∀ ρ, assignmentScore a b ρ = assignmentScore a b π → ρ = π ∨ ρ = τ) :
    (π⁻¹ * τ).IsCycle := by
  have hs (ρ : Equiv.Perm (Fin n)) : assignmentScore a (b ∘ π) ρ = assignmentScore a b (π * ρ) := by
    simp only [assignmentScore, Function.comp_def, Equiv.Perm.mul_apply]
  have hid : (Equiv.refl (Fin n) : Equiv.Perm (Fin n)) = 1 := rfl
  apply two_optima_identity_isCycle a (b ∘ π) (π⁻¹ * τ)
  · intro hz
    have h := congrArg (fun ρ => π * ρ) hz
    have htp : τ = π := by simpa [hid] using h
    exact hne htp.symm
  · intro ρ
    simpa [hs,hid] using hmax (π * ρ)
  · simpa [hs,hid] using heq
  · intro ρ hρ
    rcases htwo (π * ρ) (by simpa [hs,hid] using hρ) with h | h
    · left
      simpa [hid] using congrArg (fun σ => π⁻¹ * σ) h
    · right
      simpa [hid] using congrArg (fun σ => π⁻¹ * σ) h

/-- Every generic optimal tie is exactly a single nontrivial cycle exchange. -/
theorem generic_trajectory_optimal_tie_isCycle {n : ℕ} (b v : Fin n → ℝ → ℂ)
    (K : Set ℝ) (a : Fin n → ℂ) (ha : GenericTrajectorySources b v K a)
    (t : ℝ) (ht : t ∈ K) (π τ : Equiv.Perm (Fin n)) (hne : π ≠ τ)
    (hmax : ∀ ρ, assignmentScore a (fun i => b i t) ρ ≤ assignmentScore a (fun i => b i t) π)
    (heq : assignmentScore a (fun i => b i t) τ = assignmentScore a (fun i => b i t) π) :
    (π⁻¹ * τ).IsCycle ∧
      (∀ ρ, assignmentScore a (fun i => b i t) ρ = assignmentScore a (fun i => b i t) π →
        ρ = π ∨ ρ = τ) := by
  have htwo (ρ : Equiv.Perm (Fin n))
      (hρ : assignmentScore a (fun i => b i t) ρ = assignmentScore a (fun i => b i t) π) :
      ρ = π ∨ ρ = τ :=
    generic_trajectory_no_triple_tie b v K a ha t ht π τ ρ hne heq.symm hρ.symm
  exact ⟨two_optima_isCycle a (fun i => b i t) π τ hne hmax heq htwo, htwo⟩

/-- A generic pair tie is isolated in the real time axis, including at the period seam. -/
theorem generic_trajectory_pair_isolated {n : ℕ} (b v : Fin n → ℝ → ℂ)
    (hd : ∀ i t, HasDerivAt (b i) (v i t) t)
    (K : Set ℝ) (a : Fin n → ℂ) (ha : GenericTrajectorySources b v K a)
    (t : ℝ) (ht : t ∈ K) (π τ : Equiv.Perm (Fin n)) (hne : π ≠ τ)
    (heq : assignmentScore a (fun i => b i t) π = assignmentScore a (fun i => b i t) τ) :
    ∀ᶠ s in 𝓝[≠] t, assignmentScore a (fun i => b i s) π ≠ assignmentScore a (fun i => b i s) τ := by
  have h := ((assignmentScore_trajectory_hasDerivAt a b v hd τ t).sub
    (assignmentScore_trajectory_hasDerivAt a b v hd π t)).eventually_ne
      (generic_trajectory_pair_transverse b v K a ha t ht π τ hne heq) (c := 0)
  filter_upwards [h] with s hs
  intro he
  exact hs (sub_eq_zero.mpr he.symm)

/-- Complete W3 statement over one closed period, with actual scores and derivatives. -/
def genericTrajectoryStatement : Prop :=
  ∀ (n : ℕ) (b v : Fin n → ℝ → ℂ) (T : ℝ), 0 < T →
    (∀ i t, HasDerivAt (b i) (v i t) t) → (∀ i, Continuous (v i)) →
    (∀ t, Function.Injective (fun i => b i t)) →
    ∃ G : Set (Fin n → ℂ), IsOpen G ∧ Dense G ∧ ∀ a ∈ G,
      ({t ∈ Set.Icc 0 T | ∃ π τ : Equiv.Perm (Fin n), π ≠ τ ∧
        assignmentScore a (fun i => b i t) π = assignmentScore a (fun i => b i t) τ}.Finite) ∧
      (∀ t ∈ Set.Icc 0 T, ∀ π τ : Equiv.Perm (Fin n), π ≠ τ →
        assignmentScore a (fun i => b i t) π = assignmentScore a (fun i => b i t) τ →
        (assignmentScore a (fun i => v i t) τ - assignmentScore a (fun i => v i t) π ≠ 0) ∧
        (∀ᶠ s in 𝓝[≠] t, assignmentScore a (fun i => b i s) π ≠ assignmentScore a (fun i => b i s) τ)) ∧
      (∀ t ∈ Set.Icc 0 T, ∀ π τ : Equiv.Perm (Fin n), π ≠ τ →
        (∀ ρ, assignmentScore a (fun i => b i t) ρ ≤ assignmentScore a (fun i => b i t) π) →
        assignmentScore a (fun i => b i t) τ = assignmentScore a (fun i => b i t) π →
        (π⁻¹ * τ).IsCycle ∧
        (∀ ρ, assignmentScore a (fun i => b i t) ρ = assignmentScore a (fun i => b i t) π →
          ρ = π ∨ ρ = τ))

/-- W3: open dense source-only genericity, finite isolated transverse ties, and
exactly two optimal permutations differing by one nontrivial cycle. -/
theorem generic_trajectory_sources : genericTrajectoryStatement := by
  intro n b v T _ hd hv hb
  have hg := open_dense_genericTrajectorySources b v hd hv hb (Set.Icc 0 T) isCompact_Icc
  refine ⟨{a | GenericTrajectorySources b v (Set.Icc 0 T) a}, hg.1, hg.2, ?_⟩
  intro a ha
  refine ⟨finite_generic_trajectory_ties b v hd _ isCompact_Icc a ha, ?_, ?_⟩
  · intro t ht π τ hne heq
    exact ⟨generic_trajectory_pair_transverse b v _ a ha t ht π τ hne heq,
      generic_trajectory_pair_isolated b v hd _ a ha t ht π τ hne heq⟩
  · intro t ht π τ hne hmax heq
    exact generic_trajectory_optimal_tie_isCycle b v _ a ha t ht π τ hne hmax heq

end MonotoneMatching
