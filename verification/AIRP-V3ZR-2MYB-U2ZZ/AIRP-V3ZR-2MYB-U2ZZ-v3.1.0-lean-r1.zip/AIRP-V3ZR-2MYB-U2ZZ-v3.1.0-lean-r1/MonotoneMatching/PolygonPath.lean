import MonotoneMatching.PolygonPhase
import Mathlib.Topology.Algebra.Order.Floor

/-! A continuous piecewise-affine polygon path with explicit edge parameters. -/
noncomputable section
namespace MonotoneMatching
open scoped BigOperators

def linearHat (t : ℝ) : ℝ := max 0 (1-|t|)

theorem continuous_linearHat : Continuous linearHat := by
  unfold linearHat
  fun_prop

theorem linearHat_nat_shift (k j : ℕ) {s : ℝ} (hs : s ∈ Set.Icc (0:ℝ) 1) :
    linearHat ((k:ℝ)+s-j) = if j=k then 1-s else if j=k+1 then s else 0 := by
  by_cases hj : j=k
  · subst j
    have he : (k:ℝ)+s-k=s := by ring
    rw [he,ite_eq_left rfl]
    simp only [linearHat,abs_of_nonneg hs.1,max_eq_right (sub_nonneg.mpr hs.2)]
  · rw [ite_eq_right hj]
    by_cases hj1 : j=k+1
    · rw [ite_eq_left hj1,hj1]
      have he : (k:ℝ)+s-(k+1:ℕ)=s-1 := by push_cast; ring
      rw [he]
      simp only [linearHat,abs_of_nonpos (sub_nonpos.mpr hs.2)]
      have he' : 1- -(s-1)=s := by ring
      rw [he',max_eq_right hs.1]
    · rw [ite_eq_right hj1]
      have hb : 1 ≤ |(k:ℝ)+s-j| := by
        by_cases hlt : j<k
        · have hr : (j:ℝ)+1 ≤ k := by exact_mod_cast hlt
          apply le_trans _ (le_abs_self _)
          linarith [hs.1]
        · have hnat : k+2 ≤ j := by omega
          have hr : (k:ℝ)+2 ≤ j := by exact_mod_cast hnat
          apply le_trans _ (neg_le_abs _)
          linarith [hs.2]
      exact max_eq_left (by linarith : 1-|(k:ℝ)+s-j| ≤ 0)

/-- The finite tent-function formula is affine on each unit interval. -/
def polygonInterpolation {m : ℕ} (v : Fin (m+1) → ℂ) (t : ℝ) : ℂ :=
  ∑ j, linearHat (t-j.val) • v j

theorem continuous_polygonInterpolation {m : ℕ} (v : Fin (m+1) → ℂ) :
    Continuous (polygonInterpolation v) := by
  unfold polygonInterpolation
  apply continuous_finsetSum
  intro j _
  exact (continuous_linearHat.comp (continuous_id.sub continuous_const)).smul continuous_const

theorem polygonInterpolation_on_edge {m : ℕ} (v : Fin (m+1) → ℂ)
    (i : Fin m) {s : ℝ} (hs : s ∈ Set.Icc (0:ℝ) 1) :
    polygonInterpolation v (i.val+s)=(1-s) • v i.castSucc+s • v i.succ := by
  classical
  unfold polygonInterpolation
  have hterm (j : Fin (m+1)) : linearHat ((i.val:ℝ)+s-j.val) • v j =
      (if j=i.castSucc then (1-s) • v i.castSucc else 0) +
      (if j=i.succ then s • v i.succ else 0) := by
    rw [linearHat_nat_shift i.val j.val hs]
    by_cases h0 : j=i.castSucc
    · subst j
      simp [ne_of_lt i.castSucc_lt_succ]
    · by_cases h1 : j=i.succ
      · subst j
        simp [ne_of_gt i.castSucc_lt_succ]
      · have hv0 : j.val ≠ i.val := by intro h; exact h0 (Fin.ext h)
        have hv1 : j.val ≠ i.val+1 := by intro h; exact h1 (Fin.ext h)
        simp [hv0,hv1,h0,h1]
  rw [Finset.sum_congr rfl (fun j _ => hterm j),Finset.sum_add_distrib]
  simp

theorem polygonInterpolation_zero {m : ℕ} (hm : 0<m) (v : Fin (m+1) → ℂ) :
    polygonInterpolation v 0=v 0 := by
  let i : Fin m := ⟨0,hm⟩
  have h := polygonInterpolation_on_edge v i (s := 0) ⟨le_rfl,zero_le_one⟩
  simpa [i] using h

theorem polygonInterpolation_last {m : ℕ} (hm : 0<m) (v : Fin (m+1) → ℂ) :
    polygonInterpolation v m=v (Fin.last m) := by
  let i : Fin m := ⟨m-1,by omega⟩
  have hi : i.succ=Fin.last m := Fin.ext (by dsimp [i]; omega)
  have ht : (i.val:ℝ)+1=m := by
    have hh : i.val+1=m := by dsimp [i]; omega
    exact_mod_cast hh
  have h := polygonInterpolation_on_edge v i (s := 1) ⟨zero_le_one,le_rfl⟩
  simpa only [ht,hi,sub_self,zero_smul,one_smul,zero_add] using h

/-- Repeat the closed interpolation with period equal to the number of edges. -/
def periodicPolygonPath {m : ℕ} (v : Fin (m+1) → ℂ) (t : ℝ) : ℂ :=
  polygonInterpolation v ((m:ℝ)*Int.fract (t/m))

theorem continuous_periodicPolygonPath {m : ℕ} (hm : 0<m)
    (v : Fin (m+1) → ℂ) (hclosed : v 0=v (Fin.last m)) :
    Continuous (periodicPolygonPath v) := by
  have hc : Continuous (fun t : ℝ => polygonInterpolation v ((m:ℝ)*t)) :=
    (continuous_polygonInterpolation v).comp (continuous_const.mul continuous_id)
  have he : polygonInterpolation v ((m:ℝ)*0)=polygonInterpolation v ((m:ℝ)*1) := by
    rw [mul_zero,mul_one,polygonInterpolation_zero hm,polygonInterpolation_last hm,hclosed]
  exact (hc.continuousOn.comp_fract'' he).comp (continuous_id.div_const (m:ℝ))

theorem periodicPolygonPath_periodic {m : ℕ} (hm : 0<m) (v : Fin (m+1) → ℂ) :
    Function.Periodic (periodicPolygonPath v) (m:ℝ) := by
  intro t
  have hn : (m:ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.ne_of_gt hm)
  simp only [periodicPolygonPath,add_div,div_self hn,Int.fract_add_one]

theorem periodicPolygonPath_on_base {m : ℕ} (hm : 0<m) (v : Fin (m+1) → ℂ)
    {t : ℝ} (ht : t ∈ Set.Ico (0:ℝ) m) :
    periodicPolygonPath v t=polygonInterpolation v t := by
  have hp : (0:ℝ)<m := Nat.cast_pos.mpr hm
  have hf : Int.fract (t/m)=t/m := Int.fract_eq_self.mpr
    ⟨div_nonneg ht.1 hp.le,(div_lt_one hp).mpr ht.2⟩
  simp only [periodicPolygonPath,hf,mul_div_cancel₀ _ (ne_of_gt hp)]

theorem periodicPolygonPath_on_edge {m : ℕ} (hm : 0<m) (v : Fin (m+1) → ℂ)
    (i : Fin m) {s : ℝ} (hs : s ∈ Set.Ico (0:ℝ) 1) :
    periodicPolygonPath v (i.val+s)=(1-s) • v i.castSucc+s • v i.succ := by
  rw [periodicPolygonPath_on_base hm v]
  · exact polygonInterpolation_on_edge v i ⟨hs.1,hs.2.le⟩
  · constructor
    · exact add_nonneg (Nat.cast_nonneg _) hs.1
    · have hi : (i.val:ℝ)+1 ≤ m := by exact_mod_cast i.isLt
      linarith [hs.2]

end MonotoneMatching
