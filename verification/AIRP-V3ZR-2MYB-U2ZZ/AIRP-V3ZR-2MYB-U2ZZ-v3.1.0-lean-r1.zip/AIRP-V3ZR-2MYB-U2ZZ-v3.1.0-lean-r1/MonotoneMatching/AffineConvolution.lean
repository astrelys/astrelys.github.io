import MonotoneMatching.ConvexSmoothing
noncomputable section
namespace MonotoneMatching
open MeasureTheory ContinuousLinearMap Set
open scoped BigOperators Convolution Topology
set_option backward.isDefEq.respectTransparency.types false

/-- Convolution of an affine function has the same derivative, without needing
an explicit first moment for the smoothing kernel. -/
theorem affine_bump_convolution_hasFDerivAt (A : ℂ →L[ℝ] ℝ) (c : ℝ)
    (φ : ContDiffBump (0:ℂ)) (p : ℂ) :
    HasFDerivAt (φ.normed volume ⋆[lsmul ℝ ℝ,volume] (fun x => A x+c)) A p := by
  have hc : Continuous (fun x => A x+c) := A.continuous.add continuous_const
  have hi : Integrable (fun t => φ.normed volume t*(c-A t)) := by
    have h : ConvolutionExistsAt (φ.normed volume) (fun x => A x+c) 0 (lsmul ℝ ℝ) volume :=
      φ.hasCompactSupport_normed.convolutionExists_left_of_continuous_right
      (lsmul ℝ ℝ) φ.continuous_normed.locallyIntegrable hc 0
    simpa only [ConvolutionExistsAt,lsmul_apply,smul_eq_mul,zero_sub,map_neg,neg_add_eq_sub] using h
  have he (x : ℂ) : (φ.normed volume ⋆[lsmul ℝ ℝ,volume] (fun x => A x+c)) x=
      A x+∫ t, φ.normed volume t*(c-A t) := by
    simp only [convolution_def,lsmul_apply,smul_eq_mul,map_sub]
    have hh (t : ℂ) : φ.normed volume t*(A x-A t+c)=
        φ.normed volume t*A x+φ.normed volume t*(c-A t) := by ring
    simp_rw [hh]
    rw [integral_add (φ.integrable_normed.mul_const _) hi,integral_mul_const,φ.integral_normed,one_mul]
  simpa only [← he] using (A.hasFDerivAt.add_const (∫ t,φ.normed volume t*(c-A t)) (x := p))

/-- A sufficiently small kernel preserves the derivative on a neighborhood
where the original function is affine. -/
theorem eventually_bump_affine_derivative (f : ℂ → ℝ) (A : ℂ →L[ℝ] ℝ) (c : ℝ)
    (p : ℂ) (he : ∀ᶠ q in 𝓝 p, f q=A q+c)
    (φ : ℕ → ContDiffBump (0:ℂ)) (hφ : Filter.Tendsto (fun k => (φ k).rOut) Filter.atTop (𝓝 0)) :
    ∀ᶠ k in Filter.atTop, HasFDerivAt ((φ k).normed volume ⋆[lsmul ℝ ℝ,volume] f) A p := by
  obtain ⟨ρ,hρ,hball⟩ := Metric.mem_nhds_iff.mp he
  have hs : ∀ᶠ k in Filter.atTop,(φ k).rOut < ρ/2 :=
    hφ.eventually (gt_mem_nhds (by linarith : (0:ℝ)<ρ/2))
  filter_upwards [hs] with k hk
  apply (affine_bump_convolution_hasFDerivAt A c (φ k) p).congr_of_eventuallyEq
  filter_upwards [Metric.ball_mem_nhds p (by linarith : (0:ℝ)<ρ/2)] with q hq
  simp only [convolution_def,lsmul_apply,smul_eq_mul]
  apply integral_congr_ae
  filter_upwards with t
  by_cases ht : (φ k).normed volume t=0
  · simp only [ht,zero_mul]
  · have ht' : t ∈ Metric.ball (0:ℂ) (φ k).rOut := by
      rw [← (φ k).support_normed_eq (μ := volume)]
      exact ht
    have hdist : dist (q-t) p<ρ := by
      have htri := dist_triangle (q-t) q p
      have heq : dist (q-t) q=‖t‖ := by rw [dist_eq_norm]; simp
      rw [heq] at htri
      have ht'' : ‖t‖ < (φ k).rOut := by simpa only [Metric.mem_ball,dist_zero_right] using ht'
      have hq' : dist q p<ρ/2 := hq
      linarith
    rw [hball hdist]

end MonotoneMatching
