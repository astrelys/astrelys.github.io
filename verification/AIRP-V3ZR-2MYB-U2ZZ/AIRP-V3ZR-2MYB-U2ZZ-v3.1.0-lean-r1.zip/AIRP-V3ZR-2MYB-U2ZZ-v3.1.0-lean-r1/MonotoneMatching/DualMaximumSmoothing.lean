import MonotoneMatching.DualMaximum
import MonotoneMatching.AffineConvolution
import Mathlib.MeasureTheory.Integral.DominatedConvergence
noncomputable section
namespace MonotoneMatching
open MeasureTheory ContinuousLinearMap Set Filter
open scoped BigOperators InnerProductSpace Convolution Topology
set_option backward.isDefEq.respectTransparency.types false

/-- Smooth convex approximants have uniformly bounded derivatives and eventually
exact row derivatives at every point of a strict dual cell. -/
theorem exists_smooth_dualMaximum_sequence {n : ℕ} [Nonempty (Fin n)]
    (a : Fin n → ℂ) (r : Fin n → ℝ) :
    ∃ L : NNReal, ∃ g : ℕ → ℂ → ℝ,
      (∀ k,ContDiff ℝ (⊤:ℕ∞) (g k)) ∧ (∀ k,ConvexOn ℝ univ (g k)) ∧
      (∀ k p,‖fderiv ℝ (g k) p‖ ≤ L) ∧
      (∀ i p,p∈strictDualCell a r i →
        ∀ᶠ k in atTop,fderiv ℝ (g k) p=innerSL ℝ (a i)) := by
  let L : NNReal := ∑ i,‖a i‖₊
  have hL (i : Fin n) : ‖a i‖ ≤ L := by
    exact_mod_cast Finset.single_le_sum (fun j _ => (zero_le : (0:NNReal)≤‖a j‖₊)) (Finset.mem_univ i)
  let δ (k : ℕ) : ℝ := 1/((k:ℝ)+1)
  have hδ (k : ℕ) : 0<δ k := by dsimp [δ]; positivity
  let φ (k : ℕ) : ContDiffBump (0:ℂ) := ⟨δ k/2,δ k,by positivity,by linarith [hδ k]⟩
  let g (k : ℕ) := (φ k).normed volume ⋆[lsmul ℝ ℝ,volume] dualMaximum a r
  have hc := continuous_dualMaximum a r
  have hs (k : ℕ) : ContDiff ℝ (⊤:ℕ∞) (g k) :=
    (φ k).hasCompactSupport_normed.contDiff_convolution_left (lsmul ℝ ℝ)
      (φ k).contDiff_normed hc.locallyIntegrable
  refine ⟨L,g,hs,(fun k => convex_bump_convolution _ hc (convex_dualMaximum a r) (φ k)),?_,?_⟩
  · intro k p
    apply norm_fderiv_le_of_lipschitz ℝ
    apply LipschitzWith.of_dist_le_mul
    intro x y
    rw [dist_eq_norm,dist_eq_norm]
    exact lipschitz_bump_convolution _ hc L (fun x y => (lipschitz_dualMaximum a r L hL).norm_sub_le x y) (φ k) x y
  · intro i p hp
    have he : ∀ᶠ q in 𝓝 p,dualMaximum a r q=(innerSL ℝ (a i)) q+(-r i) := by
      simpa only [dualRow,sub_eq_add_neg] using! dualMaximum_locally_affine a r i p hp
    have ht : Tendsto (fun k => (φ k).rOut) atTop (𝓝 0) := tendsto_one_div_add_atTop_nhds_zero_nat
    filter_upwards [eventually_bump_affine_derivative (dualMaximum a r) (innerSL ℝ (a i)) (-r i) p he φ ht] with k hk
    exact hk.fderiv

/-- Dominated convergence on an edge needs gradient convergence only away from
its two endpoints; the uniform gradient norm supplies the domination. -/
theorem affine_edge_gradient_integral_limit (g : ℕ → ℂ → ℝ)
    (hg : ∀ k,ContDiff ℝ (⊤:ℕ∞) (g k)) (L : NNReal)
    (hbound : ∀ k p,‖fderiv ℝ (g k) p‖ ≤ L)
    (A : ℂ →L[ℝ] ℝ) (z w : ℂ) (V : ℂ → ℂ →L[ℝ] ℂ) (hV : Continuous V)
    (hlim : ∀ t∈Ioo (0:ℝ) 1,∀ᶠ k in atTop,fderiv ℝ (g k) ((1-t) • z+t • w)=A) :
    Tendsto (fun k => ∫ t in (0:ℝ)..1,
      fderiv ℝ (g k) ((1-t) • z+t • w) (V ((1-t) • z+t • w) (w-z))) atTop
      (𝓝 (∫ t in (0:ℝ)..1,A (V ((1-t) • z+t • w) (w-z)))) := by
  have hc : Continuous (fun t : ℝ => (1-t) • z+t • w) := by fun_prop
  have hv : Continuous (fun t : ℝ => V ((1-t) • z+t • w) (w-z)) :=
    (hV.comp hc).clm_apply continuous_const
  apply intervalIntegral.tendsto_integral_filter_of_dominated_convergence
    (fun t => (L:ℝ)*‖V ((1-t) • z+t • w) (w-z)‖)
  · filter_upwards with k
    exact (((hg k).continuous_fderiv (by simp)).comp hc |>.clm_apply hv).aestronglyMeasurable
  · filter_upwards with k
    filter_upwards with t _
    exact (le_opNorm _ _).trans (mul_le_mul_of_nonneg_right (hbound k _) (norm_nonneg _))
  · exact (continuous_const.mul hv.norm).intervalIntegrable _ _
  · filter_upwards [MeasureTheory.Measure.ae_ne volume (1:ℝ)] with t ht hmem
    have ht' : t∈Ioo (0:ℝ) 1 := by
      simp only [uIoc_of_le (by norm_num : (0:ℝ)≤1),mem_Ioc] at hmem
      exact ⟨hmem.1,lt_of_le_of_ne hmem.2 ht⟩
    apply tendsto_const_nhds.congr'
    filter_upwards [hlim t ht'] with k hk
    rw [hk]

end MonotoneMatching
