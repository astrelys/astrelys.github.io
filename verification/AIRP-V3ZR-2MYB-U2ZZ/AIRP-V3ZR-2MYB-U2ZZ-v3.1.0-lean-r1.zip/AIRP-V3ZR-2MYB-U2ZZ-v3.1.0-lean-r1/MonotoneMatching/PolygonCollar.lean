import MonotoneMatching.PolygonEdgeJump

/-! Local left and right collars of an isolated polygon edge. -/
noncomputable section
namespace MonotoneMatching
open ComplexConjugate Filter
open scoped Topology

def edgeSide (z w q : ℂ) : ℝ := ((q-z)*conj (w-z)).im

theorem continuous_edgeSide (z w : ℂ) : Continuous (edgeSide z w) := by
  unfold edgeSide
  fun_prop

theorem edgeSide_affine (z w x y : ℂ) (a b : ℝ) (hab : a+b=1) :
    edgeSide z w (a • x+b • y)=a*edgeSide z w x+b*edgeSide z w y := by
  simp only [edgeSide,Complex.mul_im,Complex.sub_re,Complex.sub_im,
    Complex.add_re,Complex.add_im,Complex.smul_re,Complex.smul_im,smul_eq_mul,
    Complex.conj_re,Complex.conj_im]
  nlinarith [congrArg (fun t : ℝ => t*z.re*(w.im-z.im)) hab,
    congrArg (fun t : ℝ => t*z.im*(w.re-z.re)) hab]

theorem convex_edgeSide_pos (z w : ℂ) : Convex ℝ {q | 0<edgeSide z w q} := by
  intro x hx y hy a b ha hb hab
  change 0<edgeSide z w x at hx
  change 0<edgeSide z w y at hy
  change 0<edgeSide z w (a • x+b • y)
  rw [edgeSide_affine _ _ _ _ _ _ hab]
  by_cases ha0 : a=0
  · subst a
    simp only [zero_add] at hab
    simpa only [hab,zero_mul,one_mul,zero_add] using (show _ from hy)
  · exact add_pos_of_pos_of_nonneg (mul_pos (lt_of_le_of_ne ha (Ne.symm ha0)) hx)
      (mul_nonneg hb hy.le)

theorem convex_edgeSide_neg (z w : ℂ) : Convex ℝ {q | edgeSide z w q<0} := by
  intro x hx y hy a b ha hb hab
  change edgeSide z w x<0 at hx
  change edgeSide z w y<0 at hy
  change edgeSide z w (a • x+b • y)<0
  rw [edgeSide_affine _ _ _ _ _ _ hab]
  by_cases ha0 : a=0
  · subst a
    simp only [zero_add] at hab
    simpa only [hab,zero_mul,one_mul,zero_add] using (show _ from hy)
  · exact add_neg_of_neg_of_nonpos (mul_neg_of_pos_of_neg (lt_of_le_of_ne ha (Ne.symm ha0)) hx)
      (mul_nonpos_of_nonneg_of_nonpos hb hy.le)

theorem edgeSide_eq_zero_on_segment (z w : ℂ) {q : ℂ} (hq : q ∈ segment ℝ z w) :
    edgeSide z w q=0 := by
  rw [segment_eq_image] at hq
  obtain ⟨t,ht,rfl⟩ := hq
  rw [edgeSide_affine _ _ _ _ _ _ (by ring)]
  simp only [edgeSide,Complex.mul_im,Complex.sub_re,Complex.sub_im,Complex.conj_re,Complex.conj_im]
  ring

theorem edgeSide_crossPoint (z w : ℂ) (r ε : ℝ) :
    edgeSide z w (edgeCrossPoint z w r ε)=ε*Complex.normSq (w-z) := by
  simp [edgeSide,edgeCrossPoint,Complex.mul_im,Complex.mul_re,Complex.normSq_apply]
  ring

/-- If a ball meets no edge other than the distinguished edge, the winding
phase is constant on each of its two open half-balls. -/
theorem polygonIndexPhase_eq_in_left_collar {ι : Type*} [Fintype ι] [DecidableEq ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (i : ι) (q : ℂ) (δ : ℝ)
    (hother : ∀ j, j≠i → Disjoint (Metric.ball q δ) (segment ℝ (v j) (v (next j))))
    {x y : ℂ} (hx : x ∈ Metric.ball q δ) (hy : y ∈ Metric.ball q δ)
    (hxs : 0<edgeSide (v i) (v (next i)) x) (hys : 0<edgeSide (v i) (v (next i)) y) :
    polygonIndexPhase next v x=polygonIndexPhase next v y := by
  apply polygonIndexPhase_eq_on_connected next v
    ((convex_ball q δ).inter (convex_edgeSide_pos _ _)).isPreconnected _ ⟨hx,hxs⟩ ⟨hy,hys⟩
  intro p hp hboundary
  obtain ⟨j,hj⟩ := Set.mem_iUnion.mp hboundary
  by_cases hji : j=i
  · subst j
    exact (ne_of_gt hp.2) (edgeSide_eq_zero_on_segment _ _ hj)
  · exact Set.disjoint_left.mp (hother j hji) hp.1 hj

theorem polygonIndexPhase_eq_in_right_collar {ι : Type*} [Fintype ι] [DecidableEq ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (i : ι) (q : ℂ) (δ : ℝ)
    (hother : ∀ j, j≠i → Disjoint (Metric.ball q δ) (segment ℝ (v j) (v (next j))))
    {x y : ℂ} (hx : x ∈ Metric.ball q δ) (hy : y ∈ Metric.ball q δ)
    (hxs : edgeSide (v i) (v (next i)) x<0) (hys : edgeSide (v i) (v (next i)) y<0) :
    polygonIndexPhase next v x=polygonIndexPhase next v y := by
  apply polygonIndexPhase_eq_on_connected next v
    ((convex_ball q δ).inter (convex_edgeSide_neg _ _)).isPreconnected _ ⟨hx,hxs⟩ ⟨hy,hys⟩
  intro p hp hboundary
  obtain ⟨j,hj⟩ := Set.mem_iUnion.mp hboundary
  by_cases hji : j=i
  · subst j
    exact (ne_of_lt hp.2) (edgeSide_eq_zero_on_segment _ _ hj)
  · exact Set.disjoint_left.mp (hother j hji) hp.1 hj

/-- An interior point belonging to only one edge admits an isolating ball. -/
theorem exists_isolated_edge_ball {ι : Type*} [Fintype ι] [DecidableEq ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (i : ι) (q : ℂ)
    (hother : ∀ j, j≠i → q ∉ segment ℝ (v j) (v (next j))) :
    ∃ δ : ℝ, 0<δ ∧ ∀ j, j≠i →
      Disjoint (Metric.ball q δ) (segment ℝ (v j) (v (next j))) := by
  let S : Set ℂ := ⋃ j : {j : ι // j≠i}, segment ℝ (v j.val) (v (next j.val))
  have hc : IsCompact S := isCompact_iUnion (fun j => isCompact_complex_segment (v j.val) (v (next j.val)))
  have hq : q ∈ Sᶜ := by
    intro h
    obtain ⟨j,hj⟩ := Set.mem_iUnion.mp h
    exact hother j.val j.property hj
  obtain ⟨δ,hδ,hball⟩ := Metric.isOpen_iff.mp hc.isClosed.isOpen_compl q hq
  refine ⟨δ,hδ,?_⟩
  intro j hj
  apply Set.disjoint_left.mpr
  intro p hp hpj
  exact hball hp (Set.mem_iUnion.mpr ⟨⟨j,hj⟩,hpj⟩)

/-- The limiting edge calculation gives an exact jump between arbitrary
points in the isolated left and right half-balls. -/
theorem polygonIndexPhase_isolated_collar_jump {ι : Type*} [Fintype ι] [DecidableEq ι]
    (next : Equiv.Perm ι) (v : ι → ℂ) (i : ι) (hne : v i≠v (next i))
    {r : ℝ} (hr : r ∈ Set.Ioo (0:ℝ) 1) {δ : ℝ} (hδ : 0<δ)
    (hother : ∀ j, j≠i → Disjoint
      (Metric.ball (edgeCrossPoint (v i) (v (next i)) r 0) δ)
      (segment ℝ (v j) (v (next j))))
    {x y : ℂ}
    (hx : x ∈ Metric.ball (edgeCrossPoint (v i) (v (next i)) r 0) δ)
    (hy : y ∈ Metric.ball (edgeCrossPoint (v i) (v (next i)) r 0) δ)
    (hxs : 0<edgeSide (v i) (v (next i)) x)
    (hys : edgeSide (v i) (v (next i)) y<0) :
    polygonIndexPhase next v x-polygonIndexPhase next v y=2*Real.pi := by
  let q := edgeCrossPoint (v i) (v (next i)) r
  have hoth : ∀ j, j≠i → q 0 ∉ segment ℝ (v j) (v (next j)) := by
    intro j hj
    exact Set.disjoint_left.mp (hother j hj) (Metric.mem_ball_self hδ)
  have hc : Continuous q := continuous_edgeCrossPoint _ _ _
  have hp : ∀ᶠ ε in 𝓝 (0:ℝ), q ε ∈ Metric.ball (q 0) δ :=
    hc.continuousAt.eventually (Metric.isOpen_ball.mem_nhds (Metric.mem_ball_self hδ))
  have hm : ∀ᶠ ε in 𝓝 (0:ℝ), q (-ε) ∈ Metric.ball (q 0) δ := by
    have h := (hc.comp continuous_neg).continuousAt (x := (0:ℝ))
    simpa only [Function.comp_def,neg_zero,Metric.mem_ball] using
      h.eventually (Metric.isOpen_ball.mem_nhds (show q (-(0:ℝ)) ∈ Metric.ball (q 0) δ by
        simpa only [neg_zero] using Metric.mem_ball_self hδ))
  have hall := (polygonIndexPhase_edge_jump next v i hne hr hoth).and
    ((hp.filter_mono nhdsWithin_le_nhds).and
      ((hm.filter_mono nhdsWithin_le_nhds).and self_mem_nhdsWithin))
  obtain ⟨ε,he,hp,hm,hε⟩ := hall.exists
  have hn : 0<Complex.normSq (v (next i)-v i) :=
    Complex.normSq_pos.mpr (sub_ne_zero.mpr hne.symm)
  have hleft : 0<edgeSide (v i) (v (next i)) (q ε) := by
    rw [edgeSide_crossPoint]
    exact mul_pos hε hn
  have hright : edgeSide (v i) (v (next i)) (q (-ε))<0 := by
    rw [edgeSide_crossPoint]
    exact mul_neg_of_neg_of_pos (neg_neg_of_pos hε) hn
  rw [polygonIndexPhase_eq_in_left_collar next v i (q 0) δ hother hx hp hxs hleft,
    polygonIndexPhase_eq_in_right_collar next v i (q 0) δ hother hy hm hys hright]
  exact he

end MonotoneMatching
