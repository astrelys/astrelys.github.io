# Planar matching under monotone pairwise angles

### Lean verification companion

**Author · Astrée Iriart**

**AIRP-V3ZR-2MYB-U2ZZ · Manuscript v3.1.0 · Package r1**

Machine-checked proofs of the paper's **Winding bound** and **Sharp rotational count** main theorems.

| Coverage | Proof environment | Verification |
| :--- | :--- | :--- |
| Two complete main theorem statements | Lean 4.34.0 | Build, axiom audit and fresh kernel replay |
| Canonical policy and all-source bounds included | Pinned mathlib and dependencies | 689 declarations |

## Verify

With Python 3, Git and [elan](https://github.com/leanprover/elan) installed, run from the extracted package directory:

```sh
elan toolchain install leanprover/lean4:v4.34.0
lake exe cache get
python3 scripts/verify.py --output ../verification-output
```

Success requires `full-recheck-passed`, `689` declarations and `2` main theorems in the final result. Allow several gigabytes for dependencies and caches and at least several minutes for checking. See the [Verification guide](docs/VERIFY.md).

## Read the evidence

| File | Purpose |
| :--- | :--- |
| [Paper identity](paper.json) | Exact manuscript version and reference PDF checksum |
| [Scope](docs/SCOPE.md) | Conclusions, hypotheses, proof routes and limits |
| [Claim map](claims.json) | Manuscript statements and checked declarations |
| [Declaration inventory](targets.json) | Included source signatures and locations |
| [Verification summary](verification-summary.json) | Mechanical result and reproduction limits |
| [Main theorems](MonotoneMatching/MainTheorems.lean) | Combined formal entry point |
| [Licensing notes](LICENSES/README.md) | Actual license status and dependency notice |

## Attribution

Astrée Iriart. *Planar matching under monotone pairwise angles*. AIRP-V3ZR-2MYB-U2ZZ, manuscript v3.1.0. Lean verification companion, r1.

The proofs and statement correspondence were developed with an AI assistant. Mechanical checking does not constitute independent human review, peer review, novelty assessment or authorship certification. The [paper page](https://astrelys.github.io/papers/AIRP-V3ZR-2MYB-U2ZZ/) identifies the reference manuscript.
