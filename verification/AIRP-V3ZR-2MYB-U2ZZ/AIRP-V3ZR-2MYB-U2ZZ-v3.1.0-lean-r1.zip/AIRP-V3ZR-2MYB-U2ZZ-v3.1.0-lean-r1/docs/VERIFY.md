# Verification guide

[Overview](../README.md) · [Scope](SCOPE.md)

## 1. Check the download

From the directory containing the ZIP and its sidecar:

```sh
sha256sum -c AIRP-V3ZR-2MYB-U2ZZ-v3.1.0-lean-r1.zip.sha256
# macOS:
shasum -a 256 -c AIRP-V3ZR-2MYB-U2ZZ-v3.1.0-lean-r1.zip.sha256
```

These checks detect changed bytes, not publisher identity. After extraction, `hashes.json` covers every payload file except itself; the verifier checks this closed inventory before running Lean. The reference PDF must match the SHA-256 in `paper.json`. The PDF itself is not bundled.

## 2. Prepare the environment

Install Python 3, Git and [elan](https://github.com/leanprover/elan). From the extracted package root:

```sh
elan toolchain install leanprover/lean4:v4.34.0
lake exe cache get
```

The toolchain is Lean 4.34.0, commit `293d5d0c0c3f3dded4688b3ccd6a33939ac5102b`. mathlib is pinned to `5ed2965256430c3649e86755f9576b54eca72435`. `dependency-lock.json` and `lake-manifest.json` list all public dependency repositories and exact commits. Do not run a dependency update or replace the pins.

Initial setup downloads the Lean toolchain, public dependency sources and mathlib's compiled cache. Allow several gigabytes of free disk space. No account, private repository or local project configuration is required. Dependency tools may contact their public download services; the verifier does not implement system-wide network isolation and does not upload package content.

## 3. Run the complete check

```sh
python3 scripts/verify.py --output ../verification-output
```

Choose a new output directory outside the package. The check verifies exact dependency commits and tracked-source cleanliness, builds the full import root, compiles every included module with warnings treated as errors, checks the complete declaration inventory and exact main target types, audits all transitive axioms, and runs `leanchecker --fresh`. It checks that the payload remains unchanged.

The final console result and `verification-output/result.json` must report `full-recheck-passed`, `689` declarations, and `2` main theorems. A successful build alone is insufficient. Fresh replay uses Lean's kernel implementation, not an independently implemented checker.

## 4. Interpret results

Command logs, the per-declaration axiom inventory and the final JSON result are written only to the chosen output directory. A nonzero exit, timeout, inventory mismatch, unexpected axiom, dependency change or missing final success result is a failed or incomplete check. Preserve that output, resolve the cause, and rerun into a new directory. Do not suppress errors, relax target statements or disable Python assertions.

Each command has a default 1,800-second limit. On a slower machine, use `--timeout 3600`; this changes only the time allowance. Runtime depends heavily on hardware and the dependency cache. Lean proof outputs are generated in `.lake`, which is not part of the distribution.

The recorded package check uses a fresh proof build in a separate extraction directory with pinned local dependency sources and compiled dependency caches reused. A first-time dependency download on a new machine was not tested. The test platform is macOS on ARM64; no successful test on another platform is claimed.
