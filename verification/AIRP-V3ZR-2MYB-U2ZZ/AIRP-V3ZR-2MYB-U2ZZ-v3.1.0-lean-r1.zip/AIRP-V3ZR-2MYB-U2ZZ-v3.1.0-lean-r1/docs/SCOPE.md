# Scope and interpretation

[Overview](../README.md) · [Verification guide](VERIFY.md)

## Mathematical coverage

The combined entry point is `MonotoneMatching.main_geometric_theorems`. It proves the two complete main geometric statements of manuscript v3.1.0. See `claims.json` for the exact declaration map and `targets.json` for every included declaration signature.

**Winding bound.** The source lists are arbitrary wherever the manuscript states an all-source conclusion. The motion consists of labeled, collision-free, periodic C1 trajectories with a positive period and nonpositive pairwise angular determinant. Continuous argument lifts define nonnegative integral pair windings. For an open dense source set, all optimal events are finite and transverse, involve exactly two optima differing by one cycle, and have the exact positive charges stated in the paper. Their sum is twice total pair winding, yielding the corrected event formula and bound.

Finite strict witnesses extend the unique-optimizer count to every source list. The canonical rule is exactly the source-coordinate lexicographic rule: original score first, then every target real/imaginary coordinate in standard order. Its image includes tie-point-only choices and has the same bound. At most `max(1,2W)` nonempty constant open cells span a full time circle. Original score optimality holds on their closures, whose integer translates cover every real time. Boundary canonical choices are not required to equal either neighboring cell label.

**Sharp rotational count.** For `n >= 2`, the universal bound is `n(n-1)` for arbitrary planar lists, including repeated labels. An explicit configuration attains it for every `n >= 2`. For `n >= 3`, attainment persists on a nonempty open set with both lists noncollinear. For one label, the count is one.

The plane is represented by complex numbers with real inner products. Maximizing assignment score is equivalent to minimizing total squared distance. The non-strict clockwise condition allows stationary angular intervals. No charge formula, finite bad set, count bound or canonical finiteness conclusion is supplied as an unproved assumption.

## Proof correspondence

The formal winding statement is the conjunction of its seven complete quantified conclusions. Lift and seam uniqueness identify the same physical winding integers across these components. Exact real half-plane phase transport and telescoping replace the manuscript's shrinking-bridge global accounting. Finite simultaneous strict realizations inject distinct canonical bad points into distinct actual optimal events; local constancy and score continuity then prove the cell and closure conclusions directly.

These alternative arguments prove the stated main conclusions. They do not separately certify the manuscript's literal bridge construction, canonical interval-charge construction or standalone no-isolated-spike proposition. Those auxiliary assertions are not premises of the formal main statements. This companion is not a line-by-line transcription of every proof step.

## Trust and review

All included definitions and theorems are audited. The permitted transitive axioms are `propext`, `Classical.choice` and `Quot.sound`. No admitted proof, custom axiom or native trust axiom is accepted. A checked definition of a proposition is not counted as its proof; the checked main theorem declarations have those exact proposition types.

Fresh replay uses the same Lean kernel implementation. Statement correspondence was reviewed by the generating assistant and has not received independent human mathematical review. A public author attribution does not constitute machine certification of authorship.

## Exclusions

This package does not certify algorithmic complexity, Fourier registration implementations, weighted extensions, unrelated corollaries, unrestricted smooth-oracle effectiveness, or every auxiliary proposition in the manuscript. Dependency source trees, caches, binaries and the manuscript are not bundled. See `exclusions.json`.

Mechanical checking does not establish originality, priority or peer review. Completion of the two named main statements is not a whole-paper correctness verdict or evidence of public publication of this companion.
