#!/usr/bin/env python3
"""Verify the complete declared Lean proof package and write evidence outside it.
No package content is uploaded. Dependency setup is a separate documented step.
"""
from pathlib import Path, PurePosixPath
import argparse
import datetime
import hashlib
import json
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
ALLOWED_AXIOMS = {'propext', 'Classical.choice', 'Quot.sound'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def payload_hashes():
    recorded = json.loads((ROOT / 'hashes.json').read_text())
    for name, digest in recorded.items():
        parts = PurePosixPath(name)
        if parts.is_absolute() or any(p in ('', '.', '..') for p in parts.parts):
            raise ValueError('unsafe inventory path')
        path = ROOT / name
        if path.is_symlink() or not path.is_file() or sha(path) != digest:
            raise ValueError('payload mismatch: ' + name)
    actual = set()
    for path in ROOT.rglob('*'):
        name = path.relative_to(ROOT).as_posix()
        if name == '.lake' or name.startswith('.lake/'):
            continue
        if path.is_symlink():
            raise ValueError('unexpected payload symlink: ' + name)
        if path.is_file():
            actual.add(name)
    if actual != set(recorded) | {'hashes.json'}:
        raise ValueError('payload inventory is not closed')
    return {name: sha(ROOT / name) for name in sorted(actual)}


def main():
    if not __debug__:
        raise SystemExit('Run Python without -O; all verification checks must remain enabled.')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path,
                        help='new evidence directory outside the extracted package')
    parser.add_argument('--timeout', type=int, default=1800,
                        help='seconds allowed for each command; default 1800')
    args = parser.parse_args()
    out = args.output.resolve()
    if out == ROOT or ROOT in out.parents or args.timeout <= 0:
        raise SystemExit('Use a new output directory outside the package and a positive timeout.')
    before = payload_hashes()
    out.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    report = {'result': 'in-progress', 'mode': 'full', 'commands': [],
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'payload_sha256': before,
              'checker_boundary': 'Fresh replay using the same Lean kernel implementation'}

    def save():
        (out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')

    def run(label, argv):
        start = time.monotonic()
        with (out / (label + '.log')).open('w') as log:
            try:
                code = subprocess.run(argv, cwd=ROOT, stdout=log,
                                      stderr=subprocess.STDOUT, timeout=args.timeout).returncode
            except subprocess.TimeoutExpired:
                code = 124
        report['commands'].append({'label': label, 'argv': argv, 'exit_code': code,
                                   'elapsed_seconds': round(time.monotonic() - start, 3),
                                   'log_sha256': sha(out / (label + '.log'))})
        save()
        if code:
            raise RuntimeError('failed command: ' + label)
        return (out / (label + '.log')).read_text()

    try:
        lock = json.loads((ROOT / 'dependency-lock.json').read_text())
        assert (ROOT / 'lean-toolchain').read_text().strip() == lock['lean_toolchain']
        version = run('lean-version', ['lake', 'env', 'lean', '--version'])
        assert lock['lean_version'] in version and lock['lean_commit'][:7] in version
        manifest = json.loads((ROOT / 'lake-manifest.json').read_text())
        assert all(p['type'] == 'git' for p in manifest['packages'])
        assert {(p['name'], p['url'], p['rev']) for p in manifest['packages']} == {
            (p['name'], p['url'], p['rev']) for p in lock['packages']}
        for package in lock['packages']:
            dep = ROOT / '.lake' / 'packages' / package['name']
            commit = subprocess.check_output(['git', '-C', str(dep), 'rev-parse', 'HEAD'], text=True).strip()
            assert commit == package['rev'], 'dependency revision mismatch: ' + package['name']
            status = subprocess.check_output(['git', '-C', str(dep), 'status', '--porcelain',
                                              '--untracked-files=no'], text=True).strip()
            assert not status, 'modified dependency: ' + package['name']
        sources = sorted((ROOT / 'MonotoneMatching').glob('*.lean'))
        parsed = []
        for module in sources:
            for kind, name in re.findall(r'^(?:@\[[^\]]*\]\s*)?(theorem|def)\s+(\w+)',
                                         module.read_text(), re.MULTILINE):
                parsed.append({'name': 'MonotoneMatching.' + name, 'kind': kind,
                               'source': module.relative_to(ROOT).as_posix()})
        targets = json.loads((ROOT / 'targets.json').read_text())
        assert parsed == [{key: row[key] for key in ('name', 'kind', 'source')} for row in targets]
        names = [row['name'] for row in parsed]
        assert len(names) == len(set(names))
        assert (ROOT / 'MonotoneMatching.lean').read_text() == ''.join(
            'import MonotoneMatching.' + p.stem + '\n' for p in sources)
        assert (ROOT / 'Audit.lean').read_text() == 'import MonotoneMatching\n\n' + ''.join(
            '#print axioms ' + name + '\n#print ' + name + '\n' for name in names)
        run('build', ['lake', 'build', 'MonotoneMatching'])
        for module in sources:
            run('strict-' + module.stem, ['lake', 'env', 'lean', '-DwarningAsError=true',
                                        module.relative_to(ROOT).as_posix()])
        audit = run('axioms-and-statements', ['lake', 'env', 'lean', '-DwarningAsError=true', 'Audit.lean'])
        axioms = {}
        for name, deps in re.findall(r"^'([^\n]+)' depends on axioms: \[([^\]]*)\]", audit, re.MULTILINE):
            axioms[name] = [x.strip() for x in deps.split(',') if x.strip()]
        for name in re.findall(r"^'([^\n]+)' does not depend on any axioms", audit, re.MULTILINE):
            axioms[name] = []
        assert set(axioms) == set(names)
        assert all(set(value) <= ALLOWED_AXIOMS for value in axioms.values())
        assert axioms == json.loads((ROOT / 'axioms.json').read_text())
        for claim in json.loads((ROOT / 'claims.json').read_text())['checked_targets']:
            name, statement = claim['declaration'], claim['statement']
            assert re.search(r'^theorem ' + re.escape(name) + r'\s*:\s*' +
                             re.escape(statement) + r'\s*:=', audit, re.MULTILINE), name
        (out / 'axioms.json').write_text(json.dumps(axioms, indent=2) + '\n')
        run('fresh-kernel-replay', ['lake', 'env', 'leanchecker', '--fresh', '--verbose', 'MonotoneMatching'])
        assert payload_hashes() == before, 'payload changed during verification'
        report.update(result='full-recheck-passed', declaration_count=len(names),
                      main_theorems_verified=2, whole_paper_verified=False,
                      source_inventory_complete=True, source_unchanged=True,
                      elapsed_seconds=round(time.monotonic() - started, 3),
                      finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    except Exception as exc:
        report.update(result='failed', error=str(exc))
        raise
    finally:
        save()
    print(json.dumps({'result': report['result'], 'declaration_count': report['declaration_count'],
                      'main_theorems_verified': report['main_theorems_verified']}))


if __name__ == '__main__':
    main()
