"""Exact, independent audit of the four-port dilution boundary.

The 5x5 evaluation test certifies identities because both displayed sides
are separately of degree at most four. It is not a numerical grid test.
No dependencies beyond the Python standard library; no project imports.
"""
from fractions import Fraction as F
from itertools import product
import json

class Z:
    def __init__(self,a=0,b=0): self.a,self.b=F(a),F(b)
    def __add__(self,o):
        o=toZ(o); return Z(self.a+o.a,self.b+o.b)
    __radd__=__add__
    def __neg__(self): return Z(-self.a,-self.b)
    def __sub__(self,o): return self+-toZ(o)
    def __rsub__(self,o): return toZ(o)+-self
    def __mul__(self,o):
        o=toZ(o)
        return Z(self.a*o.a+2*self.b*o.b,self.a*o.b+self.b*o.a)
    __rmul__=__mul__
    def __truediv__(self,o): return Z(self.a/F(o),self.b/F(o))
    def __pow__(self,n):
        ans=Z(1)
        for _ in range(n): ans=ans*self
        return ans
    def __eq__(self,o):
        o=toZ(o); return self.a==o.a and self.b==o.b

def toZ(o): return o if isinstance(o,Z) else Z(o)
r=Z(0,1); c=(r-1)/2; k=(3+2*r)/16; m=(6+7*r)/16; n=7*r/8

def Q(alpha,beta,R,S,u):
    t=alpha+beta+u
    return (-u*(t-1)*(t-2)*(t-3)
        +(R+S+F(3,4)*alpha*beta)*(t-2)*(t-3)
        -F(9,2)*(R*beta+S*alpha)*(t-3)+12*R*S)

def ep(a,kind): return a-1 if kind==0 else a*a/4

def bound(x,y,i,j):
    if (i,j)==(1,0): return bound(y,x,0,1)
    FE=lambda z:(6+7*r/2)*z*z+F(3,8)*z**3+k*z**4
    FB=lambda z:(17*r/2-F(5,4))*z*z+(F(5,8)+3*r/4)*z**3
    d=3+27*r/8; e=(51*r-7)/8
    cs={(0,0):(d,d,k,k,0),(0,1):(d,e,k,m,m),(1,1):(e,e,m,m,n)}[i,j]
    exps=((2,1),(1,2),(3,1),(1,3),(2,2))
    return (18*r-14+(53*r/2-17)*(x+y)+(53*r/2-15)*x*y
        +(FE if not i else FB)(x)+(FE if not j else FB)(y)
        +sum(v*x**a*y**b for v,(a,b) in zip(cs,exps)))

checks=0
for i,j in product(range(2),repeat=2):
    for x,y in product(map(F,range(5)),repeat=2):
        a,b=x+2,y+2
        assert -Q(a,b,ep(a,i),ep(b,j),c*(a+b))==bound(x,y,i,j)
        checks+=1
for h in map(lambda z:F(z,4),range(5)):
    g=1-h
    expected=(-k*(h**3+g**3),-h*(k*h*h+m*g*g),
        -g*(k*g*g+m*h*h),-h*g*(m-F(3,4)*h*g))
    for (rho,sigma),rhs in zip(((0,0),(0,g*g/4),(h*h/4,0),(h*h/4,g*g/4)),expected):
        got=(-c*(1+c)**3+(rho+sigma+F(3,4)*h*g)*(1+c)**2
            -F(9,2)*(rho*g+sigma*h)*(1+c)+12*rho*sigma)
        assert got==rhs
for u in range(5):
    assert Q(F(12),F(21),F(32),F(110),F(u))==(3-u)*(u**3+96*u*u+2839*u+27050)

def fourQ(a,b,d,e,u):
    al=a+b; be=d+e; t=al+be+u; R=a*b; S=d*e
    return (-4*u*(t-1)*(t-2)*(t-3)
        +(4*R+4*S+3*al*be)*(t-2)*(t-3)
        -18*(R*be+S*al)*(t-3)+48*R*S)

zeros=[]; count=0
for L in range(4,37):
    for a in range(1,L-2):
        for b in range(1,L-a-1):
            for d in range(1,L-a-b):
                e=L-a-b-d; count+=1; lo=0; hi=(L+1)//2
                assert fourQ(a,b,d,e,lo)>0 and fourQ(a,b,d,e,hi)<0
                while hi-lo>1:
                    mid=(lo+hi)//2
                    if fourQ(a,b,d,e,mid)>=0: lo=mid
                    else: hi=mid
                if fourQ(a,b,d,e,lo)==0: zeros.append((a,b,d,e,lo))
canon=sorted(set(tuple(sum(sorted([sorted(z[:2]),sorted(z[2:4])]),[]))+z[4:] for z in zeros))
assert count==58905 and canon==[(2,14,3,15,4),(4,8,10,11,3)]
assert min(sum(z[:4]) for z in zeros)==33
assert min(12+sum(z) for z in zeros)==48
print(json.dumps({'status':'PASS','exact_bound_identity_evaluations':checks,
    'limiting_corner_identity_evaluations':20,'factor_identity_evaluations':5,
    'ordered_quadruples':count,'ordered_zeros':len(zeros),
    'zero_representatives':canon,'minimum_L':33,'minimum_order':48,
    'identity_certificate':'known bidegree at most four plus exact 5x5 interpolation, not approximate sampling'}))
