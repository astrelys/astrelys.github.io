"""Reconstruct all sixteen core coefficients without Kostka recursion."""
from itertools import combinations,permutations
from functools import lru_cache
from collections import Counter
from math import factorial
import json
edges=((0,1),(0,3),(0,4),(0,5),(1,2),(2,3),(2,6),(2,7),(1,8),(3,9),(4,5),(6,7))
base={(i,j) for i,j in combinations(range(12),2) if set(edges[i])&set(edges[j])}
ports=(8,9,10,11)
terms=Counter()
for p in permutations(range(4)):
    mu=tuple(3+p[i]-i for i in range(4))
    if min(mu)<0: continue
    inv=sum(p[i]>p[j] for i,j in combinations(range(4),2))
    terms[tuple(sorted((v for v in mu if v),reverse=True))]+=(-1)**inv
terms={mu:s for mu,s in terms.items() if s}
records=[]
for mask in range(16):
    adj=[set() for _ in range(12)]
    selected=[ports[i] for i in range(4) if mask>>i&1]
    for i,j in base|set(combinations(selected,2)):
        adj[i].add(j); adj[j].add(i)
    ind=[]
    for m in range(1,4096):
        vs=[i for i in range(12) if m>>i&1]
        if all(j not in adj[i] for i,j in combinations(vs,2)): ind.append(m)
    by=[[m for m in ind if m>>i&1] for i in range(12)]
    @lru_cache(None)
    def count(rem):
        if not rem: return {():1}
        v=(rem&-rem).bit_length()-1; out=Counter()
        for I in by[v]:
            if I&rem!=I: continue
            for shape,w in count(rem^I).items():
                out[tuple(sorted(shape+(bin(I).count('1'),),reverse=True))]+=w
        return dict(out)
    counts=count(4095); h=0
    for mu,sign in terms.items():
        multi=1
        for n in Counter(mu).values(): multi*=factorial(n)
        h+=sign*counts.get(mu,0)*multi
    k=bin(mask).count('1')
    expected=48 if k==2 and mask not in (3,12) else {0:-64,1:-64,2:64,3:288,4:768}[k]
    assert h==expected
    records.append({'mask':mask,'coefficient':h,'stable_partitions':sum(counts.values())})
print(json.dumps({'status':'PASS',
    'method':'independent stable partition enumeration + direct 4x4 Jacobi Trudi determinant; no Kostka recursion',
    'determinant_profiles':len(terms),'records':records}))
