# Reproducible full four-port classification certificate.
# Preserved source program; uses standard-library exact integer/Fraction arithmetic.
from itertools import combinations, product, permutations
from functools import lru_cache
from collections import Counter
from fractions import Fraction as F
from math import factorial
import time
ROOT=((0,1),(0,3),(0,4),(0,5),(1,2),(2,3),(2,6),(2,7),(1,8),(3,9),(4,5),(6,7))
PORTS=(8,9,10,11)
G=[0]*12
def edge(adj,i,j):
 adj[i]|=1<<j;adj[j]|=1<<i
for i,j in combinations(range(12),2):
 if set(ROOT[i])&set(ROOT[j]):edge(G,i,j)
def pc(x):return bin(x).count("1")
def parts(n,cap=None):
 if not n:yield ();return
 for a in range(min(n,n if cap is None else cap),0,-1):
  for r in parts(n-a,a):yield (a,)+r
def dom(a,b):
 x=y=0
 for i in range(max(len(a),len(b))):
  x+=a[i] if i<len(a) else 0;y+=b[i] if i<len(b) else 0
  if x<y:return False
 return True
@lru_cache(None)
def strips(lam,r):
 lo=lam[1:]+(0,)
 return tuple(tuple(x for x in nu if x) for nu in product(*(range(lo[i],lam[i]+1) for i in range(len(lam)))) if sum(lam)-sum(nu)==r)
@lru_cache(None)
def K(lam,mu):
 if not mu:return int(not lam)
 if sum(lam)!=sum(mu) or not dom(lam,mu):return 0
 if len(mu)==1:return int(lam==mu)
 return sum(K(nu,mu[:-1]) for nu in strips(lam,mu[-1]))
def maskdata(adj):
 n=len(adj);ind=[True]*(1<<n);by=[[] for _ in adj]
 for m in range(1,1<<n):
  bit=m&-m;v=bit.bit_length()-1;r=m^bit;ind[m]=ind[r] and not(adj[v]&r)
  if ind[m]:
   for w in range(n):
    if m>>w&1:by[w].append(m)
 return by
BY=maskdata(G)
def coretable(selected):
 selected_mask=sum(1<<PORTS[i] for i in range(4) if selected>>i&1)
 @lru_cache(None)
 def go(mask):
  if not mask:return {((),0):1}
  anchor=(mask&-mask).bit_length()-1;out=Counter()
  for I in BY[anchor]:
   if I&mask!=I:continue
   hits=pc(I&selected_mask)
   if hits>1:continue
   for(beta,r),c in go(mask^I).items():
    if not hits:
     key=tuple(sorted(beta+(pc(I),),reverse=True)) if pc(I)>1 else beta
     out[key,r]+=c
    key=tuple(sorted(beta+(pc(I)+1,),reverse=True));out[key,r+1]+=c
  return dict(out)
 out=go(4095);go.cache_clear();return out
CORE={S:coretable(S) for S in range(16)}
def falling(n,r):
 out=1
 for h in range(r):out*=n-h
 return out
def transfer(sizes):
 t=sum(sizes);out=Counter()
 for S,table in CORE.items():
  k=pc(S);weight=(-1)**k
  for i in range(4):
   if S>>i&1:weight*=sizes[i]
  if not weight:continue
  for(beta,r),c in table.items():
   if r<=t:out[beta+(1,)*(12+t-sum(beta))]+=weight*c*falling(t-k,r-k)
 assert all(c>=0 for c in out.values())
 return {lam:c for lam,c in out.items() if c}
T=[nu for d in range(13) for nu in parts(d) if(not nu or nu[0]<=4) and sum(nu[:3])<=10]
def jj(nu):return 12-sum(nu)
def shape(nu,t):return tuple(x+1 for x in nu)+(1,)*(t+jj(nu)-len(nu))
T.sort(key=lambda nu:shape(nu,12),reverse=True)
TARGET=(3,3,3,3)
def mono(N,lam):
 c=N.get(lam,0)
 for r in Counter(lam).values():c*=factorial(r)
 return c
def schur(N,t):
 shapes=list(parts(12+t)) if t<12 else[shape(nu,t) for nu in T]
 out={};active=[]
 for lam in shapes:
  c=mono(N,lam)-sum(out[nu]*K(nu,lam) for nu in active)
  out[lam]=c
  if c:active.append(lam)
 return out
def Q(sizes):
 x,y,z,w,u=sizes;t=sum(sizes);e1=x+y+z+w
 e2=x*y+z*w+F(3,4)*(x+y)*(z+w)
 e3=x*y*z+x*y*w+x*z*w+y*z*w
 return (-t*(t-1)*(t-2)*(t-3)+e1*(t-1)*(t-2)*(t-3)
         +e2*(t-2)*(t-3)-F(9,2)*e3*(t-3)+12*x*y*z*w)
def imbalance(a,b,u):return(a,a,b,b+1,u)
def gc(d,c):return {(0,)*d:F(c)} if c else {}
def ga(p,q,c=1):
 out=dict(p)
 for I,v in q.items():out[I]=out.get(I,0)+c*v
 return {I:F(v) for I,v in out.items() if v}
def gs(p,c):return {I:F(v*c) for I,v in p.items() if v*c}
def gm(p,q):
 out=Counter()
 for I,v in p.items():
  for J,w in q.items():out[tuple(i+j for i,j in zip(I,J))]+=v*w
 return {I:F(v) for I,v in out.items() if v}
def variable(d,i):
 I=[0]*d;I[i]=1;return {tuple(I):F(1)}
def gp(p,n,d):
 out=gc(d,1)
 for _ in range(n):out=gm(out,p)
 return out
def gv(p,xs):
 out=F(0)
 for I,c in p.items():
  for x,i in zip(xs,I):c*=x**i
  out+=c
 return out
def gsub(p,images,d):
 powers=[]
 for axis,im in enumerate(images):
  mx=max((I[axis] for I in p),default=0);ps=[gc(d,1)]
  for _ in range(mx):ps.append(gm(ps[-1],im))
  powers.append(ps)
 out={}
 for I,c in p.items():
  term=gc(d,c)
  for axis,n in enumerate(I):term=gm(term,powers[axis][n])
  out=ga(out,term)
 return out
def interpolated(values):
 row=list(map(F,values));out={};fall=gc(1,1);x=variable(1,0)
 for r in range(len(values)):
  out=ga(out,gs(fall,row[0]/factorial(r)))
  fall=gm(fall,ga(x,gc(1,-r)))
  row=[row[i+1]-row[i] for i in range(len(row)-1)]
 return out
KP={}
start=time.time()
for i,nu in enumerate(T):
 for eta in T[i+1:]:
  if not dom(shape(nu,12),shape(eta,12)):continue
  delta=jj(eta)-jj(nu);assert delta>=0
  kp=interpolated([K(shape(nu,12+r),shape(eta,12+r)) for r in range(delta+1)])
  assert gv(kp,(delta+1,))==K(shape(nu,13+delta),shape(eta,13+delta))
  KP[nu,eta]=kp
print("KOSTKA_PASS",len(T),len(KP),round(time.time()-start,2),flush=True)
d=5;Z=variable(d,4);TT=ga(Z,gc(d,12))
FALL={}
for k in range(5):
 f=gc(d,1)
 for r in range(13-k):
  FALL[k,r]=f;f=gm(f,ga(TT,gc(d,-k-r)))
UN={nu:{} for nu in T}
betas={tuple(v+1 for v in nu):nu for nu in T}
for S,table in CORE.items():
 k=pc(S);weight=gc(d,(-1)**k)
 for i in range(4):
  if S>>i&1:weight=gm(weight,variable(d,i))
 for(beta,r),c in table.items():
  nu=betas[beta];UN[nu]=ga(UN[nu],gs(gm(weight,FALL[k,r-k]),c))
UK={key:{(0,0,0,0,I[0]):c for I,c in p.items()} for key,p in KP.items()}
UB={};UA={}
start=time.time()
for i,nu in enumerate(T):
 p=UN[nu]
 for c in Counter(v+1 for v in nu).values():p=gs(p,factorial(c))
 for h in range(1,13+jj(nu)-len(nu)):p=gm(p,ga(Z,gc(d,h)))
 UB[nu]=p
 for prev in T[:i]:
  if(prev,nu) in UK:p=ga(p,gm(UA[prev],UK[prev,nu]),-1)
 UA[nu]=p
 if i%40==0:print("UNIVERSAL_INVERSION",i,round(time.time()-start,2),flush=True)
for nu in T:
 p=UA[nu]
 for prev in T:
  if(prev,nu) in UK:p=ga(p,gm(UA[prev],UK[prev,nu]))
 assert p==UB[nu]
assert all(all(v<=1 for v in I[:4]) for p in UA.values() for I in p)
print("UNIVERSAL_POLYNOMIAL_PASS",sum(len(p) for p in UA.values()),max(I[4] for p in UA.values() for I in p),round(time.time()-start,2),flush=True)
def perm_poly(p,perm):
 return {tuple(I[i] for i in perm):c for I,c in p.items()}
def stats(ap,d):
 keep=[p for nu,p in ap.items() if nu!=TARGET]
 bad=[nu for nu,p in ap.items() if nu!=TARGET and any(c<0 for c in p.values())]
 print("CERT_STATS",d,"bad",bad,"terms",sum(len(p) for p in keep),
       "min_coeff",min(c for p in keep for c in p.values()),
       "min_const",min(p.get((0,)*d,0) for p in keep),flush=True)
 return bad
def endpoint(L,kind,d):
 return (gc(d,1),ga(L,gc(d,-1))) if kind==0 else(gs(L,F(1,2)),gs(L,F(1,2)))
EA={}
EC={}
for kind1,kind2 in product(range(2),repeat=2):
 d=3;alpha=ga(variable(d,0),gc(d,6));beta=ga(variable(d,1),gc(d,6))
 images=endpoint(alpha,kind1,d)+endpoint(beta,kind2,d)+(variable(d,2),)
 start=time.time();raw={nu:gsub(p,images,d) for nu,p in UA.items()}
 EA[kind1,kind2]=raw
 z=ga(ga(variable(d,0),variable(d,1)),variable(d,2))
 physical=(variable(d,0),variable(d,1),z)
 ap={nu:gsub(p,physical,d) for nu,p in raw.items()}
 bad=stats(ap,d)
 EC[kind1,kind2]=ap
 print("ENDPOINT_INTERIOR",kind1,kind2,"bad",len(bad),"seconds",round(time.time()-start,2),flush=True)
ENDCERT={};CERTSUMMARY={}
for kinds,raw in EA.items():
 family=[]
 ap=EC[kinds]
 assert not stats(ap,3)
 assert all(p.get((0,0,0),0)>0 for nu,p in ap.items() if nu!=TARGET)
 family.append(("interior",ap,3))
 for side,r in product(range(2),range(2,6)):
  fixed=gc(2,r-6);moving=ga(variable(2,0),gc(2,6-r))
  A,B=(fixed,moving) if side==0 else(moving,fixed)
  z=ga(variable(2,0),variable(2,1))
  ap={nu:gsub(p,(A,B,z),2) for nu,p in raw.items()}
  assert all(p.get((0,0),0)>0 and all(c>0 for c in p.values()) for nu,p in ap.items() if nu!=TARGET)
  family.append((("boundary",side,r),ap,2))
 for alpha in range(2,10):
  for beta in range(2,12-alpha):
   ap={nu:gsub(p,(gc(1,alpha-6),gc(1,beta-6),variable(1,0)),1) for nu,p in raw.items()}
   assert all(p.get((0,),0)>0 and all(c>0 for c in p.values()) for nu,p in ap.items() if nu!=TARGET)
   family.append((("ray",alpha,beta),ap,1))
 assert len(family)==45
 ENDCERT[kinds]=family
 total=sum(len(p) for _,ap,_ in family for nu,p in ap.items() if nu!=TARGET)
 minc=min(c for _,ap,_ in family for nu,p in ap.items() if nu!=TARGET for c in p.values())
 const=min(p[(0,)*d] for _,ap,d in family for nu,p in ap.items() if nu!=TARGET)
 CERTSUMMARY[kinds]=(total,minc,const)
 print("GENERAL_ENDPOINT_COVER_PASS",kinds,len(family),total,minc,const,flush=True)
GF={};zero_small=[]
start=time.time()
for xs in product(range(1,9),repeat=4):
 L=sum(xs)
 if L>=12:continue
 for u in range(12-L):
  sizes=xs+(u,);t=L+u;N=transfer(sizes);SS=schur(N,t);target=(4,)*4+(1,)*(t-4)
  assert SS[target]==64*factorial(t-4)*Q(sizes)
  assert [lam for lam,c in SS.items() if c<0]==([target] if Q(sizes)<0 else[])
  if Q(sizes)==0:zero_small.append(sizes)
  GF[sizes]=SS[target]
  if len(GF)%100==0:print("SMALL_GENERAL_PROGRESS",len(GF),round(time.time()-start,2),flush=True)
assert len(GF)==792
print("GENERAL_FOUR_GROUP_FINITE_PASS",len(GF),"zeros",zero_small,round(time.time()-start,2),flush=True)
print("FULL_ASYMMETRIC_CLASSIFICATION_PASS",len(ENDCERT)*45,4*45*151,sum(x[0] for x in CERTSUMMARY.values()),len(GF),flush=True)
def qq(xs,u,d):
 x,y,z,w=xs;tt=gc(d,0)
 for v in xs:tt=ga(tt,v)
 tt=ga(tt,u);t1=ga(tt,gc(d,-1));t2=ga(tt,gc(d,-2));t3=ga(tt,gc(d,-3))
 e2=ga(ga(gm(x,y),gm(z,w)),gs(gm(ga(x,y),ga(z,w)),F(3,4)))
 e3=ga(gm(gm(x,y),ga(z,w)),gm(gm(z,w),ga(x,y)))
 e4=gm(gm(x,y),gm(z,w))
 return ga(ga(gs(gm(gm(gm(u,t1),t2),t3),-1),gm(e2,gm(t2,t3))),ga(gs(gm(e3,t3),-F(9,2)),gs(e4,12)))
vs=tuple(variable(5,i) for i in range(4));sumvs={}
for v in vs:sumvs=ga(sumvs,v)
uformal=ga(TT,sumvs,-1)
expected=gs(qq(vs,uformal,5),64)
for h in range(1,9):expected=gm(expected,ga(Z,gc(5,h)))
assert expected==UA[TARGET]
print("UNIVERSAL_TARGET_IDENTITY_PASS",flush=True)
for perm in [(1,0,2,3,4),(0,1,3,2,4)]:
 assert all(perm_poly(p,perm)==p for p in UA.values())
print("WITHIN_PAIR_SYMMETRY_PASS",304,flush=True)
def grouped(sizes):
 @lru_cache(None)
 def go(mask,c):
  if not mask:return {():1}
  anchor=(mask&-mask).bit_length()-1;out=Counter()
  for I in BY[anchor]:
   if I&mask!=I:continue
   z=pc(I)
   for beta,w in go(mask^I,c).items():
    key=tuple(sorted(beta+(z,),reverse=True)) if z>1 else beta;out[key]+=w
   for g,num in enumerate(c):
    if not num or(g<4 and I>>PORTS[g]&1):continue
    cc=list(c);cc[g]-=1
    for beta,w in go(mask^I,tuple(cc)).items():
     key=tuple(sorted(beta+(z+1,),reverse=True));out[key]+=num*w
  return dict(out)
 n=12+sum(sizes);raw=go(4095,tuple(sizes));go.cache_clear()
 return {beta+(1,)*(n-sum(beta)):w for beta,w in raw.items()}
POINTS=[(1,1,1,1,8),(1,2,3,4,2),(2,1,4,3,3),(3,3,3,3,0),(1,9,1,2,0),(5,1,2,7,5),(2,3,1,6,7),(4,5,6,7,9),(1,20,3,2,1),(16,1,1,2,8),(1,1,1,1,0),(1,2,1,1,1)]
for sizes in POINTS:
 t=sum(sizes);N=transfer(sizes);assert grouped(sizes)==N
 SS=schur(N,t);target=(4,)*4+(1,)*(t-4)
 assert SS[target]==64*factorial(t-4)*Q(sizes)
 if t<12:continue
 xs=sizes[:4]+(t-12,)
 alpha=sum(sizes[:2]);beta=sum(sizes[2:4]);r=sizes[0]*sizes[1];q=sizes[2]*sizes[3]
 rho=F(0) if alpha==2 else F(r-alpha+1,F(alpha*alpha,4)-alpha+1)
 sigma=F(0) if beta==2 else F(q-beta+1,F(beta*beta,4)-beta+1)
 for nu in T:
  lam=shape(nu,t)
  assert gv(UN[nu],xs)==N.get(lam,0)
  assert gv(UB[nu],xs)*factorial(t-12)==mono(N,lam)
  assert gv(UA[nu],xs)*factorial(t-12)==SS[lam]
  v=0
  for(i,j),p in EA.items():
   v+=(rho if i else 1-rho)*(sigma if j else 1-sigma)*gv(p[nu],(alpha-6,beta-6,t-12))
  assert v==gv(UA[nu],xs)
print("DIRECT_GROUPED_AND_POLYNOMIAL_PASS",len(POINTS),flush=True)
def fullgraph(sizes):
 t=sum(sizes);adj=G[:]+[0]*t
 for i,j in combinations(range(12,12+t),2):edge(adj,i,j)
 pos=12
 for g,c in enumerate(sizes):
  if g<4:
   for v in range(pos,pos+c):edge(adj,PORTS[g],v)
  pos+=c
 return adj
def direct(adj):
 by=maskdata(adj);n=len(adj)
 @lru_cache(None)
 def go(mask):
  if not mask:return {():1}
  v=(mask&-mask).bit_length()-1;out=Counter()
  for I in by[v]:
   if I&mask!=I:continue
   z=pc(I)
   for beta,c in go(mask^I).items():
    key=tuple(sorted(beta+(z,),reverse=True)) if z>1 else beta;out[key]+=c
  return dict(out)
 raw=go((1<<n)-1);go.cache_clear()
 return {beta+(1,)*(n-sum(beta)):c for beta,c in raw.items()}
for sizes in[(1,1,1,1,2),(1,2,1,1,1)]:
 N=direct(fullgraph(sizes));assert N==grouped(sizes)==transfer(sizes)
 print("FULL_VERTEX_18_PASS",sizes,len(N),sum(N.values()),flush=True)
def cell_kostka(lam,mu):
 cells=[(i,j) for j in range(lam[0]) for i,row in enumerate(lam) if row>j]
 grid={};left=list(mu)
 def go(k):
  if k==len(cells):return 1
  i,j=cells[k];lower=max(grid.get((i,j-1),0),grid.get((i-1,j),0)+1)
  out=0
  upper=len(mu)-sum(row>j for row in lam[i+1:])
  for color in range(lower,upper+1):
   if not left[color-1]:continue
   left[color-1]-=1;grid[i,j]=color;out+=go(k+1);left[color-1]+=1
  grid.pop((i,j),None);return out
 return go(0)
controls=[]
for(nu,eta),p in KP.items():
 c=gv(p,(0,))
 if 0<c<=30:controls.append((nu,eta,int(c)))
controls=controls[::max(1,len(controls)//100)][:100]
for nu,eta,c in controls:assert cell_kostka(shape(nu,12),shape(eta,12))==c
print("CELL_TABLEAU_KOSTKA_PASS",len(controls),flush=True)
def hook(lam):
 out=1
 for i,row in enumerate(lam):
  for j in range(row):out*=row-j+sum(v>j for v in lam[i+1:])
 return out
for t in (12,17,32,65):
 for nu in T:
  lam=shape(nu,t);assert K(lam,(1,)*sum(lam))==factorial(sum(lam))//hook(lam)
print("HOOK_CONTROLS_PASS",608,flush=True)
colors=set(range(4));CS={}
for mask in range(16):
 selected=[i for i in range(4) if mask>>i&1];counts=Counter()
 for c in permutations(range(4)):
  if c[0]==0 or c[1]==1:continue
  allowed=(colors-{0,c[0]},colors-{1,c[1]},{0,1},{c[0],c[1]})
  for ports in product(*allowed):
   if len({ports[i] for i in selected})<len(selected):continue
   counts[tuple(sorted(Counter((0,1,2,3)+c+ports).values(),reverse=True))]+=1
 h=24*counts[(3,3,3,3)]-6*counts[(4,3,3,2)]+4*counts[(4,4,2,2)]
 k=pc(mask);assert h==(48 if k==2 and mask not in(3,12) else{0:-64,1:-64,2:64,3:288,4:768}[k])
 CS[mask]=h
print("PORT_COMPLETION_PASS",16,flush=True)
a=variable(2,0);b=variable(2,1)
def HE(v):return ga(ga(gs(v,F(1,2)),gs(gp(v,2,2),-1)),gs(gp(v,3,2),F(5,2)))
def HB(v):return ga(ga(gs(v,F(1,2)),gs(gp(v,2,2),F(1,4))),ga(gp(v,3,2),gs(gp(v,4,2),F(1,4))))
cross_exponents=((1,1),(2,1),(1,2),(3,1),(1,3),(2,2))
cross_coefficients={
 (0,0):(F(5,2),F(3,4),F(3,4),F(3,4),F(3,4),F(3,2)),
 (0,1):(F(5,2),F(3,4),F(9,8),F(3,4),F(1,8),F(5,8)),
 (1,0):(F(5,2),F(9,8),F(3,4),F(1,8),F(3,4),F(5,8)),
 (1,1):(F(5,2),F(9,8),F(9,8),F(1,8),F(1,8),F(1,2))
}
for kinds,cs in cross_coefficients.items():
 alpha=ga(a,gc(2,2));beta=ga(b,gc(2,2))
 xs=endpoint(alpha,kinds[0],2)+endpoint(beta,kinds[1],2)
 expected=ga(gc(2,4),ga((HE if kinds[0]==0 else HB)(a),(HE if kinds[1]==0 else HB)(b)))
 expected=ga(expected,dict(zip(cross_exponents,cs)))
 assert qq(xs,{},2)==expected
print("UNDILUTED_CORNER_IDENTITIES_PASS",4,flush=True)
v=variable(1,0);L=ga(v,gc(1,4))
upper2=ga(gs(gp(L,2,1),-F(43,16)),ga(gs(L,12),gc(1,-11)))
assert upper2=={(2,):-F(43,16),(1,):-F(19,2),(0,):-F(6)}
upper1=ga(ga(gs(gp(L,3,1),-F(3,8)),gs(gp(L,2,1),F(71,16))),ga(gs(L,-F(49,2)),gc(1,42)))
assert upper1=={(3,):-F(3,8),(2,):-F(1,16),(1,):-F(7),(0,):-F(9)}
half_bound=ga(ga(gs(gp(L,4,1),-F(15,16)),gs(gp(L,3,1),F(141,32))),ga(gs(gp(L,2,1),-F(213,8)),ga(gs(L,F(195,2)),gc(1,-108))))
assert half_bound=={(4,):-F(15,16),(3,):-F(339,32),(2,):-F(255,4),(1,):-F(144),(0,):-F(102)}
print("DILUTION_BOUND_IDENTITIES_PASS",3,flush=True)
zeros=[]
for xs in product(range(1,9),repeat=4):
 L=sum(xs);lo=0;hi=(L+1)//2
 assert Q(xs+(lo,))>0 and Q(xs+(hi,))<0
 while hi-lo>1:
  mid=(lo+hi)//2
  if Q(xs+(mid,))>=0:lo=mid
  else:hi=mid
 if Q(xs+(lo,))==0:zeros.append(xs+(lo,))
assert not zeros
print("GENERAL_INTEGER_ROOT_SEARCH_PASS",4096,flush=True)
assert len(T)==152 and sum(map(len,CORE.values()))==5291 and len(KP)==7796
assert sum(len(p) for p in UA.values())==28723
assert sum(v[0] for v in CERTSUMMARY.values())==1155583
print("FINAL_GENERAL_FOUR_PORT_AUDIT_PASS",152,5291,7796,28723,180,27180,1155583,792,100,608,flush=True)
