# Verification materials

A Sharp Schur-Positivity Transition for Four-Port Clique Attachments
Version 1.0.0

Python 3, standard library only. Run the .py files from this folder without -O. The checks supplement the proofs in the manuscript.

Included files:
- core_jt_check.py
- four_port_classification.py
- sharp_check.py
